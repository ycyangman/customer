package cigna.cm.a.bean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cigna.cm.a.dbio.CMA001DBIO;
import cigna.cm.a.io.TBCMCCD001Io;
import cigna.cm.a.io.TBCMCCD002Io;
import cigna.zz.InfUtil;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.container.cache.Configurable;
import klaf.container.cache.DistributedCache;
import klaf.container.cache.data.CommonCode;
import klaf.inf.EisExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file             cigna.cm.a.bean.CMA001BEAN.java
 * @filetype         java source file
 * @brief            공통코드 모듈 후처리 및 공통코드조회 및 이력조회 빈
 * @author           양윤철
 * @version          1.0
 * @history
 * Version           성명                   일자                                변경내용
 * -----------       ------    -----------    ----------------- 
 * 1.0               양윤철                 2016. 7.06.     신규 작성
 * 
 */
/**
 * 공통코드 정보를 조회하기 위한 KlafBean class
 * 
 */
@KlafBean
public class CMA001BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * 공통코드관련 DBIO
	 */
	@Autowired
	private CMA001DBIO cma001dbio;

	/**
	 * 공통코드ID로 공통코드 상세리스트 조회(유효한 코드)
	 * 
	 * @param comnCdId
	 *            공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public List<CommonCode> getComnCdList(String comnCdId)
			throws ApplicationException {

		logger.debug("comnCdId = {}", comnCdId);
		logger.debug("[Build Test ....]comnCdId = {}", comnCdId);

		// 필수입력값체크
		if (StringUtils.isEmpty(comnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"공통코드ID" });
		}

		// 공통코드 정보 조회
		List<CommonCode> comnCdList = null;
		DistributedCache cache = null;

		// OnlineContext 이면 cache에서 먼저 조회하고 BatchContext 이면 DB에서 바로 조회하고 끝
		if (LApplicationContext.isOnlineContext()) {

			// FWCache search
			try {

				cache = new DistributedCache(
						Configurable.CLUSTERNAME_COMMONCODE);

				comnCdList = cache
						.getComnCdList(new String[] { comnCdId }, "Y");

			} catch (Exception e) {
				logger.debug("FW Cache getComnCdList is not available");
				// logger.error("FW Cache getComnCdList 처리중 에러발생 = >", e);
				// 20170310 배포를 위한 주석 추가
			}

			if (comnCdList == null || comnCdList.size() <= 0) {

				comnCdList = this.cma001dbio.selectMultiTBCMCCD001e(comnCdId,
						"%");

				// FW 캐쉬에 없고 DB에 있으면 이력 남김

				/*
				 * 라이나생명 캐쉬 미사용 if ( comnCdList != null && comnCdList.size() > 0
				 * ) { if(cache != null) { try {
				 * cache.putComnCdList(comnCdList); } catch (Exception e) {
				 * logger.error("FW Cache 처리중 에러발생 = >", e); } }
				 * 
				 * callInsertOneTBCMCCD004(comnCdId, "getComnCdList"); }
				 */

			}
		} else {
			comnCdList = this.cma001dbio.selectMultiTBCMCCD001e(comnCdId, "%");
		}

		// 검색결과 리턴
		return comnCdList;

	}

	/**
	 * 상품관련 코드 조회
	 * 
	 * @param comnCdId
	 *            공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public Map<String, String> getComnPdCdList() throws ApplicationException {

		List<CommonCode> comnCdList = this.cma001dbio.selectMultiTBCMCCD001f();

		Map<String, String> comnPdMap = new HashMap<String, String>();

		for (CommonCode comnCd : comnCdList) {
			comnPdMap.put(comnCd.getComnCdId() + comnCd.getComnCdVl(),
					comnCd.getComnCdVlNm());
		}

		// 검색결과 리턴
		return comnPdMap;

	}

	/**
	 * 일렵값 List 코드 조회
	 * 
	 * @param comnCdId
	 *            공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public Map<String, String> getComnCdList(List<String> comnCds)
			throws ApplicationException {

		List<CommonCode> comnCdList = this.cma001dbio
				.selectMultiTBCMCCD001x(comnCds);

		Map<String, String> comnPdMap = new HashMap<String, String>();

		for (CommonCode comnCd : comnCdList) {
			comnPdMap.put(comnCd.getComnCdId() + comnCd.getComnCdVl(),
					comnCd.getComnCdVlNm());
		}

		// 검색결과 리턴
		return comnPdMap;

	}

	/**
	 * 공통코드ID로 공통코드 상세리스트 조회(모든 코드)
	 * 
	 * @param comnCdId
	 *            공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public List<CommonCode> getComnCdListAll(String comnCdId)
			throws ApplicationException {

		logger.debug("comnCdId = {}", comnCdId);
		// 필수입력값체크
		if (StringUtils.isEmpty(comnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"공통코드ID" });
		}

		// 공통코드 정보 조회
		List<CommonCode> comnCdList = null;
		DistributedCache cache = null;

		// OnlineContext 이면 cache에서 먼저 조회하고 BatchContext 이면 DB에서 바로 조회하고 끝
		if (LApplicationContext.isOnlineContext()) {

			// FWCache search
			try {

				cache = new DistributedCache(
						Configurable.CLUSTERNAME_COMMONCODE);

				comnCdList = cache
						.getComnCdList(new String[] { comnCdId }, "N");

			} catch (Exception e) {
				logger.debug("FW Cache getComnCdList is not available");
				// logger.error("FW Cache getComnCdList 처리중 에러발생 = >", e);

			}

			if (comnCdList == null || comnCdList.size() <= 0) {

				comnCdList = this.cma001dbio.selectMultiTBCMCCD001c(comnCdId,
						"%");

				// FW 캐쉬에 없고 DB에 있으면 이력 남김
				/*
				 * 라이나생명 캐쉬 미사용 if ( comnCdList != null && comnCdList.size() > 0
				 * ) { if(cache != null) { try {
				 * cache.putComnCdList(comnCdList); } catch (Exception e) {
				 * logger.error("FW Cache 처리중 에러발생 = >", e); } }
				 * //callInsertOneTBCMCCD004(comnCdId, "getComnCdList"); }
				 */

			}
		} else {
			comnCdList = this.cma001dbio.selectMultiTBCMCCD001c(comnCdId, "%");
		}

		// 검색결과 리턴
		return comnCdList;

	}

	/**
	 * 상위공통코드ID로 공통코드 상세리스트 조회(유효한 모든코드)
	 * 
	 * @param hrnkComnCdId
	 *            상위공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public List<CommonCode> getHrnkComnCdList(String hrnkComnCdId)
			throws ApplicationException {

		logger.debug("hrnkComnCdId = {}", hrnkComnCdId);
		DistributedCache cache = null;
		// 필수입력값체크
		if (StringUtils.isEmpty(hrnkComnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"상위공통코드ID" });
		}

		// 공통코드 정보 조회
		List<CommonCode> comnCdList = null;

		// OnlineContext 이면 cache에서 먼저 조회하고 BatchContext 이면 DB에서 바로 조회하고 끝
		if (LApplicationContext.isOnlineContext()) {

			/* FW API 미제공 */
			// FW Cache search
			try {
				cache = new DistributedCache(
						Configurable.CLUSTERNAME_COMMONCODE);
				comnCdList = cache.getComnCdList(new String[] { hrnkComnCdId },
						"Y");
			} catch (Exception e) {
				logger.debug("FW Cache getHrnkComnCdList is not available");
				// logger.error("FW Cache getHrnkComnCdList 처리중 에러발생 = >", e);

			}

			if (comnCdList == null || comnCdList.size() <= 0) {

				comnCdList = this.cma001dbio.selectMultiTBCMCCD001e(
						hrnkComnCdId, "%");

				// FW 캐쉬에 없고 DB에 있으면 이력 남김
				/*
				 * 라이나생명 캐쉬 미사용 if ( comnCdList != null && comnCdList.size() > 0
				 * ) { if(cache != null) { try {
				 * cache.putComnCdList(comnCdList); } catch (Exception e) {
				 * logger.error("FW Cache 처리중 에러발생 = >", e); } }
				 * 
				 * //callInsertOneTBCMCCD004(hrnkComnCdId, "getHrnkComnCdList");
				 * }
				 */

			}
		} else {
			comnCdList = this.cma001dbio.selectMultiTBCMCCD001e(hrnkComnCdId,
					"%");
		}

		// 검색결과 리턴
		return comnCdList;

	}

	/**
	 * 상위공통코드ID로 공통코드 상세리스트 조회(모든코드)
	 * 
	 * @param hrnkComnCdId
	 *            상위공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public List<CommonCode> getHrnkComnCdListAll(String hrnkComnCdId)
			throws ApplicationException {

		logger.debug("hrnkComnCdId = {}", hrnkComnCdId);

		// 필수입력값체크
		if (StringUtils.isEmpty(hrnkComnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"상위공통코드ID" });
		}

		// 공통코드 정보 조회
		List<CommonCode> comnCdList = null;
		DistributedCache cache = null;

		// OnlineContext 이면 cache에서 먼저 조회하고 BatchContext 이면 DB에서 바로 조회하고 끝
		if (LApplicationContext.isOnlineContext()) {

			/* FW API 미제공 */
			// FW Cache search
			try {
				cache = new DistributedCache(
						Configurable.CLUSTERNAME_COMMONCODE);
				comnCdList = cache.getComnCdList(new String[] { hrnkComnCdId },
						"N");
			} catch (Exception e) {
				logger.debug("FW Cache getHrnkComnCdList is not available");
				// logger.error("FW Cache getHrnkComnCdList 처리중 에러발생 = >", e);
			}

			if (comnCdList == null || comnCdList.size() <= 0) {

				comnCdList = this.cma001dbio.selectMultiTBCMCCD001c(
						hrnkComnCdId, "%");

				// FW 캐쉬에 없고 DB에 있으면 이력 남김
				/*
				 * 라이나생명 캐쉬 미사용 if ( comnCdList != null && comnCdList.size() > 0
				 * ) { if(cache != null) { try {
				 * cache.putComnCdList(comnCdList); } catch (Exception e) {
				 * logger.error("FW Cache 처리중 에러발생 = >", e); } }
				 * 
				 * //callInsertOneTBCMCCD004(hrnkComnCdId, "getHrnkComnCdList");
				 * }
				 */

			}
		} else {
			comnCdList = this.cma001dbio.selectMultiTBCMCCD001c(hrnkComnCdId,
					"%");
		}

		// 검색결과 리턴
		return comnCdList;

	}

	/**
	 * 하위공통코드ID로 공통코드 상세리스트 조회 (유효한코드)
	 * 
	 * @param lrnkComnCdId
	 *            하위공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public List<CommonCode> getLrnkComnCdList(String lrnkComnCdId)
			throws ApplicationException {

		logger.debug("lrnkComnCdId = {}", lrnkComnCdId);

		// 필수입력값체크
		if (StringUtils.isEmpty(lrnkComnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"하위공통코드ID" });
		}

		// 공통코드 정보 조회
		List<CommonCode> comnCdList = null;
		DistributedCache cache = null;

		// OnlineContext 이면 cache에서 먼저 조회하고 BatchContext 이면 DB에서 바로 조회하고 끝
		if (LApplicationContext.isOnlineContext()) {

			/* FW API 미제공 */
			// FWCache search
			try {
				cache = new DistributedCache(
						Configurable.CLUSTERNAME_COMMONCODE);
				comnCdList = cache.getComnCdList(new String[] { lrnkComnCdId },
						"Y");

			} catch (Exception e) {
				logger.debug("FW Cache getLrnkComnCdList is not available");
				// logger.error("FW Cache getLrnkComnCdList 처리중 에러발생 = >", e);
			}

			if (comnCdList == null || comnCdList.size() <= 0) {

				comnCdList = this.cma001dbio.selectMultiTBCMCCD001e(
						lrnkComnCdId, "%");

				// FW 캐쉬에 없고 DB에 있으면 이력 남김
				/*
				 * 라이나생명 캐쉬 미사용 if ( comnCdList != null && comnCdList.size() > 0
				 * ) { try { cache.putComnCdList(comnCdList); } catch (Exception
				 * e) { logger.error("FW Cache 처리중 에러발생 = >", e); }
				 * 
				 * //callInsertOneTBCMCCD004(lrnkComnCdId, "getLrnkComnCdList");
				 * }
				 */

			}
		} else {
			comnCdList = this.cma001dbio.selectMultiTBCMCCD001e(lrnkComnCdId,
					"%");
		}

		// 검색결과 리턴
		return comnCdList;

	}

	/**
	 * 하위공통코드ID로 공통코드 상세리스트 조회 (모든코드)
	 * 
	 * @param lrnkComnCdId
	 *            하위공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public List<CommonCode> getLrnkComnCdListAll(String lrnkComnCdId)
			throws ApplicationException {

		logger.debug("lrnkComnCdId = {}", lrnkComnCdId);

		// 필수입력값체크
		if (StringUtils.isEmpty(lrnkComnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"하위공통코드ID" });
		}

		// 공통코드 정보 조회
		List<CommonCode> comnCdList = null;
		DistributedCache cache = null;
		// OnlineContext 이면 cache에서 먼저 조회하고 BatchContext 이면 DB에서 바로 조회하고 끝
		if (LApplicationContext.isOnlineContext()) {

			/* FW API 미제공 */
			// FWCache search
			try {
				cache = new DistributedCache(
						Configurable.CLUSTERNAME_COMMONCODE);
				comnCdList = cache.getComnCdList(new String[] { lrnkComnCdId },
						"N");
			} catch (Exception e) {
				logger.debug("FW Cache getLrnkComnCdList is not available");
				// logger.error("FW Cache getLrnkComnCdList 처리중 에러발생 = >", e);
			}

			if (comnCdList == null || comnCdList.size() <= 0) {

				comnCdList = this.cma001dbio.selectMultiTBCMCCD001c(
						lrnkComnCdId, "%");

				// FW 캐쉬에 없고 DB에 있으면 이력 남김
				/*
				 * 라이나생명 캐쉬 미사용 if ( comnCdList != null && comnCdList.size() > 0
				 * ) { if(cache != null) { try {
				 * cache.putComnCdList(comnCdList); } catch (Exception e) {
				 * logger.error("FW Cache 처리중 에러발생 = >", e); } }
				 * logger.debug("insertMulti공통코드처리_이력테이블2()" );
				 * 
				 * //callInsertOneTBCMCCD004(lrnkComnCdId, "getLrnkComnCdList");
				 * }
				 */

			}
		} else {
			comnCdList = this.cma001dbio.selectMultiTBCMCCD001c(lrnkComnCdId,
					"%");
		}

		// 검색결과 리턴
		return comnCdList;

	}

	/**
	 * Map 객체내, 공통코드ID와 공통코드값으로 공통코드값명 조회
	 * 
	 * @param comnCdId
	 *            공통코드ID
	 * @param comnCdId
	 *            공통코드값
	 * @return String 공통코드값명
	 */
	public String getComnCdVlNm(Map<String, String> comnCdMap, String comnCdId,
			String comnCdVl) throws ApplicationException {

		if (comnCdMap.get(comnCdId + comnCdVl) == null) {

			boolean isCodeId = true;
			Set<String> keys = comnCdMap.keySet();
			for (String key : keys) {
				if (key != null) {
					if (key.indexOf(comnCdId) >= 0) {

						logger.error("comnCdId = {} , comnCdVl = {} 코드값 없음",
								comnCdId, comnCdVl);

						return ""; // 공통코드 ID는 있으나 코드값이 없는경우
					} else {
						isCodeId = false;
					}
				} else {
					isCodeId = false;
				}
			}

			// Map 에 공토코드ID가 없는경우 조회후 추가
			if (!isCodeId) {
				List<CommonCode> comnCdList = this.cma001dbio
						.selectMultiTBCMCCD001e(comnCdId, "%");
				for (CommonCode comnCd : comnCdList) {
					comnCdMap.put(comnCd.getComnCdId() + comnCd.getComnCdVl(),
							comnCd.getComnCdVlNm());
				}
			}

			return StringUtils.nvl(comnCdMap.get(comnCdId + comnCdVl), "");
			// return getComnCdVlNm(comnCdId, comnCdVl);

		} else {
			return comnCdMap.get(comnCdId + comnCdVl);
		}
	}

	/**
	 * 공통코드ID와 공통코드값으로 공통코드값명 조회
	 * 
	 * @param comnCdId
	 *            공통코드ID
	 * @param comnCdId
	 *            공통코드값
	 * @return String 공통코드값명
	 */
	public String getComnCdVlNm(String comnCdId, String comnCdVl)
			throws ApplicationException {

		logger.debug("comnCdId = {} , comnCdVl = {}", comnCdId, comnCdVl);

		// 필수입력값체크
		if (StringUtils.isEmpty(comnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"공통코드ID" });
		} else if (StringUtils.isEmpty(comnCdVl)) {
			throw new ApplicationException("APCME0005", null,
					new Object[] {
							new Throwable().getStackTrace()[0].getMethodName(),
							"공통코드값" });
		}

		String strComnCdVlNm = null;
		DistributedCache cache = null;

		// OnlineContext 이면 cache에서 먼저 조회하고 BatchContext 이면 DB에서 바로 조회하고 끝
		if (LApplicationContext.isOnlineContext()) {

			// 공통코드 정보 조회(FWCache search)

			try {
				cache = new DistributedCache(
						Configurable.CLUSTERNAME_COMMONCODE);
				CommonCode code = cache.getComnCd(new String[] { comnCdId,
						comnCdVl });

				if (code != null) {
					strComnCdVlNm = code.getComnCdVlNm();
					logger.debug("code= {}, strComnCdVlNm = {}", code,
							strComnCdVlNm);
				}
			} catch (Exception e) {
				logger.debug("FW Cache getComnCd is not available");
				// logger.debug("FW Cache getComnCd 처리중 에러발생 = >", e);
			}

			if (StringUtils.isEmpty(strComnCdVlNm)) {
				List<CommonCode> comnCdList = null;

				if (cache != null) {
					/* commCdId에 포함된 공통코드 정보를 한 건 조회하더라도 전체를 조회해서 Caching한다 */
					comnCdList = this.cma001dbio.selectMultiTBCMCCD001c(
							comnCdId, "%");

					if (comnCdList != null && comnCdList.size() > 0) {
						try {
							cache.putComnCdList(comnCdList);
							CommonCode code = cache.getComnCd(new String[] {
									comnCdId, comnCdVl });
							if (code != null) {
								strComnCdVlNm = code.getComnCdVlNm();
							}
						} catch (Exception e) {
							logger.debug("FW Cache getComnCd is not available");
							// logger.error("FW Cache 처리중 에러발생 = >", e);
						}
					}
				}

				if (StringUtils.isEmpty(strComnCdVlNm)) {
					comnCdList = this.cma001dbio.selectMultiTBCMCCD001c(
							comnCdId, comnCdVl);
					if (comnCdList.size() > 0) {
						strComnCdVlNm = comnCdList.get(0).getComnCdVlNm();
					}
				}
				logger.debug("strComnCdVlNm = {}", strComnCdVlNm);
				logger.debug("insertMulti공통코드처리_이력테이블2()");

				// callInsertOneTBCMCCD004(comnCdId, "getComnCd");
			}
		} else {

			// 공통코드 정보 조회(DB)
			List<CommonCode> comnCdList = this.cma001dbio
					.selectMultiTBCMCCD001c(comnCdId, comnCdVl);

			logger.debug("comnCdList= {}", comnCdList);

			if (comnCdList != null && comnCdList.size() > 0) {
				strComnCdVlNm = comnCdList.get(0).getComnCdVlNm();
			}

		}

		/*
		 * 2013.03.25 정창수부장님 요청 코드값이 등록이 안 된 경우 ApplicationException 추가
		 * APCME0022 : 유효하지 않는 코드입니다. / {0}의 {1}코드를 등록하세요.
		 */
		if (StringUtils.isEmpty(strComnCdVlNm)) {
			strComnCdVlNm = "";
			// 2016.03.02 에러안나게 함
			// throw new ApplicationException( "APCME0022", null, new Object[]{
			// comnCdId, comnCdVl });
		}

		// 검색결과 리턴
		return strComnCdVlNm;

	}

	/**
	 * 공통코드목록 조회
	 * 
	 * @param comnCdId
	 * @param comnCdNm
	 * @return List<TBCMCCD001Io> 공통코드상세
	 * @throws ApplicationException
	 */
	public List<TBCMCCD001Io> getComnCdList(String comnCdId, String comnCdNm)
			throws ApplicationException {

		// 1. 필수입력값체크
		if (StringUtils.isEmpty(comnCdId) && StringUtils.isEmpty(comnCdNm)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"공통코드ID, 공통코드명" });
		}

		// 2. 공통코드목록 조회
		List<TBCMCCD001Io> comnCdList = this.cma001dbio.selectMultiTBCMCCD001a(
				comnCdId, comnCdNm);

		return comnCdList;
	}

	/**
	 * 공통코드상세 조회
	 * 
	 * @param comnCdId
	 * @return List<TBCMCCD002Io> 공통코드상세
	 * @throws ApplicationException
	 */
	public List<TBCMCCD002Io> getComnCdDetailList(String comnCdId)
			throws ApplicationException {

		// 1. 필수입력값체크
		if (StringUtils.isEmpty(comnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"공통코드ID" });
		}

		// 2. 공통코드상세 조회
		List<TBCMCCD002Io> comnCdDetailList = this.cma001dbio
				.selectMultiTBCMCCD002a(comnCdId);

		return comnCdDetailList;
	}

	/**
	 * 공통코드ID로 공통코드 상세리스트 조회
	 * 
	 * @param comnCdId
	 *            공통코드ID
	 * @return List<CommonCode> 공통코드 리스트
	 */
	public List<CommonCode> getComnCdListCache(String comnCdId)
			throws ApplicationException {

		logger.debug("comnCdId = {}", comnCdId);

		// 필수입력값체크
		if (StringUtils.isEmpty(comnCdId)) {
			throw new ApplicationException("APCME0005", null, new Object[] {
					new Throwable().getStackTrace()[0].getMethodName(),
					"공통코드ID" });
		}

		// 공통코드 정보 조회
		List<CommonCode> comnCdList = null;

		// FWCache search
		try {

			DistributedCache cache = new DistributedCache(
					Configurable.CLUSTERNAME_COMMONCODE);

			comnCdList = cache.getComnCdList(new String[] { comnCdId }, "N");

		} catch (Exception e) {

			logger.debug("FW Cache getComnCdList is not available");
			// logger.error("FW Cache getComnCdList 처리중 에러발생 = >", e);

		}

		// 검색결과 리턴
		return comnCdList;

	}

	/**
	 * 공통코드생성배치 ondemand batch 타입으로 호출
	 * 
	 * @param
	 * @return
	 */
	public void updateComCdList() throws ApplicationException {
		// 공통코드생성배치 ondemand batch 타입으로 호출
		try {
			InfUtil.startBatch("BCMAB01O",
					new String[] { "dummy=`date +%Y%m%d%H%M%S`" });
		} catch (EisExecutionException e1) {
			logger.error("InfUtil.startBatch error1 \n", e1);

			throw new ApplicationException("APNBE0019",
					new String[] { "공통코드생성" }); // {0} 처리가 불가능합니다.
		}
	}

	/**
	 * 공통메시지생성배치 ondemand batch 타입으로 호출
	 * 
	 * @param
	 * @return
	 */
	public void updateMsgCdList() throws ApplicationException {
		// 공통메시지생성배치 ondemand batch 타입으로 호출
		try {
			InfUtil.startBatch("BCMAB02O",
					new String[] { "dummy=`date +%Y%m%d%H%M%S`" });
		} catch (EisExecutionException e1) {
			logger.error("InfUtil.startBatch error1 \n", e1);

			throw new ApplicationException("APNBE0019",
					new String[] { "공통메시지생성" }); // {0} 처리가 불가능합니다.
		}
	}

	/*
	 * private void callInsertOneTBCMCCD004(String comnCdId, String method) {
	 * logger.debug("insertMulti공통코드처리_이력테이블2()" );
	 * 
	 * TBCMCCD004Io tbcmccd004io = new TBCMCCD004Io(); tbcmccd004io.setDtlWrkDt(
	 * DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) );
	 * tbcmccd004io.setWrkStcd(WRK_STCD_SEARCH);
	 * tbcmccd004io.setComnCdId(comnCdId); tbcmccd004io.setNote(method);
	 * tbcmccd004io.setLastChgrId(FwUtil.getUserId());
	 * tbcmccd004io.setLastChgPgmId(FwUtil.getPgmId());
	 * tbcmccd004io.setLastChgTrmNo(FwUtil.getTrmNo());
	 * 
	 * try { int iCnt = this.cma001dbio.insertOneTBCMCCD004(tbcmccd004io);
	 * logger.debug( "공통코드_이력테이블2 insert 건수 = {}" , iCnt ); } catch (Exception
	 * e) { logger.error("공통코드 이력 등록 오류: ", e); } }
	 */
}
