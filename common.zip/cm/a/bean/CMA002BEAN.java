package cigna.cm.a.bean;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.a.dbio.CMA002DBIO;
import cigna.cm.a.dbio.CMA003DBIO;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.a.domain.OrgEtcInfo;
import cigna.cm.a.domain.OrgInfo;
import cigna.cm.a.domain.OrgTelnoInfo;
import cigna.cm.a.domain.SalesInfo;
import cigna.cm.a.io.CMA002SVC00In;
import cigna.cm.a.io.CMA002SVC00Out;
import cigna.cm.a.io.CMA002SVC01Sub;
import cigna.cm.a.io.CMA002SVC02Sub;
import cigna.cm.a.io.CMA002SVC06Out;
import cigna.cm.a.io.KLAFCOMMONMSGIo;
import cigna.cm.a.io.TBCMCCD025Io;
import cigna.cm.a.io.TBSLEMP032Io;
import cigna.zz.FwUtil;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.container.cache.Configurable;
import klaf.container.cache.DistributedCache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

/**
 * @file            cigna.cm.a.bean.CMA002BEAN.java
 * @filetype        java source file
 * @brief           UI 업무지원 공통모듈 (KLAF공통메시지,조직검색,사원검색) BEAN
 * @author          박경화
 * @version         1.2
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               박경화                 2012. 7.26.       신규 작성
 * 0.6               박경화                 2012. 7.31.       개발 완료
 * 0.9               박경화                 2012. 7.31.       Class 테스트
 * 1.0               박경화                 2012. 7.31.       단위 테스트   
 * 1.1               박경화                 2012.11.06.       로그인정보 추가
 * 1.2               박경화                 2012.12.03.       메지시정보 페이징처리
 * 10.0              김정국                 2013.12.06.       캐쉬에 로딩된 영업일 정보 획득 로직의 버그 수정(DR 테스트 도중에 식별)
 */
/**
 * 로그인정보 및 사원권한정보를 조회하기 위한 KlafBean class
 *
 */
@KlafBean
public class CMA002BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/* 공통메시지 최종 Fetch 시간 정보 Caching */
	private final static String CACHE_MSG_FETCH_HOUR 	= "CM/CMA002BEAN#HOUR";
	/* 공통메시지 정보 Caching */
	private final static String CACHE_MSG_LIST       	= "CM/CMA002BEAN#MSG_LST";
	/* 공통메시지 최종변경일시 Caching */
	private final static String CACHE_LAST_CHG_DTM      = "CM/CMA002BEAN#LAST_DATE";
	/**
	 * KLAF 공통메시지 조회 DBIO
	 */	
	@Autowired
	private CMA002DBIO cma002dbio; 	
	
	/**
	 * 영업일정보조회
	 */	
	@Autowired
	private CMA003DBIO cma003dbio;
	
	/**
	 * Klaf 공통메시지목록 조회
	 * @param in
	 * @return List<KLAFCOMMONMSGIo>  공통메시지목록
	 * @throws ApplicationException
	 */
	public CMA002SVC00Out getKlafComnMsgList(CMA002SVC00In input) throws ApplicationException {
		CMA002SVC00Out output = new CMA002SVC00Out();
		String datetime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) + DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		String currentHour = datetime.substring(0, 10);
		String datehour = null;
		List<KLAFCOMMONMSGIo> list = null;
		String lastChgDtm2 = null;
				
		/* 
		 * 공통메시지가 변경여부를 최종으로 체크한 년월일시 - 한시간 단위로 체크 함 
		 * 즉 지난 시간대에 확인했으면 이번 시간대에 체크함
		 */
		datehour = (String)LApplicationContext.getDataContainer().get(CACHE_MSG_FETCH_HOUR);
		
		/* 1시간 단위로 공통메시지의 변경된 내용이 있는 지 확인 함. */
		if(!currentHour.equals(datehour)) {
			/* 최종변경일시분초를 조회함. */
			String commMsgLastDtm = cma002dbio.selectOneKLAFCOMMONMSGa();


			/* DB에 공통메시지가 최종으로 변경된 일시분초 */
			lastChgDtm2 = (String)LApplicationContext.getDataContainer().get(CACHE_LAST_CHG_DTM);

			/* 
			 * DB의 최종 변경일시와 Caching되어 있는 최종 변경일시가 다르면 
			 * 공통메시지 전체 목록을 조회한다.
			 */
			if(!commMsgLastDtm.equals(lastChgDtm2)) {
				list = this.cma002dbio.selectMultiKLAFCOMMONMSGa();
				/* 전체 목록을 조회후 메모리에 Caching함. */
				LApplicationContext.getDataContainer().put(CACHE_MSG_LIST, list);
			}
			/*
			 * 공통메시지의 최종 변경일시분초를 메모리에 Caching한다.
			 */
			LApplicationContext.getDataContainer().put(CACHE_LAST_CHG_DTM, commMsgLastDtm);
			
			/*
			 * 공통메시지의 변경이 있었는 지 없었는 지 여부를 확인한 시간대를 메모리에 Caching한다.
			 * 같은 시간대이면 DBIO를 하지 않기 위함임.
			 */
			LApplicationContext.getDataContainer().put(CACHE_MSG_FETCH_HOUR, currentHour);
		}
		
		lastChgDtm2 = (String)LApplicationContext.getDataContainer().get(CACHE_LAST_CHG_DTM);
		output.setLastChgrDtm(lastChgDtm2);
		output.setKlafComnMsgCnt(0);
		
		/* 변경된 건이 없으면 목록을 Output으로 보내지 않는다. */
		if(lastChgDtm2.equals(input.getLastChgrDtm())) {
			return output;
		}
		
		list = (List<KLAFCOMMONMSGIo>)LApplicationContext.getDataContainer().get(CACHE_MSG_LIST);
		/* 전체 목록을 Output으로 보내줌. */
		output.setKlafComnMsgList(list);
		return output;
	}
	
	
	/**
	 * 조직검색
	 * @param inqDvsn  조회구분
	 * @param inqNm    검색어
	 * @param orgKcd   조직종류
	 * @param orgStats 조직상태
	 * @param facOrgNo 상대조직번호
	 * @param pageNum  조회할페이지번호
	 * @param pageCount 페이지 size
	 * @return List<CMA002SVC01Sub> 조직목록
	 * @throws ApplicationException
	 */
	public List<CMA002SVC01Sub> getOrgList(String inqDvsn, String inqNm, String orgStats, String facOrgNo, String orgTpcd, String bzprtCd, int pageNum, int pageCount) throws ApplicationException {
		
		if (pageNum <= 0) {
			throw new ApplicationException("KIERE0016", null, new String[] { "공통" });
		}
		if (pageCount <= 0) {
			throw new ApplicationException("KIERE0017", null, new String[] { "공통" });
		}
		
		// 필수입력값체크
		if( StringUtils.isEmpty(inqNm) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직번호 또는 조직명 검색어" });
		}

		List<CMA002SVC01Sub> orgList = null;
		
		if(StringUtils.isEmpty(facOrgNo)){
			orgList = this.cma002dbio.selectMultiTBSLORG001a(inqDvsn, inqNm, orgStats, facOrgNo, orgTpcd, bzprtCd, pageNum, pageCount);
		}else{
			orgList = this.cma002dbio.selectMultiTBSLORG001(inqDvsn, inqNm, orgStats, facOrgNo, orgTpcd, bzprtCd, pageNum, pageCount);
		}

		return orgList;

	}
	
	
	/**
	 * 
	 * @param inqDvsn  조회구분
	 * @param inqNm    검색어
	 * @param rtmtDcd  퇴직구분
	 * @param orgNo    조직번호
	 * @param pageNum  조회할페이지번호
	 * @param pageCount 페이지 size
	 * @return List<CMA002SVC02Sub> 사원목록
	 * @throws ApplicationException
	 */
	public List<CMA002SVC02Sub> getEmplList(String inqDvsn, String inqNm, String emplTpcd, String rtmtDcd, String orgNo, String bzprtCd, int pageNum, int pageCount) throws ApplicationException {
		
		if (pageNum <= 0) {
			throw new ApplicationException("KIERE0016", null, new String[] { "공통" });
		}
		if (pageCount <= 0) {
			throw new ApplicationException("KIERE0017", null, new String[] { "공통" });
		}
		
		// 필수입력값체크
		if( StringUtils.isEmpty(inqNm) && StringUtils.isEmpty(orgNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호 또는 사원명 검색어 또는 조직번호" });
		}
		
		List<CMA002SVC02Sub> emplList = null;
		
		//2013.07.25 튜닝팀 요청 사원검색 쿼리문 수정
		if( !"1".equals(inqDvsn) && orgNo != null || "1".equals(inqDvsn) && inqNm == null && orgNo !=null){	//1. ENO 가 사용되지 않고, ORG_NO 사용될 경우 (사원번호)
			emplList = this.cma002dbio.selectMultiTBSLEMP001a(inqDvsn, inqNm, emplTpcd, rtmtDcd, orgNo, bzprtCd, pageNum, pageCount);
			
		}else if( orgNo == null && "2".equals(inqDvsn) && inqNm != null ) {		//2. ENO 가 사용되지 않고, ORG_NO 가 사용되지 않고  EMPL_MN (사원명)이 사용될 경우
			emplList = this.cma002dbio.selectMultiTBSLEMP001b(inqNm, emplTpcd, rtmtDcd, bzprtCd, pageNum, pageCount);
			
		}else if( inqNm == null && orgNo == null && emplTpcd != null ) {	//3. eno, org_no, empl_nm 이 사용되지 않고, empl_tpcd 조건이 사용될 경우 
			emplList = this.cma002dbio.selectMultiTBSLEMP001c(emplTpcd, rtmtDcd, bzprtCd, pageNum, pageCount);
			
//		}else if( ("1".equals(inqDvsn) && inqNm != null) || ( inqNm == null && emplTpcd == null && "9".equals(rtmtDcd) && orgNo == null ) || ( inqNm == null && emplTpcd == null && orgNo == null && !"9".equals(rtmtDcd) )) { //4. eno 조건이 사용되거나, 아무런 조건이 사용되지 않을 경우이거나, rtmt_dt 조건만 사용될 경우
//			emplList = this.cma002dbio.selectMultiTBSLEMP001(inqDvsn, inqNm, emplTpcd, rtmtDcd, orgNo, pageNum, pageCount);
			
		}else{	// 그 이외 항목
			emplList = this.cma002dbio.selectMultiTBSLEMP001(inqDvsn, inqNm, emplTpcd, rtmtDcd, orgNo, bzprtCd, pageNum, pageCount);
		}
		return emplList;
	}
	
	/**
	 * 
	 * @param inqDvsn  조회구분
	 * @param inqNm    검색어
	 * @return List<CMA002SVC02Sub> 사원목록
	 * @throws ApplicationException
	 */
	public List<CMA002SVC02Sub> getEmplListEquals(String inqDvsn, String inqNm) throws ApplicationException {
		
		if (StringUtils.isEmpty(inqDvsn)) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호 또는 사원명 검색어 또는 조직번호" });
		}
		
		if (StringUtils.isEmpty(inqNm)) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호 또는 사원명 검색어 또는 조직번호" });
		}
		
		List<CMA002SVC02Sub> emplList = null;
		
		emplList = this.cma002dbio.selectMultiTBSLEMP001d(inqDvsn, inqNm);
		
		// 2건이상 나올경우 퇴직자는 제외한다
		if (!CollectionUtils.isEmpty(emplList)) {
			if (emplList.size() > 2) {
				for (int i = emplList.size()-1; i>=0; i--) {
					CMA002SVC02Sub cma002svc02Sub = emplList.get(i);
					
					// 해촉일자 99991231 이 아닌건은 퇴직자
					if (!"99991231".equals(cma002svc02Sub.getDsmDt())) {
						emplList.remove(i);
					}
				}
			}
		}

		return emplList;
	}
	
	/**
	 * <pre>
	 * 로그인 정보 조회
	 * CMA002BEAN.getLoginEmplInfo
	 * @return CommEmplInfo <br>
	 * eno:사원번호  <br>
	 * emplNm:사원명  <br>
	 * orgNo: 조직번호 <br>
	 * teamNo:팀번호 <br>
	 * rtmtDt: 퇴직일자<
	 * agncyEmplTpcd:대리점사원유형코드 <br>
	 * orgNm:조직명 <br>
	 * emplTpcd:사원유형코드 <br>
	 * emplKcd:사원종류코드 <br>
	 * jbdtyCd:직책코드 <br>
	 * ofrnkCd:직급코드 <br>
	 * bzprtCd:사업부문코드 <br>
	 * orgTpcd:조직유형코드 <br>
	 * orgAttrCd:조직속성코드 <br>
	 * orgKcd:조직종류코드 <br>
	 * orgChrctCd:조직특성코드 <br>
	 * hqOrgNo:본부조직번호 <br>
	 * hqOrgNm:본부조직명 <br>
	 * dofOrgNo:지점조직번호 <br>
	 * dofOrgNm:지점조직명 <br>
	 * fofOrgNo:영업소조직번호 <br>
	 * fofOrgNm:영업소조직명 <br>
	 * plazaOrgNo:플라자조직번호 <br> 
	 * plazaOrgNm:플라자조직명 <br>
	 * brnchOrgNo:브랜치조직번호 <br>
	 * brnchOrgNm:브랜치조직명 <br>
	 * propoDeptOrgNo:발의부서조직번호 <br>
	 * propoDeptOrgNm:발의부서조직명 <br>
	 * @throws ApplicationException
	 * </pre>
	 */
	public CommEmplInfo getLoginEmplInfo()  throws ApplicationException {
		
		CommEmplInfo emplinfo = null;
		
		// OnlineContext에서 호출할때만... BatchContext 에서 호출하면 rull return
		if ( LApplicationContext.isOnlineContext()) {
		
			// Context에서 LOGIN_EMEL_INFO 정보를 가져온다.
			emplinfo = (CommEmplInfo) LApplicationContext.getDataContainer().get("LOGIN_EMEL_INFO");
				
			if ( emplinfo != null ) {
				return emplinfo;
			} 
			
			String eno = FwUtil.getUserId();
			
			// 사원정보조회
			emplinfo = this.getEmplInfo(eno);
			
			// LOGIN_EMEL_INFO 정보를 Context에 넣는다.
			LApplicationContext.getDataContainer().put("LOGIN_EMEL_INFO",emplinfo);
		}
		
		
		return emplinfo;
	}
	
	/**
	 * 사원,조직정보 조회
	 * @param eno 사원번호
	 * @return CommEmplInfo <br>
	 * <per>
	 * eno: 0001320016   //사원번호 <br>
	 * emplNm: 이정가   //사원명 <br>
	 * orgNo: 008087   //조직번호 <br>
	 * teamNo: 01		//팀번호<br>
	 * rtmtDt: 99991231		//퇴직일자<br>
	 * agncyEmplTpcd : 1	//대리점사원유형코드<br>
	 * orgNm: 효원지점   //조직명 <br>
	 * emplTpcd: 11   //사원유형코드 <br>
	 * emplKcd: 10   //사원종류코드 <br>
	 * jbdtyCd: 1500   //직책코드 <br>
	 * ofrnkCd:     //직급코드 <br>
	 * bzprtCd: 01   //사업부문코드 <br>
	 * orgTpcd: 30   //조직유형코드 <br>
	 * orgAttrCd: 03   //조직속성코드 <br>
	 * orgKcd: 10   //조직종류코드 <br>
	 * orgChrctCd: 00   //조직특성코드 <br>
	 * hqOrgNo: 000104   //본부조직번호 <br>
	 * hqOrgNm: 경원지역본부   //본부조직명 <br>
	 * dofOrgNo: 000206   //지점조직번호 <br>
	 * dofOrgNm: 효원지점   //지점조직명 <br>
	 * fofOrgNo: 008087   //영업소조직번호 <br>
	 * fofOrgNm: 효원지점   //영업소조직명 <br>
	 * plazaOrgNo: 310001   //플라자조직번호 <br> 
	 * plazaOrgNm: 강남CSBRANCH   //플라자조직명 <br>
	 * brnchOrgNo: 330001   //브랜치조직번호 <br>
	 * brnchOrgNm: 수원CSBRANCH   //브랜치조직명 <br>
	 * propoDeptOrgNo: 008087   //발의부서조직번호 <br>
	 * propoDeptOrgNm: 효원지점  //발의부서조직명 <br>
	 * </per>
	 * @throws ApplicationException
	 */
	public CommEmplInfo getEmplInfo(String enoInput)  throws ApplicationException {
		String eno = enoInput;
		
		logger.debug( "사원번호 = {}" , eno );
		
		// 필수입력값체크
		if( StringUtils.isEmpty(eno) ){
		    // 입력값 오류처리
			eno = FwUtil.getUserId();
		}

		// 사원정보조회
		CommEmplInfo emplinfo = this.cma002dbio.selectOneTBSLEMP001(eno);
		
		logger.debug( "emplinfo = {}" , emplinfo );
		
		if ( emplinfo != null ) {
					
			String orgNo = emplinfo.getOrgNo();
			
			if( !StringUtils.isEmpty(orgNo) ){
				
				// 조직정보조회
				OrgInfo orginfo = this.getOrgInfo(orgNo);
				
				if ( orginfo != null ) {
					emplinfo.setOrgNm(orginfo.getOrgNm());            	//조직명
					emplinfo.setBzprtCd(orginfo.getBzprtCd());			//사업부문코드
					emplinfo.setOrgTpcd(orginfo.getOrgTpcd());			//조직유형코드
					emplinfo.setOrgAttrCd(orginfo.getOrgAttrCd());		//조직속성코드
					emplinfo.setOrgKcd(orginfo.getOrgKcd());			//조직종류코드
					emplinfo.setOrgChrctCd(orginfo.getOrgChrctCd());	//조직특성코드
					emplinfo.setHqOrgNo(orginfo.getHqOrgNo()); 			//본부조직번호
					emplinfo.setHqOrgNm(orginfo.getHqOrgNm());			//본부조직명
					emplinfo.setDofOrgNo(orginfo.getDofOrgNo());		//지점조직번호
					emplinfo.setDofOrgNm(orginfo.getDofOrgNm());		//지점조직명
					emplinfo.setFofOrgNo(orginfo.getFofOrgNo());		//영업소조직번호
					emplinfo.setFofOrgNm(orginfo.getFofOrgNm());		//영업소조직명
					emplinfo.setPropoDeptOrgNo(orginfo.getPropoDeptOrgNo()); //발의부서조직번호
					emplinfo.setPropoDeptOrgNm(orginfo.getPropoDeptOrgNm()); //발의부서조직명
				}
				
				// 조직기타정보조회
				OrgEtcInfo orgetcinfo = this.getOrgEtcInfo(orgNo);
				
				if ( orgetcinfo != null ) {
					emplinfo.setPlazaOrgNo(orgetcinfo.getPlazaOrgNo());	//플라자조직번호
					emplinfo.setPlazaOrgNm(orgetcinfo.getPlazaOrgNm());	//플라자조직명
					emplinfo.setBrnchOrgNo(orgetcinfo.getBrnchOrgNo());	//브랜치조직번호
					emplinfo.setBrnchOrgNm(orgetcinfo.getBrnchOrgNm());	//브랜치조직명
				}

				// 조직대표전화번호조회
				OrgTelnoInfo orgtelnoinfo = this.getOrgTelnoInfo(orgNo);
				
				if ( orgtelnoinfo != null ) {
					emplinfo.setOrgTelno(orgtelnoinfo.getOrgTelno());	//조직대표전화번호
				}
				
				
			}
		} 
		
		return emplinfo;
	}
	
	
	/**
	 * 조직정보 조회
	 * @param  조직번호
	 * @return OrgInfo <br>
	 * <per>
	 * orgNo: 008087   //조직번호 <br>
	 * orgNm: 효원지점   //조직명 <br>
	 * bzprtCd: 01   //사업부문코드 <br>
	 * orgTpcd: 30   //조직유형코드 <br>
	 * orgAttrCd: 03   //조직속성코드 <br>
	 * orgKcd: 10   //조직종류코드 <br>
	 * orgChrctCd: 00   //조직특성코드 <br>
	 * hqOrgNo: 000104   //본부조직번호 <br>
	 * hqOrgNm: 경원지역본부   //본부조직명 <br>
	 * dofOrgNo: 000206   //지점조직번호 <br>
	 * dofOrgNm: 효원지점   //지점조직명 <br>
	 * fofOrgNo: 008087   //영업소조직번호 <br>
	 * fofOrgNm: 효원지점   //영업소조직명 <br>
	 * propoDeptOrgNo: 008087   //발의부서조직번호 <br>
	 * propoDeptOrgNm: 효원지점  //발의부서조직명 <br>
	 * </per>
	 * @throws ApplicationException
	 */
	public OrgInfo getOrgInfo(String orgNoInput)  throws ApplicationException {
		String orgNo = orgNoInput;
		
		logger.debug( "조직번호 = {}" , orgNo );
		
		// 필수입력값체크
		if( StringUtils.isEmpty(orgNo) ){
		    // 입력값 오류처리
			orgNo = FwUtil.getDeptCd();
		}
		
		// 조직정보조회
		OrgInfo orginfo = this.cma002dbio.selectOneTBSLORG001a(orgNo);
		
		logger.debug( "orginfo = {}" , orginfo );
		
		return orginfo;
	}

	/**
	 * 조직기타정보 조회
	 * @param  조직번호
	 * @return OrgEtcInfo <br>
	 * <per>
	 * plazaOrgNo: 310001   //플라자조직번호 <br> 
	 * plazaOrgNm: 강남CSBRANCH   //플라자조직명 <br>
	 * brnchOrgNo: 330001   //브랜치조직번호 <br>
	 * brnchOrgNm: 수원CSBRANCH   //브랜치조직명 <br>
	 * </per>
	 * @throws ApplicationException
	 */
	public OrgEtcInfo getOrgEtcInfo(String orgNoInput)  throws ApplicationException {
		String orgNo = orgNoInput;
		
		logger.debug( "조직번호 = {}" , orgNo );
		
		// 필수입력값체크
		if( StringUtils.isEmpty(orgNo) ){
		    // 입력값 오류처리
			orgNo = FwUtil.getDeptCd();
		}
		
		// 조직기타정보조회
		OrgEtcInfo orgetcinfo = this.cma002dbio.selectOneTBSLORG001b(orgNo);
		
		logger.debug( "orgetcinfo = {}" , orgetcinfo );
		
		return orgetcinfo;
	}
	
	/**
	 * 조직전화번호 조회
	 * @param  조직번호
	 * @return OrgTelno <br>
	 * <per>
	 * orgTelno: 02-6330-0000   //조직대표전화번호 <br>
	 * </per>
	 * @throws ApplicationException
	 */
	public OrgTelnoInfo getOrgTelnoInfo(String orgNoInput)  throws ApplicationException {
		String orgNo = orgNoInput;
		
		logger.debug( "조직번호 = {}" , orgNo );
		
		// 필수입력값체크
		if( StringUtils.isEmpty(orgNo) ){
		    // 입력값 오류처리
			orgNo = FwUtil.getDeptCd();
		}
		
		// 조직대표전화번호조회
		OrgTelnoInfo orgtelnoinfo = this.cma002dbio.selectOneTBSLORG003(orgNo);
		
		logger.debug( "orgtelno = {}" , orgtelnoinfo );
		
		return orgtelnoinfo;
	}	
	
	/**
	 * 영업일관련 조회
	 * @param  
	 * @return SalesInfo <br>
	 * <per>
	 * baseDt: 20120915   //기준일자 <br>
	 * salesDt: 20120917  //영업일자 <br>
	 * bfSalesDt: 20120914  //전영업일자 <br>
	 * afSaesDt: 20120917   //익영업일자 <br>
	 * af2SaesDt: 20120918  //익익영업일자 <br>
	 * hldyKcd: 01  //휴일구분코드 <br>
	 * hldyYn: Y  //휴일여부 <br>
	 * </per>
	 * @throws ApplicationException
	 */
	public SalesInfo getSalesInfo(String baseDt)  throws ApplicationException {
		
		SalesInfo salesinfo = new SalesInfo();
		
		// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
		// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
		if ( StringUtils.isEmpty(baseDt) || !DateUtils.isValidDate(baseDt, DateUtils.EMPTY_DATE_TYPE) ) { 
			throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); 
		}
		
		// OnlineContext 이면 cache에서 먼저 조회하고 BatchContext 이면 DB에서 바로 조회하고 끝
		if ( LApplicationContext.isOnlineContext() ) {
		
			klaf.container.cache.data.SalesInfo cacheData  = getCacheSalesInfo(baseDt);
			
			logger.debug( "cacheData = {}" , cacheData );
			
			if ( cacheData == null ) {
				// 영업일정보조회
				salesinfo = this.cma003dbio.selectOneTBCMCCD005e(baseDt);
				
			} else {
				
				salesinfo.setBaseDt(cacheData.getBaseDt());			//기준일자
				salesinfo.setSalesDt(cacheData.getSalesDt());		//영업일자
				salesinfo.setBfSalesDt(cacheData.getBfSalesDt());	//전영업일자
				salesinfo.setAfSaesDt(cacheData.getAfSalesDt());	//익영업일자
				salesinfo.setAf2SaesDt(cacheData.getAf2SalesDt());	//익익영업일자
				salesinfo.setHldyKcd(cacheData.getHldyKcd());		//휴일구분코드
				salesinfo.setHldyYn(cacheData.getHldyYn());			//휴일여부
				
			}
		} else {
			// 영업일정보조회
			salesinfo = this.cma003dbio.selectOneTBCMCCD005e(baseDt);
		}
		
		logger.debug( "salesinfo = {}" , salesinfo );
		
		return salesinfo;
	}
	
	/**
	 * 영업일관련 조회(cache)
	 * @param baseDate 기준일자
	 * @return 기준일자에 대한 영업일 정보가 존재하면 영업일 정보를 리턴하고 그이외의 모든 상황에 대해서는 null을 리턴
	 */
	private klaf.container.cache.data.SalesInfo getCacheSalesInfo(String baseDate) {
		
		klaf.container.cache.data.SalesInfo sInfo = null;
		
		try{
			DistributedCache cache= new DistributedCache(Configurable.CLUSTERNAME_SALESINFO);
    		sInfo = cache.getSalesInfo(baseDate);
    	}catch(Exception e){
    		logger.debug("FW Cache getSalesInfo 처리중 에러발생(캐쉬기능 사용안함) ");
    		//logger.info("FW Cache getSalesInfo 처리중 에러발생(캐쉬기능 사용안함) = >", e);
    	}
    	return sInfo;
	}
	
	/**
	 * 사원 서비스화면별 버튼권한 조회
	 * @param eno		사원번호 		(ex. D000888103)
	 * @param svcScrnNo	서비스화면번호(ex. CMA001M0)
	 * @return String 	버튼권한코드	(ex. F0) <br>
	 * <per>
	 * #  버튼권한코드 CD_CM00016 <br><br>
	 * - 00 :	권한없음 <br>
	 * - 10 :	조회 권한 <br>
	 * - 30 :	처리,조회 권한 <br>
	 * - 50 :	인쇄,조회 권한 <br>
	 * - 70 :	인쇄,처리,조회 권한 <br>
	 * - 90 :	파일다운로드,조회 권한 <br>
	 * - B0 :	파일다운로드,처리,조회 권한 <br>
	 * - D0 :	파일다운로드,인쇄,조회 권한 <br>
	 * - F0 :	파일다운로드,인쇄,처리,조회 권한 <br>
	 * </per>
	 * @throws ApplicationException : 입력조건이 없을 경우, 검색결과가 없을경우 <br>
	 * <per>
	 * - 검색결과가 없을경우 ApplicationException 넘기므로 업무단에서 처리하여야 한다. <br>
	 * </per>
	 */
	public String getUserServiceScrnNoButnAuthCd(String eno, String svcScrnNo)  throws ApplicationException {
		
		String butnAuthCd = "";
		int butnAuthCdhex = 0; 
		
		logger.debug("사원번호 = {}, 서비스화면번호 = {}", eno,  svcScrnNo);
		
		// 필수입력값체크
		if( StringUtils.isEmpty(eno) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		if( StringUtils.isEmpty(svcScrnNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "서비스화면번호" });
		}
		
		//List<String> butnAuthCdList = this.cma002dbio.selectMultiTBCMCCD026(eno, svcScrnNo);
		
		List<String> butnAuthCdList =new ArrayList<String>();
		
		logger.debug("butnAuthCdList = {}", butnAuthCdList);
		
		for( String temp : butnAuthCdList ) {
			if( StringUtils.isEmpty(butnAuthCd) ){
				butnAuthCd = temp;
			} else {
				butnAuthCdhex = Integer.parseInt(temp, 16) | Integer.parseInt(butnAuthCd, 16);
				butnAuthCd    = Integer.toString(butnAuthCdhex, 16).toUpperCase();
			}
		}
		
		logger.debug("butnAuthCd = {}", butnAuthCd);
		
		if( StringUtils.isEmpty(butnAuthCd) ){
			throw new ApplicationException( "KIOKI0004", null);
		}
		
		return butnAuthCd;
	}
	
	/**
	 * Role 정보 조회
	 * @param eno 사원번호 
	 * @return Role 정보 리스트 <br>
	 * <per>
	 * roleDscNo: 23747   //역할식별번호 <br>
	 * roleNm: KDB_차세대개발자_전체권한  //역할명 <br>
	 * </per>
	 * @throws ApplicationException
	 */	
	public List<TBCMCCD025Io> getUserRoleInfo(String eno) throws ApplicationException {
		
		logger.debug("사원번호 = {}", eno);
		
		// 필수입력값체크
		if( StringUtils.isEmpty(eno) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		//List<TBCMCCD025Io> userRoleInfo = null;
		//userRoleInfo = this.cma002dbio.selectMultiTBCMCCD025(eno);
		
		List<TBCMCCD025Io> userRoleInfo = new ArrayList<TBCMCCD025Io>();
				
		/*
		logger.debug("userRoleInfo = {}", userRoleInfo);
		
		if( userRoleInfo == null ) {
			throw new ApplicationException( "KIOKI0004", null);
		}
		*/
		
		return userRoleInfo;
		
	}
	
	/**
	 * 사원겸직목록조회
	 * @param eno 사원번호
	 * @return cpstnOrgList 겸직정보
	 * @throws ApplicationException
	 */		
	public List<TBSLEMP032Io> getCpstnOrgNoList(String eno) throws ApplicationException {
		
		logger.debug("사원번호 = {}", eno);
		
		// 필수입력값체크
		if( StringUtils.isEmpty(eno) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		List<TBSLEMP032Io> cpstnOrgNoList = null;
		
		cpstnOrgNoList = this.cma002dbio.selectMultiTBSLEMP032(eno);
		
		logger.debug("cpstnOrgNoList = {}", cpstnOrgNoList);

		if( cpstnOrgNoList == null ) {
			throw new ApplicationException( "KIOKI0004", null);
		}
		
		return cpstnOrgNoList;
	}
	
	/**
	 * 사원겸직정보조회
	 * @param eno 사원번호
	 * @return cpstnOrgList 겸직정보
	 * @throws ApplicationException
	 */	
	public CMA002SVC06Out getCpstnOrgInfo(String cpstnOrgNo)  throws ApplicationException {
		
		CMA002SVC06Out cpstnInfo = new CMA002SVC06Out();
		
		if( !StringUtils.isEmpty(cpstnOrgNo) ){
			
			// 조직정보조회
			OrgInfo orginfo = this.getOrgInfo(cpstnOrgNo);
			
			logger.debug("orginfo11 = {}", orginfo);
			
			if ( orginfo != null ) {
				cpstnInfo.setBzprtCd(orginfo.getBzprtCd());			//사업부문코드
				cpstnInfo.setOrgTpcd(orginfo.getOrgTpcd());			//조직유형코드
				cpstnInfo.setOrgAttrCd(orginfo.getOrgAttrCd());		//조직속성코드
				cpstnInfo.setOrgKcd(orginfo.getOrgKcd());			//조직종류코드
				cpstnInfo.setOrgChrctCd(orginfo.getOrgChrctCd());	//조직특성코드
				cpstnInfo.setHqOrgNo(orginfo.getHqOrgNo()); 			//본부조직번호
				cpstnInfo.setHqOrgNm(orginfo.getHqOrgNm());			//본부조직명
				cpstnInfo.setDofOrgNo(orginfo.getDofOrgNo());		//지점조직번호
				cpstnInfo.setDofOrgNm(orginfo.getDofOrgNm());		//지점조직명
				cpstnInfo.setFofOrgNo(orginfo.getFofOrgNo());		//영업소조직번호
				cpstnInfo.setFofOrgNm(orginfo.getFofOrgNm());		//영업소조직명
				cpstnInfo.setPropoDeptOrgNo(orginfo.getPropoDeptOrgNo()); //발의부서조직번호
				cpstnInfo.setPropoDeptOrgNm(orginfo.getPropoDeptOrgNm()); //발의부서조직명
			}
			
			// 조직기타정보조회
			OrgEtcInfo orgetcinfo = this.getOrgEtcInfo(cpstnOrgNo);
			
			if ( orgetcinfo != null ) {
				cpstnInfo.setPlazaOrgNo(orgetcinfo.getPlazaOrgNo());	//플라자조직번호
				cpstnInfo.setPlazaOrgNm(orgetcinfo.getPlazaOrgNm());	//플라자조직명
				cpstnInfo.setBrnchOrgNo(orgetcinfo.getBrnchOrgNo());	//브랜치조직번호
				cpstnInfo.setBrnchOrgNm(orgetcinfo.getBrnchOrgNm());	//브랜치조직명
			}

			// 조직대표전화번호조회
			OrgTelnoInfo orgtelnoinfo = this.getOrgTelnoInfo(cpstnOrgNo);
			
			if ( orgtelnoinfo != null ) {
				cpstnInfo.setOrgTelno(orgtelnoinfo.getOrgTelno());	//조직대표전화번호
			}
			
		
		}
		return cpstnInfo;
	}

	/**
	 * 사원별 처리부서조직번호
	 * @param eno		사원번호 		(ex. 1000800251)
	 * @return String 	처리부서조직번호	(ex. 000111) <br>
	 * @throws ApplicationException : 입력조건이 없을 경우, 검색결과가 없을경우 <br>
	 * <per>
	 * - 검색결과가 없을경우 ApplicationException 넘기므로 업무단에서 처리하여야 한다. <br>
	 * </per>
	 */
	public String getPrcsDeptOrgNo(String eno)  throws ApplicationException {
		
		String prcsDeptOrgNo = "";
		
		logger.debug("사원번호 = {}", eno);
		
		// 필수입력값체크
		if( StringUtils.isEmpty(eno) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		prcsDeptOrgNo = this.cma002dbio.selectOneTBCMETC002(eno);
				
		logger.debug("prcsDeptOrgNo = {}", prcsDeptOrgNo);
		
		
		if( StringUtils.isEmpty(prcsDeptOrgNo) ){
			throw new ApplicationException( "KIOKI0004", null);
		}
		
		return prcsDeptOrgNo;
	}	
	
	/**
	 * 사원별 처리부서조직번호
	 * @param eno				사원번호 			(ex. 1000800251)
	 * @param prcsDeptOrgNo		처리부서조직번호 	(ex. 1000800251)
	 * @return String 			처리부서조직번호	(ex. 000111) <br>
	 * @throws ApplicationException : 입력조건이 없을 경우 <br>
	 */
	public void setPrcsDeptOrgNo(String eno, String prcsDeptOrgNo)  throws ApplicationException {
		
		logger.debug("사원번호 = {}", eno);
		logger.debug("처리부서조직번호 = {}", prcsDeptOrgNo);
		
		// 필수입력값체크
		if( StringUtils.isEmpty(eno) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		// 처리부서조직번호
		if( StringUtils.isEmpty(prcsDeptOrgNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "처리부서조직번호" });
		}
		
		// 정보 변경
		String lastChgrId 		= FwUtil.getUserId();			// 최종변경자ID
		String lastChgPgmId 	= FwUtil.getPgmId();			// 최종변경프로그램ID	
		String lastChgTrmNo 	= FwUtil.getTrmNo();			// 최종변경단말번호
				
		this.cma002dbio.updateOneTBCMETC002(eno, prcsDeptOrgNo, lastChgrId, lastChgPgmId, lastChgTrmNo);
		
		logger.debug("prcsDeptOrgNo = {}", prcsDeptOrgNo);
				
		if( StringUtils.isEmpty(prcsDeptOrgNo) ){
			throw new ApplicationException( "KIOKI0004", null);
		}
		
	}	
}

