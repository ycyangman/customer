package cigna.cm.a.bean;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import cigna.cm.a.dbio.CMA003DBIO;
import cigna.cm.a.io.CMA002SVC04Out;
import cigna.cm.a.io.CMA003SVC01In;
import cigna.cm.a.io.CMA003SVC03Sub;
import cigna.cm.a.io.TBCMCCD005Io;
import cigna.zz.BizDateUtil;
import cigna.zz.FwUtil;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.container.cache.Configurable;
import klaf.container.cache.DistributedCache;
import klaf.container.cache.data.SalesInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file            cigna.cm.a.bean.CMA003BEAN.java
 * @filetype        java source file
 * @brief           영업일 캘린더 조회, 영업일 캘린더 휴일정보 수정하는 빈
 * @author          양윤철
 * @version         1.0
 * @history
 * Version           성명                      일자                                변경내용
 * -----------       --------   -----------     ----------------- 
 * 1.0               양윤철                 2016.1.16       신규
 *
 */
@KlafBean
public class CMA003BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 영업일정보 조회, 수정하는 DBIO
	 */	
	@Autowired
	private CMA003DBIO cma003dbio; 
	
	/**
	 * 영업일 캘린더 정보 조회
	 * 
	 * @param argScalnYm 양력년월
	 * @return List<TBCMCCD005Io> 영업일 캘린더 정보
	 * @throws ApplicationException
	 */
	public List<CMA003SVC03Sub> getBizCalender(String argScalnYm) throws ApplicationException {
		
		boolean	bValidFmYmd;
		String		strFrYmd	= argScalnYm + "01";
		String		strToYmd 	= argScalnYm + "31";

		// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
		// APCME0004 : 디폴트 날짜 포맷은 "YYYY" 입니다.
		bValidFmYmd = DateUtils.isValidDate(strFrYmd, DateUtils.EMPTY_DATE_TYPE);
		if ( !bValidFmYmd ) { throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "기준년월" , "yyyyMM 날짜"}); }
		
		// 2. 시작일자와 종료일자 사이의 영엽일정보를 영업일테이블에서 가져온다.
		List<TBCMCCD005Io> bizDateList= this.cma003dbio.selectMultiTBCMCCD005(strFrYmd,strToYmd,"");
		List<CMA003SVC03Sub> bizDateListRet = new ArrayList<CMA003SVC03Sub>();		
		
		// 3. DB의 영업일 정보와 Cache의 영업일 정보의 휴일 여부 비교
		// 2016.01.17 라이나 캐쉬사용하지 않음
		//DistributedCache cache= new DistributedCache(Configurable.CLUSTERNAME_SALESINFO);
		
		SalesInfo salesInfo = null;
		CMA003SVC03Sub cma003svc03Sub = null;
		for(TBCMCCD005Io io : bizDateList) {
			cma003svc03Sub = new CMA003SVC03Sub();
			cma003svc03Sub.setScalnDt(io.getScalnDt());
			cma003svc03Sub.setLcalnDt(io.getLcalnDt());
			cma003svc03Sub.setLpmnYn(io.getLpmnYn());
			cma003svc03Sub.setJlndt(io.getJlndt());
			cma003svc03Sub.setWktms(io.getWktms());
			cma003svc03Sub.setDywkCd(io.getDywkCd());
			cma003svc03Sub.setHldyKcd(io.getHldyKcd());
			cma003svc03Sub.setHldyWkdayDcd(io.getHldyWkdayDcd());
			cma003svc03Sub.setNote(io.getNote());
			cma003svc03Sub.setLastChgrId(io.getLastChgrId());
			cma003svc03Sub.setLastChgPgmId(io.getLastChgPgmId());
			cma003svc03Sub.setLastChgTrmNo(io.getLastChgTrmNo());
			
			//salesInfo = new SalesInfo();
			//salesInfo = cache.getSalesInfo(io.getScalnDt());
			
			cma003svc03Sub.setHldyDiffYn("");
			
			if (salesInfo == null) {
				logger.info("Cache 내, 조회일자({})에 대한 데이터가 없습니다.", io.getScalnDt());
				cma003svc03Sub.setHldyDiffYn("");
			}
			else {
				if (!io.getHldyKcd().equals(salesInfo.getHldyKcd())) {
					cma003svc03Sub.setHldyDiffYn("N" + "(" + salesInfo.getHldyKcd() + ")");
				} 
				else {
					cma003svc03Sub.setHldyDiffYn("Y");
				}
			}
						
			bizDateListRet.add(cma003svc03Sub);
		}
		
		return bizDateListRet;
	}
	
	/**
	 * 영업일 캘린더 Cache 정보 조회
	 * 
	 * @param argScalnYm 양력년월
	 * @return List<CMA002SVC04Out> 영업일 캘린더 Cache 입력 정보
	 * @throws ApplicationException
	 */
	public List<CMA002SVC04Out> getBizCalendarCache(String argScalnYm) throws ApplicationException {
		
		Calendar cal = Calendar.getInstance();
		boolean bValidFmYmd;
		String strFrYmd = argScalnYm + "01";
		
		// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
		// APCME0004 : 디폴트 날짜 포맷은 "YYYY" 입니다.
		bValidFmYmd = DateUtils.isValidDate(strFrYmd, DateUtils.EMPTY_DATE_TYPE);
		if ( !bValidFmYmd ) { throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "기준년월" , "yyyyMM 날짜"}); }
		
		// 입력 월의 마지막 날짜 계산
		String sYear = argScalnYm.substring(0, 4);
		String sMonth = argScalnYm.substring(4, 6);
		String sDay = "01";
		
		int dYear = Integer.parseInt(sYear);
		int dMonth = Integer.parseInt(sMonth);
		int dDay = Integer.parseInt(sDay);
		
		cal.set(dYear, dMonth - 1, dDay);
		int endDay = cal.getActualMaximum(Calendar.DATE);
		
		CMA002SVC04Out cma002svc04out = null;
		SalesInfo salesInfo = null;
		List<CMA002SVC04Out> cma002svc04outList = new ArrayList<CMA002SVC04Out>();
		
		DistributedCache cache = null;
		try {
			cache = new DistributedCache(Configurable.CLUSTERNAME_SALESINFO);
		}
		catch(Exception e){
			logger.debug("cache is not available : {}", e.getMessage());
		}

		String inqDay = "";
		
		for (int i = 1; cache!=null && i <= endDay; i++)
		{
			if (Integer.toString(i).length() == 1) {
				inqDay = argScalnYm + "0" + Integer.toString(i);
			} 
			else {
				inqDay = argScalnYm + Integer.toString(i);
			}
			logger.debug("조회일자 : {}", inqDay);
			
			cma002svc04out = new CMA002SVC04Out();
			salesInfo = new SalesInfo();
			
			salesInfo = cache.getSalesInfo(inqDay);
			
			if (salesInfo == null)
				throw new ApplicationException("KIOKI0004", new Object[]{"Cache 내, 조회일자{}에 대한 데이터가 존재하지 않습니다.", inqDay});
			
			logger.debug(salesInfo.toString());
			
			cma002svc04out = new CMA002SVC04Out();
			cma002svc04out.setBaseDt(salesInfo.getBaseDt());
			cma002svc04out.setSalesDt(salesInfo.getSalesDt());
			cma002svc04out.setBfSalesDt(salesInfo.getBfSalesDt());
			cma002svc04out.setAfSaesDt(salesInfo.getAfSalesDt());
			cma002svc04out.setAf2SaesDt(salesInfo.getAf2SalesDt());
			cma002svc04out.setHldyKcd(salesInfo.getHldyKcd());
			cma002svc04out.setHldyYn(salesInfo.getHldyYn());
			
			cma002svc04outList.add(cma002svc04out);
		}
		
		/*
		if(cma002svc04outList == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		*/
		logger.debug(cma002svc04outList.toString());
		
		return cma002svc04outList;
		
	}
	
	/**
	 * 영업일 캘린더 정보 수정
	 * 
	 * @param in 영업일 캘린더 수정정보
	 * @return int 수정건수
	 * @throws ApplicationException
	 */
	public int updateBizCalendar (CMA003SVC01In in) throws ApplicationException {
		
		int iCnt = 0;
		int iBizCalendarCnt = in.getBizCalendarListCnt();
		List<TBCMCCD005Io> bizCalendarList = in.getBizCalendarList();
		
		String hldyKcd;			// 휴일종류코드
		String hldyWkdayDcd;	// 휴일평일구분코드
		String scalnYm = in.getScalnYm(); // 해당월
		String lcalnDt;				// 음력일자
		
		logger.debug("ScalnYm= {}", scalnYm);
		logger.debug("iBizCalendarCnt= {}, bizCalendarList= {}", iBizCalendarCnt, bizCalendarList);
		
		//1. 필수입력값체크
		if ( scalnYm.isEmpty() ) {
			// 입력값 오류처리
			throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "기준년월" , "yyyyMM 날짜"});
		}
		
		if ( bizCalendarList == null || bizCalendarList.size() == 0 || iBizCalendarCnt <= 0 ) {
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iBizCalendarCnt }, new Object[]{ "캘린더" , "변경된 내용 없음" });
		}
		
		//2. 영업일 캘린더 임시휴일 정보 저장
		String lastChgrId 		= FwUtil.getUserId();			//최종변경자ID
		String lastChgPgmId 	= FwUtil.getPgmId();			// 최종변경프로그램ID	
		String lastChgTrmNo = FwUtil.getTrmNo();			// 최종변경단말번호
		
		for( TBCMCCD005Io bizCalendar : bizCalendarList ){ 

			hldyKcd		 =  bizCalendar.getHldyKcd() ;		// 변경전 정보 (원래 휴일종류 코드값 정보)
			hldyWkdayDcd =  bizCalendar.getHldyWkdayDcd() ;	// 변경후 정보 (화면에서 변경됐을 정보)
			lcalnDt = bizCalendar.getLcalnDt(); 			// 음력일자 변경 (수정 하지 않았을 경우, 기본 조회 값)
			
			// 2015-09-01 : 음력일자 입력 check
			if (lcalnDt == null || StringUtils.isEmpty(lcalnDt)) {
				throw new ApplicationException( "APCME0008", new Object[]{"음력일자"});
			}
			
			if (hldyWkdayDcd == null || hldyWkdayDcd.trim().length()!= 2) {
				logger.debug("휴일구분코드= {}", hldyWkdayDcd);
				throw new ApplicationException( "APCME0008", new Object[]{"휴일구분코드"});
			}			
		
//			if (BizDateInfo.HLDY_WKDAY_DCD_1.equals(hldyWkdayDcd) && BizDateInfo.HLDY_KCD_00.equals(hldyKcd))  {
//				bizCalendar.setHldyKcd(BizDateInfo.HLDY_KCD_99);	
//			} else if (BizDateInfo.HLDY_WKDAY_DCD_1.equals(hldyWkdayDcd) && !BizDateInfo.HLDY_KCD_00.equals(hldyKcd))  {
//				bizCalendar.setHldyKcd(hldyKcd);
//			} else {
//				bizCalendar.setHldyKcd(BizDateInfo.HLDY_KCD_00);
//			}
			
			//2014-02-28 : 휴일구분코드가 추가되어 화면에서 넘겨주는 코드를 그대로 사용하기 위함.
			bizCalendar.setHldyKcd(hldyWkdayDcd);
			bizCalendar.setLastChgrId(lastChgrId);
			bizCalendar.setLastChgPgmId(lastChgPgmId);
			bizCalendar.setLastChgTrmNo(lastChgTrmNo);
			
			//2015-09-01 : 음력일자 수정 부분 추가
			bizCalendar.setLcalnDt(lcalnDt);
			
			iCnt += this.cma003dbio.updateOneTBCMCCD005(bizCalendar); 
		}
		
		/* 캐쉬기능 사용안함 양윤철  2016.01.16		
		
		if ( iCnt > 0 ) {
			List<SalesInfo> salesInfos = this.cma003dbio.selectMultiTBCMCCD005a(scalnYmBefore, 3);
			
			logger.debug("salesInfos= {}", salesInfos);
			
			int iCachePupCnt = putSalesInfo(salesInfos);
			
			logger.debug("iCachePupCnt= {}", iCachePupCnt);
			
			if (iCachePupCnt <= 0) {
				// KIERE0005 : 입력하신 내용을 저장 할 수 없습니다. / {0}으로 저장 할 수 없습니다.
				throw new ApplicationException("KIERE0005", null, new Object[]{"영업일정보 cache 등록실패"});
			}
			
		}
		*/
		
		return iCnt;
	}
	
	/**
	 * 영업일정보 cache에 등록(1개월)
	 * @param baseMonth 기준년월
	 * @return
	 */
	public int putSalesInfo(String baseMonth) throws ApplicationException {
		
		//1. 필수입력값체크
		if ( baseMonth.isEmpty() ) {
			// 입력값 오류처리
			throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "기준년월" , "yyyyMM 날짜"});
		}
		
		List<SalesInfo> salesInfos = this.cma003dbio.selectMultiTBCMCCD005a(baseMonth, 1);
		
		return putSalesInfo(salesInfos);
	}
	
	/**
	 * 영업일정보 cache에 등록
	 * @param salesInfos
	 * @return
	 */
	private int putSalesInfo(List<SalesInfo> salesInfos) {
		
		DistributedCache cache = null;
		try {
			cache = new DistributedCache(Configurable.CLUSTERNAME_SALESINFO);
		}
		catch(Exception e){
			logger.debug("cache is not available : {}", e.getMessage());
		}
		if(cache != null) {
			return cache.putSalesInfo(salesInfos);
		}
		else {
			return 0;	
		}
		
	}
	
	/**
	 * 영업일정보 cache에서 삭제
	 * @param baseMonth 삭제년월
	 * @return
	 */
	public boolean removeSalesInfo(String baseMonth) throws ApplicationException {
		//1. 필수입력값체크
		if ( baseMonth.isEmpty() ) {
			// 입력값 오류처리
			throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "삭제년월" , "yyyyMM 날짜"});
		}
		
		DistributedCache cache= new DistributedCache(Configurable.CLUSTERNAME_SALESINFO);
		return cache.remove(new String[]{baseMonth});
	}
	
}

