package cigna.cm.a.bean;

import java.math.BigDecimal;

import cigna.cm.a.dbio.CMA004DBIO;
import cigna.cm.a.io.TBCMCCD007Io;
import cigna.cm.a.io.TBCMCCD008Io;
import cigna.cm.a.io.TBCMCCD012Io;
import cigna.cm.a.io.TBCSPRF006Io;
import cigna.zz.FwUtil;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file            cigna.cm.a.bean.CMA004BEAN.java
 * @filetype        java source file
 * @brief           채번관련 빈
 * @author          양윤철
 * @version         1.0
 * @history
 * Version           성명                      일자                                변경내용
 * -----------       --------   -----------     ----------------- 
 * 1.0               양윤철                 2016.1.16       신규
 * 1.1               박진성                 2016.2.24       getNewContNo() 고객계약번호 채번시 현재 고객번호에 일련번호가 없으면 0000으로 insert한다
 *
 */
@KlafBean
public class CMA004BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 채번관련 DBIO
	 */	
	@Autowired
	private CMA004DBIO cma004dbio; 	
	

	/**
	 * 영수증번호 채번
	 * @param String fofOrgNo    조직번호
	 * @param String rcptIsueDcd 영수증발행구분코드
	 * @return String 영수증번호 채번 [조직번호(6)+구분코드(1)+SEQ(7)]
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String getNewRcptNo	(String orgNo, String rcptIsueDcd) throws ApplicationException {
		
		int        iResult      	= 0;
		
		int        orgNoLen 		= 6;				// 조직번호길이
		int        rcptIsueDcdLen 	= 1;				// 영수증발행구분코드길이
		int        rptSeqLen 		= 7;				// 영수증일련번호길이
		
		BigDecimal newRcptSeq    	= BigDecimal.ZERO;	// 영수증일련번호
		String     newRcptNo     	= "";				// 영수증번호
		
		logger.debug("========================  영수증번호  채번 ======================");
		logger.debug("orgNo = {} , rcptIsueDcd = {}", orgNo, rcptIsueDcd );
		
		// 필수입력값체크
		if (StringUtils.isEmpty(orgNo) || orgNo.length() != orgNoLen ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직번호" });
		} 
		
		if (StringUtils.isEmpty(rcptIsueDcd) || rcptIsueDcd.length() != rcptIsueDcdLen ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "영수증발행구분코드" });
		} 
		
		//영업소조직번호, 영수증발행구분코드로 일련번호 조회.
		newRcptSeq =  this.cma004dbio.selectOneTBCMCCD007(orgNo, rcptIsueDcd);
		
		logger.debug("newRptSeq = {}", newRcptSeq );
		
		//현재 기준년월에 영수증일련번호가 없다. 인서트하자.
		if ( newRcptSeq == null || newRcptSeq.compareTo(BigDecimal.ZERO) == 0 ) {
			//일련번호 초기화.
			newRcptSeq = BigDecimal.ONE;

			TBCMCCD007Io tbcmccd007io = new TBCMCCD007Io();
			tbcmccd007io.setOrgNo(orgNo);
			tbcmccd007io.setRcptIsueDcd(rcptIsueDcd);
			tbcmccd007io.setRcptMknoNo(newRcptSeq);
			tbcmccd007io.setLastChgrId(FwUtil.getUserId());
			tbcmccd007io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd007io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			iResult = this.cma004dbio.insertOneTBCMCCD007(tbcmccd007io);
		} else {
			//일련번호 1 증가.
			newRcptSeq = newRcptSeq.add(BigDecimal.ONE);
			
			TBCMCCD007Io tbcmccd007io = new TBCMCCD007Io();
			tbcmccd007io.setOrgNo(orgNo);
			tbcmccd007io.setRcptIsueDcd(rcptIsueDcd);
			tbcmccd007io.setRcptMknoNo(newRcptSeq);
			tbcmccd007io.setLastChgrId(FwUtil.getUserId());
			tbcmccd007io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd007io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			//채번테이블 업데이트.
			iResult = this.cma004dbio.updateOneTBCMCCD007(tbcmccd007io);
		}
		
		if ( iResult == 1 ) {
			newRcptNo = orgNo + rcptIsueDcd + StringUtils.lpad( String.valueOf(newRcptSeq), rptSeqLen, "0");
		}
		
		return newRcptNo;

	}
	
	
	/**
	 * 지급관련 채번
	 * @param String payMknoDcd 지급채번구분코드(그룹코드)
	 * @param String mknoBaseVl     채번기준값
	 * @param String mknoNoLen  채번번호길이
	 * @return String newMknoNo [그룹코드(4)+년도(4)+SEQ(seqLength)]
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String getNewPayMknoNo	(String payMknoDcd, String mknoBaseVl, int mknoNoLen) throws ApplicationException {
		
		int        iResult      		= 0;
		
		int        payMknoDcdLen 		= 4;				// 지급채번구분코드(그룹코드)길이
		int        mknoYyLen 		    = 4;				// 채번기준값길이
		int        seqLen               = mknoNoLen - (payMknoDcdLen + mknoYyLen);				// 일련번호길이
		
		
		BigDecimal newMknoSeq    		= BigDecimal.ZERO;	// 채번일련번호
		String     newMknoNo     		= "";				// 채번번호
		
		logger.debug("========================  지급관련 채번 ======================");
		logger.debug("payMknoDcd = {} , mknoBaseVl = {}", payMknoDcd, mknoBaseVl );
		logger.debug("mknoNoLen = {} ", mknoNoLen );
		
		// 필수입력값체크
		if (StringUtils.isEmpty(payMknoDcd) || payMknoDcd.length() != payMknoDcdLen ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), " 지급채번구분코드(그룹코드)" });
		} 
		
		if ("CMRT".equals(payMknoDcd) || "CMRC".equals(payMknoDcd)) {
			if (StringUtils.isEmpty(mknoBaseVl) || mknoBaseVl.length() != 8 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채번기준값" });
			}
		}
		else { 
			if (StringUtils.isEmpty(mknoBaseVl) || mknoBaseVl.length() != mknoYyLen ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채번기준값" });
			}
		}
		
		//그룹코드, 채번년도로 일련번호 조회.
		newMknoSeq =  this.cma004dbio.selectOneTBCMCCD008(payMknoDcd, mknoBaseVl);
		
		logger.debug("newMknoSeq = {}", newMknoSeq );
		
		//현재 기준년월에 일련번호가 없다. 인서트하자.
		if ( newMknoSeq == null || newMknoSeq.compareTo(BigDecimal.ZERO) == 0 ) {
			//일련번호 초기화.
			newMknoSeq = BigDecimal.ONE;

			TBCMCCD008Io tbcmccd008io = new TBCMCCD008Io();
			tbcmccd008io.setPayMknoDcd(payMknoDcd);
			tbcmccd008io.setMknoBaseVl(mknoBaseVl);
			tbcmccd008io.setPayMknoNo(newMknoSeq);
			tbcmccd008io.setLastChgrId(FwUtil.getUserId());
			tbcmccd008io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd008io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			iResult = this.cma004dbio.insertOneTBCMCCD008(tbcmccd008io);
		} else {
			//일련번호 1 증가.
			newMknoSeq = newMknoSeq.add(BigDecimal.ONE);
			
			TBCMCCD008Io tbcmccd008io = new TBCMCCD008Io();
			tbcmccd008io.setPayMknoDcd(payMknoDcd);
			tbcmccd008io.setMknoBaseVl(mknoBaseVl);
			tbcmccd008io.setPayMknoNo(newMknoSeq);
			tbcmccd008io.setLastChgrId(FwUtil.getUserId());
			tbcmccd008io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd008io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			//채번테이블 업데이트.
			iResult = this.cma004dbio.updateOneTBCMCCD008(tbcmccd008io);
		}
		
		if ( iResult == 1 ) {
			if ("CMRT".equals(payMknoDcd) || "CMRC".equals(payMknoDcd)) {
				
				newMknoNo = payMknoDcd + mknoBaseVl + StringUtils.lpad( String.valueOf(newMknoSeq), 8, "0");
			} else {
				newMknoNo = payMknoDcd + mknoBaseVl + StringUtils.lpad( String.valueOf(newMknoSeq), seqLen, "0");
			}
		}
		
		return newMknoNo;

	}

	
	
	/**
	 * 지급관련 채번
	 * @param String payMknoDcd 지급채번구분코드(그룹코드)
	 * @param String mknoNoLen 채번번호길이
	 * @return String newMknoNo [그룹코드(4)+SEQ(seqLength)]
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String getNewPayMknoNo	(String payMknoDcd, int mknoNoLen) throws ApplicationException {
		
		int        iResult      		= 0;
		
		int        grpCdLen 		    = 4;				// 그룹코드길이
		int        seqLen               = mknoNoLen - grpCdLen;				// 일련번호길이
		
		BigDecimal newMknoSeq    		= BigDecimal.ZERO;	// 채번일련번호
		String     newMknoNo     		= "";				// 채번번호
		String     mknoBaseVl               = "0000";           // 채번년도
		
		logger.debug("========================  지급관련 채번 ======================");
		logger.debug("grpCd = {} , mknoNoLen = {}", payMknoDcd, mknoNoLen);
		
		// 필수입력값체크
		if (StringUtils.isEmpty(payMknoDcd) || payMknoDcd.length() != grpCdLen ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "그룹코드" });
		} 
		
		//그룹코드로 일련번호 조회.
		newMknoSeq =  this.cma004dbio.selectOneTBCMCCD008(payMknoDcd, mknoBaseVl);
		
		logger.debug("newMknoSeq = {}", newMknoSeq );
		
		//현재 기준년월에 일련번호가 없다. 인서트하자.
		if ( newMknoSeq == null || newMknoSeq.compareTo(BigDecimal.ZERO) == 0 ) {
			//일련번호 초기화.
			newMknoSeq = BigDecimal.ONE;

			TBCMCCD008Io tbcmccd008io = new TBCMCCD008Io();
			tbcmccd008io.setPayMknoDcd(payMknoDcd);
			tbcmccd008io.setMknoBaseVl(mknoBaseVl);
			tbcmccd008io.setPayMknoNo(newMknoSeq);
			tbcmccd008io.setLastChgrId(FwUtil.getUserId());
			tbcmccd008io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd008io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			iResult = this.cma004dbio.insertOneTBCMCCD008(tbcmccd008io);
		} else {
			//일련번호 1 증가.
			newMknoSeq = newMknoSeq.add(BigDecimal.ONE);
			
			TBCMCCD008Io tbcmccd008io = new TBCMCCD008Io();
			tbcmccd008io.setPayMknoDcd(payMknoDcd);
			tbcmccd008io.setMknoBaseVl(mknoBaseVl);
			tbcmccd008io.setPayMknoNo(newMknoSeq);
			tbcmccd008io.setLastChgrId(FwUtil.getUserId());
			tbcmccd008io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd008io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			//채번테이블 업데이트.
			iResult = this.cma004dbio.updateOneTBCMCCD008(tbcmccd008io);
			
		}
		
		if ( iResult == 1 ) {
			newMknoNo = payMknoDcd + StringUtils.lpad( String.valueOf(newMknoSeq), seqLen, "0");
		}
		
		return newMknoNo;

	}
	
	
	/**
	 * 고객계약 일련번호 등록
	 * @param  String custNo 고객번호
	 * @return String srno   일련번호 (4)
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int setNewCustNoSrno	(String custNo) throws ApplicationException {
		
		int        iResult    = 0;
		int        custNoLen  = 9;				 // 고객번호길이
		String     initSrno   = "0000";			 // 일련번호
		BigDecimal srno;                         // 일련번호
		
		logger.debug("========================  고객번호 일련번호 채번 ======================");
		logger.debug("custNo = {}", custNo);
		
		// 필수입력값체크
		if (StringUtils.isEmpty(custNo) || custNo.length() != custNoLen ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "고객번호" });
		} 

		//고객번호 일련번호 조회.
		srno = this.cma004dbio.selectOneTBCSPRF006(custNo);
		
		logger.debug("srno = {}", srno );
		
		//현재 고객번호에 일련번호가 없다.
		if ( srno == null ) {
			
			TBCSPRF006Io tbcsprf006io = new TBCSPRF006Io();
			tbcsprf006io.setCustNo(custNo);
			tbcsprf006io.setCustContLastNo(initSrno);
			tbcsprf006io.setLastChgOrgNo(FwUtil.getDeptCd());
			tbcsprf006io.setLastChgrId(FwUtil.getUserId());
			tbcsprf006io.setLastChgPgmId(FwUtil.getPgmId());
			tbcsprf006io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			iResult = this.cma004dbio.insertOneTBCSPRF006(tbcsprf006io);
		} else {
			throw new ApplicationException("KIERE0000", new Object[]{null}, new Object[]{null});
		}
		
		return iResult;

	}
	
		
	/**
	 * 지급관련 채번
	 * @param String payMknoDcd 지급채번구분코드(그룹코드)
	 * @param String mknoBaseVl     채번기준값
	 * @param String mknoNoLen  채번번호길이
	 * @return String newMknoNo [년월일(8)+SEQ(seqLength)]
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String getNewPayMkno	(String payMknoDcd, String mknoBaseVl, int mknoNoLen) throws ApplicationException {
		
		int        iResult      		= 0;
		
		int        payMknoDcdLen 		= 4;				// 지급채번구분코드(그룹코드)길이
		int        mknoBaseVlLen 		    = 8;				// 채번기준값길이
		int        seqLen               = mknoNoLen - mknoBaseVlLen;				// 일련번호길이
		
		BigDecimal newMknoSeq    		= BigDecimal.ZERO;	// 채번일련번호
		String     newMknoNo     		= "";				// 채번번호
		
		logger.debug("========================  지급관련 채번 ======================");
		logger.debug("payMknoDcd = {} , mknoBaseVl = {}", payMknoDcd, mknoBaseVl );
		logger.debug("mknoNoLen = {} ", mknoNoLen );
		
		// 필수입력값체크
		if (StringUtils.isEmpty(payMknoDcd) || payMknoDcd.length() != payMknoDcdLen ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), " 지급채번구분코드(그룹코드)" });
		} 
		
		if (StringUtils.isEmpty(mknoBaseVl) || mknoBaseVl.length() != mknoBaseVlLen ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채번기준값" });
		}
		
		//그룹코드, 채번년도로 일련번호 조회.
		newMknoSeq =  this.cma004dbio.selectOneTBCMCCD008(payMknoDcd, mknoBaseVl);
		
		logger.debug("newMknoSeq = {}", newMknoSeq );
		
		//현재 기준년월에 일련번호가 없다. 인서트하자.
		if ( newMknoSeq == null || newMknoSeq.compareTo(BigDecimal.ZERO) == 0 ) {
			//일련번호 초기화.
			newMknoSeq = BigDecimal.ONE;

			TBCMCCD008Io tbcmccd008io = new TBCMCCD008Io();
			tbcmccd008io.setPayMknoDcd(payMknoDcd);
			tbcmccd008io.setMknoBaseVl(mknoBaseVl);
			tbcmccd008io.setPayMknoNo(newMknoSeq);
			tbcmccd008io.setLastChgrId(FwUtil.getUserId());
			tbcmccd008io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd008io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			iResult = this.cma004dbio.insertOneTBCMCCD008(tbcmccd008io);
		} else {
			//일련번호 1 증가.
			newMknoSeq = newMknoSeq.add(BigDecimal.ONE);
			
			TBCMCCD008Io tbcmccd008io = new TBCMCCD008Io();
			tbcmccd008io.setPayMknoDcd(payMknoDcd);
			tbcmccd008io.setMknoBaseVl(mknoBaseVl);
			tbcmccd008io.setPayMknoNo(newMknoSeq);
			tbcmccd008io.setLastChgrId(FwUtil.getUserId());
			tbcmccd008io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd008io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			//채번테이블 업데이트.
			iResult = this.cma004dbio.updateOneTBCMCCD008(tbcmccd008io);
		}
		
		if ( iResult == 1 ) {
			newMknoNo = mknoBaseVl + StringUtils.lpad( String.valueOf(newMknoSeq), seqLen, "0");
		}
		
		return newMknoNo;

	}	
	
	
	/**
	 * 고객계약번호 채번
	 * @param  String custNo     고객번호
	 * @return String newContNo  고객계약번호채번 [고객번호(9)+일련번호(4)]
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String getNewContNo(String custNo) throws ApplicationException {
		
		int        iResult      		= 0;
		
		int        custNoLen 		    = 9;	// 고객번호길이
		int        seqLen               = 4;	// 일련번호길이
		
		BigDecimal srno;	                    // 일련번호
		BigDecimal newMknoSeq;	                // 채번일련번호
		String     newSrno = "";				// 일련번호
		String     newContNo = "";				// 고객계약번호
		
		logger.debug("========================  고객번호 일련번호 채번 ======================");
		logger.debug("custNo = {}", custNo);
		
		// 필수입력값체크
		if (StringUtils.isEmpty(custNo) || custNo.length() != custNoLen ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "고객번호" });
		} 

		//고객번호 일련번호 조회.
		srno = this.cma004dbio.selectOneTBCSPRF006(custNo);
		
		logger.debug("srno = {}", srno );
		
		//현재 고객번호에 일련번호가 없으면 0000으로 insert한다
		if ( srno == null ) {
			
			srno = new BigDecimal(0);
			
			TBCSPRF006Io tbcsprf006io = new TBCSPRF006Io();
			tbcsprf006io.setCustNo(custNo);
			tbcsprf006io.setCustContLastNo(StringUtils.lpad( String.valueOf(srno), seqLen, "0" ));
			tbcsprf006io.setLastChgOrgNo(FwUtil.getDeptCd());
			tbcsprf006io.setLastChgrId(FwUtil.getUserId());
			tbcsprf006io.setLastChgPgmId(FwUtil.getPgmId());
			tbcsprf006io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			iResult = this.cma004dbio.insertOneTBCSPRF006(tbcsprf006io);
		}
		
		//일련번호 1 증가.
		newMknoSeq = srno.add(BigDecimal.ONE);
		newSrno    = StringUtils.lpad( String.valueOf(newMknoSeq), seqLen, "0" );
		
		TBCSPRF006Io tbcsprf006io = new TBCSPRF006Io();
		tbcsprf006io.setCustNo(custNo);
		tbcsprf006io.setCustContLastNo(newSrno);
		tbcsprf006io.setLastChgOrgNo(FwUtil.getDeptCd());
		tbcsprf006io.setLastChgrId(FwUtil.getUserId());
		tbcsprf006io.setLastChgPgmId(FwUtil.getPgmId());
		tbcsprf006io.setLastChgTrmNo(FwUtil.getTrmNo());
		
		//채번테이블 업데이트.
		iResult = this.cma004dbio.updateOneTBCSPRF006(tbcsprf006io);
		
		if ( iResult == 1 ) {
			newContNo = custNo + newSrno;
		}
		
		return newContNo;

	}
	
	/**
	 * 공통업무관련 채번
	 * @param String mknoDcd 채번구분코드(그룹코드)
	 * @param String mknoYyMm   채번년월
	 * @param String mknoNoLen  채번번호길이
	 * @return String newMknoNo [그룹코드(4)+년월(4)+SEQ(12)]
	 * @throws ApplicationException
	 */
	public String getNewComnMknoNo	(String mknoDcd) throws ApplicationException {
		
		String mknoYyMn = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE).substring(2, 6);
		
		String newMknoNo = this.getNewComnMknoNo(mknoDcd, mknoYyMn, 12) ;
		
		return newMknoNo;
		
	}
	
	/**
	 * 공통업무관련 채번
	 * @param String mknoDcd 채번구분코드(그룹코드)
	 * @param String mknoYyMm   채번년월
	 * @param String mknoNoLen  채번번호길이
	 * @return String newMknoNo [그룹코드(4)+년월(4)+SEQ(seqLength)]
	 * @throws ApplicationException
	 */
	public String getNewComnMknoNo	(String mknoDcd, int seqLen) throws ApplicationException {
		
		String mknoYyMn = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE).substring(2, 6);
		
		String newMknoNo = this.getNewComnMknoNo(mknoDcd, mknoYyMn, seqLen) ;
		
		return newMknoNo;
		
	}
	
	/**
	 * 공통업무관련 채번
	 * @param String mknoDcd 채번구분코드(그룹코드)
	 * @param String mknoYyMm   채번년월
	 * @param String mknoNoLen  채번번호길이
	 * @return String newMknoNo [그룹코드(4)+년(2)+SEQ(seqLength)]
	 * @throws ApplicationException
	 */
	public String getNewComnMknoNoYy (String mknoDcd, int seqLen) throws ApplicationException {
		
		String mknoYyMn = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE).substring(2, 4);
		
		String newMknoNo = this.getNewComnMknoNo(mknoDcd, mknoYyMn, seqLen) ;
		
		return newMknoNo;
		
	}
	
	/**
	 * 공통업무관련 채번
	 * @param String mknoDcd 채번구분코드(그룹코드)
	 * @param String mknoYyMm   채번년월
	 * @param String mknoNoLen  채번번호길이
	 * @return String newMknoNo [그룹코드(4)+년월(6)+SEQ(seqLength)]
	 * @throws ApplicationException
	 */
	public String getNewComnMknoNoAll (String mknoDcd, int seqLen) throws ApplicationException {
		
		String mknoYyMn = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE).substring(0, 6);
		
		String newMknoNo = this.getNewComnMknoNo(mknoDcd, mknoYyMn, seqLen) ;
		
		return newMknoNo;
		
	}
	
	/**
	 * 공통업무관련 채번
	 * @param String comnMknoDcd 채번구분코드(그룹코드)
	 * @param String mknoYm      채번년월
	 * @param String mknoNoLen   채번번호길이
	 * @return String newMknoNo  [그룹코드(4)+년월(4)+SEQ(seqLength)]
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String getNewComnMknoNo	(String comnMknoDcd, String mknoYm, int seqLen) throws ApplicationException {
		
		int        iResult      		= 0;
		
		BigDecimal newMknoSeq    		= BigDecimal.ZERO;	// 채번일련번호
		String     newMknoNo     		= "";				// 채번번호
		
		logger.debug("========================  공통업무관련 채번 ======================");
		logger.debug("comnMknoDcd = {} , mknoYm = {}", comnMknoDcd, mknoYm );
		
		
		// 필수입력값체크
		if (StringUtils.isEmpty(comnMknoDcd) || comnMknoDcd.length() > 4 ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), " 채번구분코드(그룹코드)" });
		} 
		
		if (StringUtils.isEmpty(mknoYm) || mknoYm.length() > 6 ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채번년월" });
		}
		
		//그룹코드, 채번년월로 일련번호 조회.
		newMknoSeq =  this.cma004dbio.selectOneTBCMCCD012(comnMknoDcd, mknoYm);
		
		logger.debug("newMknoSeq = {}", newMknoSeq );

		
		//현재 기준년월에 일련번호가 없다. 인서트하자.
		if ( newMknoSeq == null || newMknoSeq.compareTo(BigDecimal.ZERO) == 0 ) {
			//일련번호 초기화.
			newMknoSeq = BigDecimal.ONE;

			TBCMCCD012Io tbcmccd012io = new TBCMCCD012Io();
			tbcmccd012io.setComnMknoDcd(comnMknoDcd);
			tbcmccd012io.setMknoYm(mknoYm);
			tbcmccd012io.setComnMknoNo(newMknoSeq);
			tbcmccd012io.setLastChgrId(FwUtil.getUserId());
			tbcmccd012io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd012io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			iResult = this.cma004dbio.insertOneTBCMCCD012(tbcmccd012io);
		} else {
			//일련번호 1 증가.
			newMknoSeq = newMknoSeq.add(BigDecimal.ONE);
			
			TBCMCCD012Io tbcmccd012io = new TBCMCCD012Io();
			tbcmccd012io.setComnMknoDcd(comnMknoDcd);
			tbcmccd012io.setMknoYm(mknoYm);
			tbcmccd012io.setComnMknoNo(newMknoSeq);
			tbcmccd012io.setLastChgrId(FwUtil.getUserId());
			tbcmccd012io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmccd012io.setLastChgTrmNo(FwUtil.getTrmNo());
			
			//채번테이블 업데이트.
			iResult = this.cma004dbio.updateOneTBCMCCD012(tbcmccd012io);
		}

		
		if ( iResult == 1 ) {
		
			newMknoNo = comnMknoDcd + mknoYm + StringUtils.lpad( String.valueOf(newMknoSeq), seqLen, "0");
		}
		
		return newMknoNo;

	}
	
	
	
}

