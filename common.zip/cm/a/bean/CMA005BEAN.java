package cigna.cm.a.bean;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.dbio.CMA005DBIO;
import cigna.cm.a.domain.FileDelInfo;
import cigna.cm.a.domain.FilePutInfo;
import cigna.cm.a.io.CMA005SVC00Sub;
import cigna.cm.a.io.CMA005SVC01Sub0;
import cigna.cm.a.io.CMA005SVC01Sub1;
import cigna.cm.a.io.CMA005SVC02In;
import cigna.cm.a.io.CMA005SVC02Sub;
import cigna.cm.a.io.CMA005SVC05Sub;
import cigna.cm.a.io.CMA005SVC06In;
import cigna.cm.a.io.CMA005SVC07In;
import cigna.cm.a.io.CMA005SVC08In;
import cigna.cm.a.io.CMA005SVC09In;
import cigna.cm.a.io.TBCMCCD016Io;
import cigna.cm.a.io.TBCMCCD017Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;

/**
 * @file            cigna.cm.a.bean.CMA005BEAN.java
 * @filetype        java source file
 * @brief           파일관리 BEAN
 * @author          양윤철
 * @version         1.0
 * @history
 * Version         성명                          일 자                 변경내용
 * -----------     ---------  -----------  ----------------- 
 * 1.0             양윤철                  2016.01.27.   단위 테스트   
 */
@KlafBean
public class CMA005BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 파일관리하는 DBIO
	 */	
	@Autowired
	private CMA005DBIO cma005dbio; 
	
	/**
	 * 채번관련 BEAN
	 */	
	@Autowired
	private CMA004BEAN cma004bean;
	
	
	/** 파일관리 채번구분코드 */
	private static final String FILE_MGNT_NO_MKNO_DCD = "FI";
	
	/** FOLDER SEPARATOR */
	private static final String FOLDER_SEPARATOR= "/";
	
	/** 파일경로명 (첨부 파일 upload용 Home directory : DOC_HOME=/SDATA/doc) */
	private static final String FILE_UPLOAD_DIR_PATH = "/sdata/doc";
	
	/** 결함관리 파일경로명 */
	private static final String FILE_DFCT_DIR_PATH = FILE_UPLOAD_DIR_PATH + "/cm/dfct";
	
	/**  엑셀(파일) 대량 업로드 파일경로 */
	private static final String UI_ONLINE_FILE_PATH = "/sdata/biz/ui/online";

	/**  메뉴정보 업로드 파일경로(로컬) */
	private static final String UI_MENU_FILE_PATH = "/sdata/biz/ui/menu";	

	/**  메뉴정보 업로드 파일경로(WEB) */
	private static final String WEB_MENU_FILE_PATH = "/HTDOCS/menu";

	/**  메뉴정보 EAI InterFace ID */
	private static final String MENU_INFO_EAI_INTERFACE_ID = "KLIFBIZ00WEB00AR0001";
	
	/** 파일이동경로명 */
//	private static final String FILE_MOVE_DIR_PATH = System.getenv("DOC_HOME") + "/bakup";
	
	/** 파일관리업무코드 결함관리 결함관리일 경우 */
	private static final String FILE_MGNT_BZ_CD_DFCT = "dfct";
	
	/**  레포트출력정보 파일 업로드 경로(WAS) */
	private static final String UI_REPORTOUT_FILE_PATH = "/sdata/biz/ui/report";	

	/**  레포트출력정보 파일 업로드 경로(WEB) */
	private static final String WEB_REPORTOUT_FILE_PATH = "/HTDOCS/Report";	

	/**  레포트출력정보 EAI InterFace ID */
	private static final String REPORTOUT_INFO_EAI_INTERFACE_ID = "KLIFBIZ00WEB00AR0002";
	
	/**
	 * 파일관리목록조회
	 * @param fileMgntNo 파일관리번호
	 * @param fileMgntNoPrcsYn 파일관리번호처리여부
	 * @return List<CMA005SVC00Sub> 파일관리목록
	 * @throws ApplicationException
	 */
	public List<CMA005SVC00Sub> getFileList(String fileMgntNo, String fileMgntNoPrcsYn) throws ApplicationException {
		
		logger.debug( "fileMgntNo : {} " , fileMgntNo );
		
		// 1. 필수입력값체크
		if( StringUtils.isEmpty(fileMgntNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "파일관리번호" });
		}
		
		// 2. 파일목록조회
		List<CMA005SVC00Sub> fileList = this.cma005dbio.selectMultiTBCMCCD016(fileMgntNo, fileMgntNoPrcsYn);
		
		return fileList;
	}
	
	/**
	 * 파일관리번호 처리여부 update
	 * @param fileMgntNo 파일관리번호
	 * @return List<CMA005SVC00Sub> 파일관리목록
	 * @throws ApplicationException
	 */
	public boolean setFileMgntNoPrcsYn(String fileMgntNo) throws ApplicationException {
		

		boolean bResult = false;
		
		logger.debug( "fileMgntNo : {} " , fileMgntNo );
		
		// 1. 필수입력값체크
		if( StringUtils.isEmpty(fileMgntNo) ){
			throw new ApplicationException( "KIERE0005", new Object[]{ "파일관리번호 필수항목 누락" } );
		}
		
		// 2. 파일관리번호 처리여부 update
		String lastChgrId 	= FwUtil.getUserId();  //최종변경자ID
		String lastChgPgmId = FwUtil.getPgmId();   // 최종변경프로그램ID	
		String lastChgTrmNo = FwUtil.getTrmNo();   // 최종변경단말번호
		
		int iResult = this.cma005dbio.updateOneTBCMCCD016(fileMgntNo, lastChgrId, lastChgPgmId, lastChgTrmNo);
		
		if (iResult == 1) {
			bResult = true;
		}
		
		return bResult;
	}	

	/**
	 * 파일추가
	 * @param fileMgntBzCd 파일관리업무코드
	 * @param fileMgntNo   파일관리번호
	 * @param fileListCnt  파일추가 목록건수
	 * @param fileList     파일추가 목록
	 * @return String 파일관리번호
	 * @throws ApplicationException
	 */
	public String putFileList(String fileMgntBzCdInput, String fileMgntNoInput, int fileListCnt, List<CMA005SVC01Sub0> fileList) throws ApplicationException {
		String fileMgntBzCd = fileMgntBzCdInput;
		String fileMgntNo = fileMgntNoInput;
		
		int iResult         = 0;                              // 파일처리건수
		int fileMaxSeq      = 0;                              // 파일순번 MAX
		
		
		logger.debug( "fileMgntBzCd : {}, fileMgntNo : {} " , fileMgntBzCd, fileMgntNo );
		
		if( StringUtils.isEmpty(fileMgntBzCd) && StringUtils.isEmpty(fileMgntNo)){
			throw new ApplicationException( "KIERE0005", new Object[]{ "파일업무코드 필수항목 누락" } );
		}
		
		if( fileList == null || fileList.size() == 0 || fileListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ fileListCnt }, new Object[]{ "파일목록" , "추가된 정보 없음" });
		}
		
		// 업로드 파일경로
		String uploadFilePath = FILE_UPLOAD_DIR_PATH.toLowerCase() + FOLDER_SEPARATOR + fileMgntBzCd.toLowerCase();
		
		if (FILE_MGNT_BZ_CD_DFCT.equalsIgnoreCase(fileMgntBzCd)) {
			
			fileMgntBzCd = "CM";
			
			uploadFilePath = FILE_DFCT_DIR_PATH;
			 
		}
		
		// 신규 등록시
		if ( StringUtils.isEmpty(fileMgntNo) ) {
		
			// 파일관리번호 채번_대문자
			fileMgntNo = this.cma004bean.getNewComnMknoNo(FILE_MGNT_NO_MKNO_DCD +  fileMgntBzCd.toUpperCase(), 12);
			
			logger.debug( "신규등록채번 fileMgntNo : {} " , fileMgntNo );
			
			TBCMCCD016Io tbcmccd016io = new TBCMCCD016Io();
			
			tbcmccd016io.setFileMgntNo(fileMgntNo);			   // 파일관리번호
			tbcmccd016io.setFileMgntBzCd(fileMgntBzCd);		   // 파일관리업무코드
			tbcmccd016io.setFilePathNm(uploadFilePath);        // 경로명
			tbcmccd016io.setFileRegDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));  // 등록일자
			tbcmccd016io.setFileRegEno(FwUtil.getUserId());    // 등록자사번  
			tbcmccd016io.setLastChgrId(FwUtil.getUserId());    // 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd016io.setLastChgPgmId(FwUtil.getPgmId());   // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd016io.setLastChgTrmNo(FwUtil.getTrmNo());   // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			// 파일관리 등록
			int iCnt = this.cma005dbio.insertOneTBCMCCD016(tbcmccd016io); 
			
			if ( iCnt != 1) {
				throw new ApplicationException( "KIERE0005", null, new Object[]{ "파일정보 등록 실패" });
			}
			
		// 파일추가시	
		} else {
			// 파일관리번호로 파일순번 MAX값 가져오기
			fileMaxSeq = this.cma005dbio.selectOneTBCMCCD017(fileMgntNo);
			
			if (fileMaxSeq == 0) {
				// APCME0014 : 미등록된 {0}입니다.
				throw new ApplicationException("APCME0014", new Object[]{"파일관리번호"});
			}
		}
		
		logger.debug( "fileMaxSeq : {} " , fileMaxSeq );
		
		// 파일생성 및 파일추가 정보 등록
		
		String atchOrgcpFileNm = "";    // 첨부원본파일명
		String atchSavFileNm   = "";    // 첨부저장파일명
		//String sfileType       = "";    // 파일 확장자
		
		//byte[] fileData        = null;  // 파일데이터
		
		//boolean bResult = false;        // 파일생성결과
		
		TBCMCCD017Io tbcmccd017io = null;
		
		List<String> filePrcsList = new ArrayList<String>();

		for( CMA005SVC01Sub0 fileInfo : fileList ){ 
			
			//fileData = fileInfo.getAtchFileData(); //스트림데이터 처리가 아닌 첨부파일 기저장 후 후처치개념
			atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();  // 첨부원본파일명
			
			fileMaxSeq++;
			
			if ( atchOrgcpFileNm != null && atchOrgcpFileNm.length() > 0 ) {
			
				atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();  // 첨부원본파일명
				
				//sfileType = atchOrgcpFileNm.substring(atchOrgcpFileNm.lastIndexOf('.'));  // 파일 확장자
				
				atchSavFileNm = fileInfo.getAtchSavFileNm(); // 첨부저장파일명 
				//atchSavFileNm = fileMgntNo + "_" + StringUtils.lpad( String.valueOf(fileMaxSeq), 5, "0") + sfileType;  // 첨부저장파일명
				
				logger.debug( "atchOrgcpFileNm : {}, atchSavFileNm : {} " , atchOrgcpFileNm, atchSavFileNm );
				
				// 파일생성(실저장)
				//bResult = writeByteToFile(uploadFilePath, atchSavFileNm, fileInfo.getAtchFileData(), null);
				
				//if ( bResult ) {
				
					try {
						
						filePrcsList.add(atchSavFileNm);
						
						tbcmccd017io = new TBCMCCD017Io();
						
						tbcmccd017io.setFileMgntNo(fileMgntNo);          // 파일관리번호
						tbcmccd017io.setFileSeq(fileMaxSeq);         // 파일순번
						tbcmccd017io.setAtchOrgcpFileNm(atchOrgcpFileNm);  // 첨부원본파일명
						tbcmccd017io.setAtchSavFileNm(atchSavFileNm);    // 저장파일명
						tbcmccd017io.setLastChgrId(FwUtil.getUserId());  // 최종변경자ID(LAST_CHGR_ID) 설정
						tbcmccd017io.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
						tbcmccd017io.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
						
						// 파일상세정보 등록
						iResult += this.cma005dbio.insertOneTBCMCCD017(tbcmccd017io);
						
					} catch(Exception e) {
						
						// 파일을 생성 저장했는데 Error이 나면 파일삭제
						if (filePrcsList.size() > 0) {
	
							int iDelCnt = delateFile(uploadFilePath, filePrcsList);
							
							logger.debug( "파일생성 할 건수 : {} 생성 실패 후 파일삭제건수 : {} " , filePrcsList.size(), iDelCnt );
						}
						
						throw new ApplicationException("KIERE0005", null, new Object[]{"파일처리실패"});
	
					}
				/*
				} 0				
				else {
					// 파일을 생성 저장했는데 Error이 나면 파일삭제
					if (filePrcsList.size() > 0) {

						int iDelCnt = delateFile(uploadFilePath, filePrcsList);
						
						logger.debug( "파일생성 할 건수 : {} 생성 실패 후 파일삭제건수 : {} " , filePrcsList.size(), iDelCnt );
					}
					
					throw new ApplicationException("KIERE0005", null, new Object[]{"파일처리실패"});
				}
				*/
			}
		}
		
		logger.debug( "filePrcsList : {} " , filePrcsList );
		
		logger.debug( "filePutListCnt : {}, 파일처리건수 : {} " , fileListCnt, iResult );
		
		return fileMgntNo;
	}
	
	/**
	 * 엑셀(파일) 대량 업로드 처리
	 * @param fileInfo 파일정보
	 * @return boolean
	 * @throws ApplicationException
	 */
	public boolean putFileInfo(CMA005SVC06In fileInfo) throws ApplicationException {
		
		boolean bResult = false;        // 파일생성결과
		
		logger.debug( "fileInfo : {}" , fileInfo );
		
		String svcScrnNo       = fileInfo.getSvcScrnNo();			// 서비스화면번호
		String batPgmId     = fileInfo.getBatPgmId();			// 배치프로그램ID
		String atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();    	// 첨부원본파일명
		String atchSavFileNm = fileInfo.getAtchSavFileNm(); // 첨부저장파일명
		
		//byte[] fileData        = fileInfo.getAtchFileData();  		// 파일데이터
		
		// 필수항목 체크
		if( StringUtils.isEmpty(batPgmId) ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "배치프로그램ID 필수항목 누락" } );
		}
		
		if( StringUtils.isEmpty(atchOrgcpFileNm) ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "첨부원본파일명 필수항목 누락" } );
		}
		
		/*
		if( fileData == null || fileData.length <= 0 ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "첨부파일데이터 필수항목 누락" } );
		}
		*/
		
		// 파일생성 후 OnDemand Batch 실행
		String userId		   = FwUtil.getUserId() ; 				// 사원번호
		String sysTime         = getDate("yyyyMMddHHmmssSSS");		// 배치호출시간 (yyyyMMddHHmmssSSS)
		String sfileType       = "";    // 파일 확장자
		
		sfileType = atchOrgcpFileNm.substring(atchOrgcpFileNm.lastIndexOf('.'));  // 파일 확장자
		
		//atchSavFileNm = batPgmId + "_" + userId  + "_" + sysTime + sfileType;  // 첨부저장파일명 
		
		logger.debug( "atchOrgcpFileNm : {}, atchSavFileNm : {} " , atchOrgcpFileNm, atchSavFileNm );
		
		// 파일생성(실저장)
		//bResult = writeByteToFile(UI_ONLINE_FILE_PATH, atchSavFileNm, fileData, fileInfo.getCsvHdDelYn());
		
		// OnDemand Batch 실행
		try {
			String fileFullPath = UI_ONLINE_FILE_PATH + FOLDER_SEPARATOR + atchSavFileNm;
			
			changeFileEncodingUTF8ToMS949(fileFullPath);
			
			// jabTime=20130415163402239, 
			// eno=D000888103, 
			// fileFullPath=/SDATA/biz/UI/online/batchJobID_D000888103_20130415163402239.xlsx, 
			// orgFileNm=휴일종류코드.xlsx, svcScrnNo=Template37
			
			String[] parameters = {"jabTime=" + sysTime, "eno=" + userId, "fileFullPath=" + fileFullPath, "orgFileNm=" + atchOrgcpFileNm, "svcScrnNo=" + svcScrnNo};
			
			logger.debug( "batBatPgmId : {}, parameters : {} " , batPgmId, parameters );
			
			InfUtil.startBatch(batPgmId, parameters);
			
		} catch(Exception e) {
			
			// 파일을 생성 저장했는데 Error이 나면 파일삭제

			boolean bDel = delateFile(UI_ONLINE_FILE_PATH, atchSavFileNm);
			
			logger.debug( "파일삭제 결과: {} " , bDel );
			
			throw new ApplicationException("KIERE0014", null, new Object[]{"파일처리실패"});

		}
		
		bResult = true;
		
		return bResult;
	}

	/**
	 * 파일추가(타팀제공)
	 * @param fileMgntBzCd 파일관리업무코드
	 * @param fileMgntNo   파일관리번호
	 * @param fileListCnt  파일추가 목록건수
	 * @param fileList     파일추가 목록
	 * @return String 파일관리번호
	 * @throws ApplicationException
	 */
	public String putFileListOther(String fileMgntBzCdInput, String fileMgntNoInput, int fileListCnt, List<FilePutInfo> fileList) throws ApplicationException {
		String fileMgntBzCd = fileMgntBzCdInput;
		String fileMgntNo = fileMgntNoInput;
		
		int iResult         = 0;                              // 파일처리건수
		int fileMaxSeq      = 0;                              // 파일순번 MAX
		
		logger.debug( "fileMgntBzCd : {}, fileMgntNo : {} " , fileMgntBzCd, fileMgntNo );
		
		if( StringUtils.isEmpty(fileMgntBzCd) && StringUtils.isEmpty(fileMgntNo)){
			throw new ApplicationException( "KIERE0005", new Object[]{ "파일업무코드 필수항목 누락" } );
		}
		
		if( fileList == null || fileList.size() == 0 || fileListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ fileListCnt }, new Object[]{ "파일목록" , "추가된 정보 없음" });
		}
		
		// 업로드 파일경로
		String uploadFilePath = FILE_UPLOAD_DIR_PATH.toLowerCase() + FOLDER_SEPARATOR + fileMgntBzCd.toLowerCase();
		
		if (FILE_MGNT_BZ_CD_DFCT.equalsIgnoreCase(fileMgntBzCd)) {
			
			fileMgntBzCd = "CM";
			
			uploadFilePath = FILE_DFCT_DIR_PATH;
			 
		}
		
		// 신규 등록시
		if ( StringUtils.isEmpty(fileMgntNo) ) {
		
			// 파일관리번호 채번
			fileMgntNo = this.cma004bean.getNewComnMknoNo(FILE_MGNT_NO_MKNO_DCD +  fileMgntBzCd.toUpperCase(), 12);
			
			logger.debug( "신규등록채번 fileMgntNo : {} " , fileMgntNo );
			
			TBCMCCD016Io tbcmccd016io = new TBCMCCD016Io();
			
			tbcmccd016io.setFileMgntNo(fileMgntNo);			   // 파일관리번호
			tbcmccd016io.setFileMgntBzCd(fileMgntBzCd);		   // 파일관리업무코드
			tbcmccd016io.setFilePathNm(uploadFilePath);        // 경로명
			tbcmccd016io.setFileRegDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));  // 등록일자
			tbcmccd016io.setFileRegEno(FwUtil.getUserId());    // 등록자사번  
			tbcmccd016io.setLastChgrId(FwUtil.getUserId());    // 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd016io.setLastChgPgmId(FwUtil.getPgmId());   // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd016io.setLastChgTrmNo(FwUtil.getTrmNo());   // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			// 파일관리 등록
			int iCnt = this.cma005dbio.insertOneTBCMCCD016(tbcmccd016io); 
			
			if ( iCnt != 1) {
				throw new ApplicationException( "KIERE0005", null, new Object[]{ "파일정보 등록 실패" });
			}
			
		// 파일추가시	
		} else {
			// 파일관리번호로 파일순번 MAX값 가져오기
			fileMaxSeq = this.cma005dbio.selectOneTBCMCCD017(fileMgntNo);
			
			if (fileMaxSeq == 0) {
				// APCME0014 : 미등록된 {0}입니다.
				throw new ApplicationException("APCME0014", new Object[]{"파일관리번호"});
			}
		}
		
		logger.debug( "fileMaxSeq : {} " , fileMaxSeq );
		
		// 파일생성 및 파일추가 정보 등록
		
		String atchOrgcpFileNm = "";    // 첨부원본파일명
		String atchSavFileNm   = "";    // 첨부저장파일명
		String sfileType       = "";    // 파일 확장자
		byte[] fileData        = null;  // 파일데이터
		
		boolean bResult = false;        // 파일생성결과
		
		TBCMCCD017Io tbcmccd017io = null;
		
		List<String> filePrcsList = new ArrayList<String>();
	
		for( FilePutInfo fileInfo : fileList ){ 
			
			fileData = fileInfo.getAtchImgFileCtnt();
			
			fileMaxSeq++;
			
			if ( atchOrgcpFileNm != null && atchOrgcpFileNm.length() > 0 ) {
				
				atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();  // 첨부원본파일명
				
				//sfileType = atchOrgcpFileNm.substring(atchOrgcpFileNm.lastIndexOf('.'));  // 파일 확장자
				
				atchSavFileNm = fileInfo.getAtchSavFileNm(); // 첨부저장파일명 
				//atchSavFileNm = fileMgntNo + "_" + StringUtils.lpad( String.valueOf(fileMaxSeq), 5, "0") + sfileType;  // 첨부저장파일명
				
				logger.debug( "atchOrgcpFileNm : {}, atchSavFileNm : {} " , atchOrgcpFileNm, atchSavFileNm );
				
				// 파일생성(실저장)
				//bResult = writeByteToFile(uploadFilePath, atchSavFileNm, fileInfo.getAtchFileData(), null);
				
				//if ( bResult ) {
				
					try {
						
						filePrcsList.add(atchSavFileNm);
						
						tbcmccd017io = new TBCMCCD017Io();
						
						tbcmccd017io.setFileMgntNo(fileMgntNo);          // 파일관리번호
						tbcmccd017io.setFileSeq(fileMaxSeq);         // 파일순번
						tbcmccd017io.setAtchOrgcpFileNm(atchOrgcpFileNm);  // 첨부원본파일명
						tbcmccd017io.setAtchSavFileNm(atchSavFileNm);    // 저장파일명
						tbcmccd017io.setLastChgrId(FwUtil.getUserId());  // 최종변경자ID(LAST_CHGR_ID) 설정
						tbcmccd017io.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
						tbcmccd017io.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
						
						// 파일상세정보 등록
						iResult += this.cma005dbio.insertOneTBCMCCD017(tbcmccd017io);
						
					} catch(Exception e) {
						
						// 파일을 생성 저장했는데 Error이 나면 파일삭제
						if (filePrcsList.size() > 0) {
	
							int iDelCnt = delateFile(uploadFilePath, filePrcsList);
							
							logger.debug( "파일생성 할 건수 : {} 생성 실패 후 파일삭제건수 : {} " , filePrcsList.size(), iDelCnt );
						}
						
						throw new ApplicationException("KIERE0005", null, new Object[]{"파일처리실패"});
	
					}
				/*
				} 0				
				else {
					// 파일을 생성 저장했는데 Error이 나면 파일삭제
					if (filePrcsList.size() > 0) {

						int iDelCnt = delateFile(uploadFilePath, filePrcsList);
						
						logger.debug( "파일생성 할 건수 : {} 생성 실패 후 파일삭제건수 : {} " , filePrcsList.size(), iDelCnt );
					}
					
					throw new ApplicationException("KIERE0005", null, new Object[]{"파일처리실패"});
				}
				*/
			}
		}
		
		logger.debug( "filePrcsList : {} " , filePrcsList );
		
		logger.debug( "filePutListCnt : {}, 파일처리건수 : {} " , fileListCnt, iResult );
		
		return fileMgntNo;
	}
	
	/**
	 * 파일추가(타경로)
	 * @param fileMgntBzCd 파일관리업무코드
	 * @param fileMgntNo   파일관리번호
	 * @param fileListCnt  파일추가 목록건수
	 * @param fileList     파일추가 목록
	 * @return String 파일관리번호
	 * @throws ApplicationException
	 */
	public String putFileListOtherPath(String fileMgntBzCdInput, String fileMgntNoInput, String filePathInput, int fileListCnt, List<FilePutInfo> fileList) throws ApplicationException {
		String fileMgntBzCd = fileMgntBzCdInput;
		String fileMgntNo = fileMgntNoInput;
		String uploadFilePath = filePathInput; // 업로드 파일경로
		
		int iResult         = 0;                              // 파일처리건수
		int fileMaxSeq      = 0;                              // 파일순번 MAX
		
		logger.debug( "fileMgntBzCd : {}, fileMgntNo : {} " , fileMgntBzCd, fileMgntNo );
		
		if( StringUtils.isEmpty(fileMgntBzCd) && StringUtils.isEmpty(fileMgntNo)){
			throw new ApplicationException( "KIERE0005", new Object[]{ "파일업무코드 필수항목 누락" } );
		}
		
		if( fileList == null || fileList.size() == 0 || fileListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ fileListCnt }, new Object[]{ "파일목록" , "추가된 정보 없음" });
		}
		
		// 신규 등록시
		if ( StringUtils.isEmpty(fileMgntNo) ) {
		
			// 파일관리번호 채번
			fileMgntNo = this.cma004bean.getNewComnMknoNo(FILE_MGNT_NO_MKNO_DCD +  fileMgntBzCd.toUpperCase(), 12);
			
			logger.debug( "신규등록채번 fileMgntNo : {} " , fileMgntNo );
			
			TBCMCCD016Io tbcmccd016io = new TBCMCCD016Io();
			
			tbcmccd016io.setFileMgntNo(fileMgntNo);			   // 파일관리번호
			tbcmccd016io.setFileMgntBzCd(fileMgntBzCd);		   // 파일관리업무코드
			tbcmccd016io.setFilePathNm(uploadFilePath);        // 경로명
			tbcmccd016io.setFileRegDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));  // 등록일자
			tbcmccd016io.setFileRegEno(FwUtil.getUserId());    // 등록자사번  
			tbcmccd016io.setLastChgrId(FwUtil.getUserId());    // 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd016io.setLastChgPgmId(FwUtil.getPgmId());   // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd016io.setLastChgTrmNo(FwUtil.getTrmNo());   // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			// 파일관리 등록
			int iCnt = this.cma005dbio.insertOneTBCMCCD016(tbcmccd016io); 
			
			if ( iCnt != 1) {
				throw new ApplicationException( "KIERE0005", null, new Object[]{ "파일정보 등록 실패" });
			}
			
		// 파일추가시	
		} else {
			// 파일관리번호로 파일순번 MAX값 가져오기
			fileMaxSeq = this.cma005dbio.selectOneTBCMCCD017(fileMgntNo);
			
			if (fileMaxSeq == 0) {
				// APCME0014 : 미등록된 {0}입니다.
				throw new ApplicationException("APCME0014", new Object[]{"파일관리번호"});
			}
		}
		
		logger.debug( "fileMaxSeq : {} " , fileMaxSeq );
		
		// 파일생성 및 파일추가 정보 등록
		
		String atchOrgcpFileNm = "";    // 첨부원본파일명
		String atchSavFileNm   = "";    // 첨부저장파일명
		
		TBCMCCD017Io tbcmccd017io = null;
		
		List<String> filePrcsList = new ArrayList<String>();
	
		for( FilePutInfo fileInfo : fileList ){ 
			
			fileMaxSeq++;
			atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();  // 첨부원본파일명
			atchSavFileNm = fileInfo.getAtchSavFileNm(); // 첨부저장파일명 
			
			if ( atchOrgcpFileNm != null && atchOrgcpFileNm.length() > 0 ) {
				
				logger.debug( "atchOrgcpFileNm : {}, atchSavFileNm : {} " , atchOrgcpFileNm, atchSavFileNm );
				
				try {
					
					filePrcsList.add(atchSavFileNm);
					
					tbcmccd017io = new TBCMCCD017Io();
					
					tbcmccd017io.setFileMgntNo(fileMgntNo);          // 파일관리번호
					tbcmccd017io.setFileSeq(fileMaxSeq);         // 파일순번
					tbcmccd017io.setAtchOrgcpFileNm(atchOrgcpFileNm);  // 첨부원본파일명
					tbcmccd017io.setAtchSavFileNm(atchSavFileNm);    // 저장파일명
					tbcmccd017io.setLastChgrId(FwUtil.getUserId());  // 최종변경자ID(LAST_CHGR_ID) 설정
					tbcmccd017io.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
					tbcmccd017io.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
					
					// 파일상세정보 등록
					iResult += this.cma005dbio.insertOneTBCMCCD017(tbcmccd017io);
					
				} catch(Exception e) {
					
					// 파일을 생성 저장했는데 Error이 나면 파일삭제
					if (filePrcsList.size() > 0) {

						int iDelCnt = delateFile(uploadFilePath, filePrcsList);
						
						logger.debug( "파일생성 할 건수 : {} 생성 실패 후 파일삭제건수 : {} " , filePrcsList.size(), iDelCnt );
					}
					
					throw new ApplicationException("KIERE0005", null, new Object[]{"파일처리실패"});

				}
			}
		}
		
		logger.debug( "filePrcsList : {} " , filePrcsList );
		
		logger.debug( "filePutListCnt : {}, 파일처리건수 : {} " , fileListCnt, iResult );
		
		return fileMgntNo;
	}

	/**
	 * 메뉴정보파일 업로드 처리
	 * @param fileInfo 파일정보
	 * @return boolean
	 * @throws ApplicationException
	 */
	public boolean putMenuInfoFile(CMA005SVC08In fileInfo) throws ApplicationException {
		
		boolean bResult = false;        // 파일생성결과
		
		String atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();    	// 첨부원본파일명
		//byte[] fileData        = fileInfo.getAtchFileData();  		// 파일데이터
		
		// 필수항목 체크
		if( StringUtils.isEmpty(atchOrgcpFileNm) ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "첨부원본파일명 필수항목 누락" } );
		}
		/*
		if( fileData == null || fileData.length <= 0 ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "첨부파일데이터 필수항목 누락" } );
		}
		*/
	
		// 파일생성(실저장)
		//bResult = writeByteToFile(UI_MENU_FILE_PATH, atchOrgcpFileNm, fileData, null);
	
		if ( bResult ) {
	
			try {
				int transType = InfUtil.TRANS_FILE_EAI_ASYNC;
				String interfaceId = MENU_INFO_EAI_INTERFACE_ID;
				String localFileName = UI_MENU_FILE_PATH + FOLDER_SEPARATOR + atchOrgcpFileNm;
				String remoteFileName = WEB_MENU_FILE_PATH + FOLDER_SEPARATOR + atchOrgcpFileNm;
				
				String hdbTxnDate = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
	
				InfUtil.transFile(transType, interfaceId, localFileName, remoteFileName, hdbTxnDate);
			} catch (EisExecutionException e) {
				logger.error("EisExecutionException",e);
			} catch (NotSupportedEISException e) {
				logger.error("NotSupportedEISException",e);
			} catch (Exception e) {
				logger.error("Exception",e);
			}				
			
		} else {
			throw new ApplicationException("KIERE0014", null, new Object[]{"파일처리실패"});
		}
		
		return bResult;
	}

	/**
	 *  레포트출력정보파일 업로드 처리
	 * @param fileInfo 레포트출력정보파일
	 * @return boolean
	 * @throws ApplicationException
	 */
	public boolean putReportOutInfoFile(CMA005SVC09In fileInfo) throws ApplicationException {
		
		boolean bResult = false;        // 파일생성결과
		
		String atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();    	// 첨부원본파일명
		//byte[] fileData        = fileInfo.getAtchFileData();  		// 파일데이터
		
		// 필수항목 체크
		if( StringUtils.isEmpty(atchOrgcpFileNm) ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "첨부원본파일명 필수항목 누락" } );
		}
		
		/*
		if( fileData == null || fileData.length <= 0 ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "첨부파일데이터 필수항목 누락" } );
		}
		*/
	
		// 파일생성(실저장)
		//bResult = writeByteToFile(UI_REPORTOUT_FILE_PATH, atchOrgcpFileNm, fileData, null);
	
		if ( bResult ) {
	
			try {
				int transType = InfUtil.TRANS_FILE_EAI_ASYNC;
				String interfaceId = REPORTOUT_INFO_EAI_INTERFACE_ID;
				String localFileName = UI_REPORTOUT_FILE_PATH + FOLDER_SEPARATOR + atchOrgcpFileNm;
				String remoteFileName = WEB_REPORTOUT_FILE_PATH + FOLDER_SEPARATOR + atchOrgcpFileNm;
				String hdbTxnDate = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
	
				InfUtil.transFile(transType, interfaceId, localFileName, remoteFileName, hdbTxnDate);
			} catch (EisExecutionException e) {
				logger.error("EisExecutionException",e);
			} catch (NotSupportedEISException e) {
				logger.error("NotSupportedEISException",e);
			} catch (Exception e) {
				logger.error("Exception",e);
			}				
			
		} else {
			throw new ApplicationException("KIERE0014", null, new Object[]{"파일처리실패"});
		}
		
		return bResult;
	}

	/**
	 * 트랜스로그파일 업로드 처리
	 * @param fileInfo 파일정보
	 * @return boolean
	 * @throws ApplicationException
	 */
	public boolean putTransLogtFileInfo(CMA005SVC07In fileInfo) throws ApplicationException {
		
		boolean bResult = false;        // 파일생성결과
		
		String atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();    	// 첨부원본파일명
		byte[] fileData        = fileInfo.getAtchFileData();  		// 파일데이터
		
		// 필수항목 체크
		if( StringUtils.isEmpty(atchOrgcpFileNm) ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "첨부원본파일명 필수항목 누락" } );
		}
		
		if( fileData == null || fileData.length <= 0 ) {
			throw new ApplicationException( "KIERE0014", new Object[]{ "첨부파일데이터 필수항목 누락" } );
		}
	
		// 파일생성(실저장)
		bResult = writeByteToFile(UI_ONLINE_FILE_PATH, atchOrgcpFileNm, fileData, null);
		
		return bResult;
	}

	/**
	 * 파일삭제처리
	 * @param fileMgntNo     파일관리번호
	 * @param fileSeq        파일순번
	 * @param filePathNm     파일경로명
	 * @param atchSavFileNm  첨부저장파일명
	 * @return int 처리건수
	 * @throws ApplicationException
	 */
	public int deleteFileList(int fileDelListCnt, List<CMA005SVC01Sub1> fileDelList) throws ApplicationException {
		
		int iCnt = 0;
		//boolean bResult = false;
		
		// 필수입력값체크
		for( CMA005SVC01Sub1 fileDelInfo : fileDelList ){ 
			
			logger.debug( "fileMgntNo : {}, fileSeq : {} " , fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq() );
			logger.debug( "atchSavFileNm : {} " , fileDelInfo.getAtchSavFileNm() );
			
			if( StringUtils.isEmpty(fileDelInfo.getFileMgntNo()) ){
				throw new ApplicationException( "KIERE0005", new Object[]{ "파일관리번호 필수항목 누락" } );
			}
			
			if( fileDelInfo.getFileSeq() == null || fileDelInfo.getFileSeq() < 0 ){
				throw new ApplicationException( "KIERE0005", new Object[]{ "파일순번 필수항목 누락" } );
			}
			
			if( StringUtils.isEmpty(fileDelInfo.getFilePathNm()) ){
				throw new ApplicationException( "KIERE0005", new Object[]{ "파일경로명 필수항목 누락" } );
			}
			
			if( StringUtils.isEmpty(fileDelInfo.getAtchSavFileNm()) ){
				throw new ApplicationException( "KIERE0005", new Object[]{ "파일저장파일명 필수항목 누락" } );
			}
		}
		
		// 파일처리 및 데이터 처리
		for( CMA005SVC01Sub1 fileDelInfo : fileDelList ){ 

			logger.debug( "fileMgntNo : {}, fileSeq : {} " , fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq() );
			logger.debug( "filePathNm : {}, atchSavFileNm : {} " , fileDelInfo.getFilePathNm(), fileDelInfo.getAtchSavFileNm() );
			
			logger.debug( "DB 삭제컬럼 업데이트 처리" );
			logger.debug( "DB 삭제컬럼 업데이트 처리" );
			logger.debug( "DB 삭제컬럼 업데이트 처리" );
			
			// 파일삭제
			boolean bResult = false;
			bResult = delateFile(fileDelInfo.getFilePathNm(), fileDelInfo.getAtchSavFileNm());
			logger.debug( fileDelInfo.getFilePathNm() + ", " + fileDelInfo.getAtchSavFileNm() + " 파일삭제 성공여부 : " + bResult );
			
			//if ( bResult ) {
			String lastChgrId 	= FwUtil.getUserId();  //최종변경자ID
			String lastChgPgmId = FwUtil.getPgmId();   // 최종변경프로그램ID	
			String lastChgTrmNo = FwUtil.getTrmNo();   // 최종변경단말번호
			
			// 파일 데이터 삭제 처리
			iCnt += this.cma005dbio.updateOneTBCMCCD017(fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq(), lastChgrId, lastChgPgmId, lastChgTrmNo);
			//}
			
		}
		
		logger.debug( "fileDelListCnt : {} 파일처리건수 : {} " , fileDelListCnt, iCnt );

		return iCnt;
	}
	
	/**
	 * 파일삭제처리(타팀제공)
	 * @param fileMgntNo     파일관리번호
	 * @param fileSeq        파일순번
	 * @param filePathNm     파일경로명
	 * @param atchSavFileNm  첨부저장파일명
	 * @return int 처리건수
	 * @throws ApplicationException
	 */
	public int deleteFileListOther(int fileDelListCnt, List<FileDelInfo> fileDelList) throws ApplicationException {
		
		int iCnt = 0;
		boolean bResult = false;
		
		// 필수입력값체크
		for( FileDelInfo fileDelInfo : fileDelList ){ 
			
			logger.debug( "fileMgntNo : {}, fileSeq : {} " , fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq() );
			logger.debug( "atchSavFileNm : {} " , fileDelInfo.getAtchSavFileNm() );
			
			if( StringUtils.isEmpty(fileDelInfo.getFileMgntNo()) ){
				throw new ApplicationException( "KIERE0005", new Object[]{ "파일관리번호 필수항목 누락" } );
			}
			
			if( fileDelInfo.getFileSeq() == null || fileDelInfo.getFileSeq() < 0 ){
				throw new ApplicationException( "KIERE0005", new Object[]{ "파일순번 필수항목 누락" } );
			}
			
			if( StringUtils.isEmpty(fileDelInfo.getFilePathNm()) ){
				throw new ApplicationException( "KIERE0005", new Object[]{ "파일경로명 필수항목 누락" } );
			}
			
			if( StringUtils.isEmpty(fileDelInfo.getAtchSavFileNm()) ){
				throw new ApplicationException( "KIERE0005", new Object[]{ "파일저장파일명 필수항목 누락" } );
			}
		}
		
		// 파일처리 및 데이터 처리
		for( FileDelInfo fileDelInfo : fileDelList ){ 

			logger.debug( "fileMgntNo : {}, fileSeq : {} " , fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq() );
			logger.debug( "filePathNm : {}, atchSavFileNm : {} " , fileDelInfo.getFilePathNm(), fileDelInfo.getAtchSavFileNm() );
			
			// 파일삭제
			bResult = delateFile(fileDelInfo.getFilePathNm(), fileDelInfo.getAtchSavFileNm());
			
			logger.debug( fileDelInfo.getFilePathNm() + ", " + fileDelInfo.getAtchSavFileNm() + " 파일삭제 성공여부 : " + bResult );
			
			//if ( bResult ) {
			String lastChgrId 	= FwUtil.getUserId();  //최종변경자ID
			String lastChgPgmId = FwUtil.getPgmId();   // 최종변경프로그램ID	
			String lastChgTrmNo = FwUtil.getTrmNo();   // 최종변경단말번호
			
			// 파일 데이터 삭제 처리
			iCnt += this.cma005dbio.updateOneTBCMCCD017(fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq(), lastChgrId, lastChgPgmId, lastChgTrmNo);
			//}
			
		}
		
		logger.debug( "fileDelListCnt : {} 파일처리건수 : {} " , fileDelListCnt, iCnt );

		return iCnt;
	}
	
	/**
	 * 파일삭제처리(타팀제공)
	 * @param fileMgntNo     파일관리번호
	 * @return int 처리건수
	 * @throws ApplicationException
	 */
	public int deleteFileListOther(String fileMgntNo) throws ApplicationException {
		
		int iCnt = 0;
		boolean bResult = false;
		
		logger.debug( "fileMgntNo : {} " , fileMgntNo );
		
		// 1. 필수입력값체크
		if( StringUtils.isEmpty(fileMgntNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "파일관리번호" });
		}
		
		// 2. 파일목록조회
		List<CMA005SVC00Sub> fileDelList = this.cma005dbio.selectMultiTBCMCCD016(fileMgntNo, "Y");
		
		// 파일처리 및 데이터 처리
		for( CMA005SVC00Sub fileDelInfo : fileDelList ){
			logger.debug( "fileMgntNo : {}, fileSeq : {} " , fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq() );
			logger.debug( "filePathNm : {}, atchSavFileNm : {} " , fileDelInfo.getFilePathNm(), fileDelInfo.getAtchSavFileNm() );
			
			// 파일삭제
			bResult = delateFile(fileDelInfo.getFilePathNm(), fileDelInfo.getAtchSavFileNm());
			
			logger.debug( fileDelInfo.getFilePathNm() + ", " + fileDelInfo.getAtchSavFileNm() + " 파일삭제 성공여부 : " + bResult );
			
			//if ( bResult ) {
			String lastChgrId 	= FwUtil.getUserId();  //최종변경자ID
			String lastChgPgmId = FwUtil.getPgmId();   // 최종변경프로그램ID	
			String lastChgTrmNo = FwUtil.getTrmNo();   // 최종변경단말번호
			
			// 파일 데이터 삭제 처리
			iCnt += this.cma005dbio.updateOneTBCMCCD017(fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq(), lastChgrId, lastChgPgmId, lastChgTrmNo);
			//}
		}
		
		logger.debug( "파일처리건수 : {} ", iCnt );

		return iCnt;
	}
	
	/**
	 * 파일삭제처리(타팀제공)
	 * @param fileMgntNo     파일관리번호
	 * @param fileSeq        파일순번
	 * @return int 처리건수
	 * @throws ApplicationException
	 */
	public int deleteFileOther(String fileMgntNo, int fileSeq) throws ApplicationException {
		
		int iCnt = 0;
		boolean bResult = false;
		
		logger.debug( "fileMgntNo : {} " , fileMgntNo );
		
		// 1. 필수입력값체크
		if( StringUtils.isEmpty(fileMgntNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "파일관리번호" });
		}
		
		// 2. 파일목록조회
		List<CMA005SVC00Sub> fileDelList = this.cma005dbio.selectMultiTBCMCCD016(fileMgntNo, "Y");
		
		// 파일처리 및 데이터 처리
		for( CMA005SVC00Sub fileDelInfo : fileDelList ){
			if (fileSeq == fileDelInfo.getFileSeq()) {
	
				logger.debug( "fileMgntNo : {}, fileSeq : {} " , fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq() );
				logger.debug( "filePathNm : {}, atchSavFileNm : {} " , fileDelInfo.getFilePathNm(), fileDelInfo.getAtchSavFileNm() );
				
				// 파일삭제
				bResult = delateFile(fileDelInfo.getFilePathNm(), fileDelInfo.getAtchSavFileNm());
				
				logger.debug( fileDelInfo.getFilePathNm() + ", " + fileDelInfo.getAtchSavFileNm() + " 파일삭제 성공여부 : " + bResult );
				
				//if ( bResult ) {
				String lastChgrId 	= FwUtil.getUserId();  //최종변경자ID
				String lastChgPgmId = FwUtil.getPgmId();   // 최종변경프로그램ID	
				String lastChgTrmNo = FwUtil.getTrmNo();   // 최종변경단말번호
				
				// 파일 데이터 삭제 처리
				iCnt += this.cma005dbio.updateOneTBCMCCD017(fileDelInfo.getFileMgntNo(), fileDelInfo.getFileSeq(), lastChgrId, lastChgPgmId, lastChgTrmNo);
				//}
			}
		}
		
		logger.debug( "파일처리건수 : {} ", iCnt );

		return iCnt;
	}
	
	
	/**
	 * 파일조회(파일다운로드용)
	 * @param fileInfoInput 파일정보
	 * @return 파일
	 * @throws ApplicationException
	 */
	public CMA005SVC02Sub getFileInfo(CMA005SVC02In fileInfoInput) throws ApplicationException {
		
		CMA005SVC02Sub fileOutput = new CMA005SVC02Sub();
		
		byte[] atchFileCtnt;
		
		String filePathNm = "";
		String atchSavFileNm = "";
		String atchOrgcpFileNm = "";
		
		CMA005SVC02In fileInputResult = null;
		if ("DB".equals(fileInfoInput.getFileInqDcd())) {
			
			if( StringUtils.isEmpty(fileInfoInput.getFileMgntNo()) ){
				throw new ApplicationException( "APCME0008", new Object[]{ "파일관리번호" } );
			}
			
			if( fileInfoInput.getFileSeq() == null || fileInfoInput.getFileSeq() <= 0){
				throw new ApplicationException( "APCME0008", new Object[]{ "파일순번" } );
			}
			
			fileInputResult = this.cma005dbio.selectOneTBCMCCD016(fileInfoInput.getFileMgntNo(), fileInfoInput.getFileSeq());
			
			if(fileInputResult == null) {
				// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException("KIOKI0004", null);
			}
			
		}
		
		filePathNm = fileInputResult.getFilePathNm();
		atchSavFileNm = fileInputResult.getAtchSavFileNm();
		atchOrgcpFileNm = fileInputResult.getAtchOrgcpFileNm();
		
		if( StringUtils.isEmpty(filePathNm) ){
			throw new ApplicationException( "APCME0008", new Object[]{ "파일경로" } );
		}
		
		if( StringUtils.isEmpty(atchSavFileNm) ){
			throw new ApplicationException( "APCME0008", new Object[]{ "파일저장파일명" } );
		}
		
		if( StringUtils.isEmpty(atchOrgcpFileNm) ){
			throw new ApplicationException( "APCME0008", new Object[]{ "파일원본파일명" } );
		}
		
		atchFileCtnt = readByteFromFile ( filePathNm, atchSavFileNm );
		
		fileOutput.setAtchFileCtnt(atchFileCtnt);
		fileOutput.setAtchOrgcpFileNm(atchOrgcpFileNm);

		if(atchFileCtnt == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return fileOutput;
		
	}
	
	/**
	 * 전체파일조회(파일전체다운로드용)
	 * @param fileMgntNo 파일관리번호
	 * @return 파일
	 * @throws ApplicationException
	 */
	public List<CMA005SVC02Sub> getFileInfoListAll(String fileMgntNo) throws ApplicationException {
		
		List<CMA005SVC02Sub> fileInfoList = new ArrayList<CMA005SVC02Sub>();
		
		CMA005SVC02Sub fileCtntInfo;
		
		byte[] atchFileCtnt;
		
		logger.debug( "fileMgntNo : {}" , fileMgntNo );
		
		// 1. 필수값체크
		if( StringUtils.isEmpty(fileMgntNo) ) {
			throw new ApplicationException( "KIERE0005", new Object[]{ "파일관리번호 필수항목 누락" } );
		}
		
		// 2. 파일목록조회
		List<CMA005SVC00Sub> fileList = this.cma005dbio.selectMultiTBCMCCD016(fileMgntNo, "Y");
		
		// 3. 파일내용가져오기
		for( CMA005SVC00Sub fileInfo : fileList ){ 
			
			fileCtntInfo = new CMA005SVC02Sub();
			
			atchFileCtnt = readByteFromFile ( fileInfo.getFilePathNm(), fileInfo.getAtchSavFileNm() );
			
			if ( atchFileCtnt != null ) {
			
				fileCtntInfo.setAtchFileCtnt(atchFileCtnt);
				fileCtntInfo.setAtchOrgcpFileNm(fileInfo.getAtchOrgcpFileNm());
				
				fileInfoList.add(fileCtntInfo);
			}
		}
		
		return fileInfoList;
	}
	
	/**
	 * 다건파일조회(파일다운로드용)
	 * @param fileMgntNo 파일관리번호
	 * @return 파일
	 * @throws ApplicationException
	 */
	public List<CMA005SVC00Sub> getFileInfoListMulti(List<CMA005SVC05Sub> fileListInput) throws ApplicationException {
		
		List<CMA005SVC00Sub> fileInfoList = new ArrayList<CMA005SVC00Sub>();
		
		CMA005SVC02In fileCtntInfoDB;
		
		CMA005SVC00Sub fileCtntInfo;
		
		for( CMA005SVC05Sub fileInfo : fileListInput ) {  
		
			if( StringUtils.isEmpty(fileInfo.getFileMgntNo()) ){
				throw new ApplicationException( "APCME0008", new Object[]{ "파일관리번호" } );
			}
			
			if( fileInfo.getFileSeq() == null || fileInfo.getFileSeq() <= 0){
				throw new ApplicationException( "APCME0008", new Object[]{ "파일순번" } );
			}
		}
		
		for( CMA005SVC05Sub fileInfo : fileListInput ) {
		
			fileCtntInfoDB = this.cma005dbio.selectOneTBCMCCD016(fileInfo.getFileMgntNo(), fileInfo.getFileSeq());
			if (fileCtntInfoDB != null) {
				fileCtntInfo = new CMA005SVC00Sub();
				
				fileCtntInfo.setFileMgntNo(fileCtntInfoDB.getFileMgntNo()); // 파일관리번호
				fileCtntInfo.setFileSeq(fileCtntInfoDB.getFileSeq()); // 파일순번
				fileCtntInfo.setFilePathNm(fileCtntInfoDB.getFilePathNm()); // 파일경로명
				fileCtntInfo.setAtchOrgcpFileNm(fileCtntInfoDB.getAtchOrgcpFileNm()); // 첨부원본파일명
				fileCtntInfo.setAtchSavFileNm(fileCtntInfoDB.getAtchSavFileNm()); // 첨부저장파일명
				
				fileInfoList.add(fileCtntInfo);
			}
		}
		
		return fileInfoList;
	}

	private  int getXPlatformCsvDataStartPosition(String fileName, byte[] fileData, String headerRemoveYn) {
		if (fileName == null) {
			return 0;
		}
		
		String fileNameLowerCase = fileName.toLowerCase(Locale.ENGLISH);
		
		/*
		 * 확장자가 .CSV 파일명이 아니면 파일의 내용은 정상 
		 */
		if(fileNameLowerCase.length() > 4) {
			String fileExt = fileNameLowerCase.substring(fileNameLowerCase.length()-4, fileNameLowerCase.length());
			if(".csv".equals(fileExt) || ".CSV".equals(fileExt)) {
				return 0;
			}
		} else {
			return 0;
		}
		
		/* 
		 * CSV파일이라도 
		 * XPlatform에서 파일 업로드시에는 CSV:utf-8로 시작하므로 그 format인지를 확인함
		 */
		byte data[] = "CSV:utf-8".getBytes();
		if(fileData.length <= data.length) {
			return 0;
		}
		for(int idx = 0; idx < data.length; idx++) {
			if(data[idx] != fileData[idx]) {
				return 0;
			}
		}
		
		/*
		 * XPlatform에서 올린 파일이면 3라인을 삭제함.
		 */
		int line = 0;
		int removeLineCount = 3;
		if("Y".equals(headerRemoveYn)) {
			removeLineCount++;
		}
		for(int idx = 0; idx < fileData.length; idx++) {
			if(fileData[idx] == '\n') {
				line++;
			}
			if(line == removeLineCount) {
				return idx + 1;
			}
		}
		return 0;
	}
	/**
	 * 파일을 생성한다.
	 * @param fileName 파일이름
	 * @param fileData 파일데이터
	 * @return boolean 처리결과
	 */
	@SuppressWarnings("finally")
	private boolean writeByteToFile(String filePath, String fileName, byte[] fileData, String xlsHeaderRemoveYn)  throws ApplicationException {
		
		boolean bResult = false;
		boolean bDirExists = false;
		
		File file = null;
		
		FileOutputStream fileOs = null;
		
		BufferedOutputStream buffOs =  null;
		
		String uploadedFilePath = "";
		
		try {
			
			// 업로드 할 dir 를 생성한다. 
            File dirPath = new File(filePath);
            
            logger.debug( "dirPath : {}" , dirPath );
            
            bDirExists = dirPath.exists();
            
            if ( !bDirExists ) {
            	//bDirExists = dirPath.mkdirs();
            	logger.debug("디렉토리 없음");
            	throw new ApplicationException( "KIERE0005", null, new Object[]{ "[IOException] 파일생성 중 에러발생 : 디렉토리 없음" } );
            } 
            
            logger.debug( "bDirExists : {} " , bDirExists);
            
            if (bDirExists) {
			
				int len = fileData.length;
				
				logger.debug( "fileName : {} data len : {} " , fileName, len );
	
	            // file upload to assigned path
	            uploadedFilePath = dirPath + FOLDER_SEPARATOR + fileName;
	            
	            file = new File(uploadedFilePath);
	            
	            logger.debug( "file : {} " , file );
	            
				fileOs = new FileOutputStream(file);
				
//				logger.debug( "fileOs : {} " , fileOs );
				
				buffOs = new BufferedOutputStream(fileOs);
				
//				logger.debug( "buffOs : {} " , buffOs );
				/*
				 * XPlatform의 GRID를 통해서 Upload된 CSV format의 경우 불필요한 Header부를 
				 * 삭제하여야 하기 때문에 데이터 위치를 계산해야 함.
				 */
				int startPos = getXPlatformCsvDataStartPosition(fileName, fileData, xlsHeaderRemoveYn);
				buffOs.write(fileData, startPos, len - startPos);
				
				bResult = true;
            }
				
		} catch(IOException e) {
			
			bResult = false;
			logger.error("File Write Error: ", e);
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[IOException] 파일생성 중 에러발생" }, e );
			
		} catch(Exception e) {	
			
			bResult = false;
			logger.error("File Write Error: ", e);
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[Exception] 파일생성 중 에러발생" }, e );
			
		} finally {
			
			try { 
				if(buffOs != null) buffOs.close();
			} catch(IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
			try {
				if(fileOs != null) fileOs.close();
			} catch(IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
		}
		
		return bResult;
		
	}
	
	/**
	 * 파일을 읽어 Binary Data로 변환한다.
	 * @param filePath 파일경로명
	 * @param fileName 파일이름
	 * @return  byte[] 파일내용
	 * @throws ApplicationException
	 */
	@SuppressWarnings("finally")
	private byte[] readByteFromFile(String filePathInput, String fileName)  throws ApplicationException  {
		String filePath = filePathInput;
		
		logger.debug( "uploadedFilePath : {} fileName : {} " , filePath, fileName );
		
		byte[] resultByteArray = null;
		
		File file = null; 
		
		File dirPath = new File(filePath);
		if ( !dirPath.exists() ) {
			//logger.error("File Path Not Found!!");
			throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "File Path Not Found!!" } );
		}
		
		ByteArrayOutputStream baos = null;
		
		FileInputStream fis = null;
		
		try {
			
			filePath = dirPath + FOLDER_SEPARATOR + fileName;
            
            file = new File(filePath);
			
			baos = new ByteArrayOutputStream();
			
			fis = new FileInputStream(file);
			
			int readCnt = 0;
			
			byte[] buf = new byte[1024];
			
			while((readCnt = fis.read(buf)) != -1) {
				baos.write(buf, 0, readCnt);
			}
			
			baos.flush();
			
			resultByteArray = baos.toByteArray();
			
			baos.close();
			fis.close();
			
		} catch(FileNotFoundException e) {
			//APCME0000 : 처리중 오류가 발생했습니다.
		    throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[FileNotFoundException] 파일 Binary Data로 변환중 에러발생" }, e );
			
		} catch(IOException e) {
			//APCME0000 : 처리중 오류가 발생했습니다.
			throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 에러발생" }, e );
		
		} catch(Exception e) {
			//APCME0000 : 처리중 오류가 발생했습니다.
			throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 에러발생" }, e );
		}  finally {
			
			try { 
				if(baos != null) baos.close();
			} catch(IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
			try { 
				if(fis != null) fis.close();
			} catch(IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
		}
		
		return resultByteArray;
	}
	
	

	/**
	 * 파일을 삭제한다.
	 * @param fileName 파일이름
	 * @return boolean 처리결과
	 */
	private int delateFile(String filePath, List<String> filePrcsList) 
	{
		int iResult = 0;
		boolean bResult = false;
		
		File file = null;
		
		String uploadedFilePath = "";
		
		// 업로드 할 dir 를 생성한다. 
        File dirPath = new File(filePath);
        
        if ( dirPath.exists() ) {
        	
        	for( String fileName : filePrcsList ){ 
        		
	            // file upload to assigned path
	            uploadedFilePath = dirPath + FOLDER_SEPARATOR + fileName;
	            
	            logger.debug( "uploadedFilePath : {} " , uploadedFilePath );
	            
	            file = new File(uploadedFilePath);
	            
	            bResult = file.delete();
	            
	            if (bResult) iResult++;
        	}
        }
			
		return iResult;
		
	}
	
	/**
	 * 파일을 삭제한다.
	 * @param fileName 파일이름
	 * @return boolean 처리결과
	 */
	private boolean delateFile(String filePath, String fileName) 
	{
		boolean bResult = false;
		
		File file = null;
		
		String uploadedFilePath = "";
		
		// 업로드 할 dir 를 생성한다. 
        File dirPath = new File(filePath);
        
        logger.debug( "dirPath : {} fileName : {} " , dirPath, fileName );
        
        if ( dirPath.exists() ) {

            // file upload to assigned path
            uploadedFilePath = dirPath + FOLDER_SEPARATOR + fileName;
            
            logger.debug( "uploadedFilePath : {} " , uploadedFilePath );
            
            file = new File(uploadedFilePath);
            
            bResult = file.delete();
        }
			
		return bResult;
		
	}
	
	/**
	 * 입력한 포맷에 맞게 현재 시간을 구한다.
	 * @param Strinf 날짜 포맷
	 * @return String 계산된 날짜
	 */	
	private String getDate(String format) {
		try {
		  java.util.Date now = new java.util.Date();
		  SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.KOREA);
		  return sdf.format(now);
		  
		} catch(Exception ex) {
		  return "00000000";
		}
	}
	
	/**
	 * 입력한 파일이 UTF-8이라면 MS949로 인코딩을 변경한다
	 * @param String 인코딩할 파일경로
	 */	
	private void changeFileEncodingUTF8ToMS949(String inputFilePath) {
		
		logger.debug("파일 인코딩 변경시작(UTF-8 => MS949) : " + inputFilePath);
		
		// 임시파일지정 : 작성후 삭제한다
		String outputFilePath = inputFilePath + "_tmp";
		
		File inputFile = new File(inputFilePath);
		File outputFile = new File(outputFilePath);
		
		FileInputStream fileInputStream = null;
		FileOutputStream fileOutputStream = null;
		
		OutputStreamWriter outputWriter = null;
		InputStreamReader inputReader = null;
		
		try {
			fileInputStream = new FileInputStream(inputFile);
			
			// 캐릭터셋이 UTF-8이 아니면 오류로 감지하여 catch블럭으로 이동하게 한다
			CharsetDecoder charsetDecoder = StandardCharsets.UTF_8.newDecoder();
			charsetDecoder.onMalformedInput(CodingErrorAction.REPORT);
			charsetDecoder.onUnmappableCharacter(CodingErrorAction.REPORT);
			
			inputReader = new InputStreamReader(fileInputStream, charsetDecoder);
			
			// 임시파일의 인코딩은 MS949
			fileOutputStream = new FileOutputStream(outputFile);
			outputWriter = new OutputStreamWriter(fileOutputStream, "MS949");
			
			// 파일의 모든 내용을 임시파일로 작성한다
			int read = inputReader.read();
			while (read != -1) {
				read = inputReader.read();
				outputWriter.write(read);
			}
			
			// 임시파일이 모두 정상적으로 생성되면 기존 파일을 지우고 임시파일을 기존파일이름으로 변경한다
			inputReader.close();
			
			outputWriter.flush();
			outputWriter.close();
			
			fileOutputStream.close();
			
			inputFile.delete();
			outputFile.renameTo(inputFile);
			
		} catch (Exception e) {
			// UTF-8이 아니라면 IOException이 발생하며 이경우 생성하려던 임시파일을 지운다
			try {
				if (outputWriter != null) {
					outputWriter.close();
				}
				if (fileOutputStream != null) {
					fileOutputStream.close();
				}
			} catch (IOException e1) {
				logger.debug("[" + e.toString() + "] 파일 인코딩 변경중(UTF-8 => MS949) 스킵");
			}
			outputFile.delete();
			
			logger.debug("[" + e.toString() + "] 파일 인코딩 변경중(UTF-8 => MS949) 스킵");
		} finally {
			try {
				// 파일 리더,스트림 종료
				if (fileInputStream != null) {
					fileInputStream.close();
				}
			} catch (IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
			try {
				// 파일 리더,스트림 종료
				if (fileOutputStream != null) {
					fileOutputStream.close();
				}
			} catch (IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
			try {
				// 파일 리더,스트림 종료
				if (inputReader != null) {
					inputReader.close();
				}
			} catch (IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
			try {
				// 파일 리더,스트림 종료
				if (outputWriter != null) {
					outputWriter.close();
				}
			} catch (IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
			try {
				// 파일 리더,스트림 종료
				if (fileOutputStream != null) {
					fileOutputStream.close();
				}
			} catch (IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
		}
		
		logger.debug("파일 인코딩 변경끝(UTF-8 => MS949) : " + inputFilePath);
	}
}

