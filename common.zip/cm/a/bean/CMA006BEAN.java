package cigna.cm.a.bean;

import java.util.List;

import cigna.cm.a.dbio.CMA006DBIO;
import cigna.cm.a.io.CMA006SVC00In;
import cigna.cm.a.io.CMA006SVC01Sub;
import cigna.cm.a.io.CMA006SVC02Sub0;
import cigna.cm.a.io.CMA006SVC02Sub1;
import cigna.cm.a.io.CMA006SVC03Out;
import cigna.cm.a.io.CMA006SVC04Sub;
import cigna.cm.a.io.TBCMCCD018Io;
import cigna.cm.a.io.TBCMCCD019Io;
import cigna.zz.FwUtil;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file         cigna.cm.a.bean.CMA006BEAN.java
 * @filetype     java source file
 * @brief        엑셀보안결재관리 BEAN
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박경화                     2012. 12. 10.       신규 작성
 * 0.6           박경화                     2012. 12. 10.       개발 완료
 * 0.9           박경화                     2012. 12. 11.       Class 테스트
 * 1.0           박경화                     2012. 12. 11.       단위 테스트 
 */
@KlafBean
public class CMA006BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 엑셀보안결재관리 DBIO
	 */	
	@Autowired
	private CMA006DBIO cma006dbio; 
	
	/**
	 * 채번관련 BEAN
	 */	
	@Autowired
	private CMA004BEAN cma004bean;
	
	
	/** 파일관리 채번구분코드 */
	private static final String XLS_SECU_SANC_MGNT_DCD = "AP";
	
	/** 엑셀보안결재상태코드 결재요청 */
	private static final String XLS_SECU_SANC_STCD_00 = "00";
	
	/** 엑셀보안결재상태코드 결재승인 */
	private static final String XLS_SECU_SANC_STCD_10 = "10";
	
	/** 엑셀보안결재상태코드 결재반려 */
	private static final String XLS_SECU_SANC_STCD_20 = "20";
	
	/** 엑셀보안결재상태코드 결재요청취소 */
	private static final String XLS_SECU_SANC_STCD_30 = "30";
	
	
	
	/**
	 * 엑셀보안결재정보 등록
	 * @param input 엑셀보안결재정보
	 * @return 엑셀보안결재관리번호
	 * @throws ApplicationException
	 */
	public String insertSancReqInfo(CMA006SVC00In input) throws ApplicationException {
		
		String bzCd = input.getBzCd();  // 업무코드
		String xlsSecuSancMgntNo = "";  // 엑셀보안결재관리번호
		
		int iResult1 = 0 ;
		int iResult2 = 0 ;
		
		
		if( StringUtils.isEmpty(bzCd) ){
			throw new ApplicationException( "KIERE0014", null, new Object[]{ "업무코드 필수값 누락" } );
		}
		
		if( input.getXlsFileCtnt() == null || input.getXlsFileCtnt().length <= 0 ){
			throw new ApplicationException( "KIERE0014", null, new Object[]{ "엑셀파일 누락" } );
		}
		
		// 엑셀보안결재관리번호 채번
		xlsSecuSancMgntNo = this.cma004bean.getNewComnMknoNo(XLS_SECU_SANC_MGNT_DCD +  bzCd, 12);
		
		logger.debug( "엑셀보안결재관리번호 채번 xlsSecuSancMgntNo : {} " , xlsSecuSancMgntNo );
		
		if( !StringUtils.isEmpty(xlsSecuSancMgntNo) ){
		
			TBCMCCD018Io tbcmccd018io = new TBCMCCD018Io();
			
			tbcmccd018io.setXlsSecuSancMgntNo(xlsSecuSancMgntNo);      // 엑셀보안결재관리번호
			tbcmccd018io.setBzCd(bzCd);                                // 업무코드
			tbcmccd018io.setScrnId(input.getScrnId());                 // 화면ID
			tbcmccd018io.setScrnNm(input.getScrnNm());                 // 화면명
			tbcmccd018io.setSancReqEno(input.getSancReqEno());         // 결재요청사원번호
			tbcmccd018io.setSancEno(input.getSancEno());               // 결재사원번호
			tbcmccd018io.setAprvReqRsnCtnt(input.getAprvReqRsnCtnt()); // 승인요청사유내용
			tbcmccd018io.setScrnSecuGcd(input.getScrnSecuGcd());       // 화면보안등급코드
			tbcmccd018io.setDataMaskYn(input.getDataMaskYn());         // 데이터마스킹여부
			tbcmccd018io.setXlsFileNm(input.getXlsFileNm());           // 엑셀파일명
			tbcmccd018io.setDwldPrdStrtDt(input.getDwldPrdStrtDt());   // 다운로드기간시작일자
			tbcmccd018io.setDwldPrdEndDt(input.getDwldPrdEndDt());     // 다운로드기간종료일자
			tbcmccd018io.setLastChgrId(FwUtil.getUserId());            // 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd018io.setLastChgPgmId(FwUtil.getPgmId());           // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd018io.setLastChgTrmNo(FwUtil.getTrmNo());           // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iResult1 = this.cma006dbio.insertOneTBCMCCD018(tbcmccd018io);
			
			logger.debug( "iResult1 : {} " , iResult1 );
			
			if ( iResult1 == 1) {
			
				TBCMCCD019Io tbcmccd019io = new TBCMCCD019Io();
				
				tbcmccd019io.setXlsSecuSancMgntNo(xlsSecuSancMgntNo);      // 엑셀보안결재관리번호
				tbcmccd019io.setXlsFileCtnt(input.getXlsFileCtnt());       // 엑셀파일내용
				tbcmccd019io.setLastChgrId(FwUtil.getUserId());            // 최종변경자ID(LAST_CHGR_ID) 설정
				tbcmccd019io.setLastChgPgmId(FwUtil.getPgmId());           // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
				tbcmccd019io.setLastChgTrmNo(FwUtil.getTrmNo());           // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
				
				iResult2 = this.cma006dbio.insertOneTBCMCCD019(tbcmccd019io);
				
				logger.debug( "iResult2 : {} " , iResult2 );
			
			}
		} else {
			throw new ApplicationException( "KIERE0014", null, new Object[]{ "엑셀보안결재관리번호 채번오류" } );
		}
		
		return xlsSecuSancMgntNo;
	}
	
	
	/**
	 * 결재요청취소
	 * @param List<CMA006SVC01Sub> sancInfoList 결재요청취소정보
	 * @throws ApplicationException
	 */
	public void setSancReqCncl(List<CMA006SVC01Sub> sancInfoList) throws ApplicationException {
		
		logger.debug( "결재요청취소정보 : {} " , sancInfoList );
		
		if ( sancInfoList == null || sancInfoList.size() <= 0 ) {
			throw new ApplicationException( "KIERE0011", null, new Object[]{ "결재요청취소정보" , "공백"} );
		}
		
		for (CMA006SVC01Sub sancInfo : sancInfoList) {
			
		
			if( StringUtils.isEmpty(sancInfo.getXlsSecuSancMgntNo()) ){
				throw new ApplicationException( "KIERE0011", new Object[]{ "결재요청취소정보의 엑셀보안결재관리번호" ,"공백" } );
			}
			
			if( !XLS_SECU_SANC_STCD_00.equals(sancInfo.getXlsSecuSancStcd()) ){
				throw new ApplicationException( "KIERE0011", null, new Object[]{ "결재요청취소정보의 결재상태" , "결재요청상태가 아님" });
			}
			
			TBCMCCD018Io tbcmccd018io = new TBCMCCD018Io();
			
			tbcmccd018io.setXlsSecuSancMgntNo(sancInfo.getXlsSecuSancMgntNo()); // 엑셀보안결재관리번호
			tbcmccd018io.setXlsSecuSancStcd(XLS_SECU_SANC_STCD_30);       		// 엑셀보안결재상태코드
			tbcmccd018io.setLastChgrId(FwUtil.getUserId());            			// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd018io.setLastChgPgmId(FwUtil.getPgmId());           			// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd018io.setLastChgTrmNo(FwUtil.getTrmNo());           			// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			int iResult = this.cma006dbio.updateOneTBCMCCD018(tbcmccd018io);
			
			logger.debug( "iResult : {} " , iResult );
			
			if ( iResult == 1) {
				int iResult2 = this.cma006dbio.deleteOneTBCMCCD019(sancInfo.getXlsSecuSancMgntNo());
				
				logger.debug( "엑셀파일삭제 iResult2 : {} " , iResult2 );
			}

		}
		
	}
	
	/**
	 * 결재내역 승인
	 * @param List<CMA006SVC01Sub> sancInfoList 결재승인정보
	 * @throws ApplicationException
	 */
	public void setSancAprv(List<CMA006SVC01Sub> sancInfoList) throws ApplicationException {
		
		logger.debug( "결재승인정보 : {} " , sancInfoList );
		
		if ( sancInfoList == null || sancInfoList.size() <= 0 ) {
			throw new ApplicationException( "KIERE0013", null, new Object[]{ "결재승인정보" , "공백"} );
		}
		
		for (CMA006SVC01Sub sancInfo : sancInfoList) {
			
			if( StringUtils.isEmpty(sancInfo.getXlsSecuSancMgntNo()) ){
				throw new ApplicationException( "KIERE0013", new Object[]{ "결재승인정보의 엑셀보안결재관리번호" ,"공백" } );
			}
			
			if( !XLS_SECU_SANC_STCD_00.equals(sancInfo.getXlsSecuSancStcd()) ){
				throw new ApplicationException( "KIERE0013", null, new Object[]{ "결재승인정보의 결재상태" , "결재요청상태가 아님" });
			}
			
			TBCMCCD018Io tbcmccd018io = new TBCMCCD018Io();
			
			tbcmccd018io.setXlsSecuSancMgntNo(sancInfo.getXlsSecuSancMgntNo());	// 엑셀보안결재관리번호
			tbcmccd018io.setXlsSecuSancStcd(XLS_SECU_SANC_STCD_10);       		// 엑셀보안결재상태코드
			tbcmccd018io.setSancTndwRsnCtnt(sancInfo.getSancTndwRsnCtnt());		// 결재반려사유내용
			tbcmccd018io.setDwldPrdStrtDt(sancInfo.getDwldPrdStrtDt());			// 다운로드기간시작일자
			tbcmccd018io.setDwldPrdEndDt(sancInfo.getDwldPrdEndDt());			// 다운로드기간종료일자
			tbcmccd018io.setLastChgrId(FwUtil.getUserId());            			// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd018io.setLastChgPgmId(FwUtil.getPgmId());           			// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd018io.setLastChgTrmNo(FwUtil.getTrmNo());           			// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			int iResult = this.cma006dbio.updateOneTBCMCCD018(tbcmccd018io);
			
			logger.debug( "iResult : {} " , iResult );
			
		}
		
	}
	
	/**
	 * 결재내역 반려
	 * @param List<CMA006SVC01Sub> sancInfoList 결재반려정보
	 * @throws ApplicationException
	 */
	public void setSancTndw(List<CMA006SVC01Sub> sancInfoList) throws ApplicationException {
		
		logger.debug( "결재반려정보 : {} " , sancInfoList );
		
		if ( sancInfoList == null || sancInfoList.size() <= 0 ) {
			throw new ApplicationException( "KIERE0013", null, new Object[]{ "결재반려정보" , "공백"} );
		}
		
		for (CMA006SVC01Sub sancInfo : sancInfoList) {
			
			if( StringUtils.isEmpty(sancInfo.getXlsSecuSancMgntNo()) ){
				throw new ApplicationException( "KIERE0013", new Object[]{ "결재반려정보의 엑셀보안결재관리번호" ,"공백" } );
			}
			
			if( !XLS_SECU_SANC_STCD_00.equals(sancInfo.getXlsSecuSancStcd()) ){
				throw new ApplicationException( "KIERE0013", null, new Object[]{ "결재반려정보의 결재상태" , "결재요청상태가 아님" });
			}
			
			TBCMCCD018Io tbcmccd018io = new TBCMCCD018Io();
			
			tbcmccd018io.setXlsSecuSancMgntNo(sancInfo.getXlsSecuSancMgntNo());	// 엑셀보안결재관리번호
			tbcmccd018io.setXlsSecuSancStcd(XLS_SECU_SANC_STCD_20);       		// 엑셀보안결재상태코드
			tbcmccd018io.setSancTndwRsnCtnt(sancInfo.getSancTndwRsnCtnt());		// 결재반려사유내용
			tbcmccd018io.setDwldPrdStrtDt(sancInfo.getDwldPrdStrtDt());			// 다운로드기간시작일자
			tbcmccd018io.setDwldPrdEndDt(sancInfo.getDwldPrdEndDt());			// 다운로드기간종료일자
			tbcmccd018io.setLastChgrId(FwUtil.getUserId());            			// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd018io.setLastChgPgmId(FwUtil.getPgmId());           			// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd018io.setLastChgTrmNo(FwUtil.getTrmNo());           			// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			int iResult = this.cma006dbio.updateOneTBCMCCD018(tbcmccd018io);
			
			logger.debug( "iResult : {} " , iResult );
			
			if ( iResult == 1) {
				int iResult2 = this.cma006dbio.deleteOneTBCMCCD019(sancInfo.getXlsSecuSancMgntNo());
				
				logger.debug( "엑셀파일삭제 iResult2 : {} " , iResult2 );
			}
			
		}
		
	}
	
	/**
	 * 결재목록조회
	 * @param input 결재내역 조건정보
	 * @return 결재목록
	 * @throws ApplicationException
	 */
	public List<CMA006SVC02Sub1> getSancList(CMA006SVC02Sub0 input) throws ApplicationException {
		
		int iPageNum = input.getPageNum();
		int iPageCount = input.getPageCount();
		
		if(input.getPageNum() <= 0) {
			throw new ApplicationException("KIERE0016", null, new String[]{"공통"});
		}
		if(input.getPageCount() <= 0) {
			throw new ApplicationException("KIERE0017", null, new String[]{"공통"});
		}
		
		List<CMA006SVC02Sub1> sancList = this.cma006dbio.selectMultiTBCMCCD018(FwUtil.getUserId(), iPageNum, iPageCount, input);
		
		return sancList;
		
	}
	
	/**
	 * 엑셀파일정보 조회
	 * @param xlsSecuSancMgntNo 엑셀보안결재관리번호
	 * @return 엑셀파일정보
	 * @throws ApplicationException
	 */
	public CMA006SVC04Sub getXlsFile(String xlsSecuSancMgntNo) throws ApplicationException {
		
		if( StringUtils.isEmpty(xlsSecuSancMgntNo) ){
			throw new ApplicationException( "APCME0008", new Object[]{ "엑셀보안결재관리번호" } );
		}
		
		CMA006SVC04Sub xlsFileInfo = this.cma006dbio.selectOneTBCMCCD019(xlsSecuSancMgntNo);
		
		return xlsFileInfo;
		
	}
	
	/**
	 * 결재자정보 (소속조직 팀장)
	 * @return
	 * @throws ApplicationException
	 */
	public CMA006SVC03Out getSancInfo() throws ApplicationException {
		
		String orgNo = FwUtil.getDeptCd(); // 로그인user.소속조직번호
		
		logger.debug( "orgNo : {} " , orgNo );
		
		if( StringUtils.isEmpty(orgNo) ){
			throw new ApplicationException( "APCME0008", new Object[]{ "소속조직번호" } );
		}
		
		CMA006SVC03Out sancInfo = this.cma006dbio.selectOneTBSLEMP001(orgNo);
		
		logger.debug( "sancInfo : {} " , sancInfo );
		
		return sancInfo;
		
	}
		
	
}

