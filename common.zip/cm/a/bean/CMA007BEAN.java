package cigna.cm.a.bean;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import cigna.cm.a.dbio.CMA007DBIO;
import cigna.cm.a.io.CMA007SVC00In;
import cigna.cm.a.io.CMA007SVC03Sub;
import cigna.cm.a.io.CMA007SVC04In;
import cigna.cm.a.io.CMA007SVC04Sub;
import cigna.cm.a.io.SelectMultiTBCMCCD024Out;
import cigna.cm.a.io.TBCMCCD024Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.bean.CMA007BEAN.java
 * @filetype     java source file
 * @brief        푸시 서비스 관리
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박경화                     2013. 4. 2.       신규 작성
 *
 */
@KlafBean
public class CMA007BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 푸시서비스관리
	 */
	@Autowired
	private CMA007DBIO cma007dbio; 
	
	//private static final int PUSH_SERVICE_PORT = 30000;
	
	/** FOLDER SEPARATOR */
	private static final String FOLDER_SEPARATOR= "/";
	
	/**
	 * 푸시관련 기초정보 저장
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public void setEnoIpAddr () {
		
		int iResult = 0;
		
		try {
			String eno          = FwUtil.getUserId();
			String ipAddr       = FwUtil.getTrmNo();
			String lastChgrId 	= FwUtil.getUserId();  //최종변경자ID
			String lastChgPgmId = FwUtil.getPgmId();   // 최종변경프로그램ID	
			String lastChgTrmNo = FwUtil.getTrmNo();   // 최종변경단말번호
			
			// 1.필수값체크
			if( StringUtils.isEmpty(eno) || eno.length() > 10 ) {	
				logger.error("[입력값체크] 사원번호 공백 또는 자리수 초과 오류!");
			} else if ( StringUtils.isEmpty(ipAddr) || ipAddr.length() > 40 ) {
				logger.error("[입력값체크] 사용자IP 공백 또는 자리수 초과 오류!");
			} else {
				// 2.저장
				iResult = cma007dbio.mergeOneTBCMCCD023(eno, ipAddr, lastChgrId, lastChgPgmId, lastChgTrmNo);
			}
		} catch(Exception e) {
			logger.error("[Exception] 푸시서비스 접속정보 저장 오류 ", e);
		} finally {
			if (iResult != 1) {
				logger.error("푸시서비스 접속정보 저장 오류!");
			}
		}

	}
	
	/**
	 * 푸시서비스처리결과 조회
	 * @return 푸시서비스처리결과 목록
	 */
	public List<SelectMultiTBCMCCD024Out> getPushServiceInfo (CMA007SVC00In input)  throws ApplicationException {
		
		List<SelectMultiTBCMCCD024Out> pushList = null;
		
		String scrnNo = input.getScrnNo();
		String eno = input.getEno();
		String ipAddr = input.getIpAddr();
		String trmsStarDt = input.getTrmsStarDt();
		String trmsEndDt = input.getTrmsEndDt();
		int iPageNum = input.getPageNum();
		int iPageCount = input.getPageCount();		
		
		logger.debug("eno={}", FwUtil.getUserId());
		
		pushList = cma007dbio.selectMultiTBCMCCD024(scrnNo, eno, ipAddr, trmsStarDt, trmsEndDt, iPageNum, iPageCount);	
		
		return pushList;

	}
	
	
	/**
	 * 푸시서비스처리결과 조회
	 * @return 푸시서비스처리결과 목록
	 */
	public SelectMultiTBCMCCD024Out getOnBatchRstInfo (String trmsDt, String eno, String ipAddr, String scrnNo)  throws ApplicationException {
		
		trmsDt = StringUtils.nvl(trmsDt);
		eno    = StringUtils.nvl(eno);
		ipAddr = StringUtils.nvl(ipAddr);
		scrnNo = StringUtils.nvl(scrnNo);	
		
		logger.debug("eno={}", FwUtil.getUserId());
		
		SelectMultiTBCMCCD024Out pushInfo = cma007dbio.selectOneTBCMCCD024a(trmsDt, eno, ipAddr, scrnNo);	
		
		return pushInfo;

	}
	
	/**
	 * 다운로드 받을 파일 정보를 Table에 등록한다.
	 * 
	 * @param eno  사원번호
	 * @param scrnNo 화면ID
	 * @param title  제목
	 * @param content 내용
	 * @param atchFilePathNm 첨부파일 PATH
	 * @param atchSavFileNm  첨부파일명
	 * @throws ApplicationException
	 */
	public void setFileDownloadInfo(String eno, String scrnNo, String title, String content, String atchFilePathNm, String atchSavFileNm) throws ApplicationException {
		if (StringUtils.isEmpty(eno)) {
			throw new ApplicationException("APCME0009", new Object[]{"사원번호는"});
		} 
		if (StringUtils.isEmpty(scrnNo)) {
			throw new ApplicationException("APCME0009", new Object[]{"화면번호는"});
		} 
		if (StringUtils.isEmpty(title)) {
			throw new ApplicationException("APCME0009", new Object[]{"제목은"});
		} 
		if (StringUtils.isEmpty(atchFilePathNm)) {
			throw new ApplicationException("APCME0009", new Object[]{"첨부파일의 Path는"});
		} 
		if (StringUtils.isEmpty(atchSavFileNm)) {
			throw new ApplicationException("APCME0009", new Object[]{"첨부파일명은"});
		} 

		// 2.IP 가져오기
		String ipAddr = cma007dbio.selectOneTBCMCCD023(eno) ;

		TBCMCCD024Io tbcmccd024io = new TBCMCCD024Io();
		
		tbcmccd024io.setEno(eno);
		tbcmccd024io.setIpAddr(ipAddr);
		tbcmccd024io.setTgmTrmsTypVl(InfUtil.PUSH_TYPE_FILE);
		tbcmccd024io.setTgmTitlCtnt(title);
		tbcmccd024io.setTgmCtnt(content);
		tbcmccd024io.setScrnNo(scrnNo);
		tbcmccd024io.setAtchFilePathNm(atchFilePathNm);
		tbcmccd024io.setAtchSavFileNm(atchSavFileNm);
		tbcmccd024io.setTrmsSuccYn("Y");
		tbcmccd024io.setErrCtnt("파일다운로드용");
		tbcmccd024io.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		tbcmccd024io.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		tbcmccd024io.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		cma007dbio.insertOneTBCMCCD024(tbcmccd024io);
				
	}
	

	/**
	 * 배치결과저장
	 * @param eno	     사원번호
	 * @param sendType	전송유형
	 * @param title		전송제목
	 * @param content	전송내용
	 * @param trmsSuccYn 전송성공여부
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public void setPushServiceInfoTCP (String sendType, String eno, String scrnNo, String title, String content, String atchFilePathNm, String atchSavFileNm, String trmsSuccYn) {
		
		logger.debug("eno={}, scrnNo={}", eno, scrnNo);
		logger.debug("title={}, content={}", title, content);
		logger.debug("filePath={}, fileName={}", atchFilePathNm, atchSavFileNm);
		logger.debug("trmsSuccYn={}", trmsSuccYn);

		if(StringUtils.isEmpty(trmsSuccYn)) {
			trmsSuccYn = "N";
		}
		String errCtnt    = "";		

		// 2.IP 가져오기 - Ondemand Batch에서 호출한 경우
		String ipAddr = FwUtil.getBatchParameter("onlineIpAddr");
		
		setPushServiceInfo (sendType, eno, ipAddr, scrnNo, title, content, atchFilePathNm, atchSavFileNm, trmsSuccYn, errCtnt);

	}
	
	/**
	 * 푸시정보 전송(TCP) 및 저장
	 * @param eno	     사원번호
	 * @param sendType	전송유형
	 * @param title		전송제목
	 * @param content	전송내용
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public void setPushServiceInfoTCP (String sendType, String eno, String scrnNo, String title, String content, String atchFilePathNm, String atchSavFileNm) {
		
		logger.debug("eno={}, scrnNo={}", eno, scrnNo);
		logger.debug("title={}, content={}", title, content);
		logger.debug("filePath={}, fileName={}", atchFilePathNm, atchSavFileNm);
		

		String trmsSuccYn = "N";
		String errCtnt    = "";
		
		// 1.필수값 체크
		if( StringUtils.isEmpty(eno) ) {
			logger.error("[입력값체크] 사원번호 공백!");
			errCtnt = "[입력값체크] 사원번호 공백!";
		} 
		if( StringUtils.isEmpty(sendType) || sendType.length() > 4 ) {	
			logger.error("[입력값체크] 전송유형 공백 또는 자리수 초과 오류!");
			errCtnt = "[입력값체크] 전송유형 공백 또는 자리수 초과 오류!";
		}
		if( StringUtils.isEmpty(scrnNo) ) {	
			logger.error("[입력값체크] 화면번호 공백 오류!");
			errCtnt = "[입력값체크] 화면번호 공백 오류!";
		}
		if( StringUtils.isEmpty(title) ) {	
			logger.error("[입력값체크] 제목 공백 오류!");
			errCtnt = "[입력값체크] 제목 공백 오류!";
		}
		if( StringUtils.isEmpty(content) ) {	
			logger.error("[입력값체크] 내용 공백 오류!");
			errCtnt = "[입력값체크] 제목 공백 오류!";
		}
		
		// 2.IP 가져오기 - Ondemand Batch에서 호출한 경우
		String ipAddr = FwUtil.getBatchParameter("onlineIpAddr");
		
		if(StringUtils.isEmpty(ipAddr)) {
			// ipAddr가 설정되지 않은 경우에는 계정의 로그인한 곳의 IP
			ipAddr = cma007dbio.selectOneTBCMCCD023(eno) ;
		}

		setPushServiceInfo (sendType, eno, ipAddr, scrnNo, title, content, atchFilePathNm, atchSavFileNm, trmsSuccYn, errCtnt);

	}
	


	/**
	 * 푸시정보 전송(TCP) 및 저장
	 * @param eno	     사원번호
	 * @param sendType	전송유형
	 * @param title		전송제목
	 * @param content	전송내용
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public void setPushServiceInfo(String sendType, String eno, String ipAddr, String scrnNo, String title, 
			String content, String atchFilePathNm, String atchSavFileNm, String trmsSuccYn, String errCtnt) {

		TBCMCCD024Io tbcmccd024io = new TBCMCCD024Io();
		
		tbcmccd024io.setEno(eno);
		tbcmccd024io.setIpAddr(ipAddr);
		tbcmccd024io.setTgmTrmsTypVl(sendType);
		tbcmccd024io.setTgmTitlCtnt(title);
		tbcmccd024io.setTgmCtnt(content);
		tbcmccd024io.setScrnNo(scrnNo);
		tbcmccd024io.setAtchFilePathNm(atchFilePathNm);
		tbcmccd024io.setAtchSavFileNm(atchSavFileNm);
		tbcmccd024io.setTrmsSuccYn(trmsSuccYn); //전문의 성공여부
		tbcmccd024io.setErrCtnt(errCtnt);
		tbcmccd024io.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		tbcmccd024io.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		tbcmccd024io.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		cma007dbio.insertOneTBCMCCD024(tbcmccd024io);

	}
	/**
	 * On Demand Batch 서비스 진행상태 조회
	 * @param glblId 글로벌ID
	 * @return CMA007SVC03Sub 상태정보
	 * @throws ApplicationException
	 */	
	public CMA007SVC03Sub getBatStautsInfo(String glblId) throws ApplicationException {
				
		if( StringUtils.isEmpty(glblId) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(글로벌ID)" });
		}

		CMA007SVC03Sub batStatusInfo = null;
		batStatusInfo = cma007dbio.selectOneFBATCHJOBEXECUTION(glblId);
		
		return batStatusInfo;
	}
	
	/**
	 * 첨부파일 다운로드
	 * @param fileInfoInput 파일정보
	 * @return 파일
	 * @throws ApplicationException
	 */
	public CMA007SVC04Sub getAtchFileDownInfo(CMA007SVC04In fileInfoInput) throws ApplicationException {
		
		CMA007SVC04Sub atchFileDownInfo = new CMA007SVC04Sub();
		
		byte[] atchFileCtnt;
		
		String filePathNm = "";
		String atchSavFileNm = "";
		
		if( fileInfoInput.getPssvcTrmsNo() == null ){
			throw new ApplicationException( "APCME0008", new Object[]{ "푸시서비스전송번호" } );
		}
		
		if( StringUtils.isEmpty(fileInfoInput.getAtchSavFileNm()) ){
			throw new ApplicationException( "APCME0008", new Object[]{ "첨부파일명" } );
		}
		atchSavFileNm = fileInfoInput.getAtchSavFileNm();
		
		fileInfoInput = this.cma007dbio.selectOneTBCMCCD024(fileInfoInput.getPssvcTrmsNo());
		
		if(fileInfoInput == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		filePathNm = fileInfoInput.getAtchFilePathNm();
//		atchSavFileNm = fileInfoInput.getAtchSavFileNm();
		
		if( StringUtils.isEmpty(filePathNm) ){
			throw new ApplicationException( "APCME0008", new Object[]{ "파일경로" } );
		}
		
		//atchFileCtnt = readByteFromFile ( filePathNm, atchSavFileNm );
		//atchFileDownInfo.setAtchFileCtnt(atchFileCtnt);
		atchFileDownInfo.setAtchFilePathNm(filePathNm);
		atchFileDownInfo.setAtchSavFileNm(atchSavFileNm);

//		if(atchFileCtnt == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
//			throw new ApplicationException("KIOKI0004", null);
//		}
		
		return atchFileDownInfo;
		
	}	
	
	/**
	 * 파일을 읽어 Binary Data로 변환한다.
	 * @param filePath 파일경로명
	 * @param fileName 파일이름
	 * @return  byte[] 파일내용
	 * @throws ApplicationException
	 */
	@SuppressWarnings("finally")
	private byte[] readByteFromFile(String filePathInput, String fileName)  throws ApplicationException  {
		String filePath = filePathInput;
		
		logger.debug( "uploadedFilePath : {} fileName : {} " , filePath, fileName );
		
		byte[] resultByteArray = null;
		
		File file = null; 
		
		File dirPath = new File(filePath);
		if ( !dirPath.exists() ) {
			//logger.error("File Path Not Found!!");
			throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "File Path Not Found!!" } );
		}
		
		ByteArrayOutputStream baos = null;
		
		FileInputStream fis = null;
		
		try {
			
			filePath = dirPath + FOLDER_SEPARATOR + fileName;
            
            file = new File(filePath);
			
			baos = new ByteArrayOutputStream();
			
			fis = new FileInputStream(file);
			
			int readCnt = 0;
			
			byte[] buf = new byte[1024];
			
			while((readCnt = fis.read(buf)) != -1) {
				baos.write(buf, 0, readCnt);
			}
			
			baos.flush();
			
			resultByteArray = baos.toByteArray();
			
			baos.close();
			fis.close();
		} catch(FileNotFoundException e) {
			//APCME0000 : 처리중 오류가 발생했습니다.
		    throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[FileNotFoundException] 파일 Binary Data로 변환중 에러발생" }, e );
			
		} catch(IOException e) {
			//APCME0000 : 처리중 오류가 발생했습니다.
			throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 에러발생" }, e );
		
		} catch(Exception e) {
			//APCME0000 : 처리중 오류가 발생했습니다.
			throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 에러발생" }, e );
			
		}  finally {
			
			try { 
				if(baos != null) baos.close();
			} catch(IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
			
			try { 
				if(fis != null) fis.close();
			} catch(IOException e) {
				logger.debug("[IOException] 파일스트림 닫는중 오류");
			}
		}
		return resultByteArray;
	}	
	
}

