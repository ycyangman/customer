package cigna.cm.a.bean;

import java.util.ArrayList;
import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import cigna.cm.a.dbio.CMA008DBIO;
import cigna.cm.a.io.CMA008SVC00In;
import cigna.cm.a.io.CMA008SVC00Sub;
import cigna.cm.a.io.CMA008SVC01Sub;
import cigna.cm.a.io.TBCMCCD020Io;
import cigna.zz.FwUtil;


/**
 * @file         cigna.cm.a.bean.CMA008BEAN.java
 * @filetype     java source file
 * @brief        URL관리 BEAN
 * @author       양윤철
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           양윤철                     2016. 2. 6.       신규 작성
 */
@KlafBean
public class CMA008BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA008DBIO cma008dbio; //URL관리 DBIO
	
	@Autowired
	private CMA004BEAN cma004bean;  //채번
	
	/** 파일관리 채번구분코드 */
	private static final String URL_MGNT_NO_MKNO_DCD = "UR";
	
	/**
	 * URL 등록 삭제 처리
	 * @param input URL정보목록
	 * @return 처리건수
	 * @throws ApplicationException
	 */
	public String setUrlList(CMA008SVC00In input)  throws ApplicationException {
		
		int prcsCnt = 0;
		
		int listCnt = input.getDataListCnt();
		List<CMA008SVC00Sub> urlPrcsList = input.getDataList();
		
		TBCMCCD020Io tbcmccd020io = null;
		
		String prcsDcd   = input.getPrcsDcd();
		String urlMgntNo = input.getUrlMgntNo();
		String bzCd      = input.getBzCd();
		
		logger.debug( "prcsDcd : {} " , prcsDcd );
		
		if( urlPrcsList == null || urlPrcsList.size() == 0 || listCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ listCnt }, new Object[]{ "URL목록" , "변경된 정보 없음" });
		}
		
		List<CMA008SVC00Sub> urlList = new ArrayList<CMA008SVC00Sub>();
		// 신규 등록시
		if ( StringUtils.isEmpty(urlMgntNo) ) {
		
			// 파일관리번호 채번_대문자
			urlMgntNo = this.cma004bean.getNewComnMknoNo(URL_MGNT_NO_MKNO_DCD +  bzCd.toUpperCase(), 12);
			
			logger.debug( "신규등록채번 urlMgntNo : {} " , urlMgntNo );
		} else {
			if ("I".equals(prcsDcd)) {
				urlList = this.getUrlList(urlMgntNo);
				this.cma008dbio.deleteMultiTBCMCCD020(urlMgntNo); //전체삭제 후 등록
			}
		}
		
		if (!CollectionUtils.isEmpty(urlList)) {
			for (CMA008SVC00Sub cma008svc00Sub : urlList) {
				boolean insertFlag = true;
				for (CMA008SVC00Sub urlInfo : urlPrcsList) {
					if (urlInfo.getSeq() == cma008svc00Sub.getSeq()) {
						insertFlag = false;
					}
				}
				
				if (insertFlag) {
					tbcmccd020io = new TBCMCCD020Io();
					
					tbcmccd020io.setUrlMgntNo(cma008svc00Sub.getUrlMgntNo());
					tbcmccd020io.setBzCd(cma008svc00Sub.getBzCd());
					tbcmccd020io.setUrlNm(cma008svc00Sub.getUrlNm());
					tbcmccd020io.setUrlCtnt(cma008svc00Sub.getUrlCtnt());
					tbcmccd020io.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
					tbcmccd020io.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
					tbcmccd020io.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
					
					// URL 데이터 등록 처리
					prcsCnt += this.cma008dbio.insertOneTBCMCCD020(tbcmccd020io);
				}
			}
		}
		
		for (CMA008SVC00Sub urlInfo : urlPrcsList) {
			//String prcsDcd = urlInfo.getPrcsDcd();
			
			if(!"1".equals(urlInfo.getChkYn())) {
				continue;
			}
			
			if(StringUtils.isEmpty(urlInfo.getUrlMgntNo())) {
				urlInfo.setUrlMgntNo(urlMgntNo);
			}
			if(StringUtils.isEmpty(urlInfo.getBzCd())) {
				urlInfo.setBzCd(bzCd);
			}
						
			// URL등록
			if ("I".equals(prcsDcd)) {
				if( StringUtils.isEmpty(urlInfo.getUrlMgntNo()) ){
					throw new ApplicationException( "KIERE0005", new Object[]{ "URL관리번호 필수항목 누락" } );
				}
				/*
				if( StringUtils.isEmpty(urlInfo.getBzCd()) ){
					throw new ApplicationException( "KIERE0005", new Object[]{ "업무코드 필수항목 누락" } );
				}
				*/
				
				if( StringUtils.isEmpty(urlInfo.getUrlNm()) ){
					throw new ApplicationException( "KIERE0005", new Object[]{ "URL명 필수항목 누락" } );
				}
				
				if( urlInfo.getUrlCtnt() == null || urlInfo.getUrlCtnt().length() <= 0 ){
					throw new ApplicationException( "KIERE0005", new Object[]{ "URL내용 필수항목 누락" } );
				}
				
				tbcmccd020io = new TBCMCCD020Io();
				
				tbcmccd020io.setUrlMgntNo(urlInfo.getUrlMgntNo());
				tbcmccd020io.setBzCd(urlInfo.getBzCd());
				tbcmccd020io.setUrlNm(urlInfo.getUrlNm());
				tbcmccd020io.setUrlCtnt(urlInfo.getUrlCtnt());
				tbcmccd020io.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
				tbcmccd020io.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
				tbcmccd020io.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
				
				// URL 데이터 등록 처리
				prcsCnt += this.cma008dbio.insertOneTBCMCCD020(tbcmccd020io);
				
				
			// URL삭제	
			} else if ("D".equals(prcsDcd)) {
				
				if( StringUtils.isEmpty(urlInfo.getUrlMgntNo()) ){
					throw new ApplicationException( "KIERE0005", new Object[]{ "URL관리번호 필수항목 누락" } );
				}
				
				if( urlInfo.getSeq() == null || urlInfo.getSeq() < 0 ){
					throw new ApplicationException( "KIERE0005", new Object[]{ "URL순번 필수항목 누락" } );
				}
				
				String lastChgrId 	= FwUtil.getUserId();  //최종변경자ID
				String lastChgPgmId = FwUtil.getPgmId();   // 최종변경프로그램ID	
				String lastChgTrmNo = FwUtil.getTrmNo();   // 최종변경단말번호
				
				// URL 데이터 삭제 처리
				prcsCnt += this.cma008dbio.updateOneTBCMCCD020(urlInfo.getUrlMgntNo(), urlInfo.getSeq(), lastChgrId, lastChgPgmId, lastChgTrmNo);
				
			} 
		}
		
		logger.debug( "prcsCnt : {} " , prcsCnt );
		
		return urlMgntNo;
	}
	
	/**
	 * URL관리 조회
	 * @param urlMgntNo URL관리번호
	 * @param Seq       URL순번
	 * @return CMA008SVC01Sub URL정보
	 * @throws ApplicationException
	 */
	public CMA008SVC01Sub getUrlInfo(String urlMgntNo, int seq) throws ApplicationException {
		
		logger.debug( "urlMgntNo : {} seq : {}" , urlMgntNo, seq  );
		
		// 1. 필수입력값체크
		if( StringUtils.isEmpty(urlMgntNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "URL관리번호 필수항목 누락" });
		}
		
		if( seq <= 0 ){
			throw new ApplicationException( "KIERE0005", new Object[]{ "순번 필수항목 누락" } );
		}
		
		// 2. URL정보조회
		CMA008SVC01Sub urlInfo = this.cma008dbio.selectOneTBCMCCD020(urlMgntNo, seq);
		
		return urlInfo;
	}
	
	/**
	 * URL관리목록조회
	 * @param urlMgntNo URL관리번호
	 * @return List<CMA008SVC02Sub> URL관리목록
	 * @throws ApplicationException
	 */
	public List<CMA008SVC00Sub> getUrlList(String urlMgntNo) throws ApplicationException {
		
		logger.debug( "urlMgntNo : {} " , urlMgntNo );
		
		// 1. 필수입력값체크
		if( StringUtils.isEmpty(urlMgntNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "URL관리번호" });
		}
		
		// 2. URL목록조회
		List<CMA008SVC00Sub> urlList = this.cma008dbio.selectMultiTBCMCCD020(urlMgntNo);
		if (CollectionUtils.isEmpty(urlList)) {
			urlList = new ArrayList<CMA008SVC00Sub>();
		}
		
		return urlList;
	}
	
}

