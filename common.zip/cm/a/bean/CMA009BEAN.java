package cigna.cm.a.bean;

import java.util.List;

import cigna.cm.a.dbio.CMA009DBIO;
import cigna.cm.a.io.CMA009SVC00In;
import cigna.cm.a.io.CMA009SVC01In;
import cigna.cm.a.io.CMA009SVC02In;
import cigna.cm.a.io.CMA009SVC05In;
import cigna.cm.a.io.CMA009SVC06In;
import cigna.cm.a.io.TBCMCCD029Io;
import cigna.cm.a.io.TBCMCCD030Io;
import cigna.cm.a.io.TBCMCCD031Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.bean.CMA009BEAN.java
 * @filetype     java source file
 * @brief        대외계 관련 처리/대외계 파일 재처리/대외계 GUID Mapping 
 * @author       이미순
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이미순                 2013. 6. 28.       신규 작성
 *
 */
@KlafBean
public class CMA009BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 대외계파일송수신 관리
	 */
	@Autowired
	private CMA009DBIO cma009dbio;

	/**
	 * 대외계 파일 송수신 로그 조회
	 * @return 대외계 파일 송수신 로그 목록
	 */
	public List<TBCMCCD029Io> getFepFileLogList (CMA009SVC00In input)  throws ApplicationException {

		List<TBCMCCD029Io> fepFileLogList = null;
		
		String trrvStrtDt = input.getTrrvStrtDt();
		String trrvEndDt = input.getTrrvEndDt();
		String ifId = input.getIfId();
		String trrvStrtEno = input.getTrrvStrtEno();
		String fepFileTrmsStcd = input.getFepFileTrmsStcd();
		int iPageNum = input.getPageNum();
		int iPageCount = input.getPageCount();
		
		logger.debug("ifId={}", ifId);
		
		fepFileLogList = cma009dbio.selectMultiTBCMCCD029a(trrvStrtDt, trrvEndDt, ifId, trrvStrtEno, fepFileTrmsStcd, iPageNum, iPageCount);	
		
		return fepFileLogList;

	}
	
	/**
	 * 대외계인터페이스배치매핑 목록 조회
	 * @param ifId 인터페이스ID
	 * @return List<TBCMCCD031Io> 대외계인터페이스배치매핑 목록
	 * @throws ApplicationException
	 */
	public List<TBCMCCD031Io> getFepIfBatMappList(CMA009SVC01In input)	throws ApplicationException {

		List<TBCMCCD031Io> fepIfBatMappList = null;
		
		String ifId = input.getIfId();
		
		logger.debug("ifId={}", ifId);
		
		fepIfBatMappList = cma009dbio.selectMultiTBCMCCD031a(ifId);	
		
		return fepIfBatMappList;
	}
	
	/**
	 * 대외계인터페이스배치매핑 저장
	 * @param in CMA009SVC01In -> List<TBCMCCD031Io> 대외계인터페이스배치매핑 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	public int modifyFepIfBatMappList (CMA009SVC01In input) throws ApplicationException {
		
		int iCnt = 0;
		int iFepIfBatMappListCnt = input.getFepIfBatMappListCnt();
		List<TBCMCCD031Io> fepIfBatMappList = input.getFepIfBatMappList();
						
		//1. 필수입력값체크
		if( fepIfBatMappList == null || fepIfBatMappList.size() == 0 || iFepIfBatMappListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iFepIfBatMappListCnt }, new Object[]{ "대외계인터페이스배치매핑" , "변경된 내용 없음" });
		}	
		
		//2. 대외계인터페이스배치매핑 저장
		for( TBCMCCD031Io ifId : fepIfBatMappList ){ 
			
			// Table에 Insert / Update할 경우에 반드시 설정해야 할 Audit Column들을 설정.
			ifId.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
			ifId.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			ifId.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iCnt += this.cma009dbio.mergeOneTBCMCCD031(ifId); 
		}
		
		return iCnt;

	}	
	
	/**
	 * 대외계인터페이스배치매핑 삭제
	 * @param in CMA009SVC01In -> List<TBCMCCD031Io> 대외계인터페이스배치매핑 목록
	 * @return int 삭제건수
	 * @throws ApplicationException
	 */
	public int deleteFepIfBatMappList (CMA009SVC01In input) throws ApplicationException {
		
		int iCnt = 0;
		int iFepIfBatMappListCnt = input.getFepIfBatMappListCnt();
		List<TBCMCCD031Io> fepIfBatMappList = input.getFepIfBatMappList();
		
		//1. 필수입력값체크
		if( fepIfBatMappList == null || fepIfBatMappList.size() == 0 || iFepIfBatMappListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iFepIfBatMappListCnt }, new Object[]{ "대외계인터페이스배치매핑" , "삭제 할 대상없음" });
		}
		
		//2. 대외계인터페이스배치매핑 삭제
		for( TBCMCCD031Io ifId : fepIfBatMappList ){ 
			
			iCnt += this.cma009dbio.deleteOneTBCMCCD031(ifId.getIfId()); 
		}
		
		return iCnt;

	}		
	
	/**
	 * 대외계파일송수신로그 등록
	 * @param input 대외계파일송수신로그 정보
	 * @return 
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW)	
	public void insertFepFileLogInfo(TBCMCCD029Io fepFileLogInfo) throws ApplicationException {
		
		String baseDt = "";
		
		if( StringUtils.isEmpty(fepFileLogInfo.getGlblId()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(글로벌ID)" });
		}
		if( StringUtils.isEmpty(fepFileLogInfo.getIfTrmsKcd()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(인터페이스전송종류코드)" });
		}		
		if( StringUtils.isEmpty(fepFileLogInfo.getIfTrrvDcd()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(인터페이스송수신구분코드)" });
		}
		if( StringUtils.isEmpty(fepFileLogInfo.getIfId()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(인터페이스ID)" });
		}
		if( StringUtils.isEmpty(fepFileLogInfo.getLoclFileNm()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(로컬파일명)" });
		}		
		if( StringUtils.isEmpty(fepFileLogInfo.getRmotFileNm()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(리모트파일명)" });
		}		
		if( StringUtils.isEmpty(fepFileLogInfo.getFepFileTrmsStcd()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(대외계파일전송상태코드)" });
		}
		if( StringUtils.isEmpty(fepFileLogInfo.getBaseDt()) ) {
			baseDt = "00000000";
		}else{
			baseDt = fepFileLogInfo.getBaseDt();
		}
		
		fepFileLogInfo.setBaseDt(baseDt);// 기준일자값 설정 변경 213.08.28
		fepFileLogInfo.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		fepFileLogInfo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		fepFileLogInfo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		if(StringUtils.isEmpty(FwUtil.getUserId())) {
			fepFileLogInfo.setLastChgrId("FEP"); // 최종변경자ID(LAST_CHGR_ID) 설정
		}
		if(StringUtils.isEmpty(FwUtil.getPgmId())) {
			fepFileLogInfo.setLastChgPgmId("FEP"); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		}

		if(StringUtils.isEmpty(FwUtil.getTrmNo())) {
			fepFileLogInfo.setLastChgPgmId("FEP"); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		}
		
		this.cma009dbio.mergeOneTBCMCCD029(fepFileLogInfo);

	}
	
	/**
	 * 대외계글로벌ID매핑 등록
	 * @param input 대외계글로벌ID매핑 정보
	 * @return 
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW)
	public void insertFepGlblIdMappInfo(TBCMCCD030Io fepGlblIdMappInfo) throws ApplicationException {

		if( StringUtils.isEmpty(fepGlblIdMappInfo.getGlblId()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(글로벌ID)" });
		}			
		if( StringUtils.isEmpty(fepGlblIdMappInfo.getTrmsGlblId()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(전송글로벌ID)" });
		}			
		
		fepGlblIdMappInfo.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		fepGlblIdMappInfo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		fepGlblIdMappInfo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		this.cma009dbio.insertOneTBCMCCD030(fepGlblIdMappInfo);
	}
	
	/**
	 * 대외계파일송수신로그 수정
	 * @param input 대외계파일송수신로그 정보
	 * @return glblId 수정건수
	 * @throws ApplicationException	 * 
	 */
	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW)	
	public int updateFepFileLogInfo(TBCMCCD029Io fepFileLogInfo) throws ApplicationException {

		if( StringUtils.isEmpty(fepFileLogInfo.getGlblId()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(글로벌ID)" });
		}
		if( StringUtils.isEmpty(fepFileLogInfo.getFepFileTrmsStcd()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(대외계파일전송상태코드)" });
		}			
		
		fepFileLogInfo.setTrrvEndEno(FwUtil.getUserId()); // 송수신종료사원번호(TRRV_END_ENO) 설정
		fepFileLogInfo.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		fepFileLogInfo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		fepFileLogInfo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		int iCnt = this.cma009dbio.updateOneTBCMCCD029(fepFileLogInfo);
		
		return iCnt;
	}
	
	/**
	 * 대외계파일송수신 재전송
	 * @param input 대외계파일송수신로그 정보
	 * @return 
	 * @throws ApplicationException	 * 
	 */	
	public void putFepFileLogInfo(CMA009SVC02In input) throws ApplicationException {
		
		TBCMCCD029Io fepFileLogList = input.getFepFileLogList().get(0);
		
		if( fepFileLogList == null ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "대외계재전송 정보 누락" });
		}		
		
		Integer ifTrmsKcd = Integer.parseInt(fepFileLogList.getIfTrmsKcd());
		String ifId = fepFileLogList.getIfId();
		String loclFileNm = fepFileLogList.getLoclFileNm();
		String rmotFileNm = fepFileLogList.getRmotFileNm();
		String shllAllPathNm = fepFileLogList.getShllAllPathNm();
		String shllParmVl = fepFileLogList.getShllParmVl();
		String baseDt = fepFileLogList.getBaseDt();
		Integer fileTms = fepFileLogList.getFileTms();
		String batPgmId = "BCMBF00B";
	
		
		if( ifTrmsKcd==0 ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(인터페이스전송종류코드)" });
		}		
		if( StringUtils.isEmpty(ifId) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(인터페이스ID)" });
		}		
		if( StringUtils.isEmpty(loclFileNm) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(로컬파일명)" });
		}		
		if( StringUtils.isEmpty(rmotFileNm) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(리모트파일명)" });
		}
		
		/*
		try {
			InfUtil.transFile(ifTrmsKcd, ifId, loclFileNm, rmotFileNm, shllAllPathNm, shllParmVl, baseDt, fileTms);
		} catch (EisExecutionException e) {
			logger.error("EisExecutionException",e);
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException",e);
		} catch (Exception e) {
			logger.error("Exception",e);
		}*/
		
		try {
			String[] parameters = new String[] {"interfaceId=" + ifId, "localFile=" + loclFileNm, "remoteFile=" + rmotFileNm, "shellName=" + shllAllPathNm, "shellParams=" + shllParmVl, "transType=TRANS_FILE_FEP_ASYNC", "hdbTxnDate=" + baseDt, "fileSeq=" + fileTms};

			logger.debug( "batBatPgmId : {}, parameters : {} " , batPgmId, parameters );

			InfUtil.startBatch(batPgmId, parameters);

		} catch(Exception e) {
		    logger.error("대외계 재전송 오류: ", e);
		} 

	}
	
	
	/**
	 * 대외계파일수신
	 * @param input 대외계에서 넘겨받을 데이터 정보
	 * @return 
	 * @throws ApplicationException	 * 
	 */	
	public void putFepFileRece(CMA009SVC05In input) throws ApplicationException {
		
		String glblId = FwUtil.getGlobalId();	//글로벌ID
		if(StringUtils.isEmpty(glblId)) {
			glblId = FwUtil.generateGlobaId();
		}
		
		String ifTrmsKcd = "22";	//인터페이스전송종류코드 22.Async FEP
		String ifTrrvDcd = input.getReqtype();	//인터페이스송수신구분코드
		String ifId = input.getIfid();	//인터페이스ID
		String loclFileNm = input.getFileNm();	//로컬파일명
		String rmotFileNm = input.getFileNm();	//리모트파일명
		String baseDt = input.getTranDt();	//기준일자
		String tranTime = input.getTranTime();
		String resultCd = input.getResultCd();
		
		if( StringUtils.isEmpty(glblId)) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(글로벌ID)" });			
		}
		if( StringUtils.isEmpty(ifTrmsKcd)) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "인터페이스전송종류코드 값 오류" });
		}
		if( !"R".equals(ifTrrvDcd) && !"S".equals(ifTrrvDcd)) {	// R 수신 , S: 송신
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "인터페이스송수신구분코드 값 오류" });
		}
		if( StringUtils.isEmpty(ifId) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(인터페이스ID)" });
		}		
		if( StringUtils.isEmpty(loclFileNm) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(로컬파일명)" });
		}		
		if( StringUtils.isEmpty(rmotFileNm) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(리모트파일명)" });
		}
		
		TBCMCCD029Io fepFileLogInfo = new TBCMCCD029Io();
		fepFileLogInfo.setGlblId(glblId);
		fepFileLogInfo.setIfTrmsKcd(ifTrmsKcd);
		fepFileLogInfo.setIfTrrvDcd(ifTrrvDcd);
		fepFileLogInfo.setIfId(ifId);
		fepFileLogInfo.setLoclFileNm(loclFileNm);
		fepFileLogInfo.setRmotFileNm(rmotFileNm);
		fepFileLogInfo.setBaseDt(baseDt);
		
		try {
			if("ISFEP0001".equals(resultCd)){
				fepFileLogInfo.setFepFileTrmsStcd("20"); // 대외계파일전송상태코드 20.전송완료
			}
			else {
				fepFileLogInfo.setFepFileTrmsStcd("30"); // 대외계파일전송상태코드 30.오류
			}
			
			this.insertFepFileLogInfo(fepFileLogInfo);
			
			TBCMCCD031Io fepIfBatMappInfo = new TBCMCCD031Io();
			
			//-------------------대외계인터페이스배치매핑----------------------------------------
			fepIfBatMappInfo = cma009dbio.selectOneTBCMCCD031a(ifId);
			//--------------------------------------------------------------------------
			
			if(fepIfBatMappInfo != null){

				String runJbsId = fepIfBatMappInfo.getRunJbsId();
				String parm1Vl = fepIfBatMappInfo.getParm1Vl();
				String parm2Vl = fepIfBatMappInfo.getParm2Vl();
				String parm3Vl = fepIfBatMappInfo.getParm3Vl();
				String parm4Vl = fepIfBatMappInfo.getParm4Vl();
				String parm5Vl = fepIfBatMappInfo.getParm5Vl();
				
				try {
					String[] parameters = new String[] {parm1Vl, parm2Vl, parm3Vl, parm4Vl, parm5Vl, "currentTime="+ DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE), "loclFileNm=" + loclFileNm, "rmotFileNm="+rmotFileNm};

					logger.debug( "batBatPgmId : {}, parameters : {} " , runJbsId, parameters );

					InfUtil.startBatch(runJbsId, parameters);

				} catch(Exception e) {
				    logger.error("대외계 배치실행 오류: ", e);
				} 
			}
			
		} catch (Exception e) {
			logger.error("대외계송수신로그 Insert 에러: ", e);
		}

	}	
	
	/**
	 * 대외계파일송신
	 * @param 
	 * @return 
	 * @throws ApplicationException	 * 
	 */	
	public void putFepFileSnd(CMA009SVC06In input) throws ApplicationException {
		
		String glblId = input.getGlblId();	//글로벌ID
		String ifTrrvDcd = input.getIfTrrvDcd();	//인터페이스송수신구분코드
		String fepFileTrmsStcd = input.getFepFileTrmsStcd();	//대외계파일전송상태코드

		if( StringUtils.isEmpty(glblId)) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(글로벌ID)" });			
		}
		if( !"S".equals(ifTrrvDcd) ) {	// S 송신
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "인터페이스송수신구분코드 값 오류" });
		}
		if( StringUtils.isEmpty(fepFileTrmsStcd)) {	//대외계파일전송상태코드 값이(20=전송완료, 30=오류) 가 아닐경우
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "인터페이스전송상태코드 값 오류" });
		}
	
		TBCMCCD029Io fepFileLogInfo = new TBCMCCD029Io();
		fepFileLogInfo.setGlblId(glblId);
		fepFileLogInfo.setFepFileTrmsStcd(fepFileTrmsStcd);
		
		logger.debug( "glblId : {}, fepFileTrmsStcd : {} " , glblId, fepFileTrmsStcd );
		
		this.updateFepFileLogInfo(fepFileLogInfo);
	}
	
}

