package cigna.cm.a.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.dbio.CMA201DBIO;
import cigna.cm.a.io.CMA010SVC00In;
import cigna.cm.a.io.CMA010SVC00Out;
import cigna.cm.a.io.COM_E_DMIOS000000001In;
import cigna.cm.a.io.COM_E_DMIOS000000001Out;
import cigna.zz.BizUtil;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.RptUtil;
import cigna.zz.SecuUtil;


/**
 * @file         cigna.cm.a.bean.CMA010BEAN.java
 * @filetype     java source file
 * @brief        안내장연계
 * @author       박진성
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박진성       2016. 6. 24.       신규 작성
 *
 */
@KlafBean
public class CMA010BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());

	
	@Autowired
	private CMA201DBIO cma201dbio; 
		
	/**
	 * 안내장 발송 연계
	 * @param 
	 * @return 
	 * @throws ApplicationException	 * 
	 */	
	public CMA010SVC00Out sndNotcl(CMA010SVC00In input) throws ApplicationException {
		
		CMA010SVC00Out out = new CMA010SVC00Out();
		
		COM_E_DMIOS000000001In req = new COM_E_DMIOS000000001In();
		
        req.setReqSysId         (input.getReqSysId());          //요청시스템ID
        req.setFormtDcd         (input.getFormtDcd());          //서식구분코드
        req.setNotclId          (input.getNotclId());           //안내장ID
        req.setVerNo            (input.getVerNo());             //안내장버젼
        req.setNotclNm          (input.getNotclNm());           //안내장명
        req.setDocCd            (input.getDocCd());             //문서코드
        req.setDocId            (input.getDocId());             //문서ID
        req.setCtryCd           (input.getCtryCd());            //국가코드
        req.setExpDt            (input.getExpDt());             //예정일자
        req.setExpTi            (input.getExpTi());             //예정시각
        req.setInspYn           (input.getInspYn());            //검사여부
        req.setDocInqYn         (input.getDocInqYn());          //문서조회여부
        req.setDocStrgPrd       (input.getDocStrgPrd());        //문서보관기간
        req.setNotclSndMedcd    (input.getNotclSndMedcd());     //안내장발송매체코드
        req.setReceCustNo       (input.getReceCustNo());        //수신자-고객번호
        req.setReceCustNm       (input.getReceCustNm());        //수신자-고객명
        req.setRecvAddrDcd      (input.getRecvAddrDcd());       //안내장발송주소구분코드
        req.setReceZip          (input.getReceZip());           //수신우편번호
        req.setReceZipAddr      (input.getReceZipAddr());       //우편번호주소
//      req.setReceEtcAddr      (input.getReceEtcAddr());       //수신기타주소(암호화)
        req.setReceMphonTeldno  (input.getReceMphonTeldno());   //휴대전화전화식별번호
        req.setReceMphonTelsno  (input.getReceMphonTelsno());   //휴대전화전화국번호
//      req.setReceMphonTelino  (input.getReceMphonTelino());   //휴대전화전화개별번호(암호화)
        req.setReceFaxdno       (input.getReceFaxdno());        //수신자-팩스식별번호
        req.setReceFaxsno       (input.getReceFaxsno());        //수신자-팩스국번호
//      req.setReceFaxino       (input.getReceFaxino());        //수신자-팩스개별번호(암호화)
//      req.setReceEmailId      (input.getReceEmailId());       //이메일ID(암호화)
        req.setReceEmailDmnVl   (input.getReceEmailDmnVl());    //이메일도메인
        req.setContLnNo         (input.getContLnNo());          //계약대출번호
        req.setContLnDt         (input.getContLnDt());          //계약대출일자
        req.setPmStcd           (input.getPmStcd());            //납입상태코드
        req.setNotclAppltNm     (input.getNotclAppltNm());      //안내장신청자명
        req.setIsueOrgNo        (input.getIsueOrgNo());         //발행조직번호
        req.setIsueEno          (input.getIsueEno());           //발행사원번호
        req.setClmnHqOrgNo      (input.getClmnHqOrgNo());       //수금본부조직번호
        req.setClmnDofOrgNo     (input.getClmnDofOrgNo());      //수금지점조직번호
        req.setClmnFofOrgNo     (input.getClmnFofOrgNo());      //수금영업소조직번호
        req.setClmnPlnrEnd      (input.getClmnPlnrEnd());       //수금설계사사원번호
        req.setRespTeldno       (input.getRespTeldno());        //발송자전화식별번호
        req.setRespTelsno       (input.getRespTelsno());        //발송자전화국번호
//      req.setRespTelino       (input.getRespTelino());        //발송자전화개별번호(암호화)
        req.setNotclIsueRfNo    (input.getNotclIsueRfNo());     //안내장발행참조번호
        req.setAtchFilePswd	    (input.getAtchFilePswd());      //첨부파일비밀번호
        req.setEtcReceZip	    (input.getEtcReceZip());        //기타수신우편번호
//      req.setEtcReceZipAddr   (input.getEtcReceZipAddr());    //기타우편번호주소(암호화)
        req.setProvsLst         (input.getProvsLst());          //약관목록
        req.setSecuEmailYn      (input.getSecuEmailYn());       //보안이메일여부
		
		// 암호화가 필요한 필드에 암호화모듈 적용 
		try	{
			if( !StringUtils.isEmpty(input.getReceEtcAddr()) )	{
				req.setReceEtcAddr				(SecuUtil.getEncValue(input.getReceEtcAddr(), SecuUtil.EncType.Addr));						//수신기타주소
			}
		}catch(Exception e)	{
			req.setReceEtcAddr				(input.getReceEtcAddr());					//수신기타주소
		}
		
		try	{
			if( !StringUtils.isEmpty(input.getReceMphonTelino()) )	{
				req.setReceMphonTelino		(SecuUtil.getEncValue(input.getReceMphonTelino(), SecuUtil.EncType.Contact));		//휴대전화전화개별번호
			}
		}catch(Exception e)	{
			req.setReceMphonTelino		(input.getReceMphonTelino());			//휴대전화전화개별번호
		}
		
		try	{
			if( !StringUtils.isEmpty(input.getReceFaxino()) )	{
				req.setReceFaxino					(SecuUtil.getEncValue(input.getReceFaxino(), SecuUtil.EncType.Contact));					//수신자-팩스개별번호
			}
		}catch(Exception e)	{
			req.setReceFaxino					(input.getReceFaxino());						//수신자-팩스개별번호
		}
		
		try	{
			if( !StringUtils.isEmpty(input.getReceEmailId()) )	{
				req.setReceEmailId					(SecuUtil.getEncValue(input.getReceEmailId(), SecuUtil.EncType.Email));						//이메일ID
			}
		}catch(Exception e)	{
			req.setReceEmailId					(input.getReceEmailId());						//이메일ID
		}
		
		try	{
			if( !StringUtils.isEmpty(input.getRespTelino()) )	{
				req.setRespTelino					(SecuUtil.getEncValue(input.getRespTelino(), SecuUtil.EncType.Contact));						//발송자전화개별번호
			}
		}catch(Exception e)	{
			req.setRespTelino					(input.getRespTelino());						//발송자전화개별번호
		}
		
		try	{
			if( !StringUtils.isEmpty(input.getEtcReceZipAddr()) )	{
				req.setEtcReceZipAddr				(SecuUtil.getEncValue(input.getEtcReceZipAddr(), SecuUtil.EncType.Addr));						//수신기타주소
			}
		}catch(Exception e)	{
			req.setEtcReceZipAddr				(input.getEtcReceZipAddr());					//기타우편번호주소
		}
				
		//makeNotcl(req);
		
		String printData = input.getPrintData();
		
		logger.debug("xmlStr : " + printData);
		
		req.setPrintData     (printData);  //출력정보
		
		COM_E_DMIOS000000001Out resData = callEAINotcl(req);
	    
		if(resData != null) {
			String errCd			=  resData.getErrCd();          
		    String errCtnt			=  resData.getErrCtnt();
		    String dlvDt			=  resData.getDlvDt();
		    String dlvTi			=  resData.getDlvTi();
		    String repoDocId		=  resData.getRepoDocId();
		    String imgDocId			=  resData.getImgDocId();
		    String dlvRcd			=  resData.getDlvRcd();
		    String notclSbackRscd	=  resData.getNotclSbackRscd();
		    String umsSndRcd		=  resData.getUmsSndRcd();
		    
			out.setErrCd			(errCd);
		    out.setErrCtnt			(errCtnt);
		    out.setDlvDt			(dlvDt);
		    out.setDlvTi			(dlvTi);
		    out.setRepoDocId		(repoDocId);
		    out.setImgDocId			(imgDocId);
		    out.setDlvRcd			(dlvRcd);
		    out.setNotclSbackRscd	(notclSbackRscd);
		    out.setUmsSndRcd		(umsSndRcd);
		}
	    
	    return out;	    
	    
	}
	
	/**
	 * 안내장 요청값 추가
	 * @param CMA010SVC00In input
	 * @throws ApplicationException	 * 
	 */	
	public void addDocCdNotclReq(CMA010SVC00In input, String docCd, String[] dsId, List<? extends Object>[] srcDataArr) throws ApplicationException {
		// input이 없다면 신규생성
		if (input == null) {
			throw new ApplicationException("APNBE0000",  new Object[]{"안내장요청정보"}, new Object[]{"안내장요청정보"}); // 필수 입력 항목값이 없습니다.
		}
		
		// 데이터셋 XML
		String dataXml = RptUtil.toRptXml(dsId, srcDataArr);
		
		addDocCdNotclReq(input, docCd, dataXml);
		
	}
	
	/**
	 * 안내장 요청값 추가
	 * @param CMA010SVC00In input
	 * @throws ApplicationException	 * 
	 */	
	public void addDocCdNotclReq(CMA010SVC00In input, String docCd, String dataXml) throws ApplicationException {
		logger.debug("CMA010BEAN.addDocCdNotclReq");
		
		// input이 없다면 신규생성
		if (input == null) {
			throw new ApplicationException("APNBE0000",  new Object[]{"안내장요청정보"}, new Object[]{"안내장요청정보"}); // 필수 입력 항목값이 없습니다.
		}
		
		StringBuffer dataXmlSB = new StringBuffer(dataXml);
		
		String splitStr = ",";
		if (StringUtils.isEmpty(input.getDocCd())) {
			input.setDocCd(docCd);
			if (dataXmlSB.indexOf("<root>") < 0) {
				// root 엘리먼트가 없다면 추가
				dataXmlSB.insert(0, "<root>");
				dataXmlSB.append("</root>");
			}
			//dataXml = dataXml.replace("<root>", "").replace("</root>", ""); // root 엘리먼트 삭제
			//dataXml = "<root>" + dataXml + "</root>"; // root 엘리먼트 추가
			input.setPrintData(dataXmlSB.toString());  //출력정보_xml
		} else {
			String[] docCdArr = input.getDocCd().split(splitStr);
			
			String printData = StringUtils.nvl(input.getPrintData());
			StringBuffer printDataSB = new StringBuffer(printData);
			
			if (docCdArr.length == 1) { // 기존에 한건만 있을때
				if (printDataSB.indexOf("<root>") > -1) {
					// root 엘리먼트를 기존 docId로 대체
					printDataSB = printDataSB.replace(0, 6, "<"+docCdArr[0]+">");
					printDataSB = printDataSB.replace(printDataSB.length()-7, printDataSB.length(), "</"+docCdArr[0]+">");
				}
				//printData = printData.replace("<root>", "<"+docCdArr[0]+">").replace("</root>", "</"+docCdArr[0]+">"); // root 엘리먼트를 기존 docId로 대체
			} else if (docCdArr.length > 1) { // 기존에 한건이상 있을때
				if (printDataSB.indexOf("<root>") > -1) {
					// root 엘리먼트를 삭제
					printDataSB = printDataSB.delete(0, 6); // root 엘리먼트 삭제
					printDataSB = printDataSB.delete(printDataSB.length()-7, printDataSB.length()); // root 엘리먼트 삭제
				}
				//printData = printData.replace("<root>", "").replace("</root>", ""); // root 엘리먼트 삭제
			} else {
				throw new ApplicationException("APNBE0000",  new Object[]{"안내장요청정보"}, new Object[]{"안내장요청정보"}); // 필수 입력 항목값이 없습니다.
			}
			
			if (dataXmlSB.indexOf("<root>") > -1) {
				// root 엘리먼트를 삭제
				dataXmlSB = dataXmlSB.delete(0, 6);
				dataXmlSB = dataXmlSB.delete(dataXmlSB.length()-7, dataXmlSB.length());
			}
			dataXmlSB.insert(0, "<"+docCd+">");
			dataXmlSB.append("</"+docCd+">");
			//dataXml = dataXml.replace("<root>", "").replace("</root>", ""); // root 엘리먼트 삭제
			//dataXml = "<"+docCd+">" + dataXml + "</"+docCd+">"; // 여러건으로 docCd로 엘리먼트 생성
			
			// root 엘리먼트 추가
			printDataSB.insert(0, "<root>");
			printDataSB.append(dataXmlSB);
			printDataSB.append("</root>");
			
			//printData = "<root>" + printData + dataXml + "</root>"; // root 엘리먼트 추가
			input.setPrintData(printDataSB.toString());  //출력정보_xml
			
			input.setDocCd(input.getDocCd() + "," + docCd);
		}
		
	}

	//RptUtil.toRptXml( new List[]{customerList, bzCntcList});
	public COM_E_DMIOS000000001Out sndNotcl(COM_E_DMIOS000000001In req, String[] dsId, List<? extends Object>[] srcDataArr) throws ApplicationException {
		
		
		makeNotcl(req);

		String printData = RptUtil.toRptXml(dsId, srcDataArr);
		req.setPrintData(printData);  //출력정보_xml
		
		COM_E_DMIOS000000001Out resData = callEAINotcl(req);
	    
	    return resData;	  
	}

	/**
	 * 안내잘 발송 연계
	 * @param 
	 * @return 
	 * @throws ApplicationException	 * 
	 */	
	public void makeNotcl(COM_E_DMIOS000000001In req) throws ApplicationException	{
		
		//발송서식유형코드 - formtDcd
		//00: 일반낱장(Default) - 일반봉투(내용물 컬라)
		//01: 흑백낱장  - 일반봉투(내용물 흑백)
		//02: 상품안내책자 - A4 비닐봉투 책장
		//03: 상품안내낱장 - A4 비닐봉투 낱장
		//06: 지로안내 - 지로용지로 나갈경우
		
		//문서코드(단일서식일 경우 필수)
		if( "0".equals(req.getFormtDcd()) && StringUtils.isEmpty(req.getDocCd()) ) {
			throw new ApplicationException( "APNBE0000", new Object[]{ "문서코드[docCd]" } );
		}
		
		//안내장발송매체코드(01:창구,02:EMAIL,03:FAX,04:일반우편,05:등기,06:방문전달,07:음성안내,08:SMS,09:LMS,10:콜센터,11:비정기,12:재발행)
		if( StringUtils.isEmpty(req.getNotclSndMedcd()) ) {
			throw new ApplicationException( "APNBE0000", new Object[]{ "안내장발송매체코드[notclSndMedcd]" } );
		}
		
		// 수신자 고객번호(고객번호가 넘어오지 않는 경우 default 값 세팅 : 고객파트 요청)
		if( StringUtils.isEmpty(req.getReceCustNo()) ) {
			req.setReceCustNo("000000000");
		}
		
		logger.debug("FwUtil.getMedTyp : " + FwUtil.getMedTyp());
		logger.debug("AtchFilePswd : " + req.getAtchFilePswd());
		
		if(BizUtil.MED_TYP_CD_COR.equals(FwUtil.getMedTyp())) {
			if (!"000000000".equals(req.getReceCustNo()) && (StringUtils.isEmpty(req.getAtchFilePswd()))) {
				
				try	{
					String custDscNo = cma201dbio.selectOneTBCSPRF001c(req.getReceCustNo());
					if(custDscNo != null && custDscNo.length() > 0) {
						req.setAtchFilePswd(custDscNo.substring(0,6));
					}
				}
				catch(Exception e){
					req.setAtchFilePswd("");
				}
			}
		}
		
		/**
		// 우편 발송시 우편주소 필수체크는 고객정보 불일치에 따라 하지 않도록 함(16.08.11)
		if( ("04".equals(req.getNotclSndMedcd()) || "05".equals(req.getNotclSndMedcd()) || "06".equals(req.getNotclSndMedcd())) )	{
			//안내장발송주소구분코드 필수 (10:자택, 20:직장,30:기타, 31:기타2, 32:기타3, 33 기타4, 34:기타5, 50:사업장주소)
			if( StringUtils.isEmpty(req.getRecvAddrDcd()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "안내장발송주소구분코드[recvAddrDcd]" } );
			}
			if( StringUtils.isEmpty(req.getReceZip()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "수신우편번호[receZip]" } );
			}
			if( StringUtils.isEmpty(req.getReceZipAddr()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "우편번호주소[receZipAddr]" } );
			}
			if( StringUtils.isEmpty(req.getReceEtcAddr()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "수신기타주소[receEtcAddr]" } );
			}
			
		}
		*/
		// 우편물 발송(04,05,06)시 수신우편번호, 우편번호주소, 수신기타주소 모두 존재 하지 않는 경우 Exception
		if( "04".equals(req.getNotclSndMedcd()) || "05".equals(req.getNotclSndMedcd()) || "06".equals(req.getNotclSndMedcd()) )	{
			if( StringUtils.isEmpty(req.getReceZip()) &&  StringUtils.isEmpty(req.getReceZipAddr()) && StringUtils.isEmpty(req.getReceEtcAddr()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "주소정보" } );
			}
		}
		
		// SMS, LMS 발송시 휴대전화전화 필수 체크
		if( ("08".equals(req.getNotclSndMedcd()) || "09".equals(req.getNotclSndMedcd()) ) )	{
			/** 휴대전화번호 필수체크는 고객정보 불일치에 따라 하지 않도록 함 (16.08.11) */
			if(StringUtils.isEmpty(req.getReceMphonTeldno()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "휴대전화전화식별번호[receMphonTeldno]" } );
			}
			if(StringUtils.isEmpty(req.getReceMphonTelsno()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "휴대전화전화국번호[receMphonTelsno]" } );
			}
			if(StringUtils.isEmpty(req.getReceMphonTelino()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "휴대전화전화개별번호[receMphonTelino]" } );
			}
			
			/*
			if( !BizCommUtil.isValidMpno(req.getReceMphonTeldno() + req.getReceMphonTelsno() + SecuUtil.getDecValue(req.getReceMphonTelino(), SecuUtil.EncType.Contact)) ) {
				// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
				throw new ApplicationException( "KIERE0005", null, new Object[]{ "수신고객휴대전화번호가 휴대전화번호 형식에 맞지 않음" });
			}
			*/
			
			// 휴대전화식별번호, 휴대전화국번호, 휴대전화개별번호 모두 존재 하지 않는 경우 Exception
			if( StringUtils.isEmpty(req.getReceMphonTeldno()) || StringUtils.isEmpty(req.getReceMphonTelsno()) || StringUtils.isEmpty(req.getReceMphonTelino()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "휴대전화번호" } );
			}
			
			// 발신자 휴대전화가 없는 경우  라이나콜센터 번호로 default Setting(1588-0058)
			if( StringUtils.isEmpty(req.getRespTelsno()) && StringUtils.isEmpty(req.getRespTelino()) )		{
				req.setRespTeldno		("");
				req.setRespTelsno		("1588");
				req.setRespTelino		("0058");
			}
			
			// 수신자 휴대전화개별번호 암호화
			req.setRespTelino(SecuUtil.getEncValue(req.getRespTelino(), SecuUtil.EncType.Contact));
		}
		
		// FAX(03) 발송시 팩스번호 필수체크는 고객정보 불일치에 따라 하지 않도록 함 (16.08.11)
		if( ("03".equals(req.getNotclSndMedcd())) )	{
			/*
			if(StringUtils.isEmpty(req.getReceFaxdno()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "수신자-팩스식별번호[receFaxdno]" } );
			}
			*/
			if(StringUtils.isEmpty(req.getReceFaxsno()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "수신자-팩스국번호[receFaxsno]" } );
			}
			if(StringUtils.isEmpty(req.getReceFaxino()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "수신자-팩스개별번호[receFaxino]" } );
			}
			
			/*
			if( !BizCommUtil.isValidTelno(req.getReceMphonTeldno() + req.getReceMphonTelsno() + req.getReceMphonTelino())) {
				// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
				throw new ApplicationException( "KIERE0005", null, new Object[]{ "수신자팩스번호가 팩스번호 형식에 맞지 않음" });
			}
			*/
		}
		
		// FAX(03) 발송시 팩스식별번호, 팩스국번호, 팩스개별번호 모두 존재 하지 않는 경우 Exception
		if( ("03".equals(req.getNotclSndMedcd())) )	{
			if( StringUtils.isEmpty(req.getReceFaxdno()) &&  StringUtils.isEmpty(req.getReceFaxsno()) && StringUtils.isEmpty(req.getReceFaxino()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "팩스번호" } );
			}
		}
		
		/**
		// EMAIL(02) 발송시 이메일주소 필수체크는 고객정보 불일치에 따라 하지 않도록 함 (16.08.11)
		if( ("02".equals(req.getNotclSndMedcd())) )	{
			if(StringUtils.isEmpty(req.getReceEmailId()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "이메일ID[receEmailId]" } );
			}
			if(StringUtils.isEmpty(req.getReceEmailDmnVl()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "이메일도메인[receEmailDmnVl]" } );
			}
		}
		*/
		// EMAIL(02) 발송시 이메일ID, 이메일도메인 모두 존재 하지 않는 경우 Exception
		if( ("02".equals(req.getNotclSndMedcd())) )	{
			if( StringUtils.isEmpty(req.getNotclSndMedcd()) &&  StringUtils.isEmpty(req.getReceEmailDmnVl()) )	{
				throw new ApplicationException( "APNBE0000", new Object[]{ "이메일주소" } );
			}
		}
		
		/** 처리조직번호
		 *    1. 온라인인 경우 로그인사번의 조직번호 세팅
		 *    2. 배치인 경우 업무별 정의된 조직번호 세팅
		**/
		if ( FwUtil.isBatch() )	{
			req.setIsueOrgNo(RptUtil.getBatchDeptCd());
		} else {
			if( StringUtils.isEmpty(req.getIsueOrgNo()) )	{
				req.setIsueOrgNo(FwUtil.getDeptCd());
			}
		}
		
		//처리자의사원번호(온라인인 경우 로그인사원번호, 배치인 경우 job id)
		if ( StringUtils.isEmpty(req.getIsueEno()) ) {
			req.setIsueEno(FwUtil.getUserId());
		}
		
		//서식구분코드가 1자리면 2자리로 늘린다
		if ("0".equals(req.getFormtDcd())) {
			req.setFormtDcd("00");
		} else if ("1".equals(req.getFormtDcd())) {
			req.setFormtDcd("01");
		}
		
		if(StringUtils.isEmpty(req.getNotclId())) 			req.setNotclId("");			//안내장ID
		if(StringUtils.isEmpty(req.getRecvAddrDcd()))		req.setRecvAddrDcd("");		//주소구분코드
		if(StringUtils.isEmpty(req.getFormtDcd()))			req.setFormtDcd("00");		//서식구분코드(0):일반낱장(Default)
		if(StringUtils.isEmpty(req.getReqSysId()))			req.setReqSysId(FwUtil.getMedTyp());		//요청시스템ID
		if(StringUtils.isEmpty(req.getVerNo()))				req.setVerNo("");			//안내장버젼
		if(StringUtils.isEmpty(req.getNotclNm()))			req.setNotclNm("");			//안내장명
		if(StringUtils.isEmpty(req.getDocId()))				req.setDocId ("");			//문서ID_요청 시스템의 문서 UNIQUE ID(증권번호 or 접수번호)-생략가능
		if(StringUtils.isEmpty(req.getCtryCd()))			req.setCtryCd("");			//다국어 지원을 위한 언어코드 - 생략가능
		if(StringUtils.isEmpty(req.getExpDt()))				req.setExpDt("");			//예약발송일자 - 생략가능
		if(StringUtils.isEmpty(req.getExpTi()))				req.setExpTi("");			//예약발송시각 - 생략가능
		if(StringUtils.isEmpty(req.getInspYn()))			req.setInspYn("0");			//검사여부(0: 미검수(자동발송:DEFAULT), 1: 검수)
		if(StringUtils.isEmpty(req.getDocInqYn()))			req.setDocInqYn("1");		//문서조회여부(0:미조회, 1:조회(DEFAULT)
		if(StringUtils.isEmpty(req.getDocStrgPrd())) 		req.setDocStrgPrd("0");		//문서보관기간(DEFAULT 0 (영구))
		if(StringUtils.isEmpty(req.getReceCustNm())) 		req.setReceCustNm("");		//수신고객명
		if(StringUtils.isEmpty(req.getReceZip()))			req.setReceZip("");			//수신우편번호
		if(StringUtils.isEmpty(req.getReceZipAddr()))		req.setReceZipAddr("");		//우편번호주소
		if(StringUtils.isEmpty(req.getReceEtcAddr()))		req.setReceEtcAddr("");		//수신기타주소(암호화)
		if(StringUtils.isEmpty(req.getReceMphonTeldno()))	req.setReceMphonTeldno("");	//휴대전화전화식별번호
		if(StringUtils.isEmpty(req.getReceMphonTelsno()))	req.setReceMphonTelsno("");	//휴대전화전화국번호
		if(StringUtils.isEmpty(req.getReceMphonTelino()))	req.setReceMphonTelino("");	//휴대전화전화개별번호(암호화)
		if(StringUtils.isEmpty(req.getReceFaxdno()))		req.setReceFaxdno("");		//수신자-팩스식별번호
		if(StringUtils.isEmpty(req.getReceFaxsno()))		req.setReceFaxsno("");		//수신자-팩스국번호
		if(StringUtils.isEmpty(req.getReceFaxino()))		req.setReceFaxino("");		//수신자-팩스개별번호(암호화)
		if(StringUtils.isEmpty(req.getReceEmailId()))		req.setReceEmailId("");		//이메일ID(암호화)
		if(StringUtils.isEmpty(req.getReceEmailDmnVl()))	req.setReceEmailDmnVl("");	//이메일도메인
		if(StringUtils.isEmpty(req.getContLnNo()))			req.setContLnNo("");		//안내장발행관리번호에해당하는계약번호혹은대출번호
		if(StringUtils.isEmpty(req.getContLnDt()))			req.setContLnDt("");		//해당계약번호의계약일자혹은대출번호의대출일자
		if(StringUtils.isEmpty(req.getPmStcd()))			req.setPmStcd("");			//해당계약의납입상태를구분하는코드
		if(StringUtils.isEmpty(req.getNotclAppltNm()))		req.setNotclAppltNm("");	//신청자명
		if(StringUtils.isEmpty(req.getClmnHqOrgNo()))		req.setClmnHqOrgNo("");		//해당계약의수금을담당하는본부의조직번호
		if(StringUtils.isEmpty(req.getClmnDofOrgNo()))		req.setClmnDofOrgNo("");	//해당계약의수금을담당하는지점의조직번호
		if(StringUtils.isEmpty(req.getClmnFofOrgNo()))		req.setClmnFofOrgNo("");	//해당계약의수금을담당하는영업소의조직번호
		if(StringUtils.isEmpty(req.getClmnPlnrEnd()))		req.setClmnPlnrEnd("");		//해당계약의수금을담당하는설계사의사원번호
		if(StringUtils.isEmpty(req.getRespTeldno()))		req.setRespTeldno("");		//발송자전화식별번호
		if(StringUtils.isEmpty(req.getRespTelsno()))		req.setRespTelsno("");		//발송자전화국번호
		if(StringUtils.isEmpty(req.getRespTelino()))		req.setRespTelino("");		//발송자전화개별번호(암호화)
		if(StringUtils.isEmpty(req.getNotclIsueRfNo()))		req.setNotclIsueRfNo("");	//안내장발행참조번호
		if(StringUtils.isEmpty(req.getAtchFilePswd()))      req.setAtchFilePswd("");    //첨부파일비밀번호
		if(StringUtils.isEmpty(req.getEtcReceZip()))        req.setEtcReceZip("");      //기타수신우편번호
		if(StringUtils.isEmpty(req.getEtcReceZipAddr()))    req.setEtcReceZipAddr("");  //기타우편번호주소
		if(StringUtils.isEmpty(req.getEtcReceEtcAddr()))    req.setEtcReceEtcAddr("");  //기타수신기타주소
		if(StringUtils.isEmpty(req.getProvsLst()))          req.setProvsLst("");        //약관목록
		if(StringUtils.isEmpty(req.getSecuEmailYn()))       req.setSecuEmailYn("Y");     //보안이메일여부
		if(StringUtils.isEmpty(req.getPrintData()))         req.setPrintData("");       //PrintData
		
		// 우편번호에 nullnull들어오면 치환
		if (!StringUtils.isEmpty(req.getReceZip())) {
			req.setReceZip(req.getReceZip().replaceAll("null", ""));
		}
		if (!StringUtils.isEmpty(req.getEtcReceZip())) {
			req.setEtcReceZip(req.getEtcReceZip().replaceAll("null", ""));
		}
		
		// 암호화가 필요한 필드에 암호화모듈 적용 
		try	{
			if( !StringUtils.isEmpty(req.getReceEtcAddr()) )	{
				req.setReceEtcAddr				(SecuUtil.getEncValue(req.getReceEtcAddr(), SecuUtil.EncType.Addr));						//수신기타주소
			}
		}catch(Exception e)	{
			req.setReceEtcAddr				(req.getReceEtcAddr());					//수신기타주소
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getReceMphonTelino()) )	{
				req.setReceMphonTelino		(SecuUtil.getEncValue(req.getReceMphonTelino(), SecuUtil.EncType.Contact));		//휴대전화전화개별번호
			}
		}catch(Exception e)	{
			req.setReceMphonTelino		(req.getReceMphonTelino());			//휴대전화전화개별번호
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getReceFaxino()) )	{
				req.setReceFaxino					(SecuUtil.getEncValue(req.getReceFaxino(), SecuUtil.EncType.Contact));					//수신자-팩스개별번호
			}
		}catch(Exception e)	{
			req.setReceFaxino					(req.getReceFaxino());						//수신자-팩스개별번호
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getReceEmailId()) )	{
				req.setReceEmailId					(SecuUtil.getEncValue(req.getReceEmailId(), SecuUtil.EncType.Email));						//이메일ID
			}
		}catch(Exception e)	{
			req.setReceEmailId					(req.getReceEmailId());						//이메일ID
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getRespTelino()) )	{
				req.setRespTelino					(SecuUtil.getEncValue(req.getRespTelino(), SecuUtil.EncType.Contact));						//발송자전화개별번호
			}
		}catch(Exception e)	{
			req.setRespTelino					(req.getRespTelino());						//발송자전화개별번호
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getEtcReceEtcAddr()) )	{
				req.setEtcReceEtcAddr(SecuUtil.getEncValue(req.getEtcReceEtcAddr(), SecuUtil.EncType.Addr));						//이메일ID
			}
		}catch(Exception e)	{
			req.setEtcReceEtcAddr(req.getEtcReceEtcAddr());						//안내장발행기타주소
		}

		logger.debug("setting req data:{}", req);
		
	}
		
	public COM_E_DMIOS000000001Out callEAINotcl(COM_E_DMIOS000000001In req) throws ApplicationException {
		
		String interfaceId = "COM_E_DMIOS000000001";		// EAI Interface ID
		
		EISResponse <COM_E_DMIOS000000001Out> res = null;
		COM_E_DMIOS000000001Out resData = null;
		
		makeNotcl(req);

		logger.debug("eaiRequest data:{}", req);
		
		try {
			
			res = InfUtil.callEAI(req, interfaceId, "CS", "CSSDMISVC", "DMI0001", FwUtil.getDeptCd(), FwUtil.getUserId(), COM_E_DMIOS000000001Out.class);
			
		    resData = res.getResponseData();
		    
		    logger.debug("eaiResponse data:{}", resData);
		    
			// 정상이 아닌 경우 Exception 처리
			if( !"00000".equals(resData.getErrCd()) )	{
				throw new ApplicationException( "KIERE0005", null, new Object[]{ resData.getErrCtnt() });
			}
		    
	    } catch (EisExecutionException e) { 
	    	logger.error("EisExecutionException", e); 
	    	throw new ApplicationException( "KIERE0005", null, new Object[]{ "EAI 호출 - EisExecutionException"});
	    } catch (NotSupportedEISException e) {
	    	logger.error("NotSupportedEISException", e);
	    	throw new ApplicationException( "KIERE0005", null, new Object[]{ "EAI 호출 - NotSupportedEISException"});
	    } catch (Exception e) {
	    	logger.error("Exception", e);  
	    	throw new ApplicationException( "KIERE0005", null, new Object[]{ "EAI 호출 - 오류 발생"});
	    }
		
	    return resData;	    
	    
	}

	public void transNotclFile (String srcFileName, String tgFileName ) throws ItemStreamException{

		logger.info("transFileName{}", srcFileName);
		
		try {

			String shellPath 		= "/sdata/companion/recv/bin/dmiloader.sh";
			String shellPara 		= "";

			logger.info("targetFileName  : {}", tgFileName);
			logger.info("shellPath  : {}", shellPath);
			logger.info("shellPara  : {}", shellPara);
			
			//파일 전송 호출 for Test( /sdata/biz/CM/batch_sample.dat -> //sdata/companion/recv/eai/batch_sample.dat
			 
			
			InfUtil.transFile(	 InfUtil.TRANS_FILE_EAI_ASYNC		// EAI async 코드(단방향)
								,"COM_E_DMIBS000000001"				// Interface ID
								,srcFileName						// 전송할 File Path/File name
								,tgFileName						    // 전송될 곳의 File name
								,shellPath							// 전송후 실행할 상대 시스템의 shell 명령어
								,shellPara);						// 전송후 실행할 상대 시스템의 shell 의 parameter

		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException",e);
			throw new ItemStreamException("파일전송 오류");

		} catch (EisExecutionException e) {
			logger.error("EisExecutionException",e);
			throw new ItemStreamException("파일전송 오류");

		} catch (Exception e) {
			logger.error("Exception",e);
			throw new ItemStreamException("파일전송 오류");
		}

		logger.info("파일전송 종료");
		
	}	
	
}