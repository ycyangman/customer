package cigna.cm.a.bean;

import java.util.List;

import cigna.cm.a.dbio.CMA201DBIO;
import cigna.cm.a.domain.EmailMsgInfo;
import cigna.cm.a.domain.SmsMsgInfo;
import cigna.cm.a.io.TBCMCCD014Io;
import cigna.zz.BizCommUtil;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file         cigna.cm.a.bean.CMA201BEAN.java
 * @filetype     java source file
 * @brief        메시지 관리
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박경화                     2012. 12. 13.       신규 작성
 *
 */
/**
 * SMS/이메일(메시지) 등록하기 위한 KlafBean class
 *
 */
@KlafBean
public class CMA201BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 메시지관리 DBIO
	 */	
	@Autowired
	private CMA201DBIO cma201dbio; 
	
	/**
	 * 채번관련 BEAN
	 */	
	@Autowired
	private CMA004BEAN cma004bean;
	
	/** 시스템 구분코드 */
	private static final String SYS_DCD = "B";
	
	
	/**
	 * SMS 메시지 정보 등록(단건)
	 * @param smsMsgInfo 메지시정보
	 * <per>
	 * smsMsgInfo[ <br>
	 * 	prcsObjDcd(처리대상구분코드) : C(1) [BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME 또는 BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH] <br>
	 * 	msgDcd(메시지구분코드) : C(1) [BizCommUtil.MSG_DCD_SMS 또는 BizCommUtil.MSG_DCD_SMS] <br>
	 *  regDt(등록일자) : C(8) <br>
	 *  regTi(등록시각) : C(6) <br>
	 * 	linalifeSvcId(라이나생명서비스ID) : C(6) <br>
	 * 	ecaSvcNo(이케어서비스번호) : C(15) <br>
	 * 	sndEno(발송사원번호) : C(10) <br>
	 * 	sndOrgNo(발송조직번호) : C(6) <br>
	 * 	msgReceCustRfNo(메시지수신고객참조번호)	 : C(9) [처리계 : 고객번호] <br>
	 * 	msgReceCustNm(메시지수신고객명) : C(40) <br>
	 * 	receCustEmailMpno(수신고객휴대전화번호) : C(100)<br>
	 * 	sndEmplEmailTelno(발송사원전화번호) : C(100)<br>
	 * 	msgDataLen(메시지데이터길이) : N(5) <br>
	 * 	usrDataCtnt1(사용자대량데이터내용) : C(3000) <br>
	 * 	usrDataCtnt2(사용자데이터내용2) : C(3000) <br>
	 * 	usrDataCtnt3(사용자데이터내용3) : C(3000) <br>
	 * 	usrDataCtnt4(사용자데이터내용4) : C(3000) <br>
	 * 	usrDataCtnt5(사용자데이터내용5) : C(3000) <br>
	 * 	usrDataCtnt6(사용자데이터내용6) : C(3000) <br>
	 * 	usrDataCtnt7(사용자데이터내용7) : C(3000) <br>
	 * 	usrDataCtnt8(사용자데이터내용8) : C(3000) <br>
	 * 	usrDataCtnt9(사용자데이터내용9) : C(3000) <br>
	 * 	usrDataCtnt10(사용자데이터내용10) : C(3000) <br>
	 * ] <br>
	 * </per>
	 * @return
	 * @throws ApplicationException
	 */
	public String insertSmsInfo(SmsMsgInfo smsMsgInfo) throws ApplicationException {
		
		throw new ApplicationException("APNBE0119", new String[] {"사용하지 않는 SMS모듈입니다!"});
		
		// 메시지관리번호
		/*
		String msgMgntNo = insertSmsInfo( "", smsMsgInfo );
		return msgMgntNo;
		*/
	}
	
	/**
	 * SMS 메시지 정보 등록(다건)
	 * @param smsMsgList 메지시정보리스트
	 * <per>
	 * smsMsgInfo[ <br>
	 * 	prcsObjDcd(처리대상구분코드) : C(1) [BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME 또는 BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH] <br>
	 * 	msgDcd(메시지구분코드) : C(1) [BizCommUtil.MSG_DCD_SMS 또는 BizCommUtil.MSG_DCD_SMS] <br>
	 *  regDt(등록일자) : C(8) <br>
	 *  regTi(등록시각) : C(6) <br>
	 * 	linalifeSvcId(라이나생명서비스ID) : C(6) <br>
	 * 	ecaSvcNo(이케어서비스번호) : C(15) <br>
	 * 	sndEno(발송사원번호) : C(10) <br>
	 * 	sndOrgNo(발송조직번호) : C(6) <br>
	 * 	msgReceCustRfNo(메시지수신고객참조번호)	 : C(9) [처리계 : 고객번호] <br>
	 * 	msgReceCustNm(메시지수신고객명) : C(40) <br>
	 * 	receCustEmailMpno(수신고객휴대전화번호) : C(100)<br>
	 * 	sndEmplEmailTelno(발송사원전화번호) : C(100)<br>
	 * 	msgDataLen(메시지데이터길이) : N(5) <br>
	 * 	usrDataCtnt1(사용자대량데이터내용) : C(3000) <br>
	 * 	usrDataCtnt2(사용자데이터내용2) : C(3000) <br>
	 * 	usrDataCtnt3(사용자데이터내용3) : C(3000) <br>
	 * 	usrDataCtnt4(사용자데이터내용4) : C(3000) <br>
	 * 	usrDataCtnt5(사용자데이터내용5) : C(3000) <br>
	 * 	usrDataCtnt6(사용자데이터내용6) : C(3000) <br>
	 * 	usrDataCtnt7(사용자데이터내용7) : C(3000) <br>
	 * 	usrDataCtnt8(사용자데이터내용8) : C(3000) <br>
	 * 	usrDataCtnt9(사용자데이터내용9) : C(3000) <br>
	 * 	usrDataCtnt10(사용자데이터내용10) : C(3000) <br>
	 * ] <br>
	 * </per>
	 * @return 메시지관리그룹번호
	 * @throws ApplicationException
	 */
	public String insertSmsInfo(List<SmsMsgInfo> smsMsgInfoList) throws ApplicationException {
		
		/*
		String msgMgntGrpNo = "";  // 메시지관리그룹번호
		
		for( SmsMsgInfo smsMsgInfo : smsMsgInfoList ) { 
			
			if( StringUtils.isEmpty(msgMgntGrpNo) ) {
				msgMgntGrpNo = insertSmsInfo(smsMsgInfo); 
			} else {
				insertSmsInfo(msgMgntGrpNo, smsMsgInfo); 
			}
		}
		
		return msgMgntGrpNo;
		*/
		
		throw new ApplicationException("APNBE0119", new String[] {"사용하지 않는 SMS모듈입니다!"});
	}
	
	/**
	 * SMS 메시지 정보 등록
	 * @param msgMgntGrpNo  메시지관리그룹번호
	 * @param smsMsgInfo    메지시정보
	 * @return 메시지관리번호
	 * @throws ApplicationException
	 */
	private String insertSmsInfo(String msgMgntGrpNoInput, SmsMsgInfo smsMsgInfo) throws ApplicationException {
		String msgMgntGrpNo = msgMgntGrpNoInput;
		
		String prcsObjDcd = smsMsgInfo.getPrcsObjDcd();  // 처리대상구분코드
		
		String msgDcd = smsMsgInfo.getMsgDcd();  // 메시지구분코드
		
		String msgMgntNo = "";  // 메시지관리번호
		
		String regDt = smsMsgInfo.getRegDt();  // 등록일자
		
		String regTi = smsMsgInfo.getRegTi();  // 등록시각
		
		int iResult = 0;
		
		logger.debug("smsMsgInfo : {} " , smsMsgInfo);

		// 처리대상구분코드가 명시적으로 셋팅하지 않을경우 온라인에서 실행 된 건은 실시간, 배치에서 실행된 건은 대량배치로 처리  
		if( StringUtils.isEmpty(prcsObjDcd) || 
				( !BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME.equals(prcsObjDcd) && !BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH.equals(prcsObjDcd) ) ) {
			if ( LApplicationContext.isOnlineContext() ) {
				prcsObjDcd = BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME;	// 실시간 : R
			} else {
				prcsObjDcd = BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH; 		// 대량배치 : B
			}
		}
		
		if( StringUtils.isEmpty(msgDcd) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(메시지구분코드)" });
		} else if ( !BizCommUtil.MSG_DCD_SMS.equals(msgDcd) && !BizCommUtil.MSG_DCD_LMS.equals(msgDcd) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "메시지구분코드 범위 초과(S 또는 L)" });
		}
		
		if( StringUtils.isEmpty(regDt))  {	//등록일자가 없을 경우
			regDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		}
		
		if( StringUtils.isEmpty(regTi))  {	//등록시간이 없을 경우
			regTi = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		}
		
		if( StringUtils.isEmpty(smsMsgInfo.getLinalifeSvcId()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(라이나생명서비스ID)" });
		} else if (smsMsgInfo.getLinalifeSvcId().length() > 6) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "라이나생명서비스ID 길이 초과 (6자리이내)" });
		}
		
		if( BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME.equals(prcsObjDcd) && StringUtils.isEmpty(smsMsgInfo.getEcaSvcNo()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(이케어서비스번호)" });
		} else if (BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME.equals(prcsObjDcd) && !StringUtils.isDigit(smsMsgInfo.getEcaSvcNo())) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "이케어서비스번호는 숫자만 가능" });
		}
		
		if( StringUtils.isEmpty(smsMsgInfo.getMsgReceCustRfNo()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(메시지수신고객참조번호)" });
		}
		
		if( StringUtils.isEmpty(smsMsgInfo.getMsgReceCustNm())  ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(메시지수신고객명)" });
		} else if (BizCommUtil.getStringToByteLen(smsMsgInfo.getMsgReceCustNm(), "KSC5601") > 40) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "메시지수신고객명 길이초과 (40byte까지 가능)" });
		}
		
		if( StringUtils.isEmpty(smsMsgInfo.getReceCustEmailMpno()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(수신고객휴대전화번호)" });
		} else if (!BizCommUtil.isValidMpno(smsMsgInfo.getReceCustEmailMpno())) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "수신고객휴대전화번호 항목이 휴대전화 형식에 맞지 않음" });
		}
		
		if( StringUtils.isEmpty(smsMsgInfo.getSndEmplEmailTelno()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(발송사원전화번호)" });
		} else if (!BizCommUtil.isValidTelno(smsMsgInfo.getSndEmplEmailTelno())) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "발송사원전화번호 항목이 전화번호 형식에 맞지 않음" });
		}
		
		if( StringUtils.isEmpty(smsMsgInfo.getUsrBigQtyDataCtnt()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(사용자대량데이터내용)" });
		}
		
		if( smsMsgInfo.getMsgDataLen() == null ) {
			// 메시지데이터길이 계산
			
			int msgDataLen = BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrBigQtyDataCtnt(), "KSC5601");
			
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt2(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt3(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt4(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt5(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt6(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt7(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt8(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt9(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(smsMsgInfo.getUsrDataCtnt10(), "KSC5601");
			
			smsMsgInfo.setMsgDataLen(msgDataLen);
			
			logger.debug( "msgDataLen : {} " , msgDataLen );
		} 
		
		if( StringUtils.isEmpty(smsMsgInfo.getSndEno()) ) {
			// 발송사원번호
			smsMsgInfo.setSndEno(FwUtil.getUserId());
		}
		
		if( StringUtils.isEmpty(smsMsgInfo.getSndOrgNo()) ) {
			// 발송조직번호
			smsMsgInfo.setSndOrgNo(FwUtil.getDeptCd());
		}
		
		// 메시지관리번호 채번
		msgMgntNo = this.cma004bean.getNewComnMknoNoAll( SYS_DCD + prcsObjDcd  +  msgDcd , 12);
		
		if( StringUtils.isEmpty(msgMgntGrpNo) ) {
			// 메시지관리그룹번호
			msgMgntGrpNo = msgMgntNo;
		}
		
		logger.debug( "메시지관리번호 채번 msgMgntNo : {} " , msgMgntNo );
		
		if( !StringUtils.isEmpty(msgMgntNo) ) {
		
			TBCMCCD014Io tbcmccd014io = new TBCMCCD014Io();
			
			tbcmccd014io.setMsgMgntNo(msgMgntNo); 									// 메시지관리번호
			tbcmccd014io.setMsgDcd(msgDcd); 										// 메시지구분코드
			tbcmccd014io.setMsgMgntGrpNo(msgMgntGrpNo); 		     				// 메시지관리그룹번호
			tbcmccd014io.setRegDt(regDt);		     									// 등록일자
			tbcmccd014io.setRegTi(regTi); 		     									// 등록시간
			tbcmccd014io.setLinalifeSvcId(smsMsgInfo.getLinalifeSvcId()); 			// 라이나생명서비스ID
			tbcmccd014io.setEcaSvcNo(smsMsgInfo.getEcaSvcNo()); 					// 이케어서비스번호
			tbcmccd014io.setSndEno(smsMsgInfo.getSndEno()); 						// 발송사원번호
			tbcmccd014io.setSndOrgNo(smsMsgInfo.getSndOrgNo()); 					// 발송조직번호
			tbcmccd014io.setMsgReceCustRfNo(smsMsgInfo.getMsgReceCustRfNo()); 		// 메시지수신고객참조번호
			tbcmccd014io.setMsgReceCustNm(smsMsgInfo.getMsgReceCustNm()); 			// 메시지수신고객명
			tbcmccd014io.setReceCustEmailMpno(smsMsgInfo.getReceCustEmailMpno()); 	// 수신고객이메일휴대전화번호
			tbcmccd014io.setSndEmplEmailTelno(smsMsgInfo.getSndEmplEmailTelno()); 	// 발송사원이메일전화번호
			tbcmccd014io.setMsgDataLen(smsMsgInfo.getMsgDataLen()); 				// 메시지데이터길이
			tbcmccd014io.setUsrBigQtyDataCtnt(smsMsgInfo.getUsrBigQtyDataCtnt()); 			// 사용자대량데이터내용
			tbcmccd014io.setUsrDataCtnt2(smsMsgInfo.getUsrDataCtnt2()); 			// 사용자데이터내용2
			tbcmccd014io.setUsrDataCtnt3(smsMsgInfo.getUsrDataCtnt3()); 			// 사용자데이터내용3
			tbcmccd014io.setUsrDataCtnt4(smsMsgInfo.getUsrDataCtnt4()); 			// 사용자데이터내용4
			tbcmccd014io.setUsrDataCtnt5(smsMsgInfo.getUsrDataCtnt5()); 			// 사용자데이터내용5
			tbcmccd014io.setUsrDataCtnt6(smsMsgInfo.getUsrDataCtnt6());	 			// 사용자데이터내용6
			tbcmccd014io.setUsrDataCtnt7(smsMsgInfo.getUsrDataCtnt7()); 			// 사용자데이터내용6
			tbcmccd014io.setUsrDataCtnt8(smsMsgInfo.getUsrDataCtnt8()); 			// 사용자데이터내용8
			tbcmccd014io.setUsrDataCtnt9(smsMsgInfo.getUsrDataCtnt9()); 			// 사용자데이터내용9
			tbcmccd014io.setUsrDataCtnt10(smsMsgInfo.getUsrDataCtnt10()); 			// 사용자데이터내용10
			tbcmccd014io.setLastChgrId(FwUtil.getUserId()); 						// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd014io.setLastChgPgmId(FwUtil.getPgmId()); 						// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd014io.setLastChgTrmNo(FwUtil.getTrmNo()); 						// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			SecuUtil.doEncObject(tbcmccd014io); // 객체암호화
			/*
			if (BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME.equals(prcsObjDcd)) {
				iResult = this.cma201dbio.insertOneTBCMCCD014(tbcmccd014io);
			} 
			else if (BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH.equals(prcsObjDcd)) {
				iResult = this.cma201dbio.insertOneTBCMCCD022(tbcmccd014io);
			}
			*/
			
			logger.debug( "iResult : {} " , iResult );
			
		} else {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "메시지관리번호채번오류" });
		}
		
		return msgMgntNo;
	}
	
	/**
	 * 이메일 메시지 정보 등록(단건)
	 * @param emailMsgInfo 메지시정보
	 * <per>
	 * emailMsgInfo[ <br>
	 * 	prcsObjDcd(처리대상구분코드) : C(1) [BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME 또는 BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH] <br>
	 *  regDt(등록일자) : C(8) <br>
	 *  regTi(등록시각) : C(6) <br>
	 * 	linalifeSvcId(라이나생명서비스ID) : C(6) <br>
	 * 	ecaSvcNo(이케어서비스번호) : C(15) <br>
	 * 	sndEno(발송사원번호) : C(10) <br>
	 * 	sndOrgNo(발송조직번호) : C(6) <br>
	 * 	msgReceCustRfNo(메시지수신고객참조번호)	 : C(9) [처리계 : 고객번호] <br>
	 * 	msgReceCustNm(메시지수신고객명) : C(40) <br>
	 * 	receCustEmailMpno(수신고객이메일) : C(100)<br>
	 * 	sndEmplEmailTelno(발송사원이메일) : C(100)<br>
	 * 	secuEmailDvsnVl(보안이메일구분값) : C(1) [BizCommUtil.SECU_EMAIL_DVSN_VL_NONSECURITY 또는 BizCommUtil.SECU_EMAIL_DVSN_VL_SECURITY] <br>
	 * 	secuKeyCper(보안키자릿수) : N(2) [BizCommUtil.SECU_EMAIL_DVSN_VL_SECURITY 경우 필수] <br>
	 * 	secuKeyVl(보안키값) : C(10) [BizCommUtil.SECU_EMAIL_DVSN_VL_SECURITY 경우 필수]<br>
	 * 	msgDataLen(메시지데이터길이) : N(5) <br>
	 * 	usrDataCtnt1(사용자대량데이터내용) : C(3000) <br>
	 * 	usrDataCtnt2(사용자데이터내용2) : C(3000) <br>
	 * 	usrDataCtnt3(사용자데이터내용3) : C(3000) <br>
	 * 	usrDataCtnt4(사용자데이터내용4) : C(3000) <br>
	 * 	usrDataCtnt5(사용자데이터내용5) : C(3000) <br>
	 * 	usrDataCtnt6(사용자데이터내용6) : C(3000) <br>
	 * 	usrDataCtnt7(사용자데이터내용7) : C(3000) <br>
	 * 	usrDataCtnt8(사용자데이터내용8) : C(3000) <br>
	 * 	usrDataCtnt9(사용자데이터내용9) : C(3000) <br>
	 * 	usrDataCtnt10(사용자데이터내용10) : C(3000) <br>
	 * ] <br>
	 * </per>
	 * @return
	 * @throws ApplicationException
	 */
	public String insertEmailInfo(EmailMsgInfo emailMsgInfo) throws ApplicationException {
		
		throw new ApplicationException("APNBE0119", new String[] {"사용하지 않는 SMS모듈입니다!"});
		
		// 메시지관리번호
		/*
		String msgMgntNo = insertEmailInfo( "", emailMsgInfo );
		
		return msgMgntNo;
		*/
	}	
	
	/**
	 * 이메일 메시지 정보 등록(다건)
	 * @param emailMsgInfo 메지시정보리스트
	 * <per>
	 * emailMsgInfo[ <br>
	 * 	prcsObjDcd(처리대상구분코드) : C(1) [BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME 또는 BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH] <br>
	 *  regDt(등록일자) : C(8) <br>
	 *  regTi(등록시각) : C(6) <br>
	 * 	linalifeSvcId(라이나생명서비스ID) : C(6) <br>
	 * 	ecaSvcNo(이케어서비스번호) : C(15) <br>
	 * 	sndEno(발송사원번호) : C(10) <br>
	 * 	sndOrgNo(발송조직번호) : C(6) <br>
	 * 	msgReceCustRfNo(메시지수신고객참조번호)	 : C(9) [처리계 : 고객번호] <br>
	 * 	msgReceCustNm(메시지수신고객명) : C(40) <br>
	 * 	receCustEmailMpno(수신고객이메일) : C(100)<br>
	 * 	sndEmplEmailTelno(발송사원이메일) : C(100)<br>
	 * 	secuEmailDvsnVl(보안이메일구분값) : C(1) [BizCommUtil.SECU_EMAIL_DVSN_VL_NONSECURITY 또는 BizCommUtil.SECU_EMAIL_DVSN_VL_SECURITY] <br>
	 * 	secuKeyCper(보안키자릿수) : N(2) [BizCommUtil.SECU_EMAIL_DVSN_VL_SECURITY 경우 필수] <br>
	 * 	secuKeyVl(보안키값) : C(10) [BizCommUtil.SECU_EMAIL_DVSN_VL_SECURITY 경우 필수]<br>
	 * 	msgDataLen(메시지데이터길이) : N(5) <br>
	 * 	usrDataCtnt1(사용자대량데이터내용) : C(3000) <br>
	 * 	usrDataCtnt2(사용자데이터내용2) : C(3000) <br>
	 * 	usrDataCtnt3(사용자데이터내용3) : C(3000) <br>
	 * 	usrDataCtnt4(사용자데이터내용4) : C(3000) <br>
	 * 	usrDataCtnt5(사용자데이터내용5) : C(3000) <br>
	 * 	usrDataCtnt6(사용자데이터내용6) : C(3000) <br>
	 * 	usrDataCtnt7(사용자데이터내용7) : C(3000) <br>
	 * 	usrDataCtnt8(사용자데이터내용8) : C(100) <br>
	 * 	usrDataCtnt9(사용자데이터내용9) : C(100) <br>
	 * 	usrDataCtnt10(사용자데이터내용10) : C(100) <br>
	 * ] <br>
	 * </per>
	 * @return 메시지관리그룹번호
	 * @throws ApplicationException
	 */
	public String insertEmailInfo(List<EmailMsgInfo> emailMsgInfoList) throws ApplicationException {
		
		throw new ApplicationException("APNBE0119", new String[] {"사용하지 않는 SMS모듈입니다!"});
		
		/*
		String msgMgntGrpNo = "";  // 메시지관리그룹번호
		
		for( EmailMsgInfo emailMsgInfo : emailMsgInfoList ) { 
			
			if( StringUtils.isEmpty(msgMgntGrpNo) ) {
			    msgMgntGrpNo = insertEmailInfo(emailMsgInfo); 
			} else {
				insertEmailInfo(msgMgntGrpNo, emailMsgInfo); 
			}
		}
		
		return msgMgntGrpNo;
		*/
	}
	
	
	/**
	 * 이메일 메시지 정보 등록
	 * @param msgMgntGrpNo  메시지관리그룹번호
	 * @param emailMsgInfo  메지시정보
	 * @return 메시지관리번호
	 * @throws ApplicationException
	 */
	private String insertEmailInfo(String msgMgntGrpNoInput, EmailMsgInfo emailMsgInfo) throws ApplicationException {
		String msgMgntGrpNo = msgMgntGrpNoInput;
		
		String prcsObjDcd = emailMsgInfo.getPrcsObjDcd();  // 처리대상구분코드
		
		String msgDcd = BizCommUtil.MSG_DCD_EMAIL;  // 메시지구분코드
		
		String msgMgntNo = "";  // 메시지관리번호
		
		String regDt = emailMsgInfo.getRegDt();  // 등록일자
		
		String regTi = emailMsgInfo.getRegTi();  // 등록시각
		
		int iResult = 0;
		
		logger.debug("emailMsgInfo : {} " , emailMsgInfo);
		
		// 처리대상구분코드가 명시적으로 셋팅하지 않을경우 온라인에서 실행 된 건은 실시간, 배치에서 실행된 건은 대량배치로 처리  
		if( StringUtils.isEmpty(prcsObjDcd) || 
				( !BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME.equals(prcsObjDcd) && !BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH.equals(prcsObjDcd) ) ) {
			if ( LApplicationContext.isOnlineContext() ) {
				prcsObjDcd = BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME;	// 실시간 : R
			} else {
				prcsObjDcd = BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH; 		// 대량배치 : B
			}
		}

		if( StringUtils.isEmpty(regDt))  {	//등록일자가 없을 경우
			regDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		}
		
		if( StringUtils.isEmpty(regTi))  {	//등록일자가 없을 경우
			regTi = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		}
		
		if( StringUtils.isEmpty(emailMsgInfo.getLinalifeSvcId()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(라이나생명서비스ID)" });
		} else if (emailMsgInfo.getLinalifeSvcId().length() > 6) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "라이나생명서비스ID 길이 초과 (6자리이내)" });
		}
		
		if( BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME.equals(prcsObjDcd) && StringUtils.isEmpty(emailMsgInfo.getEcaSvcNo()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(이케어서비스번호)" });
		} else if (BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME.equals(prcsObjDcd) && !StringUtils.isDigit(emailMsgInfo.getEcaSvcNo())) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "이케어서비스번호는 숫자만 가능" });
		}
		
		if( StringUtils.isEmpty(emailMsgInfo.getMsgReceCustRfNo()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(메시지수신고객참조번호)" });
		}
		
		if( StringUtils.isEmpty(emailMsgInfo.getMsgReceCustNm())  ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(메시지수신고객명)" });
		} else if (BizCommUtil.getStringToByteLen(emailMsgInfo.getMsgReceCustNm(), "KSC5601") > 40) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "메시지수신고객명 길이초과 (40byte까지 가능)" });
		}
		
		if( StringUtils.isEmpty(emailMsgInfo.getReceCustEmailMpno()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(수신고객이메일)" });
		} else if (!StringUtils.isFormattedString(emailMsgInfo.getReceCustEmailMpno(), StringUtils.EMAIL_ADDRESS_PATTERN)) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "수신고객이메일 항목이 이메일주소 형식에 맞지 않음" });
		}
		
		if( StringUtils.isEmpty(emailMsgInfo.getSndEmplEmailTelno())) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(발송사원이메일)" });
		} else if (!StringUtils.isFormattedString(emailMsgInfo.getSndEmplEmailTelno(), StringUtils.EMAIL_ADDRESS_PATTERN)) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "발송사원이메일 항목이 이메일주소 형식에 맞지 않음" });
		}
		
		// 보안이메일구분값 : 보안이메일일 경우 보안키자릿수, 보안키값 필수
		if ( BizCommUtil.SECU_EMAIL_DVSN_VL_SECURITY.equals(emailMsgInfo.getSecuEmailDvsnVl()) ) {
			if( emailMsgInfo.getSecuKeyCper() == null || emailMsgInfo.getSecuKeyCper() <= 0 ){
				throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(보안이메일일 경우 보안키자릿수)" });
			}
			
			if( StringUtils.isEmpty(emailMsgInfo.getSecuKeyVl()) ) {
				throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(보안이메일일 경우 보안키값)" });
			}
		} else {
			emailMsgInfo.setSecuEmailDvsnVl(BizCommUtil.SECU_EMAIL_DVSN_VL_NONSECURITY);
		}
		
		if( StringUtils.isEmpty(emailMsgInfo.getUsrBigQtyDataCtnt()) ) {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "필수항목 누락(사용자대량데이터내용)" });
		}	

		if( emailMsgInfo.getMsgDataLen() == null ) {
			// 메시지데이터길이 계산
			
			int msgDataLen = BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrBigQtyDataCtnt(), "KSC5601");
			
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt2(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt3(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt4(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt5(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt6(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt7(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt8(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt9(), "KSC5601");
			msgDataLen += BizCommUtil.getStringToByteLen(emailMsgInfo.getUsrDataCtnt10(), "KSC5601");
			
			emailMsgInfo.setMsgDataLen(msgDataLen);
			
			logger.debug( "msgDataLen : {} " , msgDataLen );
		} 
		
		
		if( StringUtils.isEmpty(emailMsgInfo.getSndEno()) ) {
			// 발송사원번호
			emailMsgInfo.setSndEno(FwUtil.getUserId());
		}
		
		if( StringUtils.isEmpty(emailMsgInfo.getSndOrgNo()) ) {
			// 발송조직번호
			emailMsgInfo.setSndOrgNo(FwUtil.getDeptCd());
		}
		
		// 메시지관리번호 채번
		msgMgntNo = this.cma004bean.getNewComnMknoNoAll( SYS_DCD + prcsObjDcd  +  msgDcd , 12);
		
		if( StringUtils.isEmpty(msgMgntGrpNo) ){
			// 메시지관리그룹번호
			msgMgntGrpNo = msgMgntNo;
		}
		
		logger.debug( "메시지관리번호 채번 msgMgntNo : {} " , msgMgntNo );
		
		if( !StringUtils.isEmpty(msgMgntNo) ) {
		
			TBCMCCD014Io tbcmccd014io = new TBCMCCD014Io();
			
			tbcmccd014io.setMsgMgntNo(msgMgntNo); 									// 메시지관리번호
			tbcmccd014io.setMsgDcd(msgDcd); 										// 메시지구분코드
			tbcmccd014io.setMsgMgntGrpNo(msgMgntGrpNo); 		     				// 메시지관리그룹번호
			tbcmccd014io.setRegDt(regDt); 		     									// 등록일자
			tbcmccd014io.setRegTi(regTi); 		     									// 등록시간
			tbcmccd014io.setLinalifeSvcId(emailMsgInfo.getLinalifeSvcId()); 			// KDB생명서비스ID
			tbcmccd014io.setEcaSvcNo(emailMsgInfo.getEcaSvcNo()); 					// 이케어서비스번호
			tbcmccd014io.setSndEno(emailMsgInfo.getSndEno()); 						// 발송사원번호
			tbcmccd014io.setSndOrgNo(emailMsgInfo.getSndOrgNo()); 					// 발송조직번호
			tbcmccd014io.setMsgReceCustRfNo(emailMsgInfo.getMsgReceCustRfNo()); 	// 메시지수신고객참조번호
			tbcmccd014io.setMsgReceCustNm(emailMsgInfo.getMsgReceCustNm()); 		// 메시지수신고객명
			tbcmccd014io.setReceCustEmailMpno(emailMsgInfo.getReceCustEmailMpno()); // 수신고객이메일휴대전화번호
			tbcmccd014io.setSndEmplEmailTelno(emailMsgInfo.getSndEmplEmailTelno()); // 발송사원이메일전화번호
			tbcmccd014io.setSecuEmailDvsnVl(emailMsgInfo.getSecuEmailDvsnVl());		// 보안이메일구분값
			tbcmccd014io.setSecuKeyCper(emailMsgInfo.getSecuKeyCper());				// 보안키자릿수
		    tbcmccd014io.setSecuKeyVl(emailMsgInfo.getSecuKeyVl());					// 보안키값
			tbcmccd014io.setMsgDataLen(emailMsgInfo.getMsgDataLen()); 				// 메시지데이터길이
			tbcmccd014io.setUsrBigQtyDataCtnt(emailMsgInfo.getUsrBigQtyDataCtnt()); // 사용자대량데이터내용
			tbcmccd014io.setUsrDataCtnt2(emailMsgInfo.getUsrDataCtnt2()); 			// 사용자데이터내용2
			tbcmccd014io.setUsrDataCtnt3(emailMsgInfo.getUsrDataCtnt3()); 			// 사용자데이터내용3
			tbcmccd014io.setUsrDataCtnt4(emailMsgInfo.getUsrDataCtnt4()); 			// 사용자데이터내용4
			tbcmccd014io.setUsrDataCtnt5(emailMsgInfo.getUsrDataCtnt5()); 			// 사용자데이터내용5
			tbcmccd014io.setUsrDataCtnt6(emailMsgInfo.getUsrDataCtnt6());	 		// 사용자데이터내용6
			tbcmccd014io.setUsrDataCtnt7(emailMsgInfo.getUsrDataCtnt7()); 			// 사용자데이터내용6
			tbcmccd014io.setUsrDataCtnt8(emailMsgInfo.getUsrDataCtnt8()); 			// 사용자데이터내용8
			tbcmccd014io.setUsrDataCtnt9(emailMsgInfo.getUsrDataCtnt9()); 			// 사용자데이터내용9
			tbcmccd014io.setUsrDataCtnt10(emailMsgInfo.getUsrDataCtnt10()); 		// 사용자데이터내용10
			tbcmccd014io.setLastChgrId(FwUtil.getUserId()); 						// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcmccd014io.setLastChgPgmId(FwUtil.getPgmId()); 						// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcmccd014io.setLastChgTrmNo(FwUtil.getTrmNo()); 						// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			SecuUtil.doEncObject(tbcmccd014io); // 객체암호화
			
			//YYC 인프라 협의후 진행 2016.05.26
			/*
			if (BizCommUtil.MSG_PRCS_OBJ_DCD_REAL_TIME.equals(prcsObjDcd)) {
				iResult = this.cma201dbio.insertOneTBCMCCD014(tbcmccd014io);
			}
			else if (BizCommUtil.MSG_PRCS_OBJ_DCD_BATCH.equals(prcsObjDcd)) {
				iResult = this.cma201dbio.insertOneTBCMCCD022(tbcmccd014io);
			}
			*/
			
			logger.debug( "iResult : {} " , iResult );
			
		} else {
			// KIERE0005 입력하신 내용을 저장 할 수 없습니다. {0}으로 저장 할 수 없습니다.
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "메시지관리번호채번오류" });
		}
		
		return msgMgntNo;
	}

}

