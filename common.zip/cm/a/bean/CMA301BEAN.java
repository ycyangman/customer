package cigna.cm.a.bean;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import cigna.cm.a.dbio.CMA301DBIO;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import sun.misc.BASE64Encoder;


/**
 * @file         cigna.cm.a.bean.CMA301BEAN.java
 * @filetype     java source file
 * @brief        사원번호, 비밀번호 체크 빈
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박경화                     2013. 2. 13.       신규 작성
 *
 */
/**
 * 
 * 사원번호, 비밀번호 체크하기 위한 KlafBean class
 *
 */
@KlafBean
public class CMA301BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 비상로그인관리 DBIO
	 */	
	@Autowired
	private CMA301DBIO cma301dbio; 
	
	/**
	 * <pre>
	 * 사원번호, 비밀번호 체크
	 * </pre>
	 * @param eno 사원번호
	 * @param pswd 비밀번호
	 * @return 사원번호,비밀번호 체크가 정상이면 true, 그렇지 않으면 false
	 * @throws ApplicationException
	 */
	public boolean isPasswordCheck(String eno, String pswd) throws ApplicationException {

		boolean isPasswordCheck = false;
		
		logger.debug( "사원번호 = {}, 비밀번호 = {}" , eno, pswd );
		
		if( StringUtils.isEmpty(eno) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		if( StringUtils.isEmpty(pswd) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "비밀번호" });
		}
		
		String ssoPswd = cma301dbio.selectOneTBCMCCD021(eno);
		
		logger.info( "ssoPswd = {}, SecuUtil.getEncPasswd(pswd) = {}" , ssoPswd, SecuUtil.getEncPasswd(pswd) );
		
		if (SecuUtil.getEncPasswd(pswd).equals(ssoPswd)) {
			// 비밀번호 일치
			isPasswordCheck = true;
		} 
		
		logger.info( "isPasswordCheck = {}" , isPasswordCheck );
		
		// 개발서버라면 무조건 true로 반환한다
		if (FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) {
			return true;
		}
		
		return isPasswordCheck;
		
	}
	
	/**
	 * <pre>
	 * 설계사 체크
	 * </pre>
	 * @param eno 사원번호
	 * @param pswd 비밀번호
	 * @return 사원번호,비밀번호 체크가 정상이면 true, 그렇지 않으면 false
	 * @throws ApplicationException
	 */
	public String isPlnrCheck(String eno, String pswd) throws ApplicationException {

		String isPlnrCheck = "X";
		
		logger.debug( "사원번호 = {}, 비밀번호 = {}" , eno, pswd );
		
		if( StringUtils.isEmpty(eno) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		if( StringUtils.isEmpty(pswd) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "비밀번호" });
		}
		
		String ssoPswd = cma301dbio.selectOneTBCMCCD021(eno);
		
		logger.debug( "ssoPswd = {}, getSHA256(pswd) = {}" , ssoPswd, getSHA256(pswd) );
		
		if(ssoPswd != null){
			
			logger.debug( "ssoPswdEtc  = {}" , SecuUtil.getDecValue(ssoPswd, SecuUtil.EncType.Etc) );
			logger.debug( "ssoPswdPswd = {}" , SecuUtil.getDecValue(ssoPswd, SecuUtil.EncType.pswd) );
			
			if (getSHA256(pswd).equals(ssoPswd)) {
				// 비밀번호 일치
				isPlnrCheck = "Y";
			}else{
				// 비밀번호 비일치
				isPlnrCheck = "N";				
			}
		}
		
		logger.debug( "isPlnrCheck = {}" , isPlnrCheck );
		
		return isPlnrCheck;
		
	}	
	
    /**
     * sha-256알고리즘으로 단방향암호화 후 base64 인코딩된 값을 얻는다.
     * @param input SHA-256
     * @return OUTPUT SHA-256 BASE64 
     * @throws ApplicationException
     */
	@SuppressWarnings("finally")
	private String getSHA256(String input) throws ApplicationException {
		
		String res ="";
		
		try{
			MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
			
			sha256.update(input.getBytes());
			byte[] sha256Byte = sha256.digest();
			res = new BASE64Encoder().encode(sha256Byte);
			
		} catch(NoSuchAlgorithmException e) {
			
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[NoSuchAlgorithmException] 비밀번호 복호화 중 에러발생" }, e );
			
		} catch(Exception e) {	
			
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[Exception] 비밀번호 복호화 중 에러발생" }, e );
		}			
		
		return res;		
			
	}
}

