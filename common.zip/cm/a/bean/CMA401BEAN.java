package cigna.cm.a.bean;

import java.util.List;

import cigna.cm.a.dbio.CMA201DBIO;
import cigna.cm.a.dbio.CMA401DBIO;
import cigna.cm.a.domain.SmsMsgInfo;
import cigna.cm.a.io.CMA401SVC00In;
import cigna.cm.a.io.CMA401SVC02In;
import cigna.cm.a.io.CMA401SVC03In;
import cigna.cm.a.io.CMA401SVC04In;
import cigna.cm.a.io.CMA401SVC04Sub;
import cigna.cm.a.io.TBCMCCD010Io;
import cigna.cm.a.io.TBCMCCD011Io;
import cigna.cm.a.io.TBCMCCD013Io;
import cigna.zz.BizCommUtil;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file         cigna.cm.a.bean.CMA401BEAN.java
 * @filetype     java source file
 * @brief        결함관리 BEAN
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1               박경화                 2012. 9.17.       신규 작성
 * 0.6               박경화                 2012. 9.27.       개발 완료
 * 0.9               박경화                 2012. 9.28.       Class 테스트
 * 1.0               박경화                 2012. 9.28.       단위 테스트 
 */
@KlafBean
public class CMA401BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * 결함관리 DBIO
	 */	
	@Autowired
	private CMA401DBIO cma401dbio; 	
	
	/**
	 * 채번관련 BEAN
	 */	
	@Autowired
	private CMA004BEAN cma004bean; 
	
	/**
	 * 파일관리 빈
	 */
	@Autowired
	private CMA005BEAN cma005bean;
	
	/**
	 * 메시지관리 DBIO
	 */	
	@Autowired
	private CMA201DBIO cma201dbio; 
	
	/** 결함관리번호 채번구분코드 */
	private static final String DFCT_MGNT_NO_MKNO_DCD = "D";
	
	/** 결함상태코드 : 조치완료 */
	private static final String DFCT_STCD_TRTM_CMPT = "001";
	
	/** SMS 발송여부  : Y */
	private static final String SMS_SND_Y = "Y";
	
	/**
	 * 결함관리 조회
	 * @param input 결함관리 조회조건
	 * @return List<TBCMCCD010Io> 결함관리 목록
	 * @throws ApplicationException 
	 */
	public List<TBCMCCD010Io> getDfctList(CMA401SVC00In input) throws ApplicationException {
		
		String inqStrtDt = input.getInqStrtDt();
		String inqEndDt  = input.getInqEndDt();
		
		String dfctPrfRnkCd  = input.getDfctPrfRnkCd();
		
		String expStrtDt = input.getExpStrtDt();
		String expEndDt = input.getExpEndDt();
		
		int iPageNum = input.getPageNum();
		int iPageCount = input.getPageCount();
		
		String inqAuth = input.getInqAuth();
		
		// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
		// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
		boolean bValidFmYmd = DateUtils.isValidDate(inqStrtDt, DateUtils.EMPTY_DATE_TYPE);
		if ( !bValidFmYmd ) {throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
		
		boolean bValidToYmd = DateUtils.isValidDate(inqEndDt, DateUtils.EMPTY_DATE_TYPE);
		if ( !bValidToYmd ) {throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
		
		
		if ( Integer.parseInt(inqStrtDt) > Integer.parseInt(inqEndDt) ) {
			//  APCME0006 : 적용종료일자는 적용시작일자보다 크거나 같아야 합니다. 
			throw new ApplicationException("APCME0006", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), inqEndDt, inqStrtDt } );
		}
		
		List<TBCMCCD010Io> dfctList = null; 
		
		logger.debug( "inqAuth : {} " , inqAuth );
		
		if("D".equals(inqAuth)){
			dfctList = this.cma401dbio.selectMultiTBCMCCD010a(input, dfctPrfRnkCd, expStrtDt, expEndDt, iPageNum, iPageCount);
		}else{
			dfctList = this.cma401dbio.selectMultiTBCMCCD010(input, dfctPrfRnkCd, expStrtDt, expEndDt, iPageNum, iPageCount);
		}
		
		SecuUtil.doDecList(dfctList);
			
		
		
		return dfctList;
		
	}
	
	/**
	 * 결함관리 이력 조회
	 * @param dfctMgntNo 결함관리 번호
	 * @return List<TBCMCCD011Io> 결함관리 이력 목록
	 * @throws ApplicationException
	 */
	public List<TBCMCCD011Io> getDfctHisList(String dfctMgntNo) throws ApplicationException {
		
		if( StringUtils.isEmpty(dfctMgntNo)){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "결함관리번호" });
		}
		
		List<TBCMCCD011Io> dfctHisList = this.cma401dbio.selectMultiTBCMCCD011(dfctMgntNo);
		
		return dfctHisList;
		
	}
	
	/**
	 * 결함관리 이미지 조회
	 * @param dfctMgntNo 결함관리 번호
	 * @return byte[] 결함관리 이미지
	 * @throws ApplicationException
	 */
	public TBCMCCD013Io getDfctImgCtnt(String dfctMgntNo) throws ApplicationException {
		
		if( StringUtils.isEmpty(dfctMgntNo)){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "결함관리번호" });
		}
		
		TBCMCCD013Io tbcmccd013io = this.cma401dbio.selectOneTBCMCCD013(dfctMgntNo);
		
		return tbcmccd013io;
		
	}
	
	/**
	 * 결함관리 등록
	 * @param input 결함관리, 결함관리이력 정보
	 * @return dfctMgntNo 결함관리번호
	 * @throws ApplicationException
	 */
	public String insertDfctInto(CMA401SVC02In input) throws ApplicationException {
		
		TBCMCCD010Io dfctInfo = input.getDfctList().get(0);
		
		if( dfctInfo == null ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", null, new Object[]{ "결함관리" , "변경된 내용 없음" });
		}
		
		String dfctMgntNo = this.cma004bean.getNewComnMknoNoYy(DFCT_MGNT_NO_MKNO_DCD, 5);
		
		dfctInfo.setDfctMgntNo(dfctMgntNo);
		
		dfctInfo.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		dfctInfo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		dfctInfo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		SecuUtil.doEncObject(dfctInfo);
		int iCnt = this.cma401dbio.insertOneTBCMCCD010(dfctInfo);
		
		if (iCnt == 1) {
			
			// 결함이미지내용
			byte[] dfctImgCtnt = input.getDfctImgCtnt() ;
			
			if ( dfctImgCtnt != null && dfctImgCtnt.length > 0 ) {
			
				TBCMCCD013Io dfctBtchInfo = new TBCMCCD013Io();
				
				dfctBtchInfo.setDfctMgntNo(dfctMgntNo);	         // 결함관리번호
				dfctBtchInfo.setDfctImgCtnt(dfctImgCtnt);        // 결함이미지내용
				dfctBtchInfo.setLastChgrId(FwUtil.getUserId());  // 최종변경자ID(LAST_CHGR_ID) 설정
				dfctBtchInfo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
				dfctBtchInfo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
				
				this.cma401dbio.insertOneTBCMCCD013(dfctBtchInfo);
			}
			
			TBCMCCD011Io dfctHisInfo = new TBCMCCD011Io();
			
			dfctHisInfo.setDfctMgntNo(dfctInfo.getDfctMgntNo());	        // 결함관리번호
			dfctHisInfo.setDfctCtnt(dfctInfo.getDfctCtnt());	            // 결함내용
			dfctHisInfo.setDfctCausCtnt(dfctInfo.getDfctCausCtnt());	    // 결함원인내용
			dfctHisInfo.setDfctPrcsRstCtnt(dfctInfo.getDfctPrcsRstCtnt());  // 결함처리결과내용
			dfctHisInfo.setRegEno(dfctInfo.getRegEno());	                // 등록사원번호
			dfctHisInfo.setRegDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	  // 등록일자
			dfctHisInfo.setReqPrcsHopeDt(dfctInfo.getReqPrcsHopeDt());	    // 요청처리희망일자
			dfctHisInfo.setDfctPrcsExpDt(dfctInfo.getDfctPrcsExpDt());	    // 결함처리예정일자
			dfctHisInfo.setDfctStcd(dfctInfo.getDfctStcd());	            // 결함상태코드
			dfctHisInfo.setDfctTpcd(dfctInfo.getDfctTpcd());	            // 결함유형코드
			dfctHisInfo.setLastChgrId(FwUtil.getUserId()); 					// 최종변경자ID(LAST_CHGR_ID) 설정
			dfctHisInfo.setLastChgPgmId(FwUtil.getPgmId());					// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			dfctHisInfo.setLastChgTrmNo(FwUtil.getTrmNo()); 				// 최종변경단말번호(LAST_CHG_TRM_NO) 설정 
			
			this.cma401dbio.insertOneTBCMCCD011(dfctHisInfo);
			
			// 첨부파일이 있을 경우 파일관리번호처리여부 저장
			if ( !StringUtils.isEmpty(dfctInfo.getFileMgntNo()) ) {
				this.cma005bean.setFileMgntNoPrcsYn(dfctInfo.getFileMgntNo());
			}
		}

		return dfctMgntNo;
	}
	
	/**
	 * 결함관리 수정
	 * @param input 결함관리, 결함관리이력 정보
	 * @return 수정건수
	 * @throws ApplicationException
	 */
	public int updateDfctInto(CMA401SVC03In input) throws ApplicationException {
		
		TBCMCCD010Io dfctInfo = input.getDfctList().get(0);
		
		if( dfctInfo == null || StringUtils.isEmpty(dfctInfo.getDfctMgntNo()) ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", null, new Object[]{ "결함관리" , "변경된 내용 없음" });
		}
		
		dfctInfo.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		dfctInfo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		dfctInfo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		if (dfctInfo.getChrgpEno() != null && dfctInfo.getChrgpEno().length() > 10) {
			dfctInfo.setChrgpEno(dfctInfo.getChrgpEno().substring(0, 10));
		}
		
		SecuUtil.doEncObject(dfctInfo);
		int iCnt = this.cma401dbio.updateOneTBCMCCD010(dfctInfo);
		
		if (iCnt == 1) {
			TBCMCCD011Io dfctHisInfo = new TBCMCCD011Io();
			
			dfctHisInfo.setDfctMgntNo(dfctInfo.getDfctMgntNo());	        // 결함관리번호
			dfctHisInfo.setDfctCtnt(dfctInfo.getDfctCtnt());	            // 결함내용
			dfctHisInfo.setDfctCausCtnt(dfctInfo.getDfctCausCtnt());	    // 결함원인내용
			dfctHisInfo.setDfctPrcsRstCtnt(dfctInfo.getDfctPrcsRstCtnt());  // 결함처리결과내용
			dfctHisInfo.setRegEno(FwUtil.getUserId());	                    // 등록사원번호
			dfctHisInfo.setRegDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	  // 등록일자
			dfctHisInfo.setReqPrcsHopeDt(dfctInfo.getReqPrcsHopeDt());	    // 요청처리희망일자
			dfctHisInfo.setDfctPrcsExpDt(dfctInfo.getDfctPrcsExpDt());	    // 결함처리예정일자
			dfctHisInfo.setDfctStcd(dfctInfo.getDfctStcd());	            // 결함상태코드
			dfctHisInfo.setDfctTpcd(dfctInfo.getDfctTpcd());	            // 결함유형코드
			dfctHisInfo.setLastChgrId(FwUtil.getUserId()); 					// 최종변경자ID(LAST_CHGR_ID) 설정
			dfctHisInfo.setLastChgPgmId(FwUtil.getPgmId()); 				// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			dfctHisInfo.setLastChgTrmNo(FwUtil.getTrmNo()); 				// 최종변경단말번호(LAST_CHG_TRM_NO) 설정 
			
			// TODO 임시 테스트기간동안
			if (!StringUtils.isEmpty(dfctInfo.getTestDfctUserId())) {
				dfctHisInfo.setRegEno(dfctInfo.getTestDfctUserId());	        // 등록사원번호
			}
			
			this.cma401dbio.insertOneTBCMCCD011(dfctHisInfo);
			
			// 첨부파일이 있을 경우 파일관리번호처리여부 저장
			if ( "Y".equals(dfctInfo.getFileNewYn()) && !StringUtils.isEmpty(dfctInfo.getFileMgntNo()) ) {
				this.cma005bean.setFileMgntNoPrcsYn(dfctInfo.getFileMgntNo());
			}
		}

		// SMS 발송
		if (SMS_SND_Y.equals(dfctInfo.getSmsSndYn()) && DFCT_STCD_TRTM_CMPT.equals(dfctInfo.getDfctStcd())) {
			
			String dfctMgntNo     = dfctInfo.getDfctMgntNo();
			String dfctTitlNm     = dfctInfo.getDfctTitlNm();
			String dfctRegEno     = dfctInfo.getRegEno();
			String dfctRegEnoNm   = dfctInfo.getRegEnoNm();
			String dfctRegOrgNo   = dfctInfo.getRegOrgNo();
			String dfctChrgpEno   = dfctInfo.getChrgpEno();
			String dfctChrgpEnoNm = dfctInfo.getChrgpEnoNm();
			String dfctChrgpOrgNo = dfctInfo.getChrgpOrgNo();
			
			String dfctRegpTel    = dfctInfo.getDfctRegpTeldno();
			dfctRegpTel          += dfctInfo.getDfctRegpTelsno(); 
			dfctRegpTel          += SecuUtil.getDecValue(dfctInfo.getDfctRegpTelino(), SecuUtil.EncType.Contact);
			
			String dfctChrgpTel   = dfctInfo.getDfctChrgpTeldno();
			dfctChrgpTel         += dfctInfo.getDfctChrgpTelsno();
			dfctChrgpTel         += SecuUtil.getDecValue(dfctInfo.getDfctChrgpTelino(), SecuUtil.EncType.Contact);
			
			if ( !BizCommUtil.isValidTelno(dfctChrgpTel) ) { 
				throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "담당자연락처" , "전화번호"});
			}
			
			if ( !BizCommUtil.isValidMpno(dfctRegpTel) ) { 
				throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "등록자연락처" , "휴대전화번호"});
			}
			
			if (dfctTitlNm.length() > 10) dfctTitlNm = dfctInfo.getDfctTitlNm().substring(0,10);
			
			logger.debug("dfctMgntNo={}",     dfctMgntNo);
			logger.debug("dfctTitlNm={}",     dfctTitlNm);
			logger.debug("dfctRegEno={}",     dfctRegEno);
			logger.debug("dfctRegEnoNm={}",   dfctRegEnoNm);
			logger.debug("dfctRegOrgNo={}",   dfctRegOrgNo);
			logger.debug("dfctRegpTel={}",    dfctRegpTel);
			logger.debug("dfctChrgpEno={}",   dfctChrgpEno);
			logger.debug("dfctChrgpEnoNm={}", dfctChrgpEnoNm);
			logger.debug("dfctChrgpOrgNo={}", dfctChrgpOrgNo);
			logger.debug("dfctChrgpTel={}",   dfctChrgpTel);
			
			String sendText = "결함번호 "+ dfctMgntNo + " "+ dfctTitlNm + "이 조치완료 되었습니다.";
			
			logger.debug("SMS메시지={}",sendText);
			
			String dfctRegCustNo = cma201dbio.selectOneTBCSPRF001b(dfctRegEno);
			
			logger.debug( "dfctRegCustNo : {} " , dfctRegCustNo );
			
			if (!StringUtils.isEmpty(dfctRegCustNo) ) {
			
				SmsMsgInfo smsmsginfo = new SmsMsgInfo();
				
				smsmsginfo.setMsgDcd(BizCommUtil.MSG_DCD_SMS); 	// 메시지구분코드 (MSG_DCD_SMS : S, MSG_DCD_LMS : L) [필수]
				smsmsginfo.setLinalifeSvcId("CL2016"); 			// KDB생명서비스ID [필수]
				smsmsginfo.setEcaSvcNo("83"); 					// 이케어서비스번호 [필수]
				smsmsginfo.setSndEno(dfctChrgpEno); 		    // 발송사원번호 [필수]
				smsmsginfo.setSndOrgNo(dfctChrgpOrgNo); 	    // 발송조직번호 [필수]
				smsmsginfo.setMsgReceCustRfNo(dfctRegCustNo); 	// 메시지수신고객참조번호 [필수]
				smsmsginfo.setMsgReceCustNm(dfctRegEnoNm); 		// 메시지수신고객명 [필수]
				smsmsginfo.setReceCustEmailMpno(dfctRegpTel);	// 수신고객이메일휴대전화번호 [필수]
				smsmsginfo.setSndEmplEmailTelno(dfctChrgpTel);  // 발송사원이메일전화번호 [필수]
				smsmsginfo.setUsrBigQtyDataCtnt(sendText); 			// 사용자데이터내용1 [필수]
				
				// TODO SMS발송
				// 메시지관리번호
				//String msgMgntNo = cma201bean.insertSmsInfo(smsmsginfo);
				
				//logger.debug( "msgMgntNo : {} " , msgMgntNo );
			}
		}

		return iCnt;
	}
	
	
	/**
	 * 결함관리 일괄처리
	 * @param input 결함관리 일괄처리 정보, 결함관리이력 정보
	 * @return 건수
	 * @throws ApplicationException
	 */
	public int updateDfctBtchList(CMA401SVC04In input) throws ApplicationException {
		
		int iCnt = 0;
				
		if( input.getDfctBtchList() == null || input.getDfctBtchList().size() <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", null, new Object[]{ "결함관리일관처리" , "변경된 내용 없음" });
		}
		
		for( CMA401SVC04Sub dfctBtchInfo : input.getDfctBtchList() ) {
		
			// 결함관리 수정
			
			TBCMCCD010Io dfctInfo = new TBCMCCD010Io();
			
			dfctInfo.setDfctMgntNo(dfctBtchInfo.getDfctMgntNo());   // 결함관리번호
			dfctInfo.setChrgpEno(dfctBtchInfo.getChrgpEno());       // 담당자사원번호
			dfctInfo.setChrgpOrgNo(dfctBtchInfo.getChrgpOrgNo());   // 담당자조직번호
			dfctInfo.setDfctStcd(dfctBtchInfo.getDfctStcd());       // 결함상태코드
			dfctInfo.setDfctTpcd(dfctBtchInfo.getDfctTpcd());       // 결함유형코드
			dfctInfo.setDfctPrfRnkCd(dfctBtchInfo.getDfctPrfRnkCd());       // 결함우선순위코드
			dfctInfo.setLastChgrId(FwUtil.getUserId());         	// 최종변경자ID(LAST_CHGR_ID) 설정
			dfctInfo.setLastChgPgmId(FwUtil.getPgmId());        	// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			dfctInfo.setLastChgTrmNo(FwUtil.getTrmNo());        	// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			SecuUtil.doEncObject(dfctInfo);
			iCnt += this.cma401dbio.updateOneTBCMCCD010(dfctInfo);
			
			// 결함관리 이력등록
			
			TBCMCCD011Io dfctHisInfo = new TBCMCCD011Io();
			
			dfctHisInfo.setDfctMgntNo(dfctBtchInfo.getDfctMgntNo());	               // 결함관리번호
			dfctHisInfo.setDfctCtnt(dfctBtchInfo.getDfctCtnt());	                   // 결함내용
			dfctHisInfo.setDfctPrcsRstCtnt(dfctBtchInfo.getDfctPrcsRstCtnt());         // 결함처리결과내용
			dfctHisInfo.setRegEno(FwUtil.getUserId());	                               // 등록사원번호
			dfctHisInfo.setRegDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)); // 등록일자
			dfctHisInfo.setDfctStcd(dfctBtchInfo.getDfctStcd());	                   // 결함상태코드
			dfctHisInfo.setDfctTpcd(dfctBtchInfo.getDfctTpcd());	                   // 결함유형코드
			dfctHisInfo.setReqPrcsHopeDt(dfctBtchInfo.getReqPrcsHopeDt());	           // 요청처리희망일자
			dfctHisInfo.setDfctPrcsExpDt(dfctBtchInfo.getDfctPrcsExpDt());	           // 결함처리예정일자
			dfctHisInfo.setLastChgrId(FwUtil.getUserId()); 							   // 최종변경자ID(LAST_CHGR_ID) 설정
			dfctHisInfo.setLastChgPgmId(FwUtil.getPgmId()); 						   // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			dfctHisInfo.setLastChgTrmNo(FwUtil.getTrmNo());                            // 최종변경단말번호(LAST_CHG_TRM_NO) 설정 
			
			// TODO 임시 테스트기간동안
			if (!StringUtils.isEmpty(dfctBtchInfo.getTestDfctUserId())) {
				dfctHisInfo.setRegEno(dfctBtchInfo.getTestDfctUserId());	        // 등록사원번호
			}
			
			this.cma401dbio.insertOneTBCMCCD011(dfctHisInfo);
		}

		return iCnt;
	}
	
}

