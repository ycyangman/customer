package cigna.cm.a.bean;

import java.util.List;

import cigna.cm.a.dbio.CMA501DBIO;
import cigna.cm.a.io.CMA501SVC01In;
import cigna.cm.a.io.CMA501SVC04In;
import cigna.cm.a.io.CMA501SVC04Out;
import cigna.cm.a.io.CMA501SVC06In;
import cigna.cm.a.io.CMA501SVC08In;
import cigna.cm.a.io.SelectMultiTBCMCCD025Out;
import cigna.cm.a.io.SelectMultiTBCMCCD026Out;
import cigna.cm.a.io.SelectMultiTBCMCCD035aOut;
import cigna.cm.a.io.SelectMultiTBCMCCD037Out;
import cigna.cm.a.io.SelectMultiTBCMCCD038Out;
import cigna.cm.a.io.TBCMCCD035Io;
import cigna.cm.a.io.TBCMCCD036Io;
import cigna.cm.a.io.TBCMCCD037Io;
import cigna.cm.a.io.TBCMCCD038Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.bean.CMA501BEAN.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2013. 8. 6.       신규 작성
 *
 */
@KlafBean
public class CMA501BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA501DBIO cma501dbio;
	
	/**
	 * 채번관련 BEAN
	 */	
	@Autowired
	private CMA004BEAN cma004bean;
	
	
	/** SSO비밀번호초기화 신청 채번구분코드 */
	private static final String PSWD_MGNT_NO_MKNO_DCD = "PW";

	/** 가상사원번호 신청 채번구분코드 */
	private static final String SPST_MGNT_NO_MKNO_DCD = "SP";
	
	/**
	 * 사원권한신청 저장
	 * @param in CMA501SVC01In -> List<SelectMultiTBCMCCD035aOut> 사원권한신청 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW)	
	public int modifyEmplAuthApplList (CMA501SVC01In input) throws ApplicationException {
		
		TBCMCCD035Io emplRoleApplList = input.getEmplRoleApplList();	//사원권한신청 정보

		List<TBCMCCD036Io> emplRoleInfoList = input.getEmplRoleInfoList();	//사원권한신청 상세역할정보
		
		//1. 필수입력값체크
		if( emplRoleApplList == null ){
		    // 입력값 오류처리
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원권한신청" });
		}
		
		Integer sysEmplRoleApplNo;
		//신청번호 채번
		sysEmplRoleApplNo = cma501dbio.selectOneTBCMCCD035();
		
		// Table에 Insert / Update할 경우에 반드시 설정해야 할 Audit Column들을 설정.
		emplRoleApplList.setSysEmplRoleApplNo(sysEmplRoleApplNo); // 신청번호 설정
		emplRoleApplList.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		emplRoleApplList.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		emplRoleApplList.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		//2. 사원권한신청 정보 저장
		cma501dbio.insertOneTBCMCCD035(emplRoleApplList); 

		if( sysEmplRoleApplNo == 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "권한신청일자" });
		}
		
		if(emplRoleInfoList != null) {
			//2. 사원권한신청상세역할 정보 저장
			for( TBCMCCD036Io emplRoleInfo : emplRoleInfoList ){ 
				logger.debug("emplRoleInfo={}", emplRoleInfo);
				// Table에 Insert / Update할 경우에 반드시 설정해야 할 Audit Column들을 설정.
				emplRoleInfo.setSysEmplRoleApplNo(sysEmplRoleApplNo); //사원권한신청시퀀스번호
				emplRoleInfo.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
				emplRoleInfo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
				emplRoleInfo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
				
				cma501dbio.insertOneTBCMCCD036(emplRoleInfo); 
			}
		}

		return sysEmplRoleApplNo;
	}

	/**
	 * 사원권한신청 목록 조회
	 * @param scrnNo 화면번호
	 * @return List<SelectMultiTBCMCCD035aOut> 사원권한신청 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMCCD035aOut> getEmplRoleApplList(String roleAdptEno, String applStrtDt, String applEndDt, String applEno, String orgNo, String roleAdptDt)	throws ApplicationException {
		
		//1. 필수입력값체크
		if (StringUtils.isEmpty(applStrtDt) || StringUtils.isEmpty(applEndDt)) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "권한신청일자" });
		} 

		//2. 화면연결정보 조회
		List<SelectMultiTBCMCCD035aOut> emplRoleApplList = this.cma501dbio.selectMultiTBCMCCD035a(roleAdptEno, applStrtDt, applEndDt, applEno, orgNo, roleAdptDt);
		
		return emplRoleApplList;
	}
	
	
	/**
	 * 시스템역할목록 조회
	 * 
	 * @param roleDscNo
	 * @param roleNm
	 * @return List<SelectMultiTBCMCCD025Out> 시스템역할목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMCCD025Out> getRoleInfoList(String roleNm) throws ApplicationException {
		
		// 1. 시스템역할목록 조회
		List<SelectMultiTBCMCCD025Out> roleInfoList = this.cma501dbio.selectMultiTBCMCCD025a(roleNm);
		
		return roleInfoList;
	}
	
	/**
	 * 시스템역할별서비스목록 조회
	 * 
	 * @param roleDscNo
	 * @return List<SelectMultiTBCMCCD026Out> 시스템역할별서비스 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMCCD026Out> getRoleDetailList(String roleDscNo) throws ApplicationException {
		
		// 1. 시스템역할별서비스목록 조회
		List<SelectMultiTBCMCCD026Out> roleDetailList = this.cma501dbio.selectMultiTBCMCCD026a(roleDscNo);
		
		return roleDetailList;
	}	
	
	/**
	 * SSO비밀번호초기화 신청 목록 조회
	 * @param 
	 * @return List<SelectMultiTBCMCCD035aOut> 비밀번호초기화 신청 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMCCD037Out> getPswdInitlApplList(String pswdInitlObjEno, String applStrtDt, String applEndDt, String applEno, String orgNo)	throws ApplicationException {
		
		//1. 필수입력값체크
		if (StringUtils.isEmpty(applStrtDt) || StringUtils.isEmpty(applEndDt)) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "신청일자" });
		} 

		//2. SSO비밀번호초기화 신청 조회
		List<SelectMultiTBCMCCD037Out> pswdInitlApplList = this.cma501dbio.selectMultiTBCMCCD037(pswdInitlObjEno, applStrtDt, applEndDt, applEno, orgNo);
		
		return pswdInitlApplList;
	}	
	
	/**
	 * SSO비밀번호초기화 저장
	 * @param in CMA501SVC06In -> List<SelectMultiTBCMCCD037Out> SSO비밀번호초기화 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW)	
	public String modifyPswdInitlApplList (CMA501SVC06In input) throws ApplicationException {

		TBCMCCD037Io pswdInitlApplList = input.getPswdInitlApplList();	//SSO비밀번호초기화신청 정보

		//1. 필수입력값체크
		if( pswdInitlApplList == null ){
		    // 입력값 오류처리
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "SSO비밀번호초기화신청" });
		}
		
		// SSO비밀번호초기화 채번
		String ssoPswdInitlApplNo = this.cma004bean.getNewComnMknoNo(PSWD_MGNT_NO_MKNO_DCD, 4);
		
		logger.debug( "신규등록채번 sysPswdInitlApplNo : {} " , ssoPswdInitlApplNo );				
		
		// Table에 Insert / Update할 경우에 반드시 설정해야 할 Audit Column들을 설정.
		pswdInitlApplList.setSsoPswdInitlApplNo(ssoPswdInitlApplNo);// 신청번호 설정
		pswdInitlApplList.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		pswdInitlApplList.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		pswdInitlApplList.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		//2. SSO비밀번호초기화 정보 저장
		cma501dbio.insertOneTBCMCCD037(pswdInitlApplList); 

		return ssoPswdInitlApplNo;

	}
	
	/**
	 * 가상사원번호 신청 목록 조회
	 * @param 
	 * @return List<SelectMultiTBCMCCD038Out> 가상사원번호 신청 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMCCD038Out> getSpstEnoApplList(String spstEmplRrno, String spstEmplNm, String spstEmplBlntOrgNo, String applStrtDt, String applEndDt, String applEno, String orgNo)	throws ApplicationException {
		
		//1. 필수입력값체크
		if (StringUtils.isEmpty(applStrtDt) || StringUtils.isEmpty(applEndDt)) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "신청일자" });
		} 

		//2. 가상사원번호 신청 조회
		List<SelectMultiTBCMCCD038Out> spstEnoApplList = this.cma501dbio.selectMultiTBCMCCD038(SecuUtil.getEncValue(spstEmplRrno, SecuUtil.EncType.Jumin), spstEmplNm, spstEmplBlntOrgNo, applStrtDt, applEndDt, applEno, orgNo);
		
		SecuUtil.doDecList(spstEnoApplList);
		
		return spstEnoApplList;
	}	
	
	/**
	 * 가상사원번호 저장
	 * @param in CMA501SVC08In -> List<SelectMultiTBCMCCD038Out> 가상사원번호 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW)	
	public String modifySpstEnoApplList (CMA501SVC08In input) throws ApplicationException {
		
		TBCMCCD038Io spstEnoApplList = input.getSpstEnoApplList();	//가상사원번호 정보

		//1. 필수입력값체크
		if( spstEnoApplList == null ){
		    // 입력값 오류처리
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "가상사원번호신청" });
		}

		// 가상사원번호신청 채번
		String spstEnoApplNo = this.cma004bean.getNewComnMknoNo(SPST_MGNT_NO_MKNO_DCD, 4);
		
		logger.debug( "신규등록채번 가상사원번호신청 : {} " , spstEnoApplNo );				
		
		spstEnoApplList.setSpstEnoApplNo(spstEnoApplNo);	// 신청번호 설정
		spstEnoApplList.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
		spstEnoApplList.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		spstEnoApplList.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		SecuUtil.doEncObject(spstEnoApplList);
		//2. 가상사원번호신청 정보 저장
		cma501dbio.insertOneTBCMCCD038(spstEnoApplList); 

		return spstEnoApplNo;

	}	
	
	/**
	 * EAI호출
	 */	
	public void getEAITrmsInfo(String interfaceId, String eaiTrmsNo){

		EISResponse <CMA501SVC04Out> response = null;
		CMA501SVC04Out responseData = null;				
		
		CMA501SVC04In request = new CMA501SVC04In(); // Interface request data(OMM)
		
		String eaiApplNo = "key:"+eaiTrmsNo;
		request.setEaiRoleApplNo(eaiApplNo);

		try {
			response = InfUtil.callEAI(request,interfaceId, CMA501SVC04Out.class);
			
			logger.debug("response={}", response);
		    responseData = response.getResponseData();
		    logger.debug("response data:{}", responseData);			
		    
		} catch (Exception e) {
			logger.error("EAI 전송 오류 ", e);
		} 
	}	
}

