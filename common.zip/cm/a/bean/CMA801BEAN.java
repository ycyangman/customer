package cigna.cm.a.bean;

import java.math.BigDecimal;
import java.util.List;

import cigna.cm.a.dbio.CMA801DBIO;
import cigna.cm.a.io.CMA801SVC01In;
import cigna.cm.a.io.SelectMultiTBCMETC003aOut;
import cigna.cm.a.io.SelectMultiTBCMETC004bOut;
import cigna.cm.a.io.SelectMultiTBCMETC005bOut;
import cigna.cm.a.io.TBCMETC003Io;
import cigna.cm.a.io.TBCMETC004Io;
import cigna.cm.a.io.TBCMETC005Io;
import cigna.zz.FwUtil;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.bean.CMA800BEAN.java
 * @filetype     java source file
 * @brief        대외기관 전송 파일을 관리시 현황 조회, 파일 업로드 / 다운로드, 담당자 관리의 기능을 제공하는 BEAN 클래스
 * @author       김정국
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김정국                 2014. 12. 26.       신규 작성
 *
 */
@KlafBean
public class CMA801BEAN {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA005BEAN cma005bean;
	
	@Autowired
	private CMA801DBIO cma801dbio;
	
	/**
	 * 로그인한 사용자의 사원번호를 이용하여 대외기관 전송 파일의 현황을 조회
	 * @param eno 문자열 사원번호
	 * @param pageNum 페이지번호
	 * @param pageCount 페이지건수
	 * @return 대외기관 전송 파일의 현황 리스트
	 * @throws ApplicationException 필수 입력값 사원번호가 없을 경우
	 */
	public List<SelectMultiTBCMETC003aOut> getExtrnInstSendFileStatus(
			final String eno
			, final int pageNum
			, final int pageCount) throws ApplicationException {
		
		logger.debug("대외기관 전송 파일 현황 조회시작");
		logger.debug("사원번호:[{}] 페이지번호:[{}] 페이지건수:[{}]", new Object[]{eno, pageNum, pageCount});

		//입력값 체크
		if(StringUtils.isEmpty(eno))
			throw new ApplicationException("APCME0008", new String[]{"사원번호"});
		
		//파일관리 현황 조회
		List<SelectMultiTBCMETC003aOut> fileList = cma801dbio.selectMultiTBCMETC003a(pageNum, pageCount, eno);
		
		logger.debug("대외기관 전송 파일현황 조회결과 건수:[{}]", fileList != null ? fileList.size() : 0);
		
		return fileList;
		
	}
	
	/**
	 * 세부업무와 담당자 정보를 저장
	 * @param intput 세부업무 및 담당자 정보
	 * @return 저장된 건수
	 * @throws ApplicationException 세부업무 및 담당자 정보가 올바르지 않는 경우
	 */
	public int saveDetlBzChrgEno(final CMA801SVC01In intput) throws ApplicationException {
		
		logger.debug("세부업무 및 담당자 저장 시작");
		
		int saveCount = 0;
		List<SelectMultiTBCMETC004bOut> detlBzInfoList = intput.getDetlBzInfoList();
		
		logger.debug("세부업무 및 담당자 저장 대상건수:[{}]", detlBzInfoList == null ? 0 : detlBzInfoList.size());
		
		for(int i=0;i<detlBzInfoList.size();i++) {
			SelectMultiTBCMETC004bOut detlBzInfo = detlBzInfoList.get(i);
			saveCount += this.saveDetlBzInfo(detlBzInfo);
		}
		
		logger.debug("세부업무 담당자 저장건수:[{}]", saveCount);
		
		return saveCount;
	}
	
	/**
	 * 세부업무 담당자 정보 단건 저장
	 * @param detlBzInfo 세부업무 담당자 정보
	 * @return 저장건수
	 * @throws ApplicationException
	 */
	public int saveDetlBzInfo(final SelectMultiTBCMETC004bOut detlBzInfo) throws ApplicationException {
		
		int saveCount = 0;
		
		isValidateDetlBzInfo(detlBzInfo);
		
		//신규 데이터 저장
		if(detlBzInfo.getDetlBzMgntNo() == 0) {
			
			BigDecimal detlBzMgntNo = cma801dbio.selectLockTBCMETC005c();
			Integer tmpDetlBzMgntNo = (detlBzMgntNo == null ? new Integer(1) : new Integer(detlBzMgntNo.intValue() + 1));
			
			TBCMETC004Io detlBzChrgpInfo = new TBCMETC004Io();
			detlBzChrgpInfo.setDetlBzMgntNo(tmpDetlBzMgntNo);
			detlBzChrgpInfo.setChrgpEno(FwUtil.getUserId());
			detlBzChrgpInfo.setDetlBzMgrYn("Y");
			detlBzChrgpInfo.setDelYn("N");
			detlBzChrgpInfo.setLastChgrId(FwUtil.getUserId());
			detlBzChrgpInfo.setLastChgPgmId(FwUtil.getPgmId());
			detlBzChrgpInfo.setLastChgTrmNo(FwUtil.getTrmNo());
			
			saveCount += cma801dbio.insertOneTBCMETC004a(detlBzChrgpInfo);
			
			TBCMETC005Io detlBzInfos = new TBCMETC005Io();
			detlBzInfos.setDetlBzMgntNo(tmpDetlBzMgntNo);
			detlBzInfos.setDetlBzNm(detlBzInfo.getDetlBzNm());
			detlBzInfos.setExtrnInstNm(detlBzInfo.getExtrnInstNm());
			detlBzInfos.setDelYn("N");
			detlBzInfos.setLastChgrId(FwUtil.getUserId());
			detlBzInfos.setLastChgPgmId(FwUtil.getPgmId());
			detlBzInfos.setLastChgTrmNo(FwUtil.getTrmNo());
			
			saveCount += cma801dbio.insertOneTBCMETC005a(detlBzInfos);
		}
		//기등록 데이터에서 담당자 추가
		else {
			
			TBCMETC004Io detlBzChrgpInfo = new TBCMETC004Io();
			detlBzChrgpInfo.setDetlBzMgntNo(detlBzInfo.getDetlBzMgntNo());
			detlBzChrgpInfo.setChrgpEno(detlBzInfo.getChrgpEno());
			detlBzChrgpInfo.setDetlBzMgrYn("N");
			detlBzChrgpInfo.setDelYn("N");
			detlBzChrgpInfo.setLastChgrId(FwUtil.getUserId());
			detlBzChrgpInfo.setLastChgPgmId(FwUtil.getPgmId());
			detlBzChrgpInfo.setLastChgTrmNo(FwUtil.getTrmNo());
			
			saveCount += cma801dbio.insertOneTBCMETC004a(detlBzChrgpInfo);
			
		}
		
		return saveCount;
		
	}
	
	/**
	 * @param detlBzInfo
	 * @throws ApplicationException
	 */
	private void isValidateDetlBzInfo(final SelectMultiTBCMETC004bOut detlBzInfo) throws ApplicationException {
		
		logger.debug("세부업무");
		
		if(detlBzInfo == null) {
			logger.error("세부업무 정보가 없는 오류");
			throw new ApplicationException("APCME0039", null, new Object[]{"세부업무 정보 및 담당자 정보"});
		}

		//새로운 세부업무가 아니면 상세 데이터 체크
		if(detlBzInfo.getDetlBzMgntNo() != 0) {
			//파라미터 정보가 세부업무 담당자 사번이 존재하면서 사번이 로그인한 사용자가 아닐때 처리 가능한지에 대한 판단
			if(!StringUtils.isEmpty(detlBzInfo.getChrgpEno())
					&& FwUtil.getUserId().equals(detlBzInfo.getChrgpEno())
					&& !this.isDetlBzMgrYn(detlBzInfo.getDetlBzMgntNo(), FwUtil.getUserId())) {
				logger.error("");
				TBCMETC005Io detlBzMgrInfo = cma801dbio.selectOneTBCMETC005a(detlBzInfo.getDetlBzMgntNo(), null, "Y");
				throw new ApplicationException(
						"APCME0038"
						, new Object[]{"세부업무에 대한 파일을 저장 할 수 있는 "}
						, new Object[]{detlBzMgrInfo.getOrgNm() + " " + detlBzMgrInfo.getEmplNm() + "에게 " + detlBzInfo.getDetlBzNm() + "에 대한 담당자 추가를 요청하시기 바랍니다."});
			}
		}
		
		this.isValidateDetlBzInfoCols(detlBzInfo);
		
	}
	
	/**
	 * 세부업무 및 담당자 정보에 대한 입력값 체크
	 * @param detlBzInfo 세부업무 및 담당자 정보 객체
	 * @throws ApplicationException 항목값이 올바르지 않은 경우
	 */
	private void isValidateDetlBzInfoCols(final SelectMultiTBCMETC004bOut detlBzInfo) throws ApplicationException {
		
		if(StringUtils.isEmpty(detlBzInfo.getDetlBzNm())) {
			logger.error("오류난 세부업무 정보:{}", detlBzInfo);
			throw new ApplicationException("APCME0039", null, new Object[]{"세부 업무명이 없습니다."});
		}
		
		if(StringUtils.isEmpty(detlBzInfo.getExtrnInstNm())) {
			logger.error("오류난 세부업무 정보:{}", detlBzInfo);
			throw new ApplicationException("APCME0039", null, new Object[]{"세부업무를 보고하는 대외기관명이 없습니다."});
		}
		
		if(StringUtils.isEmpty(detlBzInfo.getChrgpEno())) {
			logger.error("오류난 세부업무 정보:{}", detlBzInfo);
			throw new ApplicationException("APCME0039", null, new Object[]{"세부업무에 대한 담당자 정보가 없습니다."});
		}
		
	}
	
	/**
	 * 세부업무와 파일을 맵핑하는 파일관리상세 세부업무 정보 목록을 저장
	 * @param fileMgntDetlBzList 저장하고자 하는 파일관리상세 세부업무 정보목록
	 * @return 저장된 건수
	 * @throws ApplicationException 저장 데이터가 올바르지 않거나 처리하는 사용자의 권한이 없을 경우
	 */
	public int saveDetlBzFileInfo(final List<TBCMETC003Io> fileMgntDetlBzList) throws ApplicationException {
		
		logger.debug("파일관리상세 세부업무 리스트 저장 시작");
		
		int fileMgntDetlBzSaveCount = 0;
		
		if(fileMgntDetlBzList == null || fileMgntDetlBzList.size() < 1) {
			throw new ApplicationException("APCME0037", null, new Object[]{"파일관리상세 세부업무 리스트 정보"});
		}
		
		for(final TBCMETC003Io tbcmetc003io : fileMgntDetlBzList) {
			tbcmetc003io.setLastChgrId(FwUtil.getUserId());
			tbcmetc003io.setLastChgPgmId(FwUtil.getPgmId());
			tbcmetc003io.setLastChgTrmNo(FwUtil.getTrmNo());
			fileMgntDetlBzSaveCount += saveDetlBzFileInfo(tbcmetc003io);
		}
		
		return fileMgntDetlBzSaveCount;
	}
	
	/**
	 * 세부업무와 파일을 맵핑하는 파일관리상세 세부업무 정보를 저장
	 * @param tbcmetc003io 저장하고자 하는 파일관리상세 세부업무 정보
	 * @return 저장된 건수
	 * @throws ApplicationException 저장 데이터가 올바르지 않거나 처리하는 사용자의 권한이 없을 경우
	 */
	public int saveDetlBzFileInfo(final TBCMETC003Io tbcmetc003io) throws ApplicationException {
		
		logger.debug("파일관리상세 세부업무 저장 시작");
		
		int saveCount = 0;
		
		if(tbcmetc003io == null) {
			logger.error("오류난 파일관리상세 세부업무 정보:{}", tbcmetc003io);
			throw new ApplicationException("APCME0037", null, new Object[]{"저장 하려는 세부업무와 파일간의 맵핑정보"});
		}
		
		if(tbcmetc003io.getDetlBzMgntNo() < 1) {
			logger.error("오류난 파일관리상세 세부업무 정보:{}", tbcmetc003io);
			throw new ApplicationException("APCME0037", null, new Object[]{"세부업무관리번호"});
		}
		
		if(StringUtils.isEmpty(tbcmetc003io.getFileMgntNo())) {
			logger.error("오류난 파일관리상세 세부업무 정보:{}", tbcmetc003io);
			throw new ApplicationException("APCME0037", null, new Object[]{"파일관리번호"});
		}
		
		if(tbcmetc003io.getFileSeq() < 1) {
			logger.error("오류난 파일관리상세 세부업무 정보:{}", tbcmetc003io);
			throw new ApplicationException("APCME0037", null, new Object[]{"파일일련번호"});
		}
		
		if(StringUtils.isEmpty(tbcmetc003io.getFileStrgExpiDt())) {
			logger.error("오류난 파일관리상세 세부업무 정보:{}", tbcmetc003io);
			throw new ApplicationException("APCME0037", null, new Object[]{"파일보관만기일자"});
		}
		
		if(tbcmetc003io.getFileStrgDys() < 1) {
			logger.error("오류난 파일관리상세 세부업무 정보:{}", tbcmetc003io);
			throw new ApplicationException("APCME0037", null, new Object[]{"파일보관일수"});
		}
		
		//로그인한 사용자의 권한 체크
		if(!isAvailableDetlBzFileSaving(tbcmetc003io.getDetlBzMgntNo(), FwUtil.getUserId())) {
			TBCMETC005Io detlBzInfo = cma801dbio.selectOneTBCMETC005a(tbcmetc003io.getDetlBzMgntNo(), null, "Y");
			throw new ApplicationException(
					"APCME0038"
					, new Object[]{"세부업무에 대한 파일을 저장 할 수 있는 "}
					, new Object[]{detlBzInfo.getOrgNm() + " " + detlBzInfo.getEmplNm() + "에게 " + detlBzInfo.getDetlBzNm() + "에 대한 담당자 추가를 요청하시기 바랍니다."});
		}
		
		saveCount = cma801dbio.insertOneTBCMETC003a(tbcmetc003io);
		
		logger.debug("파일관리상세 세부업무 저장건수:[{}]", saveCount);
		
		return saveCount;
	}
	
	/**
	 * 사번에 대한 가능한 세부업무 목록을 조회하여 리턴
	 * @param eno 사원번호 문자열
	 * @return 세부업무 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMETC004bOut> getdetlBzAndChrgList(final String eno) throws ApplicationException {
		
		logger.debug("세부업무 목록 조회시작");
		logger.debug("사원번호:[{}]", eno);
		
		if(StringUtils.isEmpty(eno))
			throw new ApplicationException("APCME0008", new String[]{"사원번호"});
		
		List<SelectMultiTBCMETC004bOut> detlBzList = cma801dbio.selectMultiTBCMETC003b(eno);
		
		logger.debug("사번:[{}]에 대한 처리가능한 세부업무 목록 조회결과 건수:[{}]"
				, new Object[]{eno, detlBzList != null ? detlBzList.size() : 0});
		
		return detlBzList;
		
	}
	
	/**
	 * 사번에 대한 가능한 세부업무 목록을 조회하여 리턴
	 * @param eno 사원번호 문자열
	 * @return 세부업무 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMETC005bOut> getdetlBzList(final String eno) throws ApplicationException {
		
		logger.debug("세부업무 목록 조회시작");
		logger.debug("사원번호:[{}]", eno);
		
		if(StringUtils.isEmpty(eno))
			throw new ApplicationException("APCME0008", new String[]{"사원번호"});
		
		List<SelectMultiTBCMETC005bOut> detlBzList = cma801dbio.selectMultiTBCMETC005c(eno);
		
		logger.debug("사번:[{}]에 대한 처리가능한 세부업무 목록 조회결과 건수:[{}]"
				, new Object[]{eno, detlBzList != null ? detlBzList.size() : 0});
		
		return detlBzList;
		
	}
	
	/**
	 * 세부업무관리번호, 사번을 이용하여 세부업무 담당자인지 판단하여 참 또는 거짓을 리턴
	 * @param detlBzMgntNo <code>int</code> 타입의 세부업무관리번호
	 * @param eno 문자열의 담당자 사번(10자리)
	 * @return 세부업무 담당자이면 <code>true</code> 리턴 이외에 <code>false</code> 리턴
	 */
	private boolean isAvailableDetlBzFileSaving(final int detlBzMgntNo, final String eno) {
		
		logger.debug("세부업무의 파일을 저장 할 수 있는 사람인지 판단(세부업무관리번호:{}, 사번:{})", detlBzMgntNo, eno);
		
		if(detlBzMgntNo < 1) {
			logger.warn("세부업무 담당자 저장이 가능한 사람인지 판단해야 하는 대상의 세부업무관리번호 정보가 1보다 작음.");
			return false;
		}
		
		if(StringUtils.isEmpty(eno)) {
			logger.warn("세부업무 담당자 저장이 가능한 사람인지 판단해야 하는 대상의 사번 정보가 없음.");
			return false;
		}
		
		//세부업무 담당자 테이블을 조회하여 처리하고자 하는 사용자의 권한 체크 
		TBCMETC004Io detlBzFileInfo = cma801dbio.selectOneTBCMETC004a(eno, detlBzMgntNo);
		
		if(detlBzFileInfo == null || StringUtils.isEmpty(detlBzFileInfo.getChrgpEno())) {
			logger.warn("조회된 결과가 없거나 담당자가 올바르지 않습니다.");
			return false;
		}
		
		return true;
	}
	
	/**
	 * 세부업무관리번호, 사번을 통해서 세부업무에 대한 관리자인지 판단하여 참 또는 거짓을 리턴
	 * @param detlBzMgntNo 정수 형태의 세부업무관리번호
	 * @param eno 문자열 형태의 담당자 사번
	 * @return 세부업무관리번호에 대한 관리자 사번이 맞으면 참 이외에는 거짓
	 * @throws ApplicationException 파라미터가 올바르지 않을 경우
	 */
	private boolean isDetlBzMgrYn(final int detlBzMgntNo, final String eno) throws ApplicationException {
		
		logger.debug("세부업무관리번호:[{}] 사번:[{}] 세부업무 관리자 여부 판단 시작", detlBzMgntNo, eno);
		
		if(detlBzMgntNo < 1) {
			logger.equals("세부업무 관리번호가 1미만");
			throw new ApplicationException("APCME0008", new String[]{"세부업무 관리번호"});
		}
		
		if(StringUtils.isEmpty(eno)) {
			logger.equals("사번이 입력되지 않았음.");
			throw new ApplicationException("APCME0008", new String[]{"세부업무 관리자인지 판단할 담당자 사번"});
		}
		
		boolean isDetlBzMgrYn = true;
		
		TBCMETC004Io detlBzFileInfo = cma801dbio.selectOneTBCMETC004a(eno, detlBzMgntNo);
		
		if(detlBzFileInfo == null || !"Y".equals(detlBzFileInfo.getDetlBzMgrYn()))
			isDetlBzMgrYn = false;
		
		logger.debug("세부업무관리번호:[{}] 사번:[{}] 세부업무 관리자 여부 판단결과:[{}]", new Object[]{detlBzMgntNo, eno, isDetlBzMgrYn});
		
		return isDetlBzMgrYn;
	}
	
	/**
	 * 파일관리상세 세부업무 정보 삭제
	 * @param input 파일정보
	 * @return 삭제된 건수
	 * @throws ApplicationException 삭제 처리시 SQL 오류가 발생할 경우
	 */
	public int deleteDetlBzFileInfos(final CMA801SVC01In input) throws ApplicationException {
		
		logger.debug("대외기관 전송 파일삭제(다건) 시작");
		
		if(input == null) {
			logger.error("삭제할 정보가 없음");
			throw new ApplicationException("APCME0037", null, new Object[]{"삭제할 정보"});
		}
		
		int deleteCount = 0;
		
		List<TBCMETC003Io> fileInfoList = input.getFileMgntDetlBzList();
		
		if(fileInfoList == null || fileInfoList.isEmpty() || fileInfoList.size() < 1) {
			logger.error("대외기관 전송 파일리스트 정보가 없음");
			throw new ApplicationException("APCME0037", null, new Object[]{"대외기관 전송 파일리스트 정보"});
		}
		
		logger.debug("삭제할 대상건수:[{}]", fileInfoList != null ? fileInfoList.size() : 0);
		
		for(final TBCMETC003Io fileInfo : fileInfoList) {
			deleteCount += deleteDetlBzFileInfo(fileInfo);
		}
		
		logger.debug("삭제된 정보건수:[{}]", deleteCount);
		
		return deleteCount;
		
	}
	
	/**
	 * 대외기관 전송용 파일을 삭제(단건)
	 * @param detlBzFileInfo 파일정보
	 * @return 삭제 결과건수
	 * @throws ApplicationException 삭제 처리중 오류가 발생할 경우
	 */
	public int deleteDetlBzFileInfo(final TBCMETC003Io detlBzFileInfo) throws ApplicationException {
		
		logger.debug("대외기관 전송 파일삭제(단건) 시작");
		logger.debug("삭제 대상정보:{}", detlBzFileInfo);
		
		if(detlBzFileInfo == null || detlBzFileInfo.getDetlBzMgntNo() == null
				|| detlBzFileInfo.getDetlBzMgntNo().intValue() < 1 || StringUtils.isEmpty(detlBzFileInfo.getFileMgntNo())) {
			logger.error("오류난 대외기관 전송 파일정보:{}", detlBzFileInfo);
			throw new ApplicationException("APCME0037", null, new Object[]{"대외기관 전송 파일정보"});
		}
		
		int deleteCount = 0;
		
		deleteCount = cma801dbio.deleteOneTBCMETC003a(
				detlBzFileInfo.getDetlBzMgntNo()
				, detlBzFileInfo.getFileMgntNo()
				, detlBzFileInfo.getFileSeq());
		
		cma005bean.deleteFileOther(detlBzFileInfo.getFileMgntNo(), detlBzFileInfo.getFileSeq());
		
		logger.debug("삭제 결과건수:[{}]", deleteCount);
		
		return deleteCount;
	}
	
	/**
	 * 세부업무 및 담당자 정보를 다건으로 받아서 일괄로 삭제
	 * @param input 세부업무 및 담당자 정보를 다건으로 보유한 데이터
	 * @return 삭제 결과건수
	 * @throws ApplicationException 삭제 처리중 오류가 발생할 경우
	 */
	public int deleteDetlBzAndChrgs(final CMA801SVC01In input) throws ApplicationException {
		
		logger.debug("세부업무 및 담당자 정보삭제(다건) 시작");
		logger.debug("삭제 대상정보:{}", input);
		
		if(input == null) {
			logger.error("오류난 세부업무 및 담당자 정보:{}", input);
			throw new ApplicationException("APCME0039", null, new Object[]{"세부업무 및 담당자 정보"});
		}
		
		int deleteCount = 0;
		
		List<SelectMultiTBCMETC004bOut> detlBzChrgList = input.getDetlBzInfoList();
		
		if(detlBzChrgList == null || detlBzChrgList.isEmpty() || detlBzChrgList.size() < 1) {
			logger.error("오류난 세부업무 및 담당자 정보:{}", input);
			throw new ApplicationException("APCME0039", null, new Object[]{"세부업무 및 담당자 정보"});
		}
		
		for(final SelectMultiTBCMETC004bOut detlBzChrgInfo : detlBzChrgList) {
			deleteCount += deleteDetlBzAndChrg(detlBzChrgInfo);
		}
		
		logger.debug("삭제 결과건수:[{}]", deleteCount);
		
		return deleteCount;
	}
	
	/**
	 * 세부업무 및 담당자 정보를 다건으로 받아서 일괄로 삭제
	 * @param detlBzChrg 세부업무 및 담당자 정보
	 * @return 삭제 결과건수
	 * @throws ApplicationException 삭제 처리중 오류가 발생할 경우
	 */
	public int deleteDetlBzAndChrg(final SelectMultiTBCMETC004bOut detlBzChrg) throws ApplicationException {
		
		logger.debug("세부업무 및 담당자 정보삭제(단건) 시작");
		logger.debug("삭제 대상정보:{}", detlBzChrg);
		
		if(detlBzChrg == null || detlBzChrg.getDetlBzMgntNo() == null || detlBzChrg.getDetlBzMgntNo().intValue() < 1) {
			logger.error("오류난 세부업무 및 담당자 정보:{}", detlBzChrg);
			throw new ApplicationException("APCME0039", null, new Object[]{"세부업무 및 담당자 정보"});
		}
		
		int deleteCount = 0;

		//로그인 사용자 권한 체크
		if(!isDetlBzMgrYn(detlBzChrg.getDetlBzMgntNo(), FwUtil.getUserId())) {
			logger.error("오류난 세부업무 및 담당자 정보:{}", detlBzChrg);
			throw new ApplicationException(
					"APCME0038", new Object[]{"관리자 "}, new Object[]{detlBzChrg.getDetlBzNm() + "업무의 관리자에게 "});
		}
		
		//삭제할 데이터의 담당자가 로그인한 사람 본인이면 세부업무에 대한 관리자로 판단
		if(FwUtil.getUserId().equals(detlBzChrg.getChrgpEno())) {
			
			//세부업무에 대한 파일이 존재하는지 체크
			List<SelectMultiTBCMETC003aOut> existFileList = cma801dbio.selectMultiTBCMETC003c(detlBzChrg.getDetlBzMgntNo());
			
			if(existFileList != null && !existFileList.isEmpty() && existFileList.size() > 0) {
				logger.error("세부업무에 연결된 파일이 존재하여 삭제하지 못함");
				throw new ApplicationException("APCME0040", null);
			}
			
			//관리자 본인 이외에 세부업무와 연결된 담당자가 있는지 1건만 조회
			TBCMETC004Io chrgpInfo = cma801dbio.selectOneTBCMETC004c(detlBzChrg.getDetlBzMgntNo(), FwUtil.getUserId());
			
			if(chrgpInfo != null && !StringUtils.isEmpty(chrgpInfo.getChrgpEno())) {
				logger.error("세부업무 삭제시 관리자를 제외한 담당자가 존재하여 삭제불가 담당자 데이터(1건만 조회한 결과):{}"
						, chrgpInfo);
				throw new ApplicationException("APCME0041"
						, new Object[]{detlBzChrg.getDetlBzNm()}
						, new Object[]{detlBzChrg.getDetlBzNm()});
			}
			
			logger.debug("세부업무 및 세부업무 담당자 삭제건");
			deleteCount += cma801dbio.deleteOneTBCMETC004a(detlBzChrg.getDetlBzMgntNo(), detlBzChrg.getChrgpEno());
			deleteCount += cma801dbio.deleteOneTBCMETC005a(detlBzChrg.getDetlBzMgntNo());
		}
		//세부업무 담당자 삭제
		else {
			logger.debug("세부업무 담당자 삭제건");
			deleteCount = cma801dbio.deleteOneTBCMETC004a(detlBzChrg.getDetlBzMgntNo(), detlBzChrg.getChrgpEno());
		}
		
		logger.debug("삭제 결과건수:[{}]", deleteCount);
		
		return deleteCount;
	}
	
}