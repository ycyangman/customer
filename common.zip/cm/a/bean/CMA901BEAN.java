package cigna.cm.a.bean;

import java.math.BigDecimal;

import cigna.cm.a.dbio.CMA901DBIO;
import cigna.cm.a.io.TBCMCCD041Io;
import cigna.zz.FwUtil;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.bean.CMA901BEAN.java
 * @filetype     java source file
 * @brief        엑셀 다운로드를 실행한 사용자에 대한 정보를 엑셀다운로드이력(TBCMCCD041) 테이블에 저장
 * @author       김정국
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김정국                2014. 1. 21.       신규 작성
 * 1.1           김정국                2015. 3. 21.       형상관리 서버 OS 백업 에이젼트 설치후 배포테스트
 *
 */
@KlafBean
public class CMA901BEAN {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA901DBIO cma901dbio;
	
	/**
	 * 화면명, 저장 엑셀 ROW 건수를 받아서 저장
	 * 
	 * @param scrnNm 화면명
	 * @param xlsSwtCnt 저장 엑셀 ROW 건수
	 * @return 이력 저장이 성공하면 true, 아니면 false
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public boolean insertExcelDownloadLog(String scrnNm, Integer xlsSwtCnt) throws ApplicationException {
		
		logger.debug("엑셀 다운로드 오퍼레이팅을 로그로 생성합니다. 화면명:[{}] 다운로드 엑셀파일 행수:[{}]", scrnNm, xlsSwtCnt);
		
		//입력값 체크
		if(StringUtils.isEmpty(scrnNm) || xlsSwtCnt == null || xlsSwtCnt.intValue() < 1){
			logger.warn("로깅에 필요한 정보가 부족합니다. 화면이름:[{}] 다운로드 엑셀파일 행수:[{}]", scrnNm, xlsSwtCnt);
			return false;
		}
		
		String usrId = FwUtil.getUserId();
		if(StringUtils.isEmpty(usrId)) {
			usrId = "unkown";
		}
		
		String deptId = FwUtil.getDeptCd();
		if(StringUtils.isEmpty(deptId)) {
			deptId = FwUtil.getMedTyp();
		}
		
		boolean isSaved = false;
		String swtDtm = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) + DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		
		//로그 테이블에서 작업순번 MAX 조회(FOR UPDATE WAIT 3 사용)
		BigDecimal maxWrkSeq = cma901dbio.selectOneTBCMCCD041();
		if(maxWrkSeq == null)
			maxWrkSeq = BigDecimal.ZERO;
		BigDecimal addedMaxWrkSeq = maxWrkSeq.add(BigDecimal.ONE);
		
		TBCMCCD041Io downLogInfo = new TBCMCCD041Io();
		downLogInfo.setWrkSeq(addedMaxWrkSeq);				//작업순번
		downLogInfo.setScrnId(FwUtil.getScreenId());		//화면ID
		downLogInfo.setScrnNm(scrnNm);						//화면명
		downLogInfo.setBlntOrgNo(deptId);		//소속조직번호
		downLogInfo.setEno(usrId);				//사원번호
		downLogInfo.setXlsSwtRowsNum(xlsSwtCnt);			//엑셀전환행수
		downLogInfo.setSwtDtm(swtDtm);						//전환일시
		downLogInfo.setIpAddr(FwUtil.getTrmNo());			//IP주소
		downLogInfo.setLastChgPgmId(FwUtil.getPgmId());		//최종변경프로그램ID
		downLogInfo.setLastChgrId(usrId);		//최종변경자ID
		downLogInfo.setLastChgTrmNo(FwUtil.getTrmNo());		//최종변경단말번호
		
		int successCnt = 0;
		
		try{
			
			successCnt = cma901dbio.insertOneTBCMCCD041(downLogInfo);
			
			if(successCnt > 0){
				isSaved = true;
			}else{
				logger.warn("엑셀 다운로드 오퍼레이팅에 로그 생성을 하지 못했습니다. 로그내용:{}", downLogInfo);
				isSaved = false;
			}
		}catch(Exception e){
			logger.error("엑셀 다운로드 오퍼레이팅에 로그 생성을 하지 못했습니다. 로그내용:{}", downLogInfo, e);
		}
		
		logger.debug("엑셀 다운로드 오퍼레이팅에 대한 로그생성을 종료합니다. 처리결과:[{}]", isSaved);
		
		return isSaved;
	}
}