package cigna.cm.a.bean;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.a.dbio.CMAZ00DBIO;
import cigna.cm.a.io.CMAZ00SVC02In;
import cigna.cm.a.io.CMAZ00SVC04In;
import cigna.cm.a.io.CMAZ00SVC06In;
import cigna.cm.a.io.SelectMultiTBCMCCD006bOut;
import cigna.cm.a.io.TBCMCCD006Io;
import cigna.cm.a.io.TBCMCCD032Io;
import cigna.cm.a.io.TBCMCCD040Io;
import cigna.zz.FwUtil;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file         cigna.cm.a.bean.CMAZ00BEAN.java
 * @filetype     java source file
 * @brief        기타 공통업무 화면 BEAN(화면연결정보)		
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1               박경화                 2012. 8. 3.       신규 작성
 * 0.6               박경화                 2012. 8.10.       개발 완료
 * 0.9               박경화                 2012. 8.10.       Class 테스트
 * 1.0               박경화                 2012. 8.10.       단위 테스트  
 * 
 */
@KlafBean
public class CMAZ00BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 화면연결정보 조회, 수정하는 DBIO
	 */	
	@Autowired
	private CMAZ00DBIO cmaz00dbio; 
	
	/**
	 * 화면연결정보 목록 조회
	 * @param scrnNo 화면번호
	 * @return List<TBCMCCD006Io> 화면연결정보 목록
	 * @throws ApplicationException
	 */
	public List<TBCMCCD006Io> getConnScrnNoList(String scrnNo)	throws ApplicationException {
		
		//1. 필수입력값체크
		if (StringUtils.isEmpty(scrnNo)) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "화면번호" });
		} 

		//2. 화면연결정보 조회
		List<TBCMCCD006Io> connScrnNoList = this.cmaz00dbio.selectMultiTBCMCCD006a(scrnNo);
		
		return connScrnNoList;
	}
	
	/**
	 * 화면연결정보 목록 조회(UI용)
	 * @param scrnNo 화면번호
	 * @return List<SelectMultiTBCMCCD006bOut> 화면연결정보 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMCCD006bOut> getConnScrnNoListUI(String scrnNo)	throws ApplicationException {
		
		List<SelectMultiTBCMCCD006bOut> connScrnNoList = new ArrayList<SelectMultiTBCMCCD006bOut>();
		List<SelectMultiTBCMCCD006bOut> connScrnNoListTemp = null;
		
		// 1-1. 화면연결정보 목록 건수 조회 
		//int iconnScrnNoListCnt = this.cmaz00dbio.selectOneTBCMCCD006();
		
		int pageCount = 3000;
		//int pageNumMax = new BigDecimal(iconnScrnNoListCnt).divide(new BigDecimal(pageCount), BigDecimal.ROUND_CEILING).intValue();
		
		//logger.debug("pageCount={}, pageNumMax= {}", pageCount, pageNumMax);
		
		boolean flag = true;
		//for (int pageNum = 1 ; pageNum <= pageNumMax ; pageNum++ ) {
		for(int pageNum = 1; flag; pageNum++) {
			
			//1-2. 화면연결정보 조회
			connScrnNoListTemp = this.cmaz00dbio.selectMultiTBCMCCD006b(scrnNo, pageNum, pageCount);
			
			if ( connScrnNoListTemp != null && connScrnNoListTemp.size() > 0 ) {
				
				logger.debug( "connScrnNoList add (connScrnNoListTemp) {}",  connScrnNoListTemp.size() );
				
				connScrnNoList.addAll(connScrnNoListTemp);
				
				logger.debug( "connScrnNoList addAll (connScrnNoList) {}",  connScrnNoList.size() );
				
				
			}  else {
				flag = false;
			}
		}
		
		return connScrnNoList;
	}
	
	/**
	 * 화면연결정보 저장
	 * @param in CMAZ00SVC01In -> List<TBCMCCD006Io> 화면연결정보 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	public int modifyConnScrnNoList (CMAZ00SVC02In in) throws ApplicationException {
		
		int iCnt = 0;
		int iConnScrnNoListCnt = in.getConnScrnNoListCnt();
		List<TBCMCCD006Io> connScrnNoList = in.getConnScrnNoList();
		
		//1. 필수입력값체크
		if( connScrnNoList == null || connScrnNoList.size() == 0 || iConnScrnNoListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iConnScrnNoListCnt }, new Object[]{ "화면연결정보" , "변경된 내용 없음" });
		}
		
		//2. 화면연결정보 저장
		for( TBCMCCD006Io connScrnNo : connScrnNoList ){ 
			
			// Table에 Insert / Update할 경우에 반드시 설정해야 할 Audit Column들을 설정.
			connScrnNo.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
			connScrnNo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			connScrnNo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iCnt += this.cmaz00dbio.mergeOneTBCMCCD006(connScrnNo); 
		}
		
		return iCnt;

	}
	
	/**
	 * 화면연결정보 삭제
	 * @param in CMAZ00SVC01In -> List<TBCMCCD006Io> 화면연결정보 목록
	 * @return int 삭제건수
	 * @throws ApplicationException
	 */
	public int deleteConnScrnNoList (CMAZ00SVC02In in) throws ApplicationException {
		
		int iCnt = 0;
		int iConnScrnNoListCnt = in.getConnScrnNoListCnt();
		List<TBCMCCD006Io> connScrnNoList = in.getConnScrnNoList();
		
		//1. 필수입력값체크
		if( connScrnNoList == null || connScrnNoList.size() == 0 || iConnScrnNoListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iConnScrnNoListCnt }, new Object[]{ "화면연결정보" , "삭제 할 대상없음" });
		}
		
		//2. 화면연결정보 삭제
		for( TBCMCCD006Io connScrnNo : connScrnNoList ){ 
			
			iCnt += this.cmaz00dbio.deleteOneTBCMCCD006(connScrnNo.getScrnNo(), connScrnNo.getConnScrnNo()); 
		}
		
		return iCnt;

	}
	
	/**
	 * UI요약정보 목록 조회
	 * @param 
	 * @return List<TBCMCCD032Io> UI요약정보 목록
	 * @throws ApplicationException
	 */
	public List<TBCMCCD032Io> getSmryInfoList()	throws ApplicationException {

		//UI요약정보 조회
		List<TBCMCCD032Io> smryInfoList = this.cmaz00dbio.selectMultiTBCMCCD032a();
		
		return smryInfoList;
	}
	
	/**
	 * UI요약정보 화면유형 저장
	 * @param in CMAZ00SVC04In -> List<TBCMCCD032Io> UI요약정보 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	public int modifySmryInfoList (CMAZ00SVC04In input) throws ApplicationException {
		
		int iCnt = 0;
		int iSmryInfoListCnt = input.getSmryInfoListCnt();
		List<TBCMCCD032Io> smryInfoList = input.getSmryInfoList();
						
		//1. 필수입력값체크
		if( smryInfoList == null || smryInfoList.size() == 0 || iSmryInfoListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iSmryInfoListCnt }, new Object[]{ "UI요약정보" , "변경된 내용 없음" });
		}	
		
		//2. UI요약정보 화면유형 저장
		for( TBCMCCD032Io scrnId : smryInfoList ){ 
			
			// Table에 Insert / Update할 경우에 반드시 설정해야 할 Audit Column들을 설정.
			scrnId.setRegDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	  // 등록일자
			scrnId.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
			scrnId.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			scrnId.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iCnt += this.cmaz00dbio.mergeOneTBCMCCD032(scrnId); 
		}
		
		return iCnt;

	}
	
	/**
	 * UI요약정보 삭제
	 * @param in CMAZ00SVC04In -> List<TBCMCCD032Io> UI요약정보 목록
	 * @return int 삭제건수
	 * @throws ApplicationException
	 */
	public int deleteSmryInfoList (CMAZ00SVC04In in) throws ApplicationException {
		
		int iCnt = 0;
		int iSmryInfoListCnt = in.getSmryInfoListCnt();
		List<TBCMCCD032Io> smryInfoList = in.getSmryInfoList();
		
		//1. 필수입력값체크
		if( smryInfoList == null || smryInfoList.size() == 0 || iSmryInfoListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iSmryInfoListCnt }, new Object[]{ "UI요약정보" , "삭제 할 대상없음" });
		}
		
		//2. UI요약정보 삭제
		for( TBCMCCD032Io smryInfo : smryInfoList ){ 
			
			iCnt += this.cmaz00dbio.deleteOneTBCMCCD032(smryInfo.getScrnId()); 
		}
		
		return iCnt;

	}	
	
	/**
	 * 마이메뉴 목록 조회
	 * @param 
	 * @return List<TBCMCCD040Io> 마이메뉴 목록
	 * @throws ApplicationException
	 */
	public List<TBCMCCD040Io> getMyMenuInfoList(String eno)	throws ApplicationException {

		//마이메뉴 조회
		List<TBCMCCD040Io> myMenuInfoList = this.cmaz00dbio.selectMultiTBCMCCD040(eno);
		
		return myMenuInfoList;
	}
	
	/**
	 * 마이메뉴 저장
	 * @param in CMAZ00SVC06In -> List<TBCMCCD040Io> 마이메뉴 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	public int modifyMyMenuInfoList (CMAZ00SVC06In input) throws ApplicationException {
		
		int iCnt = 0;
		int iMyMenuInfoListCnt = input.getMyMenuInfoListCnt();
		List<TBCMCCD040Io> myMenuInfoList = input.getMyMenuInfoList();
						
		//1. 필수입력값체크
		if( myMenuInfoList == null || myMenuInfoList.size() == 0 || iMyMenuInfoListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iMyMenuInfoListCnt }, new Object[]{ "마이메뉴" , "변경된 내용 없음" });
		}	
		
		//2. 마이메뉴 저장
		for( TBCMCCD040Io eno : myMenuInfoList ){ 
			
			// Table에 Insert / Update할 경우에 반드시 설정해야 할 Audit Column들을 설정.
			eno.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
			eno.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			eno.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iCnt += this.cmaz00dbio.mergeOneTBCMCCD040(eno); 
		}
		
		return iCnt;

	}
	
	/**
	 * 마이메뉴 삭제
	 * @param in CMAZ00SVC06In -> List<TBCMCCD040Io> 마이메뉴 목록
	 * @return int 삭제건수
	 * @throws ApplicationException
	 */
	public int deleteMyMenuInfoList (CMAZ00SVC06In in) throws ApplicationException {
		
		int iCnt = 0;
		int iMyMenuInfoListCnt = in.getMyMenuInfoListCnt();
		List<TBCMCCD040Io> myMenuInfoList = in.getMyMenuInfoList();
		
		//1. 필수입력값체크
		if( myMenuInfoList == null || myMenuInfoList.size() == 0 || iMyMenuInfoListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iMyMenuInfoListCnt }, new Object[]{ "마이메뉴" , "삭제 할 대상없음" });
		}
		
		//2. 마이메뉴 삭제
		for( TBCMCCD040Io eno : myMenuInfoList ){ 
			
			iCnt += this.cmaz00dbio.deleteOneTBCMCCD040(eno.getEno(), eno.getScrnId()); 
		}
		
		return iCnt;

	}		
}

