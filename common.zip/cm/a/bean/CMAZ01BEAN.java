package cigna.cm.a.bean;

import java.util.List;

import cigna.cm.a.dbio.CMAZ01DBIO;
import cigna.cm.a.io.CMAZ01SVC01In;
import cigna.cm.a.io.CMAZ01SVC02In;
import cigna.cm.a.io.CMAZ01SVC03In;
import cigna.cm.a.io.CMAZ01SVC05In;
import cigna.cm.a.io.CMAZ01SVC05Out;
import cigna.cm.a.io.SelectMultiTBCMCCD026Out;
import cigna.cm.a.io.SelectMultiTBCMCCD033Out;
import cigna.cm.a.io.TBCMCCD033Io;
import cigna.cm.a.io.SelectMultiTBCMCCD033cOut;
import cigna.zz.FwUtil;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.bean.CMZ001BEAN.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2013. 8. 1.       신규 작성
 *
 */
@KlafBean
public class CMAZ01BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMAZ01DBIO cmaz01dbio;
	
	/**
	 * 메뉴 조회
	 * @param CMAZ01SVC03In
	 * @return
	 * @throws ApplicationException
	 */	
	public List<TBCMCCD033Io> getMenuInfoList(CMAZ01SVC03In input) throws ApplicationException {
		List<TBCMCCD033Io> menuInfoList = null;
		String menuSysCd = StringUtils.nvl(input.getMenuSysCd());
		String menuGrpCd = StringUtils.nvl(input.getMenuGrpCd());
		menuInfoList = cmaz01dbio.selectMultiTBCMCCD033b(menuSysCd,menuGrpCd);
		
		if(menuInfoList == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return menuInfoList;
	}	
	
	/**
	 * 메뉴 조회
	 * @param 
	 * @return
	 * @throws ApplicationException
	 */	
	public List<TBCMCCD033Io> getMenuInfoListAll(CMAZ01SVC03In input) throws ApplicationException {
		List<TBCMCCD033Io> menuInfoList = null;
		String menuSysCd = StringUtils.nvl(input.getMenuSysCd());
		menuInfoList = cmaz01dbio.selectMultiTBCMCCD033a(menuSysCd);
		
		if(menuInfoList == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return menuInfoList;
	}
		
	/**
	 * 메뉴 조회 UI연동
	 * @param 
	 * @return
	 * @throws ApplicationException
	 */	
	public List<SelectMultiTBCMCCD033cOut> getComMnList() throws ApplicationException {
		List<SelectMultiTBCMCCD033cOut> menuInfoList = null;
		
		String sysId = null;
		String usrId = FwUtil.getUserId();
		
		//임시 
		if(StringUtils.isEmpty(usrId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "사용자 ID" } );
		}
		
		menuInfoList = cmaz01dbio.selectMultiTBCMCCD033c(usrId, sysId);
		
		if(menuInfoList == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return menuInfoList;
	}	
	
	/**
	 * 메뉴 조회 UI연동
	 * @param 
	 * @return
	 * @throws ApplicationException
	 */	
	public CMAZ01SVC05Out getComBtnList(CMAZ01SVC05In input) throws ApplicationException {
		
		CMAZ01SVC05Out output = new CMAZ01SVC05Out();
		List<SelectMultiTBCMCCD026Out> btunInfoList = null;
		
		String sysId = null;
		String usrId = FwUtil.getUserId();
		String scrnId = input.getScrnId();
		
		String authAdptYn = "Y";
		
		if(StringUtils.isEmpty(scrnId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "화면ID" } );
		}
		
		//임시테스트
		/*
		 * 
		String bzGvn = "";
		if(!StringUtils.isEmpty(scrnId)) {
			bzGvn = scrnId.substring(0,2);
		}
		
		if(!"CM".equals(bzGvn)) {
			authAdptYn = "N";
		}
		*/
		
		output.setAuthAdptYn(authAdptYn);
		
		btunInfoList = cmaz01dbio.selectMultiTBCMCCD035( sysId, usrId, scrnId);
		
		output.setButnList(btunInfoList);
		output.setButnListCnt(btunInfoList.size());
		
		return output;
	}		
	
	/**
	 * 메뉴정보 저장
	 * @param in CMAZ01SVC01In -> List<TBCMCCD033Io> 메뉴정보 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	public int modifyMenuInfoList(CMAZ01SVC01In input) throws ApplicationException {
		
		int iCnt = 0;
		int iMenuInfoListCnt = input.getMenuInfoListCnt();
//		String scrnId = "";
//		String scrnUrlVl = "";
		List<TBCMCCD033Io> menuInfoList = input.getMenuInfoList();
						
		//1. 필수입력값체크
		if( menuInfoList == null || menuInfoList.size() == 0 || iMenuInfoListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iMenuInfoListCnt }, new Object[]{ "메뉴정보" , "변경된 내용 없음" });
		}	
		
		//2. 메뉴정보 저장
		for( TBCMCCD033Io menuMgntInfo : menuInfoList ){ 
			
			logger.debug( "menuInfoList : {} " , menuInfoList );
			
//			if(menuMgntInfo.getMenuMgntNo() != menuMgntInfo.getMenuMgntNoTmp() && menuMgntInfo.getMenuMgntNoTmp() != null){
//				this.cmaz01dbio.deleteOneTBCMCCD033(menuMgntInfo.getMenuMgntNoTmp());
//			}
			
			// Table에 Insert / Update할 경우에 반드시 설정해야 할 Audit Column들을 설정.
			menuMgntInfo.setLastChgrId(FwUtil.getUserId()); // 최종변경자ID(LAST_CHGR_ID) 설정
			menuMgntInfo.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			menuMgntInfo.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iCnt += this.cmaz01dbio.mergeOneTBCMCCD033b(menuMgntInfo);
			
//			if(menuMgntInfo.getScrnId() != null){ //화면 테이블 정보가 존재할때만 등록
//				if(menuMgntInfo.getScrnId() != menuMgntInfo.getScrnIdTmp() && menuMgntInfo.getScrnIdTmp() != null){	//화면 ID가 있으면서 변경된 경우 기존 화면ID 삭제여부 수정
//					this.cmaz01dbio.updateOneTBCMCCD034(menuMgntInfo);
//				}
//				scrnId = menuMgntInfo.getScrnId();
//				scrnUrlVl = scrnId.substring(0,2)+"::"+scrnId+".html";	//화면ID가 있을 경우 자동으로 URL 생성
//				menuMgntInfo.setScrnUrlVl(scrnUrlVl);	//화면URL 설정
//				this.cmaz01dbio.mergeOneTBCMCCD034(menuMgntInfo);	//화면 정보등록
//			}
		}
		
		return iCnt;

	}
	
	/**
	 * 메뉴정보 삭제
	 * @param in CMAZ01SVC02In -> List<SelectMultiTBCMCCD033Out> 메뉴관리번호 목록
	 * @return int 삭제건수
	 * @throws ApplicationException
	 */
	public int deleteMenuMgntNoList (CMAZ01SVC02In input) throws ApplicationException {
		
		int iCnt = 0;
		int iMenuMgntNoListCnt = input.getMenuDelListCnt();
		List<SelectMultiTBCMCCD033Out> menuMgntNoList = input.getMenuDelList();
		
		//1. 필수입력값체크
		if( menuMgntNoList == null || menuMgntNoList.size() == 0 || iMenuMgntNoListCnt <= 0 ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ iMenuMgntNoListCnt }, new Object[]{ "메뉴삭제정보" , "삭제 할 대상없음" });
		}
		
		//2. 메뉴정보 삭제
		for( SelectMultiTBCMCCD033Out menuMgntNo : menuMgntNoList ){ 
			
			iCnt += this.cmaz01dbio.deleteOneTBCMCCD033(menuMgntNo.getMenuMgntNo()); 
		}
		
		return iCnt;

	}	
	
}

