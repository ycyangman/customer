/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Thu Feb 02 14:12:51 KST 2017
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA001DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA001DBIO
{

	/**
	 * 공통코드처리건수로그시퀀스조회
	 */
	java.lang.Integer selectOneTBCMCCD001();

	/**
	 * 공통코드목록조회
	 * @TestValues 	comnCdId=CD_CM00005;	comnCdNm=;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD001Io> selectMultiTBCMCCD001a(@Param("comnCdId")
	java.lang.String comnCdId, @Param("comnCdNm")
	java.lang.String comnCdNm);

	/**
	 * 공통코드상세조회
	 * @TestValues 	comnCdId=CD_AT00015;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD002Io> selectMultiTBCMCCD002a(
			@Param("comnCdId")
			java.lang.String comnCdId);

	/**
	 * 공통코드리스트조회(전체)
	 */
	java.util.List<cigna.cm.a.domain.ComnCd> selectMultiTBCMCCD001b();

	/**
	 * 공통코드목록. 공통코드값 조회(API용)
	 * @TestValues 	comnCdId=CD_CN00091;	comnCdVl=04;
	 */
	java.util.List<klaf.container.cache.data.CommonCode> selectMultiTBCMCCD001c(
			@Param("comnCdId")
			java.lang.String comnCdId, @Param("comnCdVl")
			java.lang.String comnCdVl);

	/**
	 * 공통코드후처리 Cache Put
	 * @TestValues 	lastChgDtm=20130413;	pageNum=1;	pageCount=100;
	 */
	java.util.List<klaf.container.cache.data.CommonCode> selectMultiTBCMCCD001d(
			@Param("lastChgDtm")
			java.lang.String lastChgDtm, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount);

	/**
	 * (유효한) 공통코드목록. 공통코드값 조회(API용)
	 * @TestValues 	comnCdId=;	comnCdVl=;
	 */
	java.util.List<klaf.container.cache.data.CommonCode> selectMultiTBCMCCD001e(
			@Param("comnCdId")
			java.lang.String comnCdId, @Param("comnCdVl")
			java.lang.String comnCdVl);

	/**
	 * 공통코드후처리 Cache Put 건수
	 * @TestValues 	lastChgDtm=20130413;
	 */
	java.lang.Integer selectOneTBCMCCD001a(
			@Param("lastChgDtm")
			java.lang.String lastChgDtm);

	/**
	 * 공통코드목록전체조회
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD001Io> selectMultiTBCMCCD001();

	/**
	 * 공통코드상세전체조회
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD002Io> selectMultiTBCMCCD002();

	java.util.List<klaf.container.cache.data.CommonCode> selectMultiTBCMCCD001f();

	java.util.List<klaf.container.cache.data.CommonCode> selectMultiTBCMCCD001x(
			@Param("comnCdList") java.util.List comnCdList);
}