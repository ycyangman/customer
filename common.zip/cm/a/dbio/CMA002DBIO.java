/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Mon Mar 20 20:13:52 KST 2017
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA002DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA002DBIO
{

	/**
	 * @TestValues 	pageNum=0;	pageCount=0;
	 */
	java.util.List<cigna.cm.a.io.KLAFCOMMONMSGIo> selectMultiKLAFCOMMONMSG(@Param("pageNum")
	int pageNum, @Param("pageCount")
	int pageCount);

	/**
	 * @TestValues 	inqDvsn=;	inqNm=김;	emplTpcd=;	rtmtDcd=;	orgNo=;	bzprtCd=;	pageNum=1;	pageCount=10;
	 */
	java.util.List<cigna.cm.a.io.CMA002SVC02Sub> selectMultiTBSLEMP001(@Param("inqDvsn")
	java.lang.String inqDvsn, @Param("inqNm")
	java.lang.String inqNm, @Param("emplTpcd")
	java.lang.String emplTpcd, @Param("rtmtDcd")
	java.lang.String rtmtDcd, @Param("orgNo")
	java.lang.String orgNo, @Param("bzprtCd")
	java.lang.String bzprtCd, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount);

	/**
	 * @TestValues 	inqDvsn=;	inqNm=326006;	orgStats=;	facOrgNo=000100;	orgTpcd=;	bzprtCd=;	pageNum=1;	pageCount=10;
	 */
	java.util.List<cigna.cm.a.io.CMA002SVC01Sub> selectMultiTBSLORG001(@Param("inqDvsn")
	java.lang.String inqDvsn, @Param("inqNm")
	java.lang.String inqNm, @Param("orgStats")
	java.lang.String orgStats, @Param("facOrgNo")
	java.lang.String facOrgNo, @Param("orgTpcd")
	java.lang.String orgTpcd, @Param("bzprtCd")
	java.lang.String bzprtCd, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount);

	/**
	 * 사원기본정보조회
	 * @TestValues 	eno=1500364000;
	 */
	cigna.cm.a.domain.CommEmplInfo selectOneTBSLEMP001(@Param("eno")
	java.lang.String eno);

	/**
	 * 조직정보조회
	 * @TestValues 	orgNo=000311;
	 */
	cigna.cm.a.domain.OrgInfo selectOneTBSLORG001a(
			@Param("orgNo")
			java.lang.String orgNo);

	/**
	 * @TestValues 	orgNo=008087;
	 */
	cigna.cm.a.domain.OrgEtcInfo selectOneTBSLORG001b(@Param("orgNo")
	java.lang.String orgNo);

	java.lang.Integer selectOneKLAFCOMMONMSG();

	/**
	 * 사용자 서비스별 권한 조회
	 * @TestValues 	eno=D000888103;	svcScrnNo=CMA001M0;
	 */
	java.util.List<java.lang.String> selectMultiTBCMCCD026(@Param("eno")
			java.lang.String eno, @Param("svcScrnNo")
			java.lang.String svcScrnNo);

	java.util.List<cigna.cm.a.io.KLAFCOMMONMSGIo> selectMultiKLAFCOMMONMSGa();

	/**
	 * 사용자 역활 조회
	 * @TestValues 	eno=D000888103;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD025Io> selectMultiTBCMCCD025(@Param("eno")
	java.lang.String eno);

	java.lang.String selectOneKLAFCOMMONMSGa();

	/**
	 * @TestValues 	orgNo=000000;
	 */
	cigna.cm.a.domain.OrgTelnoInfo selectOneTBSLORG003(@Param("orgNo")
	java.lang.String orgNo);

	/**
	 * @TestValues 	inqDvsn=;	inqNm=;	emplTpcd=;	rtmtDcd=;	orgNo=000022;	bzprtCd=;	pageNum=1;	pageCount=15;
	 */
	java.util.List<cigna.cm.a.io.CMA002SVC02Sub> selectMultiTBSLEMP001a(
			@Param("inqDvsn")
			java.lang.String inqDvsn, @Param("inqNm")
			java.lang.String inqNm, @Param("emplTpcd")
			java.lang.String emplTpcd, @Param("rtmtDcd")
			java.lang.String rtmtDcd, @Param("orgNo")
			java.lang.String orgNo, @Param("bzprtCd")
			java.lang.String bzprtCd, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);

	/**
	 * @TestValues 	inqNm=;	emplTpcd=;	rtmtDcd=;	bzprtCd=;	pageNum=1;	pageCount=15;
	 */
	java.util.List<cigna.cm.a.io.CMA002SVC02Sub> selectMultiTBSLEMP001b(@Param("inqNm")
	java.lang.String inqNm, @Param("emplTpcd")
	java.lang.String emplTpcd, @Param("rtmtDcd")
	java.lang.String rtmtDcd, @Param("bzprtCd")
	java.lang.String bzprtCd, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount);

	/**
	 * @TestValues 	emplTpcd=11;	rtmtDcd=;	bzprtCd=;	pageNum=1;	pageCount=15;
	 */
	java.util.List<cigna.cm.a.io.CMA002SVC02Sub> selectMultiTBSLEMP001c(@Param("emplTpcd")
	java.lang.String emplTpcd, @Param("rtmtDcd")
	java.lang.String rtmtDcd, @Param("bzprtCd")
	java.lang.String bzprtCd, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount);

	/**
	 * @TestValues 	eno=;
	 */
	java.util.List<cigna.cm.a.io.TBSLEMP032Io> selectMultiTBSLEMP032(
			@Param("eno")
			java.lang.String eno);

	/**
	 * @TestValues 	eno=;
	 */
	java.lang.String selectOneTBCMCCD039(
			@Param("eno")
			java.lang.String eno);

	/**
	 * @TestValues 	inqDvsn=;	inqNm=s;	orgStats=;	facOrgNo=;	orgTpcd=;	bzprtCd=;	pageNum=1;	pageCount=10;
	 */
	java.util.List<cigna.cm.a.io.CMA002SVC01Sub> selectMultiTBSLORG001a(
			@Param("inqDvsn")
			java.lang.String inqDvsn, @Param("inqNm")
			java.lang.String inqNm, @Param("orgStats")
			java.lang.String orgStats, @Param("facOrgNo")
			java.lang.String facOrgNo, @Param("orgTpcd")
			java.lang.String orgTpcd, @Param("bzprtCd")
			java.lang.String bzprtCd, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);

	/**
	 * 사원번호에 해당하는 처리부서조직번호를 읽어온다
	 * @TestValues 	eno=1000111364;
	 */
	java.lang.String selectOneTBCMETC002(@Param("eno")
	java.lang.String eno);

	/**
	 * @TestValues 	eno=1000111364;	prcsDeptOrgNo=310007;	lastChgrId=1000800251;	lastChgPgmId=SYSTEM;	lastChgTrmNo=010003014029;
	 */
	int updateOneTBCMETC002(@Param("eno")
			java.lang.String eno, @Param("prcsDeptOrgNo")
			java.lang.String prcsDeptOrgNo, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo);

	/**
	 * 사원번호 또는 사원명으로 equal 검색
	 * @TestValues 	inqDvsn=;	inqNm=김;
	 */
	java.util.List<cigna.cm.a.io.CMA002SVC02Sub> selectMultiTBSLEMP001d(
			@Param("inqDvsn")
			java.lang.String inqDvsn, @Param("inqNm")
			java.lang.String inqNm);
}