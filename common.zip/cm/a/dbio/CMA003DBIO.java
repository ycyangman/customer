/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue Mar 07 17:07:44 KST 2017
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA003DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA003DBIO
{

	/**
	 * 영업일캘린더조회
	 * @TestValues 	inqStrtDt=20120801;	inqEndDt=20120831;	hldyKcd=01;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD005Io> selectMultiTBCMCCD005(
			@Param("inqStrtDt")
			java.lang.String inqStrtDt, @Param("inqEndDt")
			java.lang.String inqEndDt, @Param("hldyKcd")
			java.lang.String hldyKcd);

	/**
	 * 영업일캘린더수정
	 * @TestValues 	calendar.scalnDt=20150901;	calendar.lcalnDt=20150719;	calendar.lpmnYn=;	calendar.jlndt=;	calendar.wktms=;	calendar.dywkCd=;	calendar.hldyKcd=00;	calendar.hldyWkdayDcd=;	calendar.note=;	calendar.lastChgrId=test;	calendar.lastChgPgmId=test;	calendar.lastChgTrmNo=test;
	 */
	int updateOneTBCMCCD005(
			@Param("calendar")
			cigna.cm.a.io.TBCMCCD005Io calendar);

	/**
	 * N익영업일조회
	 * @TestValues 	inqDt=20120815;	inqDys=0;
	 */
	java.lang.String selectOneTBCMCCD005a(
			@Param("inqDt")
			java.lang.String inqDt, @Param("inqDys")
			int inqDys);

	/**
	 * N전영업일조회
	 * @TestValues 	inqDt=20120901;	inqDys=0;
	 */
	java.lang.String selectOneTBCMCCD005b(
			@Param("inqDt")
			java.lang.String inqDt, @Param("inqDys")
			int inqDys);

	/**
	 * 마지막영업일 조회
	 * @TestValues 	inqYm=201209;
	 */
	java.lang.String selectOneTBCMCCD005d(@Param("inqYm")
	java.lang.String inqYm);

	/**
	 * 첫영업일 조회, 첫영업일 + N 일 조회
	 * @TestValues 	inqYm=201209;	inqDys=0;
	 */
	java.lang.String selectOneTBCMCCD005c(@Param("inqYm")
			java.lang.String inqYm, @Param("inqDys")
			int inqDys);

	/**
	 * 영업일정보 조회
	 * @TestValues 	baseDt=20120901;
	 */
	cigna.cm.a.domain.SalesInfo selectOneTBCMCCD005e(@Param("baseDt")
	java.lang.String baseDt);

	/**
	 * 영업정보 N개월치
	 * @TestValues 	baseYm=201209;	inqMm=3;
	 */
	java.util.List<klaf.container.cache.data.SalesInfo> selectMultiTBCMCCD005a(
			@Param("baseYm")
			java.lang.String baseYm, @Param("inqMm")
			java.lang.Integer inqMm);

	/**
	 * N전영업일조회
	 * @TestValues 	inqDt=20120901;	inqDys=0;
	 */
	java.lang.String selectOneTBCMCCD005f(
			@Param("inqDt") java.lang.String inqDt, @Param("inqDys") int inqDys);
}