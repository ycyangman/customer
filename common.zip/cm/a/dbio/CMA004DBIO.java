/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue Jun 07 18:09:08 KST 2016
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA004DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA004DBIO
{

	/**
	 * @TestValues 	custNo=999999999;
	 */
	java.math.BigDecimal selectOneTBCSPRF006(
			@Param("custNo")
			java.lang.String custNo);

	/**
	 * @TestValues 	custNo=99999999;	custContLastNo=0000;	lastChgOrgNo=test;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int insertOneTBCSPRF006(cigna.cm.a.io.TBCSPRF006Io tBCSPRF006Io);

	/**
	 * @TestValues 	custNo=999999999;	custContLastNo=0001;	lastChgOrgNo=test;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int updateOneTBCSPRF006(cigna.cm.a.io.TBCSPRF006Io tBCSPRF006Io);

	/**
	 * @TestValues 	orgNo=666666;	rcptIsueDcd=1;
	 */
	java.math.BigDecimal selectOneTBCMCCD007(@Param("orgNo")
			java.lang.String orgNo, @Param("rcptIsueDcd")
			java.lang.String rcptIsueDcd);

	/**
	 * @TestValues 	orgNo=00000;	rcptIsueDcd=1;	rcptMknoNo=1;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int insertOneTBCMCCD007(cigna.cm.a.io.TBCMCCD007Io tBCMCCD007Io);

	/**
	 * @TestValues 	orgNo=666666;	rcptIsueDcd=1;	rcptMknoNo=2;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int updateOneTBCMCCD007(cigna.cm.a.io.TBCMCCD007Io tBCMCCD007Io);

	/**
	 * @TestValues 	payMknoDcd=PAPA;	mknoBaseVl=;
	 */
	java.math.BigDecimal selectOneTBCMCCD008(@Param("payMknoDcd")
			java.lang.String payMknoDcd, @Param("mknoBaseVl")
			java.lang.String mknoBaseVl);

	/**
	 * @TestValues 	payMknoDcd=PAPc;	mknoBaseVl=;	payMknoNo=1;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int insertOneTBCMCCD008(cigna.cm.a.io.TBCMCCD008Io tBCMCCD008Io);

	/**
	 * @TestValues 	payMknoDcd=PAPA;	mknoBaseVl=;	payMknoNo=1;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int updateOneTBCMCCD008(cigna.cm.a.io.TBCMCCD008Io tBCMCCD008Io);

	/**
	 * @TestValues 	comnMknoDcd=CMDF;	mknoYm=1209;
	 */
	java.math.BigDecimal selectOneTBCMCCD012(
			@Param("comnMknoDcd")
			java.lang.String comnMknoDcd, @Param("mknoYm")
			java.lang.String mknoYm);

	/**
	 * @TestValues 	comnMknoDcd=gggg;	mknoYm=1209;	comnMknoNo=1;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int insertOneTBCMCCD012(cigna.cm.a.io.TBCMCCD012Io tBCMCCD012Io);

	/**
	 * @TestValues 	comnMknoDcd=CMDF;	mknoYm=1209;	comnMknoNo=10;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int updateOneTBCMCCD012(cigna.cm.a.io.TBCMCCD012Io tBCMCCD012Io);
}