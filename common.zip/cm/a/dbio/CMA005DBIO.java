package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA005DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA005DBIO
{

	/**
	 * 파일관리 목록조회
	 * @TestValues 	fileMgntNo=FICM1301000000000001;	file_mgnt_no_prcs_yn=Y;
	 */
	java.util.List<cigna.cm.a.io.CMA005SVC00Sub> selectMultiTBCMCCD016(@Param("fileMgntNo")
	java.lang.String fileMgntNo, @Param("file_mgnt_no_prcs_yn")
	java.lang.String file_mgnt_no_prcs_yn);

	/**
	 * 파일관리상세 일련번호 MAX값 조회
	 * @TestValues 	fileMgntNo=;
	 */
	java.lang.Integer selectOneTBCMCCD017(@Param("fileMgntNo")
	java.lang.String fileMgntNo);

	/**
	 * 파일관리 파일정보 등록
	 * @TestValues 	fileMgntNo=test;	fileMgntBzCd=cm;	filePathNm=test;	fileRegDt=20121130;	fileRegEno=000000;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int insertOneTBCMCCD016(cigna.cm.a.io.TBCMCCD016Io tBCMCCD016Io);

	/**
	 * 파일관리 파일상세정보 등록
	 * @TestValues 	fileMgntNo=test;	fileSeq=;	atchOrgcpFileNm=test;	atchSavFileNm=test;	lastChgrId=test;	lastChgPgmId=test;	lastChgTrmNo=test;
	 */
	int insertOneTBCMCCD017(cigna.cm.a.io.TBCMCCD017Io tBCMCCD017Io);

	/**
	 * 파일삭제처리
	 * @TestValues 	fileMgntNo=;	fileSeq=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMCCD017(@Param("fileMgntNo")
	java.lang.String fileMgntNo, @Param("fileSeq")
	java.lang.Integer fileSeq, @Param("lastChgrId")
	java.lang.String lastChgrId, @Param("lastChgPgmId")
	java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
	java.lang.String lastChgTrmNo);

	/**
	 * @TestValues 	fileMgntNo=FICM12000000000002;	fileSeq=1;
	 */
	cigna.cm.a.io.CMA005SVC02In selectOneTBCMCCD016(@Param("fileMgntNo")
			java.lang.String fileMgntNo, @Param("fileSeq")
			java.lang.Integer fileSeq);

	/**
	 * 파일관리번호처리여부
	 * @TestValues 	fileMgntNo=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMCCD016(@Param("fileMgntNo")
			java.lang.String fileMgntNo, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo);
}