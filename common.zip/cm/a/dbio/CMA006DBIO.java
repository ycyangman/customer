package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA006DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA006DBIO
{

	/**
	 * @TestValues 	xlsSecuSancMgntNo=9999;	bzCd=99;	xlsSecuSancStcd=;	scrnId=9;	scrnNm=9;	sancReqEno=9;	sancReqDt=;	sancReqTi=;	sancEno=9;	sancDt=;	sancTi=;	aprvReqRsnCtnt=9;	sancTndwRsnCtnt=;	scrnSecuGcd=9;	dataMaskYn=9;	xlsFileNm=a;	dwldPrdStrtDt=9;	dwldPrdEndDt=9;	lastChgrId=9;	lastChgPgmId=9;	lastChgTrmNo=9;
	 */
	int insertOneTBCMCCD018(cigna.cm.a.io.TBCMCCD018Io tBCMCCD018Io);

	/**
	 * @TestValues 	xlsSecuSancMgntNo=;	xlsFileCtnt=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD019(cigna.cm.a.io.TBCMCCD019Io tBCMCCD019Io);

	/**
	 * @TestValues 	xlsSecuSancMgntNo=;	bzCd=;	xlsSecuSancStcd=;	scrnId=;	scrnNm=;	sancReqEno=;	sancReqDt=;	sancReqTi=;	sancEno=;	sancDt=;	sancTi=;	aprvReqRsnCtnt=;	sancTndwRsnCtnt=;	scrnSecuGcd=;	dataMaskYn=;	dwldPrdStrtDt=;	dwldPrdEndDt=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMCCD018(cigna.cm.a.io.TBCMCCD018Io tBCMCCD018Io);

	/**
	 * @TestValues 	xlsSecuSancMgntNo=;
	 */
	int deleteOneTBCMCCD019(@Param("xlsSecuSancMgntNo")
	java.lang.String xlsSecuSancMgntNo);

	/**
	 * @TestValues 	eno=0000358435;	pageNum=25;	pageCount=1;	contInfo.sancReqStrtDt=20121213;	contInfo.sancReqEndDt=20121220;	contInfo.sancStrtDt=;	contInfo.sancEndDt=;	contInfo.xlsSecuSancStcd=;	contInfo.orgNo=;	contInfo.sancReqEno=;	contInfo.sancEno=;	contInfo.scrnId=;	contInfo.scrnNm=;	contInfo.xlsFileNm=;	contInfo.pageNum=;	contInfo.pageCount=;
	 */
	java.util.List<cigna.cm.a.io.CMA006SVC02Sub1> selectMultiTBCMCCD018(@Param("eno")
	java.lang.String eno, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount, @Param("contInfo")
	cigna.cm.a.io.CMA006SVC02Sub0 contInfo);

	/**
	 * @TestValues 	orgNo=D00001;
	 */
	cigna.cm.a.io.CMA006SVC03Out selectOneTBSLEMP001(@Param("orgNo")
	java.lang.String orgNo);

	/**
	 * @TestValues 	xlsSecuSancMgntNo=APCM1212000000000008;
	 */
	cigna.cm.a.io.CMA006SVC04Sub selectOneTBCMCCD019(
			@Param("xlsSecuSancMgntNo")
			java.lang.String xlsSecuSancMgntNo);
}