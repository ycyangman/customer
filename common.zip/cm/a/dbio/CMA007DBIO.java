/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Thu Dec 01 19:53:19 KST 2016
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA007DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA007DBIO
{

	/**
	 * @TestValues 	eno=1;	ipAddr=1;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int mergeOneTBCMCCD023(@Param("eno")
	java.lang.String eno, @Param("ipAddr")
	java.lang.String ipAddr, @Param("lastChgrId")
	java.lang.String lastChgrId, @Param("lastChgPgmId")
	java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
	java.lang.String lastChgTrmNo);

	/**
	 * @TestValues 	eno=1;	ipAddr=1;	trmsDt=;	trmsTi=;	tgmTrmsTypVl=1;	tgmTitlCtnt=1;	tgmCtnt=1;	scrnNo=;	atchFilePathNm=;	atchSavFileNm=;	trmsSuccYn=1;	errCtnt=1;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int insertOneTBCMCCD024(cigna.cm.a.io.TBCMCCD024Io tBCMCCD024Io);

	/**
	 * @TestValues 	eno=1;
	 */
	java.lang.String selectOneTBCMCCD023(@Param("eno")
	java.lang.String eno);

	/**
	 * @TestValues 	scrnNo=;	eno=;	ipAddr=;	trmsStrtDt=20130605;	trmsEndDt=20130605;	pageNum=1;	pageCount=10;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD024Out> selectMultiTBCMCCD024(
			@Param("scrnNo")
			java.lang.String scrnNo, @Param("eno")
			java.lang.String eno, @Param("ipAddr")
			java.lang.String ipAddr, @Param("trmsStrtDt")
			java.lang.String trmsStrtDt, @Param("trmsEndDt")
			java.lang.String trmsEndDt, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount);

	/**
	 * @TestValues 	pssvcTrmsNo=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMCCD024(@Param("pssvcTrmsNo")
	java.math.BigDecimal pssvcTrmsNo, @Param("lastChgrId")
	java.lang.String lastChgrId, @Param("lastChgPgmId")
	java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
	java.lang.String lastChgTrmNo);

	/**
	 * @TestValues 	glblId=11;
	 */
	cigna.cm.a.io.CMA007SVC03Sub selectOneFBATCHJOBEXECUTION(
			@Param("glblId")
			java.lang.String glblId);

	/**
	 * @TestValues 	pssvcTrmsNo=;
	 */
	cigna.cm.a.io.CMA007SVC04In selectOneTBCMCCD024(
			@Param("pssvcTrmsNo")
			java.lang.Integer pssvcTrmsNo);

	/**
	 * 처리결과 최근조회
	 * @TestValues 	trmsDt=20161117;	eno=1A16011034;	ipAddr=;	scrnNo=;
	 */
	cigna.cm.a.io.SelectMultiTBCMCCD024Out selectOneTBCMCCD024a(@Param("trmsDt")
			java.lang.String trmsDt, @Param("eno")
			java.lang.String eno, @Param("ipAddr")
			java.lang.String ipAddr, @Param("scrnNo")
			java.lang.String scrnNo);
}