/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Wed Nov 30 11:52:05 KST 2016
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA008DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA008DBIO
{

	/**
	 * 사이버첨부파일정보 등록
	 * @TestValues 	urlMgntNo=;	seq=;	bzCd=;	urlNm=;	urlCtnt=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD020(cigna.cm.a.io.TBCMCCD020Io tBCMCCD020Io);

	/**
	 * URL관리 목록조회
	 * @TestValues 	urlMgntNo=1;
	 */
	java.util.List<cigna.cm.a.io.CMA008SVC00Sub> selectMultiTBCMCCD020(
			@Param("urlMgntNo")
			java.lang.String urlMgntNo);

	/**
	 * @TestValues 	urlMgntNo=1;	seq=1;
	 */
	cigna.cm.a.io.CMA008SVC01Sub selectOneTBCMCCD020(
			@Param("urlMgntNo")
			java.lang.String urlMgntNo, @Param("seq")
			java.lang.Integer seq);

	/**
	 * URL관리 단건논리삭제
	 * @TestValues 	urlMgntNo=;	seq=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMCCD020(@Param("urlMgntNo")
	java.lang.String urlMgntNo, @Param("seq")
	java.lang.Integer seq, @Param("lastChgrId")
	java.lang.String lastChgrId, @Param("lastChgPgmId")
	java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
	java.lang.String lastChgTrmNo);

	/**
	 * URL관리삭제
	 * @TestValues 	urlMgntNo=;
	 */
	int deleteMultiTBCMCCD020(@Param("urlMgntNo")
	java.lang.String urlMgntNo);
}