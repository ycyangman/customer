/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Wed Sep 25 16:49:42 KST 2013
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA009DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA009DBIO
{

	/**
	 * @TestValues 	trrvStrtDt=;	trrvEndDt=;	ifId=;	trrvStrtEno=;	fepFileTrmsStcd=;	pageNum=1;	pageCount=10;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD029Io> selectMultiTBCMCCD029a(
			@Param("trrvStrtDt")
			java.lang.String trrvStrtDt, @Param("trrvEndDt")
			java.lang.String trrvEndDt, @Param("ifId")
			java.lang.String ifId, @Param("trrvStrtEno")
			java.lang.String trrvStrtEno, @Param("fepFileTrmsStcd")
			java.lang.String fepFileTrmsStcd, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount);

	/**
	 * @TestValues 	fepIfBatMapp.ifId=12345678901234567890;	fepIfBatMapp.runShllNm=1122334455;	fepIfBatMapp.appNm=appName;	fepIfBatMapp.runJbsId=jobName;	fepIfBatMapp.parm1Vl=;	fepIfBatMapp.parm2Vl=;	fepIfBatMapp.parm3Vl=;	fepIfBatMapp.parm4Vl=;	fepIfBatMapp.parm5Vl=;	fepIfBatMapp.lastChgrId=12;	fepIfBatMapp.lastChgPgmId=34;	fepIfBatMapp.lastChgTrmNo=56;
	 */
	int mergeOneTBCMCCD031(
			@Param("fepIfBatMapp")
			cigna.cm.a.io.TBCMCCD031Io fepIfBatMapp);

	/**
	 * @TestValues 	ifId=12123434;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD031Io> selectMultiTBCMCCD031a(
			@Param("ifId")
			java.lang.String ifId);

	/**
	 * @TestValues 	glblId=;	ifTrmsKcd=;	ifTrrvDcd=;	ifId=;	loclFileNm=;	rmotFileNm=;	shllAllPathNm=;	shllParmVl=;	baseDt=;	fileTms=;	trrvStrtDtm=;	trrvEndDtm=;	trrvStrtEno=;	trrvEndEno=;	fepFileTrmsStcd=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD029(cigna.cm.a.io.TBCMCCD029Io tBCMCCD029Io);

	/**
	 * @TestValues 	glblId=;	ifTrmsKcd=;	ifTrrvDcd=;	ifId=;	loclFileNm=;	rmotFileNm=;	shllAllPathNm=;	shllParmVl=;	baseDt=;	fileTms=;	trrvStrtDtm=;	trrvEndDtm=;	trrvStrtEno=;	trrvEndEno=;	fepFileTrmsStcd=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMCCD029(cigna.cm.a.io.TBCMCCD029Io tBCMCCD029Io);

	/**
	 * @TestValues 	glblId=;	trmsGlblId=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD030(cigna.cm.a.io.TBCMCCD030Io tBCMCCD030Io);

	/**
	 * @TestValues 	ifId=;
	 */
	cigna.cm.a.io.TBCMCCD031Io selectOneTBCMCCD031a(@Param("ifId")
	java.lang.String ifId);

	/**
	 * @TestValues 	glblId=;	ifTrmsKcd=;	ifTrrvDcd=;	ifId=;	loclFileNm=;	rmotFileNm=;	shllAllPathNm=;	shllParmVl=;	baseDt=;	fileTms=;	trrvStrtDtm=;	trrvEndDtm=;	trrvStrtEno=;	trrvEndEno=;	fepFileTrmsStcd=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int mergeOneTBCMCCD029(cigna.cm.a.io.TBCMCCD029Io tBCMCCD029Io);

	/**
	 * @TestValues 	ifId=;
	 */
	int deleteOneTBCMCCD031(@Param("ifId")
	java.lang.String ifId);
}