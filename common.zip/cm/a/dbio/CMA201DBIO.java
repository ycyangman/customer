/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Mon Apr 03 17:17:03 KST 2017
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA201DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA201DBIO
{

	/**
	 * 사원연락처 조회
	 * @TestValues 	eno=0001320016;
	 */
	java.lang.String selectOneTBCSPRF001a(@Param("eno")
	java.lang.String eno);

	/**
	 * 사원 고객번호 조회
	 * @TestValues 	eno=9501031283;
	 */
	java.lang.String selectOneTBCSPRF001b(@Param("eno")
	java.lang.String eno);

	/**
	 * 고객번호 고객식별번호조회
	 * @TestValues 	custNo=000314375;
	 */
	java.lang.String selectOneTBCSPRF001c(
			@Param("custNo")
			java.lang.String custNo);

	/**
	 * @TestValues 	custDscNo=7609271024QF5M47AQ64NMQI0eCr6i92vK;
	 */
	cigna.cm.a.io.TBCSPRF001Io selectOneTBCSPRF001d(
			@Param("custDscNo")
			java.lang.String custDscNo);

	/**
	 * 공통, 조직번호로 사원연락처 조회
	 * @TestValues 	orgNo=000022;
	 */
	java.util.List<cigna.cm.a.io.TBCSPRF001Io> selectMultiTBCSPRF001a(@Param("orgNo")
	java.lang.String orgNo);
}