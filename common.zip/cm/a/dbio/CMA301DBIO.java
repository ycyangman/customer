package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA301DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA301DBIO
{

	/**
	 * @TestValues 	eno=;
	 */
	java.lang.String selectOneTBCMCCD021(@Param("eno")
	java.lang.String eno);
}