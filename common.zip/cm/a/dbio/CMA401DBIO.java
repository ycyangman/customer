/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Wed Sep 07 23:15:16 KST 2016
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA401DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA401DBIO
{

	/**
	 * @TestValues 	dfctMgntNo=D1200001;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD011Io> selectMultiTBCMCCD011(@Param("dfctMgntNo")
	java.lang.String dfctMgntNo);

	/**
	 * @TestValues 	cma401svc00in.inqStrtDt=20160901;	cma401svc00in.inqEndDt=20160930;	cma401svc00in.scrnId=;	cma401svc00in.scrnNm=;	cma401svc00in.regEno=;	cma401svc00in.regOrgNo=;	cma401svc00in.chrgpEno=;	cma401svc00in.chrgpOrgNo=;	cma401svc00in.dfctStcd=;	cma401svc00in.dfctTpcd=;	cma401svc00in.dfctPrfRnkCd=;	cma401svc00in.dfctTitlNm=;	cma401svc00in.testPhseNm=;	cma401svc00in.testPhseDifn=;	cma401svc00in.dfctMgntNo=;	cma401svc00in.expStrtDt=;	cma401svc00in.expEndDt=;	cma401svc00in.pageNum=;	cma401svc00in.pageCount=;	cma401svc00in.inqAuth=;	dfctPrfRnkCd=;	expStrtDt=;	expEndDt=;	pageNum=1;	pageCount=10;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD010Io> selectMultiTBCMCCD010(@Param("cma401svc00in")
	cigna.cm.a.io.CMA401SVC00In cma401svc00in, @Param("dfctPrfRnkCd")
	java.lang.String dfctPrfRnkCd, @Param("expStrtDt")
	java.lang.String expStrtDt, @Param("expEndDt")
	java.lang.String expEndDt, @Param("pageNum")
	int pageNum, @Param("pageCount")
	int pageCount);

	/**
	 * @TestValues 	dfctMgntNo=9999;	scrnId=1;	scrnNm=1;	regEno=1;	regEnoNm=;	regOrgNo=1;	regOrgNoNm=;	dfctRegpTeldno=1;	dfctRegpTelsno=1;	dfctRegpTelino=1;	dfctRegDt=1;	reqPrcsHopeDt=1;	chrgpEno=1;	chrgpEnoNm=;	chrgpOrgNo=1;	chrgpOrgNoNm=;	dfctChrgpTeldno=1;	dfctChrgpTelsno=1;	dfctChrgpTelino=1;	dfctStcd=1;	dfctTpcd=1;	dfctPrfRnkCd=;	dfctPrcsExpDt=1;	dfctPrcsCmptDt=1;	dfctTitlNm=1;	dfctCtnt=1;	dfctCausCtnt=1;	dfctPrcsRstCtnt=1;	smsSndYn=;	fileMgntNo=1;	testPhseNm=1;	testPhseDifn=1;	delYn=;	lastChgDtm=;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;	trtmCsmgDys=;	testDfctUserId=;	fileNewYn=;
	 */
	int insertOneTBCMCCD010(cigna.cm.a.io.TBCMCCD010Io tBCMCCD010Io);

	/**
	 * @TestValues 	dfctMgntNo=999;	dfctHisSeq=;	dfctCtnt=1;	dfctCausCtnt=1;	dfctPrcsRstCtnt=1;	regEno=1;	regEnoNm=;	regDt=1;	reqPrcsHopeDt=1;	dfctPrcsExpDt=1;	dfctStcd=1;	dfctTpcd=1;	delYn=;	lastChgDtm=;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int insertOneTBCMCCD011(cigna.cm.a.io.TBCMCCD011Io tBCMCCD011Io);

	/**
	 * @TestValues 	dfctMgntNo=999999;	scrnId=;	scrnNm=;	regEno=;	regEnoNm=;	regOrgNo=;	regOrgNoNm=;	dfctRegpTeldno=;	dfctRegpTelsno=;	dfctRegpTelino=;	dfctRegDt=;	reqPrcsHopeDt=;	chrgpEno=;	chrgpEnoNm=;	chrgpOrgNo=;	chrgpOrgNoNm=;	dfctChrgpTeldno=;	dfctChrgpTelsno=;	dfctChrgpTelino=;	dfctStcd=;	dfctTpcd=;	dfctPrfRnkCd=;	dfctPrcsExpDt=;	dfctPrcsCmptDt=;	dfctTitlNm=;	dfctCtnt=;	dfctCausCtnt=;	dfctPrcsRstCtnt=;	smsSndYn=;	fileMgntNo=;	testPhseNm=;	testPhseDifn=;	delYn=;	lastChgDtm=;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;	trtmCsmgDys=;	testDfctUserId=;	fileNewYn=;
	 */
	int updateOneTBCMCCD010(cigna.cm.a.io.TBCMCCD010Io tBCMCCD010Io);

	/**
	 * @TestValues 	dfctMgntNo=;
	 */
	cigna.cm.a.io.TBCMCCD013Io selectOneTBCMCCD013(
			@Param("dfctMgntNo")
			java.lang.String dfctMgntNo);

	/**
	 * @TestValues 	dfctMgntNo=999;	dfctImgCtnt=;	lastChgrId=3;	lastChgPgmId=3;	lastChgTrmNo=3;
	 */
	int insertOneTBCMCCD013(cigna.cm.a.io.TBCMCCD013Io tBCMCCD013Io);

	/**
	 * @TestValues 	cma401svc00in.inqStrtDt=;	cma401svc00in.inqEndDt=;	cma401svc00in.scrnId=;	cma401svc00in.scrnNm=;	cma401svc00in.regEno=;	cma401svc00in.regOrgNo=;	cma401svc00in.chrgpEno=;	cma401svc00in.chrgpOrgNo=;	cma401svc00in.dfctStcd=;	cma401svc00in.dfctTpcd=;	cma401svc00in.dfctPrfRnkCd=;	cma401svc00in.dfctTitlNm=;	cma401svc00in.testPhseNm=;	cma401svc00in.testPhseDifn=;	cma401svc00in.dfctMgntNo=;	cma401svc00in.expStrtDt=;	cma401svc00in.expEndDt=;	cma401svc00in.pageNum=;	cma401svc00in.pageCount=;	cma401svc00in.inqAuth=;	dfctPrfRnkCd=;	expStrtDt=;	expEndDt=;	pageNum=0;	pageCount=0;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD010Io> selectMultiTBCMCCD010a(
			@Param("cma401svc00in")
			cigna.cm.a.io.CMA401SVC00In cma401svc00in, @Param("dfctPrfRnkCd")
			java.lang.String dfctPrfRnkCd, @Param("expStrtDt")
			java.lang.String expStrtDt, @Param("expEndDt")
			java.lang.String expEndDt, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount);
}