/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue May 03 14:34:36 KST 2016
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA501DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA501DBIO
{

	/**
	 * @TestValues 	roleNm=;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD025Out> selectMultiTBCMCCD025a(@Param("roleNm")
	java.lang.String roleNm);

	/**
	 * @TestValues 	roleDscNo=23749;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD026Out> selectMultiTBCMCCD026a(@Param("roleDscNo")
	java.lang.String roleDscNo);

	/**
	 * @TestValues 	sysEmplRoleApplNo=;	applEno=;	roleAdptEno=;	roleAdptStrtDt=;	roleAdptEndDt=;	aprvPrcsRcd=;	applDt=;	roleApplCtnt=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD035(cigna.cm.a.io.TBCMCCD035Io tBCMCCD035Io);

	/**
	 * @TestValues 	sysEmplRoleApplNo=;	roleDscNo=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD036(cigna.cm.a.io.TBCMCCD036Io tBCMCCD036Io);

	/**
	 * @TestValues 	roleAdptEno=;	applStrtDt=20130809;	applEndDt=20130809;	applEno=;	orgNo=;	roleAdptDt=;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD035aOut> selectMultiTBCMCCD035a(
			@Param("roleAdptEno")
			java.lang.String roleAdptEno, @Param("applStrtDt")
			java.lang.String applStrtDt, @Param("applEndDt")
			java.lang.String applEndDt, @Param("applEno")
			java.lang.String applEno, @Param("orgNo")
			java.lang.String orgNo, @Param("roleAdptDt")
			java.lang.String roleAdptDt);

	java.lang.Integer selectOneTBCMCCD035();

	/**
	 * @TestValues 	pswdInitlObjEno=;	applStrtDt=;	applEndDt=;	applEno=;	orgNo=;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD037Out> selectMultiTBCMCCD037(
			@Param("pswdInitlObjEno")
			java.lang.String pswdInitlObjEno, @Param("applStrtDt")
			java.lang.String applStrtDt, @Param("applEndDt")
			java.lang.String applEndDt, @Param("applEno")
			java.lang.String applEno, @Param("orgNo")
			java.lang.String orgNo);

	/**
	 * @TestValues 	ssoPswdInitlApplNo=;	applEno=;	pswdInitlObjEno=;	applCtnt=;	applDt=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD037(cigna.cm.a.io.TBCMCCD037Io tBCMCCD037Io);

	/**
	 * @TestValues 	spstEnoApplNo=1;	applEno=2;	spstEmplRrno=3;	spstEmplNm=4;	spstEmplBlntOrgNo=5;	enoVldStrtDt=6;	enoVldEndDt=7;	applDt=8;	lastChgrId=9;	lastChgPgmId=1;	lastChgTrmNo=2;
	 */
	int insertOneTBCMCCD038(cigna.cm.a.io.TBCMCCD038Io tBCMCCD038Io);

	/**
	 * @TestValues 	spstEmplRrno=;	spstEmplNm=;	spstEmplBlntOrgNo=;	applStrtDt=;	applEndDt=;	applEno=;	orgNo=;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD038Out> selectMultiTBCMCCD038(
			@Param("spstEmplRrno")
			java.lang.String spstEmplRrno, @Param("spstEmplNm")
			java.lang.String spstEmplNm, @Param("spstEmplBlntOrgNo")
			java.lang.String spstEmplBlntOrgNo, @Param("applStrtDt")
			java.lang.String applStrtDt, @Param("applEndDt")
			java.lang.String applEndDt, @Param("applEno")
			java.lang.String applEno, @Param("orgNo")
			java.lang.String orgNo);
}