/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Thu Mar 17 10:03:26 KST 2016
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;
import klaf.container.das.DasHistory;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA801DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA801DBIO
{

	/**
	 * @TestValues 	pageNum=1;	pageCount=30;	chrgpEno=1000111485;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMETC003aOut> selectMultiTBCMETC003a(@Param("pageNum")
	int pageNum, @Param("pageCount")
	int pageCount, @Param("chrgpEno")
	java.lang.String chrgpEno);

	/**
	 * @TestValues 	detlBzMgntNo=;	fileMgntNo=;	fileSeq=;	fileStrgExpiDt=;	fileStrgDys=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMETC003a(cigna.cm.a.io.TBCMETC003Io tBCMETC003Io);

	/**
	 * @TestValues 	detlBzMgntNo=1;	chrgpEno=1000111485;	detlBzMgrYn=Y;	delYn=N;	lastChgDtm=;	lastChgrId=1000111485;	lastChgPgmId=CMA801SVC;	lastChgTrmNo=10.3.13.215;
	 */
	int insertOneTBCMETC004a(cigna.cm.a.io.TBCMETC004Io tBCMETC004Io);

	/**
	 * @TestValues 	detlBzMgntNo=1;	detlBzNm=1;	extrnInstNm=1;	delYn=y;	detlBzMgrYn=;	chrgEno=;	emplNm=;	blntOrgNo=;	orgNm=;	lastChgDtm=;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int insertOneTBCMETC005a(cigna.cm.a.io.TBCMETC005Io tBCMETC005Io);

	/**
	 * @TestValues 	detlBzMgntNo=100;	chrgpEno=1000111485;	detlBzMgrYn=Y;
	 */
	cigna.cm.a.io.TBCMETC005Io selectOneTBCMETC005a(@Param("detlBzMgntNo")
	int detlBzMgntNo, @Param("chrgpEno")
	java.lang.String chrgpEno, @Param("detlBzMgrYn")
	java.lang.String detlBzMgrYn);

	/**
	 * @TestValues 	chrgpEno=1000111485;	detlBzMgntNo=100;
	 */
	cigna.cm.a.io.TBCMETC004Io selectOneTBCMETC004a(@Param("chrgpEno")
	java.lang.String chrgpEno, @Param("detlBzMgntNo")
	int detlBzMgntNo);

	/**
	 * @TestValues 	chrgEno=1000111485;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMETC004bOut> selectMultiTBCMETC003b(@Param("chrgEno")
	java.lang.String chrgEno);

	/**
	 * @TestValues 	chrgpEno=1000111485;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMETC005bOut> selectOneTBCMETC005b(@Param("chrgpEno")
	java.lang.String chrgpEno);

	java.math.BigDecimal selectLockTBCMETC005c();

	/**
	 * @TestValues 	detlBzMgntNo=100;
	 */
	cigna.cm.a.io.TBCMETC004Io selectOneTBCMETC004b(
			@Param("detlBzMgntNo")
			int detlBzMgntNo);

	/**
	 * @TestValues 	detlBzMgntNo=10;	fileMgntNo=ABCD;	fileSeq=1;
	 */
	int deleteOneTBCMETC003a(
			@Param("detlBzMgntNo")
			java.lang.Integer detlBzMgntNo, @Param("fileMgntNo")
			java.lang.String fileMgntNo, @Param("fileSeq")
			java.lang.Integer fileSeq);

	/**
	 * @TestValues 	chrgpEno=1000111485;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMETC005bOut> selectMultiTBCMETC005c(
			@Param("chrgpEno")
			java.lang.String chrgpEno);

	/**
	 * @TestValues 	detlBzMgntNo=10;	chrgpEno=1000111485;
	 */
	int deleteOneTBCMETC004a(
			@Param("detlBzMgntNo")
			java.lang.Integer detlBzMgntNo, @Param("chrgpEno")
			java.lang.String chrgpEno);

	/**
	 * @TestValues 	detlBzMgntNo=10;
	 */
	int deleteOneTBCMETC005a(
			@Param("detlBzMgntNo")
			java.lang.Integer detlBzMgntNo);

	/**
	 * @TestValues 	detlBzMgntNo=19;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMETC003aOut> selectMultiTBCMETC003c(
			@Param("detlBzMgntNo")
			int detlBzMgntNo);

	/**
	 * @TestValues 	detlBzMgntNo=1;	chrgpEno=1000111485;
	 */
	cigna.cm.a.io.TBCMETC004Io selectOneTBCMETC004c(
			@Param("detlBzMgntNo")
			int detlBzMgntNo, @Param("chrgpEno")
			java.lang.String chrgpEno);
}