/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue Jan 28 17:56:34 KST 2014
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA901DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA901DBIO
{

	java.math.BigDecimal selectOneTBCMCCD041();

	/**
	 * @TestValues 	wrkSeq=;	scrnId=;	scrnNm=;	blntOrgNo=;	eno=;	swtDtm=;	xlsSwtRowsNum=;	ipAddr=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD041(cigna.cm.a.io.TBCMCCD041Io tBCMCCD041Io);
}