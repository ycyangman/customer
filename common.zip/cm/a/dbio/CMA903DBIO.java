/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue Mar 24 13:53:33 KST 2015
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import klaf.container.das.DasListUpdate;
import klaf.container.das.DasExecutor;
import klaf.container.das.ExecutorType;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA903DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA903DBIO
{

	/**
	 * @TestValues 	ldgrChgReqItsmRegId=111;	ldgrChgCtntInputDtm=20150323;	ldgrTbEngNm=1234;	chgWrkDcd=1111;	chgBfafDcd=1111;	ldgrChgCtntSeq=1;	ldgrChgCtntDtlSeq=111;	ldgrChgCtnt=11;	ldgrChgColEngNm=11;	delYn=1;	lastChgDtm=;	lastChgrId=11;	lastChgPgmId=1;	lastChgTrmNo=11;
	 */
	int insertOneTBCMETC006(cigna.cm.a.io.TBCMETC006Io tBCMETC006Io);
}