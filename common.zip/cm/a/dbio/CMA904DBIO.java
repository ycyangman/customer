/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue Mar 24 15:27:49 KST 2015
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMA904DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMA904DBIO
{

	/**
	 * @TestValues 	ldgrChgReqItsmRegId=1;	ldgrChgCtntInputDtm=1;	ldgrTbEngNm=1;	chgWrkDcd=1;	chgBfafDcd=1;	ldgrChgColEngNm=1;	filePathNm=1;	ldgrChgCtntFileNm=1;	delYn=1;	lastChgDtm=;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int insertOneTBCMETC007(cigna.cm.a.io.TBCMETC007Io tBCMETC007Io);

	/**
	 * @TestValues 	lastChgrId=3;	lastChgPgmId=4;	ldgrChgReqItsmRegId=T1401020048;	ldgrChgColEngNm=9;	lastChgTrmNo=TEST;
	 */
	int updateOneTBCMETC007(@Param("lastChgrId")
	java.lang.String lastChgrId, @Param("lastChgPgmId")
	java.lang.String lastChgPgmId, @Param("ldgrChgReqItsmRegId")
	java.lang.String ldgrChgReqItsmRegId, @Param("ldgrChgColEngNm")
	java.lang.String ldgrChgColEngNm, @Param("lastChgTrmNo")
	java.lang.String lastChgTrmNo);

	/**
	 * @TestValues 	ldgrTbEngNm=1;	ldgrChgCtntInputDtm=2;	ldgrChgReqItsmRegId=3;	chgBfafDcd=4;	chgWrkDcd=5;
	 */
	int deleteOneTBCMETC007(@Param("ldgrTbEngNm")
			java.lang.String ldgrTbEngNm, @Param("ldgrChgCtntInputDtm")
			java.lang.String ldgrChgCtntInputDtm, @Param("ldgrChgReqItsmRegId")
			java.lang.String ldgrChgReqItsmRegId, @Param("chgBfafDcd")
			java.lang.String chgBfafDcd, @Param("chgWrkDcd")
			java.lang.String chgWrkDcd);

	/**
	 * @TestValues 	ldgrChgReqItsmRegId=3;
	 */
	cigna.cm.a.io.TBCMETC007Io selectOneTBCMETC007(
			@Param("ldgrChgReqItsmRegId")
			java.lang.String ldgrChgReqItsmRegId);
}