/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Thu Oct 10 18:05:29 KST 2013
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMAZ00DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMAZ00DBIO
{

	/**
	 * @TestValues 	scrnNo=000000;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD006Io> selectMultiTBCMCCD006a(@Param("scrnNo")
	java.lang.String scrnNo);

	/**
	 * @TestValues 	scrnNo=;	connScrnNo=;
	 */
	int deleteOneTBCMCCD006(@Param("scrnNo")
	java.lang.String scrnNo, @Param("connScrnNo")
	java.lang.String connScrnNo);

	/**
	 * @TestValues 	scrnNo=;	pageNum=500;	pageCount=1;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD006bOut> selectMultiTBCMCCD006b(@Param("scrnNo")
	java.lang.String scrnNo, @Param("pageNum")
	int pageNum, @Param("pageCount")
	int pageCount);

	/**
	 * @TestValues 	scrnNoInfo.scrnNo=aa;	scrnNoInfo.connScrnNo=aa;	scrnNoInfo.connScrnParmYn=1;	scrnNoInfo.prntSeq=1;	scrnNoInfo.connScrnGrpDcd=;	scrnNoInfo.lastChgrId=aa;	scrnNoInfo.lastChgPgmId=aa;	scrnNoInfo.lastChgTrmNo=aa;
	 */
	int mergeOneTBCMCCD006(@Param("scrnNoInfo")
	cigna.cm.a.io.TBCMCCD006Io scrnNoInfo);

	java.lang.Integer selectOneTBCMCCD006();

	java.util.List<cigna.cm.a.io.TBCMCCD032Io> selectMultiTBCMCCD032a();

	/**
	 * @TestValues 	smryInfo.scrnId=CMAZ00P1;	smryInfo.scrnNm=테스트화면;	smryInfo.bzCd=CM;	smryInfo.smryInfoScrnTpcd=C;	smryInfo.imgVrtcVl=;	smryInfo.regEno=D000888261;	smryInfo.regDt=20130627;	smryInfo.lastChgrId=D000888261;	smryInfo.lastChgPgmId=11;	smryInfo.lastChgTrmNo=22;
	 */
	int mergeOneTBCMCCD032(
			@Param("smryInfo")
			cigna.cm.a.io.TBCMCCD032Io smryInfo);

	/**
	 * @TestValues 	scrnId=;
	 */
	int deleteOneTBCMCCD032(@Param("scrnId")
	java.lang.String scrnId);

	/**
	 * @TestValues 	mymenuInfo.eno=;	mymenuInfo.scrnId=;	mymenuInfo.sciconImgNm=;	mymenuInfo.menuNm=;	mymenuInfo.menuOrd=;	mymenuInfo.lastChgrId=;	mymenuInfo.lastChgPgmId=;	mymenuInfo.lastChgTrmNo=;
	 */
	int mergeOneTBCMCCD040(
			@Param("mymenuInfo")
			cigna.cm.a.io.TBCMCCD040Io mymenuInfo);

	/**
	 * @TestValues 	eno=;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD040Io> selectMultiTBCMCCD040(
			@Param("eno")
			java.lang.String eno);

	/**
	 * @TestValues 	eno=;	scrnId=;
	 */
	int deleteOneTBCMCCD040(@Param("eno")
			java.lang.String eno, @Param("scrnId")
			java.lang.String scrnId);
}