/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Mon Jul 04 12:14:18 KST 2016
 */
package cigna.cm.a.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/a/dbio/CMAZ01DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMAZ01DBIO
{

	/**
	 * @TestValues 	menuSysCd=01;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD033Io> selectMultiTBCMCCD033a(@Param("menuSysCd")
	java.lang.String menuSysCd);

	/**
	 * @TestValues 	menuInfo.menuMgntNo=;	menuInfo.menuMgntNoTmp=;	menuInfo.hrnkMenuMgntNo=;	menuInfo.menuSysCd=;	menuInfo.menuNm=;	menuInfo.menuDcd=;	menuInfo.menuGrpCd=;	menuInfo.menuLevVl=;	menuInfo.scrnId=;	menuInfo.scrnIdTmp=;	menuInfo.scrnNm=;	menuInfo.scrnTpcd=;	menuInfo.scrnUrlVl=;	menuInfo.rslnCd=;	menuInfo.bzProgPhseMarkYn=;	menuInfo.menuMarkYn=;	menuInfo.menuGcd=;	menuInfo.menuOrd=;	menuInfo.adptStrtDt=;	menuInfo.adptEndDt=;	menuInfo.delYn=;	menuInfo.lastChgrId=;	menuInfo.lastChgPgmId=;	menuInfo.lastChgTrmNo=;
	 */
	int mergeOneTBCMCCD033(
			@Param("menuInfo")
			cigna.cm.a.io.TBCMCCD033Io menuInfo);

	/**
	 * @TestValues 	menuMgntNo=;	menuMgntNoTmp=;	hrnkMenuMgntNo=;	menuSysCd=;	menuNm=;	menuDcd=;	menuGrpCd=;	menuLevVl=;	scrnId=;	scrnIdTmp=;	scrnNm=;	scrnTpcd=;	scrnUrlVl=;	rslnCd=;	bzProgPhseMarkYn=;	menuMarkYn=;	menuGcd=;	menuOrd=;	adptStrtDt=;	adptEndDt=;	delYn=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int mergeOneTBCMCCD034(cigna.cm.a.io.TBCMCCD033Io tBCMCCD033Io);

	/**
	 * @TestValues 	menuMgntNo=;
	 */
	int deleteOneTBCMCCD033(@Param("menuMgntNo")
	java.lang.String menuMgntNo);

	/**
	 * @TestValues 	menuMgntNo=;	menuMgntNoTmp=;	hrnkMenuMgntNo=;	menuSysCd=;	menuNm=;	menuDcd=;	menuGrpCd=;	menuLevVl=;	scrnId=;	scrnIdTmp=;	scrnNm=;	scrnTpcd=;	scrnUrlVl=;	rslnCd=;	bzProgPhseMarkYn=;	menuMarkYn=;	menuGcd=;	menuOrd=;	adptStrtDt=;	adptEndDt=;	delYn=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMCCD034(cigna.cm.a.io.TBCMCCD033Io tBCMCCD033Io);

	/**
	 * @TestValues 	menuSysCd=01;	menuGrpCd=NB;
	 */
	java.util.List<cigna.cm.a.io.TBCMCCD033Io> selectMultiTBCMCCD033b(@Param("menuSysCd")
	java.lang.String menuSysCd, @Param("menuGrpCd")
	java.lang.String menuGrpCd);

	/**
	 * @TestValues 	menuInfo.menuMgntNo=00000000010;	menuInfo.menuMgntNoTmp=;	menuInfo.hrnkMenuMgntNo=00000000008;	menuInfo.menuSysCd=01;	menuInfo.menuNm=UW심사;	menuInfo.menuDcd=9;	menuInfo.menuGrpCd=NB;	menuInfo.menuLevVl=4;	menuInfo.scrnId=NBE202M0;	menuInfo.scrnIdTmp=;	menuInfo.scrnNm=;	menuInfo.scrnTpcd=;	menuInfo.scrnUrlVl=;	menuInfo.rslnCd=Y;	menuInfo.bzProgPhseMarkYn=N;	menuInfo.menuMarkYn=1;	menuInfo.menuGcd=1;	menuInfo.menuOrd=2;	menuInfo.adptStrtDt=20160406;	menuInfo.adptEndDt=20160406;	menuInfo.delYn=;	menuInfo.lastChgrId=1600045000;	menuInfo.lastChgPgmId=CMAZ01SVC;	menuInfo.lastChgTrmNo=10.128.77.50;
	 */
	int mergeOneTBCMCCD033b(@Param("menuInfo")
	cigna.cm.a.io.TBCMCCD033Io menuInfo);

	/**
	 * UI 사용자별 메뉴조회
	 * @TestValues 	usrId=1500364000;	sysId=;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD033cOut> selectMultiTBCMCCD033c(@Param("usrId")
	java.lang.String usrId, @Param("sysId")
	java.lang.String sysId);

	/**
	 * 권한버튼 서비스
	 * @TestValues 	sysId=;	usrId=1500364000;	scrnId=CMA006M0;
	 */
	java.util.List<cigna.cm.a.io.SelectMultiTBCMCCD026Out> selectMultiTBCMCCD035(
			@Param("sysId")
			java.lang.String sysId, @Param("usrId")
			java.lang.String usrId, @Param("scrnId")
			java.lang.String scrnId);

	/**
	 * 메뉴업무그룹관리
	 */
	java.util.List<cigna.cm.a.io.CMAZ01SVC06Sub> selectMultiTBCMCCD038a();

	/**
	 * 메뉴업무그룹관리
	 * @TestValues 	menuGrpMgnt.menuBzGrpId=;	menuGrpMgnt.menuBzGrpNm=111;	menuGrpMgnt.sortOrd=1;	menuGrpMgnt.useYn=Y;	menuGrpMgnt.delYn=;	menuGrpMgnt.lastChgDtm=;	menuGrpMgnt.lastChgrId=1;	menuGrpMgnt.lastChgPgmId=1;	menuGrpMgnt.lastChgTrmNo=1;	menuGrpMgnt.chkYn=;
	 */
	int mergeOneTBCMCCD038(
			@Param("menuGrpMgnt")
			cigna.cm.a.io.CMAZ01SVC06Sub menuGrpMgnt);
}