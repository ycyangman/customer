/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Mon Nov 05 13:00:37 KST 2012
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName EmplInfo
 * @Description 
 */
public class CommEmplInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = -793211116L;
	/**
	 * @Type java.lang.String
	 * @Name eno
	 * @Description 사원번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String eno;
	/**
	 * @Type java.lang.String
	 * @Name emplNm
	 * @Description 사원명
	 * @Length 40
	 * @Decimal 0
	 */
	private java.lang.String emplNm;
	/**
	 * @Type java.lang.String
	 * @Name emplTpcd
	 * @Description 사원유형코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String emplTpcd;
	/**
	 * @Type java.lang.String
	 * @Name emplKcd
	 * @Description 사원종류코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String emplKcd;
	/**
	 * @Type java.lang.String
	 * @Name jbdtyCd
	 * @Description 직책코드
	 * @Length 4
	 * @Decimal 0
	 */
	private java.lang.String jbdtyCd;
	/**
	 * @Type java.lang.String
	 * @Name ofrnkCd
	 * @Description 직급코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String ofrnkCd;
	/**
	 * @Type java.lang.String
	 * @Name orgNo
	 * @Description 조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String orgNo;
	/**
	 * @Type java.lang.String
	 * @Name teamNo
	 * @Description 팀번호
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String teamNo;
	/**
	 * @Type java.lang.String
	 * @Name rtmtDt
	 * @Description 퇴직일자
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String rtmtDt;	
	/**
	 * @Type java.lang.String
	 * @Name agncyEmplTpcd
	 * @Description 대리점사원유형코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String agncyEmplTpcd;	
	/**
	 * @Type java.lang.String
	 * @Name orgNm
	 * @Description 조직명
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String orgNm;
	/**
	 * @Type java.lang.String
	 * @Name bzprtCd
	 * @Description 사업부문코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String bzprtCd;
	/**
	 * @Type java.lang.String
	 * @Name orgTpcd
	 * @Description 조직유형코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String orgTpcd;
	/**
	 * @Type java.lang.String
	 * @Name orgAttrCd
	 * @Description 조직속성코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String orgAttrCd;
	/**
	 * @Type java.lang.String
	 * @Name orgKcd
	 * @Description 조직종류코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String orgKcd;
	/**
	 * @Type java.lang.String
	 * @Name orgChrctCd
	 * @Description 조직특성코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String orgChrctCd;
	/**
	 * @Type java.lang.String
	 * @Name hqOrgNo
	 * @Description 본부조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String hqOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name hqOrgNm
	 * @Description 본부조직명
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String hqOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name dofOrgNo
	 * @Description 지점조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String dofOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name dofOrgNm
	 * @Description 지점조직명
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String dofOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name fofOrgNo
	 * @Description 영업소조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String fofOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name fofOrgNm
	 * @Description 영업소조직명
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String fofOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name plazaOrgNo
	 * @Description 플라자조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String plazaOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name plazaOrgNm
	 * @Description 플라자조직명
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String plazaOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name brnchOrgNo
	 * @Description 브랜치조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String brnchOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name brnchOrgNm
	 * @Description 브랜치조직명
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String brnchOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name propoDeptOrgNo
	 * @Description 발의부서조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String propoDeptOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name propoDeptOrgNm
	 * @Description 발의부서조직명
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String propoDeptOrgNm;		
	/**
	 * @Type java.lang.String
	 * @Name orgTelno
	 * @Description 조직대표전화번호
	 * @Length 14
	 * @Decimal 0
	 */
	private java.lang.String orgTelno;
	
	/**
	 * @Type java.lang.String
	 * @Name inlnNo
	 * @Description 내선번호
	 * @Length 4
	 * @Decimal 0
	 */
	private java.lang.String inlnNo;
	
	/**
	 * @Type java.lang.String
	 * @Name macAddr
	 * @Description MAC주소
	 * @Length 100
	 * @Decimal 0
	 */
	private java.lang.String macAddr;
	
	/**
	 * @Type java.lang.String
	 * @Name cpstnOrgNo
	 * @Description 겸직조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String cpstnOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name custNo
	 * @Description 겸직조직번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String custNo;
	
	/**
	 * GET 사원번호
	 */
	public java.lang.String getEno() {
		return this.eno;
	}

	/**
	 * SET 사원번호
	 */
	public void setEno(java.lang.String eno) {
		this.eno = eno;
	}

	/**
	 * GET 사원명
	 */
	public java.lang.String getEmplNm() {
		return this.emplNm;
	}

	/**
	 * SET 사원명
	 */
	public void setEmplNm(java.lang.String emplNm) {
		this.emplNm = emplNm;
	}

	/**
	 * GET 사원유형코드
	 */
	public java.lang.String getEmplTpcd() {
		return this.emplTpcd;
	}

	/**
	 * SET 사원유형코드
	 */
	public void setEmplTpcd(java.lang.String emplTpcd) {
		this.emplTpcd = emplTpcd;
	}

	/**
	 * GET 사원종류코드
	 */
	public java.lang.String getEmplKcd() {
		return this.emplKcd;
	}

	/**
	 * SET 사원종류코드
	 */
	public void setEmplKcd(java.lang.String emplKcd) {
		this.emplKcd = emplKcd;
	}

	/**
	 * GET 직책코드
	 */
	public java.lang.String getJbdtyCd() {
		return this.jbdtyCd;
	}

	/**
	 * SET 직책코드
	 */
	public void setJbdtyCd(java.lang.String jbdtyCd) {
		this.jbdtyCd = jbdtyCd;
	}

	/**
	 * GET 직급코드
	 */
	public java.lang.String getOfrnkCd() {
		return this.ofrnkCd;
	}

	/**
	 * SET 직급코드
	 */
	public void setOfrnkCd(java.lang.String ofrnkCd) {
		this.ofrnkCd = ofrnkCd;
	}

	/**
	 * GET 조직번호
	 */
	public java.lang.String getOrgNo() {
		return this.orgNo;
	}

	/**
	 * SET 조직번호
	 */
	public void setOrgNo(java.lang.String orgNo) {
		this.orgNo = orgNo;
	}

	/**
	 * GET 팀번호
	 */
	public java.lang.String getTeamNo() {
		return this.teamNo;
	}

	/**
	 * SET 팀번호
	 */
	public void setTeamNo(java.lang.String teamNo) {
		this.teamNo = teamNo;
	}

	/**
	 * GET 퇴직일자
	 */
	public java.lang.String getRtmtDt() {
		return this.rtmtDt;
	}

	/**
	 * SET 퇴직일자
	 */
	public void setRtmtDt(java.lang.String rtmtDt) {
		this.rtmtDt = rtmtDt;
	}
	
	/**
	 * GET 대리점사원유형코드
	 */
	public java.lang.String getAgncyEmplTpcd() {
		return this.agncyEmplTpcd;
	}

	/**
	 * SET 대리점사원유형코드
	 */
	public void setAgncyEmplTpcd(java.lang.String agncyEmplTpcd) {
		this.agncyEmplTpcd = agncyEmplTpcd;
	}
	
	/**
	 * GET 조직명
	 */
	public java.lang.String getOrgNm() {
		return this.orgNm;
	}

	/**
	 * SET 조직명
	 */
	public void setOrgNm(java.lang.String orgNm) {
		this.orgNm = orgNm;
	}

	/**
	 * GET 사업부문코드
	 */
	public java.lang.String getBzprtCd() {
		return this.bzprtCd;
	}

	/**
	 * SET 사업부문코드
	 */
	public void setBzprtCd(java.lang.String bzprtCd) {
		this.bzprtCd = bzprtCd;
	}

	/**
	 * GET 조직유형코드
	 */
	public java.lang.String getOrgTpcd() {
		return this.orgTpcd;
	}

	/**
	 * SET 조직유형코드
	 */
	public void setOrgTpcd(java.lang.String orgTpcd) {
		this.orgTpcd = orgTpcd;
	}

	/**
	 * GET 조직속성코드
	 */
	public java.lang.String getOrgAttrCd() {
		return this.orgAttrCd;
	}

	/**
	 * SET 조직속성코드
	 */
	public void setOrgAttrCd(java.lang.String orgAttrCd) {
		this.orgAttrCd = orgAttrCd;
	}

	/**
	 * GET 조직종류코드
	 */
	public java.lang.String getOrgKcd() {
		return this.orgKcd;
	}

	/**
	 * SET 조직종류코드
	 */
	public void setOrgKcd(java.lang.String orgKcd) {
		this.orgKcd = orgKcd;
	}

	/**
	 * GET 조직특성코드
	 */
	public java.lang.String getOrgChrctCd() {
		return this.orgChrctCd;
	}

	/**
	 * SET 조직특성코드
	 */
	public void setOrgChrctCd(java.lang.String orgChrctCd) {
		this.orgChrctCd = orgChrctCd;
	}

	/**
	 * GET 본부조직번호
	 */
	public java.lang.String getHqOrgNo() {
		return this.hqOrgNo;
	}

	/**
	 * SET 본부조직번호
	 */
	public void setHqOrgNo(java.lang.String hqOrgNo) {
		this.hqOrgNo = hqOrgNo;
	}

	/**
	 * GET 본부조직명
	 */
	public java.lang.String getHqOrgNm() {
		return this.hqOrgNm;
	}

	/**
	 * SET 본부조직명
	 */
	public void setHqOrgNm(java.lang.String hqOrgNm) {
		this.hqOrgNm = hqOrgNm;
	}

	/**
	 * GET 지점조직번호
	 */
	public java.lang.String getDofOrgNo() {
		return this.dofOrgNo;
	}

	/**
	 * SET 지점조직번호
	 */
	public void setDofOrgNo(java.lang.String dofOrgNo) {
		this.dofOrgNo = dofOrgNo;
	}

	/**
	 * GET 지점조직명
	 */
	public java.lang.String getDofOrgNm() {
		return this.dofOrgNm;
	}

	/**
	 * SET 지점조직명
	 */
	public void setDofOrgNm(java.lang.String dofOrgNm) {
		this.dofOrgNm = dofOrgNm;
	}

	/**
	 * GET 영업소조직번호
	 */
	public java.lang.String getFofOrgNo() {
		return this.fofOrgNo;
	}

	/**
	 * SET 영업소조직번호
	 */
	public void setFofOrgNo(java.lang.String fofOrgNo) {
		this.fofOrgNo = fofOrgNo;
	}

	/**
	 * GET 영업소조직명
	 */
	public java.lang.String getFofOrgNm() {
		return this.fofOrgNm;
	}

	/**
	 * SET 영업소조직명
	 */
	public void setFofOrgNm(java.lang.String fofOrgNm) {
		this.fofOrgNm = fofOrgNm;
	}

	/**
	 * GET 플라자조직번호
	 */
	public java.lang.String getPlazaOrgNo() {
		return this.plazaOrgNo;
	}

	/**
	 * SET 플라자조직번호
	 */
	public void setPlazaOrgNo(java.lang.String plazaOrgNo) {
		this.plazaOrgNo = plazaOrgNo;
	}

	/**
	 * GET 플라자조직명
	 */
	public java.lang.String getPlazaOrgNm() {
		return this.plazaOrgNm;
	}

	/**
	 * SET 플라자조직명
	 */
	public void setPlazaOrgNm(java.lang.String plazaOrgNm) {
		this.plazaOrgNm = plazaOrgNm;
	}

	/**
	 * GET 브랜치조직번호
	 */
	public java.lang.String getBrnchOrgNo() {
		return this.brnchOrgNo;
	}

	/**
	 * SET 브랜치조직번호
	 */
	public void setBrnchOrgNo(java.lang.String brnchOrgNo) {
		this.brnchOrgNo = brnchOrgNo;
	}

	/**
	 * GET 브랜치조직명
	 */
	public java.lang.String getBrnchOrgNm() {
		return this.brnchOrgNm;
	}

	/**
	 * SET 브랜치조직명
	 */
	public void setBrnchOrgNm(java.lang.String brnchOrgNm) {
		this.brnchOrgNm = brnchOrgNm;
	}
	
	/**
	 * GET 발의부서조직번호
	 */
	public java.lang.String getPropoDeptOrgNo() {
		return this.propoDeptOrgNo;
	}

	/**
	 * SET 발의부서조직번호
	 */
	public void setPropoDeptOrgNo(java.lang.String propoDeptOrgNo) {
		this.propoDeptOrgNo = propoDeptOrgNo;
	}	

	/**
	 * GET 발의부서조직명
	 */
	public java.lang.String getPropoDeptOrgNm() {
		return this.propoDeptOrgNm;
	}

	/**
	 * SET 발의부서조직명
	 */
	public void setPropoDeptOrgNm(java.lang.String propoDeptOrgNm) {
		this.propoDeptOrgNm = propoDeptOrgNm;
	}
	
	/**
	 * GET 조직대표전화번호
	 */
	public java.lang.String getOrgTelno() {
		return this.orgTelno;
	}

	/**
	 * SET 조직대표전화번호
	 */
	public void setOrgTelno(java.lang.String orgTelno) {
		this.orgTelno = orgTelno;
	}
	
	
	/**
	 * GET 내선번호
	 */
	public java.lang.String getInlnNo() {
		return this.inlnNo;
	}

	/**
	 * SET 내선번호
	 */
	public void setInlnNo(java.lang.String inlnNo) {
		this.inlnNo = inlnNo;
	}
	
	/**
	 * GET MAC주소
	 */
	public java.lang.String getMacAddr() {
		return this.macAddr;
	}

	/**
	 * SET MAC주소
	 */
	public void setMacAddr(java.lang.String macAddr) {
		this.macAddr = macAddr;
	}	
	
	/**
	 * GET 겸직조직번호
	 */
	public java.lang.String getCpstnOrgNo() {
		return this.cpstnOrgNo;
	}

	/**
	 * SET 겸직조직번호
	 */
	public void setCpstnOrgNo(java.lang.String cpstnOrgNo) {
		this.cpstnOrgNo = cpstnOrgNo;
	}
	
	/**
	 * GET 고객번호
	 */
	public java.lang.String getCustNo() {
		return custNo;
	}

	/**
	 * SET 고객번호
	 */
	public void setCustNo(java.lang.String custNo) {
		this.custNo = custNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((agncyEmplTpcd == null) ? 0 : agncyEmplTpcd.hashCode());
		result = prime * result
				+ ((brnchOrgNm == null) ? 0 : brnchOrgNm.hashCode());
		result = prime * result
				+ ((brnchOrgNo == null) ? 0 : brnchOrgNo.hashCode());
		result = prime * result + ((bzprtCd == null) ? 0 : bzprtCd.hashCode());
		result = prime * result
				+ ((cpstnOrgNo == null) ? 0 : cpstnOrgNo.hashCode());
		result = prime * result + ((custNo == null) ? 0 : custNo.hashCode());
		result = prime * result
				+ ((dofOrgNm == null) ? 0 : dofOrgNm.hashCode());
		result = prime * result
				+ ((dofOrgNo == null) ? 0 : dofOrgNo.hashCode());
		result = prime * result + ((emplKcd == null) ? 0 : emplKcd.hashCode());
		result = prime * result + ((emplNm == null) ? 0 : emplNm.hashCode());
		result = prime * result
				+ ((emplTpcd == null) ? 0 : emplTpcd.hashCode());
		result = prime * result + ((eno == null) ? 0 : eno.hashCode());
		result = prime * result
				+ ((fofOrgNm == null) ? 0 : fofOrgNm.hashCode());
		result = prime * result
				+ ((fofOrgNo == null) ? 0 : fofOrgNo.hashCode());
		result = prime * result + ((hqOrgNm == null) ? 0 : hqOrgNm.hashCode());
		result = prime * result + ((hqOrgNo == null) ? 0 : hqOrgNo.hashCode());
		result = prime * result + ((inlnNo == null) ? 0 : inlnNo.hashCode());
		result = prime * result + ((jbdtyCd == null) ? 0 : jbdtyCd.hashCode());
		result = prime * result + ((macAddr == null) ? 0 : macAddr.hashCode());
		result = prime * result + ((ofrnkCd == null) ? 0 : ofrnkCd.hashCode());
		result = prime * result
				+ ((orgAttrCd == null) ? 0 : orgAttrCd.hashCode());
		result = prime * result
				+ ((orgChrctCd == null) ? 0 : orgChrctCd.hashCode());
		result = prime * result + ((orgKcd == null) ? 0 : orgKcd.hashCode());
		result = prime * result + ((orgNm == null) ? 0 : orgNm.hashCode());
		result = prime * result + ((orgNo == null) ? 0 : orgNo.hashCode());
		result = prime * result
				+ ((orgTelno == null) ? 0 : orgTelno.hashCode());
		result = prime * result + ((orgTpcd == null) ? 0 : orgTpcd.hashCode());
		result = prime * result
				+ ((plazaOrgNm == null) ? 0 : plazaOrgNm.hashCode());
		result = prime * result
				+ ((plazaOrgNo == null) ? 0 : plazaOrgNo.hashCode());
		result = prime * result
				+ ((propoDeptOrgNm == null) ? 0 : propoDeptOrgNm.hashCode());
		result = prime * result
				+ ((propoDeptOrgNo == null) ? 0 : propoDeptOrgNo.hashCode());
		result = prime * result + ((rtmtDt == null) ? 0 : rtmtDt.hashCode());
		result = prime * result + ((teamNo == null) ? 0 : teamNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CommEmplInfo other = (CommEmplInfo) obj;
		if (agncyEmplTpcd == null) {
			if (other.agncyEmplTpcd != null)
				return false;
		} else if (!agncyEmplTpcd.equals(other.agncyEmplTpcd))
			return false;
		if (brnchOrgNm == null) {
			if (other.brnchOrgNm != null)
				return false;
		} else if (!brnchOrgNm.equals(other.brnchOrgNm))
			return false;
		if (brnchOrgNo == null) {
			if (other.brnchOrgNo != null)
				return false;
		} else if (!brnchOrgNo.equals(other.brnchOrgNo))
			return false;
		if (bzprtCd == null) {
			if (other.bzprtCd != null)
				return false;
		} else if (!bzprtCd.equals(other.bzprtCd))
			return false;
		if (cpstnOrgNo == null) {
			if (other.cpstnOrgNo != null)
				return false;
		} else if (!cpstnOrgNo.equals(other.cpstnOrgNo))
			return false;
		if (custNo == null) {
			if (other.custNo != null)
				return false;
		} else if (!custNo.equals(other.custNo))
			return false;
		if (dofOrgNm == null) {
			if (other.dofOrgNm != null)
				return false;
		} else if (!dofOrgNm.equals(other.dofOrgNm))
			return false;
		if (dofOrgNo == null) {
			if (other.dofOrgNo != null)
				return false;
		} else if (!dofOrgNo.equals(other.dofOrgNo))
			return false;
		if (emplKcd == null) {
			if (other.emplKcd != null)
				return false;
		} else if (!emplKcd.equals(other.emplKcd))
			return false;
		if (emplNm == null) {
			if (other.emplNm != null)
				return false;
		} else if (!emplNm.equals(other.emplNm))
			return false;
		if (emplTpcd == null) {
			if (other.emplTpcd != null)
				return false;
		} else if (!emplTpcd.equals(other.emplTpcd))
			return false;
		if (eno == null) {
			if (other.eno != null)
				return false;
		} else if (!eno.equals(other.eno))
			return false;
		if (fofOrgNm == null) {
			if (other.fofOrgNm != null)
				return false;
		} else if (!fofOrgNm.equals(other.fofOrgNm))
			return false;
		if (fofOrgNo == null) {
			if (other.fofOrgNo != null)
				return false;
		} else if (!fofOrgNo.equals(other.fofOrgNo))
			return false;
		if (hqOrgNm == null) {
			if (other.hqOrgNm != null)
				return false;
		} else if (!hqOrgNm.equals(other.hqOrgNm))
			return false;
		if (hqOrgNo == null) {
			if (other.hqOrgNo != null)
				return false;
		} else if (!hqOrgNo.equals(other.hqOrgNo))
			return false;
		if (inlnNo == null) {
			if (other.inlnNo != null)
				return false;
		} else if (!inlnNo.equals(other.inlnNo))
			return false;
		if (jbdtyCd == null) {
			if (other.jbdtyCd != null)
				return false;
		} else if (!jbdtyCd.equals(other.jbdtyCd))
			return false;
		if (macAddr == null) {
			if (other.macAddr != null)
				return false;
		} else if (!macAddr.equals(other.macAddr))
			return false;
		if (ofrnkCd == null) {
			if (other.ofrnkCd != null)
				return false;
		} else if (!ofrnkCd.equals(other.ofrnkCd))
			return false;
		if (orgAttrCd == null) {
			if (other.orgAttrCd != null)
				return false;
		} else if (!orgAttrCd.equals(other.orgAttrCd))
			return false;
		if (orgChrctCd == null) {
			if (other.orgChrctCd != null)
				return false;
		} else if (!orgChrctCd.equals(other.orgChrctCd))
			return false;
		if (orgKcd == null) {
			if (other.orgKcd != null)
				return false;
		} else if (!orgKcd.equals(other.orgKcd))
			return false;
		if (orgNm == null) {
			if (other.orgNm != null)
				return false;
		} else if (!orgNm.equals(other.orgNm))
			return false;
		if (orgNo == null) {
			if (other.orgNo != null)
				return false;
		} else if (!orgNo.equals(other.orgNo))
			return false;
		if (orgTelno == null) {
			if (other.orgTelno != null)
				return false;
		} else if (!orgTelno.equals(other.orgTelno))
			return false;
		if (orgTpcd == null) {
			if (other.orgTpcd != null)
				return false;
		} else if (!orgTpcd.equals(other.orgTpcd))
			return false;
		if (plazaOrgNm == null) {
			if (other.plazaOrgNm != null)
				return false;
		} else if (!plazaOrgNm.equals(other.plazaOrgNm))
			return false;
		if (plazaOrgNo == null) {
			if (other.plazaOrgNo != null)
				return false;
		} else if (!plazaOrgNo.equals(other.plazaOrgNo))
			return false;
		if (propoDeptOrgNm == null) {
			if (other.propoDeptOrgNm != null)
				return false;
		} else if (!propoDeptOrgNm.equals(other.propoDeptOrgNm))
			return false;
		if (propoDeptOrgNo == null) {
			if (other.propoDeptOrgNo != null)
				return false;
		} else if (!propoDeptOrgNo.equals(other.propoDeptOrgNo))
			return false;
		if (rtmtDt == null) {
			if (other.rtmtDt != null)
				return false;
		} else if (!rtmtDt.equals(other.rtmtDt))
			return false;
		if (teamNo == null) {
			if (other.teamNo != null)
				return false;
		} else if (!teamNo.equals(other.teamNo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CommEmplInfo [eno=" + eno + ", emplNm=" + emplNm
				+ ", emplTpcd=" + emplTpcd + ", emplKcd=" + emplKcd
				+ ", jbdtyCd=" + jbdtyCd + ", ofrnkCd=" + ofrnkCd + ", orgNo="
				+ orgNo + ", teamNo=" + teamNo + ", rtmtDt=" + rtmtDt
				+ ", agncyEmplTpcd=" + agncyEmplTpcd + ", orgNm=" + orgNm
				+ ", bzprtCd=" + bzprtCd + ", orgTpcd=" + orgTpcd
				+ ", orgAttrCd=" + orgAttrCd + ", orgKcd=" + orgKcd
				+ ", orgChrctCd=" + orgChrctCd + ", hqOrgNo=" + hqOrgNo
				+ ", hqOrgNm=" + hqOrgNm + ", dofOrgNo=" + dofOrgNo
				+ ", dofOrgNm=" + dofOrgNm + ", fofOrgNo=" + fofOrgNo
				+ ", fofOrgNm=" + fofOrgNm + ", plazaOrgNo=" + plazaOrgNo
				+ ", plazaOrgNm=" + plazaOrgNm + ", brnchOrgNo=" + brnchOrgNo
				+ ", brnchOrgNm=" + brnchOrgNm + ", propoDeptOrgNo="
				+ propoDeptOrgNo + ", propoDeptOrgNm=" + propoDeptOrgNm
				+ ", orgTelno=" + orgTelno + ", inlnNo=" + inlnNo
				+ ", macAddr=" + macAddr + ", cpstnOrgNo=" + cpstnOrgNo
				+ ", custNo=" + custNo + "]";
	}
	
	
}
