/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Fri Oct 05 16:19:08 KST 2012
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName ComnCd
 * @Description 공통코드값
 */
public class ComnCd implements Serializable, Cloneable {

	private static final long serialVersionUID = 564904048L;
	/**
	 * @Type java.lang.String
	 * @Name comnCdId
	 * @Description 공통코드ID
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String comnCdId;
	/**
	 * @Type java.lang.String
	 * @Name comnCdNm
	 * @Description 공통코드명
	 * @Length 100
	 * @Decimal 0
	 */
	private java.lang.String comnCdNm;
	/**
	 * @Type java.lang.String
	 * @Name hrnkComnCdId
	 * @Description 상위공통코드ID
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String hrnkComnCdId;
	/**
	 * @Type java.lang.String
	 * @Name comnCdVl
	 * @Description 공통코드값
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String comnCdVl;
	/**
	 * @Type java.lang.String
	 * @Name comnCdVlNm
	 * @Description 공통코드값명
	 * @Length 500
	 * @Decimal 0
	 */
	private java.lang.String comnCdVlNm;
	/**
	 * @Type java.lang.String
	 * @Name lrnkComnCdId
	 * @Description 하위공통코드ID
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String lrnkComnCdId;
	/**
	 * @Type java.lang.String
	 * @Name vldYn
	 * @Description 유효여부
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String vldYn;

	/**
	 * GET 공통코드ID
	 */
	public java.lang.String getComnCdId() {
		return this.comnCdId;
	}

	/**
	 * SET 공통코드ID
	 */
	public void setComnCdId(java.lang.String comnCdId) {
		this.comnCdId = comnCdId;
	}

	/**
	 * GET 공통코드명
	 */
	public java.lang.String getComnCdNm() {
		return this.comnCdNm;
	}

	/**
	 * SET 공통코드명
	 */
	public void setComnCdNm(java.lang.String comnCdNm) {
		this.comnCdNm = comnCdNm;
	}

	/**
	 * GET 상위공통코드ID
	 */
	public java.lang.String getHrnkComnCdId() {
		return this.hrnkComnCdId;
	}

	/**
	 * SET 상위공통코드ID
	 */
	public void setHrnkComnCdId(java.lang.String hrnkComnCdId) {
		this.hrnkComnCdId = hrnkComnCdId;
	}

	/**
	 * GET 공통코드값
	 */
	public java.lang.String getComnCdVl() {
		return this.comnCdVl;
	}

	/**
	 * SET 공통코드값
	 */
	public void setComnCdVl(java.lang.String comnCdVl) {
		this.comnCdVl = comnCdVl;
	}

	/**
	 * GET 공통코드값명
	 */
	public java.lang.String getComnCdVlNm() {
		return this.comnCdVlNm;
	}

	/**
	 * SET 공통코드값명
	 */
	public void setComnCdVlNm(java.lang.String comnCdVlNm) {
		this.comnCdVlNm = comnCdVlNm;
	}

	/**
	 * GET 하위공통코드ID
	 */
	public java.lang.String getLrnkComnCdId() {
		return this.lrnkComnCdId;
	}

	/**
	 * SET 하위공통코드ID
	 */
	public void setLrnkComnCdId(java.lang.String lrnkComnCdId) {
		this.lrnkComnCdId = lrnkComnCdId;
	}

	/**
	 * GET 유효여부
	 */
	public java.lang.String getVldYn() {
		return this.vldYn;
	}

	/**
	 * SET 유효여부
	 */
	public void setVldYn(java.lang.String vldYn) {
		this.vldYn = vldYn;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((comnCdId == null) ? 0 : comnCdId.hashCode());
		result = prime * result
				+ ((comnCdNm == null) ? 0 : comnCdNm.hashCode());
		result = prime * result
				+ ((hrnkComnCdId == null) ? 0 : hrnkComnCdId.hashCode());
		result = prime * result
				+ ((comnCdVl == null) ? 0 : comnCdVl.hashCode());
		result = prime * result
				+ ((comnCdVlNm == null) ? 0 : comnCdVlNm.hashCode());
		result = prime * result
				+ ((lrnkComnCdId == null) ? 0 : lrnkComnCdId.hashCode());
		result = prime * result + ((vldYn == null) ? 0 : vldYn.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ComnCd other = (ComnCd) obj;
		if (comnCdId == null) {
			if (other.comnCdId != null)
				return false;
		} else if (!comnCdId.equals(other.comnCdId))
			return false;
		if (comnCdNm == null) {
			if (other.comnCdNm != null)
				return false;
		} else if (!comnCdNm.equals(other.comnCdNm))
			return false;
		if (hrnkComnCdId == null) {
			if (other.hrnkComnCdId != null)
				return false;
		} else if (!hrnkComnCdId.equals(other.hrnkComnCdId))
			return false;
		if (comnCdVl == null) {
			if (other.comnCdVl != null)
				return false;
		} else if (!comnCdVl.equals(other.comnCdVl))
			return false;
		if (comnCdVlNm == null) {
			if (other.comnCdVlNm != null)
				return false;
		} else if (!comnCdVlNm.equals(other.comnCdVlNm))
			return false;
		if (lrnkComnCdId == null) {
			if (other.lrnkComnCdId != null)
				return false;
		} else if (!lrnkComnCdId.equals(other.lrnkComnCdId))
			return false;
		if (vldYn == null) {
			if (other.vldYn != null)
				return false;
		} else if (!vldYn.equals(other.vldYn))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("ComnCd[\n");
		sb.append("	comnCdId(공통코드ID) = " + comnCdId);
		sb.append("\n");
		sb.append("	comnCdNm(공통코드명) = " + comnCdNm);
		sb.append("\n");
		sb.append("	hrnkComnCdId(상위공통코드ID) = " + hrnkComnCdId);
		sb.append("\n");
		sb.append("	comnCdVl(공통코드값) = " + comnCdVl);
		sb.append("\n");
		sb.append("	comnCdVlNm(공통코드값명) = " + comnCdVlNm);
		sb.append("\n");
		sb.append("	lrnkComnCdId(하위공통코드ID) = " + lrnkComnCdId);
		sb.append("\n");
		sb.append("	vldYn(유효여부) = " + vldYn);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
