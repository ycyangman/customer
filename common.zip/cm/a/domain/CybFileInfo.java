/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Thu Feb 07 18:23:19 KST 2013
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName CybFileInfo
 * @Description 
 */
public class CybFileInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 1896831028L;
	/**
	 * @Type java.lang.String
	 * @Name prcsDcd
	 * @Description 처리구분코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsDcd;
	/**
	 * @Type java.lang.String
	 * @Name cybFileMgntNo
	 * @Description 사이버파일관리번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String cybFileMgntNo;
	/**
	 * @Type java.lang.Integer
	 * @Name fileSeq
	 * @Description 파일순번
	 * @Length 5
	 * @Decimal 0
	 */
	private java.lang.Integer fileSeq;
	/**
	 * @Type java.lang.String
	 * @Name fileMgntBzCd
	 * @Description 파일관리업무코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String fileMgntBzCd;
	/**
	 * @Type java.lang.String
	 * @Name atchOrgcpFileNm
	 * @Description 첨부원본파일명
	 * @Length 500
	 * @Decimal 0
	 */
	private java.lang.String atchOrgcpFileNm;
	/**
	 * @Type java.lang.Integer
	 * @Name fileSeq
	 * @Description 파일크기
	 * @Length 5
	 * @Decimal 0
	 */
	private java.lang.Integer fileLength;
	/**
	 * @Type java.util.List<java.lang.Byte>
	 * @Name atchImgFileCtnt
	 * @Description 첨부이미지파일내용
	 * @Length 4000
	 * @Decimal 0
	 */
	private java.util.List<java.lang.Byte> atchImgFileCtnt;

	/**
	 * GET 처리구분코드
	 */
	public java.lang.String getPrcsDcd() {
		return this.prcsDcd;
	}

	/**
	 * SET 처리구분코드
	 */
	public void setPrcsDcd(java.lang.String prcsDcd) {
		this.prcsDcd = prcsDcd;
	}

	/**
	 * GET 사이버파일관리번호
	 */
	public java.lang.String getCybFileMgntNo() {
		return this.cybFileMgntNo;
	}

	/**
	 * SET 사이버파일관리번호
	 */
	public void setCybFileMgntNo(java.lang.String cybFileMgntNo) {
		this.cybFileMgntNo = cybFileMgntNo;
	}

	/**
	 * GET 파일순번
	 */
	public java.lang.Integer getFileSeq() {
		return this.fileSeq;
	}

	/**
	 * SET 파일순번
	 */
	public void setFileSeq(java.lang.Integer fileSeq) {
		this.fileSeq = fileSeq;
	}

	/**
	 * GET 파일관리업무코드
	 */
	public java.lang.String getFileMgntBzCd() {
		return this.fileMgntBzCd;
	}

	/**
	 * SET 파일관리업무코드
	 */
	public void setFileMgntBzCd(java.lang.String fileMgntBzCd) {
		this.fileMgntBzCd = fileMgntBzCd;
	}

	/**
	 * GET 첨부원본파일명
	 */
	public java.lang.String getAtchOrgcpFileNm() {
		return this.atchOrgcpFileNm;
	}

	/**
	 * SET 첨부원본파일명
	 */
	public void setAtchOrgcpFileNm(java.lang.String atchOrgcpFileNm) {
		this.atchOrgcpFileNm = atchOrgcpFileNm;
	}

	/**
	 * GET 파일크기
	 */
	public java.lang.Integer getFileLength() {
		return this.fileLength;
	}

	/**
	 * SET 파일크기
	 */
	public void setFileLength(java.lang.Integer fileLength) {
		this.fileLength = fileLength;
	}
	
	/**
	 * GET 첨부이미지파일내용
	 */
	public java.util.List<java.lang.Byte> getAtchImgFileCtnt() {
		return this.atchImgFileCtnt;
	}

	/**
	 * SET 첨부이미지파일내용
	 */
	public void setAtchImgFileCtnt(java.util.List<java.lang.Byte> atchImgFileCtnt) {
		this.atchImgFileCtnt = atchImgFileCtnt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((prcsDcd == null) ? 0 : prcsDcd.hashCode());
		result = prime * result
				+ ((cybFileMgntNo == null) ? 0 : cybFileMgntNo.hashCode());
		result = prime * result + ((fileSeq == null) ? 0 : fileSeq.hashCode());
		result = prime * result
				+ ((fileMgntBzCd == null) ? 0 : fileMgntBzCd.hashCode());
		result = prime * result
				+ ((atchOrgcpFileNm == null) ? 0 : atchOrgcpFileNm.hashCode());
		result = prime * result + ((fileLength == null) ? 0 : fileLength.hashCode());
		result = prime * result
				+ ((atchImgFileCtnt == null) ? 0 : atchImgFileCtnt.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CybFileInfo other = (CybFileInfo) obj;
		if (prcsDcd == null) {
			if (other.prcsDcd != null)
				return false;
		} else if (!prcsDcd.equals(other.prcsDcd))
			return false;
		if (cybFileMgntNo == null) {
			if (other.cybFileMgntNo != null)
				return false;
		} else if (!cybFileMgntNo.equals(other.cybFileMgntNo))
			return false;
		if (fileSeq == null) {
			if (other.fileSeq != null)
				return false;
		} else if (!fileSeq.equals(other.fileSeq))
			return false;
		if (fileMgntBzCd == null) {
			if (other.fileMgntBzCd != null)
				return false;
		} else if (!fileMgntBzCd.equals(other.fileMgntBzCd))
			return false;
		if (atchOrgcpFileNm == null) {
			if (other.atchOrgcpFileNm != null)
				return false;
		} else if (!atchOrgcpFileNm.equals(other.atchOrgcpFileNm))
			return false;
		if (fileLength == null) {
			if (other.fileLength != null)
				return false;
		} else if (!fileLength.equals(other.fileLength))
			return false;
		if (atchImgFileCtnt == null) {
			if (other.atchImgFileCtnt != null)
				return false;
		} else if (!atchImgFileCtnt.equals(other.atchImgFileCtnt))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("CybFileInfo[\n");
		sb.append("	prcsDcd(처리구분코드) = " + prcsDcd);
		sb.append("\n");
		sb.append("	cybFileMgntNo(사이버파일관리번호) = " + cybFileMgntNo);
		sb.append("\n");
		sb.append("	fileSeq(파일순번) = " + fileSeq);
		sb.append("\n");
		sb.append("	fileMgntBzCd(파일관리업무코드) = " + fileMgntBzCd);
		sb.append("\n");
		sb.append("	atchOrgcpFileNm(첨부원본파일명) = " + atchOrgcpFileNm);
		sb.append("\n");
		sb.append("	fileLength(파일크기) = " + fileLength);
		sb.append("\n");
		sb.append("	atchImgFileCtnt(첨부이미지파일내용) = " + atchImgFileCtnt);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
