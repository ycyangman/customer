/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Wed Jan 30 09:13:33 KST 2013
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName FileDelInfo
 * @Description 
 */
public class FileDelInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = -1723774117L;
	/**
	 * @Type java.lang.String
	 * @Name fileMgntNo
	 * @Description 파일관리번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String fileMgntNo;
	/**
	 * @Type java.lang.Integer
	 * @Name fileSeq
	 * @Description 파일순번
	 * @Length 5
	 * @Decimal 0
	 */
	private java.lang.Integer fileSeq;
	/**
	 * @Type java.lang.String
	 * @Name filePathNm
	 * @Description 파일경로명
	 * @Length 500
	 * @Decimal 0
	 */
	private java.lang.String filePathNm;
	/**
	 * @Type java.lang.String
	 * @Name atchSavFileNm
	 * @Description 첨부저장파일명
	 * @Length 100
	 * @Decimal 0
	 */
	private java.lang.String atchSavFileNm;

	/**
	 * GET 파일관리번호
	 */
	public java.lang.String getFileMgntNo() {
		return this.fileMgntNo;
	}

	/**
	 * SET 파일관리번호
	 */
	public void setFileMgntNo(java.lang.String fileMgntNo) {
		this.fileMgntNo = fileMgntNo;
	}

	/**
	 * GET 파일순번
	 */
	public java.lang.Integer getFileSeq() {
		return this.fileSeq;
	}

	/**
	 * SET 파일순번
	 */
	public void setFileSeq(java.lang.Integer fileSeq) {
		this.fileSeq = fileSeq;
	}

	/**
	 * GET 파일경로명
	 */
	public java.lang.String getFilePathNm() {
		return this.filePathNm;
	}

	/**
	 * SET 파일경로명
	 */
	public void setFilePathNm(java.lang.String filePathNm) {
		this.filePathNm = filePathNm;
	}

	/**
	 * GET 첨부저장파일명
	 */
	public java.lang.String getAtchSavFileNm() {
		return this.atchSavFileNm;
	}

	/**
	 * SET 첨부저장파일명
	 */
	public void setAtchSavFileNm(java.lang.String atchSavFileNm) {
		this.atchSavFileNm = atchSavFileNm;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((fileMgntNo == null) ? 0 : fileMgntNo.hashCode());
		result = prime * result + ((fileSeq == null) ? 0 : fileSeq.hashCode());
		result = prime * result
				+ ((filePathNm == null) ? 0 : filePathNm.hashCode());
		result = prime * result
				+ ((atchSavFileNm == null) ? 0 : atchSavFileNm.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileDelInfo other = (FileDelInfo) obj;
		if (fileMgntNo == null) {
			if (other.fileMgntNo != null)
				return false;
		} else if (!fileMgntNo.equals(other.fileMgntNo))
			return false;
		if (fileSeq == null) {
			if (other.fileSeq != null)
				return false;
		} else if (!fileSeq.equals(other.fileSeq))
			return false;
		if (filePathNm == null) {
			if (other.filePathNm != null)
				return false;
		} else if (!filePathNm.equals(other.filePathNm))
			return false;
		if (atchSavFileNm == null) {
			if (other.atchSavFileNm != null)
				return false;
		} else if (!atchSavFileNm.equals(other.atchSavFileNm))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("FileDelInfo[\n");
		sb.append("	fileMgntNo(파일관리번호) = " + fileMgntNo);
		sb.append("\n");
		sb.append("	fileSeq(파일순번) = " + fileSeq);
		sb.append("\n");
		sb.append("	filePathNm(파일경로명) = " + filePathNm);
		sb.append("\n");
		sb.append("	atchSavFileNm(첨부저장파일명) = " + atchSavFileNm);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
