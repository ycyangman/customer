/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Mon Feb 18 14:35:22 KST 2013
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName FilePutList
 * @Description 
 */
public class FilePutInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 801875023L;
	/**
	 * @Type java.lang.String
	 * @Name atchOrgcpFileNm
	 * @Description 첨부원본파일명
	 * @Length 500
	 * @Decimal 0
	 */
	private java.lang.String atchOrgcpFileNm;
	/**
	 * @Type byte[]
	 * @Name atchFileCtnt
	 * @Description 첨부파일내용
	 * @Length 0
	 * @Decimal 0
	 */
	private byte[] atchFileCtnt;
	
	/**
	 * @Type java.lang.String
	 * @Name atchOrgcpFileNm
	 * @Description 첨부원본파일명
	 * @Length 500
	 * @Decimal 0
	 */
	private java.lang.String atchSavFileNm;

	/**
	 * GET 첨부원본파일명
	 */
	public java.lang.String getAtchOrgcpFileNm() {
		return this.atchOrgcpFileNm;
	}

	/**
	 * SET 첨부원본파일명
	 */
	public void setAtchOrgcpFileNm(java.lang.String atchOrgcpFileNm) {
		this.atchOrgcpFileNm = atchOrgcpFileNm;
	}

	/**
	 * GET 첨부원본저장명
	 */
	public java.lang.String getAtchSavFileNm() {
		return atchSavFileNm;
	}

	/**
	 * SET 첨부원본저장명
	 */
	public void setAtchSavFileNm(java.lang.String atchSavFileNm) {
		this.atchSavFileNm = atchSavFileNm;
	}

	/**
	 * GET 첨부파일내용
	 */
	public byte[] getAtchImgFileCtnt() {
		return this.atchFileCtnt;
	}

	/**
	 * SET 첨부파일내용
	 */
	public void setAtchImgFileCtnt(byte[] atchFileCtnt) {
		this.atchFileCtnt = atchFileCtnt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((atchOrgcpFileNm == null) ? 0 : atchOrgcpFileNm.hashCode());
		result = prime * result
				+ ((atchFileCtnt == null) ? 0 : atchFileCtnt.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FilePutInfo other = (FilePutInfo) obj;
		if (atchOrgcpFileNm == null) {
			if (other.atchOrgcpFileNm != null)
				return false;
		} else if (!atchOrgcpFileNm.equals(other.atchOrgcpFileNm))
			return false;
		if (atchSavFileNm == null) {
			if (other.atchSavFileNm != null)
				return false;
		} else if (!atchSavFileNm.equals(other.atchSavFileNm))
			return false;
		if (atchFileCtnt == null) {
			if (other.atchFileCtnt != null)
				return false;
		} else if (!atchFileCtnt.equals(other.atchFileCtnt))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("FilePutList[\n");
		sb.append("	atchOrgcpFileNm(첨부원본파일명) = " + atchOrgcpFileNm);
		sb.append("\n");
		sb.append("	atchSavFileNm(첨부저장파일명) = " + atchSavFileNm);
		sb.append("\n");
		sb.append("	atchFileCtnt(첨부파일내용) = " + atchFileCtnt);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
