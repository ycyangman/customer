/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Mon Nov 05 13:33:40 KST 2012
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName OrgEtcInfo
 * @Description 
 */
public class OrgEtcInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = -2017439744L;
	/**
	 * @Type java.lang.String
	 * @Name plazaOrgNo
	 * @Description 플라자조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String plazaOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name plazaOrgNm
	 * @Description 플라자조직명
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String plazaOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name brnchOrgNo
	 * @Description 브랜치조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String brnchOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name brnchOrgNm
	 * @Description 브랜치조직명
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String brnchOrgNm;

	/**
	 * GET 플라자조직번호
	 */
	public java.lang.String getPlazaOrgNo() {
		return this.plazaOrgNo;
	}

	/**
	 * SET 플라자조직번호
	 */
	public void setPlazaOrgNo(java.lang.String plazaOrgNo) {
		this.plazaOrgNo = plazaOrgNo;
	}

	/**
	 * GET 플라자조직명
	 */
	public java.lang.String getPlazaOrgNm() {
		return this.plazaOrgNm;
	}

	/**
	 * SET 플라자조직명
	 */
	public void setPlazaOrgNm(java.lang.String plazaOrgNm) {
		this.plazaOrgNm = plazaOrgNm;
	}

	/**
	 * GET 브랜치조직번호
	 */
	public java.lang.String getBrnchOrgNo() {
		return this.brnchOrgNo;
	}

	/**
	 * SET 브랜치조직번호
	 */
	public void setBrnchOrgNo(java.lang.String brnchOrgNo) {
		this.brnchOrgNo = brnchOrgNo;
	}

	/**
	 * GET 브랜치조직명
	 */
	public java.lang.String getBrnchOrgNm() {
		return this.brnchOrgNm;
	}

	/**
	 * SET 브랜치조직명
	 */
	public void setBrnchOrgNm(java.lang.String brnchOrgNm) {
		this.brnchOrgNm = brnchOrgNm;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((plazaOrgNo == null) ? 0 : plazaOrgNo.hashCode());
		result = prime * result
				+ ((plazaOrgNm == null) ? 0 : plazaOrgNm.hashCode());
		result = prime * result
				+ ((brnchOrgNo == null) ? 0 : brnchOrgNo.hashCode());
		result = prime * result
				+ ((brnchOrgNm == null) ? 0 : brnchOrgNm.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrgEtcInfo other = (OrgEtcInfo) obj;
		if (plazaOrgNo == null) {
			if (other.plazaOrgNo != null)
				return false;
		} else if (!plazaOrgNo.equals(other.plazaOrgNo))
			return false;
		if (plazaOrgNm == null) {
			if (other.plazaOrgNm != null)
				return false;
		} else if (!plazaOrgNm.equals(other.plazaOrgNm))
			return false;
		if (brnchOrgNo == null) {
			if (other.brnchOrgNo != null)
				return false;
		} else if (!brnchOrgNo.equals(other.brnchOrgNo))
			return false;
		if (brnchOrgNm == null) {
			if (other.brnchOrgNm != null)
				return false;
		} else if (!brnchOrgNm.equals(other.brnchOrgNm))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("OrgEtcInfo[\n");
		sb.append("	plazaOrgNo(플라자조직번호) = " + plazaOrgNo);
		sb.append("\n");
		sb.append("	plazaOrgNm(플라자조직명) = " + plazaOrgNm);
		sb.append("\n");
		sb.append("	brnchOrgNo(브랜치조직번호) = " + brnchOrgNo);
		sb.append("\n");
		sb.append("	brnchOrgNm(브랜치조직명) = " + brnchOrgNm);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
