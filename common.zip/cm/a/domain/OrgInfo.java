/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Mon Nov 05 13:09:51 KST 2012
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName OrgInfo
 * @Description 
 */
public class OrgInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = -1823415856L;
	/**
	 * @Type java.lang.String
	 * @Name orgNo
	 * @Description 조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String orgNo;
	/**
	 * @Type java.lang.String
	 * @Name orgNm
	 * @Description 조직명
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String orgNm;
	/**
	 * @Type java.lang.String
	 * @Name bzprtCd
	 * @Description 사업부문코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String bzprtCd;
	/**
	 * @Type java.lang.String
	 * @Name orgTpcd
	 * @Description 조직유형코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String orgTpcd;
	/**
	 * @Type java.lang.String
	 * @Name orgAttrCd
	 * @Description 조직속성코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String orgAttrCd;
	/**
	 * @Type java.lang.String
	 * @Name orgKcd
	 * @Description 조직종류코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String orgKcd;
	/**
	 * @Type java.lang.String
	 * @Name orgChrctCd
	 * @Description 조직특성코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String orgChrctCd;
	/**
	 * @Type java.lang.String
	 * @Name hqOrgNo
	 * @Description 본부조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String hqOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name hqOrgNm
	 * @Description 본부조직명
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String hqOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name dofOrgNo
	 * @Description 지점조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String dofOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name dofOrgNm
	 * @Description 지점조직명
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String dofOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name fofOrgNo
	 * @Description 영업소조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String fofOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name fofOrgNm
	 * @Description 영업소조직명
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String fofOrgNm;
	/**
	 * @Type java.lang.String
	 * @Name propoDeptOrgNo
	 * @Description 발의부서조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String propoDeptOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name propoDeptOrgNm
	 * @Description 발의부서조직명
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String propoDeptOrgNm;	
	/**
	 * GET 조직번호
	 */
	public java.lang.String getOrgNo() {
		return this.orgNo;
	}

	/**
	 * SET 조직번호
	 */
	public void setOrgNo(java.lang.String orgNo) {
		this.orgNo = orgNo;
	}

	/**
	 * GET 조직명
	 */
	public java.lang.String getOrgNm() {
		return this.orgNm;
	}

	/**
	 * SET 조직명
	 */
	public void setOrgNm(java.lang.String orgNm) {
		this.orgNm = orgNm;
	}

	/**
	 * GET 사업부문코드
	 */
	public java.lang.String getBzprtCd() {
		return this.bzprtCd;
	}

	/**
	 * SET 사업부문코드
	 */
	public void setBzprtCd(java.lang.String bzprtCd) {
		this.bzprtCd = bzprtCd;
	}

	/**
	 * GET 조직유형코드
	 */
	public java.lang.String getOrgTpcd() {
		return this.orgTpcd;
	}

	/**
	 * SET 조직유형코드
	 */
	public void setOrgTpcd(java.lang.String orgTpcd) {
		this.orgTpcd = orgTpcd;
	}

	/**
	 * GET 조직속성코드
	 */
	public java.lang.String getOrgAttrCd() {
		return this.orgAttrCd;
	}

	/**
	 * SET 조직속성코드
	 */
	public void setOrgAttrCd(java.lang.String orgAttrCd) {
		this.orgAttrCd = orgAttrCd;
	}

	/**
	 * GET 조직종류코드
	 */
	public java.lang.String getOrgKcd() {
		return this.orgKcd;
	}

	/**
	 * SET 조직종류코드
	 */
	public void setOrgKcd(java.lang.String orgKcd) {
		this.orgKcd = orgKcd;
	}

	/**
	 * GET 조직특성코드
	 */
	public java.lang.String getOrgChrctCd() {
		return this.orgChrctCd;
	}

	/**
	 * SET 조직특성코드
	 */
	public void setOrgChrctCd(java.lang.String orgChrctCd) {
		this.orgChrctCd = orgChrctCd;
	}

	/**
	 * GET 본부조직번호
	 */
	public java.lang.String getHqOrgNo() {
		return this.hqOrgNo;
	}

	/**
	 * SET 본부조직번호
	 */
	public void setHqOrgNo(java.lang.String hqOrgNo) {
		this.hqOrgNo = hqOrgNo;
	}

	/**
	 * GET 본부조직명
	 */
	public java.lang.String getHqOrgNm() {
		return this.hqOrgNm;
	}

	/**
	 * SET 본부조직명
	 */
	public void setHqOrgNm(java.lang.String hqOrgNm) {
		this.hqOrgNm = hqOrgNm;
	}

	/**
	 * GET 지점조직번호
	 */
	public java.lang.String getDofOrgNo() {
		return this.dofOrgNo;
	}

	/**
	 * SET 지점조직번호
	 */
	public void setDofOrgNo(java.lang.String dofOrgNo) {
		this.dofOrgNo = dofOrgNo;
	}

	/**
	 * GET 지점조직명
	 */
	public java.lang.String getDofOrgNm() {
		return this.dofOrgNm;
	}

	/**
	 * SET 지점조직명
	 */
	public void setDofOrgNm(java.lang.String dofOrgNm) {
		this.dofOrgNm = dofOrgNm;
	}

	/**
	 * GET 영업소조직번호
	 */
	public java.lang.String getFofOrgNo() {
		return this.fofOrgNo;
	}

	/**
	 * SET 영업소조직번호
	 */
	public void setFofOrgNo(java.lang.String fofOrgNo) {
		this.fofOrgNo = fofOrgNo;
	}

	/**
	 * GET 영업소조직명
	 */
	public java.lang.String getFofOrgNm() {
		return this.fofOrgNm;
	}

	/**
	 * SET 영업소조직명
	 */
	public void setFofOrgNm(java.lang.String fofOrgNm) {
		this.fofOrgNm = fofOrgNm;
	}
	
	/**
	 * GET 발의부서조직번호
	 */
	public java.lang.String getPropoDeptOrgNo() {
		return this.propoDeptOrgNo;
	}

	/**
	 * SET 발의부서조직번호
	 */
	public void setPropoDeptOrgNo(java.lang.String propoDeptOrgNo) {
		this.propoDeptOrgNo = propoDeptOrgNo;
	}

	/**
	 * GET 발의부서조직명
	 */
	public java.lang.String getPropoDeptOrgNm() {
		return this.propoDeptOrgNm;
	}

	/**
	 * SET 발의부서조직명
	 */
	public void setPropoDeptOrgNm(java.lang.String propoDeptOrgNm) {
		this.propoDeptOrgNm = propoDeptOrgNm;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orgNo == null) ? 0 : orgNo.hashCode());
		result = prime * result + ((orgNm == null) ? 0 : orgNm.hashCode());
		result = prime * result + ((bzprtCd == null) ? 0 : bzprtCd.hashCode());
		result = prime * result + ((orgTpcd == null) ? 0 : orgTpcd.hashCode());
		result = prime * result
				+ ((orgAttrCd == null) ? 0 : orgAttrCd.hashCode());
		result = prime * result + ((orgKcd == null) ? 0 : orgKcd.hashCode());
		result = prime * result
				+ ((orgChrctCd == null) ? 0 : orgChrctCd.hashCode());
		result = prime * result + ((hqOrgNo == null) ? 0 : hqOrgNo.hashCode());
		result = prime * result + ((hqOrgNm == null) ? 0 : hqOrgNm.hashCode());
		result = prime * result
				+ ((dofOrgNo == null) ? 0 : dofOrgNo.hashCode());
		result = prime * result
				+ ((dofOrgNm == null) ? 0 : dofOrgNm.hashCode());
		result = prime * result
				+ ((fofOrgNo == null) ? 0 : fofOrgNo.hashCode());
		result = prime * result
				+ ((fofOrgNm == null) ? 0 : fofOrgNm.hashCode());
		result = prime * result
				+ ((propoDeptOrgNo == null) ? 0 : propoDeptOrgNo.hashCode());
		result = prime * result
				+ ((propoDeptOrgNm == null) ? 0 : propoDeptOrgNm.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrgInfo other = (OrgInfo) obj;
		if (orgNo == null) {
			if (other.orgNo != null)
				return false;
		} else if (!orgNo.equals(other.orgNo))
			return false;
		if (orgNm == null) {
			if (other.orgNm != null)
				return false;
		} else if (!orgNm.equals(other.orgNm))
			return false;
		if (bzprtCd == null) {
			if (other.bzprtCd != null)
				return false;
		} else if (!bzprtCd.equals(other.bzprtCd))
			return false;
		if (orgTpcd == null) {
			if (other.orgTpcd != null)
				return false;
		} else if (!orgTpcd.equals(other.orgTpcd))
			return false;
		if (orgAttrCd == null) {
			if (other.orgAttrCd != null)
				return false;
		} else if (!orgAttrCd.equals(other.orgAttrCd))
			return false;
		if (orgKcd == null) {
			if (other.orgKcd != null)
				return false;
		} else if (!orgKcd.equals(other.orgKcd))
			return false;
		if (orgChrctCd == null) {
			if (other.orgChrctCd != null)
				return false;
		} else if (!orgChrctCd.equals(other.orgChrctCd))
			return false;
		if (hqOrgNo == null) {
			if (other.hqOrgNo != null)
				return false;
		} else if (!hqOrgNo.equals(other.hqOrgNo))
			return false;
		if (hqOrgNm == null) {
			if (other.hqOrgNm != null)
				return false;
		} else if (!hqOrgNm.equals(other.hqOrgNm))
			return false;
		if (dofOrgNo == null) {
			if (other.dofOrgNo != null)
				return false;
		} else if (!dofOrgNo.equals(other.dofOrgNo))
			return false;
		if (dofOrgNm == null) {
			if (other.dofOrgNm != null)
				return false;
		} else if (!dofOrgNm.equals(other.dofOrgNm))
			return false;
		if (fofOrgNo == null) {
			if (other.fofOrgNo != null)
				return false;
		} else if (!fofOrgNo.equals(other.fofOrgNo))
			return false;
		if (fofOrgNm == null) {
			if (other.fofOrgNm != null)
				return false;
		} else if (!fofOrgNm.equals(other.fofOrgNm))
			return false;
		if (propoDeptOrgNo == null) {
			if (other.propoDeptOrgNo != null)
				return false;
		} else if (!propoDeptOrgNo.equals(other.propoDeptOrgNo))
			return false;
		if (propoDeptOrgNm == null) {
			if (other.propoDeptOrgNm != null)
				return false;
		} else if (!propoDeptOrgNm.equals(other.propoDeptOrgNm))
			return false;
		
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("OrgInfo[\n");
		sb.append("	orgNo(조직번호) = " + orgNo);
		sb.append("\n");
		sb.append("	orgNm(조직명) = " + orgNm);
		sb.append("\n");
		sb.append("	bzprtCd(사업부문코드) = " + bzprtCd);
		sb.append("\n");
		sb.append("	orgTpcd(조직유형코드) = " + orgTpcd);
		sb.append("\n");
		sb.append("	orgAttrCd(조직속성코드) = " + orgAttrCd);
		sb.append("\n");
		sb.append("	orgKcd(조직종류코드) = " + orgKcd);
		sb.append("\n");
		sb.append("	orgChrctCd(조직특성코드) = " + orgChrctCd);
		sb.append("\n");
		sb.append("	hqOrgNo(본부조직번호) = " + hqOrgNo);
		sb.append("\n");
		sb.append("	hqOrgNm(본부조직명) = " + hqOrgNm);
		sb.append("\n");
		sb.append("	dofOrgNo(지점조직번호) = " + dofOrgNo);
		sb.append("\n");
		sb.append("	dofOrgNm(지점조직명) = " + dofOrgNm);
		sb.append("\n");
		sb.append("	fofOrgNo(영업소조직번호) = " + fofOrgNo);
		sb.append("\n");
		sb.append("	fofOrgNm(영업소조직명) = " + fofOrgNm);
		sb.append("\n");
		sb.append("	propoDeptOrgNo(발의부서조직번호) = " + propoDeptOrgNo);
		sb.append("\n");
		sb.append("	propoDeptOrgNm(발의부서조직명) = " + propoDeptOrgNm);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
