/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Tue Jul 23 10:52:14 KST 2013
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName OrgTelnoInfo
 * @Description 
 */
public class OrgTelnoInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 1308198408L;
	/**
	 * @Type java.lang.String
	 * @Name orgTelno
	 * @Description 조직대표전화번호
	 * @Length 14
	 * @Decimal 0
	 */
	private java.lang.String orgTelno;
	
	/**
	 * GET 조직대표전화번호
	 */
	public java.lang.String getOrgTelno() {
		return this.orgTelno;
	}

	/**
	 * SET 조직대표전화번호
	 */
	public void setOrgTelno(java.lang.String orgTelno) {
		this.orgTelno = orgTelno;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((orgTelno == null) ? 0 : orgTelno.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrgTelnoInfo other = (OrgTelnoInfo) obj;
		if (orgTelno == null) {
			if (other.orgTelno != null)
				return false;
		} else if (!orgTelno.equals(other.orgTelno))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("OrgTelnoInfo[\n");
		sb.append("	orgTelno(조직대표전화번호) = " + orgTelno);
		sb.append("\n");		
		sb.append("]");
		return sb.toString();
	}

}
