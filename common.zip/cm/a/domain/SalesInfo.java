/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Mon Nov 05 11:40:28 KST 2012
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName SalesInfo
 * @Description 
 */
public class SalesInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = -1505912712L;
	/**
	 * @Type java.lang.String
	 * @Name hldyKcd
	 * @Description 휴일종류코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String hldyKcd;
	/**
	 * @Type java.lang.String
	 * @Name baseDt
	 * @Description 기준일자
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String baseDt;
	/**
	 * @Type java.lang.String
	 * @Name bfSalesDt
	 * @Description 전영업일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String salesDt;
	/**
	 * @Type java.lang.String
	 * @Name bfSalesDt
	 * @Description 전영업일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfSalesDt;
	/**
	 * @Type java.lang.String
	 * @Name afSaesDt
	 * @Description 익영업일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afSaesDt;
	/**
	 * @Type java.lang.String
	 * @Name af2SaesDt
	 * @Description 익익영업일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String af2SaesDt;
	/**
	 * @Type java.lang.String
	 * @Name hldyYn
	 * @Description 휴일여부
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String hldyYn;

	/**
	 * GET 휴일종류코드
	 */
	public java.lang.String getHldyKcd() {
		return this.hldyKcd;
	}

	/**
	 * SET 휴일종류코드
	 */
	public void setHldyKcd(java.lang.String hldyKcd) {
		this.hldyKcd = hldyKcd;
	}

	/**
	 * GET 기준일자
	 */
	public java.lang.String getBaseDt() {
		return this.baseDt;
	}

	/**
	 * SET 기준일자
	 */
	public void setBaseDt(java.lang.String baseDt) {
		this.baseDt = baseDt;
	}
	
	/**
	 * GET 영업일
	 */
	public java.lang.String getSalesDt() {
		return this.salesDt;
	}

	/**
	 * SET 영업일
	 */
	public void setSalesDt(java.lang.String salesDt) {
		this.salesDt = salesDt;
	}

	/**
	 * GET 전영업일
	 */
	public java.lang.String getBfSalesDt() {
		return this.bfSalesDt;
	}

	/**
	 * SET 전영업일
	 */
	public void setBfSalesDt(java.lang.String bfSalesDt) {
		this.bfSalesDt = bfSalesDt;
	}

	/**
	 * GET 익영업일
	 */
	public java.lang.String getAfSaesDt() {
		return this.afSaesDt;
	}

	/**
	 * SET 익영업일
	 */
	public void setAfSaesDt(java.lang.String afSaesDt) {
		this.afSaesDt = afSaesDt;
	}

	/**
	 * GET 익익영업일
	 */
	public java.lang.String getAf2SaesDt() {
		return this.af2SaesDt;
	}

	/**
	 * SET 익익영업일
	 */
	public void setAf2SaesDt(java.lang.String af2SaesDt) {
		this.af2SaesDt = af2SaesDt;
	}

	/**
	 * GET 휴일여부
	 */
	public java.lang.String getHldyYn() {
		return this.hldyYn;
	}

	/**
	 * SET 휴일여부
	 */
	public void setHldyYn(java.lang.String hldyYn) {
		this.hldyYn = hldyYn;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hldyKcd == null) ? 0 : hldyKcd.hashCode());
		result = prime * result + ((baseDt == null) ? 0 : baseDt.hashCode());
		result = prime * result
				+ ((salesDt == null) ? 0 : salesDt.hashCode());
		result = prime * result
				+ ((bfSalesDt == null) ? 0 : bfSalesDt.hashCode());
		result = prime * result
				+ ((afSaesDt == null) ? 0 : afSaesDt.hashCode());
		result = prime * result
				+ ((af2SaesDt == null) ? 0 : af2SaesDt.hashCode());
		result = prime * result + ((hldyYn == null) ? 0 : hldyYn.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SalesInfo other = (SalesInfo) obj;
		if (hldyKcd == null) {
			if (other.hldyKcd != null)
				return false;
		} else if (!hldyKcd.equals(other.hldyKcd))
			return false;
		if (baseDt == null) {
			if (other.baseDt != null)
				return false;
		} else if (!baseDt.equals(other.baseDt))
			return false;
		if (salesDt == null) {
			if (other.salesDt != null)
				return false;
		} else if (!salesDt.equals(other.salesDt))
			return false;
		if (bfSalesDt == null) {
			if (other.bfSalesDt != null)
				return false;
		} else if (!bfSalesDt.equals(other.bfSalesDt))
			return false;
		if (afSaesDt == null) {
			if (other.afSaesDt != null)
				return false;
		} else if (!afSaesDt.equals(other.afSaesDt))
			return false;
		if (af2SaesDt == null) {
			if (other.af2SaesDt != null)
				return false;
		} else if (!af2SaesDt.equals(other.af2SaesDt))
			return false;
		if (hldyYn == null) {
			if (other.hldyYn != null)
				return false;
		} else if (!hldyYn.equals(other.hldyYn))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("SalesInfo[\n");
		sb.append("	baseDt(기준일자) = " + baseDt);
		sb.append("\n");
		sb.append("	salesDt(영업일) = " + salesDt);
		sb.append("\n");
		sb.append("	bfSalesDt(전영업일) = " + bfSalesDt);
		sb.append("\n");
		sb.append("	afSaesDt(익영업일) = " + afSaesDt);
		sb.append("\n");
		sb.append("	af2SaesDt(익익영업일) = " + af2SaesDt);
		sb.append("\n");
		sb.append("	hldyKcd(휴일종류코드) = " + hldyKcd);
		sb.append("\n");		
		sb.append("	hldyYn(휴일여부) = " + hldyYn);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
