/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Thu Dec 13 13:15:26 KST 2012
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName SmsMsgInfo
 * @Description 
 */
public class SmsMsgInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = -137141416L;
	/**
	 * @Type java.lang.String
	 * @Name msgDprcsObjDcdcd
	 * @Description 처리대상구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String prcsObjDcd;	
	/**
	 * @Type java.lang.String
	 * @Name msgDcd
	 * @Description 메시지구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String msgDcd;
	/**
	 * @Type java.lang.String
	 * @Name regDt
	 * @Description 등록일자
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String regDt;
	/**
	 * @Type java.lang.String
	 * @Name regTi
	 * @Description 등록시각
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String regTi;	
	/**
	 * @Type java.lang.String
	 * @Name linalifeSvcId
	 * @Description 라이나생명서비스ID
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String linalifeSvcId;
	/**
	 * @Type java.lang.String
	 * @Name ecaSvcNo
	 * @Description 이케어서비스번호
	 * @Length 15
	 * @Decimal 0
	 */
	private java.lang.String ecaSvcNo;
	/**
	 * @Type java.lang.String
	 * @Name sndEno
	 * @Description 발송사원번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String sndEno;
	/**
	 * @Type java.lang.String
	 * @Name sndOrgNo
	 * @Description 발송조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String sndOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name msgReceCustRfNo
	 * @Description 메시지수신고객참조번호
	 * @Length 82
	 * @Decimal 0
	 */
	private java.lang.String msgReceCustRfNo;
	/**
	 * @Type java.lang.String
	 * @Name msgReceCustNm
	 * @Description 메시지수신고객명
	 * @Length 40
	 * @Decimal 0
	 */
	private java.lang.String msgReceCustNm;
	/**
	 * @Type java.lang.String
	 * @Name receCustEmailMpno
	 * @Description 수신고객이메일휴대전화번호
	 * @Length 146
	 * @Decimal 0
	 */
	private java.lang.String receCustEmailMpno;
	/**
	 * @Type java.lang.String
	 * @Name sndEmplEmailTelno
	 * @Description 발송사원이메일전화번호
	 * @Length 146
	 * @Decimal 0
	 */
	private java.lang.String sndEmplEmailTelno;
	/**
	 * @Type java.lang.Integer
	 * @Name msgDataLen
	 * @Description 메시지데이터길이
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.Integer msgDataLen;
	/**
	 * @Type java.lang.String
	 * @Name usrBigQtyDataCtnt
	 * @Description 사용자대량데이터내용
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrBigQtyDataCtnt;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt2
	 * @Description 사용자데이터내용2
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt2;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt3
	 * @Description 사용자데이터내용3
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt3;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt4
	 * @Description 사용자데이터내용4
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt4;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt5
	 * @Description 사용자데이터내용5
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt5;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt6
	 * @Description 사용자데이터내용6
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt6;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt7
	 * @Description 사용자데이터내용7
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt7;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt8
	 * @Description 사용자데이터내용8
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt8;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt9
	 * @Description 사용자데이터내용9
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt9;
	/**
	 * @Type java.lang.String
	 * @Name usrDataCtnt10
	 * @Description 사용자데이터내용10
	 * @Length 3000
	 * @Decimal 0
	 */
	private java.lang.String usrDataCtnt10;

	
	/**
	 * GET 처리대상구분코드
	 */
	public java.lang.String getPrcsObjDcd() {
		return this.prcsObjDcd;
	}

	/**
	 * SET 처리대상구분코드
	 */
	public void setPrcsObjDcd(java.lang.String prcsObjDcd) {
		this.prcsObjDcd = prcsObjDcd;
	}
	
	/**
	 * GET 메시지구분코드
	 */
	public java.lang.String getMsgDcd() {
		return this.msgDcd;
	}

	/**
	 * SET 메시지구분코드
	 */
	public void setMsgDcd(java.lang.String msgDcd) {
		this.msgDcd = msgDcd;
	}

	/**
	 * GET 등록일자
	 */
	public java.lang.String getRegDt() {
		return this.regDt;
	}

	/**
	 * SET 등록일자
	 */
	public void setRegDt(java.lang.String regDt) {
		this.regDt = regDt;
	}
	
	/**
	 * GET 등록시각
	 */
	public java.lang.String getRegTi() {
		return this.regTi;
	}

	/**
	 * SET 등록시각
	 */
	public void setRegTi(java.lang.String regTi) {
		this.regTi = regTi;
	}
	
	/**
	 * GET 라이나생명서비스ID
	 */
	public java.lang.String getLinalifeSvcId() {
		return this.linalifeSvcId;
	}

	/**
	 * SET 라이나생명서비스ID
	 */
	public void setLinalifeSvcId(java.lang.String linalifeSvcId) {
		this.linalifeSvcId = linalifeSvcId;
	}

	/**
	 * GET 이케어서비스번호
	 */
	public java.lang.String getEcaSvcNo() {
		return this.ecaSvcNo;
	}

	/**
	 * SET 이케어서비스번호
	 */
	public void setEcaSvcNo(java.lang.String ecaSvcNo) {
		this.ecaSvcNo = ecaSvcNo;
	}

	/**
	 * GET 발송사원번호
	 */
	public java.lang.String getSndEno() {
		return this.sndEno;
	}

	/**
	 * SET 발송사원번호
	 */
	public void setSndEno(java.lang.String sndEno) {
		this.sndEno = sndEno;
	}

	/**
	 * GET 발송조직번호
	 */
	public java.lang.String getSndOrgNo() {
		return this.sndOrgNo;
	}

	/**
	 * SET 발송조직번호
	 */
	public void setSndOrgNo(java.lang.String sndOrgNo) {
		this.sndOrgNo = sndOrgNo;
	}

	/**
	 * GET 메시지수신고객참조번호
	 */
	public java.lang.String getMsgReceCustRfNo() {
		return this.msgReceCustRfNo;
	}

	/**
	 * SET 메시지수신고객참조번호
	 */
	public void setMsgReceCustRfNo(java.lang.String msgReceCustRfNo) {
		this.msgReceCustRfNo = msgReceCustRfNo;
	}

	/**
	 * GET 메시지수신고객명
	 */
	public java.lang.String getMsgReceCustNm() {
		return this.msgReceCustNm;
	}

	/**
	 * SET 메시지수신고객명
	 */
	public void setMsgReceCustNm(java.lang.String msgReceCustNm) {
		this.msgReceCustNm = msgReceCustNm;
	}

	/**
	 * GET 수신고객이메일휴대전화번호
	 */
	public java.lang.String getReceCustEmailMpno() {
		return this.receCustEmailMpno;
	}

	/**
	 * SET 수신고객이메일휴대전화번호
	 */
	public void setReceCustEmailMpno(java.lang.String receCustEmailMpno) {
		this.receCustEmailMpno = receCustEmailMpno;
	}

	/**
	 * GET 발송사원이메일전화번호
	 */
	public java.lang.String getSndEmplEmailTelno() {
		return this.sndEmplEmailTelno;
	}

	/**
	 * SET 발송사원이메일전화번호
	 */
	public void setSndEmplEmailTelno(java.lang.String sndEmplEmailTelno) {
		this.sndEmplEmailTelno = sndEmplEmailTelno;
	}

	/**
	 * GET 메시지데이터길이
	 */
	public java.lang.Integer getMsgDataLen() {
		return this.msgDataLen;
	}

	/**
	 * SET 메시지데이터길이
	 */
	public void setMsgDataLen(java.lang.Integer msgDataLen) {
		this.msgDataLen = msgDataLen;
	}

	/**
	 * GET 사용자대량데이터내용
	 */
	public java.lang.String getUsrBigQtyDataCtnt() {
		return this.usrBigQtyDataCtnt;
	}

	/**
	 * SET 사용자대량데이터내용
	 */
	public void setUsrBigQtyDataCtnt(java.lang.String usrBigQtyDataCtnt) {
		this.usrBigQtyDataCtnt = usrBigQtyDataCtnt;
	}

	/**
	 * GET 사용자데이터내용2
	 */
	public java.lang.String getUsrDataCtnt2() {
		return this.usrDataCtnt2;
	}

	/**
	 * SET 사용자데이터내용2
	 */
	public void setUsrDataCtnt2(java.lang.String usrDataCtnt2) {
		this.usrDataCtnt2 = usrDataCtnt2;
	}

	/**
	 * GET 사용자데이터내용3
	 */
	public java.lang.String getUsrDataCtnt3() {
		return this.usrDataCtnt3;
	}

	/**
	 * SET 사용자데이터내용3
	 */
	public void setUsrDataCtnt3(java.lang.String usrDataCtnt3) {
		this.usrDataCtnt3 = usrDataCtnt3;
	}

	/**
	 * GET 사용자데이터내용4
	 */
	public java.lang.String getUsrDataCtnt4() {
		return this.usrDataCtnt4;
	}

	/**
	 * SET 사용자데이터내용4
	 */
	public void setUsrDataCtnt4(java.lang.String usrDataCtnt4) {
		this.usrDataCtnt4 = usrDataCtnt4;
	}

	/**
	 * GET 사용자데이터내용5
	 */
	public java.lang.String getUsrDataCtnt5() {
		return this.usrDataCtnt5;
	}

	/**
	 * SET 사용자데이터내용5
	 */
	public void setUsrDataCtnt5(java.lang.String usrDataCtnt5) {
		this.usrDataCtnt5 = usrDataCtnt5;
	}

	/**
	 * GET 사용자데이터내용6
	 */
	public java.lang.String getUsrDataCtnt6() {
		return this.usrDataCtnt6;
	}

	/**
	 * SET 사용자데이터내용6
	 */
	public void setUsrDataCtnt6(java.lang.String usrDataCtnt6) {
		this.usrDataCtnt6 = usrDataCtnt6;
	}

	/**
	 * GET 사용자데이터내용7
	 */
	public java.lang.String getUsrDataCtnt7() {
		return this.usrDataCtnt7;
	}

	/**
	 * SET 사용자데이터내용7
	 */
	public void setUsrDataCtnt7(java.lang.String usrDataCtnt7) {
		this.usrDataCtnt7 = usrDataCtnt7;
	}

	/**
	 * GET 사용자데이터내용8
	 */
	public java.lang.String getUsrDataCtnt8() {
		return this.usrDataCtnt8;
	}

	/**
	 * SET 사용자데이터내용8
	 */
	public void setUsrDataCtnt8(java.lang.String usrDataCtnt8) {
		this.usrDataCtnt8 = usrDataCtnt8;
	}

	/**
	 * GET 사용자데이터내용9
	 */
	public java.lang.String getUsrDataCtnt9() {
		return this.usrDataCtnt9;
	}

	/**
	 * SET 사용자데이터내용9
	 */
	public void setUsrDataCtnt9(java.lang.String usrDataCtnt9) {
		this.usrDataCtnt9 = usrDataCtnt9;
	}

	/**
	 * GET 사용자데이터내용10
	 */
	public java.lang.String getUsrDataCtnt10() {
		return this.usrDataCtnt10;
	}

	/**
	 * SET 사용자데이터내용10
	 */
	public void setUsrDataCtnt10(java.lang.String usrDataCtnt10) {
		this.usrDataCtnt10 = usrDataCtnt10;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((prcsObjDcd == null) ? 0 : prcsObjDcd.hashCode());
		result = prime * result + ((msgDcd == null) ? 0 : msgDcd.hashCode());
		result = prime * result + ((regDt == null) ? 0 : regDt.hashCode());
		result = prime * result + ((regTi == null) ? 0 : regTi.hashCode());
		result = prime * result
				+ ((linalifeSvcId == null) ? 0 : linalifeSvcId.hashCode());
		result = prime * result
				+ ((ecaSvcNo == null) ? 0 : ecaSvcNo.hashCode());
		result = prime * result + ((sndEno == null) ? 0 : sndEno.hashCode());
		result = prime * result
				+ ((sndOrgNo == null) ? 0 : sndOrgNo.hashCode());
		result = prime * result
				+ ((msgReceCustRfNo == null) ? 0 : msgReceCustRfNo.hashCode());
		result = prime * result
				+ ((msgReceCustNm == null) ? 0 : msgReceCustNm.hashCode());
		result = prime
				* result
				+ ((receCustEmailMpno == null) ? 0 : receCustEmailMpno
						.hashCode());
		result = prime
				* result
				+ ((sndEmplEmailTelno == null) ? 0 : sndEmplEmailTelno
						.hashCode());
		result = prime * result
				+ ((msgDataLen == null) ? 0 : msgDataLen.hashCode());
		result = prime * result
				+ ((usrBigQtyDataCtnt == null) ? 0 : usrBigQtyDataCtnt.hashCode());
		result = prime * result
				+ ((usrDataCtnt2 == null) ? 0 : usrDataCtnt2.hashCode());
		result = prime * result
				+ ((usrDataCtnt3 == null) ? 0 : usrDataCtnt3.hashCode());
		result = prime * result
				+ ((usrDataCtnt4 == null) ? 0 : usrDataCtnt4.hashCode());
		result = prime * result
				+ ((usrDataCtnt5 == null) ? 0 : usrDataCtnt5.hashCode());
		result = prime * result
				+ ((usrDataCtnt6 == null) ? 0 : usrDataCtnt6.hashCode());
		result = prime * result
				+ ((usrDataCtnt7 == null) ? 0 : usrDataCtnt7.hashCode());
		result = prime * result
				+ ((usrDataCtnt8 == null) ? 0 : usrDataCtnt8.hashCode());
		result = prime * result
				+ ((usrDataCtnt9 == null) ? 0 : usrDataCtnt9.hashCode());
		result = prime * result
				+ ((usrDataCtnt10 == null) ? 0 : usrDataCtnt10.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SmsMsgInfo other = (SmsMsgInfo) obj;
		if (prcsObjDcd == null) {
			if (other.prcsObjDcd != null)
				return false;
		} else if (!prcsObjDcd.equals(other.prcsObjDcd))
			return false;
		if (msgDcd == null) {
			if (other.msgDcd != null)
				return false;
		} else if (!msgDcd.equals(other.msgDcd))
			return false;
		if (regDt == null) {
			if (other.regDt != null)
				return false;
		} else if (!regDt.equals(other.regDt))
			return false;
		if (regTi == null) {
			if (other.regTi != null)
				return false;
		} else if (!regTi.equals(other.regTi))
			return false;		
		if (linalifeSvcId == null) {
			if (other.linalifeSvcId != null)
				return false;
		} else if (!linalifeSvcId.equals(other.linalifeSvcId))
			return false;
		if (ecaSvcNo == null) {
			if (other.ecaSvcNo != null)
				return false;
		} else if (!ecaSvcNo.equals(other.ecaSvcNo))
			return false;
		if (sndEno == null) {
			if (other.sndEno != null)
				return false;
		} else if (!sndEno.equals(other.sndEno))
			return false;
		if (sndOrgNo == null) {
			if (other.sndOrgNo != null)
				return false;
		} else if (!sndOrgNo.equals(other.sndOrgNo))
			return false;
		if (msgReceCustRfNo == null) {
			if (other.msgReceCustRfNo != null)
				return false;
		} else if (!msgReceCustRfNo.equals(other.msgReceCustRfNo))
			return false;
		if (msgReceCustNm == null) {
			if (other.msgReceCustNm != null)
				return false;
		} else if (!msgReceCustNm.equals(other.msgReceCustNm))
			return false;
		if (receCustEmailMpno == null) {
			if (other.receCustEmailMpno != null)
				return false;
		} else if (!receCustEmailMpno.equals(other.receCustEmailMpno))
			return false;
		if (sndEmplEmailTelno == null) {
			if (other.sndEmplEmailTelno != null)
				return false;
		} else if (!sndEmplEmailTelno.equals(other.sndEmplEmailTelno))
			return false;
		if (msgDataLen == null) {
			if (other.msgDataLen != null)
				return false;
		} else if (!msgDataLen.equals(other.msgDataLen))
			return false;
		if (usrBigQtyDataCtnt == null) {
			if (other.usrBigQtyDataCtnt != null)
				return false;
		} else if (!usrBigQtyDataCtnt.equals(other.usrBigQtyDataCtnt))
			return false;
		if (usrDataCtnt2 == null) {
			if (other.usrDataCtnt2 != null)
				return false;
		} else if (!usrDataCtnt2.equals(other.usrDataCtnt2))
			return false;
		if (usrDataCtnt3 == null) {
			if (other.usrDataCtnt3 != null)
				return false;
		} else if (!usrDataCtnt3.equals(other.usrDataCtnt3))
			return false;
		if (usrDataCtnt4 == null) {
			if (other.usrDataCtnt4 != null)
				return false;
		} else if (!usrDataCtnt4.equals(other.usrDataCtnt4))
			return false;
		if (usrDataCtnt5 == null) {
			if (other.usrDataCtnt5 != null)
				return false;
		} else if (!usrDataCtnt5.equals(other.usrDataCtnt5))
			return false;
		if (usrDataCtnt6 == null) {
			if (other.usrDataCtnt6 != null)
				return false;
		} else if (!usrDataCtnt6.equals(other.usrDataCtnt6))
			return false;
		if (usrDataCtnt7 == null) {
			if (other.usrDataCtnt7 != null)
				return false;
		} else if (!usrDataCtnt7.equals(other.usrDataCtnt7))
			return false;
		if (usrDataCtnt8 == null) {
			if (other.usrDataCtnt8 != null)
				return false;
		} else if (!usrDataCtnt8.equals(other.usrDataCtnt8))
			return false;
		if (usrDataCtnt9 == null) {
			if (other.usrDataCtnt9 != null)
				return false;
		} else if (!usrDataCtnt9.equals(other.usrDataCtnt9))
			return false;
		if (usrDataCtnt10 == null) {
			if (other.usrDataCtnt10 != null)
				return false;
		} else if (!usrDataCtnt10.equals(other.usrDataCtnt10))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("SmsMsgInfo[\n");
		sb.append("	prcsObjDcd(처리대상구분코드) = " + prcsObjDcd);
		sb.append("\n");
		sb.append("	msgDcd(메시지구분코드) = " + msgDcd);
		sb.append("\n");
		sb.append("	regDt(등록일자) = " + regDt);
		sb.append("\n");
		sb.append("	regTi(등록시각) = " + regTi);
		sb.append("\n");
		sb.append("	linalifeSvcId(라이나생명서비스ID) = " + linalifeSvcId);
		sb.append("\n");
		sb.append("	ecaSvcNo(이케어서비스번호) = " + ecaSvcNo);
		sb.append("\n");
		sb.append("	sndEno(발송사원번호) = " + sndEno);
		sb.append("\n");
		sb.append("	sndOrgNo(발송조직번호) = " + sndOrgNo);
		sb.append("\n");
		sb.append("	msgReceCustRfNo(메시지수신고객참조번호) = " + msgReceCustRfNo);
		sb.append("\n");
		sb.append("	msgReceCustNm(메시지수신고객명) = " + msgReceCustNm);
		sb.append("\n");
		sb.append("	receCustEmailMpno(수신고객이메일휴대전화번호) = " + receCustEmailMpno);
		sb.append("\n");
		sb.append("	sndEmplEmailTelno(발송사원이메일전화번호) = " + sndEmplEmailTelno);
		sb.append("\n");
		sb.append("	msgDataLen(메시지데이터길이) = " + msgDataLen);
		sb.append("\n");
		sb.append("	usrBigQtyDataCtnt(사용자대량데이터내용) = " + usrBigQtyDataCtnt);
		sb.append("\n");
		sb.append("	usrDataCtnt2(사용자데이터내용2) = " + usrDataCtnt2);
		sb.append("\n");
		sb.append("	usrDataCtnt3(사용자데이터내용3) = " + usrDataCtnt3);
		sb.append("\n");
		sb.append("	usrDataCtnt4(사용자데이터내용4) = " + usrDataCtnt4);
		sb.append("\n");
		sb.append("	usrDataCtnt5(사용자데이터내용5) = " + usrDataCtnt5);
		sb.append("\n");
		sb.append("	usrDataCtnt6(사용자데이터내용6) = " + usrDataCtnt6);
		sb.append("\n");
		sb.append("	usrDataCtnt7(사용자데이터내용7) = " + usrDataCtnt7);
		sb.append("\n");
		sb.append("	usrDataCtnt8(사용자데이터내용8) = " + usrDataCtnt8);
		sb.append("\n");
		sb.append("	usrDataCtnt9(사용자데이터내용9) = " + usrDataCtnt9);
		sb.append("\n");
		sb.append("	usrDataCtnt10(사용자데이터내용10) = " + usrDataCtnt10);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
