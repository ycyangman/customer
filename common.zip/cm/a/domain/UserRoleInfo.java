/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Mon May 06 14:39:10 KST 2013
 * 
 */
package cigna.cm.a.domain;

import java.io.Serializable;

/**
 * @DataObjectName UserRoleInfo
 * @Description 
 */
public class UserRoleInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 1837103569L;
	/**
	 * @Type java.lang.String
	 * @Name roleDscNo
	 * @Description 역할식별번호
	 * @Length 5
	 * @Decimal 0
	 */
	private java.lang.String roleDscNo;
	/**
	 * @Type java.lang.String
	 * @Name roleNm
	 * @Description 역할명
	 * @Length 100
	 * @Decimal 0
	 */
	private java.lang.String roleNm;

	/**
	 * GET 역할식별번호
	 */
	public java.lang.String getRoleDscNo() {
		return this.roleDscNo;
	}

	/**
	 * SET 역할식별번호
	 */
	public void setRoleDscNo(java.lang.String roleDscNo) {
		this.roleDscNo = roleDscNo;
	}

	/**
	 * GET 역할명
	 */
	public java.lang.String getRoleNm() {
		return this.roleNm;
	}

	/**
	 * SET 역할명
	 */
	public void setRoleNm(java.lang.String roleNm) {
		this.roleNm = roleNm;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((roleDscNo == null) ? 0 : roleDscNo.hashCode());
		result = prime * result + ((roleNm == null) ? 0 : roleNm.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserRoleInfo other = (UserRoleInfo) obj;
		if (roleDscNo == null) {
			if (other.roleDscNo != null)
				return false;
		} else if (!roleDscNo.equals(other.roleDscNo))
			return false;
		if (roleNm == null) {
			if (other.roleNm != null)
				return false;
		} else if (!roleNm.equals(other.roleNm))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("UserRoleInfo[\n");
		sb.append("	roleDscNo(역할식별번호) = " + roleDscNo);
		sb.append("\n");
		sb.append("	roleNm(역할명) = " + roleNm);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
