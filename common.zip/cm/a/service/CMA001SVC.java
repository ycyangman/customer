package cigna.cm.a.service;

import java.util.List;

import cigna.cm.a.bean.CMA001BEAN;
import cigna.cm.a.io.CMA001SVC01In;
import cigna.cm.a.io.CMA001SVC02In;
import cigna.cm.a.io.CMA001SVC02Out;
import cigna.cm.a.io.CMA001SVC03In;
import cigna.cm.a.io.CMA001SVC03Out;
import cigna.cm.a.io.CMA001SVC04In;
import cigna.cm.a.io.CMA001SVC04Out;
import cigna.cm.a.io.CMA001SVC05In;
import cigna.cm.a.io.CMA001SVC05Out;
import cigna.cm.a.io.TBCMCCD001Io;
import cigna.cm.a.io.TBCMCCD002Io;
import cigna.cm.a.io.TBCMCCD003Io;
import cigna.cm.a.io.TBCMCCD004Io;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.container.cache.data.CommonCode;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file            cigna.cm.a.service.CMA001SVC.java
 * @filetype        java source file
 * @brief           공통코드 모듈 후처리 및 공통코드조회 및 이력조회 서비스
 * @author          박경화
 * @version         1.0
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               박경화                 2012. 7.06.       신규 작성
 * 0.6               박경화                 2012. 7.10.       개발 완료
 * 0.9               박경화                 2012. 7.21.       Class 테스트
 * 1.0               박경화                 2012. 7.21.       단위 테스트     
 *
 */
@KlafService("CMA001SVC")
public class CMA001SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 공통코드 정보 이관 후 후처리 및 조회 관련 빈
	 */
	@Autowired
	private CMA001BEAN cma001bean;

	/*
	 * 공통코드정보 후처리
	 * @param input EAI처리내용
	 * @throws ApplicationException
	 */
	/*
	@KlafServiceOperation( "changeUpdate1" )
	@TransactionalOperation
	public void changeUpdate1(CMA001SVC01In input) throws ApplicationException{
		logger.debug("changeUpdate1 내용없음");
		//this.cma001bean.setComnCdData(input.getEaiWrkDt(), input.getEaiPrcsStaDcd(), input.getEaiRegCnt(), input.getEaiModCnt(), input.getFileRowCnt());
		
	}
	*/
	
	/**
	 * 공통코드 동기화
	 * @param input EAI처리내용
	 * @throws ApplicationException
	 */
	@KlafServiceOperation( "changeUpdate2" )
	@TransactionalOperation
	public void changeUpdate2(CMA001SVC04In input) throws ApplicationException{

		cma001bean.updateComCdList();
		
	}
	
	/**
	 * 공통메시지 동기화
	 * @param input EAI처리내용
	 * @throws ApplicationException
	 */
	@KlafServiceOperation( "changeUpdate3" )
	@TransactionalOperation
	public void changeUpdate3(CMA001SVC04In input) throws ApplicationException{

		cma001bean.updateMsgCdList();
		
	}


	/**
	 * 공통코드목록 조회
	 * @param input 공통코드목록 조회조건
	 * @return CMA001SVC04Out 공통코드목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMA001SVC04Out selectList0(CMA001SVC04In input)
			throws ApplicationException {
		CMA001SVC04Out output = new CMA001SVC04Out();
		
		List<TBCMCCD001Io> comnCdList =  this.cma001bean.getComnCdList(input.getComnCdId(), input.getComnCdNm());

		output.setComnCdList(comnCdList);
		
		if ( output.getComnCdListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getComnCdListCnt()}, null ) ; 
		
		return output;
	}

	/**
	 * 공통코드상세목록 조회
	 * @param input 공통코드상세목록 조회조건
	 * @return CMA001SVC05Out 공통코드상세목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMA001SVC05Out selectList1(CMA001SVC05In input)
			throws ApplicationException {
		
		CMA001SVC05Out output = new CMA001SVC05Out();
		
		List<TBCMCCD002Io> comnCdDetailList =  this.cma001bean.getComnCdDetailList(input.getComnCdId());

		output.setComnCdDetailList(comnCdDetailList);
		
		if ( output.getComnCdDetailListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getComnCdDetailListCnt()}, null ) ; 
		
		return output;
	}
	
	/**
	 * 공통코드목록 조회(캐쉬)
	 * @param input 공통코드목록 조회조건
	 * @return CMA001SVC04Out 공통코드목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMA001SVC04Out selectList2(CMA001SVC04In input)
			throws ApplicationException {
		CMA001SVC04Out output = new CMA001SVC04Out();
		int iCnt = 0; 
		List<CommonCode> comnCdList =  this.cma001bean.getComnCdListCache(input.getComnCdId());
		
		if ( comnCdList == null ) {
			iCnt = -1; 
		} else {
			iCnt = comnCdList.size(); 
		}
		
		output.setComnCdListCnt(iCnt);
		
		if ( output.getComnCdListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getComnCdListCnt()}, null ) ; 
		
		return output;
	}
	
	/**
	 * 공통코드목록 조회(캐쉬 API)
	 * @param input 공통코드목록 조회조건
	 * @return CMA001SVC04Out 공통코드목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMA001SVC04Out selectList3(CMA001SVC04In input)
			throws ApplicationException {
		CMA001SVC04Out output = new CMA001SVC04Out();
		int iCnt = 0; 
		List<CommonCode> comnCdList =  this.cma001bean.getComnCdList(input.getComnCdId());
		
		if ( comnCdList == null ) {
			iCnt = -1; 
		} else {
			iCnt = comnCdList.size(); 
		}
		
		output.setComnCdListCnt(iCnt);
		
		if ( output.getComnCdListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getComnCdListCnt()}, null ) ; 
		
		return output;
	}
}


