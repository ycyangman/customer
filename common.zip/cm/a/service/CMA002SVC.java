package cigna.cm.a.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA002BEAN;
import cigna.cm.a.bean.CMA007BEAN;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.a.domain.SalesInfo;
import cigna.cm.a.io.CMA002SVC00In;
import cigna.cm.a.io.CMA002SVC00Out;
import cigna.cm.a.io.CMA002SVC01In;
import cigna.cm.a.io.CMA002SVC01Out;
import cigna.cm.a.io.CMA002SVC01Sub;
import cigna.cm.a.io.CMA002SVC02In;
import cigna.cm.a.io.CMA002SVC02Out;
import cigna.cm.a.io.CMA002SVC02Sub;
import cigna.cm.a.io.CMA002SVC03In;
import cigna.cm.a.io.CMA002SVC03Out;
import cigna.cm.a.io.CMA002SVC04In;
import cigna.cm.a.io.CMA002SVC04Out;
import cigna.cm.a.io.CMA002SVC05In;
import cigna.cm.a.io.CMA002SVC05Out;
import cigna.cm.a.io.CMA002SVC06In;
import cigna.cm.a.io.CMA002SVC06Out;
import cigna.cm.a.io.CMA002SVC07In;
import cigna.cm.a.io.CMA002SVC07Out;
import cigna.cm.a.io.CMA002SVC08In;
import cigna.cm.a.io.CMA002SVC09In;
import cigna.cm.a.io.TBSLEMP032Io;

/**
 * @file            cigna.cm.a.service.CMA002SVC.java
 * @filetype        java source file
 * @brief           UI 업무지원 공통모듈 (KLAF공통메시지,조직검색,사원검색) SERVICE
 * @author          박경화
 * @version         1.1
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               박경화                 2012. 7.26.       신규 작성
 * 0.6               박경화                 2012. 7.31.       개발 완료
 * 0.9               박경화                 2012. 7.31.       Class 테스트
 * 1.0               박경화                 2012. 7.31.       단위 테스트  
 * 1.1               박경화                 2012.11.06.       selectSingle추가
 * 5.6               임점예                 2014.09.04.       selectSingle추가
 * 
 */
@KlafService("CMA002SVC")
public class CMA002SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * Klaf 공통메시지목록 조회 빈
	 */
	@Autowired
	private CMA002BEAN cma002bean;
	
	/**
	 * 푸시 서비스 관리 빈
	 */
	@Autowired
	private CMA007BEAN cma007bean;
	
	
	/**
	 * Klaf 공통메시지목록 조회
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList")
	public CMA002SVC00Out selectList(CMA002SVC00In input) throws ApplicationException {
		CMA002SVC00Out output = null;
		
		// 푸시 서비스관련 정보저장
		this.cma007bean.setEnoIpAddr();
		
		// Klaf 공통메시지목록 조회
		output = this.cma002bean.getKlafComnMsgList(input) ;
		
		
		if ( output.getKlafComnMsgCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getKlafComnMsgCnt()}, null ) ; 
		
		return output;
	}
	
	/**
	 * 조직검색
	 * @param input 조직검색 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMA002SVC01Out selectList0(CMA002SVC01In input) throws ApplicationException {
		
	    CMA002SVC01Out output = new CMA002SVC01Out();
		
        List<CMA002SVC01Sub> orgList = this.cma002bean.getOrgList(input.getInqDvsn(), input.getInqNm(), input.getOrgStats(), input.getFacOrgNo(), input.getOrgTpcd(), input.getBzprtCd(), input.getPageNum(), input.getPageCount());
       
	    output.setOrgList(orgList);

	    logger.debug("info1{1}, info2{2}" , input.getFacOrgNo(), input.getInqNm());
	    
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(orgList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		if ( output.getListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			int totalCount = ((input.getPageNum()-1)*input.getPageCount()) + output.getListCnt();
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{totalCount}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{totalCount}, null);
			}
		}

		return output;
	}
	
	/**
	 * 사원검색
	 * @param input 사원검색 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMA002SVC02Out selectList1(CMA002SVC02In input) throws ApplicationException {
		
	    CMA002SVC02Out output = new CMA002SVC02Out();
	    
        List<CMA002SVC02Sub> emplList = this.cma002bean.getEmplList(input.getInqDvsn(), input.getInqNm(), input.getEmplTpcd(), input.getRtmtDcd(), input.getOrgNo(), input.getBzprtCd(), input.getPageNum(), input.getPageCount()); 
        		
	    output.setEmplList(emplList);

		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(emplList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		if ( output.getListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			int totalCount = ((input.getPageNum()-1)*input.getPageCount()) + output.getListCnt();
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{totalCount}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{totalCount}, null);
			}
		}

		return output;
	}
	
	/**
	 * 사원정보조회
	 * UI 글로벌 변수  셋팅용
	 * @param input 사원번호
	 * @return EmplInfo 사원정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle")
	public CMA002SVC03Out selectSingle(CMA002SVC03In input)	throws ApplicationException {
		CMA002SVC03Out output = null;
		
		CommEmplInfo emplinfo = this.cma002bean.getEmplInfo(input.getEno());
		
		// 조회된 내용이 없는 경우, 오류처리
		if (emplinfo == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage( "KIOKI0004", null, null) ; 
		} else {
			
			output = new CMA002SVC03Out();

			output.setEno(emplinfo.getEno());				//사원번호
			output.setEmplNm(emplinfo.getEmplNm());			//사원명
			output.setEmplTpcd(emplinfo.getEmplTpcd());		//사원유형코드
			output.setEmplKcd(emplinfo.getEmplKcd());		//사원종류코드
			output.setJbdtyCd(emplinfo.getJbdtyCd());		//직책코드
			output.setOfrnkCd(emplinfo.getOfrnkCd());		//직급코드
			output.setOrgNo(emplinfo.getOrgNo());			//조직번호
			output.setTeamNo(emplinfo.getTeamNo());		//팀번호
			output.setAgncyEmplTpcd(emplinfo.getAgncyEmplTpcd());	//대리점사원유형코드
			output.setOrgNm(emplinfo.getOrgNm());          	//조직명
			output.setBzprtCd(emplinfo.getBzprtCd());		//사업부문코드
			output.setOrgTpcd(emplinfo.getOrgTpcd());		//조직유형코드
			output.setOrgAttrCd(emplinfo.getOrgAttrCd());	//조직속성코드
			output.setOrgKcd(emplinfo.getOrgKcd());			//조직종류코드
			output.setOrgChrctCd(emplinfo.getOrgChrctCd());	//조직특성코드
			output.setHqOrgNo(emplinfo.getHqOrgNo()); 		//본부조직번호
			output.setHqOrgNm(emplinfo.getHqOrgNm());		//본부조직명
			output.setDofOrgNo(emplinfo.getDofOrgNo());		//지점조직번호
			output.setDofOrgNm(emplinfo.getDofOrgNm());		//지점조직명
			output.setFofOrgNo(emplinfo.getFofOrgNo());		//영업소조직번호
			output.setFofOrgNm(emplinfo.getFofOrgNm());		//영업소조직명
			output.setPlazaOrgNo(emplinfo.getPlazaOrgNo());	//플라자조직번호
			output.setPlazaOrgNm(emplinfo.getPlazaOrgNm());	//플라자조직명
			output.setBrnchOrgNo(emplinfo.getBrnchOrgNo());	//브랜치조직번호
			output.setBrnchOrgNm(emplinfo.getBrnchOrgNm());	//브랜치조직명
			output.setPropoDeptOrgNo(emplinfo.getPropoDeptOrgNo()); //발의부서조직번호
			output.setPropoDeptOrgNm(emplinfo.getPropoDeptOrgNm()); //발의부서조직명
			output.setOrgTelno(emplinfo.getOrgTelno());	//조직대표전화번호
			output.setCurDtTm(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) + DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE));
			output.setInlnNo(emplinfo.getInlnNo());
			output.setMacAddr(emplinfo.getMacAddr());
			output.setCpstnOrgNo(emplinfo.getCpstnOrgNo());
		}

		// KIOKI001 : 요청하신 내용이 조회 되었습니다.
		LApplicationContext.addMessage("KIOKI0001", null, null);
		
		return output;
	}
	
	/**
	 * 영업일정보조회
	 * @param input 기준일자
	 * @return EmplInfo 사원정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle1")
	public CMA002SVC04Out selectSingle1(CMA002SVC04In input)	throws ApplicationException {
		CMA002SVC04Out output = null;
		
		SalesInfo salesinfo = this.cma002bean.getSalesInfo(input.getBaseDt());
		
		// 조회된 내용이 없는 경우, 오류처리
		if (salesinfo == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage( "KIOKI0004", null, null) ; 
		} else {
			output = new CMA002SVC04Out();
			 
			output.setBaseDt(salesinfo.getBaseDt());	    //기준일자
			output.setHldyKcd(salesinfo.getHldyKcd());		//휴일구분코드
			output.setSalesDt(salesinfo.getSalesDt());	    //영업일자
			output.setBfSalesDt(salesinfo.getBfSalesDt());	//전영업일자
			output.setAfSaesDt(salesinfo.getAfSaesDt());	//익영업일자
			output.setAf2SaesDt(salesinfo.getAf2SaesDt());	//익익영업일자
			output.setHldyYn(salesinfo.getHldyYn());		//휴일여부
		}

		// KIOKI001 : 요청하신 내용이 조회 되었습니다.
		LApplicationContext.addMessage("KIOKI0001", null, null);
		return output;
	}
	
	/**
	 * 사원겸직목록조회
	 * @param eno 사원번호
	 * @return cpstnOrgList 겸직정보
	 * @throws ApplicationException
	 */	
	@KlafServiceOperation("selectList2")
	public CMA002SVC05Out selectList2(CMA002SVC05In input) throws ApplicationException {
		
		CMA002SVC05Out output = new CMA002SVC05Out();
		
		List<TBSLEMP032Io> cpstnOrgList =  this.cma002bean.getCpstnOrgNoList(input.getEno());

		output.setCpstnOrgList(cpstnOrgList);
		
		if ( output.getCpstnOrgListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getCpstnOrgListCnt()}, null );
		
		return output;
	}
	
	/**
	 * 사원겸직정보조회
	 * @param input 사원번호
	 * @return EmplInfo 사원정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle2")
	public CMA002SVC06Out selectSingle2(CMA002SVC06In input)	throws ApplicationException {
		
		CMA002SVC06Out output = null;
		
		CMA002SVC06Out cpstnInfo = this.cma002bean.getCpstnOrgInfo(input.getCpstnOrgNo());
		
		// 조회된 내용이 없는 경우, 오류처리
		if (cpstnInfo == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage( "KIOKI0004", null, null) ; 
		} else {
			
			output = new CMA002SVC06Out();

			output.setBzprtCd(cpstnInfo.getBzprtCd());		//사업부문코드
			output.setOrgTpcd(cpstnInfo.getOrgTpcd());		//조직유형코드
			output.setOrgAttrCd(cpstnInfo.getOrgAttrCd());	//조직속성코드
			output.setOrgKcd(cpstnInfo.getOrgKcd());			//조직종류코드
			output.setOrgChrctCd(cpstnInfo.getOrgChrctCd());	//조직특성코드
			output.setHqOrgNo(cpstnInfo.getHqOrgNo()); 		//본부조직번호
			output.setHqOrgNm(cpstnInfo.getHqOrgNm());		//본부조직명
			output.setDofOrgNo(cpstnInfo.getDofOrgNo());		//지점조직번호
			output.setDofOrgNm(cpstnInfo.getDofOrgNm());		//지점조직명
			output.setFofOrgNo(cpstnInfo.getFofOrgNo());		//영업소조직번호
			output.setFofOrgNm(cpstnInfo.getFofOrgNm());		//영업소조직명
			output.setPlazaOrgNo(cpstnInfo.getPlazaOrgNo());	//플라자조직번호
			output.setPlazaOrgNm(cpstnInfo.getPlazaOrgNm());	//플라자조직명
			output.setBrnchOrgNo(cpstnInfo.getBrnchOrgNo());	//브랜치조직번호
			output.setBrnchOrgNm(cpstnInfo.getBrnchOrgNm());	//브랜치조직명
			output.setPropoDeptOrgNo(cpstnInfo.getPropoDeptOrgNo()); //발의부서조직번호
			output.setPropoDeptOrgNm(cpstnInfo.getPropoDeptOrgNm()); //발의부서조직명
			output.setOrgTelno(cpstnInfo.getOrgTelno());	//조직대표전화번호
		}

		// KIOKI001 : 요청하신 내용이 조회 되었습니다.
		LApplicationContext.addMessage("KIOKI0001", null, null);
		return output;
	}	

	/**
	 * 사원 처리부서조직번호
	 * @param input 사원번호
	 * @return String 처리부서조직번호
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle3")
	public CMA002SVC07Out selectSingle3(CMA002SVC07In input)	throws ApplicationException {
		
		CMA002SVC07Out output = new CMA002SVC07Out();
		
		String eno = input.getEno();
		
		String strPrcsDeptNo = this.cma002bean.getPrcsDeptOrgNo(eno);
		
		// 조회된 내용이 없는 경우, 오류처리
		if (strPrcsDeptNo == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage( "KIOKI0004", null, null) ; 
		}
		
		output.setPrcsDeptOrgCd(strPrcsDeptNo);

		// KIOKI001 : 요청하신 내용이 조회 되었습니다.
		LApplicationContext.addMessage("KIOKI0001", null, null);
		
		return output;
	}
	
	/**
	 * 겸직조직정보로 처리부서조직번호 수정
	 * 
	 * @param input 사원번호 처리부서조직번호
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate")
	@TransactionalOperation
	public void changeUpdate(CMA002SVC07In input) throws ApplicationException {
		
		String eno = input.getEno();
		String prcsDeptOrgNo = input.getPrcsDeptOrgNo();
		
		this.cma002bean.setPrcsDeptOrgNo(eno, prcsDeptOrgNo);
		
		LApplicationContext.addMessage("KIOKI0010", null, null);

	}
	
	/**
	 * 채널 사원검색
	 * @param input 사원검색 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMA002SVC02Out selectList3(CMA002SVC08In input) throws ApplicationException {
		
	    CMA002SVC02Out output = new CMA002SVC02Out();
        List<CMA002SVC02Sub> emplList = null;
        
        if (!StringUtils.isEmpty(input.getEno())) {
        	// 사원번호로 검색
        	emplList = this.cma002bean.getEmplList("1", input.getEno(), null, input.getRtmtDcd(), input.getOrgNo(), input.getBzprtCd(), 1, 5000);
        } else {
        	// 사원명으로 조회
        	emplList = this.cma002bean.getEmplList("2", input.getEmplNm(), null, input.getRtmtDcd(), input.getOrgNo(), input.getBzprtCd(), 1, 5000);
        }
	    output.setEmplList(emplList);

		return output;
	}
	
	/**
	 * 채널 조직검색
	 * @param input 사원검색 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList4")
	public CMA002SVC01Out selectList4(CMA002SVC09In input) throws ApplicationException {
		
	    CMA002SVC01Out output = new CMA002SVC01Out();
	    List<CMA002SVC01Sub> orgList = null;
	    
	    if (!StringUtils.isEmpty(input.getOrgNo())) {
	    	orgList = this.cma002bean.getOrgList("1", input.getOrgNo(), input.getOrgStats(), null, input.getOrgTpcd(), input.getBzprtCd(), 1, 5000);
	    } else {
	    	orgList = this.cma002bean.getOrgList("2", input.getOrgNm(), input.getOrgStats(), null, input.getOrgTpcd(), input.getBzprtCd(), 1, 5000);
	    }
	    
	    output.setOrgList(orgList);
	    
		return output;
	}
	
	/**
	 * 사원검색
	 * @param input 사원검색 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList5")
	public CMA002SVC02Out selectList5(CMA002SVC02In input) throws ApplicationException {
	    CMA002SVC02Out output = new CMA002SVC02Out();
	    
        List<CMA002SVC02Sub> emplList = this.cma002bean.getEmplListEquals(input.getInqDvsn(), input.getInqNm()); 
        
	    output.setEmplList(emplList);
	    
		return output;
	}
}

