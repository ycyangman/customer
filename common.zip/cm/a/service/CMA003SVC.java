package cigna.cm.a.service;

import java.util.List;

import cigna.cm.a.bean.CMA003BEAN;
import cigna.cm.a.io.CMA002SVC04Out;
import cigna.cm.a.io.CMA003SVC00In;
import cigna.cm.a.io.CMA003SVC01In;
import cigna.cm.a.io.CMA003SVC02Out;
import cigna.cm.a.io.CMA003SVC03Out;
import cigna.cm.a.io.CMA003SVC03Sub;
import cigna.zz.BizDateUtil;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file            cigna.cm.a.service.CMA003SVC.java
 * @filetype        java source file
 * @brief           영업일 캘린더 조회, 영업일 캘린더 휴일정보 수정하는 서비스
 * @author          박경화
 * @version         1.0
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               박경화                 2012. 7.13.       신규 작성
 * 0.6               박경화                 2012. 7.18.       개발 완료
 * 0.9               박경화                 2012. 7.25.       Class 테스트
 * 1.0               박경화                 2012. 7.25.       단위 테스트     
 *
 */
@KlafService("CMA003SVC")
public class CMA003SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * 영업일정보 조회, 수정하는 빈
	 */
	@Autowired
	private CMA003BEAN cma003bean; 
	
	
	/**
	 * 영업일 캘린더 정보 조회
	 * 
	 * @param input  영업일 캘린더 정보 조회조건
	 * @return CMA003SVC01Out 영업일 캘린더 정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList")
	public CMA003SVC03Out selectList(CMA003SVC00In input) throws ApplicationException {
		
		logger.info("변경된 소스입니다!!!!!!!!!");
		
		CMA003SVC03Out output = new CMA003SVC03Out();
		
		List<CMA003SVC03Sub> bizCalendarList =  this.cma003bean.getBizCalender(input.getScalnYm());
		
		output.setBizCalendarList(bizCalendarList);
		
		if ( output.getBizCalendarListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getBizCalendarListCnt()}, null ) ; 
		
		return output;
	}
	
	@KlafServiceOperation("selectList1")
	public CMA003SVC02Out selectList1(CMA003SVC00In input) throws ApplicationException {
		CMA003SVC02Out output = new CMA003SVC02Out();
		
		List<CMA002SVC04Out> bizCalendarList = this.cma003bean.getBizCalendarCache(input.getScalnYm());
		
		output.setBizDateInfo(bizCalendarList);
		
		if (output.getListCount() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		} else {
			// KIOKI0002: 요청하신 내용 {0}건이 조회 되었습니다.
			LApplicationContext.addMessage("KIOKI0002",	new Object[] {output.getListCount()}, null ) ;
		}

		return output;
	}
	
	/**
	 * 영업일 캘린더 정보 수정
	 * 
	 * @param input 영업일 캘린더 수정 정보 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate")
	@TransactionalOperation
	public CMA003SVC03Out changeUpdate(CMA003SVC01In input) throws ApplicationException {
		
		CMA003SVC03Out output = new CMA003SVC03Out();
		
		int iCnt = this.cma003bean.updateBizCalendar(input);
		
		List<CMA003SVC03Sub> bizCalendarList =  this.cma003bean.getBizCalender(input.getScalnYm());
		
		output.setBizCalendarList(bizCalendarList);

		LApplicationContext.addMessage("KIOKI0010", new Object[]{iCnt}, null);
		
		return output;
	}
	
	/**
	 * 영업일정보 cache 등록 및 삭제
	 * <per>
	 * - 입력년월의 영업일정보를 cache 등록하고 
	 *   입력년월의 18개월전 영업일정로를 cache에서 삭제한다.
	 * </per>
	 * @param input 기준년월
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert")
	@TransactionalOperation
	public void changeInsert(CMA003SVC00In input) throws ApplicationException {
		
		String baseYm = input.getScalnYm();
		
		logger.debug( "입력년월 : {} " , baseYm );
		
		if ( baseYm.isEmpty() ) {
			// 입력값 오류처리
			throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "입력년월" , "yyyyMM 날짜"});
		}
		
		int putRet = cma003bean.putSalesInfo(baseYm);
		
		logger.debug( "cache 등록결과 : {} " , putRet );
		
		String baseYmBefore18= BizDateUtil.getYmMonthsBefore(18, baseYm);
		
		logger.debug( "18개월전 년월 : {} " , baseYmBefore18 );
		
		boolean removeRet = cma003bean.removeSalesInfo(baseYmBefore18);
		
		logger.debug( "cache 삭제결과 : {} " , removeRet );
		

	}
}

