package cigna.cm.a.service;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.a.bean.CMA005BEAN;
import cigna.cm.a.io.CMA005SVC00In;
import cigna.cm.a.io.CMA005SVC00Out;
import cigna.cm.a.io.CMA005SVC00Sub;
import cigna.cm.a.io.CMA005SVC01In;
import cigna.cm.a.io.CMA005SVC01Out;
import cigna.cm.a.io.CMA005SVC01Sub0;
import cigna.cm.a.io.CMA005SVC01Sub1;
import cigna.cm.a.io.CMA005SVC02In;
import cigna.cm.a.io.CMA005SVC02Out;
import cigna.cm.a.io.CMA005SVC02Sub;
import cigna.cm.a.io.CMA005SVC03In;
import cigna.cm.a.io.CMA005SVC04In;
import cigna.cm.a.io.CMA005SVC04Out;
import cigna.cm.a.io.CMA005SVC05In;
import cigna.cm.a.io.CMA005SVC05Out;
import cigna.cm.a.io.CMA005SVC05Sub;
import cigna.cm.a.io.CMA005SVC06In;
import cigna.cm.a.io.CMA005SVC07In;
import cigna.cm.a.io.CMA005SVC08In;
import cigna.cm.a.io.CMA005SVC09In;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file            cigna.cm.a.service.CMA005SVC.java
 * @filetype        java source file
 * @brief           파일관리 SERVICE
 * @author          박경화
 * @version         1.0
 * @history
 * Version           성명                    일자                              변경내용
 * -----------       ------    -----------     ----------------- 
 * 1.0               박경화                 2016.01.30.     신규 작성
 */
@KlafService("CMA005SVC")
public class CMA005SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 파일관리 빈
	 */
	@Autowired
	private CMA005BEAN cma005bean;
	
	
	/**
	 * 파일목록조회
	 * @param input 파일관리번호
	 * @return 파일목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList")
	public CMA005SVC00Out selectList(CMA005SVC00In input) throws ApplicationException {
		
		CMA005SVC00Out output = new CMA005SVC00Out();
		
		List<CMA005SVC00Sub> fileList = this.cma005bean.getFileList(input.getFileMgntNo(), "Y");
		
		output.setFileList(fileList);
		
		if ( output.getFileListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getFileListCnt()}, null ) ; 
		
		return output;
	}
	
	
	/**
	 * 파일 조회
	 * @param input 파일정보
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle")
	public CMA005SVC02Out selectSingle(CMA005SVC02In input) throws ApplicationException {
		
		CMA005SVC02Out output = new CMA005SVC02Out();
		
		CMA005SVC02Sub fileInfo = this.cma005bean.getFileInfo(input);
		
		List<CMA005SVC02Sub> fileInfoList = new ArrayList<CMA005SVC02Sub>();
		fileInfoList.add(fileInfo);
				
		output.setFileInfo(fileInfoList);
		
		if ( output == null || fileInfoList.size() <= 0)
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0001", null, null ) ; 
		
		return output;
	}
	
	/**
	 * 파일목록조회
	 * @param input 파일관리번호
	 * @return 파일목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMA005SVC04Out selectList1(CMA005SVC04In input) throws ApplicationException {
		
		CMA005SVC04Out output = new CMA005SVC04Out();
		
		List<CMA005SVC02Sub> fileInfoList = this.cma005bean.getFileInfoListAll(input.getFileMgntNo());
		
		output.setFileInfoList(fileInfoList);
		
		if ( output.getFileListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getFileListCnt()}, null ) ; 
		
		return output;
	}
	
	/**
	 * 파일목록조회
	 * @param input 파일관리번호
	 * @return 파일목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMA005SVC05Out selectList2(CMA005SVC05In input) throws ApplicationException {
		
		CMA005SVC05Out output = new CMA005SVC05Out();
		
		List<CMA005SVC05Sub> fileListInput = input.getFileList();
		
		List<CMA005SVC00Sub> fileList = this.cma005bean.getFileInfoListMulti(fileListInput);
		
		output.setFileList(fileList);
		
		if ( output.getFileListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getFileListCnt()}, null ) ; 
		
		return output;
	}
	
	/**
	 * 파일관리번호처리여부 저장
	 * @param input 파일관리번호
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate")
	@TransactionalOperation
	public void changeUpdate(CMA005SVC03In input) throws ApplicationException {
		
		boolean bResult = this.cma005bean.setFileMgntNoPrcsYn(input.getFileMgntNo());
		
		logger.debug( "bResult : {} " , bResult );

		LApplicationContext.addMessage("KIOKI0007", null, null);
	}

	/**
	 * 파일신규등록 및 추가, 삭제
	 * @param input 파일추가정보, 파일삭제정보
	 * @return 파일목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert")
	@TransactionalOperation
	public CMA005SVC01Out changeInsert(CMA005SVC01In input) throws ApplicationException {
		
		CMA005SVC01Out 	output = new CMA005SVC01Out();
		
		String fileMgntNo = input.getFileMgntNo();
		
		int filePutListCnt = input.getFilePutListCnt();
		List<CMA005SVC01Sub0> filePutList = input.getFliePutList();
		
		int fileDelListCnt = input.getFileDelListCnt();
		List<CMA005SVC01Sub1> fileDelList = input.getFlieDelList();
		
		String fileMgntNoPrcsYn = "";
		
		int iDelCnt = 0;
		
		if (!StringUtils.isEmpty(fileMgntNo)) {
			fileMgntNoPrcsYn = "Y";
		}
		
		// 파일추가
		if( filePutListCnt > 0 && filePutList.size() > 0 &&  filePutList != null ){
			
			fileMgntNo = this.cma005bean.putFileList(input.getFileMgntBzCd(), input.getFileMgntNo(), filePutListCnt, filePutList);
			
			logger.debug( "fileMgntNo : {} " , fileMgntNo );
		    
		} 
		
		// 파일삭제
		if( fileDelListCnt > 0 && fileDelList.size() > 0 &&  fileDelList != null ){
			
			iDelCnt = this.cma005bean.deleteFileList(fileDelListCnt, fileDelList);
			
			logger.debug( "iDelCnt : {} " , iDelCnt );
		    
		}
		
		
		if (StringUtils.isEmpty(fileMgntNo)) {
			// KIERE0005 : 입력하신 내용을 저장 할 수 없습니다. / {0}으로 저장 할 수 없습니다.
			throw new ApplicationException("KIERE0005", null, new Object[]{"파일처리실패"});
		}
		
		output.setFileMgntNo(fileMgntNo);
		
		List<CMA005SVC00Sub> fileList = this.cma005bean.getFileList(fileMgntNo, fileMgntNoPrcsYn);
		
		logger.debug( "fileList : {} " , fileList );
		
		output.setFileList(fileList);
		
		// 파일추가
		if( filePutListCnt > 0 && filePutList.size() > 0 &&  filePutList != null ){
			LApplicationContext.addMessage("KIOKI0009", null, null);
		}
		
		// 파일삭제
		if( fileDelListCnt > 0 && fileDelList.size() > 0 &&  fileDelList != null ){
			LApplicationContext.addMessage("KIOKI0018", new Object[]{iDelCnt}, null);
		}
		return output;
	
	}
	
	/**
	 * 파일 삭제
	 * @param input 파일추가정보, 파일삭제정보
	 * @return 파일목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeDelete")
	@TransactionalOperation
	public CMA005SVC01Out changeDelete(CMA005SVC01In input) throws ApplicationException {
		
		CMA005SVC01Out 	output = new CMA005SVC01Out();
		
		String fileMgntNo = input.getFileMgntNo();
		
		if (StringUtils.isEmpty(fileMgntNo)) {
			// KIERE0005 : 입력하신 내용을 저장 할 수 없습니다. / {0}으로 저장 할 수 없습니다.
			throw new ApplicationException("KIERE0005", null, new Object[]{"파일처리실패"});
		}
		
		// 파일삭제
		int iDelCnt = 0; 
		iDelCnt = this.cma005bean.deleteFileListOther(fileMgntNo);
		logger.debug( "iDelCnt : {} " , iDelCnt );
	
		output.setFileMgntNo(fileMgntNo);
		
		List<CMA005SVC00Sub> fileList = this.cma005bean.getFileList(fileMgntNo, "Y");
		
		logger.debug( "fileList : {} " , fileList );
		
		output.setFileList(fileList);
		
		// 파일삭제
		if( iDelCnt > 0){
			LApplicationContext.addMessage("KIOKI0018", new Object[]{iDelCnt}, null);
		}
		return output;
	
	}


	/**
	 * 엑셀대량업로드 
	 * @param input 파일정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public void changeInsert1(CMA005SVC06In input) throws ApplicationException {
		
		boolean bResult = this.cma005bean.putFileInfo(input);
		
		
		if (bResult) {
			LApplicationContext.addMessage("KIOKI0021", null, null);
		} else {
			throw new ApplicationException("KIERE0014", null, new Object[]{"파일처리실패"});
		}

	}

	/**
	 * 트랜스로그 파일 업로드
	 * @param input 파일정보
	 * @throws ApplicationException
	 */	
	@KlafServiceOperation("changeInsert2")
	@TransactionalOperation
	public void changeInsert2(CMA005SVC07In input) throws ApplicationException {
		
		boolean bResult = this.cma005bean.putTransLogtFileInfo(input);
		
		if (bResult) {
			LApplicationContext.addMessage("KIOKI0021", null, null);
		} else {
			throw new ApplicationException("KIERE0014", null, new Object[]{"TransLog파일처리실패"});
		}

	}	
	
	/**
	 * 메뉴정보 파일 업로드
	 * @param input 파일정보
	 * @throws ApplicationException
	 */		
	@KlafServiceOperation("changeInsert3")
	@TransactionalOperation
	public void changeInsert3(CMA005SVC08In input) throws ApplicationException {
		
		boolean bResult = this.cma005bean.putMenuInfoFile(input);
		
		if (bResult) {
			LApplicationContext.addMessage("KIOKI0021", null, null);
		} else {
			throw new ApplicationException("KIERE0014", null, new Object[]{"메뉴정보파일처리실패"});
		}

	}
	
	/**
	 * 레포트출력정보 파일 업로드
	 * @param input 파일정보
	 * @throws ApplicationException
	 */		
	@KlafServiceOperation("changeInsert4")
	@TransactionalOperation
	public void changeInsert4(CMA005SVC09In input) throws ApplicationException {
		
		boolean bResult = this.cma005bean.putReportOutInfoFile(input);
		
		if (bResult) {
			LApplicationContext.addMessage("KIOKI0021", null, null);
		} else {
			throw new ApplicationException("KIERE0014", null, new Object[]{"레포트출력정보파일처리실패"});
		}

	}			
}

