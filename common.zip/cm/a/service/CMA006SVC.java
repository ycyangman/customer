package cigna.cm.a.service;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.a.bean.CMA006BEAN;
import cigna.cm.a.io.CMA006SVC00In;
import cigna.cm.a.io.CMA006SVC00Out;
import cigna.cm.a.io.CMA006SVC01In;
import cigna.cm.a.io.CMA006SVC02In;
import cigna.cm.a.io.CMA006SVC02Out;
import cigna.cm.a.io.CMA006SVC02Sub0;
import cigna.cm.a.io.CMA006SVC02Sub1;
import cigna.cm.a.io.CMA006SVC03In;
import cigna.cm.a.io.CMA006SVC03Out;
import cigna.cm.a.io.CMA006SVC04In;
import cigna.cm.a.io.CMA006SVC04Out;
import cigna.cm.a.io.CMA006SVC04Sub;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file         cigna.cm.a.service.CMA006SVC.java
 * @filetype     java source file
 * @brief        엑셀보안결재관리 서비스
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박경화                     2012. 12. 10.       신규 작성
 * 0.6           박경화                     2012. 12. 10.       개발 완료
 * 0.9           박경화                     2012. 12. 11.       Class 테스트
 * 1.0           박경화                     2012. 12. 11.       단위 테스트 
 */
@KlafService("CMA006SVC")
public class CMA006SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 엑셀보안결재관리 빈
	 */
	@Autowired
	private CMA006BEAN cma006bean;

	/**
	 * 엑셀보안결재정보 요청
	 * @param input 엑셀보안결재정보
	 * @return 엑셀보안결재관리번호
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert")
	@TransactionalOperation
	public CMA006SVC00Out changeInsert(CMA006SVC00In input) throws ApplicationException {
		
		CMA006SVC00Out 	output = new CMA006SVC00Out();
		
		String xlsSecuSancMgntNo = this.cma006bean.insertSancReqInfo(input);
		
		if (StringUtils.isEmpty(xlsSecuSancMgntNo)) {
			// KIERE0005 : 입력하신 내용을 저장 할 수 없습니다. / {0}으로 저장 할 수 없습니다.
			throw new ApplicationException("KIERE0014", null, new Object[]{"엑셀보안결재요청 처리 실패"});
		}

		output.setXlsSecuSancMgntNo(xlsSecuSancMgntNo);
		
		LApplicationContext.addMessage("KIOKI0021", null, null);
		
		return output;
	}
	
	/**
	 * 결재요청취소
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate0")
	@TransactionalOperation
	public CMA006SVC02Out changeUpdate0(CMA006SVC01In input) throws ApplicationException {
		
		CMA006SVC02Out 	output = new CMA006SVC02Out();
		
		this.cma006bean.setSancReqCncl(input.getSancInfoList());
		
		CMA006SVC02Sub0 contInfo = input.getContInfo().get(0);
		
		int pageNum = contInfo.getPageNum();
		int pageCount = contInfo.getPageCount();
		
		logger.debug( "pageNum : {} pageCount : {}" , pageNum, pageCount );
		
		contInfo.setPageNum(1);
		contInfo.setPageCount(pageNum*pageCount);
		
		logger.debug( "pageNum : {} pageCount : {}" , contInfo.getPageNum(), contInfo.getPageCount() );
		
		List<CMA006SVC02Sub1> sancList = this.cma006bean.getSancList(contInfo);
		
		output.setSancList(sancList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(sancList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		LApplicationContext.addMessage("KIOKI0015", null, null);
		
		return output;
	}
	
	/**
	 * 결재승인
	 * @param input
	 * @return 결재목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate1")
	@TransactionalOperation
	public CMA006SVC02Out changeUpdate1(CMA006SVC01In input) throws ApplicationException {
		
		CMA006SVC02Out 	output = new CMA006SVC02Out();
		
		this.cma006bean.setSancAprv(input.getSancInfoList());
		
		CMA006SVC02Sub0 contInfo = input.getContInfo().get(0);
		
		int pageNum = contInfo.getPageNum();
		int pageCount = contInfo.getPageCount();
		
		logger.debug( "pageNum : {} pageCount : {}" , pageNum, pageCount );
		
		contInfo.setPageNum(1);
		contInfo.setPageCount(pageNum*pageCount);
		
		logger.debug( "pageNum : {} pageCount : {}" , contInfo.getPageNum(), contInfo.getPageCount() );
		
		List<CMA006SVC02Sub1> sancList = this.cma006bean.getSancList(contInfo);
		
		output.setSancList(sancList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(sancList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		LApplicationContext.addMessage("KIOKI0019", null, null);
		
		return output;
	}
	
	/**
	 * 결재반려
	 * @param input
	 * @return 결재목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate2")
	@TransactionalOperation
	public CMA006SVC02Out changeUpdate2(CMA006SVC01In input) throws ApplicationException {
		
		CMA006SVC02Out 	output = new CMA006SVC02Out();
		
		this.cma006bean.setSancTndw(input.getSancInfoList());
		
		CMA006SVC02Sub0 contInfo = input.getContInfo().get(0);
		
		int pageNum = contInfo.getPageNum();
		int pageCount = contInfo.getPageCount();
		
		logger.debug( "pageNum : {} pageCount : {}" , pageNum, pageCount );
		
		contInfo.setPageNum(1);
		contInfo.setPageCount(pageNum*pageCount);
		
		logger.debug( "pageNum : {} pageCount : {}" , contInfo.getPageNum(), contInfo.getPageCount() );
		
		List<CMA006SVC02Sub1> sancList = this.cma006bean.getSancList(contInfo);
		
		output.setSancList(sancList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(sancList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		LApplicationContext.addMessage("KIOKI0019", null, null);
		
		return output;
	}
	
	/**
	 * 결재목록조회
	 * @param input 조회조건
	 * @return 결재목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList")
	public CMA006SVC02Out selectList(CMA006SVC02In input) throws ApplicationException {
		
		CMA006SVC02Out 	output = new CMA006SVC02Out();
		
		List<CMA006SVC02Sub1> sancList = this.cma006bean.getSancList(input.getContInfo().get(0));
		
		output.setSancList(sancList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(sancList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		if ( output.getSancListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{output.getSancListCnt()}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getSancListCnt()}, null);
			}
		}
		
		return output;
	}
	
	/**
	 * 결재자정보 (소속조직 팀장)
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle0")
	public CMA006SVC03Out selectSingle0(CMA006SVC03In input) throws ApplicationException {
		
		CMA006SVC03Out 	output = this.cma006bean.getSancInfo();
		
		if ( output == null )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0001", null, null ) ; 
		
		return output;
	}
	
	/**
	 * 엑셀파일정보 조회
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle1")
	public CMA006SVC04Out selectSingle1(CMA006SVC04In input) throws ApplicationException {
		
		CMA006SVC04Out output = new CMA006SVC04Out();
		
		CMA006SVC04Sub xlsFileInfo = this.cma006bean.getXlsFile(input.getXlsSecuSancMgntNo());
		
		List<CMA006SVC04Sub> xlsFileList = new ArrayList<CMA006SVC04Sub>();
		
		xlsFileList.add(xlsFileInfo);

		output.setXlsFile(xlsFileList);
		
		if ( xlsFileInfo == null )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0001", null, null ) ; 
		
		return output;
	}
	
}

