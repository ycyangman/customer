package cigna.cm.a.service;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.a.bean.CMA007BEAN;
import cigna.cm.a.io.CMA007SVC00In;
import cigna.cm.a.io.CMA007SVC02Out;
import cigna.cm.a.io.CMA007SVC03In;
import cigna.cm.a.io.CMA007SVC03Out;
import cigna.cm.a.io.CMA007SVC03Sub;
import cigna.cm.a.io.CMA007SVC04In;
import cigna.cm.a.io.CMA007SVC04Out;
import cigna.cm.a.io.CMA007SVC04Sub;
import cigna.cm.a.io.SelectMultiTBCMCCD024Out;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA007SVC.java
 * @filetype     java source file
 * @brief        공통 EAI 관련 인터페이스 서비스
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박경화                     2013. 2. 5.       신규 작성
 * 0.6           박경화                     2013. 2. 5.       개발 완료
 * 
 */
@KlafService("CMA007SVC")
public class CMA007SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA007BEAN cma007bean; 
	
	/**
	 * 푸시서비스 처리결과 조회
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation( "selectList" )
	public CMA007SVC02Out selectList(CMA007SVC00In input)  throws ApplicationException {
		
		CMA007SVC02Out 	output = new CMA007SVC02Out();
		
		List<SelectMultiTBCMCCD024Out> pushList = this.cma007bean.getPushServiceInfo(input);
		
		output.setPushList(pushList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(pushList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		if ( output.getListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{output.getListCnt()}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getListCnt()}, null);
			}
		}		
		
		return output;
		
	}
	
	/**
	 * On Demand Batch 서비스 진행상태 조회
	 * @param glblId 글로벌ID
	 * @return CMA007SVC03Out 상태정보
	 * @throws ApplicationException
	 */		
	@KlafServiceOperation("selectSingle")
	public CMA007SVC03Out selectSingle(CMA007SVC03In input) throws ApplicationException {
		
		CMA007SVC03Out output = new CMA007SVC03Out();
		
		CMA007SVC03Sub batStatusInfo = cma007bean.getBatStautsInfo(input.getGlblId());
		
		if(batStatusInfo == null) {
			output.setBatStcd("000");
			output.setBatStaCtnt("요청하신 온디맨드 배치가 실행되지 않았습니다.");
		}else if("Y".equals(batStatusInfo.getIsSuspended())) {
			output.setBatStcd("200");
			output.setBatStaCtnt("SUSPEND 상태입니다.");
	    }else if("STARTED".equals(batStatusInfo.getStatus()) && ("UNKNOWN".equals(batStatusInfo.getExitCode()) || "EXECUTING".equals(batStatusInfo.getExitCode()))) {
			output.setBatStcd("100");
			output.setBatStaCtnt("요청하신 온디맨드 배치가 실행중입니다.");
	    }else if("COMPLETED".equals(batStatusInfo.getStatus()) && "COMPLETED".equals(batStatusInfo.getExitCode())) {
			output.setBatStcd("500");
			output.setBatStaCtnt("정상적으로 종료되었습니다.");
	    }else if("FAILED".equals(batStatusInfo.getStatus()) || "FAILED".equals(batStatusInfo.getExitCode())) {
			output.setBatStcd("510");
			output.setBatStaCtnt("오류가 발생하여 종료되었습니다.");
	    }else {
			output.setBatStcd("520");
			output.setBatStaCtnt("알 수 없는 오류가 발생하여 종료되었습니다.");
	    }
		return output;
	}
	
	/**
	 * 첨부파일 다운로드
	 * @param input 파일정보
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle1")
	public CMA007SVC04Out selectSingle1(CMA007SVC04In input) throws ApplicationException {
		
		CMA007SVC04Out output = new CMA007SVC04Out();
		
		CMA007SVC04Sub fileInfo = this.cma007bean.getAtchFileDownInfo(input);
		
		List<CMA007SVC04Sub> fileInfoList = new ArrayList<CMA007SVC04Sub>();
		fileInfoList.add(fileInfo);
				
		output.setFileInfo(fileInfoList);
		
		if ( output == null || fileInfoList.size() <= 0)
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0001", null, null ) ; 
		
		return output;
	}	
}

