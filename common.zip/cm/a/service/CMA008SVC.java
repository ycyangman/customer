package cigna.cm.a.service;

import java.util.List;

import cigna.cm.a.bean.CMA008BEAN;
import cigna.cm.a.io.CMA008SVC00In;
import cigna.cm.a.io.CMA008SVC00Out;
import cigna.cm.a.io.CMA008SVC00Sub;
import cigna.cm.a.io.CMA008SVC01In;
import cigna.cm.a.io.CMA008SVC01Out;
import cigna.cm.a.io.CMA008SVC01Sub;
import cigna.cm.a.io.CMA008SVC02Out;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA008SVC.java
 * @filetype     java source file
 * @brief        URL관리 서비스
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박경화                     2013. 2. 6.       신규 작성
 */

@KlafService("CMA008SVC")
public class CMA008SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 사이버첨부파일관리 빈
	 */
	@Autowired
	private CMA008BEAN cma008bean;
	
	/**
	 * URL신규등록 및 추가, 삭제
	 * @param input URL추가정보, URL삭제정보
	 * @return 처리건수
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert")
	@TransactionalOperation
	public CMA008SVC00Out changeInsert(CMA008SVC00In input) throws ApplicationException {
		
		CMA008SVC00Out	output = new CMA008SVC00Out();
		
		if( input == null ){
		    // 입력값 오류처리
			throw new ApplicationException( "KIERE0004", new Object[]{ }, new Object[]{ "URL목록" , "변경된 정보 없음" });
		}
		
		String urlMgntNo = this.cma008bean.setUrlList(input);
		
		output.setUrlMgntNo(urlMgntNo);
				
		LApplicationContext.addMessage("KIOKI0009", null, null);
		
		return output;

	}
	
	/**
	 * URL관리정보 조회
	 * @param input URL관리번호, URL순번
	 * @return URL관리정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle0")
	public CMA008SVC01Out selectSingle0(CMA008SVC01In input) throws ApplicationException {
		
		CMA008SVC01Out output = new CMA008SVC01Out();
		
		CMA008SVC01Sub urlInfo = this.cma008bean.getUrlInfo(input.getUrlMgntNo(), input.getSeq());
		
		output.setUrlInfo(urlInfo);
		
		if ( urlInfo == null )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0001", null, null ) ; 
		
		return output;
	}
		
	/**
	 * URL관리목록조회
	 * @param input URL관리번호
	 * @return URL관리목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList")
	public CMA008SVC02Out selectList(CMA008SVC01In input) throws ApplicationException {
		
		CMA008SVC02Out output = new CMA008SVC02Out();
		
		List<CMA008SVC00Sub> urlList = this.cma008bean.getUrlList(input.getUrlMgntNo());
		
		output.setDataList(urlList);
		
		if ( output.getDataListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getDataListCnt()}, null ) ; 
		
		return output;
	}
}

