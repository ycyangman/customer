package cigna.cm.a.service;

import java.util.List;

import cigna.cm.a.bean.CMA009BEAN;
import cigna.cm.a.io.CMA009SVC00In;
import cigna.cm.a.io.CMA009SVC00Out;
import cigna.cm.a.io.CMA009SVC01In;
import cigna.cm.a.io.CMA009SVC01Out;
import cigna.cm.a.io.CMA009SVC02In;
import cigna.cm.a.io.CMA009SVC02Out;
import cigna.cm.a.io.CMA009SVC05In;
import cigna.cm.a.io.CMA009SVC06In;
import cigna.cm.a.io.TBCMCCD029Io;
import cigna.cm.a.io.TBCMCCD031Io;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA009SVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2013. 6. 28.       신규 작성
 *
 */
@KlafService("CMA009SVC")
public class CMA009SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA009BEAN cma009bean; 
	
	/**
	 * 대외계파일송수신 조회
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation( "selectList0" )
	public CMA009SVC00Out selectList0(CMA009SVC00In input)  throws ApplicationException {
		
		CMA009SVC00Out 	output = new CMA009SVC00Out();
		
		List<TBCMCCD029Io> fepFileLogList = this.cma009bean.getFepFileLogList(input);
		
		output.setFepFileLogList(fepFileLogList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(fepFileLogList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		if ( output.getFepFileLogListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{output.getFepFileLogListCnt()}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getFepFileLogListCnt()}, null);
			}
		}		
		
		return output;
		
	}	
	
	
	/**
	 * 대외계인터페이스배치매핑 목록 조회
	 * @param 
	 * @return CMA009SVC01Out 대외계인터페이스배치매핑
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMA009SVC01Out selectList1(CMA009SVC01In input) throws ApplicationException {
		CMA009SVC01Out output = new CMA009SVC01Out();
		
		List<TBCMCCD031Io> fepIfBatMappList =  this.cma009bean.getFepIfBatMappList(input);
		
		output.setFepIfBatMappList(fepIfBatMappList);
		
		if ( output.getFepIfBatMappListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getFepIfBatMappListCnt()}, null ) ; 
	
		return output;
	}		

	/**
	 * 대외계인터페이스배치매핑 저장
	 * @param input 대외계인터페이스배치매핑 저장정보
	 * @return CMA009SVC1Out 대외계인터페이스배치매핑 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify")
	@TransactionalOperation
	public CMA009SVC01Out changeModify(CMA009SVC01In input) throws ApplicationException {
		
		CMA009SVC01Out output = new CMA009SVC01Out();
		
		int iCnt = this.cma009bean.modifyFepIfBatMappList(input);
		
		List<TBCMCCD031Io> fepIfBatMappList =  this.cma009bean.getFepIfBatMappList(input);
		
		output.setFepIfBatMappList(fepIfBatMappList);

		LApplicationContext.addMessage("KIOKI0010", new Object[]{iCnt}, null);
		
		return output;
	}	
	
	/**
	 * 대외계인터페이스배치매핑 삭제 조회
	 * @param input 대외계인터페이스배치매핑 삭제정보
	 * @return CMAZ00SVC04Out 화면연결정보 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeDelete")
	@TransactionalOperation
	public CMA009SVC01Out changeDelete(CMA009SVC01In input) throws ApplicationException {
		
		CMA009SVC01Out output = new CMA009SVC01Out();
		
		int iCnt = this.cma009bean.deleteFepIfBatMappList(input);
		
		List<TBCMCCD031Io> fepIfBatMappList =  this.cma009bean.getFepIfBatMappList(input);
		
		output.setFepIfBatMappList(fepIfBatMappList);

		LApplicationContext.addMessage("KIOKI0018", new Object[]{iCnt}, null);
		
		return output;
	}	
	
	/**
	 * 대외계파일송수신 재전송
	 * @param input 대외계파일송수신 재전송 정보
	 * @return  
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert")
	@TransactionalOperation
	public CMA009SVC02Out changeInsert(CMA009SVC02In input) throws ApplicationException {
		
		CMA009SVC02Out output = new CMA009SVC02Out(); 
		
		//대외계 재전송 
		cma009bean.putFepFileLogInfo(input);
		
        //대외계 송수신 로그 목록
		CMA009SVC00In cma009svc00in = new CMA009SVC00In();
		cma009svc00in.setTrrvStrtDt(input.getTrrvStrtDt());
		cma009svc00in.setTrrvEndDt(input.getTrrvEndDt());
		cma009svc00in.setIfId(input.getIfId());
		cma009svc00in.setFepFileTrmsStcd(input.getFepFileTrmsStcd());
		cma009svc00in.setTrrvStrtEno(input.getTrrvStrtEno());

		int pageNum = input.getPageNum();
		int pageCount = input.getPageCount();
		
		cma009svc00in.setPageNum(1);
		cma009svc00in.setPageCount(pageNum*pageCount);

		List<TBCMCCD029Io> fepFileLogList = this.cma009bean.getFepFileLogList(cma009svc00in);
		
		output.setFepFileLogList(fepFileLogList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(fepFileLogList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		if ( output.getFepFileLogListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{output.getFepFileLogListCnt()}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getFepFileLogListCnt()}, null);
			}
		}
		return output;		
	}
	
	/**
	 * 대외계파일수신
	 * @param input 대외계에서 넘겨받을 데이터 정보
	 * @return  
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public void changeInsert1(CMA009SVC05In input) throws ApplicationException {
		
		cma009bean.putFepFileRece(input);
		
	}	
	
	/**
	 * 대외계파일송신
	 * @param
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify1")
	@TransactionalOperation
	public void changeModify1(CMA009SVC06In input) throws ApplicationException {
		
		cma009bean.putFepFileSnd(input);
		
	}
	
}

