package cigna.cm.a.service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import cigna.cm.a.bean.CMA010BEAN;
import cigna.cm.a.io.CMA010SVC00In;
import cigna.cm.a.io.CMA010SVC00Out;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA009SVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           양윤철       2016. 6. 28.       신규 작성
 *
 */
@KlafService("CMA010SVC")
public class CMA010SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA010BEAN cma010bean; 
	

	/**
	 * 안내장 발송 연계
	 * @param input 안내장 전송 정보
	 * @return  
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert")
	@TransactionalOperation
	public CMA010SVC00Out changeInsert(CMA010SVC00In input) throws ApplicationException {
		
		CMA010SVC00Out output = cma010bean.sndNotcl(input);
		//CMA010SVC00Out output = cma010bean.sndNotclScrn(input);
	
		return output;		
	}
	
	
	
}

