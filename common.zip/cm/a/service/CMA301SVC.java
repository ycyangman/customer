package cigna.cm.a.service;

import cigna.cm.a.bean.CMA301BEAN;
import cigna.cm.a.io.CMA301SVC00In;
import cigna.cm.a.io.CMA301SVC00Out;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA301SVC.java
 * @filetype     java source file
 * @brief        사원번호, 비밀번호 체크 서비스
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박경화                     2013. 2. 13.       신규 작성
 *
 */
@KlafService("CMA301SVC")
public class CMA301SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 비상로그인 빈
	 */
	@Autowired
	private CMA301BEAN cma301bean;
	
	/**
	 *  로그인 체크
	 * @param input 로그인 정보
	 * @return 로그인 체크
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle")
	public CMA301SVC00Out selectSingle(CMA301SVC00In input) throws ApplicationException {
		
		CMA301SVC00Out output = new CMA301SVC00Out();
		
		boolean isPasswordCheck = cma301bean.isPasswordCheck(input.getEno(), input.getPswd());
		
		if ( isPasswordCheck ) {
			output.setPswdChkYn("Y");
		} else {
			output.setPswdChkYn("N");
		}
		
		LApplicationContext.addMessage("KIOKI0001", null, null);
		return output;
	}
	
	
	/**
	 *  설계사 체크
	 * @param input 로그인 정보
	 * @return 로그인 체크
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle1")
	public CMA301SVC00Out selectSingle1(CMA301SVC00In input) throws ApplicationException {
		
		CMA301SVC00Out output = new CMA301SVC00Out();
		
		String isPlnrCheck = cma301bean.isPlnrCheck(input.getEno(), input.getPswd());
		
		output.setPswdChkYn(isPlnrCheck);
		
		LApplicationContext.addMessage("KIOKI0001", null, null);
		return output;
	}	
}

