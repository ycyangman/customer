package cigna.cm.a.service;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.a.bean.CMA401BEAN;
import cigna.cm.a.io.CMA401SVC00In;
import cigna.cm.a.io.CMA401SVC00Out;
import cigna.cm.a.io.CMA401SVC01In;
import cigna.cm.a.io.CMA401SVC01Out;
import cigna.cm.a.io.CMA401SVC02In;
import cigna.cm.a.io.CMA401SVC02Out;
import cigna.cm.a.io.CMA401SVC03In;
import cigna.cm.a.io.CMA401SVC03Out;
import cigna.cm.a.io.CMA401SVC04In;
import cigna.cm.a.io.CMA401SVC04Out;
import cigna.cm.a.io.TBCMCCD010Io;
import cigna.cm.a.io.TBCMCCD011Io;
import cigna.cm.a.io.TBCMCCD013Io;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file         cigna.cm.a.service.CMA401SVC.java
 * @filetype     java source file
 * @brief        결함관리 SERVICE
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1               박경화                 2012. 9.17.       신규 작성
 * 0.6               박경화                 2012. 9.27.       개발 완료
 * 0.9               박경화                 2012. 9.28.       Class 테스트
 * 1.0               박경화                 2012. 9.28.       단위 테스트 
 *
 */
@KlafService("CMA401SVC")
public class CMA401SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * 화면연결정보 조회, 수정하는 빈
	 */
	@Autowired
	private CMA401BEAN cma401bean;
	
	/**
	 * 결함관리 목록 조회
	 * @param input
	 * @return 결함관리 목록 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMA401SVC00Out selectList0(CMA401SVC00In input) throws ApplicationException {
		CMA401SVC00Out 	output = new CMA401SVC00Out();

		List<TBCMCCD010Io> dfctList = this.cma401bean.getDfctList(input); 
	
		output.setDfctList(dfctList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(dfctList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		if ( output.getListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{output.getListCnt()}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getListCnt()}, null);
			}
		}
		
		return output;
	}
	
	/**
	 * 결함관리 이력 조회
	 * @param input
	 * @return 결함관리이력목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMA401SVC01Out selectList1(CMA401SVC01In input) throws ApplicationException {
		CMA401SVC01Out 	output = new CMA401SVC01Out();
		
		// 결함관리이력조회
		List<TBCMCCD011Io> dfctHisList = this.cma401bean.getDfctHisList(input.getDfctMgntNo()) ;
		
		output.setDfctHisList(dfctHisList);
		
		// 결함관리 이미지 조회
		TBCMCCD013Io tbcmccd013io = this.cma401bean.getDfctImgCtnt(input.getDfctMgntNo()) ;
		
		List<TBCMCCD013Io> dfctImg = new ArrayList<TBCMCCD013Io>();
		dfctImg.add(0, tbcmccd013io);
		
		if ( tbcmccd013io != null ) {
			
			output.setDfctImg(dfctImg);
			
			//output.setDfctImgCtnt(tbcmccd013io.getDfctImgCtnt());
			
			//logger.debug("이미지={}",tbcmccd013io.getDfctImgCtnt());
		}
		
		if ( output.getListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getListCnt()}, null ) ; 
		
		return output;
	}
	
	/**
	 * 결함관리 등록
	 * @param input 결함관리 등록 입력정보
	 * @return 결함관리번호
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert")
	@TransactionalOperation
	public CMA401SVC02Out changeInsert(CMA401SVC02In input) throws ApplicationException {
		
		CMA401SVC02Out 	output = new CMA401SVC02Out();
		
		String dfctMgntNo = this.cma401bean.insertDfctInto(input);
		
		output.setDfctMgntNo(dfctMgntNo);
		
		LApplicationContext.addMessage("KIOKI0009", null, null);
		
		return output;
	}
	
	/**
	 * 결함괸리 수정
	 * @param input 결함괸리 수정 입력정보
	 * @return 결함관리 이력목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate")
	@TransactionalOperation
	public CMA401SVC03Out changeUpdate(CMA401SVC03In input) throws ApplicationException {
		
		CMA401SVC03Out 	output = new CMA401SVC03Out();
		
		// 결함내용 수정
		this.cma401bean.updateDfctInto(input);
		
		// 결함이력조회
		String dfctMgntNo = input.getDfctList().get(0).getDfctMgntNo();
				
		List<TBCMCCD011Io> dfctHisList = this.cma401bean.getDfctHisList(dfctMgntNo);
		
		output.setDfctHisList(dfctHisList);
        // 결함목록조회
		CMA401SVC00In cma401svc00in = new CMA401SVC00In();
		cma401svc00in.setInqStrtDt(input.getInqStrtDt());
		cma401svc00in.setInqEndDt(input.getInqEndDt());
		cma401svc00in.setScrnId(input.getScrnId());
		cma401svc00in.setScrnNm(input.getScrnNm());
		cma401svc00in.setRegEno(input.getRegEno());
		cma401svc00in.setRegOrgNo(input.getRegOrgNo());
		cma401svc00in.setChrgpEno(input.getChrgpEno());
		cma401svc00in.setChrgpOrgNo(input.getChrgpOrgNo());
		cma401svc00in.setDfctStcd(input.getDfctStcd());
		cma401svc00in.setDfctPrfRnkCd(input.getDfctPrfRnkCd());
		cma401svc00in.setDfctTpcd(input.getDfctTpcd());
		cma401svc00in.setDfctTitlNm(input.getDfctTitlNm());
		cma401svc00in.setDfctMgntNo(input.getDfctMgntNo());
		
		int pageNum = input.getPageNum();
		int pageCount = input.getPageCount();
		
		cma401svc00in.setPageNum(1);
		cma401svc00in.setPageCount(pageNum*pageCount);
		
		List<TBCMCCD010Io> dfctList = this.cma401bean.getDfctList(cma401svc00in);
		
		output.setDfctList(dfctList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(dfctList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		LApplicationContext.addMessage("KIOKI0009", null, null);
		
		return output;
	}
	
	/**
	 * 결함괸리 일괄처리
	 * @param input 결함괸리 일괄처리 입력정보
	 * @return 결함관리목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate0")
	@TransactionalOperation
	public CMA401SVC04Out changeUpdate0(CMA401SVC04In input) throws ApplicationException {
		
		CMA401SVC04Out 	output = new CMA401SVC04Out();
		
		// 결함관리 일괄처리
		this.cma401bean.updateDfctBtchList(input);
		
        // 결함목록조회
		CMA401SVC00In cma401svc00in = new CMA401SVC00In();
		cma401svc00in.setInqStrtDt(input.getInqStrtDt());
		cma401svc00in.setInqEndDt(input.getInqEndDt());
		cma401svc00in.setScrnId(input.getScrnId());
		cma401svc00in.setScrnNm(input.getScrnNm());
		cma401svc00in.setRegEno(input.getRegEno());
		cma401svc00in.setRegOrgNo(input.getRegOrgNo());
		cma401svc00in.setChrgpEno(input.getChrgpEno());
		cma401svc00in.setChrgpOrgNo(input.getChrgpOrgNo());
		cma401svc00in.setDfctStcd(input.getDfctStcd());
		cma401svc00in.setDfctTpcd(input.getDfctTpcd());
		cma401svc00in.setDfctPrfRnkCd(input.getDfctPrfRnkCd());
		cma401svc00in.setDfctTitlNm(input.getDfctTitlNm());
		cma401svc00in.setDfctMgntNo(input.getDfctMgntNo());
		
		int pageNum = input.getPageNum();
		int pageCount = input.getPageCount();
		
		cma401svc00in.setPageNum(1);
		cma401svc00in.setPageCount(pageNum*pageCount);
		
		List<TBCMCCD010Io> dfctList = this.cma401bean.getDfctList(cma401svc00in);
		
		output.setDfctList(dfctList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(dfctList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		LApplicationContext.addMessage("KIOKI0009", null, null);
		
		return output;
	}
	
}

