package cigna.cm.a.service;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.a.bean.CMA501BEAN;
import cigna.cm.a.io.CMA501SVC00In;
import cigna.cm.a.io.CMA501SVC00Out;
import cigna.cm.a.io.CMA501SVC01In;
import cigna.cm.a.io.CMA501SVC01Out;
import cigna.cm.a.io.CMA501SVC02In;
import cigna.cm.a.io.CMA501SVC02Out;
import cigna.cm.a.io.CMA501SVC03In;
import cigna.cm.a.io.CMA501SVC03Out;
import cigna.cm.a.io.CMA501SVC05In;
import cigna.cm.a.io.CMA501SVC05Out;
import cigna.cm.a.io.CMA501SVC06In;
import cigna.cm.a.io.CMA501SVC06Out;
import cigna.cm.a.io.CMA501SVC07In;
import cigna.cm.a.io.CMA501SVC07Out;
import cigna.cm.a.io.CMA501SVC08In;
import cigna.cm.a.io.CMA501SVC08Out;
import cigna.cm.a.io.SelectMultiTBCMCCD025Out;
import cigna.cm.a.io.SelectMultiTBCMCCD026Out;
import cigna.cm.a.io.SelectMultiTBCMCCD035aOut;
import cigna.cm.a.io.SelectMultiTBCMCCD037Out;
import cigna.cm.a.io.SelectMultiTBCMCCD038Out;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA501SVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2013. 8. 6.       신규 작성
 *
 */
@KlafService("CMA501SVC")
public class CMA501SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA501BEAN cma501bean;
	
	/**
	 * 사원권한신청정보 목록 조회
	 * @param input 사원권한신청정보 조회조건
	 * @return CMA501SVC00Out 사원권한신청정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMA501SVC00Out selectList0(CMA501SVC00In input) throws ApplicationException {
		CMA501SVC00Out output = new CMA501SVC00Out();
		
		List<SelectMultiTBCMCCD035aOut> emplRoleApplList = new ArrayList<SelectMultiTBCMCCD035aOut>();
		
		emplRoleApplList = this.cma501bean.getEmplRoleApplList(input.getRoleAdptEno(), input.getApplStrtDt(), input.getApplEndDt(), input.getApplEno(), input.getOrgNo(), input.getRoleAdptDt());
		
		output.setEmplRoleApplList(emplRoleApplList);
		
		if ( output.getEmplRoleApplListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getEmplRoleApplListCnt()}, null ) ; 

		return output;
	}
	
	/**
	 * 사원권한신청정보 저장
	 * @param input 사원권한신청 저장정보
	 * @return CMA501SVC01Out 사원권한신청 목록 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify")
	@TransactionalOperation
	public CMA501SVC01Out changeModify(CMA501SVC01In input) throws ApplicationException {
		
		CMA501SVC01Out output = new CMA501SVC01Out();
		
		List<SelectMultiTBCMCCD035aOut> emplRoleApplList = new ArrayList<SelectMultiTBCMCCD035aOut>();
		
		int sysEmplRoleApplNo = this.cma501bean.modifyEmplAuthApplList(input);
		
		String interfaceId = "KLIFBIZ00SSO00AR0001";	//사원권한신청 인터페이스 ID
		
		this.cma501bean.getEAITrmsInfo(interfaceId, Integer.toString(sysEmplRoleApplNo)); //EAI호출을 공통으로 사용하기 위해 toString 처리함.
		
		emplRoleApplList =  this.cma501bean.getEmplRoleApplList(input.getRoleAdptEno(), input.getApplStrtDt(), input.getApplEndDt(), input.getApplEno(), input.getOrgNo(), input.getRoleAdptDt());
		
		output.setEmplRoleApplList(emplRoleApplList);

		LApplicationContext.addMessage("KIOKI0009", null, null);
		
		return output;
	}
	
	/**
	 * 시스템역할목록 조회
	 * @param input 시스템역할목록 조회조건
	 * @return CMA501SVC02Out 시스템역할목록
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMA501SVC02Out selectList2(CMA501SVC02In input) throws ApplicationException {
		
		CMA501SVC02Out output = new CMA501SVC02Out();
		
		List<SelectMultiTBCMCCD025Out> roleInfoList =  this.cma501bean.getRoleInfoList(input.getRoleNm());

		output.setRoleInfoList(roleInfoList);
		
		if ( output.getRoleInfoListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getRoleInfoListCnt()}, null );
		
		return output;
	}

	/**
	 * 시스템역할목록상세 조회
	 * @param input 시스템역할목록상세 조회조건
	 * @return CMA501SVC02Out 시스템역할상세목록
	 * @throws ApplicationException
	 */	
	@KlafServiceOperation("selectList3")
	public CMA501SVC03Out selectList3(CMA501SVC03In input) throws ApplicationException {
		
		CMA501SVC03Out output = new CMA501SVC03Out();
		
		List<SelectMultiTBCMCCD026Out> roleDetailList =  this.cma501bean.getRoleDetailList(input.getRoleDscNo());

		output.setRoleDetailList(roleDetailList);
		
		if ( output.getRoleDetailListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getRoleDetailListCnt()}, null );
		
		return output;
	}
	
	/**
	 * SSO비밀번호초기화 신청 목록 조회
	 * @param input SSO비밀번호초기화 신청 조회조건
	 * @return CMA501SVC05Out SSO비밀번호초기화 신청정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList4")
	public CMA501SVC05Out selectList4(CMA501SVC05In input) throws ApplicationException {
		CMA501SVC05Out output = new CMA501SVC05Out();
		
		List<SelectMultiTBCMCCD037Out> pswdInitlApplList = new ArrayList<SelectMultiTBCMCCD037Out>();
		
		pswdInitlApplList = this.cma501bean.getPswdInitlApplList(input.getPswdInitlObjEno(), input.getApplStrtDt(), input.getApplEndDt(), input.getApplEno(), input.getOrgNo());
		
		output.setPswdInitlApplList(pswdInitlApplList);
		
		if ( output.getPswdInitlApplListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getPswdInitlApplListCnt()}, null ) ; 

		return output;
	}	
	
	/**
	 * SSO비밀번호초기화 신청 저장
	 * @param input SSO비밀번호초기화 신청 저장정보
	 * @return CMA501SVC06Out SSO비밀번호초기화 신청 목록 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify0")
	@TransactionalOperation
	public CMA501SVC06Out changeModify0(CMA501SVC06In input) throws ApplicationException {
		
		CMA501SVC06Out output = new CMA501SVC06Out();
		
		List<SelectMultiTBCMCCD037Out> pswdInitlApplList = new ArrayList<SelectMultiTBCMCCD037Out>();
		
		String ssoPswdInitlApplNo = this.cma501bean.modifyPswdInitlApplList(input);
		
		String interfaceId = "KLIFBIZ00SSO00AR0006";	//SSO비밀번호초기화 인터페이스 ID
		
		this.cma501bean.getEAITrmsInfo(interfaceId, ssoPswdInitlApplNo); //EAI호출
		
		pswdInitlApplList =  this.cma501bean.getPswdInitlApplList(input.getPswdInitlObjEno(), input.getApplStrtDt(), input.getApplEndDt(), input.getApplEno(), input.getOrgNo());
		
		output.setPswdInitlApplList(pswdInitlApplList);

		LApplicationContext.addMessage("KIOKI0009", null, null);
		
		return output;
	}	
	
	/**
	 * 가상사원번호 신청 목록 조회
	 * @param input 가상사원번호 신청 조회조건
	 * @return CMA501SVC07Out 가상사원번호 신청정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList5")
	public CMA501SVC07Out selectList5(CMA501SVC07In input) throws ApplicationException {
		CMA501SVC07Out output = new CMA501SVC07Out();
		
		List<SelectMultiTBCMCCD038Out> spstEnoApplList = new ArrayList<SelectMultiTBCMCCD038Out>();
		
		spstEnoApplList = this.cma501bean.getSpstEnoApplList(input.getSpstEmplRrno(), input.getSpstEmplNm(), input.getSpstEmplBlntOrgNo(), input.getApplStrtDt(), input.getApplEndDt(), input.getApplEno(), input.getOrgNo());
		
		output.setSpstEnoApplList(spstEnoApplList);
		
		if ( output.getSpstEnoApplListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getSpstEnoApplListCnt()}, null ) ; 

		return output;
	}	

	/**
	 * 가상사원번호 신청 저장
	 * @param input 가상사원번호 신청 저장정보
	 * @return CMA501SVC08Out 가상사원번호 신청 목록 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify1")
	@TransactionalOperation
	public CMA501SVC08Out changeModify1(CMA501SVC08In input) throws ApplicationException {
		
		CMA501SVC08Out output = new CMA501SVC08Out();
		
		List<SelectMultiTBCMCCD038Out> spstEnoApplList = new ArrayList<SelectMultiTBCMCCD038Out>();
		
		String spstEnoApplNo = this.cma501bean.modifySpstEnoApplList(input);
		
		String interfaceId = "KLIFBIZ00SSO00AR0005";
		
		this.cma501bean.getEAITrmsInfo(interfaceId, spstEnoApplNo); //EAI호출
		
		spstEnoApplList =  this.cma501bean.getSpstEnoApplList(input.getSpstEmplRrno(), input.getSpstEmplNm(), input.getSpstEmplBlntOrgNo(), input.getApplStrtDt(), input.getApplEndDt(), input.getApplEno(), input.getOrgNo());
		
		output.setSpstEnoApplList(spstEnoApplList);

		LApplicationContext.addMessage("KIOKI0009", null, null);
		
		return output;
	}	
}

