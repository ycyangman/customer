package cigna.cm.a.service;

import java.util.List;

import cigna.cm.a.bean.CMA801BEAN;
import cigna.cm.a.io.CMA801SVC01In;
import cigna.cm.a.io.CMA801SVC01Out;
import cigna.cm.a.io.CMA801SVC02Out;
import cigna.cm.a.io.CMA801SVC03Out;
import cigna.cm.a.io.SelectMultiTBCMETC003aOut;
import cigna.cm.a.io.SelectMultiTBCMETC004bOut;
import cigna.cm.a.io.SelectMultiTBCMETC005bOut;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA801SVC.java
 * @filetype     java source file
 * @brief        대외기관으로 전송하는 개인정보가 포함된 파일을 관리하는 서비스
 * @author       김정국
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김정국                 2014. 12. 26.       신규 작성
 *
 */
@KlafService("CMA801SVC")
public class CMA801SVC {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA801BEAN cma801bean;
	
	/**
	 * 대외기관으로 전송하는 파일의 현황조회
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMA801SVC01Out selectList1(final CMA801SVC01In input)
			throws ApplicationException {
		
		CMA801SVC01Out output = new CMA801SVC01Out();
		
		List<SelectMultiTBCMETC003aOut> list =
				cma801bean.getExtrnInstSendFileStatus(input.getChrgpEno(), input.getPageNum(), input.getPageCount());
		
		output.setFileListCnt(list.size());
		output.setFileList(list);

		if(list.size() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage("KIOKI0004", null, null);
		}
		else {
			// KIOKI0002: 요청하신 내용 {0}건이 조회 되었습니다.
			LApplicationContext.addMessage("KIOKI0002", new Object[] { list.size() }, null);
		}
		return output;
	}
	
	/**
	 * 특정인의 처리가능한 세부업무 목록을 조회
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMA801SVC02Out selectList2(final CMA801SVC01In input) throws ApplicationException {
		
		CMA801SVC02Out output = new CMA801SVC02Out();
		
		List<SelectMultiTBCMETC004bOut> detlBzList = cma801bean.getdetlBzAndChrgList(input.getChrgpEno());
		
		output.setDetlBzCnt(detlBzList.size());
		output.setDetlBz(detlBzList);
		
		return output;
	}
	
	/**
	 * 대외기관 전송을 위한 파일 저장
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public void changeInsert1(final CMA801SVC01In input) throws ApplicationException {
		
		int saveCount = cma801bean.saveDetlBzFileInfo(input.getFileMgntDetlBzList());

		if(saveCount > 0)
			LApplicationContext.addMessage("KIOKI0009", null, null);
		else
			LApplicationContext.addMessage("APCME0035", null, null);
	}
	
	/**
	 * 대외기관 전송을 위한 파일정보 삭제
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeDelete0")
	@TransactionalOperation
	public void changeDelete0(final CMA801SVC01In input) throws ApplicationException {

		int deleteCount = cma801bean.deleteDetlBzFileInfos(input);

		if(deleteCount > 0)
			LApplicationContext.addMessage("KIOKI0009", null, null);
	}
	
	/**
	 * 세부업무 및 담당자 저장 처리
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert0")
	@TransactionalOperation
	public void changeInsert0(final CMA801SVC01In input) throws ApplicationException {
		
		int saveCount = cma801bean.saveDetlBzChrgEno(input);
		
		if(saveCount > 0)
			LApplicationContext.addMessage("KIOKI0009", null, null);
		else
			LApplicationContext.addMessage("APCME0035", null, null);
	}
	
	/**
	 * 세부업무 목록을 조회
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMA801SVC03Out selectList3(final CMA801SVC01In input) throws ApplicationException {
		
		CMA801SVC03Out output = new CMA801SVC03Out();
		
		List<SelectMultiTBCMETC005bOut> detlBzList = cma801bean.getdetlBzList(input.getChrgpEno());
		
		output.setDetlBzCnt(detlBzList.size());
		output.setDetlBz(detlBzList);
		
		return output;
	}
	
	/**
	 * 세부업무 및 담당자 정보 삭제처리
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeDelete1")
	@TransactionalOperation
	public void changeDelete1(final CMA801SVC01In input) throws ApplicationException {
		
		int deleteCount = cma801bean.deleteDetlBzAndChrgs(input);

		if(deleteCount > 0)
			LApplicationContext.addMessage("KIOKI0009", null, null);
	}
	
}