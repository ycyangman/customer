package cigna.cm.a.service;

import cigna.cm.a.bean.CMA901BEAN;
import cigna.cm.a.io.CMA901SVC00In;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA901SVC.java
 * @filetype     java source file
 * @brief        개인정보보호를 위한 엑셀전환시 로깅 서비스
 * @author       김정국
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김정국                2014. 1. 21.       신규 작성
 *
 */
@KlafService("CMA901SVC")
public class CMA901SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA901BEAN cma901bean;
	
	/**
	 * 처리계 화면에서 엑셀저장을 처리시 호출되어 엑셀다운로드이력 테이블에 정보를 저장
	 * 
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert0")
	@TransactionalOperation
	public void changeInsert0(CMA901SVC00In input) throws ApplicationException {
		
		boolean isSaved = cma901bean.insertExcelDownloadLog(input.getScrnNm(), input.getXlsSwtCnt());

		if(isSaved)
			LApplicationContext.addMessage("KIOKI0009", null, null);
		else
			LApplicationContext.addMessage("KIERE0005", null, new Object[]{"데이터 베이스 연결을 실패했거나, 데이터 중복"});
	}
}