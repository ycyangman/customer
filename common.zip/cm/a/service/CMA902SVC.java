package cigna.cm.a.service;


import cigna.cm.a.io.CMA902SVC00In;
import cigna.cm.a.io.CMA902SVC01In;
import cigna.cm.a.io.CMA902SVC01Out;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMA902SVC.java
 * @filetype     java source file
 * @brief        처리계 시스템 사용자가 고객정보를 조회시 조회목적 및 조회용도에 대한 내용으로 이력을 남기는 서비스
 * @author       김정국
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김정국                 2014. 3. 27.       신규 작성
 *
 */
@KlafService("CMA902SVC")
public class CMA902SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	/**
	 * 처리계 화면에서 고객정보조회시 이력을 고객정보조회이력(TBCMCCD042) 테이블에 정보를 저장
	 * @param input 처리계 화면에서 넘어온 저장 정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert0")
	@TransactionalOperation
	public void changeInsert0(CMA902SVC00In input) throws ApplicationException {
		
		logger.debug("CMA902SVC.changeInsert0");
		/*
		boolean isSaved = cma902bean.insertCustInfoInqHis(input);

		if(isSaved)
			LApplicationContext.addMessage("KIOKI0009", null, null);
		else
			LApplicationContext.addMessage("KIERE0005", null, new Object[]{"데이터 베이스 연결을 실패했거나, 데이터의 중복, 필수 입력값이 누락"});
		*/
	}
	
	/**
	 * 고객정보조회를 하는 화면을 조회
	 * @param input 처리계 화면에서 넘어온 조회정보(업무코드, 화면ID)
	 * @return 조회결과 리스트
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMA902SVC01Out selectList0(CMA902SVC00In input) throws ApplicationException {
		
		//고객정보조회 화면을 조회
		CMA902SVC01Out output = new  CMA902SVC01Out();
		/*
		output = cma902bean.getCustInfoInqScrn(input.getBzCd(), input.getScrnId(), input.getPageNum(), input.getPageCount());
		
		if(output.getCustInfoInqScrnCnt() == 0)
		    LApplicationContext.addMessage("KIOKI0004", null, null);  
		else
			LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getCustInfoInqScrnCnt()}, null);
		
		*/
		return output;
	}

	/**
	 * 고객정보조회 화면정보를 저장
	 * @param input 고객정보조회 화면정보와 맵핑할 서비스 오퍼레이션 정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public void changeInsert1(CMA902SVC01In input) throws ApplicationException {
		
		logger.debug("CMA902SVC.changeInsert1");
		/*
		int saveCnt = cma902bean.savCustInfoInqScrn(input);

		if(saveCnt > 0)
			LApplicationContext.addMessage("KIOKI0009", null, null);
		else
			LApplicationContext.addMessage("KIERE0005", null, new Object[]{"데이터 베이스 연결을 실패했거나, 데이터의 중복, 필수 입력값이 누락"});
		
		*/
	}
}