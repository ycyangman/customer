package cigna.cm.a.service;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.a.bean.CMAZ00BEAN;
import cigna.cm.a.io.CMAZ00SVC00In;
import cigna.cm.a.io.CMAZ00SVC00Out;
import cigna.cm.a.io.CMAZ00SVC01In;
import cigna.cm.a.io.CMAZ00SVC01Out;
import cigna.cm.a.io.CMAZ00SVC02In;
import cigna.cm.a.io.CMAZ00SVC02Out;
import cigna.cm.a.io.CMAZ00SVC03In;
import cigna.cm.a.io.CMAZ00SVC03Out;
import cigna.cm.a.io.CMAZ00SVC04In;
import cigna.cm.a.io.CMAZ00SVC04Out;
import cigna.cm.a.io.CMAZ00SVC06In;
import cigna.cm.a.io.CMAZ00SVC06Out;
import cigna.cm.a.io.SelectMultiTBCMCCD006bOut;
import cigna.cm.a.io.TBCMCCD006Io;
import cigna.cm.a.io.TBCMCCD032Io;
import cigna.cm.a.io.TBCMCCD040Io;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/****
 * @file         cigna.cm.a.service.CMAZ00SVC.java
 * @filetype     java source file
 * @brief        기타 공통업무 화면 SERVICE (화면연결정보)
 * @author       박경화
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1               박경화                 2012. 8. 3.       신규 작성
 * 0.6               박경화                 2012. 8.10.       개발 완료
 * 0.9               박경화                 2012. 8.10.       Class 테스트
 * 1.0               박경화                 2012. 8.10.       단위 테스트  
 *
 */
@KlafService("CMAZ00SVC")
public class CMAZ00SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 화면연결정보 조회, 수정하는 빈
	 */
	@Autowired
	private CMAZ00BEAN cmaz00bean; 
	
	/**
	 * 화면연결정보 목록 조회
	 * @param input 화면연결정보 조회조건
	 * @return CMAZ00SVC00Out 화면연결정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMAZ00SVC00Out selectList0(CMAZ00SVC00In input) throws ApplicationException {
		CMAZ00SVC00Out output = new CMAZ00SVC00Out();
		
		List<TBCMCCD006Io> connScrnNoList =  this.cmaz00bean.getConnScrnNoList(input.getScrnNo());
		
		output.setConnScrnNoList(connScrnNoList);
		
		if ( output.getConnScrnNoListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getConnScrnNoListCnt()}, null ) ; 

		return output;
	}
	
	/**
	 * 화면연결정보 목록 조회(UI용)
	 * @param input 화면연결정보 조회조건
	 * @return CMAZ00SVC01Out 화면연결정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMAZ00SVC01Out selectList1(CMAZ00SVC01In input) throws ApplicationException {
		CMAZ00SVC01Out output = new CMAZ00SVC01Out();
		
		List<SelectMultiTBCMCCD006bOut> connScrnNoList =  this.cmaz00bean.getConnScrnNoListUI(input.getScrnNo());
		
		output.setConnScrnNoList(connScrnNoList);
		
		if ( output.getConnScrnNoListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getConnScrnNoListCnt()}, null ) ; 

		return output;
	}
	
	/**
	 * 화면연결정보 저장
	 * @param input 화면연결정보 저장정보
	 * @return CMAZ00SVC02Out 화면연결정보 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify")
	@TransactionalOperation
	public CMAZ00SVC02Out changeModify(CMAZ00SVC02In input) throws ApplicationException {
		
		CMAZ00SVC02Out output = new CMAZ00SVC02Out();
		
		List<TBCMCCD006Io> connScrnNoList = new ArrayList<TBCMCCD006Io>();
		
		int iCnt = this.cmaz00bean.modifyConnScrnNoList(input);
		
		if (StringUtils.isEmpty(input.getScrnNo())) {
			connScrnNoList = input.getConnScrnNoList();
		} else {
			connScrnNoList =  this.cmaz00bean.getConnScrnNoList(input.getScrnNo());
		}
		
		output.setConnScrnNoList(connScrnNoList);

		LApplicationContext.addMessage("KIOKI0010", new Object[]{iCnt}, null);
		
		return output;
	}
	
	/**
	 * 화면연결정보 삭제 조회
	 * @param input 화면연결정보 저장정보
	 * @return CMAZ00SVC02Out 화면연결정보 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeDelete")
	@TransactionalOperation
	public CMAZ00SVC02Out changeDelete(CMAZ00SVC02In input) throws ApplicationException {
		
		CMAZ00SVC02Out output = new CMAZ00SVC02Out();
		
		int iCnt = this.cmaz00bean.deleteConnScrnNoList(input);
		
		List<TBCMCCD006Io> connScrnNoList =  this.cmaz00bean.getConnScrnNoList(input.getScrnNo());
		
		output.setConnScrnNoList(connScrnNoList);

		LApplicationContext.addMessage("KIOKI0018", new Object[]{iCnt}, null);
		
		return output;
	}
	
	/**
	 * UI요약정보 목록 조회
	 * @param 
	 * @return CMAZ00SVC03Out UI요약정보
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMAZ00SVC03Out selectList2(CMAZ00SVC03In input) throws ApplicationException {
		CMAZ00SVC03Out output = new CMAZ00SVC03Out();
		
		List<TBCMCCD032Io> smryInfoList =  this.cmaz00bean.getSmryInfoList();
		
		output.setSmryInfoList(smryInfoList);
		
		if ( output.getSmryInfoListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getSmryInfoListCnt()}, null ) ; 
	
		return output;
	}		

	/**
	 * UI요약정보 저장
	 * @param input UI요약정보 저장정보
	 * @return CMAZ00SVC04Out 화면연결정보 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify1")
	@TransactionalOperation
	public CMAZ00SVC04Out changeModify1(CMAZ00SVC04In input) throws ApplicationException {
		
		CMAZ00SVC04Out output = new CMAZ00SVC04Out();
		
		int iCnt = this.cmaz00bean.modifySmryInfoList(input);
		
		List<TBCMCCD032Io> smryInfoList =  this.cmaz00bean.getSmryInfoList();
		
		output.setSmryInfoList(smryInfoList);

		LApplicationContext.addMessage("KIOKI0010", new Object[]{iCnt}, null);
		
		return output;
	}
	
	/**
	 * UI요약정보 삭제 조회
	 * @param input 화면연결정보 저장정보
	 * @return CMAZ00SVC04Out 화면연결정보 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeDelete1")
	@TransactionalOperation
	public CMAZ00SVC04Out changeDelete1(CMAZ00SVC04In input) throws ApplicationException {
		
		CMAZ00SVC04Out output = new CMAZ00SVC04Out();
		
		int iCnt = this.cmaz00bean.deleteSmryInfoList(input);
		
		List<TBCMCCD032Io> smryInfoList =  this.cmaz00bean.getSmryInfoList();
		
		output.setSmryInfoList(smryInfoList);

		LApplicationContext.addMessage("KIOKI0018", new Object[]{iCnt}, null);
		
		return output;
	}
	
	/**
	 * 마이메뉴 목록 조회
	 * @param 
	 * @return CMAZ00SVC06Out 마이메뉴
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMAZ00SVC06Out selectList3(CMAZ00SVC06In input) throws ApplicationException {
		CMAZ00SVC06Out output = new CMAZ00SVC06Out();
		
		List<TBCMCCD040Io> myMenuInfoList =  this.cmaz00bean.getMyMenuInfoList(input.getEno());
		
		output.setMyMenuInfoList(myMenuInfoList);
		
		if ( output.getMyMenuInfoListCnt() == 0 )
		    LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		else
			LApplicationContext.addMessage( "KIOKI0002", new Object[]{output.getMyMenuInfoListCnt()}, null ) ; 
	
		return output;
	}		

	/**
	 * 마이메뉴 저장
	 * @param input 마이메뉴 저장정보
	 * @return CMAZ00SVC06Out 마이메뉴 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify2")
	@TransactionalOperation
	public CMAZ00SVC06Out changeModify2(CMAZ00SVC06In input) throws ApplicationException {
		
		CMAZ00SVC06Out output = new CMAZ00SVC06Out();
		
		int iCnt = this.cmaz00bean.modifyMyMenuInfoList(input);
		
		List<TBCMCCD040Io> myMenuInfoList =  this.cmaz00bean.getMyMenuInfoList(input.getEno());
		
		output.setMyMenuInfoList(myMenuInfoList);

		LApplicationContext.addMessage("KIOKI0010", new Object[]{iCnt}, null);
		
		return output;
	}
	
	/**
	 * 마이메뉴 삭제 조회
	 * @param input 마이메뉴 삭제정보
	 * @return CMAZ00SVC06Out 마이메뉴 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeDelete2")
	@TransactionalOperation
	public CMAZ00SVC06Out changeDelete2(CMAZ00SVC06In input) throws ApplicationException {
		
		CMAZ00SVC06Out output = new CMAZ00SVC06Out();
		
		int iCnt = this.cmaz00bean.deleteMyMenuInfoList(input);
		
		List<TBCMCCD040Io> myMenuInfoList =  this.cmaz00bean.getMyMenuInfoList(input.getEno());
		
		output.setMyMenuInfoList(myMenuInfoList);

		LApplicationContext.addMessage("KIOKI0018", new Object[]{iCnt}, null);
		
		return output;
	}	
	
}