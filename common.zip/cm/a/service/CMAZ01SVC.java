package cigna.cm.a.service;

import java.util.List;

import cigna.cm.a.bean.CMAZ01BEAN;

import cigna.cm.a.io.CMAZ01SVC00Out;
import cigna.cm.a.io.CMAZ01SVC01In;
import cigna.cm.a.io.CMAZ01SVC02In;
import cigna.cm.a.io.CMAZ01SVC03In;
import cigna.cm.a.io.CMAZ01SVC04In;
import cigna.cm.a.io.CMAZ01SVC04Out;
import cigna.cm.a.io.CMAZ01SVC05In;
import cigna.cm.a.io.CMAZ01SVC05Out;
import cigna.cm.a.io.SelectMultiTBCMCCD026Out;
import cigna.cm.a.io.TBCMCCD033Io;
import cigna.cm.a.io.SelectMultiTBCMCCD033cOut;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.a.service.CMAZ01SVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2013. 8. 1.       신규 작성
 *
 */
@KlafService("CMAZ01SVC")
public class CMAZ01SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMAZ01BEAN cmaz01bean; 	
	
	/**
	 * 메뉴 조회
	 * @param CMAZ01SVC03In
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList")
	public CMAZ01SVC00Out selectList(CMAZ01SVC03In input) throws ApplicationException {
		
		CMAZ01SVC00Out output = new CMAZ01SVC00Out();
		
		List<TBCMCCD033Io> menuInfoList = null;
		
		if(StringUtils.isEmpty(input.getMenuGrpCd())){
			menuInfoList = this.cmaz01bean.getMenuInfoListAll(input);
		}else{
			menuInfoList = this.cmaz01bean.getMenuInfoList(input);
		}
		
		output.setMenuInfoList(menuInfoList);
		
		if ( output.getMenuInfoListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getMenuInfoListCnt()}, null);
		}		
		return output;
	}
	
	/**
	 * 버튼 권한 조회
	 * @param CMAZ01SVC05In
	 * @return CMAZ01SVC05Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMAZ01SVC05Out selectList1(CMAZ01SVC05In input) throws ApplicationException {
		
		CMAZ01SVC05Out output  = this.cmaz01bean.getComBtnList(input);

		return output;
	}
	
	/**
	 * 메뉴 조회 UI연동
	 * @param  CMAZ01SVC04In
	 * @return 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMAZ01SVC04Out selectList2(CMAZ01SVC04In input) throws ApplicationException {
		
		CMAZ01SVC04Out output = new CMAZ01SVC04Out();
		List<SelectMultiTBCMCCD033cOut> menuInfoList = this.cmaz01bean.getComMnList();
		
		output.setComMnList(menuInfoList);
		
		if ( output.getComMnListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getComMnListCnt()}, null);
		}		
		
		return output;
	}
	
	/**
	 * 메뉴정보 저장
	 * @param in CMAZ01SVC01In -> List<TBCMCCD033Io> 메뉴정보 목록
	 * @return int 저장건수
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify")
	@TransactionalOperation
	public void changeModify(CMAZ01SVC01In input) throws ApplicationException {
	
		int iCnt = this.cmaz01bean.modifyMenuInfoList(input);
		if (iCnt > 0 ){
			
			// 입력하신내용 {0}건이 저장 되었습니다. 
			LApplicationContext.addMessage("KIOKI0010", new Object[]{ Integer.toString(iCnt)}, null);
			
		}else {
			
			// 입력하신 내용을 저장할 수 없습니다. 
			LApplicationContext.addMessage("KIERE0005", new Object[]{ Integer.toString(iCnt)}, null);		
		}	
	}
	
	/**
	 * 메뉴정보 삭제
	 * @param input 메뉴정보 저장정보
	 * @return CMAZ01SVC02Out 메뉴정보 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeDelete")
	@TransactionalOperation
	public void changeDelete(CMAZ01SVC02In input) throws ApplicationException {
		
	
		int iCnt = this.cmaz01bean.deleteMenuMgntNoList(input);
		
		if (iCnt > 0 ){
			LApplicationContext.addMessage("KIOKI0018", new Object[]{iCnt}, null);
		}	

	}	
	
}

