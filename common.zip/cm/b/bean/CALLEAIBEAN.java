package cigna.cm.b.bean;

import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;

import org.omg.CORBA.portable.ApplicationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cigna.cm.b.io.COR_E_EAIOS000000001;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;


/**
 * @file         cigna.cm.b.bean.CALLEAI.java
 * @filetype     java source file
 * @brief
 * @author       개발자(김진일)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(김진일)       2016. 2. 5.       신규 작성
 *
 */
@KlafBean
public class CALLEAIBEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
		
	public void callEai(COR_E_EAIOS000000001 input) {
		
		// set inData
		
		String interfaceId = "COR_E_EAIOS000000001";
		
//		EISResponse <COR_E_EAIOS000000001> response = null;
		
		logger.debug("===================== 입력정보");
		logger.debug("request::{}", input);
		
		try {
			EISResponse <COR_E_EAIOS000000001> response = InfUtil.callEAI(input, 
				                   interfaceId, 
				                   "BS", 
				                   "BSZ010SVC",
				                   "selectList0",
				                   FwUtil.getDeptCd(), 
				                   FwUtil.getUserId(), 
				                   COR_E_EAIOS000000001.class
				                   );
			logger.debug("=====================");
			logger.debug("response={}", response);
			logger.debug("=====================");
			response.getResponseData();
			logger.debug("=====================");
		    logger.debug("response data:{}", response.getResponseData());
			logger.debug("=====================");
			
		} 
		catch(Exception e) {
			logger.error(e.getMessage());
		}
	}
}

