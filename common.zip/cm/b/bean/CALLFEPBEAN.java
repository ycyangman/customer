package cigna.cm.b.bean;

import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cigna.cm.b.io.COM_F_KSNOSKSPO00004In;
import cigna.zz.InfUtil;


/**
 * @file         cigna.cm.b.bean.CALLFEPBEAN.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2016. 2. 11.       신규 작성
 *
 */
@KlafBean
public class CALLFEPBEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public void callFep(COM_F_KSNOSKSPO00004In input) {
		
		EISResponse < COM_F_KSNOSKSPO00004In > response = null;
		COM_F_KSNOSKSPO00004In request = new COM_F_KSNOSKSPO00004In();
		
		
		logger.debug("===================== 입력정보");
		logger.debug("request::{}", input);
		
		request = input;
		
		try{
			String interfaceId = "COM_F_KSNOS000000004";
			
			response = InfUtil.callFEP(request, interfaceId, COM_F_KSNOSKSPO00004In.class);
			
			logger.debug("=====================");
			logger.debug("response={}", response);
			logger.debug("=====================");
			response.getResponseData();
			logger.debug("=====================");
		    logger.debug("response data:{}", response.getResponseData());
			logger.debug("=====================");
			
		}catch(Exception e) {
			logger.error("Exception", e);
		}
		
	}
	
}

