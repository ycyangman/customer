package cigna.cm.b.bean;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA002BEAN;
import cigna.cm.a.bean.CMA004BEAN;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.domain.WtrsfAsntDlngInfo;
import cigna.cm.b.io.OSTGMDATAVERFINFOTESTIo;
import cigna.cm.b.io.SelectMultiTBPATRN001bOut;
import cigna.cm.b.io.TBCMRTM001Io;
import cigna.cm.b.io.TBCMRTM002Io;
import cigna.cm.b.io.TBCMRTM003Io;
import cigna.cm.b.io.TBCMRTM004Io;
import cigna.cm.b.io.TBCMRTM011Io;
import cigna.cm.b.io.TBCMRTM024Io;
import cigna.cm.b.io.TBCSFCR001Io;
import cigna.cm.b.io.TBCSFCR003Io;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;



/**
 * @file         cigna.cm.b.bean.CMB001BEAN.java
 * @filetype     java source file
 * @brief        지급이체자금이체송수신처리_메인
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                          성명                                               일자                                     변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                           2016. 2. 2.       신규 작성
 *
 */
@KlafBean
public class CMB001BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB001DBIO cmb001dbio;		// 전문번호 체크
	
	@Autowired
	private CMA004BEAN cma004bean;		// 리얼타임이체거래번호 채번메소드 호출
	
	@Autowired
	private CMBZ00BEAN cmbz00bean;		// RT 공통메소드 호출
	
	@Autowired
	private CMB003BEAN cmb003bean;		// 지급이체자금이체송수신처리_KIB-NET
	
	@Autowired
	private CMB040BEAN cmb040bean;		// 출금이체동의증빙
	
	@Autowired
	private CMA002BEAN cma002bean;		//
	
	
	private static final String M_FININ_RLTM_ANSW_CD_OK = "0000"; //금융기관리얼타임응답코드_정상
	
	/**
	 * 2016.10.04;현승훈 
	 * 지급이체송수신전문처리_메인 Operation
	 * @param TrsfTrrvPrcsInfo  이체송수신처리정보
	 * @return TrsfTrrvPrcsInfo  이체송수신처리정보 
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public TrsfTrrvPrcsInfo callTgmTrrv (TrsfTrrvPrcsInfo input) throws ApplicationException {
		
		TrsfTrrvPrcsInfo prcsInfo = null;
		
		//2016.10.08;현승훈;출금이체동의증빙		
		WtrsfAsntDlngInfo dlngInfo = null;
		
		TBCSFCR001Io actInfo = new TBCSFCR001Io();							// 계좌정보		
		TBCMRTM024Io fininInfo = new TBCMRTM024Io();						// 금융기관제휴업무목록
		
		int	iResult			= 0;						// 처리결과값
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		String tgmNo 		= "";				// 전문번호
		String rltmTrsfTxNo	= "";				// 리얼타임이체거래번호
		String prcsHms		= "";				// 처리시간
		String tgmNoBankCd = "" ;               // 전문번호 생성 은행코드 
		String wtrsfAsntCd = "";				//출금이체동의 결과
		String rltmTrsfPmpsNo = "";				//리얼타임납부자번호
		String prcsEno = "";					//처리사번
		String orgKnd = "";						//조직종류
		String propoDeptOrgNo = "";				//발의부서
		
		BigDecimal zero = BigDecimal.ZERO;
		
		logger.debug("☆★☆★☆ ★☆ ====================> 송신 수신 전문 START2222 <==================== ★☆ ☆★☆★☆ ");
		//logger.debug("☆★☆==========> input={}", input);
		logger.debug("☆★☆★☆★☆  ====================> 송신 수신 전문 END <==================== ★☆ ☆★☆★☆ ");
		
		if(StringUtils.isEmpty(input.getPyrcPrcsEno())) {
			prcsEno = FwUtil.getUserId();								// set [이체처리사원번호]
		}else{
			prcsEno = input.getPyrcPrcsEno();							// set [이체처리사원번호]
		}
		
		CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(prcsEno);
		
		if (commEmplInfo.getPropoDeptOrgNo() == null || StringUtils.isEmpty(commEmplInfo.getPropoDeptOrgNo())) {
			
			throw new ApplicationException("APCME0055", null);
		}
		
		//orgKnd = cmb001dbio.selectOneTBSLORG001a(commEmplInfo.getPropoDeptOrgNo());	//조직종류코드조회
		orgKnd = commEmplInfo.getOrgKcd();
		
		if (orgKnd == null || StringUtils.isEmpty(orgKnd)) {
			//throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직종류코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"조직종류코드(M)"});
		}
		
		// 조직종류 TM -- 100118
		// 조직종류 GA -- 100980
		// 조직종류 스텝부서 -- 발의부서
		if (RTCont.ORG_KND_TM.equals(orgKnd)) {
			propoDeptOrgNo = RTCont.ORG_NO_TM;
			//propoDeptOrgNo = "101088";			
		} else {
			//2017.01.26;현승훈;김유나과장요청-발의부서가 소비자보험팀일 경우 통합모니터링팀으로 변경
			if ("DP".equals(input.getBzDcd()) && RTCont.ORG_NO_CNSU_SFGD_TEAM.equals(commEmplInfo.getPropoDeptOrgNo())) {
				propoDeptOrgNo = RTCont.ORG_NO_INTGR_MNT_TEAM;
			} else if ("UW".equals(input.getBzDcd()) && RTCont.ORG_NO_CNSU_SFGD_TEAM.equals(commEmplInfo.getPropoDeptOrgNo())) {
				// 2017.03.29;현승훈;부활 처리시 소비자보호팀은 고객서비스팀 발의부서로 처리;성희선과장요청
				propoDeptOrgNo = RTCont.ORG_NO_SVC_TEAM;
			} else {
				propoDeptOrgNo = commEmplInfo.getPropoDeptOrgNo();
			}
			
//			if ("DP".equals(input.getBzDcd()) && "100981".equals(commEmplInfo.getPropoDeptOrgNo())) {
//				propoDeptOrgNo = "101115";
//			} else {
//				propoDeptOrgNo = commEmplInfo.getPropoDeptOrgNo();
//			}
		} 
		
		logger.debug("propoDeptOrgNo" + propoDeptOrgNo);
		//2016.10.17;현스훈;발의부서 세팅;
		if (StringUtils.isEmpty(input.getPropoDeptOrgNo())) {
			input.setPropoDeptOrgNo(propoDeptOrgNo);
		}
		
		logger.debug("input.setPropoDeptOrgNo" + input.getPropoDeptOrgNo());
		
//		input.setPropoDeptOrgNo(propoDeptOrgNo);
		
		if (StringUtils.isEmpty(input.getCentrNm()) ) {
			input.setCentrNm(commEmplInfo.getDofOrgNm());
		}
		if (StringUtils.isEmpty(input.getTeamNm()) ) {
			input.setTeamNm(commEmplInfo.getFofOrgNm());
		}
		if (StringUtils.isEmpty(input.getChrgpNm()) ) {
			input.setChrgpNm(commEmplInfo.getEmplNm());
		}
		
		SecuUtil.doDecObject(input);
	   
		if(!StringUtils.isEmpty(input.getActNo())){
		   input.setActNo(input.getActNo().replace("-", "")) ;  // 계좌번호 - 삭제
		   
		   if (input.getActNo().length() > 16) {
				throw new ApplicationException("APCME0025", new Object[]{"계좌번호(16자리초과)"});
		   }
		}
		
		// 처리시간 (자동이체처리 호출(OMM) 세팅용)
		prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

		
		/*********************** 이체송수신처리정보 기본필수입력값체크 START ***********************/
		
		// Validation#0 : TrsfTrrvPrcsInfo(이체송수신처리정보) 기본필수입력값체크
		if (StringUtils.isEmpty(input.getPrcsCd()) || input.getPrcsCd().length() != 2) {
			throw new ApplicationException("APCME0025", new Object[]{"처리코드(M)"});
		}
		
		if (StringUtils.isEmpty(input.getPrcsDt()) || input.getPrcsDt().length() != 8) {
			throw new ApplicationException("APCME0025", new Object[]{"처리일자(M)"});
		}
		
		if (StringUtils.isEmpty(input.getDpwdDcd()) || input.getDpwdDcd().length() != 1) {
			throw new ApplicationException("APCME0025", new Object[]{"입출금구분코드(M)"});
		}
		
		if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3) {
			throw new ApplicationException("APCME0025", new Object[]{"은행코드(M)"});
		}
		
		//2016.11.11;현승훈;출금이체동의 필수 항목 체크
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){				//(02) 자동집금처리(입금,집금) 
			if (!StringUtils.isEmpty(input.getWtrsfAsntEvidDcd())) {
				if (StringUtils.isEmpty(input.getWtrsfAsntSysCd())) {
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의시스템코드"}); 
				}
				if (StringUtils.isEmpty(input.getWtrsfAsntEvidDcd())) {
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의증빙구분코드"}); 
				}
				if (StringUtils.isEmpty(input.getWtrsfAsntEvidNo())) {
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의증빙번호"});
				}
				if (StringUtils.isEmpty(input.getWtrsfAsntDcd())) {
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의구분코드"});
				}
				if (StringUtils.isEmpty(input.getWtrsfAsntRcDcd())) {
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의접수구분코드"});
				}
				if (StringUtils.isEmpty(input.getContNo())) {
					throw new ApplicationException("APCME0025", new Object[]{"계약번호"});
				}
				if (StringUtils.isEmpty(input.getContrNm())) {
					throw new ApplicationException("APCME0025", new Object[]{"계약자명"});
				}				
			}
		}
				
		// 송금처리 : 동일일자,출금금액, 참조거래번호가 같으면 오류로 분류하여 처리.(전송 중인 건 체크)
		if (input.getBzTmKeyVl() != null  && input.getBzDcd() != null) {
			//2016.10.08;현승훈;입금처리 추가
			if (RTCont.PRCSCD_01.equals(input.getPrcsCd()) ) {
				TBCMRTM001Io  tBCMRTM001Io = cmb001dbio.selectOneTBCMRTM0014(input.getBzTmKeyVl(), input.getBzDcd(),input.getPrcsDt(),input.getPrcsCd());	//리얼타임이체거래번호로 조회
				if (tBCMRTM001Io != null) {
					if (tBCMRTM001Io.getTrsfAmt().compareTo(input.getTrsfAmt()) == 0 &&
						tBCMRTM001Io.getTrsfDt().equals(input.getPrcsDt()) &&
						RTCont.PRCSCD_01.equals(tBCMRTM001Io.getRltmBzDcd()) ) {
						/* 출금처리 요청시 동일일자 동일참조번호에 동일금액의 기 송금자료가 존재합니다. */
						throw new ApplicationException("APPAE0404", new Object[]{}); 
					}
				}
			}
		}
				
		// 송금처리 : 동일일자,출금금액, 참조거래번호가 같으면 오류로 분류하여 처리.
		if (input.getBzTmKeyVl() != null  && input.getBzDcd() != null) {
			//2016.10.08;현승훈;입금처리 추가
			if (RTCont.PRCSCD_01.equals(input.getPrcsCd()) ) {
				TBCMRTM001Io  tBCMRTM001Io = cmb001dbio.selectOneTBCMRTM0011(input.getBzTmKeyVl(), input.getBzDcd(),input.getPrcsDt(),input.getPrcsCd());	//리얼타임이체거래번호로 조회
				if (tBCMRTM001Io != null) {
					if (tBCMRTM001Io.getTrsfAmt().compareTo(input.getTrsfAmt()) == 0 &&
						tBCMRTM001Io.getTrsfDt().equals(input.getPrcsDt()) &&
						RTCont.PRCSCD_01.equals(tBCMRTM001Io.getRltmBzDcd()) ) {
						/* 출금처리 요청시 동일일자 동일참조번호에 동일금액의 기 송금자료가 존재합니다. */
						throw new ApplicationException("APPAE0325", new Object[]{}); 
					}
				}
			}
		}
		
		// 입금처리 : 동일일자,출금금액, 참조거래번호가 같으면 오류로 분류하여 처리.(전송 중인 건 체크)
		if (input.getBzTmKeyVl() != null  && input.getBzDcd() != null) {
			//2016.10.08;현승훈;입금처리 추가
			if (RTCont.PRCSCD_02.equals(input.getPrcsCd()) ) {
				TBCMRTM001Io  tBCMRTM001Io = cmb001dbio.selectOneTBCMRTM0014(input.getBzTmKeyVl(), input.getBzDcd(),input.getPrcsDt(),input.getPrcsCd());	//리얼타임이체거래번호로 조회
				if (tBCMRTM001Io != null) {
					if (tBCMRTM001Io.getTrsfAmt().compareTo(input.getTrsfAmt()) == 0 &&
						tBCMRTM001Io.getTrsfDt().equals(input.getPrcsDt()) &&
						RTCont.PRCSCD_02.equals(tBCMRTM001Io.getRltmBzDcd()) ) {
						/* 출금처리 요청시 동일일자 동일참조번호에 동일금액의 기 송금자료가 존재합니다. */
						throw new ApplicationException("APPAE0406", new Object[]{}); 
					}
				}
			}
		}
				
		// 입금처리 : 동일일자,출금금액, 참조거래번호가 같으면 오류로 분류하여 처리.
		if (input.getBzTmKeyVl() != null  && input.getBzDcd() != null) {
			//2016.10.08;현승훈;입금처리 추가
			if (RTCont.PRCSCD_02.equals(input.getPrcsCd()) ) {
				TBCMRTM001Io  tBCMRTM001Io = cmb001dbio.selectOneTBCMRTM0011(input.getBzTmKeyVl(), input.getBzDcd(),input.getPrcsDt(),input.getPrcsCd());	//리얼타임이체거래번호로 조회
				if (tBCMRTM001Io != null) {
					if (tBCMRTM001Io.getTrsfAmt().compareTo(input.getTrsfAmt()) == 0 &&
						tBCMRTM001Io.getTrsfDt().equals(input.getPrcsDt()) &&
						RTCont.PRCSCD_02.equals(tBCMRTM001Io.getRltmBzDcd()) ) {
						/* 출금처리 요청시 동일일자 동일참조번호에 동일금액의 기 송금자료가 존재합니다. */
						throw new ApplicationException("APPAE0405", new Object[]{}); 
					}
				}
			}
		}
		
		//2017.02.21;현승훈;이체금액 체크
		if (RTCont.PRCSCD_01.equals(input.getPrcsCd()) || RTCont.PRCSCD_02.equals(input.getPrcsCd()) ) {
			if (input.getTrsfAmt() == null || input.getTrsfAmt().compareTo(zero) == 0 ) {			
				throw new ApplicationException("APCME0025", new Object[]{"이체금액"});
			} else if (input.getTrsfAmt().compareTo(zero) < 0 ){
				throw new ApplicationException("APCME0025", new Object[]{"이체금액"});
			}
		}
		
		/*********************** 이체송수신처리정보 기본필수입력값체크 END ***********************/
	
		
		/*********************** 지급이체송수신전문처리위한 세팅부 START ***********************/		
		
		// Validation#1 : 처리코드(01 or 02) 와 입출금구분코드가 상이할 경우 오류, return
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){			// 입금
			if(!RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){
				// '처리코드와 입출금구분코드가 상이합니다. 확인해주세요.'
				throw new ApplicationException("APPAE0058", new Object[]{"처리코드", "입출금구분코드"});
			}
		}
		
		if(RTCont.PRCSCD_01.equals(input.getPrcsCd())){			// 출금
			if(!RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd())){
				// '처리코드와 입출금구분코드가 상이합니다. 확인해주세요.'
				throw new ApplicationException("APPAE0058", new Object[]{"처리코드", "입출금구분코드"});
			}
		}
		
		if(RTCont.PRCSCD_01.equals(input.getPrcsCd()))	{
			tgmNoBankCd = cmb001dbio.selectOneTBCMRTM0240(input.getPropoDeptOrgNo(), "02");	//모계좌금융기관조회(제지급계좌조회)
		} else if(RTCont.PRCSCD_07.equals(input.getPrcsCd()))	{
			tgmNoBankCd =  input.getBnkCd() ;
		} else if(RTCont.PRCSCD_02.equals(input.getPrcsCd()))	{
			tgmNoBankCd = cmb001dbio.selectOneTBCMRTM0242(input.getPropoDeptOrgNo(), "01", input.getBnkCd());	//모계좌금융기관조회(입금계좌(RTB))
		} else{
			//tgmNoBankCd =  input.getBnkCd() ;
			// 이체처리 결과시 지급처리건 조회시 제지급모계좌 조회
			if (RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd())) {
				tgmNoBankCd = cmb001dbio.selectOneTBCMRTM0240(input.getPropoDeptOrgNo(), "02");	//모계좌금융기관조회(제지급계좌조회)
			} else {
				tgmNoBankCd = cmb001dbio.selectOneTBCMRTM0242(input.getPropoDeptOrgNo(), "01", input.getBnkCd());	//모계좌금융기관조회(입금계좌(RTB))
			}
		}
		
		if (StringUtils.isEmpty(tgmNoBankCd)) {
			throw new ApplicationException("APPAE0051", null);
		}
		
		// 전송구분코드 세팅 (default 미전송 : 0 세팅)
		input.setTrmsDcd(RTCont.TRMSDCD_0);
		
		// 처리코드별(업무별 구분코드) 분기하여 처리은행코드 세팅
		if(RTCont.PRCSCD_07.equals(input.getPrcsCd())){	//(07) 성명조회(예금주조회)

			//라이나 성명조회시 지급계좌로 변경
			input.setPrcsBnkCd(tgmNoBankCd);
			
			// (07) 성명조회(예금주조회)시 업무구분코드가 고객(CS)일 경우 계좌관리번호로 계좌조회 로직을 수행하지 않는다._20121212(고객팀요청)
			if(!"CS".equals(input.getBzDcd())){
				
				if(!StringUtils.isEmpty(input.getActMgntNo())){
					// 계좌관리번호로 계좌조회
					actInfo = this.cmb001dbio.selectOneTBCSFCR0010(input.getActMgntNo());
					SecuUtil.doDecObject(actInfo);
					
				}else{
					throw new ApplicationException( "APCME0005", null, new Object[]{ "계좌관리번호", "계좌관리번호" });
				}
				
				// 계좌관리번호로 계좌조회하여 업무파트에서 넘어온 매핑하여 비교
				if(actInfo != null){						
					if(!input.getActNo().equals((actInfo.getActNo()))){		// 계좌번호 비교
						// validation : 계좌정보에 존재하지 않는 계좌번호입니다. 확인해주세요, 업무파트로 return
						logger.debug("입력계좌번호 {}, 조회계좌번호 {}",input.getActNo(), actInfo.getActNo());
						throw new ApplicationException("APPAE0047", new Object[]{"계좌번호"});
						
					}else if(!input.getAchdNm().equals((actInfo.getAchdNm()))){		// 예금주명 비교
						// validation : 계좌정보에 존재하지 않는 예금주명입니다. 확인해주세요, 업무파트로 return
						logger.debug("입력예금주명 {}, 조회예금주명 {}",input.getAchdNm(), actInfo.getAchdNm());
						throw new ApplicationException("APPAE0047", new Object[]{"예금주명"});
						
					}else if(!"0000".equals(actInfo.getFininActStcd())){					// 금융기관계좌상태코드 체크
						// validation : 해당금융기관의 계좌상태가 정상이 아닙니다. 확인해주세요, 업무파트로 return
						logger.debug("계좌상태: {}", actInfo.getFininActStcd());
						throw new ApplicationException("APPAE0055", null);
					}
					
				}else{
					// 계좌정보가 존재하지 않는 계좌관리번호입니다. 확인해주세요.
					throw new ApplicationException("APPAE0048", null);
				}
			}
		}else{	    // (07) 성명조회(예금주조회) 이외업무
			if (RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd()) && !RTCont.PRCSCD_08.equals(input.getPrcsCd())){
				input.setPrcsBnkCd(tgmNoBankCd);
			} else {
				input.setPrcsBnkCd(input.getBnkCd());
			}
			
			// Validation#2 : 계좌관리번호로 계좌조회하여 업무파트에서 넘어온 매핑하여 비교
			if((RTCont.PRCSCD_01.equals(input.getPrcsCd()) || 	//(01) 자동이체처리 호출(송금,지급) 이거나
					RTCont.PRCSCD_02.equals(input.getPrcsCd()) ||	//(02) 자동집금처리(출금,집금) 이거나
						RTCont.PRCSCD_03.equals(input.getPrcsCd()) ||	//(03) 이체처리결과조회(이체확인) 이거나
							RTCont.PRCSCD_04.equals(input.getPrcsCd()) ||	//(04) 이체취소(SC만) 이거나
								RTCont.PRCSCD_07.equals(input.getPrcsCd())) &&	//(07) 성명조회(예금주조회) 일 경우 - 예금주조회는 위에 분기에서 적용함
									!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd())){	// && 채널에서 넘어온 데이터가 아닐 경우 추가_20121201 	
				
				if(!StringUtils.isEmpty(input.getActMgntNo())){
					// 계좌관리번호로 계좌조회
					actInfo = this.cmb001dbio.selectOneTBCSFCR0010(input.getActMgntNo());
					SecuUtil.doDecObject(actInfo);
					
				}else{
					throw new ApplicationException( "APCME0005", null, new Object[]{ "계좌관리번호", "계좌관리번호" });
				}
				
				// 계좌관리번호로 계좌조회하여 업무파트에서 넘어온 매핑하여 비교
				if(actInfo != null){
					
					if(!input.getActNo().equals((actInfo.getActNo()))){		// 계좌번호 비교
						// validation : 계좌정보에 존재하지 않는 계좌번호입니다. 확인해주세요, 업무파트로 return
						throw new ApplicationException("APPAE0047", new Object[]{"계좌번호"});
						
					}else if(!input.getAchdNm().equals((actInfo.getAchdNm()))){		// 예금주명 비교
						// validation : 계좌정보에 존재하지 않는 예금주명입니다. 확인해주세요, 업무파트로 return
						throw new ApplicationException("APPAE0047", new Object[]{"예금주명"});
						
					}else if(!"00".equals(actInfo.getFininActStcd())){					// 금융기관계좌상태코드 체크
						// validation : 해당금융기관의 계좌상태가 정상이 아닙니다. 확인해주세요, 업무파트로 return
						throw new ApplicationException("APPAE0055", null);
					}
					
				}else{
					// 계좌정보가 존재하지 않는 계좌관리번호입니다. 확인해주세요.
					throw new ApplicationException("APPAE0048", null);
				}
				
			}
		}  // end if 예금주 조회 else if 모계좌 조회  else 다른 업무
		
		logger.debug("☆★☆==========> 여기는 들어오는지 0000000000000000000");
		if( !RTCont.PRCSCD_08.equals(input.getPrcsCd()) && !RTCont.PRCSCD_07.equals(input.getPrcsCd())) {	//ERP파트에서 넘어온 데이터가 아니면 입출금구분코드 값으로 조건값을 세팅
			// 입출금구분코드가 입금(1) 일 경우 모계좌업무구분코드가 RTB (01) 로 조회
			if(RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){
				
				fininInfo =  this.cmb001dbio.selectOneTBCMRTM0241(input.getPropoDeptOrgNo(),"01" , tgmNoBankCd);
				
			// 입출금구분코드가 출금(2) 일 경우 모계좌업무구분코드가 제지급 (02) 로 조회
			}else if(RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd())){
				
				fininInfo =  this.cmb001dbio.selectOneTBCMRTM0241(input.getPropoDeptOrgNo(),"02" , tgmNoBankCd);
				
			}else{
				// 채널구분코드나 입출금구분코드가 형식에 맞지 않는 코드입니다. 확인해주세요.
				throw new ApplicationException("APPAE0076", null);
			}
			
			SecuUtil.doDecObject(fininInfo);
			
			if(fininInfo == null){
				// 채널구분코드별로 금융기관제휴업무목록(TBCMRTM006) 을 조회, '금융기관제휴업무목록 정보가 존재하지 않습니다.' 메세지
				throw new ApplicationException("APPAE0051", null);
			}
		}		
		/*********************** 지급이체송수신전문처리위한 세팅부 END ***********************/
		
		/*********************** 인출일 경우 출금이체동의 시작 START ***********************/
		// 2016.03.14;현승훈;입금,집금일 경우 출금이체동의 신청 처리 우선 선행
		// 처리코드별(업무별 구분코드) : 02-자동집금처리(입금,집금)
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){				//(02) 자동집금처리(입금,집금)
			
			if (input.getTrsfAmt() == null || input.getTrsfAmt().compareTo(zero) == 0 ) {			
				throw new ApplicationException("APCME0025", new Object[]{"이체금액"});
			}
			
			if ((StringUtils.isEmpty(input.getActMgntNo()) ) && // || input.getActMgntNo().length() != 20) &&
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201) {
				throw new ApplicationException("APCME0025", new Object[]{"계좌관리번호"});
			}
			
			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
				throw new ApplicationException("APCME0025", new Object[]{"은행코드"});
			}
			
			if (StringUtils.isEmpty(input.getActNo())) {
				throw new ApplicationException("APCME0025", new Object[]{"계좌번호"});
			} 
			
			if ((StringUtils.isEmpty(input.getAchdNm())) && 
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {
				throw new ApplicationException("APCME0025", new Object[]{"예금주명"});
			}
			
			if ((StringUtils.isEmpty(input.getAchdRrno()) || (input.getAchdRrno().length() != 13 && input.getAchdRrno().length() != 10)) &&
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201
				throw new ApplicationException("APCME0025", new Object[]{"예금주주민등록번호"});
			}
			
			
			rltmTrsfPmpsNo = this.cmb001dbio.selectOneTBCMRTM0013();
			
			wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "11", rltmTrsfPmpsNo);
			
			if (StringUtils.isEmpty(wtrsfAsntCd) || wtrsfAsntCd == null) 
			{
				throw new ApplicationException("APCME0054", new Object[]{"대외계 미응답"});
			} else if (!"0000".equals(wtrsfAsntCd))
			{
				String rltmAnswCtnt = this.cmb001dbio.selectOneTBCMRTM0081(tgmNoBankCd, wtrsfAsntCd);
						
				if (StringUtils.isEmpty(rltmAnswCtnt)) {
					rltmAnswCtnt = "기타오류";
				} 
				
				throw new ApplicationException("APCME0054", new Object[]{"출금이체동의신청 시 응답결과 오류 ( " + rltmAnswCtnt + " - " + wtrsfAsntCd + ") 가 발생했습니다."});
			}
		}
		/*********************** 인출일 경우 출금이체동의 종료 END ***********************/
		
		/******* 송수신전문 전송보내기전 리얼타임이체원장(TBCMRTM001) 테이블 입력 : insert START *******/
		logger.debug("=========>> 송수신전문 전송보내기전 리얼타임이체원장(TBCMRTM001) 테이블 입력 : insert START <<=========");
		
		// 전문번호 생성
		tgmNo = setTgmNoCrt(tgmNoBankCd, today);  // 
		
		if(!StringUtils.hasText(tgmNo)){
			// 전문번호 생성 오류 : '전문번호가 생성되지 않았습니다. 확인해주세요.'
			throw new ApplicationException("APPAE0057", new Object[]{"전문번호"});
		}
				
		// 리얼타임이체거래번호 채번생성
		rltmTrsfTxNo = cma004bean.getNewPayMknoNo("CMRT", today.substring(0, 8), 20);
		
		if(!StringUtils.hasText(rltmTrsfTxNo)){
			// 리얼타임이체거래번호 채번생성 오류 : '리얼타임이체거래번호가 생성되지 않았습니다. 확인해주세요.'
			throw new ApplicationException("APPAE0057", new Object[]{"리얼타임이체거래번호"});
		}
		
		logger.debug("=========>> rltmTrsfPmpsNo <<=========" + rltmTrsfPmpsNo);
		
		logger.debug("=========>> input <<=========" + input);
		
		iResult = insertTrmsDcd(rltmTrsfTxNo, today, prcsHms, tgmNo, rltmTrsfPmpsNo, input);
		
		if(iResult != 1){
			
			// 2016.03.14;현승훈;입금,집금일 경우 출금이체동의 신청 처리 우선 선행
			// 처리코드별(업무별 구분코드) : 02-자동집금처리(입금,집금)
			if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){				//(02) 자동집금처리(입금,집금)
				wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "12", rltmTrsfPmpsNo);
			}
			
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장입력"});
		}
		
		iResult = 0;
		
		//2016.10.17;현승훈;
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){
			if (!StringUtils.isEmpty(input.getWtrsfAsntEvidDcd())) {
				dlngInfo = new WtrsfAsntDlngInfo();
				
				if (StringUtils.isEmpty(input.getWtrsfAsntDt())) {
					dlngInfo.setWtrsfAsntDt(today);											// set [출금이체동의일자]
				} else {
					dlngInfo.setWtrsfAsntDt(input.getWtrsfAsntDt());						// set [출금이체동의일자]
				}
				dlngInfo.setWtrsfAsntTi(prcsHms);										// set [출금이체동의시각]
				dlngInfo.setWtrsfAsntSysCd(input.getWtrsfAsntSysCd());					// set [출금이체동의시스템코드]				
				dlngInfo.setWtrsfAsntEvidDcd(input.getWtrsfAsntEvidDcd());				// set [출금이체동의증빙구분코드]
				dlngInfo.setWtrsfAsntEvidNo(input.getWtrsfAsntEvidNo());				// set [출금이체동의증빙번호]
				dlngInfo.setWtrsfAsntDcd(input.getWtrsfAsntDcd());						// set [출금이체동의구분코드]
				dlngInfo.setWtrsfAsntRcDcd(input.getWtrsfAsntRcDcd());					// set [출금이체동의접수구분코드]
				dlngInfo.setContNo(input.getContNo());									// set [계약번호]
				dlngInfo.setPmpsNo(rltmTrsfPmpsNo);										// set [납부자번호]
				dlngInfo.setContrNm(input.getContrNm());								// set [계약자명]
				dlngInfo.setPmpsDscNo(input.getAchdRrno());								// set [납부자식별번호]
				dlngInfo.setPmpsNm(input.getAchdNm());									// set [납부자명]
				dlngInfo.setFininCd(input.getBnkCd());									// set [금융기관코드]
				dlngInfo.setPmpsActNo(input.getActNo());								// set [납부자계좌번호]
				dlngInfo.setTrsfAmt(input.getTrsfAmt());								// set [이체금액]
				
				
				dlngInfo.setWtrsfAsntVcrecStrtDtm(input.getWtrsfAsntVcrecStrtDtm());	// set [출금이체동의녹취시작일시]
				dlngInfo.setWtrsfAsntVcrecEndDtm(input.getWtrsfAsntVcrecEndDtm());		// set [출금이체동의녹취종료일시]
				dlngInfo.setCentrNm(input.getCentrNm());								// set [센터명]
				dlngInfo.setTeamNm(input.getTeamNm());									// set [팀명]
				dlngInfo.setChrgpEno(input.getChrgpEno());								// set [담당자사원번호]
				dlngInfo.setChrgpNm(input.getChrgpNm());								// set [담당자명]
				
				dlngInfo.setBzTxRfDcd(input.getBzDcd());								// set [업무거래참조구분코드]
				dlngInfo.setBzTxRfNo(input.getBzTmKeyVl());								// set [업무거래참조번호]
				dlngInfo.setWtrsfAsntNrmYn("N");										// set [출금이체동의정상여부]
				
//				logger.debug("=========>> dlngInfo (TBCMETC015) 테이블 입력 : insert END <<=========" + dlngInfo);
				
				iResult = cmb040bean.callWtrsfAsntDlng(dlngInfo);
				
				if(iResult != 1){
					wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "12", rltmTrsfPmpsNo);
					// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
					throw new ApplicationException("APPAE0009", new Object[]{"출금이체동의처리내역입력"});
				}				
			}			
		}
		
		logger.debug("=========>> 송수신전문 전송보내기전 리얼타임이체원장(TBCMRTM001) 테이블 입력 : insert END <<=========");
		/******* 송수신전문 전송보내기전 리얼타임이체원장(TBCMRTM001) 테이블 입력 : insert END *******/
		
		String testDay		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
		// 처리코드별(업무별 구분코드) 업무분기 (각 전문전송업무 메소드 호출)
		if(RTCont.PRCSCD_01.equals(input.getPrcsCd())){				//(01) 자동이체처리 호출(송금,지급)
		
			//2017.03.24;현승훈;테스트를 위해 분기처리 : 지급처리 27일부터
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 자동이체처리 호출(송금,지급)
				prcsInfo = cmb003bean.setAtrPrcsNewTest(input, tgmNo, rltmTrsfTxNo);
			} else {
				// KIB-NET 자동이체처리 호출(송금,지급)
				prcsInfo = cmb003bean.setAtrPrcsNew(input, tgmNo, rltmTrsfTxNo);
			}

		}else if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){		//(02) 자동집금처리(입금,집금)
			
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 자동집금처리(입금,집금)
				prcsInfo = cmb003bean.setDpsPrcsNewTest(input, tgmNo, rltmTrsfTxNo, rltmTrsfPmpsNo);
			} else {
				// KIB-NET 자동집금처리(입금,집금)
				prcsInfo = cmb003bean.setDpsPrcsNew(input, tgmNo, rltmTrsfTxNo, rltmTrsfPmpsNo);
			}
			
			//2016.10.17;현승훈;출금이체동의처리내역
			//입금결과가 정상일 경우
			if ("0000".equals(prcsInfo.getBnkAnswCd())) {
				//if (!StringUtils.isEmpty(input.getWtrsfAsntEvidDcd())) {
					
					if (StringUtils.isEmpty(input.getWtrsfAsntDt())) {							
						iResult = cmb040bean.updateWtrsfAnstDlng(input.getBzTmKeyVl(), today, "Y" );
					} else {
						iResult = cmb040bean.updateWtrsfAnstDlng(input.getBzTmKeyVl(), input.getWtrsfAsntDt(), "Y" );
					}
				//}			
			}
			
		}else if(RTCont.PRCSCD_03.equals(input.getPrcsCd())){		//(03) 이체처리결과조회(이체확인)
			
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 이체처리결과조회(이체확인)
				prcsInfo = cmb003bean.setTrsfPrcsRstInqNewTest(input, tgmNo, rltmTrsfTxNo);
			} else {
				// KIB-NET 이체처리결과조회(이체확인)
				prcsInfo = cmb003bean.setTrsfPrcsRstInqNew(input, tgmNo, rltmTrsfTxNo);
			}
			
//			//2016.10.17;현승훈;출금이체동의처리내역
//			//입금결과가 정상일 경우
			if ("0000".equals(prcsInfo.getBnkAnswCd())) {
				if(RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){		// 입출금구분코드가 입금(1) 일 경우
					
					iResult = cmb040bean.updateWtrsfAnstDlng(input.getBzTmKeyVl(), "Y" );
					
					if(iResult != 1){
						wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "12", rltmTrsfPmpsNo);
						// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						throw new ApplicationException("APPAE0009", new Object[]{"출금이체동의처리내역입력"});
					}				
				}			
			}
		}else if(RTCont.PRCSCD_06.equals(input.getPrcsCd())){		//(06) 출금이체신청(납부자번호등록)
			
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 출금이체신청(납부자번호등록)
				prcsInfo = cmb003bean.setWdmTrsfApplNewTest(input, tgmNo, rltmTrsfTxNo, "");
			} else {
				// KIB-NET 출금이체신청(납부자번호등록)
				prcsInfo = cmb003bean.setWdmTrsfApplNew(input, tgmNo, rltmTrsfTxNo, "");
			}

		}else if(RTCont.PRCSCD_07.equals(input.getPrcsCd())){		//(07) 실명조회(예금주조회)
			
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 실명조회
				prcsInfo = cmb003bean.setRlnmInqNewTest(input, tgmNo, rltmTrsfTxNo);
			} else {
				// KIB-NET 실명조회
				prcsInfo = cmb003bean.setRlnmInqNew(input, tgmNo, rltmTrsfTxNo);
			}
			
		}else if(RTCont.PRCSCD_08.equals(input.getPrcsCd())){		//(08) 잔액조회 (이체모계좌조회)
			
			// KIB-NET 잔액조회
			prcsInfo = cmb003bean.setBamtInqNew(input, tgmNo, rltmTrsfTxNo);
					
		} else if(RTCont.PRCSCD_10.equals(input.getPrcsCd())){		//(10) 수취조회
			
			// KIB-NET 수취조회
			prcsInfo = cmb003bean.setRecvInqNew(input, tgmNo, rltmTrsfTxNo);
			
		} else{
			// '유효하지않은 처리코드(업무별구분코드)입니다. 확인해주세요.', 오류 return
			throw new ApplicationException("APPAE0052", new Object[]{"처리코드(업무별구분코드)"});
			
		}
		
		/*********************** 인출일 경우 출금이체동의 해지 시작 START ***********************/
		// 2016.03.14;현승훈;입금,집금일 경우 출금이체동의 신청 처리 우선 선행
		// 처리코드별(업무별 구분코드) : 02-자동집금처리(입금,집금)
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){				//(02) 자동집금처리(입금,집금)
			
			wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "12", rltmTrsfPmpsNo);
			
		}
		/*********************** 인출일 경우 출금이체동의 해지 종료 END ***********************/
		
		return prcsInfo;
	}
	
	/**
	 * 전문번호생성
	 * @param String fnnCd       금융기관코드
	 * @param String mknoPrcsDt  채번처리일자
	 * @return String mknoTgmNo  채번전문번호 
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String setTgmNoCrt (String fnnCd, String mknoPrcsDt) throws ApplicationException {
		
		int        iResult      		= 0;
		
		String     strMknoTgmNo     	= "";				// 조회된 채번전문번호
		String     mknoTgmNo     		= "";				// 채번전문번호
		String     sFnnCd               = "";
		
		logger.debug("========================  전문번호생성 채번 ======================");
		logger.debug("fnnCd = {} ", fnnCd);
		logger.debug("mknoPrcsDt = {} ", mknoPrcsDt );
		
		sFnnCd = fnnCd;
		
		// 필수입력값체크
		if (StringUtils.isEmpty(sFnnCd) || sFnnCd.length() != 3 ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ "금융기관코드", "금융기관코드" });
		} 
		
		if (StringUtils.isEmpty(mknoPrcsDt) || mknoPrcsDt.length() != 8 ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ "채번처리일자", "채번처리일자" });
		}
		
		
		/*전문번호 생성시 각 금융기관코드를 대표금융기관코드로 치환하여 번호를 생성하기 위해 추가코딩_20130503*/
		if(RTCont.FININCD_010.equals(sFnnCd) || RTCont.FININCD_011.equals(sFnnCd) || 
				RTCont.FININCD_012.equals(sFnnCd) || RTCont.FININCD_013.equals(sFnnCd) || 
					RTCont.FININCD_014.equals(sFnnCd) || RTCont.FININCD_015.equals(sFnnCd)){
			
			sFnnCd = RTCont.FININCD_011;		// 농협
			
		}else if(RTCont.FININCD_071.equals(sFnnCd) || RTCont.FININCD_072.equals(sFnnCd) || 
					RTCont.FININCD_073.equals(sFnnCd) || RTCont.FININCD_074.equals(sFnnCd) || 
						RTCont.FININCD_075.equals(sFnnCd)){
			
			sFnnCd = RTCont.FININCD_071;		// 우체국
			
		}else if(RTCont.FININCD_088.equals(sFnnCd)){
			sFnnCd = RTCont.FININCD_026;		// 신한
			
		}else if(RTCont.FININCD_045.equals(sFnnCd) || RTCont.FININCD_046.equals(sFnnCd)){
			sFnnCd = RTCont.FININCD_045;		// 새마을금고
			
		}else if(RTCont.FININCD_048.equals(sFnnCd) || RTCont.FININCD_049.equals(sFnnCd)){
			sFnnCd = RTCont.FININCD_048;		// 신용협동조합
		}
		
		//금융기관코드, 채번처리일자로 채번전문번호 조회(체크)
		//2016.09.02
		//kibnet은 거래번호가 은행이 다르고 거래일련번호가 같은 경우 오류 처리 발생으로 
		//금융기관코드 대신 "999"로 세팅해서 처리하도록 수정
		//strMknoTgmNo =  this.cmb001dbio.selectOneTBCMRTM0020(mknoPrcsDt, fnnCd);
		strMknoTgmNo =  this.cmb001dbio.selectOneTBCMRTM0020(mknoPrcsDt, "999");
		
		logger.debug("strMknoTgmNo = {}", strMknoTgmNo );
		
		//리얼타임전문번호의 채번전문번호 조회시 전문번호가 존재하지 않으면 생성(insert) 아니면 수정(update)
		if (!StringUtils.hasText(strMknoTgmNo)) {
			//전문번호 초기화.
			mknoTgmNo = "";
			
			mknoTgmNo = "0000001";

			TBCMRTM002Io tbcmrtm002io = new TBCMRTM002Io();

			//2016.09.02
			//kibnet은 거래번호가 은행이 다르고 거래일련번호가 같은 경우 오류 처리 발생으로 
			//금융기관코드 대신 "999"로 세팅해서 처리하도록 수정
			//tbcmrtm002io.setFininCd(fnnCd);						// set [금융기관코드]
			tbcmrtm002io.setFininCd("999");						// set [금융기관코드]
			tbcmrtm002io.setMknoPrcsDt(mknoPrcsDt);				// set [채번처리일자]
			tbcmrtm002io.setMknoTgmNo(mknoTgmNo);				// set [채번전문번호]
			tbcmrtm002io.setLastChgrId(FwUtil.getUserId());		// set [최종변경자ID]
			tbcmrtm002io.setLastChgPgmId(FwUtil.getPgmId());	// set [최종변경프로그램ID]
			tbcmrtm002io.setLastChgTrmNo(FwUtil.getTrmNo());	// set [최종변경단말번호]
			
			logger.debug("tbcmrtm002io(리얼타임전문번호테이블 INSERT 세팅값)={}", tbcmrtm002io);
			
			iResult = this.cmb001dbio.insertOneTBCMRTM0020(tbcmrtm002io);
			
		} else {
			
			//2016.09.02
			mknoTgmNo = Integer.toString(Integer.parseInt(strMknoTgmNo) + 1);
			
			mknoTgmNo = StringUtils.lpad(mknoTgmNo, 7, "0");
			
			logger.debug(" === mknoTgmNo === " + mknoTgmNo);
			
			TBCMRTM002Io tbcmrtm002io = new TBCMRTM002Io();
			
			//2016.09.02
			//kibnet은 거래번호가 은행이 다르고 거래일련번호가 같은 경우 오류 처리 발생으로 
			//금융기관코드 대신 "999"로 세팅해서 처리하도록 수정
			//tbcmrtm002io.setFininCd(fnnCd);						// set [금융기관코드]
			tbcmrtm002io.setFininCd("999");						// set [금융기관코드]			
			tbcmrtm002io.setMknoPrcsDt(mknoPrcsDt);				// set [채번처리일자]
			tbcmrtm002io.setMknoTgmNo(mknoTgmNo);				// set [채번전문번호]
			tbcmrtm002io.setLastChgrId(FwUtil.getUserId());		// set [최종변경자ID]
			tbcmrtm002io.setLastChgPgmId(FwUtil.getPgmId());	// set [최종변경프로그램ID]
			tbcmrtm002io.setLastChgTrmNo(FwUtil.getTrmNo());	// set [최종변경단말번호]
			
			logger.debug("tbcmrtm002io(리얼타임전문번호테이블 UPDATE 세팅값)={}", tbcmrtm002io);
			
			//채번테이블 업데이트.
			iResult = this.cmb001dbio.updateOneTBCMRTM0020(tbcmrtm002io);
		}
		
		if(iResult == 1){
			logger.debug("mknoTgmNo(생성된 전문번호)={}", mknoTgmNo);
		}else{
			// SQL오류, '리얼타임전문번호입력 및 변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문번호 입력 및 변경"});
		}
		
		return mknoTgmNo;
	}
	
	/**
	 * 리얼타임이체원장 입력
	 * @param rltmTrsfTxNo  리얼타임이체거래번호
	 * @param today  이체일자
	 * @param prcsHms  이체처리시각
	 * @param tgmNo  전문번호
	 * @param TrsfTrrvPrcsInfo  이체송수신처리정보
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int insertTrmsDcd (String rltmTrsfTxNo, String today, String prcsHms, String tgmNo, String rltmTrsfPmpsNo, TrsfTrrvPrcsInfo input) throws ApplicationException {
		
		int iResult = 0;
		TBCMRTM001Io insertInput = new TBCMRTM001Io();
		String achdRrno = "";
//		EmplInfo empInfo = slzyy1bean.getEmplInfo(FwUtil.getUserId());				// 사원정보조회
		
		insertInput.setRltmTrsfTxNo(rltmTrsfTxNo);									// set [리얼타임이체거래번호]
		insertInput.setRltmBzDcd(StringUtils.nvl(input.getPrcsCd()));				// set [리얼타임업무구분코드]
		insertInput.setTrsfDt(today);												// set [이체일자]
	   	if(StringUtils.isEmpty(input.getPyrcDofOrgNo())) {
			insertInput.setTrsfDofOrgNo(FwUtil.getDeptCd());							// set [이체지점조직번호]	
		}else{
			insertInput.setTrsfDofOrgNo(input.getPyrcDofOrgNo());					// set [이체지점조직번호]
		}
		
		if(StringUtils.isEmpty(input.getPyrcFofOrgNo())) {
			insertInput.setTrsfFofOrgNo(FwUtil.getDeptCd());							// set [이체영업소조직번호]	
		}else{
			insertInput.setTrsfFofOrgNo(input.getPyrcFofOrgNo());							// set [이체영업소조직번호]
		}
		
		if(StringUtils.isEmpty(input.getPyrcPrcsEno())) {
			insertInput.setTrsfPrcsEno(FwUtil.getUserId());								// set [이체처리사원번호]
		}else{
			insertInput.setTrsfPrcsEno(input.getPyrcPrcsEno());							// set [이체영업소조직번호]
		}

		
		insertInput.setPayRcPathCd(StringUtils.nvl(input.getPayRcPathCd()));		// set [지급접수경로코드]
		insertInput.setPyprcPathCd(StringUtils.nvl(input.getPyprcPathCd()));		// set [지급처리경로코드]
		insertInput.setPyprcCd(StringUtils.nvl(input.getChnlDcd()));				// set [지급처리코드] - 채널구분코드(지급처리코드)
		insertInput.setPayRcMcd(StringUtils.nvl(input.getPayRcMcd()));				// set [지급접수방법코드]
		insertInput.setTpayAmt(input.getTrsfAmt());									// set [총지급금액]
		insertInput.setTrsfAmt(input.getTrsfAmt());									// set [이체금액]
		insertInput.setBenfcCustNo(StringUtils.nvl(input.getBenfcCustNo()));		// set [수익자고객번호]
		insertInput.setContrCustNo(StringUtils.nvl(input.getContrCustNo()));		// set [계약자고객번호]
		insertInput.setDpwdDcd(StringUtils.nvl(input.getDpwdDcd()));				// set [입출금구분코드]
		insertInput.setActNo(StringUtils.nvl(input.getActNo()));					// set [계좌번호]
		insertInput.setAchdNm(StringUtils.nvl(input.getAchdNm()));					// set [예금주명]
		
		achdRrno = SecuUtil.getEncValue(input.getAchdRrno(), EncType.achdRrno );
		insertInput.setAchdRrno(StringUtils.nvl(achdRrno));				// set [예금주주민등록번호]
		
		// 처리코드가 (02) 자동집금처리 호출(입금,집금) 일 경우
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){
			
			insertInput.setTrsfObjFininCd(StringUtils.nvl(input.getPrcsBnkCd()));	// set [이체대상금융기관코드]
			if(RTCont.FININCD_012.equals(input.getBnkCd())){
				insertInput.setTrsfPrcsFininCd(StringUtils.nvl(RTCont.FININCD_011));		// set [이체처리금융기관코드]
			}
			else{
			     insertInput.setTrsfPrcsFininCd(StringUtils.nvl(input.getBnkCd()));		// set [이체처리금융기관코드]
			}
			
		// 그외일 경우	
		}else{
			insertInput.setTrsfObjFininCd(StringUtils.nvl(input.getBnkCd()));		// set [이체대상금융기관코드]
			insertInput.setTrsfPrcsFininCd(StringUtils.nvl(input.getPrcsBnkCd()));	// set [이체처리금융기관코드]	
		}
		
		insertInput.setRltmTrmsDcd(StringUtils.nvl(input.getTrmsDcd()));			// set [전송구분코드]
		insertInput.setTrsfPrcsTi(prcsHms);											// set [이체처리시각]
		insertInput.setCmpyImtrsfRcd("");											// set [업체즉시이체결과코드]
		insertInput.setFininImtrsfRcd("");											// set [금융기관즉시이체결과코드]
		insertInput.setBfCmpyImtrsfRcd("");											// set [이전업체즉시이체결과코드]
		insertInput.setBfFininImtrsfRcd("");										// set [이전금융기관즉시이체결과코드]
		insertInput.setRltmTgmNo(tgmNo);											// set [리얼타임전문번호]
		insertInput.setKftcTgmNo("");												// set [금융결제원전문번호]
		insertInput.setRfActMgntNo(StringUtils.nvl(input.getActMgntNo()));			// set [참조계좌관리번호]
		insertInput.setPyrcTxRfNoDcd(StringUtils.nvl(input.getBzDcd()));			// set [출수납거래참조번호구분코드]
		insertInput.setPyrcTxRfNo(StringUtils.nvl(input.getBzTmKeyVl()));			// set [출수납거래참조번호]
		insertInput.setReqPgmId(StringUtils.nvl(input.getReqBzTmBean()));			// set [요청프로그램ID]
		insertInput.setReqMetdId(StringUtils.nvl(input.getReqBzTmMethod()));		// set [요청메서드ID]
		insertInput.setDelYn("N");													// set [삭제여부]
		insertInput.setNrmCnclDcd(RTCont.NRM_CNCL_DCD_NRM);						// set [정상취소구분코드]
//		insertInput.setLastChgDtm();												// set [최종변경일시]
		insertInput.setLastChgrId(FwUtil.getUserId());								// 최종변경자ID(LAST_CHGR_ID) 설정
		insertInput.setLastChgPgmId(FwUtil.getPgmId());								// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		insertInput.setLastChgTrmNo(FwUtil.getTrmNo());								// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		insertInput.setRltmTrsfPmpsNo(rltmTrsfPmpsNo);
		
		insertInput.setWtrsfAsntEvidDcd(input.getWtrsfAsntEvidDcd());

		SecuUtil.doEncObject(insertInput);
		logger.debug("☆☆☆☆☆☆☆ insertInput ===>{}", insertInput);
		iResult = this.cmb001dbio.insertOneTBCMRTM0010(insertInput);
		
		
		return iResult;
	}
	

	/**
	 * 리얼타임이체원장 업데이트(전송구분코드) : 미전송(0) => 전송(1)
	 * @param trmsDcd  전송구분코드(변경)
	 * @param rltmTrsfTxNo  리얼타임이체거래번호
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int updateTrmsDcd (String trmsDcd, String rltmTrsfTxNo) throws ApplicationException {
		
		int iResult = 0;
		TBCMRTM001Io inputVl = new TBCMRTM001Io();
		
		inputVl.setRltmTrmsDcd(trmsDcd);					// set [전송구분코드]
		inputVl.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
		inputVl.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
		inputVl.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
		inputVl.setRltmTrsfTxNo(rltmTrsfTxNo);				// set [리얼타임이체거래번호]
		
		iResult = this.cmb001dbio.updateOneTBCMRTM0010(inputVl);
		
		
		return iResult;
	}
	
	
	/**
	 * 리얼타임이체원장 업데이트(전송구분코드) : 전송(1) => 정상(2) or 오류(3)
	 * 									     즉시이체결과코드 외 3건
	 * @param realTmSetInfo  리얼타임이체원장정보
	 * @param rltmTrsfTxNo  리얼타임이체거래번호
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
    // 2013-10-24 : 자동이체 이체원장이 업데이트 되면 업무에서도 같이 
	// 프로그램 수행이 되어 request new을 막고 transation이 종료된후 받을수 있게 처리함. 
	// @TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int updateImtrsf (TBCMRTM001Io realTmSetInfo, String rltmTrsfTxNo) throws ApplicationException {
		
		int iResult = 0;
		TBCMRTM001Io inputVl = new TBCMRTM001Io();
		logger.debug("realTmSetInfo ==> {}",realTmSetInfo);
		logger.debug("rltmTrsfTxNo ==> {}",rltmTrsfTxNo);
		
		inputVl.setCmpyImtrsfRcd(StringUtils.nvl(realTmSetInfo.getCmpyImtrsfRcd()));				// set [엡체즉시이체결과코드]
		inputVl.setFininImtrsfRcd(StringUtils.nvl(realTmSetInfo.getFininImtrsfRcd()));				// set [금융기관즉시이체결과코드]
		inputVl.setBfCmpyImtrsfRcd(StringUtils.nvl(realTmSetInfo.getBfCmpyImtrsfRcd()));			// set [이전업체즉시이체결과코드]
		inputVl.setBfFininImtrsfRcd(StringUtils.nvl(realTmSetInfo.getBfFininImtrsfRcd()));			// set [이전금융기관즉시이체결과코드]
		inputVl.setRltmTrsfPmpsNo(StringUtils.nvl(realTmSetInfo.getRltmTrsfPmpsNo()));              // set [리얼타임이체납부자번호]

		if("0000".equals(StringUtils.nvl(realTmSetInfo.getFininImtrsfRcd())) || 
				"000".equals(StringUtils.nvl(realTmSetInfo.getFininImtrsfRcd())) ){
			inputVl.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
			inputVl.setFininImtrsfRcd("0000");	// set [전송구분코드 : 정상(TRMSDCD_2)]
		}else{
			// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
			inputVl.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
			
			if (StringUtils.nvl(realTmSetInfo.getFininImtrsfRcd()).length() == 3) {
				inputVl.setFininImtrsfRcd("0" + StringUtils.nvl(realTmSetInfo.getFininImtrsfRcd()));
			}
		}

		inputVl.setLastChgrId(FwUtil.getUserId());									// set [최종변경자ID]	
		inputVl.setLastChgPgmId(FwUtil.getPgmId());									// set [최종변경프로그램ID]
		inputVl.setLastChgTrmNo(FwUtil.getTrmNo());									// set [최종변경단말번호]
		inputVl.setRltmTrsfTxNo(rltmTrsfTxNo);										// set [리얼타임이체거래번호]
		
		if (!StringUtils.isEmpty(realTmSetInfo.getPropoDeptOrgNo())) {
			inputVl.setPropoDeptOrgNo(realTmSetInfo.getPropoDeptOrgNo());								// 발의부서
		}
		if (!StringUtils.isEmpty(realTmSetInfo.getMoActNo())) {			
			inputVl.setMoActNo(SecuUtil.getEncValue(realTmSetInfo.getMoActNo(), EncType.moActNo));				 //모계좌
		}
		
		
		// 예금주명이 있을경우
		if(!StringUtils.isEmpty(realTmSetInfo.getAchdNm())){
			inputVl.setAchdNm(realTmSetInfo.getAchdNm());
		}
		
		iResult = this.cmb001dbio.updateOneTBCMRTM0011(inputVl);
		
		
		return iResult;
	}
	
	/**
	 * 리얼타임전문로그 입력
	 * @param realTgmLog  리얼타임전문로그정보
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int insertTgmLog (TBCMRTM004Io realTgmLog) throws ApplicationException {
		
		int iResult = 0;
		TBCMRTM004Io inputVl = new TBCMRTM004Io();
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		String prcsHms		= "";					  // 처리시간
		
		prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		
		inputVl.setTgmLogTxNo(realTgmLog.getTgmLogTxNo());					// set [전문로그거래번호]
		inputVl.setLogPrcsDt(today);										// set [로그처리일자]
		inputVl.setLogPrcsTi(prcsHms);										// set [로그처리시각]
		inputVl.setTrsfPrcsFininCd(realTgmLog.getTrsfPrcsFininCd());		// set [이체처리금융기관코드]
		inputVl.setRltmTgmNo(realTgmLog.getRltmTgmNo());					// set [리얼타임전문번호]
		inputVl.setTgmCtnt(realTgmLog.getTgmCtnt());						// set [전문내용]
//		inputVl.setLastChgDtm(realTgmLog.getLastChgDtm());					// set [최종변경일시]
		inputVl.setLastChgrId(FwUtil.getUserId());							// set [최종변경자ID]
		inputVl.setLastChgPgmId(FwUtil.getPgmId());							// set [최종변경프로그램ID]
		inputVl.setLastChgTrmNo(FwUtil.getTrmNo());							// set [최종변경단말번호]
		
		iResult = this.cmb001dbio.insertOneTBCMRTM0040(inputVl);
		
		
		return iResult;
	}
	

	
	/**
	 * 모계좌 잔액조회 입력
	 * @param realTgmLog  리얼타임전문로그정보
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)

	public int insertmoActBamt (TBCMRTM011Io realmoAct, String flag) throws ApplicationException {
		
		int iResult = 0;
		TBCMRTM011Io inputVl = new TBCMRTM011Io();

		inputVl.setFininCd(realmoAct.getFininCd());			// set [은행코드]
		inputVl.setPrcsDtm(realmoAct.getPrcsDtm());			// set [이체처리일시]
		inputVl.setMoActNo(realmoAct.getMoActNo());			// set [모계좌번호]
		inputVl.setMoActBamt(realmoAct.getMoActBamt());		// set [리얼타임전문번호]
	
		inputVl.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
		inputVl.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
		inputVl.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
		
		iResult = this.cmb001dbio.insertOneTBCMRTM0110(inputVl);
		
		return iResult;
	}
	

	/**
	 * 복기부호처리
	 * @param OSTGMDATAVERFINFOIo  복기부호관련정보 (은행코드 bnkCd(2)는 호출하는 메소드에서 bnkCd(3)을 substring 하여 전달)
	 * @return String verfMrk  복기부호
	 * @throws ApplicationException
	 * @case 복기부호처리_03, 복기부호처리_05, 복기부호처리_23, 복기부호처리_11, 복기부호처리_20, 복기부호처리_71
	 */
	public String getTgmDataVerf (OSTGMDATAVERFINFOTESTIo input) throws ApplicationException {
		
		// 세팅될 return 값
		String verfMrk = "";					//복기부호
		
		// 필요String 변수값 세팅용
		String verf1 = "";						//복기1
		String verf2 = "";						//복기2
		String verf3 = "";						//복기3
		String verf4 = "";						//복기4
		String verf5 = "";						//복기5
		String verf6 = "";						//복기6
		String verfSum = "";					//복기SUM
		String strVerf = "";
		String strVerf3 = "";
		String strVerf4 = "";
		String[] strVerfRem = null;				//나눈나머지배열값
		String[] rtnVerfRem = null;				//리턴받을나눈나머지배열값
		
		// 필요Integer 변수값 세팅용
		int intVerf1 = 0;
		int intVerf2 = 0;
		int intVerf3 = 0;
		int intVerf4 = 0;
		int intVerf5 = 0;
		int intVerf6 = 0;
		int intVerf7 = 0;
		int intVerf = 0;
		int intVerfSum = 0;
		int intVerfQuot = 0;					//나눈몫
		int intVerfRem = 0;						//나눈나머지
		int inputValue = 0;
		int intVerft1 = 0;
		int intVerft2 = 0;
		int intVerft3 = 0;
		int intVerft4 = 0;
		int intVerft5 = 0;
		int intVerft6 = 0;
		// 필요BigDecimal 변수값 세팅용
		BigDecimal bdcVerf1 = BigDecimal.ZERO;
		
		BigDecimal bdcVerf2 = BigDecimal.ZERO;
		BigDecimal bdcVerf3 = BigDecimal.ZERO;
		BigDecimal bdcVerf = BigDecimal.ZERO;
		
		BigDecimal zero = BigDecimal.ZERO;
		
		String wdmActNo 	= input.getWdmActNo();		//출금계좌번호
		String dpsActNo 	= input.getDpsActNo();		//입금계좌번호
		BigDecimal wdmAmt 	= input.getWdmAmt() == null ? zero : input.getWdmAmt();			//출금금액
		String trmsDt 		= input.getTrmsDt();		//전송일자
		BigDecimal trmsAmt 	= input.getTrmsAmt() == null ? zero : input.getTrmsAmt();		//전송금액
		BigDecimal trsfAmt 	= input.getTrsfAmt() == null ? zero : input.getTrsfAmt();		//이체금액
		String trsfDtm 		= input.getTrsfDtm();		//이체일시
		String tgmNo 		= input.getTgmNo();			//전문번호
		String dpsBnkCd 	= input.getDpsBnkCd();		//입금은행코드
		String inputDt 		= input.getInputDt();		//입력일자
		String trmsHms 		= input.getTrmsHms();		//전송시간
		String inputHms 	= input.getInputHms();		//입력시간
		BigDecimal dpsAmt	= input.getDpsAmt();		//입금금액
		String objBnkCd 	= input.getObjBnkCd();		//대상은행코드(우리은행 복기부호구성값) [T1409260036]
		
		logger.debug("========================== getTgmDataVerf(복기부호처리) START ============================");
		logger.debug("wdmActNo={}",wdmActNo);
		logger.debug("dpsActNo={}",dpsActNo);
		logger.debug("wdmAmt={}",wdmAmt);
		logger.debug("trmsDt={}",trmsDt);
		logger.debug("trmsAmt={}",trmsAmt);
		logger.debug("trsfAmt={}",trsfAmt);
		logger.debug("trsfDtm={}",trsfDtm);
		logger.debug("tgmNo={}",tgmNo);
		logger.debug("dpsBnkCd={}",dpsBnkCd);
		logger.debug("inputDt={}",inputDt);
		logger.debug("trmsHms={}",trmsHms);
		logger.debug("inputHms={}",inputHms);
		logger.debug("dpsAmt={}",dpsAmt);
		logger.debug("objBnkCd={}",objBnkCd);
		logger.debug("========================== getTgmDataVerf(복기부호처리) END ============================");
		
		Date toDay = FwUtil.getSystemDate();
		
		String prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		
		String todayHms = toDay.toString() + prcsHms;
		
		logger.debug("todayHms={}",todayHms);
		
		if(RTCont.BNKCD_05.equals(dpsBnkCd)){
			
			//전송일자
			trmsDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			
			// 필수입력값체크
			if (StringUtils.isEmpty(wdmActNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "출금계좌번호", "출금계좌번호" });
			} 

			if (StringUtils.isEmpty(dpsActNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "입금계좌번호", "입금계좌번호" });
			} 

			if (trmsAmt.compareTo(zero) == 0) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "전송금액", "전송금액" });
			} 

			if (StringUtils.isEmpty(trmsDt)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "전송일자", "전송일자" });
			}
			
			logger.debug("복기부호처리_05'swdmActNo111111111111={}",wdmActNo.substring(0,11));
			logger.debug("복기부호처리_05's dpsActNo={}",dpsActNo.substring(0, 11));
			
			bdcVerf1 = new BigDecimal(wdmActNo.substring(0, 11)).add(new BigDecimal(dpsActNo.substring(0, 11)));
			logger.debug("복기부호처리_05's bdcVerf1={}",bdcVerf1);
			
			bdcVerf2 = new BigDecimal(trmsDt.substring(2, 4))
					   .add(new BigDecimal(trmsDt.substring(4, 6))
					   .add(new BigDecimal(trmsDt.substring(6, 8))));
			
			logger.debug("복기부호처리_05's bdcVerf2={}",bdcVerf2);
			logger.debug("복기부호처리_05's trmsAmt={}",trmsAmt);
			
			bdcVerf3 = bdcVerf1.add(trmsAmt).add(new BigDecimal(trmsDt.substring(2, 8)));
			logger.debug("복기부호처리_05's bdcVerf3={}",bdcVerf3);
			
			//복기자료
			bdcVerf = bdcVerf3.divide(bdcVerf2, 0, BigDecimal.ROUND_DOWN);
			logger.debug("복기부호처리_05's bdcVerf={}",bdcVerf);
			
			strVerf = StringUtils.lpad("", 13 - bdcVerf.toString().length(), "0").concat(bdcVerf.toString());
			logger.debug("복기부호처리_05's strVerf={}",strVerf);
			
			verfMrk = strVerf.substring(9, 13);
			logger.debug("복기부호처리_05's verfMrk={}",verfMrk);
			
			
		// 입금은행코드가 SC제일은행(23) 일 경우 '복기부호처리_23'
		}else if(RTCont.BNKCD_23.equals(dpsBnkCd)){
			
			//전송일자
			trmsDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			//이체시각
		  	trsfDtm = todayHms;
			
			// TEST data 세팅
		/*	wdmActNo = "86010054929";
			trsfAmt = new BigDecimal(19660);
			trsfDtm = "184804";
			trmsDt = "20130812";
			tgmNo="0800022" ;*/
		  	
			if("01".equals(input.getPrcsCd())){            //출금이체
				wdmActNo = dpsActNo ;
			}
			
			// 필수입력값체크
			if (StringUtils.isEmpty(wdmActNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "출금계좌번호", "출금계좌번호" });
			} 

			if (trsfAmt.compareTo(zero) == 0) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "이체금액" , "이체금액" });
			} 

			if (StringUtils.isEmpty(trsfDtm)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "이체일시", "이체일시" });
			}
			
			if (StringUtils.isEmpty(trmsDt)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "전송일자", "전송일자" });
			} 		
			
			logger.debug("복기부호처리_23's 출금계좌 wdmActNo={}",wdmActNo);
			logger.debug("복기부호처리_23's 이체금액 trsfAmt={}",trsfAmt);
			logger.debug("복기부호처리_23's 이체시각 trsfDtm={}",trsfDtm);
			logger.debug("복기부호처리_23's 이체월일 trmsDt={}",trmsDt);
			logger.debug("복기부호처리_23's 전문번호 tgmNo={}",tgmNo);
			
			wdmActNo = wdmActNo + StringUtils.lpad("", 15 - wdmActNo.length(), "0") ;
			wdmActNo = wdmActNo.substring(0, 10) ;
			
			logger.debug("복기부호처리_23's 출금계좌 wdmActNo 10자리로 자름={}",wdmActNo);
			
			bdcVerf1 = new BigDecimal(wdmActNo).add(trsfAmt).add(new BigDecimal(trsfDtm));			
			
			logger.debug("복기부호처리_23's bdcVerf1={}",bdcVerf1);
			
			
			String bdcVerf11 = StringUtils.lpad("", 13 - bdcVerf1.toString().length(), "0") + bdcVerf1.toString();
			
			logger.debug("복기부호처리_23's bdcVerf1_1={}",bdcVerf11);
						 
				
			logger.debug("복기부호처리_23's bdcVerf1_1(1)={}", new BigDecimal(bdcVerf11.substring(0, 1)).multiply(BigDecimal.valueOf(61)));
			logger.debug("복기부호처리_23's bdcVerf1_1(2)={}", new BigDecimal(bdcVerf11.substring(1, 2)).multiply(BigDecimal.valueOf(53)));
			logger.debug("복기부호처리_23's bdcVerf1_1(3)={}", new BigDecimal(bdcVerf11.substring(2, 3)).multiply(BigDecimal.valueOf(51)));
			logger.debug("복기부호처리_23's bdcVerf1_1(4)={}", new BigDecimal(bdcVerf11.substring(3, 4)).multiply(BigDecimal.valueOf(49)));
			logger.debug("복기부호처리_23's bdcVerf1_1(5)={}", new BigDecimal(bdcVerf11.substring(4, 5)).multiply(BigDecimal.valueOf(47)));
			logger.debug("복기부호처리_23's bdcVerf1_1(6)={}", new BigDecimal(bdcVerf11.substring(5, 6)).multiply(BigDecimal.valueOf(43)));
			logger.debug("복기부호처리_23's bdcVerf1_1(7)={}", new BigDecimal(bdcVerf11.substring(6, 7)).multiply(BigDecimal.valueOf(41)));
			logger.debug("복기부호처리_23's bdcVerf1_1(8)={}", new BigDecimal(bdcVerf11.substring(7, 8)).multiply(BigDecimal.valueOf(37)));
			logger.debug("복기부호처리_23's bdcVerf1_1(9)={}", new BigDecimal(bdcVerf11.substring(8, 9)).multiply(BigDecimal.valueOf(31)));
			logger.debug("복기부호처리_23's bdcVerf1_1(10)={}", new BigDecimal(bdcVerf11.substring(9, 10)).multiply(BigDecimal.valueOf(29)));
			logger.debug("복기부호처리_23's bdcVerf1_1(11)={}", new BigDecimal(bdcVerf11.substring(10, 11)).multiply(BigDecimal.valueOf(23)));
			logger.debug("복기부호처리_23's bdcVerf1_1(12)={}", new BigDecimal(bdcVerf11.substring(11, 12)).multiply(BigDecimal.valueOf(19)));
			logger.debug("복기부호처리_23's bdcVerf1_1(13)={}", new BigDecimal(bdcVerf11.substring(12, 13)).multiply(BigDecimal.valueOf(17)));
			
			 bdcVerf2 = new BigDecimal(bdcVerf11.substring(0, 1)).multiply(BigDecimal.valueOf(61))
					 	.add(new BigDecimal(bdcVerf11.substring(1, 2)).multiply(BigDecimal.valueOf(53)))
					 	.add(new BigDecimal(bdcVerf11.substring(2, 3)).multiply(BigDecimal.valueOf(51)))
					 	.add(new BigDecimal(bdcVerf11.substring(3, 4)).multiply(BigDecimal.valueOf(49)))
					 	.add(new BigDecimal(bdcVerf11.substring(4, 5)).multiply(BigDecimal.valueOf(47)))
					 	.add(new BigDecimal(bdcVerf11.substring(5, 6)).multiply(BigDecimal.valueOf(43)))
					 	.add(new BigDecimal(bdcVerf11.substring(6, 7)).multiply(BigDecimal.valueOf(41)))
					 	.add(new BigDecimal(bdcVerf11.substring(7, 8)).multiply(BigDecimal.valueOf(37)))
					 	.add(new BigDecimal(bdcVerf11.substring(8, 9)).multiply(BigDecimal.valueOf(31)))
					 	.add(new BigDecimal(bdcVerf11.substring(9, 10)).multiply(BigDecimal.valueOf(29)))
					 	.add(new BigDecimal(bdcVerf11.substring(10, 11)).multiply(BigDecimal.valueOf(23)))
					 	.add(new BigDecimal(bdcVerf11.substring(11, 12)).multiply(BigDecimal.valueOf(19)))
					 	.add(new BigDecimal(bdcVerf11.substring(12, 13)).multiply(BigDecimal.valueOf(17)));
			 
			logger.debug("복기부호처리_23's bdcVerf2(1)={}",bdcVerf2);
			
			logger.debug("복기부호처리_23's tgmNo={}",tgmNo);
			
			bdcVerf2 = bdcVerf2.add(new BigDecimal(tgmNo));
			logger.debug("복기부호처리_23's bdcVerf2(2)={}",bdcVerf2);
			
			bdcVerf2 = new BigDecimal(Integer.parseInt(bdcVerf2.toString()) % 13);
			
			logger.debug("복기부호처리_23's bdcVerf2(3)={}",bdcVerf2);
			
			logger.debug("복기부호처리_23's trmsDt.substring(6, 8)={}",trmsDt.substring(6, 8));
		//	bdcVerf2 = bdcVerf2.multiply(new BigDecimal(trmsDt.substring(4, 6)));
			bdcVerf2 = bdcVerf2.multiply(new BigDecimal(trmsDt.substring(6, 8)));
			logger.debug("복기부호처리_23's bdcVerf2(4)={}",bdcVerf2);			
			
			// 최종복기자료
			intVerf = Integer.parseInt(bdcVerf2.toString()) % 30;
			logger.debug("복기부호처리_23's intVerf={}",intVerf);
			
			String mode = LApplicationContext.getSystemMode();
			
			// 최종복기자료를 30개의 safeCard를 대입하여 복기부호를 가져온다.  
			logger.debug("복기부호처리_23's processCd={}",input.getPrcsCd());
			if("R".equals(mode)) {  
				if("01".equals(input.getPrcsCd())){            //출금이체
					 verfMrk = RTCont.SAFECARD_In[intVerf];
				}else{			
				     verfMrk = RTCont.SAFECARD[intVerf];
				}
			} else if("D".equals(mode) || "T".equals(mode)) {
				
				verfMrk = RTCont.SAFECARD_In_T[intVerf];
			}
			
			logger.debug("복기부호처리_23's verfMrk={}",verfMrk);
			
			
		// 입금은행코드가 농협(11) 일 경우 '복기부호처리_11'
		}else if(RTCont.BNKCD_11.equals(dpsBnkCd)){
			
			//전송일자
			trmsDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			
			// 필수입력값체크
			if (StringUtils.isEmpty(wdmActNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "출금계좌번호", "출금계좌번호" });
			}

			if (StringUtils.isEmpty(trmsDt)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "전송일자", "전송일자" });
			}
			
			if (trsfAmt.compareTo(zero) == 0) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "이체금액", "이체금액" });
			}
			
			// 최종복기자료
			bdcVerf1 = (new BigDecimal(wdmActNo)
							.add(new BigDecimal(trmsDt))
							.add(new BigDecimal(11))
							.add(trsfAmt))
					   .divide(new BigDecimal(880058), 0, BigDecimal.ROUND_DOWN);
			
			logger.debug("복기부호처리_11's bdcVerf1={}",bdcVerf1);
			
			verfMrk = StringUtils.lpad("", 15 - bdcVerf1.toString().length(), "0") + bdcVerf1.toString();
			logger.debug("복기부호처리_11's verfMrk1={}",verfMrk);
			
			verfMrk = verfMrk.substring(9, 15);
			logger.debug("복기부호처리_11's verfMrk2={}",verfMrk);
		
		// 입금은행코드가 단위농협(12) 일 경우 '복기부호처리_12'
		}else if(RTCont.BNKCD_12.equals(dpsBnkCd)){
						
			//전송일자
			trmsDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			
			// 필수입력값체크
			if (StringUtils.isEmpty(wdmActNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "출금계좌번호", "출금계좌번호" });
			}

			if (StringUtils.isEmpty(trmsDt)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "전송일자", "전송일자" });
			}
			
			if (trsfAmt.compareTo(zero) == 0) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "이체금액", "이체금액" });
			}
			
			logger.debug("복기부호처리_12's wdmActNo={}",wdmActNo);
			logger.debug("복기부호처리_12's trmsDt={}",trmsDt);
			logger.debug("복기부호처리_12's trsfAmt={}",trsfAmt);
			
			// 최종복기자료
			bdcVerf1 = (new BigDecimal(wdmActNo)
							.add(new BigDecimal(trmsDt))
							.add(new BigDecimal(12))
							.add(trsfAmt))
					   .divide(new BigDecimal(880058), 0, BigDecimal.ROUND_DOWN);
			
			logger.debug("복기부호처리_12's bdcVerf1={}",bdcVerf1);
			
			verfMrk = StringUtils.lpad("", 15 - bdcVerf1.toString().length(), "0") + bdcVerf1.toString();
			logger.debug("복기부호처리_12's verfMrk1={}",verfMrk);
			
			verfMrk = verfMrk.substring(9, 15);
			logger.debug("복기부호처리_12's verfMrk2={}",verfMrk);
							
		// 입금은행코드가 우리은행(20) 일 경우 '복기부호처리_20'
		}else if(RTCont.BNKCD_20.equals(dpsBnkCd)){
			
			//전송일자
			trmsDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			
			// 필수입력값체크
			if (StringUtils.isEmpty(trmsDt)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "전송일자", "전송일자" });
			}
			
			if (StringUtils.isEmpty(dpsActNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "입금계좌번호", "입금계좌번호" });
			}
			
			if (dpsAmt.compareTo(zero) == 0) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "입금금액" , "입금금액" });
			}
			
			if (StringUtils.isEmpty(dpsBnkCd)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "입금은행코드", "입금은행코드" });
			}

			if (StringUtils.isEmpty(wdmActNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "출금계좌번호", "출금계좌번호" });
			}
			
			if (trsfAmt.compareTo(zero) == 0) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "이체금액", "이체금액" });
			}

			if (StringUtils.isEmpty(objBnkCd)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{"대상은행코드", "대상은행코드" });
			}

			if (dpsActNo.length() > 14)	{							//[T1409260036] 입금계좌번호 복기부호기준 길이조정	
				dpsActNo = dpsActNo.substring(0, 14);
				logger.debug("## dpsActNo.substring={}",dpsActNo);
			}
			if (wdmActNo.length() > 14)	{							//[T1409260036] 출금계좌번호 복기부호기준 길이조정
				wdmActNo = wdmActNo.substring(0, 14);
				logger.debug("## wdmActNo.substring={}",wdmActNo);
			}
			verfSum = trmsDt.substring(2, 8)
//					+ (dpsActNo + StringUtils.lpad("", 15 - dpsActNo.length(), "0"))
					+ (dpsActNo + StringUtils.lpad("", 14 - dpsActNo.length(), "0"))	//[T1409260036] 입금계좌번호
					+ (StringUtils.lpad("", 13 - dpsAmt.toString().length(), "0") + dpsAmt.toString())
//					+ dpsBnkCd
					+ objBnkCd			//[T1409260036] 입출금 대상은행코드
//					+ (wdmActNo + StringUtils.lpad("", 15 - wdmActNo.length(), "0"));
					+ (wdmActNo + StringUtils.lpad("", 14 - wdmActNo.length(), "0"));	//[T1409260036] 출금계좌번호
			
			logger.debug("복기부호처리_20's verfSum={}",verfSum);
			logger.debug("복기부호처리_20's verfSum.length()={}",verfSum.length());
			
			//if(verfSum.length() != 51){
			if(verfSum.length() != 50){
				// 에러코드 : 입금은행코드가 우리은행(20) 일 경우 '복기부호처리_20' 처리시 복기SUM(verfSum(51)) 자릿수가 맞지않는 오류
				// '유효하지않은 자릿수입니다. 확인해주세요.'
				throw new ApplicationException("APPAE0053", null);
			}
			
			// 복기CHAR 51자리 모두 더한다.
			for(int i=0; i < verfSum.length(); i++){
				intVerfSum = intVerfSum + Integer.parseInt(verfSum.substring(i, i+1));
			}
			
			logger.debug("복기부호처리_20's intVerfSum={}",intVerfSum);
			
			// 이체금액을 복기SUM(intVerfSum)으로 나눈 나머지
			intVerfRem = trsfAmt.intValue() % intVerfSum;
			logger.debug("복기부호처리_20's intVerfRem={}",intVerfRem);
			
			verfMrk = StringUtils.lpad("", 3 - Integer.toString(intVerfSum).length(), "0")
					+ Integer.toString(intVerfSum) 
					+ StringUtils.lpad("", 3 - Integer.toString(intVerfRem).length(), "0") 
					+ Integer.toString(intVerfRem);
			
			logger.debug("복기부호처리_20's verfMrk={}",verfMrk);
			
		// 입금은행코드가 우체국(71) 일 경우 '복기부호처리_71'
		}else if(RTCont.BNKCD_71.equals(dpsBnkCd)){
			strVerfRem = new String[7];
			rtnVerfRem = new String[7];
			
			//전송일자
			trmsDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			
			// 필수입력값체크
			if (StringUtils.isEmpty(trmsDt)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "전송일자", "전송일자" });
			}
			
			if (StringUtils.isEmpty(trmsHms)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "전송시간", "전송시간" });
			}
			
			if (StringUtils.isEmpty(wdmActNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ "출금계좌번호", "출금계좌번호" });
			}
		
			//wdmActNo   = "01338302084937";
			//wdmActNo     = "01344102130643";
			//trmsHms  = "195957";
			inputDt  = trmsDt.substring(0, 7);		//입력일자
			inputHms = trmsDt.substring(7, 8).concat(trmsHms.substring(0, 6));	//입력시간
			wdmActNo = wdmActNo.length() == 15 ? wdmActNo : wdmActNo.concat(StringUtils.lpad("", 15 - wdmActNo.length(), "0"));
			
			logger.debug("복기부호처리_71's inputDtTEST={}",inputDt);
			logger.debug("복기부호처리_71's inputHms={}",inputHms); 
			logger.debug("복기부호처리_71's wdmActNo={}",wdmActNo);
			logger.debug("복기부호처리_71's wdmActNo.length()={}",wdmActNo.length());
			
			logger.debug("복기부호처리_71's wdmActNo.substring(0, 7)={}",wdmActNo.substring(0, 7));
			logger.debug("복기부호처리_71's wdmActNo.substring(7, 14)={}",wdmActNo.substring(7, 14));
			
			String  strVerf1 = "";
			String  strVerf2 = "";
			
			intVerf1 = Integer.parseInt(inputHms) + Integer.parseInt(wdmActNo.substring(0, 7));
			intVerf2 = Integer.parseInt(inputDt)  + Integer.parseInt(wdmActNo.substring(7, 14));

			logger.debug("복기부호처리_71's intVerf1={}",intVerf1);
			logger.debug("복기부호처리_71's intVerf2={}",intVerf2);
			//2013-09-30
			strVerf1 = Integer.toString(intVerf1); 
			strVerf2 = Integer.toString(intVerf2); 
			
			strVerf1 = StringUtils.lpad(Integer.toString(intVerf1), 8, "0"); 
			strVerf2 = StringUtils.lpad(Integer.toString(intVerf2), 8, "0"); 

			logger.debug("복기부호처리_71's strVerf1={}",strVerf1);
			logger.debug("복기부호처리_71's strVerf2={}",strVerf2);
			//2013-09-30 end
			// 복기자료(1:8) reverse
			//2013.09.30  start
//			for(int i= Integer.toString(intVerf1).length() ; i > 0 ; i--){
//				logger.debug("복기부호처리_71's {}번째 strVerf3={}", i,Integer.toString(intVerf1).substring(i-1, i));
//				strVerf3 = strVerf3 + Integer.toString(intVerf1).substring(i-1, i); 
//			}
//			
//			for(int i= Integer.toString(intVerf2).length() ; i > 0 ; i--){
//				logger.debug("복기부호처리_71's {}번째 strVerf4={}", i,Integer.toString(intVerf1).substring(i-1, i));
//				strVerf4 = strVerf4 + Integer.toString(intVerf2).substring(i-1, i); 
//			}
			//
			
			for(int i= strVerf1.length() ; i > 0 ; i--){
				logger.debug("복기부호처리_71's {}번째 strVerf3={}", i,strVerf1.substring(i-1, i));
				strVerf3 = strVerf3 + strVerf1.substring(i-1, i); 
			}
			
			for(int i= strVerf2.length() ; i > 0 ; i--){
				logger.debug("복기부호처리_71's {}번째 strVerf4={}", i,strVerf2.substring(i-1, i));
				strVerf4 = strVerf4 + strVerf2.substring(i-1, i); 
			}
			
			logger.debug("복기부호처리_71's re1 strVerf3={}",strVerf3);
			logger.debug("복기부호처리_71's re2 strVerf4={}",strVerf4);
			
			strVerf3 =  StringUtils.lpad(strVerf3.substring(0,7), 8, "0");
			strVerf4 =  StringUtils.lpad(strVerf4.substring(0,7), 8, "0");
			// 2013-09-30 end
			
			/*for(int i=8; i > 0; i--){
				logger.debug("복기부호처리_71's {}번째 strVerf3={}", i,Integer.toString(intVerf1).substring(i-1, i));
				logger.debug("복기부호처리_71's {}번째 strVerf4={}", i,Integer.toString(intVerf2).substring(i-1, i));
				
				strVerf3 = strVerf3 + Integer.toString(intVerf1).substring(i-1, i);
				strVerf4 = strVerf4 + Integer.toString(intVerf2).substring(i-1, i);
			}*/
			
			logger.debug("복기부호처리_71's strVerf3={}",strVerf3);
			logger.debug("복기부호처리_71's strVerf4={}",strVerf4);
			//old
//			intVerf5 = intVerf2 + Integer.parseInt(strVerf3.substring(0,7));
//			intVerf6 = intVerf1 + Integer.parseInt(strVerf4.substring(0,7));
			//new
			intVerf5 = intVerf2 + Integer.parseInt(strVerf3);
			intVerf6 = intVerf1 + Integer.parseInt(strVerf4);
			intVerf7 = intVerf5 + intVerf6;
			inputValue = intVerf7;
			
			logger.debug("복기부호처리_71's intVerf5={}",intVerf5);
			logger.debug("복기부호처리_71's intVerf6={}",intVerf6);
			logger.debug("복기부호처리_71's intVerf7={}",intVerf7);
			logger.debug("복기부호처리_71's inputValue={}",inputValue);
			
			int j = 0;
			int h = 0;
			
			for(int i=0; i < 7; i++){
				intVerfQuot = new BigDecimal(inputValue).divide(new BigDecimal(16), 0, BigDecimal.ROUND_DOWN).intValue();
				intVerfRem = inputValue % 16;
				
				logger.debug("복기부호처리_71's {}번째 inputValue={}", i,inputValue);
				logger.debug("복기부호처리_71's {}번째 intVerfQuot={}", i,intVerfQuot);   //몫
				logger.debug("복기부호처리_71's {}번째 intVerfRem={}", i,intVerfRem);    // 나머지
				
				// 입력값을 16으로 나눈 몫이 15보다 크면 입력값에 몫대입
				if(intVerfQuot > 15){
					inputValue = intVerfQuot;
					strVerfRem[i] = Integer.toString(intVerfRem);
					logger.debug("복기부호처리_71's {}번째 strVerfRem 변경전={}", i,strVerfRem[i]);
					j++;
					
				// 입력값을 16으로 나눈 몫이 15보다 작으면 입력값에 나머지대입, 몫대입(연속적)
				}else{
					strVerfRem[i] = Integer.toString(intVerfRem);
					i++;
					j++;
					strVerfRem[i] = Integer.toString(intVerfQuot);
					j++;
					i=10;
				}
			}
			
			if(strVerfRem[6]== null) {
				strVerfRem[6] = "0" ;
				j = j + 1;
			}
			logger.debug("strVerfRem6={}", strVerfRem[6]);
			logger.debug("strVerfRem5={}", strVerfRem[5]);
			logger.debug("strVerfRem4={}", strVerfRem[4]);
			logger.debug("strVerfRem3={}", strVerfRem[3]);
			logger.debug("strVerfRem2={}", strVerfRem[2]);
			logger.debug("strVerfRem1={}", strVerfRem[1]);
			logger.debug("strVerfRem0={}", strVerfRem[0]);
			
			logger.debug("복기부호처리_71's j88={}",j);
			
			// reverse 이후 복기부호값 도출
			for(int k=j-1; k >= 0; k--){
				logger.debug("strVerfRem[k]={}", strVerfRem[k]);
				rtnVerfRem[h] = strVerfRem[k];
				
				logger.debug("복기부호처리_71's rtnVerfRem[{}번째]={}", h,rtnVerfRem[h]);
				
				if(h == 0){
					verfMrk = verfMrk + RTCont.ARRAYHEX_1[Integer.parseInt(rtnVerfRem[h])];
				}else if(h == 1){
					verfMrk = verfMrk + RTCont.ARRAYHEX_2[Integer.parseInt(rtnVerfRem[h])];
				}else if(h == 2){
					verfMrk = verfMrk + RTCont.ARRAYHEX_3[Integer.parseInt(rtnVerfRem[h])];
				}else if(h == 3){
					verfMrk = verfMrk + RTCont.ARRAYHEX_4[Integer.parseInt(rtnVerfRem[h])];
				}else if(h == 4){
					verfMrk = verfMrk + RTCont.ARRAYHEX_5[Integer.parseInt(rtnVerfRem[h])];
				}else if(h == 5){
					verfMrk = verfMrk + RTCont.ARRAYHEX_6[Integer.parseInt(rtnVerfRem[h])];
				}else if(h == 6){
					verfMrk = verfMrk + RTCont.ARRAYHEX_7[Integer.parseInt(rtnVerfRem[h])];
				}
				
				logger.debug("복기부호처리_71's {}번째 verfMrk={}", h,verfMrk);
				
				h++;
			}
		
		 logger.debug("verfMrk ={} and verfMak.length() = {}", verfMrk , verfMrk.length());	
		 
			 if(verfMrk.length() == 7 ){ 
				verfMrk = verfMrk.substring(1,7);
			 }
		 
			
		}
		
		
		logger.debug("복기부호처리_71's 마지막 verfMrk={}", verfMrk);
		
		return verfMrk;
	}
	

	/**
	 * 
	 * 복기부호 변경
	 * 
	 * @param argChgFlag       변경할 문자
	 * @return String         변경된값
	 * 
	 * @throws ApplicationException
	 */
	public String setHexString(String argChgFlag) throws ApplicationException {
		
		logger.debug("CMB001BEAN.setHexString 변경 전===============argChgFlag={}" , argChgFlag );
		
		String wkChgFlag ="";
		
		wkChgFlag = RTCont.ARRAYHEX_0[Integer.parseInt(argChgFlag)];
		
		logger.debug("CMB001BEAN.setHexString 변경 후===============argChgFlag ={}" , wkChgFlag );
		
		return wkChgFlag;
	}
	

	/**
	 * 입금인성명 조회
	 * @param chnlDcd  채널구분코드
	 * @return dpsIndNm  입금인성명 
	 * @throws ApplicationException
	 */
	public String getDpsIndNm (String chnlDcd) throws ApplicationException {
		
		String dpsIndNm = "라이나생명";
		
		return dpsIndNm;
	}
	

	/**
	 * TrsfTrrvPrcsInfo(이체송수신처리정보) 세팅용메소드 (OMM ==> DO) - 각 업무파트 전문수행이후 응답용
	 * @param realTmInfo  리얼타임이체원장 OMM (수신이후)
	 * @return TrsfTrrvPrcsInfo  각 업무파트별 전문수신이후 응답용 DO 
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setPrcsInfo(TBCMRTM001Io realTmInfo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo prcsInfo = new TrsfTrrvPrcsInfo();
		
		prcsInfo.setPrcsCd(realTmInfo.getRltmBzDcd());// set [처리코드]
		prcsInfo.setChnlDcd(realTmInfo.getPyprcCd());// set [채널구분코드]
		prcsInfo.setPrcsDt(realTmInfo.getTrsfDt());// set [처리일자]
		prcsInfo.setPayRcPathCd(realTmInfo.getPayRcPathCd());// set [지급접수경로코드]
		prcsInfo.setPayRcMcd(realTmInfo.getPayRcMcd());// set [지급접수방법코드]
		prcsInfo.setPyprcPathCd(realTmInfo.getPyprcPathCd());// set [지급처리경로코드]
		prcsInfo.setTrsfAmt(realTmInfo.getTrsfAmt());// set [이체금액]
		prcsInfo.setBenfcCustNo(realTmInfo.getBenfcCustNo());// set [수익자고객번호]
		prcsInfo.setContrCustNo(realTmInfo.getContrCustNo());// set [계약자고객번호]
		prcsInfo.setDpwdDcd(realTmInfo.getDpwdDcd());// set [입출금구분코드]
		prcsInfo.setActMgntNo(realTmInfo.getRfActMgntNo());// set [계좌관리번호] - 참조계좌관리번호

		prcsInfo.setActNo(realTmInfo.getActNo());// set [계좌번호]
		prcsInfo.setAchdNm(realTmInfo.getAchdNm());// set [예금주명]
		prcsInfo.setAchdRrno(realTmInfo.getAchdRrno());// set [예금주주민등록번호]
		prcsInfo.setNrmCnclDcd(realTmInfo.getNrmCnclDcd());// set [정상취소구분코드]
		prcsInfo.setBzDcd(realTmInfo.getPyrcTxRfNoDcd());// set [업무구분코드] - 출수납거래참조번호구분코드
		prcsInfo.setBzTmKeyVl(realTmInfo.getPyrcTxRfNo());// set [업무팀KEY값] - 출수납거래참조번호
		prcsInfo.setReqBzTmBean(realTmInfo.getReqPgmId());// set [요청파트BEAN] - 요청프로그램ID
		prcsInfo.setReqBzTmMethod(realTmInfo.getReqMetdId());// set [요청파트Method] - 요청메서드ID
		
		prcsInfo.setTrmsDcd(realTmInfo.getRltmTrmsDcd());// set [전송구분코드]
	//	prcsInfo.setBnkAnswCd(realTmInfo.getKsnetImmdtTrsfRcd());// set [은행응답코드] - 업체즉시이체결과코드
		prcsInfo.setBnkAnswCd(realTmInfo.getFininImtrsfRcd());// set [은행응답코드] - 은행 즉시이체결과코드
	
		prcsInfo.setPrcsHms(realTmInfo.getTrsfPrcsTi());// set [처리시간] - 이체처리시각
		prcsInfo.setRltmTrsfTxNo(realTmInfo.getRltmTrsfTxNo());// set [리얼타임이체거래번호]
		
		// 처리코드가 (02) 자동집금처리 호출(입금,집금) 일 경우
		if(RTCont.PRCSCD_02.equals(realTmInfo.getRltmBzDcd())){
			prcsInfo.setPrcsBnkCd(realTmInfo.getTrsfObjFininCd());// set [처리은행코드] - 이체대상금융기관코드
			prcsInfo.setBnkCd(realTmInfo.getTrsfPrcsFininCd());// set [은행코드] - 이체처리금융기관코드
			
		}else{
			prcsInfo.setPrcsBnkCd(realTmInfo.getTrsfPrcsFininCd());// set [처리은행코드] - 이체대상금융기관코드
			prcsInfo.setBnkCd(realTmInfo.getTrsfObjFininCd());// set [은행코드] - 이체처리금융기관코드			
		}
		
		
		return prcsInfo;
	}
	

	/**
	 * 리얼타임착오전문 입력
	 * @param realTmInfo	리얼타임이체원장
	 * @param tgmCont	전문내용
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int insertErTgm (TBCMRTM001Io realTmInfo, int mstkTgmSeq, String tgmCont) throws ApplicationException {
		
		int iResult = 0;
		TBCMRTM003Io inputVl = new TBCMRTM003Io();
		
		String todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

		inputVl.setRltmTgmNo(realTmInfo.getRltmTgmNo());					// set [리얼타임전문번호]
		inputVl.setMstkTgmSeq(mstkTgmSeq);									// set [착오전문순번]
		inputVl.setTrsfMstkDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [이체착오일자]
		inputVl.setRltmTrsfTxNo(realTmInfo.getRltmTrsfTxNo());				// set [리얼타임이체거래번호]
		inputVl.setMstkTgmPrcsDofOrgNo(FwUtil.getDeptCd());					// set [착오전문처리지점조직번호]
		inputVl.setMstkTgmPrcsFofOrgNo(FwUtil.getDeptCd());					// set [착오전문처리영업소조직번호]
		inputVl.setMstkTgmPrcsTi(todayHms);									// set [착오전문처리시각]
		inputVl.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드]
		inputVl.setMstkTpcd(realTmInfo.getCmpyImtrsfRcd());					// set [착오유형코드] - 응답코드
		inputVl.setMstkStaVrfcYn("Y");										// set [착오상태확인여부]
		inputVl.setFininCd(realTmInfo.getTrsfObjFininCd());					// set [금융기관코드]
		inputVl.setActNo(realTmInfo.getActNo());							// set [계좌번호]
		inputVl.setDpwdDcd(realTmInfo.getDpwdDcd());						// set [입출금구분코드]
		inputVl.setRltmPrcsAmt(realTmInfo.getTrsfAmt());					// set [리얼타임처리금액]
		inputVl.setTgmCtnt(tgmCont);										// set [전문내용]
		//inputVl.setLastChgDtm();											// set [최종변경일시]
		inputVl.setLastChgrId(FwUtil.getUserId());							// set [최종변경자ID]
		inputVl.setLastChgPgmId(FwUtil.getPgmId());							// set [최종변경프로그램ID]
		inputVl.setLastChgTrmNo(FwUtil.getTrmNo());							// set [최종변경단말번호]
		
		SecuUtil.doEncObject(inputVl);
		iResult = this.cmb001dbio.insertOneTBCMRTM0030(inputVl);
		
		
		return iResult;
	}
	
	/**
	 * 리얼타임착오전문 수정 - 사용미정_20121130
	 * @param realTmInfo	리얼타임이체원장
	 * @param tgmCont	전문내용
	 * @param mstkTgmSeq	착오전문순번
	 * @param mstkTgmSeq	이체착오일자
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int updateErTgm (TBCMRTM001Io realTmInfo, String tgmCont, int mstkTgmSeq, String trsfMstkDt) throws ApplicationException {
		
		int iResult = 0;
		TBCMRTM003Io inputVl = new TBCMRTM003Io();
		
		String todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

		inputVl.setRltmTgmNo(realTmInfo.getRltmTgmNo());					// set [리얼타임전문번호]
		inputVl.setMstkTgmSeq(mstkTgmSeq);									// set [착오전문순번]
		inputVl.setTrsfMstkDt(trsfMstkDt);									// set [이체착오일자]
		inputVl.setMstkTgmPrcsTi(todayHms);									// set [착오전문처리시각]
		inputVl.setMstkTpcd(realTmInfo.getCmpyImtrsfRcd());					// set [착오유형코드] - 응답코드
		inputVl.setTgmCtnt(tgmCont);										// set [전문내용]
		//inputVl.setLastChgDtm();											// set [최종변경일시]
		inputVl.setLastChgrId(FwUtil.getUserId());							// set [최종변경자ID]
		inputVl.setLastChgPgmId(FwUtil.getPgmId());							// set [최종변경프로그램ID]
		inputVl.setLastChgTrmNo(FwUtil.getTrmNo());							// set [최종변경단말번호]
		
		iResult = this.cmb001dbio.updateOneTBCMRTM0030(inputVl);
		
		
		return iResult;
	}
	
	
	/**
	 * 즉시이체 성공시 이전지급처리후 계약테이블중 '지급이체중(05)' 로 변경한 지급처리보류사유코드를 
	 * 다시 '지급보류미등록(00)' 으로 변경, 출수납거래번호로 보전파트모듈 호출_20130401
	 * 
	 * @param 출수납거래번호
	 * @return N/A
	 * @throws ApplicationException
	 */
	public void updateContCdStatus(String bzTmKeyVl) throws ApplicationException {
		List<SelectMultiTBPATRN001bOut> contInfoList = null;
	}
	

	/**
	 * 업무파트에 수신내용 Send Method 공통  Operation - 각 요청업무파트별 callback bean, method 정의 및 분기
	 * @param TrsfTrrvPrcsInfo  이체송수신처리정보
	 * @return null
	 * @throws ApplicationException
	 */
	public void callBackTgmTrrv (TrsfTrrvPrcsInfo sendPut) throws ApplicationException {
		
		logger.debug("PA's TrsfTrrvPrcsInfo toString = {}", sendPut);
		
		// 지급파트에서 요청시
		if(RTCont.BZCD_PA.equals(sendPut.getBzDcd())){
			// 즉시이체처리가 정상일 경우 출수납거래참조번호가 존재하고 전송구분코드가 '정상(02)' 일 경우
			
			/***********************************************************
			 * DATE : 2013-10-19 ( 윤석을)
			 * NOTE : 응답이 늦게 도착했는데(지급 이체중인경우) 정상처리, 오류인 경우는 취소처리(인터넷,모바일,IVR만)를 한다.
			 *        최문정대리의 요청
			 ***********************************************************/
//			SelectOneTBPATRN0015Out  pyrcTxInfo = null;
//			pyrcTxInfo = pak001dbio.selectOneTBPATRN0015(sendPut.getBzTmKeyVl());
//
//			if (pyrcTxInfo != null) {
//				
//				//자동송금처리후 송금테이블 업데이트
//				if(RTCont.TRMSDCD_2.equals(sendPut.getTrmsDcd())) {			
//					//계약원장 이체중을 정상으로 업데이트
//					this.updateContCdStatus(sendPut.getBzTmKeyVl());
//
//					pak008dbio.updateOneTBPATRN0153(sendPut.getBzTmKeyVl(), sendPut.getRltmTrsfTxNo(), "2", FwUtil.getUserId(), FwUtil.getPgmId(), FwUtil.getTrmNo());
//					
//				} 
//				else {
//					try {
//						
//						if(	("326002".equals(pyrcTxInfo.getPyrcFofOrgNo()) ||
//							 "326008".equals(pyrcTxInfo.getPyrcFofOrgNo()) ||	
//							 "326005".equals(pyrcTxInfo.getPyrcFofOrgNo())) ) {
//							//출수납즉시이체처리
//							paa900bean.setIndPayCncl(pyrcTxInfo.getPyrcTxNo(), "N", "04", pyrcTxInfo.getPyrcDt(), pyrcTxInfo.getPayRcNo());
//							pak008dbio.updateOneTBPATRN0151(sendPut.getBzTmKeyVl(), FwUtil.getUserId(), FwUtil.getPgmId(), FwUtil.getTrmNo());
//							//this.updateContCdStatus(sendPut.getBzTmKeyVl());
//						}
//						
//						pak008dbio.updateOneTBPATRN0153(sendPut.getBzTmKeyVl(), sendPut.getRltmTrsfTxNo(), "3", FwUtil.getUserId(), FwUtil.getPgmId(), FwUtil.getTrmNo());
//					} catch (Exception e) {
//						throw new ApplicationException("APPAE0102", new Object[]{"즉시이체처리","이체 처리"});
//					}
//				}
//			}
			

			
			this.callTest(sendPut);
		
		// 고객파트에서 요청시
		}
//		else if(RTCont.BZCD_CS.equals(sendPut.getBzDcd())){
//			//cszx03bean.achdVrfcAnsw(sendPut);
//		// 회계파트에서 요청시
//		}else if(RTCont.BZCD_AC.equals(sendPut.getBzDcd())){
			//aca070bean.sendSapBigQtyTrsfRst(sendPut);
			
		// 융자파트에서 요청시
	//	}else if(PAZ500BEAN.BZCD_LN.equals(sendPut.getBzDcd())){
//			lnzm08bean.setResultProc(sendPut);
			
		// 변액파트에서 요청시	
//		}else if(PAZ500BEAN.BZCD_VI.equals(sendPut.getBzDcd())){
//			vic034bean.setTrsfReceInfo(sendPut);
//			
		// 입금파트에서 요청시	
//		}else if(PAZ500BEAN.BZCD_DP.equals(sendPut.getBzDcd())){
//			dpb340bean.insertRltmTrsfPm(sendPut);
			
		// 사고파트에서 요청시	
	//	}else if(PAZ500BEAN.BZCD_AI.equals(sendPut.getBzDcd())){
			// 즉시이체처리가 정상일 경우 출수납거래참조번호가 존재하고 전송구분코드가 '정상(02)' 일 경우
		/*	if(!StringUtils.isEmpty(sendPut.getBzTmKeyVl()) 
					&& PAZ500BEAN.TRMSDCD_2.equals(sendPut.getTrmsDcd())){
				// 즉시이체 성공시 이전지급처리후 계약테이블중 '지급이체중(05)' 로 변경한 지급처리보류사유코드를 
				// 다시 '지급보류미등록(00)' 으로 변경, 출수납거래번호로 보전파트모듈 호출_20130401
				this.updateContCdStatus(sendPut.getBzTmKeyVl());
			}*/
			
			// async시 사고파트 리턴될수신메소드 정의요함
//		}
	}
	
	/**
	 * 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
	 * @param TrsfTrrvPrcsInfo  이체송수신처리정보, 리얼타임이체거래번호
	 * @return TrsfTrrvPrcsInfo  이체송수신처리정보 (오류내역)
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setErrInfo(TrsfTrrvPrcsInfo errInfo, String rltmTrsfTxNo){
//		TrsfTrrvPrcsInfo sendErrInfo = new TrsfTrrvPrcsInfo();
		
		String prcsHms		= "";						// 처리시간		

		prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);		

		errInfo.setBnkAnswCd(RTCont.BNK_ANSW_CD_9999);	// set [은행응답코드] - 오류코드 세팅 KDB : 9999 (업무처리진행오류)
		errInfo.setPrcsHms(prcsHms);						// set [처리시간]
		errInfo.setRltmTrsfTxNo(rltmTrsfTxNo);				// set [리얼타임이체거래번호]
		
		return errInfo;
	}
	
	
	public void callTest(TrsfTrrvPrcsInfo sendPut){
		logger.debug("========================= callTest's TrsfTrrvPrcsInfo START ==============================");
		logger.debug("TrsfTrrvPrcsInfo ==> {}", sendPut);
		logger.debug("========================= callTest's TrsfTrrvPrcsInfo END ==============================");
	}
	
	
	/**
	 * 출금이체동의 응답코드 전환(기처리건 에러 정상 응답코드로 변환)
	 * @param wtrsfAsntStsDcd : 출금이체동의상태구분코드(1:동의/2:해지)
	 * @param fininCd         : 금융기관코드
	 * @param fininRltmAnswCd : 금융기관리얼타임응답코드
	 * @return
	 * @throws ApplicationException
	 */
	public String getWdmAsntAnswCd(String wtrsfAsntStsDcd, String fininCd, String fininRltmAnswCd ) throws ApplicationException {

		//출금이체동의상태구분코드 1:동의/2해지
		if (StringUtils.isEmpty(wtrsfAsntStsDcd)) {
			throw new ApplicationException("APCSE0004",	new String[]{"출금동의구분코드"}, new String[]{"출금동의구분코드(1/2)"} );
		}
		if (StringUtils.isEmpty(fininCd)) {
			throw new ApplicationException("APCSE0004",	new String[]{"금융기관코드"}, new String[]{"금융기관코드"} );
		}

		String strFininRltmAnswCd = StringUtils.isEmpty(fininRltmAnswCd) ? "" : fininRltmAnswCd;


		if("1".equals(wtrsfAsntStsDcd)){
			//등록인경우 기등록 에러 정상처리

			//TODO:실제 은행별로 처리해보면서 세팅할것
			//이거는 AS-IS
			if     ("002".equals(fininCd) && "0605".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("005".equals(fininCd) && "A001".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("021".equals(fininCd) && "U237".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("026".equals(fininCd) && "U237".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("088".equals(fininCd) && "U237".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("023".equals(fininCd) && "0361".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("027".equals(fininCd) && "0307".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("031".equals(fininCd) && "2505".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("034".equals(fininCd) && "1412".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if("071".equals(fininCd) && "B039".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;
			else if(                         "2005".equals(strFininRltmAnswCd)) strFininRltmAnswCd = M_FININ_RLTM_ANSW_CD_OK;

		}

		return strFininRltmAnswCd;
	}
	
	/**
	 * 출금이체동의해지 이력 입력
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public int insertWdmAsntHis(TBCSFCR003Io input) throws ApplicationException {
		int retCnt = -1;

		logger.debug("입력할 data::{}" , input);
		TBCSFCR003Io tbcsfcr003io = cmb001dbio.selectOneTBCSFCR0030(input.getActMgntNo());
		//logger.debug("기존재출금동의이력 존재확인::{}" , tbcsfcr003io.getActMgntNo());

		//기존재건 있으면 이력처리후 INSERT
		if(tbcsfcr003io == null ){
			input.setWtrsfAsntRescsDt("99991231");


			retCnt = cmb001dbio.insertOneTBCSFCR003(input);
		}else{
			//logger.debug("기존재 출금동의정보 data::{}" , tbcsfcr003io);

			if( "2".equals(input.getWtrsfAsntStaDcd()) ){
				input.setWtrsfAsntPrcsDt(tbcsfcr003io.getWtrsfAsntPrcsDt());
			}else{
				input.setWtrsfAsntRescsDt("99991231");

			}

			//logger.debug("변경된 입력 data::{}" , input);

			TBCSFCR003Io tbcsfcr003ioUpdate = new TBCSFCR003Io();

			tbcsfcr003ioUpdate.setActMgntNo(input.getActMgntNo());
			tbcsfcr003ioUpdate.setLastHisYn("N");


			tbcsfcr003ioUpdate.setLastChgDtm(input.getLastChgDtm());
			tbcsfcr003ioUpdate.setLastChgOrgNo(input.getLastChgOrgNo());
			tbcsfcr003ioUpdate.setLastChgPgmId(input.getLastChgPgmId());
			tbcsfcr003ioUpdate.setLastChgrId(input.getLastChgrId());
			tbcsfcr003ioUpdate.setLastChgTrmNo(input.getLastChgTrmNo());

			retCnt = cmb001dbio.updateOneTBCSFCR003(tbcsfcr003ioUpdate);
			logger.debug("출금동의이력수정결과::{}" , retCnt);

			logger.debug("이력등록정보 ::{}", input);
			retCnt = cmb001dbio.insertOneTBCSFCR003(input);
			logger.debug("출금동의이력등록결과::{}" , retCnt);

		}

		return retCnt;

	}
	
	
	
	
	/**
	 * 업무파트에 수신내용 Send Method 공통  Operation - 각 요청업무파트별 callback bean, method 정의 및 분기
	 * @param TrsfTrrvPrcsInfo  이체송수신처리정보
	 * @return null
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String prcsWtrsfAsntInfoNew(TrsfTrrvPrcsInfo input, String tgmNoBankCd, String today, String prcsHms, String wdmAsntDcd, String rltmTrsfPmpsNo) throws ApplicationException {
		
		logger.debug("prcsWtrsfAsntInfo toString = {}", input);
		
		String wtrsfAsntCd = "";
		String tgmNo = "";
		String rltmTrsfTxNo = "";
		int iResult = 0;
		
		String strRegRescsDcd = "";
		String nrmCnclcDcd = "";
		String strTrsfPmpsRegDcd = "";
		String strWdmAsntMthd = "1";			//TODO:2016.03.16;현승훈;출금동의방법코드 추후 수정 
		String strPrcsCd = "";
		
		TrsfTrrvPrcsInfo trsftrrvprcsinfoOut = null;
		
		String testDay		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
		String currDate = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE );
		
		//출금이체동의(11)/출금이체동의해지(12)
		//등록(정상취소구분(0), 해지(정상취소구분(1)로 세팅)
		if( "11".equals(wdmAsntDcd)){
			strRegRescsDcd    = "1";
			nrmCnclcDcd       = "0";
			strTrsfPmpsRegDcd = "3";
			strPrcsCd         = RTCont.PRCSCD_12;
		}else if( "12".equals(wdmAsntDcd)){
			strRegRescsDcd    = "2";
			nrmCnclcDcd       = "1";
			strTrsfPmpsRegDcd = "C";
			strPrcsCd         = RTCont.PRCSCD_11;
		}else{
			throw new ApplicationException("APCSE0004", new Object[]{"업무구분코드(동의/해지)"}, new Object[]{"업무구분코드(동의/해지)"});
		}

		//출금이체 동의 해지처리 전문송신
		TrsfTrrvPrcsInfo  trsftrrvprcsinfoIn = new TrsfTrrvPrcsInfo();

		trsftrrvprcsinfoIn.setPrcsCd(strPrcsCd);// set [처리코드(12/리얼타임출금이체신청, 11/리얼타임출금이체해지]]
		trsftrrvprcsinfoIn.setChnlDcd("");// set [채널구분코드]
		trsftrrvprcsinfoIn.setPrcsDt(currDate);// set [처리일자]
		//trsftrrvprcsinfoIn.setPayRcPathCd("WB");// set [지급접수경로코드]
		//trsftrrvprcsinfoIn.setPayRcMcd("WB");// set [지급접수방법코드]
		//trsftrrvprcsinfoIn.setPyprcPathCd("S");// set [지급처리경로코드]
		trsftrrvprcsinfoIn.setTrsfAmt(BigDecimal.ZERO);// set [이체금액]
		//trsftrrvprcsinfoIn.setBenfcCustNo(null);// set [수익자고객번호]
		//trsftrrvprcsinfoIn.setContrCustNo(trsftrrvprcsinfoOut.getContrCustNo());// set [계약자고객번호]
		trsftrrvprcsinfoIn.setDpwdDcd("1");// set [입출금구분코드] 1:입금, 2:출금
		trsftrrvprcsinfoIn.setActMgntNo(input.getActMgntNo());// set [계좌관리번호]
		trsftrrvprcsinfoIn.setPrcsBnkCd(input.getPrcsBnkCd());// set [처리은행코드]

		//대표금융기관코드
		String repFininCd = cmb001dbio.selectOneTBCSFCR0071(input.getBnkCd()).substring(0, 3);
		trsftrrvprcsinfoIn.setBnkCd(repFininCd);// set [은행코드]

		trsftrrvprcsinfoIn.setActNo(input.getActNo());// set [계좌번호]
		trsftrrvprcsinfoIn.setAchdNm(input.getAchdNm());// set [예금주명]
		trsftrrvprcsinfoIn.setAchdRrno(input.getAchdRrno()); //set [예금주주민등록번호]

		trsftrrvprcsinfoIn.setNrmCnclDcd(nrmCnclcDcd);// set [정상취소구분코드]등록(정상취소구분(0), 해지(정상취소구분(1)로 세팅)
		trsftrrvprcsinfoIn.setBzDcd(input.getBzDcd());// set [업무구분코드]
		trsftrrvprcsinfoIn.setBzTmKeyVl(input.getBzTmKeyVl());// set [업무팀KEY값], 출금동의방법코드
		trsftrrvprcsinfoIn.setReqBzTmBean(input.getReqBzTmBean());// set [요청파트BEAN]
		trsftrrvprcsinfoIn.setReqBzTmMethod(input.getReqBzTmMethod());// set [요청파트Method]
		trsftrrvprcsinfoIn.setTrmsDcd(RTCont.TRMSDCD_0);
		
		if(StringUtils.isEmpty(input.getPyrcDofOrgNo())) {
			trsftrrvprcsinfoIn.setPyrcDofOrgNo(FwUtil.getDeptCd());							// set [이체지점조직번호]	
		}else{
			trsftrrvprcsinfoIn.setPyrcDofOrgNo(input.getPyrcDofOrgNo());					// set [이체지점조직번호]
		}
		
		if(StringUtils.isEmpty(input.getPyrcFofOrgNo())) {
			trsftrrvprcsinfoIn.setPyrcFofOrgNo(FwUtil.getDeptCd());							// set [이체영업소조직번호]	
		}else{
			trsftrrvprcsinfoIn.setPyrcFofOrgNo(input.getPyrcFofOrgNo());							// set [이체영업소조직번호]
		}
		
		if(StringUtils.isEmpty(input.getPyrcPrcsEno())) {
			trsftrrvprcsinfoIn.setPyrcPrcsEno(FwUtil.getUserId());								// set [이체처리사원번호]
		}else{
			trsftrrvprcsinfoIn.setPyrcPrcsEno(input.getPyrcPrcsEno());							// set [이체영업소조직번호]
		}

		trsftrrvprcsinfoIn.setOptnKey("S");	//set옵션키 : 전송유형(S/sync)
		
		trsftrrvprcsinfoIn.setPropoDeptOrgNo(input.getPropoDeptOrgNo());					// set [발의부서]
		trsftrrvprcsinfoIn.setWtrsfAsntEvidDcd(input.getWtrsfAsntEvidDcd());
		
		tgmNo = setTgmNoCrt(tgmNoBankCd, today);  // 
		
		if(!StringUtils.hasText(tgmNo)){
			// 전문번호 생성 오류 : '전문번호가 생성되지 않았습니다. 확인해주세요.'
			throw new ApplicationException("APPAE0057", new Object[]{"전문번호"});
		}
				
		// 리얼타임이체거래번호 채번생성
		rltmTrsfTxNo = cma004bean.getNewPayMknoNo("CMRT", today.substring(0, 8), 20);
		
		if(!StringUtils.hasText(rltmTrsfTxNo)){
			// 리얼타임이체거래번호 채번생성 오류 : '리얼타임이체거래번호가 생성되지 않았습니다. 확인해주세요.'
			throw new ApplicationException("APPAE0057", new Object[]{"리얼타임이체거래번호"});
		}
		
		logger.debug("=========>> rltmTrsfPmpsNo <<=========" + rltmTrsfPmpsNo);
		
		iResult = insertTrmsDcd(rltmTrsfTxNo, today, prcsHms, tgmNo,rltmTrsfPmpsNo, trsftrrvprcsinfoIn);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장입력"});
		}
		
		logger.debug(" ##########  수정 후   ##########   " + rltmTrsfPmpsNo);
		
		//2017.03.24;현승훈;테스트를 위해 분기처리 
		if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
			// KIB-NET 출금이체신청(납부자번호등록)
			trsftrrvprcsinfoOut = cmb003bean.setWdmTrsfApplNewTest(trsftrrvprcsinfoIn.clone(), tgmNo, rltmTrsfTxNo, rltmTrsfPmpsNo);
		} else {
			// KIB-NET 출금이체신청(납부자번호등록)
			trsftrrvprcsinfoOut = cmb003bean.setWdmTrsfApplNew(trsftrrvprcsinfoIn.clone(), tgmNo, rltmTrsfTxNo, rltmTrsfPmpsNo);
		}
		
		
		
		
		if(trsftrrvprcsinfoOut == null){
			throw new ApplicationException("APCSE0025", new String[]{"출금동의 확인"},new String[] { "공통","대외계 오류" });
		}
		//logger.debug("출금이체신청송신결과 TrsfTrrvPrcsInfo ::{}",  trsftrrvprcsinfoOut);


		//응답코드 변환(중복등록 정상처리, 해지는 무조건정상)
		String strFininRltmAnswCd =   this.getWdmAsntAnswCd(strRegRescsDcd, trsftrrvprcsinfoOut.getPrcsBnkCd(), trsftrrvprcsinfoOut.getBnkAnswCd());

//
//
//		//출금이체동의정보 입력
//		TBCSFCR003Io tbcsfcr003ioInsert = new TBCSFCR003Io();
//
//
//		tbcsfcr003ioInsert.setActMgntNo(input.getActMgntNo());// set [계좌관리번호]
//		//tbcsfcr003ioInsert.setWtrsfAsntHisSeq(0);// set [출금이체동의이력순번]
//		tbcsfcr003ioInsert.setRltmTrsfPmpsNo(input.getActMgntNo());// set [리얼타임이체납부자번호]
//		tbcsfcr003ioInsert.setWtrsfAsntStaDcd(strRegRescsDcd);// set [출금이체동의상태구분코드]
//		tbcsfcr003ioInsert.setRltmTrsfPmpsRegDcd(strTrsfPmpsRegDcd);// set [리얼타임이체납부자등록구분코드]
//		tbcsfcr003ioInsert.setWtrsfAsntMcd(strWdmAsntMthd);// set [출금이체동의방법코드]
//
//
//		if( "2".equals(strRegRescsDcd) ){
//			tbcsfcr003ioInsert.setWtrsfAsntRescsDt(trsftrrvprcsinfoOut.getPrcsDt());// set [출금이체동의해지일자]
//		}else{
//			tbcsfcr003ioInsert.setWtrsfAsntPrcsDt(trsftrrvprcsinfoOut.getPrcsDt());// set [출금이체동의처리일자]
//		}
//
//		tbcsfcr003ioInsert.setFininRltmAnswCd(strFininRltmAnswCd);// set [금융기관리얼타임응답코드]
//		tbcsfcr003ioInsert.setLastHisYn("Y");// set [최종이력여부]
//		tbcsfcr003ioInsert.setRltmTrsfTxNo(trsftrrvprcsinfoOut.getRltmTrsfTxNo());//
//
//
//		tbcsfcr003ioInsert.setFstCrtDtm(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE ));// set [최초생성일시]
//		tbcsfcr003ioInsert.setFstCrtOrgNo(FwUtil.getDeptCd());// set [최초생성조직번호]
//		tbcsfcr003ioInsert.setFstCrtrId(FwUtil.getUserId());// set [최초생성자ID]
//		tbcsfcr003ioInsert.setDelYn("N");// set [삭제여부]
//		tbcsfcr003ioInsert.setLastChgDtm(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE ));// set [최종변경일시]
//		tbcsfcr003ioInsert.setLastChgOrgNo(FwUtil.getDeptCd());// set [최종변경조직번호]
//		tbcsfcr003ioInsert.setLastChgrId(FwUtil.getUserId());// set [최종변경자ID]
//		tbcsfcr003ioInsert.setLastChgPgmId(FwUtil.getPgmId());// set [최종변경프로그램ID]
//		tbcsfcr003ioInsert.setLastChgTrmNo(FwUtil.getTrmNo());// set [최종변경단말번호]
//
//
//		int intRegCnt = this.insertWdmAsntHis(tbcsfcr003ioInsert);
//		logger.debug("출금동의등록건수 ::{}", intRegCnt);
		////////////////////////////////////////////////////////

		//응답전문을 수신한경우 결과 세팅
		wtrsfAsntCd = strFininRltmAnswCd;
		
		return wtrsfAsntCd;
	}
	
	/**
	 * 2016.12.08;현승훈 (신계약전용)
	 * 지급이체송수신전문처리_메인 Operation
	 * 신계약(청약및계약 처리시 응답결과가 정상이 아닐 경우 해당데이터 ROLLBACK 처리를 위해 한Transaction으로 처리
	 * 따라서 타 업무에서 사용하는 계좌테이블 조회 로직 제외시힘( 신규 계좌로 처리시  Transaction이 분리되어 계좌 조회 불가)
	 * @param TrsfTrrvPrcsInfo  이체송수신처리정보
	 * @return TrsfTrrvPrcsInfo  이체송수신처리정보 
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public TrsfTrrvPrcsInfo callTgmTrrvNB (TrsfTrrvPrcsInfo input) throws ApplicationException {
		
		TrsfTrrvPrcsInfo prcsInfo = null;
		
		//2016.10.08;현승훈;출금이체동의증빙		
		WtrsfAsntDlngInfo dlngInfo = null;
		
		TBCSFCR001Io actInfo = new TBCSFCR001Io();							// 계좌정보		
		//TBCMRTM006Io fininInfo = new TBCMRTM006Io();						// 금융기관제휴업무목록
		
		TBCMRTM024Io fininInfo = new TBCMRTM024Io();						// 금융기관제휴업무목록
		
		int	iResult			= 0;						// 처리결과값
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		String tgmNo 		= "";				// 전문번호
		String rltmTrsfTxNo	= "";				// 리얼타임이체거래번호
		String prcsHms		= "";				// 처리시간
		String tgmNoBankCd = "" ;               // 전문번호 생성 은행코드 
		String wtrsfAsntCd = "";				//출금이체동의 결과
		String rltmTrsfPmpsNo = "";				//리얼타임납부자번호
		String prcsEno = "";					//처리사번
		String orgKnd = "";						//조직종류
		String propoDeptOrgNo = "";				//발의부서
		
		BigDecimal zero = BigDecimal.ZERO;
		
		logger.debug("☆★☆★☆ ★☆ ====================> 송신 수신 전문 START2222 <==================== ★☆ ☆★☆★☆ ");
//		logger.debug("☆★☆==========> input={}", input);
		logger.debug("☆★☆★☆★☆  ====================> 송신 수신 전문 END <==================== ★☆ ☆★☆★☆ ");

		
		if(StringUtils.isEmpty(input.getPyrcPrcsEno())) {
			prcsEno = FwUtil.getUserId();								// set [이체처리사원번호]
		}else{
			prcsEno = input.getPyrcPrcsEno();							// set [이체처리사원번호]
		}
		
		CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(prcsEno);
		
		if (commEmplInfo.getPropoDeptOrgNo() == null || StringUtils.isEmpty(commEmplInfo.getPropoDeptOrgNo())) {
			
			throw new ApplicationException("APCME0055", null);
		}
		
		//orgKnd = cmb001dbio.selectOneTBSLORG001a(commEmplInfo.getPropoDeptOrgNo());	//조직종류코드조회
		orgKnd = commEmplInfo.getOrgKcd();	//조직종류코드조회
		
		if (orgKnd == null || StringUtils.isEmpty(orgKnd)) {
			//throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직종류코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"조직종류코드(M)"});
		}
		
		// 조직종류 TM -- 100118
		// 조직종류 GA -- 100980
		// 조직종류 스텝부서 -- 발의부서
		if (RTCont.ORG_KND_TM.equals(orgKnd)) {
			propoDeptOrgNo = RTCont.ORG_NO_TM;
			//propoDeptOrgNo = "101088";			
		} 
//		else if (RTCont.ORG_KND_GA.equals(orgKnd)) {
//			propoDeptOrgNo = RTCont.ORG_NO_GA;
//		} 
		else {
			propoDeptOrgNo = commEmplInfo.getPropoDeptOrgNo();
		} 
		
		//2016.10.17;현스훈;발의부서 세팅;
		input.setPropoDeptOrgNo(propoDeptOrgNo);
		
		if (StringUtils.isEmpty(input.getCentrNm()) ) {
			input.setCentrNm(commEmplInfo.getDofOrgNm());
		}
		if (StringUtils.isEmpty(input.getTeamNm()) ) {
			input.setTeamNm(commEmplInfo.getFofOrgNm());
		}
		if (StringUtils.isEmpty(input.getChrgpNm()) ) {
			input.setChrgpNm(commEmplInfo.getEmplNm());
		}
		
		SecuUtil.doDecObject(input);
	   
		if(!StringUtils.isEmpty(input.getActNo())){
		   input.setActNo(input.getActNo().replace("-", "")) ;  // 계좌번호 - 삭제
		   if (input.getActNo().length() > 16) {
				throw new ApplicationException("APCME0025", new Object[]{"계좌번호(16자리초과)"});
		   }
		}		
		//처리시간 (자동이체처리 호출(OMM) 세팅용)
		prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

		
		/*********************** 이체송수신처리정보 기본필수입력값체크 START ***********************/
		
		// Validation#0 : TrsfTrrvPrcsInfo(이체송수신처리정보) 기본필수입력값체크
		if (StringUtils.isEmpty(input.getPrcsCd()) || input.getPrcsCd().length() != 2) {
			throw new ApplicationException("APCME0025", new Object[]{"처리코드(M)"});
		}
		
		if (StringUtils.isEmpty(input.getPrcsDt()) || input.getPrcsDt().length() != 8) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "처리일자(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "처리일자(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"처리일자(M)"});
		}
		
		if (StringUtils.isEmpty(input.getDpwdDcd()) || input.getDpwdDcd().length() != 1) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "입출금구분코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "입출금구분코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"입출금구분코드(M)"});
		}
		
		if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"은행코드(M)"});
		}
		
		//2016.11.11;현승훈;출금이체동의 필수 항목 체크
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){				//(02) 자동집금처리(입금,집금) 
			if (!StringUtils.isEmpty(input.getWtrsfAsntEvidDcd())) {
				if (StringUtils.isEmpty(input.getWtrsfAsntSysCd())) {
					//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의시스템코드" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의시스템코드" });
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의시스템코드"}); 
				}
				if (StringUtils.isEmpty(input.getWtrsfAsntEvidDcd())) {
					//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의증빙구분코드" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의증빙구분코드" });
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의증빙구분코드"}); 
				}
				if (StringUtils.isEmpty(input.getWtrsfAsntEvidNo())) {
					//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의증빙번호" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의증빙번호" });
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의증빙번호"});
				}
				if (StringUtils.isEmpty(input.getWtrsfAsntDcd())) {
					//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의구분코드" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의구분코드" });
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의구분코드"});
				}
				if (StringUtils.isEmpty(input.getWtrsfAsntRcDcd())) {
					//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의접수구분코드" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "출금이체동의접수구분코드" });
					throw new ApplicationException("APCME0025", new Object[]{"출금이체동의접수구분코드"});
				}
				if (StringUtils.isEmpty(input.getContNo())) {
					//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계약번호" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계약번호" });
					throw new ApplicationException("APCME0025", new Object[]{"계약번호"});
				}
				if (StringUtils.isEmpty(input.getContrNm())) {
					//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계약자명" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계약자명" });
					throw new ApplicationException("APCME0025", new Object[]{"계약자명"});
				}				
			}
		}
		
				
		// 송금처리 : 동일일자,출금금액, 참조거래번호가 같으면 오류로 분류하여 처리.(전송 중인 건 체크)
		if (input.getBzTmKeyVl() != null  && input.getBzDcd() != null) {
			//2016.10.08;현승훈;입금처리 추가
			if (RTCont.PRCSCD_01.equals(input.getPrcsCd()) ) {
				TBCMRTM001Io  tBCMRTM001Io = cmb001dbio.selectOneTBCMRTM0014(input.getBzTmKeyVl(), input.getBzDcd(),input.getPrcsDt(),input.getPrcsCd());	//리얼타임이체거래번호로 조회
				if (tBCMRTM001Io != null) {
					if (tBCMRTM001Io.getTrsfAmt().compareTo(input.getTrsfAmt()) == 0 &&
						tBCMRTM001Io.getTrsfDt().equals(input.getPrcsDt()) &&
						RTCont.PRCSCD_01.equals(tBCMRTM001Io.getRltmBzDcd()) ) {
						/* 출금처리 요청시 동일일자 동일참조번호에 동일금액의 기 송금자료가 존재합니다. */
						throw new ApplicationException("APPAE0404", new Object[]{}); 
					}
				}
			}
		}
				
		// 송금처리 : 동일일자,출금금액, 참조거래번호가 같으면 오류로 분류하여 처리.
		if (input.getBzTmKeyVl() != null  && input.getBzDcd() != null) {
			//2016.10.08;현승훈;입금처리 추가
			if (RTCont.PRCSCD_01.equals(input.getPrcsCd()) ) {
				TBCMRTM001Io  tBCMRTM001Io = cmb001dbio.selectOneTBCMRTM0011(input.getBzTmKeyVl(), input.getBzDcd(),input.getPrcsDt(),input.getPrcsCd());	//리얼타임이체거래번호로 조회
				if (tBCMRTM001Io != null) {
					if (tBCMRTM001Io.getTrsfAmt().compareTo(input.getTrsfAmt()) == 0 &&
						tBCMRTM001Io.getTrsfDt().equals(input.getPrcsDt()) &&
						RTCont.PRCSCD_01.equals(tBCMRTM001Io.getRltmBzDcd()) ) {
						/* 출금처리 요청시 동일일자 동일참조번호에 동일금액의 기 송금자료가 존재합니다. */
						throw new ApplicationException("APPAE0325", new Object[]{}); 
					}
				}
			}
		}
		
		// 입금처리 : 동일일자,출금금액, 참조거래번호가 같으면 오류로 분류하여 처리.(전송 중인 건 체크)
		if (input.getBzTmKeyVl() != null  && input.getBzDcd() != null) {
			//2016.10.08;현승훈;입금처리 추가
			if (RTCont.PRCSCD_02.equals(input.getPrcsCd()) ) {
				TBCMRTM001Io  tBCMRTM001Io = cmb001dbio.selectOneTBCMRTM0014(input.getBzTmKeyVl(), input.getBzDcd(),input.getPrcsDt(),input.getPrcsCd());	//리얼타임이체거래번호로 조회
				if (tBCMRTM001Io != null) {
					if (tBCMRTM001Io.getTrsfAmt().compareTo(input.getTrsfAmt()) == 0 &&
						tBCMRTM001Io.getTrsfDt().equals(input.getPrcsDt()) &&
						RTCont.PRCSCD_02.equals(tBCMRTM001Io.getRltmBzDcd()) ) {
						/* 출금처리 요청시 동일일자 동일참조번호에 동일금액의 기 송금자료가 존재합니다. */
						throw new ApplicationException("APPAE0406", new Object[]{}); 
					}
				}
			}
		}
				
		// 입금처리 : 동일일자,출금금액, 참조거래번호가 같으면 오류로 분류하여 처리.
		if (input.getBzTmKeyVl() != null  && input.getBzDcd() != null) {
			//2016.10.08;현승훈;입금처리 추가
			if (RTCont.PRCSCD_02.equals(input.getPrcsCd()) ) {
				TBCMRTM001Io  tBCMRTM001Io = cmb001dbio.selectOneTBCMRTM0011(input.getBzTmKeyVl(), input.getBzDcd(),input.getPrcsDt(),input.getPrcsCd());	//리얼타임이체거래번호로 조회
				if (tBCMRTM001Io != null) {
					if (tBCMRTM001Io.getTrsfAmt().compareTo(input.getTrsfAmt()) == 0 &&
						tBCMRTM001Io.getTrsfDt().equals(input.getPrcsDt()) &&
						RTCont.PRCSCD_02.equals(tBCMRTM001Io.getRltmBzDcd()) ) {
						/* 출금처리 요청시 동일일자 동일참조번호에 동일금액의 기 송금자료가 존재합니다. */
						throw new ApplicationException("APPAE0405", new Object[]{}); 
					}
				}
			}
		}
		
		/*********************** 이체송수신처리정보 기본필수입력값체크 END ***********************/
	
		
		/*********************** 지급이체송수신전문처리위한 세팅부 START ***********************/		
		
		// Validation#1 : 처리코드(01 or 02) 와 입출금구분코드가 상이할 경우 오류, return
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){			// 입금
			if(!RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){
				// '처리코드와 입출금구분코드가 상이합니다. 확인해주세요.'
				throw new ApplicationException("APPAE0058", new Object[]{"처리코드", "입출금구분코드"});
			}
		}
		
		if(RTCont.PRCSCD_01.equals(input.getPrcsCd())){			// 출금
			if(!RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd())){
				// '처리코드와 입출금구분코드가 상이합니다. 확인해주세요.'
				throw new ApplicationException("APPAE0058", new Object[]{"처리코드", "입출금구분코드"});
			}
		}
		
		if(RTCont.PRCSCD_01.equals(input.getPrcsCd()))	{
			tgmNoBankCd = cmb001dbio.selectOneTBCMRTM0240(input.getPropoDeptOrgNo(), "02");	//모계좌금융기관조회(제지급계좌조회)
		} else if(RTCont.PRCSCD_07.equals(input.getPrcsCd()))	{
			tgmNoBankCd =  input.getBnkCd() ;
		} else if(RTCont.PRCSCD_02.equals(input.getPrcsCd()))	{
			tgmNoBankCd = cmb001dbio.selectOneTBCMRTM0242(input.getPropoDeptOrgNo(), "01", input.getBnkCd());	//모계좌금융기관조회(입금계좌(RTB))
		} else{
			//tgmNoBankCd =  input.getBnkCd() ;
			// 이체처리 결과시 지급처리건 조회시 제지급모계좌 조회
			if (RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd())) {
				tgmNoBankCd = cmb001dbio.selectOneTBCMRTM0240(input.getPropoDeptOrgNo(), "02");	//모계좌금융기관조회(제지급계좌조회)
			} else {
				tgmNoBankCd = cmb001dbio.selectOneTBCMRTM0242(input.getPropoDeptOrgNo(), "01", input.getBnkCd());	//모계좌금융기관조회(입금계좌(RTB))
			}
		}
		
		if (StringUtils.isEmpty(tgmNoBankCd)) {
			throw new ApplicationException("APPAE0051", null);
		}
		
		// 전송구분코드 세팅 (default 미전송 : 0 세팅)
		input.setTrmsDcd(RTCont.TRMSDCD_0);
		
		// 처리코드별(업무별 구분코드) 분기하여 처리은행코드 세팅
		if(RTCont.PRCSCD_07.equals(input.getPrcsCd())){	//(07) 성명조회(예금주조회)

			//라이나 성명조회시 지급계좌로 변경
			input.setPrcsBnkCd(tgmNoBankCd);
			
			// (07) 성명조회(예금주조회)시 업무구분코드가 고객(CS)일 경우 계좌관리번호로 계좌조회 로직을 수행하지 않는다._20121212(고객팀요청)
			if(!"CS".equals(input.getBzDcd())){
				
				if(!StringUtils.isEmpty(input.getActMgntNo())){
					// 계좌관리번호로 계좌조회
					actInfo = this.cmb001dbio.selectOneTBCSFCR0010(input.getActMgntNo());
					SecuUtil.doDecObject(actInfo);
					
				}else{
					throw new ApplicationException( "APCME0005", null, new Object[]{ "계좌관리번호", "계좌관리번호" });
				}
				
				// 계좌관리번호로 계좌조회하여 업무파트에서 넘어온 매핑하여 비교
				if(actInfo != null){						
					if(!input.getActNo().equals((actInfo.getActNo()))){		// 계좌번호 비교
						// validation : 계좌정보에 존재하지 않는 계좌번호입니다. 확인해주세요, 업무파트로 return
						logger.debug("입력계좌번호 {}, 조회계좌번호 {}",input.getActNo(), actInfo.getActNo());
						throw new ApplicationException("APPAE0047", new Object[]{"계좌번호"});
						
					}else if(!input.getAchdNm().equals((actInfo.getAchdNm()))){		// 예금주명 비교
						// validation : 계좌정보에 존재하지 않는 예금주명입니다. 확인해주세요, 업무파트로 return
						logger.debug("입력예금주명 {}, 조회예금주명 {}",input.getAchdNm(), actInfo.getAchdNm());
						throw new ApplicationException("APPAE0047", new Object[]{"예금주명"});
						
					}else if(!"0000".equals(actInfo.getFininActStcd())){					// 금융기관계좌상태코드 체크
						// validation : 해당금융기관의 계좌상태가 정상이 아닙니다. 확인해주세요, 업무파트로 return
						logger.debug("계좌상태: {}", actInfo.getFininActStcd());
						throw new ApplicationException("APPAE0055", null);
					}
					
				}else{
					// 계좌정보가 존재하지 않는 계좌관리번호입니다. 확인해주세요.
					throw new ApplicationException("APPAE0048", null);
				}
			}
		}else{	    // (07) 성명조회(예금주조회) 이외업무
			if (RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd()) && !RTCont.PRCSCD_08.equals(input.getPrcsCd())){
				input.setPrcsBnkCd(tgmNoBankCd);
			} else {
				input.setPrcsBnkCd(input.getBnkCd());
			}		
		}  // end if 예금주 조회 else if 모계좌 조회  else 다른 업무
		
		if( !RTCont.PRCSCD_08.equals(input.getPrcsCd()) && !RTCont.PRCSCD_07.equals(input.getPrcsCd())) {	//ERP파트에서 넘어온 데이터가 아니면 입출금구분코드 값으로 조건값을 세팅
			// 입출금구분코드가 입금(1) 일 경우 즉시이체구분코드(조회조건값)가 '0002', 고객은행코드 세팅
			
			if(RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){
				
				fininInfo =  this.cmb001dbio.selectOneTBCMRTM0241(input.getPropoDeptOrgNo(),"01" , tgmNoBankCd);
				
			// 입출금구분코드가 출금(2) 일 경우 즉시이체구분코드(조회조건값)가 '0001', 처리은행코드 세팅
			}else if(RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd())){
				
				fininInfo =  this.cmb001dbio.selectOneTBCMRTM0241(input.getPropoDeptOrgNo(),"02" , tgmNoBankCd);
				
			}else{
				// 채널구분코드나 입출금구분코드가 형식에 맞지 않는 코드입니다. 확인해주세요.
				throw new ApplicationException("APPAE0076", null);
			}
			
		}
		
		SecuUtil.doDecObject(fininInfo);
		
		if(fininInfo == null){
			// 채널구분코드별로 금융기관제휴업무목록(TBCMRTM006) 을 조회, '금융기관제휴업무목록 정보가 존재하지 않습니다.' 메세지
			throw new ApplicationException("APPAE0051", null);
		}
		
		logger.debug("☆★☆==========> 여기는 들어오는지 2222222222222222");
		/*********************** 지급이체송수신전문처리위한 세팅부 END ***********************/
		
		/*********************** 인출일 경우 출금이체동의 시작 START ***********************/
		// 2016.03.14;현승훈;입금,집금일 경우 출금이체동의 신청 처리 우선 선행
		// 처리코드별(업무별 구분코드) : 02-자동집금처리(입금,집금)
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){				//(02) 자동집금처리(입금,집금)
			
			if (input.getTrsfAmt() == null || input.getTrsfAmt().compareTo(zero) == 0 ) {
				//throw new ApplicationException( "APCME0025", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "이체금액" });
				throw new ApplicationException("APCME0025", new Object[]{"이체금액"});
			}
			
			if ((StringUtils.isEmpty(input.getActMgntNo()) ) && // || input.getActMgntNo().length() != 20) &&
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201) {
				//throw new ApplicationException( "APCME0025", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌관리번호" });
				throw new ApplicationException("APCME0025", new Object[]{"계좌관리번호"});
			}
			
			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
				//throw new ApplicationException( "APCME0025", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드" });
				throw new ApplicationException("APCME0025", new Object[]{"은행코드"});
			}
			
			if (StringUtils.isEmpty(input.getActNo())) {
				//throw new ApplicationException( "APCME0025", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌번호" });
				throw new ApplicationException("APCME0025", new Object[]{"계좌번호"});
			} 
			
			if ((StringUtils.isEmpty(input.getAchdNm())) && 
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {
				//throw new ApplicationException( "APCME0025", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "예금주명" });
				throw new ApplicationException("APCME0025", new Object[]{"예금주명"});
			}
			
			if ((StringUtils.isEmpty(input.getAchdRrno()) || (input.getAchdRrno().length() != 13 && input.getAchdRrno().length() != 10)) &&
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201
				//throw new ApplicationException( "APCME0025", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "예금주주민등록번호" });
				throw new ApplicationException("APCME0025", new Object[]{"예금주주민등록번호"});
			}
			
			rltmTrsfPmpsNo = this.cmb001dbio.selectOneTBCMRTM0013();
			
			wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "11", rltmTrsfPmpsNo);
			
			
			if (StringUtils.isEmpty(wtrsfAsntCd) || wtrsfAsntCd == null) 
			{
				throw new ApplicationException("APCME0054", new Object[]{"대외계 미응답"});
			} else if (!"0000".equals(wtrsfAsntCd))
			{
				String rltmAnswCtnt = this.cmb001dbio.selectOneTBCMRTM0081(tgmNoBankCd, wtrsfAsntCd);
				
				if (StringUtils.isEmpty(rltmAnswCtnt)) {
					rltmAnswCtnt = "기타오류";
				} 
				
				throw new ApplicationException("APCME0054", new Object[]{"출금이체동의신청 시 응답결과 오류 ( " + rltmAnswCtnt + " - " + wtrsfAsntCd + ") 가 발생했습니다."});
			}
		}
		/*********************** 인출일 경우 출금이체동의 종료 END ***********************/
		
		/******* 송수신전문 전송보내기전 리얼타임이체원장(TBCMRTM001) 테이블 입력 : insert START *******/
		logger.debug("=========>> 송수신전문 전송보내기전 리얼타임이체원장(TBCMRTM001) 테이블 입력 : insert START <<=========");
		
		// 전문번호 생성
		//tgmNo = setTgmNoCrt(input.getBnkCd(), today);    
		tgmNo = setTgmNoCrt(tgmNoBankCd, today);  // 
		
		if(!StringUtils.hasText(tgmNo)){
			// 전문번호 생성 오류 : '전문번호가 생성되지 않았습니다. 확인해주세요.'
			throw new ApplicationException("APPAE0057", new Object[]{"전문번호"});
		}
				
		// 리얼타임이체거래번호 채번생성
		rltmTrsfTxNo = cma004bean.getNewPayMknoNo("CMRT", today.substring(0, 8), 20);
		
		if(!StringUtils.hasText(rltmTrsfTxNo)){
			// 리얼타임이체거래번호 채번생성 오류 : '리얼타임이체거래번호가 생성되지 않았습니다. 확인해주세요.'
			throw new ApplicationException("APPAE0057", new Object[]{"리얼타임이체거래번호"});
		}
		
		logger.debug("=========>> rltmTrsfPmpsNo <<=========" + rltmTrsfPmpsNo);
		
		logger.debug("=========>> input <<=========" + input);
		
		iResult = insertTrmsDcd(rltmTrsfTxNo, today, prcsHms, tgmNo, rltmTrsfPmpsNo, input);
		
		if(iResult != 1){
			
			// 2016.03.14;현승훈;입금,집금일 경우 출금이체동의 신청 처리 우선 선행
			// 처리코드별(업무별 구분코드) : 02-자동집금처리(입금,집금)
			if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){				//(02) 자동집금처리(입금,집금)
				wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "12", rltmTrsfPmpsNo);
			}
			
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장입력"});
		}
		
		iResult = 0;
		
		//2016.10.17;현승훈;
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){
			if (!StringUtils.isEmpty(input.getWtrsfAsntEvidDcd())) {
				dlngInfo = new WtrsfAsntDlngInfo();
				
//				dlngInfo.setWtrsfAsntDt(input.getWtrsfAsntDt());						// set [출금이체동의일자]
//				dlngInfo.setWtrsfAsntTi(input.getWtrsfAsntTi());						// set [출금이체동의시각]
				if (StringUtils.isEmpty(input.getWtrsfAsntDt())) {
					dlngInfo.setWtrsfAsntDt(today);											// set [출금이체동의일자]
				} else {
					dlngInfo.setWtrsfAsntDt(input.getWtrsfAsntDt());						// set [출금이체동의일자]
				}
				dlngInfo.setWtrsfAsntTi(prcsHms);										// set [출금이체동의시각]
				dlngInfo.setWtrsfAsntSysCd(input.getWtrsfAsntSysCd());					// set [출금이체동의시스템코드]				
				dlngInfo.setWtrsfAsntEvidDcd(input.getWtrsfAsntEvidDcd());				// set [출금이체동의증빙구분코드]
				dlngInfo.setWtrsfAsntEvidNo(input.getWtrsfAsntEvidNo());				// set [출금이체동의증빙번호]
				dlngInfo.setWtrsfAsntDcd(input.getWtrsfAsntDcd());						// set [출금이체동의구분코드]
				dlngInfo.setWtrsfAsntRcDcd(input.getWtrsfAsntRcDcd());					// set [출금이체동의접수구분코드]
				dlngInfo.setContNo(input.getContNo());									// set [계약번호]
				dlngInfo.setPmpsNo(rltmTrsfPmpsNo);										// set [납부자번호]
				dlngInfo.setContrNm(input.getContrNm());								// set [계약자명]
				dlngInfo.setPmpsDscNo(input.getAchdRrno());								// set [납부자식별번호]
				dlngInfo.setPmpsNm(input.getAchdNm());									// set [납부자명]
				dlngInfo.setFininCd(input.getBnkCd());									// set [금융기관코드]
				dlngInfo.setPmpsActNo(input.getActNo());								// set [납부자계좌번호]
				dlngInfo.setTrsfAmt(input.getTrsfAmt());								// set [이체금액]
				
				dlngInfo.setWtrsfAsntVcrecStrtDtm(input.getWtrsfAsntVcrecStrtDtm());	// set [출금이체동의녹취시작일시]
				dlngInfo.setWtrsfAsntVcrecEndDtm(input.getWtrsfAsntVcrecEndDtm());		// set [출금이체동의녹취종료일시]
				dlngInfo.setCentrNm(input.getCentrNm());								// set [센터명]
				dlngInfo.setTeamNm(input.getTeamNm());									// set [팀명]
				dlngInfo.setChrgpEno(input.getChrgpEno());								// set [담당자사원번호]
				dlngInfo.setChrgpNm(input.getChrgpNm());								// set [담당자명]
				
				dlngInfo.setBzTxRfDcd(input.getBzDcd());								// set [업무거래참조구분코드]
				dlngInfo.setBzTxRfNo(input.getBzTmKeyVl());								// set [업무거래참조번호]
				dlngInfo.setWtrsfAsntNrmYn("N");										// set [출금이체동의정상여부]
				
				
				//logger.debug("=========>> dlngInfo (TBCMETC015) 테이블 입력 : insert END <<=========" + dlngInfo);
				
				
				iResult = cmb040bean.callWtrsfAsntDlng(dlngInfo);
				
				if(iResult != 1){
					wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "12", rltmTrsfPmpsNo);
					// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
					throw new ApplicationException("APPAE0009", new Object[]{"출금이체동의처리내역입력"});
				}				
			}			
		}
		
		logger.debug("=========>> 송수신전문 전송보내기전 리얼타임이체원장(TBCMRTM001) 테이블 입력 : insert END <<=========");
		/******* 송수신전문 전송보내기전 리얼타임이체원장(TBCMRTM001) 테이블 입력 : insert END *******/
		
		String testDay		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
		// 처리코드별(업무별 구분코드) 업무분기 (각 전문전송업무 메소드 호출)
		if(RTCont.PRCSCD_01.equals(input.getPrcsCd())){				//(01) 자동이체처리 호출(송금,지급)
			
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 자동이체처리 호출(송금,지급)
				prcsInfo = cmb003bean.setAtrPrcsNewTest(input, tgmNo, rltmTrsfTxNo);
			} else {
				// KIB-NET 자동이체처리 호출(송금,지급)
				prcsInfo = cmb003bean.setAtrPrcsNew(input, tgmNo, rltmTrsfTxNo);
			}
			
		}else if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){		//(02) 자동집금처리(입금,집금)
			
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 자동집금처리(입금,집금)
				prcsInfo = cmb003bean.setDpsPrcsNewTest(input, tgmNo, rltmTrsfTxNo, rltmTrsfPmpsNo);
			} else {
				// KIB-NET 자동집금처리(입금,집금)
				prcsInfo = cmb003bean.setDpsPrcsNew(input, tgmNo, rltmTrsfTxNo, rltmTrsfPmpsNo);
			}
			
			//2016.10.17;현승훈;출금이체동의처리내역
			//입금결과가 정상일 경우
			if ("0000".equals(prcsInfo.getBnkAnswCd())) {
				//if (!StringUtils.isEmpty(input.getWtrsfAsntEvidDcd())) {
					
					if (StringUtils.isEmpty(input.getWtrsfAsntDt())) {							
						iResult = cmb040bean.updateWtrsfAnstDlng(input.getBzTmKeyVl(), today, "Y" );
					} else {
						iResult = cmb040bean.updateWtrsfAnstDlng(input.getBzTmKeyVl(), input.getWtrsfAsntDt(), "Y" );
					}
				//}			
			}			
		}else if(RTCont.PRCSCD_03.equals(input.getPrcsCd())){		//(03) 이체처리결과조회(이체확인)
			
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 이체처리결과조회(이체확인)
				prcsInfo = cmb003bean.setTrsfPrcsRstInqNewTest(input, tgmNo, rltmTrsfTxNo);
			} else {
				// KIB-NET 이체처리결과조회(이체확인)
				prcsInfo = cmb003bean.setTrsfPrcsRstInqNew(input, tgmNo, rltmTrsfTxNo);
			}
			
//			//2016.10.17;현승훈;출금이체동의처리내역
//			//입금결과가 정상일 경우
			if ("0000".equals(prcsInfo.getBnkAnswCd())) {
				if(RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){		// 입출금구분코드가 입금(1) 일 경우
					
					iResult = cmb040bean.updateWtrsfAnstDlng(input.getBzTmKeyVl(), "Y" );
					
					if(iResult != 1){
						wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "12", rltmTrsfPmpsNo);
						// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						throw new ApplicationException("APPAE0009", new Object[]{"출금이체동의처리내역입력"});
					}				
				}			
			}
		}else if(RTCont.PRCSCD_06.equals(input.getPrcsCd())){		//(06) 출금이체신청(납부자번호등록)
			
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 출금이체신청(납부자번호등록)
				prcsInfo = cmb003bean.setWdmTrsfApplNewTest(input, tgmNo, rltmTrsfTxNo, "");
			} else {
				// KIB-NET 출금이체신청(납부자번호등록)
				prcsInfo = cmb003bean.setWdmTrsfApplNew(input, tgmNo, rltmTrsfTxNo, "");
			}
			
		}else if(RTCont.PRCSCD_07.equals(input.getPrcsCd())){		//(07) 성명조회(예금주조회)
						
			//2017.03.24;현승훈;테스트를 위해 분기처리 
			if (Integer.parseInt(testDay) > Integer.parseInt("20170220") && Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				// KIB-NET 실명조회
				prcsInfo = cmb003bean.setRlnmInqNewTest(input, tgmNo, rltmTrsfTxNo);
			} else {
				// KIB-NET 실명조회
				prcsInfo = cmb003bean.setRlnmInqNew(input, tgmNo, rltmTrsfTxNo);
			}
			
		}else if(RTCont.PRCSCD_08.equals(input.getPrcsCd())){		//(08) 잔액조회 (이체모계좌조회)
			
			// KIB-NET 잔액조회
			prcsInfo = cmb003bean.setBamtInqNew(input, tgmNo, rltmTrsfTxNo);

		} else if(RTCont.PRCSCD_10.equals(input.getPrcsCd())){		//(10) 실명조회
			
			// KIB-NET 실명조회
			//prcsInfo = cmb003bean.setRlnmInq(input, tgmNo, rltmTrsfTxNo);
			prcsInfo = cmb003bean.setRecvInqNew(input, tgmNo, rltmTrsfTxNo);
		
		} else{
			// '유효하지않은 처리코드(업무별구분코드)입니다. 확인해주세요.', 오류 return
			throw new ApplicationException("APPAE0052", new Object[]{"처리코드(업무별구분코드)"});
			
		}
		
		/*********************** 인출일 경우 출금이체동의 해지 시작 START ***********************/
		// 2016.03.14;현승훈;입금,집금일 경우 출금이체동의 신청 처리 우선 선행
		// 처리코드별(업무별 구분코드) : 02-자동집금처리(입금,집금)
		if(RTCont.PRCSCD_02.equals(input.getPrcsCd())){				//(02) 자동집금처리(입금,집금)
			
			wtrsfAsntCd = prcsWtrsfAsntInfoNew(input.clone(), tgmNoBankCd, today, prcsHms, "12", rltmTrsfPmpsNo);
			
		}
		/*********************** 인출일 경우 출금이체동의 해지 종료 END ***********************/
		
		return prcsInfo;
	}
}

