package cigna.cm.b.bean;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.io.COM_F_KSNOAKSPO00001In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00001In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00003In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00004In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00005In;
import cigna.cm.b.io.COM_F_KSNOSKSFO00001In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00009In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00013In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00014In;
import cigna.cm.b.io.OSTGMDATAVERFINFOTESTIo;
import cigna.cm.b.io.SelectOneTBCMRTM0041Out;
import cigna.cm.b.io.TBCMRTM001Io;
import cigna.cm.b.io.TBCMRTM004Io;
import cigna.cm.b.io.TBCMRTM006Io;
import cigna.cm.b.io.TBCSFCR003Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;




/**
 * @file         cigna.cm.b.bean.CMB002BEAN.java
 * @filetype     java source file
 * @brief         지급이체자금이체송신처리_KS-NET
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                          성명                                                일자                                     변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 2. 4.       신규 작성
 *
 */
@KlafBean
public class CMB002BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB001DBIO cmb001dbio;		// 전문번호 체크
	
	@Autowired
	private CMBZ00BEAN cmbz00bean;		// RT 공통메소드 호출
	
	@Autowired
	private CMB001BEAN cmb001bean;		// 지급이체자금이체송수신처리_메인
	
	@Autowired
	private CMB004BEAN cmb004bean;		// 지급이체자금이체 수신처리
	
	/**
	 * 공통헤더부 세팅
	 * @param String bnkCd(3) 은행코드(3자리)
	 * @param OAKSNTKSNP000000000000In obj 공통부 OMM
	 * @param String tgmNo	전문번호
	 * @param String tgmCtgyCd	전문종별코드
	 * @param String bzDvsnCd	업무구분코드
	 * @param String chnlDcd	채널구분코드
	 * @return null  
	 * @throws ApplicationException
	 */
	public void setImtrSfchCommonHeader (String bnkCdInput, Object obj, String tgmNo, String tgmCtgyCd, String bzDvsnCd, String chnlDcd, String prcsCd) throws ApplicationException {
		String bnkCd = bnkCdInput;
	
		TBCMRTM006Io rtnResult = new TBCMRTM006Io();
//		String imtrsfChnlDcd = "01";		// 즉시이체채널구분코드
		String fininMgntCmpyCd = "";		// 금융기관관리업체코드
		String dscCd = "";					// 식별코드
		String todayHms = "";				// 오늘일자(YYYYMMDDHHMISS)
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
//		
//		todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
		
		todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		
		// 금융기관제휴업목록 테이블 조회 (금융기관관리업체코드 가져오기 위해)
		rtnResult = this.cmb001dbio.selectOneTBCMRTM0060(bnkCd, chnlDcd);
		
		SecuUtil.doDecObject(rtnResult);
				
		
		logger.debug("todayHms={}",todayHms);
		
		if(rtnResult != null && StringUtils.hasText(rtnResult.getFininMgntCmpyCd2()) && StringUtils.hasText(rtnResult.getFininMgntCmpyCd3()) ){
			//fininMgntCmpyCd = rtnResult.getFininMgntCmpyCd2();
			//에금주(성명)조회 일 경우 업체코드3 사용
			if (RTCont.PRCSCD_07.equals(prcsCd)) {
				fininMgntCmpyCd = rtnResult.getFininMgntCmpyCd3().concat(StringUtils.lpad("", 8 - rtnResult.getFininMgntCmpyCd2().trim().length(), " "));
			} else {
				fininMgntCmpyCd = rtnResult.getFininMgntCmpyCd2().concat(StringUtils.lpad("", 8 - rtnResult.getFininMgntCmpyCd2().trim().length(), " "));
			}
			
		}else{
			// 금융기관제휴업무목록 정보가 존재하지 않습니다.
			throw new ApplicationException("APPAE0051", null);
		}
		logger.debug("109 ==========================>");
//		
//		/*전문헤더 생성시 각 금융기관코드를 대표금융기관코드로 치환하여 번호를 생성하기 위해 추가코딩_20130507*/
		if(RTCont.FININCD_010.equals(bnkCd) || RTCont.FININCD_011.equals(bnkCd) || 
				RTCont.FININCD_012.equals(bnkCd) || RTCont.FININCD_013.equals(bnkCd) || 
					RTCont.FININCD_014.equals(bnkCd) || RTCont.FININCD_015.equals(bnkCd)){
			
			bnkCd = RTCont.FININCD_011;		// 농협
			
		}else if(RTCont.FININCD_071.equals(bnkCd) || RTCont.FININCD_072.equals(bnkCd) || 
					RTCont.FININCD_073.equals(bnkCd) || RTCont.FININCD_074.equals(bnkCd) || 
						RTCont.FININCD_075.equals(bnkCd)){
			
			bnkCd = RTCont.FININCD_071;		// 우체국
			
		}else if(RTCont.FININCD_045.equals(bnkCd) || RTCont.FININCD_046.equals(bnkCd)){
			bnkCd = RTCont.FININCD_045;		// 새마을금고
			
		}else if(RTCont.FININCD_048.equals(bnkCd) || RTCont.FININCD_049.equals(bnkCd)){
			bnkCd = RTCont.FININCD_048;		// 신용협동조합
			
		}else if(RTCont.FININCD_006.equals(bnkCd) || RTCont.FININCD_004.equals(bnkCd)){
			bnkCd = RTCont.FININCD_004;		// 국민은행 
		}
		
		logger.debug("134 ==========================>");
		/* 식별번호 세팅 */
		/* 2016.01.29;현승훈; 라이나 KS-NET RT은행:씨티은행, 새마을금고, 우체국 */
		/* 2016.01.29;현승훈; KS-NET 사용은행을 제외한 은행은 KIB-NET */
		// 은행코드가 씨티은행(27)이면
		if(RTCont.BNKCD_27.equals(bnkCd.substring(1))){
			//dscCd = "JCRL     ";
			dscCd = "1384     ";
		// 은행코드가 새마을금고(45)이면 업체코드
		}else if(RTCont.BNKCD_45.equals(bnkCd.substring(1))){
			//dscCd = "         ";
			dscCd = "1384     ";
		
		// 은행코드가 우체국(71)이면
		}else if(RTCont.BNKCD_71.equals(bnkCd.substring(1))){
			//dscCd = "         ";
			dscCd = "1384     ";
		// 그외 SPACE
		}else{
			/* 2016.02.02;현승훈;KS-NET 은행코드가 아닐 경우 오류 : 씨티은행(027), 새마을금고(045), 우체국(071) */
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "ks-net 처리은행코드(M)" });
		}

		//처리코드별(업무별 구분코드)로 공통헤더부분 세팅 
		if (RTCont.PRCSCD_01.equals(prcsCd))	
		{
			// 전문송신 KS-NET 헤더정보 세팅
			//(01) 자동이체처리 호출(송금,지급)  KS-NET
			((COM_F_KSNOSKSPO00001In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00001In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00001In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00001In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00001In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00001In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00001In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00001In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00001In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00001In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00001In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00001In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00001In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00001In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00001In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00001In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
		} else if (RTCont.PRCSCD_02.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(02) 자동집금처리(입금,집금)  KS-NET
			((COM_F_KSNOSKSPO00004In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00004In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00004In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00004In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00004In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00004In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00004In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00004In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00004In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00004In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00004In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00004In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00004In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00004In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00004In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00004In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		} else if (RTCont.PRCSCD_03.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(03) 이체처리결과조회(이체확인) KS-NET
			((COM_F_KSNOSKSPO00005In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00005In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00005In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00005In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00005In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00005In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00005In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00005In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00005In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00005In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00005In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00005In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00005In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00005In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00005In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00005In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		} else if (RTCont.PRCSCD_05.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(05) 집계처리 KS-NET
			((COM_F_KSNOSKSPO00014In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00014In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00014In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00014In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00014In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00014In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00014In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00014In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00014In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00014In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00014In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00014In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00014In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00014In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00014In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00014In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		} else if (RTCont.PRCSCD_06.equals(prcsCd) || RTCont.PRCSCD_11.equals(prcsCd) || RTCont.PRCSCD_12.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(06) 출금이체신청(납부자번호등록)
			((COM_F_KSNOSKSPO00003In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00003In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00003In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00003In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00003In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00003In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00003In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00003In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00003In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00003In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00003In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00003In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00003In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00003In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00003In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00003In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		} else if (RTCont.PRCSCD_07.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(07) 성명조회(예금주조회)
			((COM_F_KSNOSKSFO00001In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSFO00001In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSFO00001In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSFO00001In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSFO00001In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSFO00001In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSFO00001In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSFO00001In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSFO00001In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSFO00001In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSFO00001In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSFO00001In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSFO00001In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSFO00001In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSFO00001In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSFO00001In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		} else if (RTCont.PRCSCD_08.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(08) 잔액조회 (이체모계좌조회)
			((COM_F_KSNOSKSPO00013In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00013In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00013In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00013In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00013In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00013In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00013In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00013In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00013In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00013In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00013In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00013In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00013In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00013In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00013In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00013In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		} else if (RTCont.PRCSCD_08.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(08) 잔액조회 (이체모계좌조회)
			((COM_F_KSNOSKSPO00013In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00013In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00013In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00013In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00013In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00013In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00013In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00013In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00013In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00013In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00013In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00013In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00013In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00013In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00013In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00013In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		}
		/*
		 * Async
		else if (RTCont.PRCSCD_A1.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(A1) 업무개시
			((COM_F_KSNOAKSPO00001In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOAKSPO00001In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOAKSPO00001In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOAKSPO00001In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOAKSPO00001In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOAKSPO00001In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOAKSPO00001In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOAKSPO00001In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOAKSPO00001In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOAKSPO00001In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOAKSPO00001In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOAKSPO00001In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOAKSPO00001In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOAKSPO00001In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOAKSPO00001In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOAKSPO00001In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		} else if (RTCont.PRCSCD_A3.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(A3) 테스트콜
			((COM_F_KSNOAKSPO00001In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOAKSPO00001In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOAKSPO00001In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOAKSPO00001In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOAKSPO00001In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOAKSPO00001In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOAKSPO00001In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOAKSPO00001In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOAKSPO00001In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOAKSPO00001In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOAKSPO00001In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOAKSPO00001In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOAKSPO00001In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOAKSPO00001In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOAKSPO00001In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOAKSPO00001In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		}
		*/
		//Sync
		else if (RTCont.PRCSCD_A1.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(A1) 업무개시
			((COM_F_KSNOSKSPO00009In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00009In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00009In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00009In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00009In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00009In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00009In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00009In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00009In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00009In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00009In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00009In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00009In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00009In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00009In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00009In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		} else if (RTCont.PRCSCD_A3.equals(prcsCd)){
			// 전문송신 KS-NET 헤더정보 세팅
			//(A3) 테스트콜
			((COM_F_KSNOSKSPO00009In) obj).setDscCd(dscCd);								// set [식별코드]
			((COM_F_KSNOSKSPO00009In) obj).setCmpyCd(fininMgntCmpyCd);					// set [업체코드]
			((COM_F_KSNOSKSPO00009In) obj).setBnkCd2(bnkCd.substring(1));				// set [은행코드]
			((COM_F_KSNOSKSPO00009In) obj).setMsgCd(tgmCtgyCd);							// set [전문코드(메시지구분)]
			((COM_F_KSNOSKSPO00009In) obj).setBzDvsnCd(bzDvsnCd);						// set [업무구분코드]
			((COM_F_KSNOSKSPO00009In) obj).setSndmWdrw("1");							// set [전문송신횟수]
			((COM_F_KSNOSKSPO00009In) obj).setTgmNo(tgmNo.substring(1));				// set [전문일련번호]
			((COM_F_KSNOSKSPO00009In) obj).setTrmsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	// set [전송일자]
			((COM_F_KSNOSKSPO00009In) obj).setTrmsHms(todayHms);						// set [전송시간]
			((COM_F_KSNOSKSPO00009In) obj).setAnswCd(StringUtils.lpad("", 4, " "));	// set [응답코드]
			((COM_F_KSNOSKSPO00009In) obj).setBnkAnswCd(StringUtils.lpad("", 4, " "));	// set [은행응답코드]
			((COM_F_KSNOSKSPO00009In) obj).setInqDt(StringUtils.lpad("", 8, " "));		// set [조회일자]
			((COM_F_KSNOSKSPO00009In) obj).setInqNo(StringUtils.lpad("", 6, " "));		// set [조회번호]
			((COM_F_KSNOSKSPO00009In) obj).setBnkTgmNo(StringUtils.lpad("", 15, " "));	// set [은행전문번호]
			((COM_F_KSNOSKSPO00009In) obj).setBnkCd3(bnkCd);							// set [은행코드3자리]
			((COM_F_KSNOSKSPO00009In) obj).setPprn(StringUtils.lpad("", 13, " "));		// set [예비]
			
		}
		
		
	}
	
	/**
	 * 자동이체처리 호출(송금,지급) - 처리코드(01)
	 * @param trsfTrrvPrcsInfo  이체송수신처리정보
	 * @param tgmNo	전문번호
	 * @param rltmTrsfTxNo	리얼타임이체거래번호
	 * @return trsfTrrvPrcsInfo  이체송수신처리정보
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setAtrPrcs (TrsfTrrvPrcsInfo input, String tgmNo, String rltmTrsfTxNo) throws ApplicationException {
		
//		EISResponse<OAKSNTKSNP010010000000In> response = null;
//		OAKSNTKSNP010010000000In responseData = null;
//		List<SelectMultiTBCSFCR0010Out> out1 = null;
		TrsfTrrvPrcsInfo prcsInfo = new TrsfTrrvPrcsInfo();
		OSTGMDATAVERFINFOTESTIo verfInfo = new OSTGMDATAVERFINFOTESTIo();		// 복기부호 생성용 OMM
//		SelectOneTBCSPRF0014Out custInfo = new SelectOneTBCSPRF0014Out();
		TBCMRTM006Io rtnResult = new TBCMRTM006Io();
//		TBCSFCR003Io pmpsInfo =  new TBCSFCR003Io();
		TBCMRTM001Io realTmInfo = new TBCMRTM001Io();			// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		//SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회
		String tgmLogTxNo = "";
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();// (테스트용<삭제>)리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
	//	String imtrsfChnlDcd = "0001";							// 즉시이체채널구분코드
		String imtrsfChnlDcd ="";
		BigDecimal zero = BigDecimal.ZERO;
		
		
		EISResponse < COM_F_KSNOSKSPO00001In > response = null;
		
		COM_F_KSNOSKSPO00001In responseData = null;
		
	
		if(cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd())){
			imtrsfChnlDcd =input.getChnlDcd();
		}else{
			imtrsfChnlDcd ="0001";
		}
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);

		logger.debug("=========>> INPUT CHECK input        : CMB002BEAN {} <<=========", input);
		logger.debug("=========>> INPUT CHECK tgmNo        : CMB002BEAN {} <<=========", tgmNo);
		logger.debug("=========>> INPUT CHECK rltmTrsfTxNo : CMB002BEAN {} <<=========", rltmTrsfTxNo);

		try {
			
			
			// 필수입력값체크
			if (StringUtils.isEmpty(tgmNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "전문번호" });
			}
			
			if (StringUtils.isEmpty(rltmTrsfTxNo) || rltmTrsfTxNo.length() != 20) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "리얼타임이체거래번호" });
			}
			
//			if (StringUtils.isEmpty(input.getChnlDcd()) || input.getChnlDcd().length() != 4 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채널구분코드" });
//			} 
			
			if (input.getTrsfAmt() == null || input.getTrsfAmt().compareTo(zero) == 0 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "이체금액" });
			}
			
			if ((StringUtils.isEmpty(input.getActMgntNo()) &&//|| input.getActMgntNo().length() != 20) &&  __참조계좌관리번호가 20자리가 아닌값도 갖고있어 잠시 주석_20130128
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) )) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌관리번호" });
			}
			
			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드" });
			}
			
			if (StringUtils.isEmpty(input.getActNo())) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌번호" });
			} 
			
//			if (StringUtils.isEmpty(input.getAchdNm())) {
			if (StringUtils.isEmpty(input.getAchdNm()) &&      
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {	//채널에서 넘어온 데이터가 아닐 경우 추가_20121201)				
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "예금주명" });
			}
			
			if ((StringUtils.isEmpty(input.getAchdRrno()) || (input.getAchdRrno().length() != 13 && input.getAchdRrno().length() != 10)) &&
						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "예금주주민등록번호" });
			}
			
			if (StringUtils.isEmpty(input.getPrcsBnkCd()) || input.getPrcsBnkCd().length() != 3) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "처리은행코드" });
			}

			// 자동이체처리 호출(송금,지급) 전문송신 세팅용 변수 
			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
//			String txDt 		= today.substring(4);					// 거래일자 (today)
			String bnkCd3 		= input.getBnkCd();						// 은행코드3자리
			String bnkCd 		= input.getBnkCd().substring(1);		// 은행코드
			String actNo		= input.getActNo().concat(StringUtils.lpad("", 15 - input.getActNo().length(), " "));	// 계좌번호
//			String actNm		= "";									// 계좌성명
//			String rrno			= "";									// 주민번호
			String tgmCtgyCd 	= "";									// 전문종별코드
			String bzDvsnCd 	= "";									// 업무구분코드
			String prcsBnkCd 	= input.getPrcsBnkCd();					// 처리은행코드
			String prcsBnkCd2 	= input.getPrcsBnkCd().substring(1) ;					// 처리은행코드
			String dpsIndNm 	= "";									// 입금인성명
			String verfMrk		= "";									// 복기부호
			BigDecimal wdmAmt 	= input.getTrsfAmt();					// 출금금액(이체금액)
			String achdRrno		= "";									// 예금주주민등록번호
			String trmsDcd 		= "";									// 전송구분코드
//			String rltmTrsfPmpsNo = "";									// 납부자번호
			String tgmCont 		= "";									// 전문내용
			String prcsCd       = input.getPrcsCd();					// 거래코드
			
			COM_F_KSNOSKSPO00001In request = new COM_F_KSNOSKSPO00001In(); // EAI Interface request data(OMM)
			String interfaceId = "COM_F_KSNOSKSPO00001"; // EAI Interface ID
			
			
			logger.debug("=========>> Header Setting 전 : CMB002BEAN  <<=========");
			
			// 처리시간 (집계처리 호출(OMM) 세팅용)
//			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			
			// 공통헤더부 세팅 위한 은행별(제일은행 or KS-NET) 전문종별코드, 업무구분코드 정의 - 자동이체처리 호출(송금,지급)
			tgmCtgyCd = "0100";
			bzDvsnCd = "100";
			
			// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 자동이체처리 호출(송금,지급)시는 처리은행코드가 기준이 된다. (input.getPrcsBnkCd())
			setImtrSfchCommonHeader(prcsBnkCd, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd, prcsCd);
			
			// 금융기관제휴업목록 테이블 조회 (모계좌 추출)
			rtnResult = this.cmb001dbio.selectOneTBCMRTM0060(prcsBnkCd, imtrsfChnlDcd);
			
			SecuUtil.doDecObject(rtnResult);
			
			logger.debug("=========>> CMB002BEAN : 모계좌 추출후 : {} <<=========",rtnResult);
			
			// 입금인성명 조회
			dpsIndNm = cmb001bean.getDpsIndNm(input.getChnlDcd());
			
			logger.debug("=========>> CMB002BEAN : 입금인성명 추출후 : {} <<=========",dpsIndNm);
			
			// 예금주주민등록번호
			if(!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201

				
				if(input.getAchdRrno().length() != 10) {
					
					if(( "011".equals(input.getBnkCd()) || "012".equals(input.getBnkCd()))		//농협만 시행일자가 다름 
							 && today.compareTo("20140807") < 0) {
							achdRrno = input.getAchdRrno();
					} else {
						achdRrno = input.getAchdRrno().substring(0, 6).concat(StringUtils.lpad("", 7, " ")); //20140722
					}

				// 주민등록번호가 10자리(사업자등록번호) 일 경우 뒤에 ' '를 추가하여 세팅
				} else {
					achdRrno = input.getAchdRrno().concat(StringUtils.lpad("", 3, " "));
				}

			}
			
				
			/********** 복기부호 생성 (복기부호 필요OMM 세팅후 처리) START **********/
			
			try{
				verfInfo.setWdmActNo(rtnResult.getMoActNo().trim());	// set [출금계좌번호]
				verfInfo.setDpsActNo(input.getActNo());					// set [입금계좌번호]
				verfInfo.setWdmAmt(input.getTrsfAmt());					// set [출금금액] : 재정의 요함
				verfInfo.setTrmsDt(today);								// set [전송일자] : 재정의 요함
				verfInfo.setTrmsAmt(input.getTrsfAmt());				// set [전송금액] : 재정의 요함
				verfInfo.setTrsfAmt(input.getTrsfAmt());				// set [이체금액] : 재정의 요함
				verfInfo.setTrsfDtm(today.concat(todayHms));			// set [이체일시] : 재정의 요함
				verfInfo.setTgmNo(tgmNo);								// set [전문번호]
			//	verfInfo.setDpsBnkCd(bnkCd);							// set [입금은행코드] - 2자리
				verfInfo.setDpsBnkCd(prcsBnkCd2);							// set [입금은행코드] - 2자리
				verfInfo.setInputDt(today);								// set [입력일자] : 재정의 요함
				verfInfo.setTrmsHms(todayHms);							// set [전송시간] : 재정의 요함
				verfInfo.setInputHms(todayHms);							// set [입력시간] : 재정의 요함
				verfInfo.setDpsAmt(input.getTrsfAmt());					// set [입금금액] : 재정의 요함
				verfInfo.setPrcsCd(input.getPrcsCd());					// set 프로세스코드(입금,지급)
				verfInfo.setObjBnkCd(bnkCd3);							// set 입출금대상은행코드 [T1409260036]				
	
				verfMrk = cmb001bean.getTgmDataVerf(verfInfo);
				
			}catch (Exception e) {
				logger.error("Exception", e);
				
				// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
				prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
			}
			
			/********** 복기부호 생성 (복기부호 필요OMM 세팅후 처리) END **********/
			
			logger.debug("=========>> CMB002BEAN : 복기부호 생성후 : {} <<=========",verfMrk);
			

			// 자동이체처리 호출(송금,지급) 데이터 설정
			request.setWdmActNo(rtnResult.getMoActNo().trim().concat(StringUtils.lpad("", 15 - rtnResult.getMoActNo().trim().length(), " ")));	// set [출금계좌번호(모계좌번호)]
			request.setBkbkPswd(StringUtils.lpad("", 8, " "));			// set [통장비밀번호(모계좌비번)]
			request.setVerfMrk(verfMrk);								// set [복기부호]
			request.setWdmAmt(StringUtils.lpad("", 13 - wdmAmt.toString().length(), "0").concat(wdmAmt.toString()));	// set [출금금액(이체금액)]
			request.setWdmAfBamtMrk(StringUtils.lpad("", 1, " "));		// set [출금후잔액부호(+/-)]
			request.setWdmAfBamt(StringUtils.lpad("", 13, "0"));			// set [출금후잔액(원장잔액)]
			request.setDpsBnkCd2(StringUtils.lpad("", 2, " "));			// set [입금은행코드(자 계좌은행)]
			request.setDpsActNo(actNo);									// set [입금계좌번호(자 계좌)]
			request.setFee(StringUtils.lpad("", 9, "0"));			// set [수수료]
			request.setTrsfHms(todayHms);								// set [이체시각(HH:MM:SS)]
			request.setDpsActAbstr(dpsIndNm + StringUtils.lpad("", 20 - dpsIndNm.length(), " "));// set [입금인성명(자 계좌인자내용)]
			request.setCmsCd(StringUtils.lpad("", 16, " "));			// set [CMS CODE(SPACE)]
			request.setAchdRrno(achdRrno);								// set [고객주민번호]
			request.setAtrDvsn(StringUtils.lpad("", 2, " "));			// set [자동이체구분]

			//** 2015.05.22_김완진_23291_Start1
			if (input.getAchdNm().length() > 20) {
				logger.debug("##예금주명 길이초과 ==> {}, {}", input.getAchdNm(), input.getAchdNm().length());
				String tAchdNm	= input.getAchdNm().substring(0, 20);
				request.setWdmActAbstr(tAchdNm.concat(StringUtils.lpad("", 20 - tAchdNm.length(), " ")));	// set [입금계좌정보] => 예금주명 세팅함, 추후 확인요망
				logger.debug("##예금주명 길이수정 ==> {}, {}", tAchdNm, tAchdNm.length());
			} else {
				request.setWdmActAbstr(input.getAchdNm().concat(StringUtils.lpad("", 20 - input.getAchdNm().length(), " ")));	// set [입금계좌정보] => 예금주명 세팅함, 추후 확인요망
			}
			//** 2015.05.22_김완진_23291_End1
			
			request.setDpsBnkCd3(bnkCd3);								// set [입금은행코드3자리(자 계좌은행)]
//			request.setPprnSb(rltmTrsfTxNo + StringUtils.lpad("", 38 - rltmTrsfTxNo.length(), " "));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용) 세팅 ☆★☆★☆
//			request.setPprn2(rltmTrsfTxNo.concat(input.getOptnKey()).concat(StringUtils.lpad("", 37 - rltmTrsfTxNo.length(), " ")));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			request.setPprn2(StringUtils.lpad("", 37, " "));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆			
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업 (COMMA)
//			tgmCont = FwUtil.toCSV(request).replace(",", "");
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(request));

			// 송신전 세팅값 확인
			logger.debug("☆★☆★☆ ★☆ ====================> request 전문내용(tgmCont) START <==================== ★☆ ☆★☆★☆ ");
			logger.debug("☆★☆==========> tgmCont=[{}]", tgmCont);
			logger.debug("☆★☆★☆★☆  ====================> request 전문내용(tgmCont) END <==================== ★☆ ☆★☆★☆ ");
		
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE START ********************************/
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = this.cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			logger.debug("=========>> CMB002BEAN : 리얼타임전송전 이체마스터 업데이트 : {} <<=========",realTmInfo);
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 미전송(0)이 아닐경우 오류 : insert시 입력한 전송구분코드가 미전송(0) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_0.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				// 전송구분코드 미전송(0)을 전문발송전 전송(1)로 변경하여 세팅
				trmsDcd = RTCont.TRMSDCD_1;
			}
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE
			iResult = cmb001bean.updateTrmsDcd(trmsDcd, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE END ********************************/
			logger.debug("=========>> CMB002BEAN : 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE : {} <<=========",iResult);

			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
//			realTgmLog.setTgmLogPrcsDtm(today.concat(todayHms));	// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(prcsBnkCd);				// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);							// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			
//			// FEP call
//			InfUtil.callAsyncFEP(request, interfaceId);
//			
//
//			// 옵션키(A:aSync, S:sync) 가 'S'일 경우 sync 타입으로 각 업무파트로 return값을 세팅하여 전달_20130219
//			if(RTCont.OPTNKEY_S.equals(input.getOptnKey())){
//				
//				logger.debug("출금's rltmTrsfTxNo ===> {}", rltmTrsfTxNo);
//				
//				input.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//				prcsInfo = cmb001bean.syncOptnResponse(input);
//				
//				
//			}else{
//				prcsInfo = input;
//				prcsInfo.setPrcsBnkCd(prcsBnkCd);				// set [처리은행코드]
//				prcsInfo.setTrmsDcd(RTCont.TRMSDCD_1);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
//				prcsInfo.setPrcsHms(todayHms);					// set [처리시간]
//				prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//			}			
			
			String mode = LApplicationContext.getSystemMode();	 
			
			logger.debug("request---> {}",request);
			
			 //운영계
			//if("R".equals(mode)) {
			if("T".equals(mode)) {
			//if("R".equals(mode) || "D".equals(mode)) {  
				  
				  //3.동기화 방식 송신
				  response= InfUtil.callFEP(request, interfaceId, COM_F_KSNOSKSPO00001In.class);
				  
				  logger.debug("response---> {}",response);

				  responseData = response.getResponseData();					
				  
				  prcsInfo = cmb004bean.setAtrPrcs(responseData, rltmTrsfTxNo);
				  
					
			 //개발,테스트	  
//			 } else if( "T".equals(mode) || "D".equals(mode) ) {
			} else if( "R".equals(mode) || "D".equals(mode) ) {
			// } else if( "T".equals(mode)) {
			      
				  prcsInfo = input;
				  prcsInfo.setPrcsBnkCd(prcsBnkCd);				// set [처리은행코드]
				  prcsInfo.setTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : TRMSDCD_2(정상)]
				  prcsInfo.setPrcsHms(todayHms);				// set [처리시간]
				  prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);		// set [리얼타임이체거래번호]
				  prcsInfo.setBnkAnswCd("0000");				// set [은행결과코드]
				  
				  realTmSetInfo.setCmpyImtrsfRcd("0000");		// 업체즉시이체결과코드 : 응답코드 세팅
				  realTmSetInfo.setFininImtrsfRcd("0000");		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				  
				  //리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
				  iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
					
				  if(iResult != 1){
					  //SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						
					  throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
				  }
				  
			  } 

			
			   logger.debug("☆★☆==========> prcsInfo={}", prcsInfo);

		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
			
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}  catch (Exception e) {
			logger.error("Exception", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}
		
		return prcsInfo;
	}
	
	/**
	 * 자동집금처리 호출(입금,집금) - 처리코드(02)
	 * @param trsfTrrvPrcsInfo  이체송수신처리정보
	 * @param tgmNo	전문번호
	 * @param rltmTrsfTxNo	리얼타임이체거래번호
	 * @return trsfTrrvPrcsInfo  이체송수신처리정보
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setDpsPrcs (TrsfTrrvPrcsInfo input, String tgmNo, String rltmTrsfTxNo, String rltmTrsfPmpsNo) throws ApplicationException {
		
//		EISResponse<OAKSNTKSNP010050100000In> response = null;
//		OAKSNTKSNP010050100000In responseData = null;
//		List<SelectMultiTBCSFCR0010Out> out1 = null;
		TrsfTrrvPrcsInfo prcsInfo = new TrsfTrrvPrcsInfo();
		OSTGMDATAVERFINFOTESTIo verfInfo = new OSTGMDATAVERFINFOTESTIo();		// 복기부호 생성용 OMM
//		SelectOneTBCSPRF0014Out custInfo = new SelectOneTBCSPRF0014Out();
		TBCMRTM006Io rtnResult = new TBCMRTM006Io();
		TBCSFCR003Io pmpsInfo =  new TBCSFCR003Io();
		TBCMRTM001Io realTmInfo = new TBCMRTM001Io();			// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String imtrsfChnlDcd = "0002";							// 즉시이체채널구분코드
		String prcsCd       = input.getPrcsCd();					// 거래코드
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();// (테스트용<삭제>)리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		EISResponse < COM_F_KSNOSKSPO00004In > response = null;
		COM_F_KSNOSKSPO00004In responseData = null;
		
		BigDecimal zero = BigDecimal.ZERO;
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		try {
			COM_F_KSNOSKSPO00004In request = new COM_F_KSNOSKSPO00004In(); // EAI Interface request data(OMM)
			String interfaceId = "COM_F_KSNOSKSPO00004"; // EAI Interface ID

//			// 필수입력값체크
//			if (StringUtils.isEmpty(tgmNo)) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "전문번호" });
//			}
//			
//			if (StringUtils.isEmpty(rltmTrsfTxNo) || rltmTrsfTxNo.length() != 20) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "리얼타임이체거래번호" });
//			}
//			
////			if (StringUtils.isEmpty(input.getChnlDcd()) || input.getChnlDcd().length() != 4 ) {
////				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채널구분코드" });
////			} 
//			
//			if (input.getTrsfAmt() == null || input.getTrsfAmt().compareTo(zero) == 0 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "이체금액" });
//			}
//			
//			if ((StringUtils.isEmpty(input.getActMgntNo()) ) && // || input.getActMgntNo().length() != 20) &&
//						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌관리번호" });
//			}
//			
//			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드" });
//			}
//			
//			if (StringUtils.isEmpty(input.getActNo())) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌번호" });
//			} 
//			
//			if ((StringUtils.isEmpty(input.getAchdNm())) && 
//						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "예금주명" });
//			}
//			
//			if ((StringUtils.isEmpty(input.getAchdRrno()) || (input.getAchdRrno().length() != 13 && input.getAchdRrno().length() != 10)) &&
//						!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "예금주주민등록번호" });
//			}
			
//			if (StringUtils.isEmpty(input.getPrcsBnkCd()) || input.getPrcsBnkCd().length() != 3) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "처리은행코드" });
//			}
			

			// 자동집금처리 호출(입금,집금) 전문송신 세팅용 변수 
			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
//			String txDt 		= today.substring(4);					// 거래일자 (today)
			String bnkCd3 		= input.getBnkCd();						// 은행코드3자리
			String bnkCd 		= input.getBnkCd().substring(1);		// 은행코드
			String actNo		= input.getActNo().concat(StringUtils.lpad("", 15 - input.getActNo().length(), " "));		// 계좌번호
//			String actNm		= "";									// 계좌성명
//			String rrno			= "";									// 주민번호
			String tgmCtgyCd 	= "";									// 전문종별코드
			String bzDvsnCd 	= "";									// 업무구분코드
//			String prcsBnkCd 	= input.getPrcsBnkCd();					// 처리은행코드
			String wdmIndNm 	= "";									// 출금인성명
			String dpsIndNm 	= "";									// 입금인성명
			String verfMrk		= "";									// 복기부호
			String bkbkPswd		= "";									// 통장비밀번호
			String atrDvsn		= "";									// 자동이체구분
			BigDecimal dpsAmt 	= input.getTrsfAmt();					// 입금금액(이체금액)
			//String rltmTrsfPmpsNo = "";									// 납부자번호
			String achdRrno 	= "";									// 예금주주민등록번호
			String trmsDcd 		= "";									// 전송구분코드
			String tgmCont 		= "";									// 전문내용
			
			
		
			// 계좌관리번호로 리얼타임출금이체동의(TBCSFCR003) 조회하여 최종이력여부가 'Y'이면서 
			// 출금이체동의상태구분코드가 '1'인 경우만.. (납부자등록여부조회)
//			if(!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201
//				pmpsInfo = this.cmb001dbio.selectOneTBCSFCR0030(input.getActMgntNo());
//				
//				if(pmpsInfo != null){
//					if(!RTCont.WTRSF_ASNT_STA_ASNT.equals(pmpsInfo.getWtrsfAsntStaDcd())){
//						// 납부자등록 미등록사항 - '납부자등록이 미등록되었습니다. 확인해주세요.'
//						throw new ApplicationException("APPAE0054", null);
//					}else{
//						rltmTrsfPmpsNo = pmpsInfo.getRltmTrsfPmpsNo();
//					}
//				}else{
//					// 오류!!!! '리얼타임출금이체동의 내용이 존재하지 않습니다.'
//					throw new ApplicationException("APPAE0059", null);
//				}
//			}

			// 처리시간 (집계처리 호출(OMM) 세팅용)
			//todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			
			// 공통헤더부 세팅 위한 KS-NET 전문종별코드, 업무구분코드 정의 - 자동집금처리 호출(입금,집금)
			tgmCtgyCd = "0100";
			bzDvsnCd = "501";
			
			// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 자동집금처리 호출(입금,집금)시는 고객은행코드가 기준이 된다. (input.getBnkCd())
			setImtrSfchCommonHeader(bnkCd3, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd, prcsCd);
			
			// 금융기관제휴업목록 테이블 조회 (모계좌 추출)
			rtnResult = this.cmb001dbio.selectOneTBCMRTM0060(bnkCd3, imtrsfChnlDcd);
			
			SecuUtil.doDecObject(rtnResult);
			
			// 출금인성명 세팅
			wdmIndNm = "라이나생명";
			
			// 통장비밀번호(자계좌비번) 세팅
			if(RTCont.BNKCD_21.equals(bnkCd)){		// 조흥은행(21)이면 '00000000'세팅
				bkbkPswd = "00000000";
			}else{
				bkbkPswd = StringUtils.lpad("", 8, " ");
			}
			
			// 자동이체구분 세팅
			if(RTCont.BNKCD_20.equals(bnkCd) || RTCont.BNKCD_71.equals(bnkCd)){		// 우리은행(20) or 우체국(71)이면 '20'세팅
				atrDvsn = "20";
			}else{
				atrDvsn = StringUtils.lpad("", 2, " ");
			}
			
			// 입금인성명 세팅
			if(RTCont.BNKCD_11.equals(bnkCd)){		// 농협(11)이면 세팅
				//** 2015.05.22_김완진_23291_Start2
				//dpsIndNm = input.getAchdNm();		// 예금주명
				if (input.getAchdNm().length() > 20) {
					logger.debug("##(농협)예금주명 길이초과 ==> {}, {}", input.getAchdNm(), input.getAchdNm().length());
					dpsIndNm = input.getAchdNm().substring(0, 20);		// 입금인성명길이제한 (20자)
					logger.debug("##(농협)예금주명 길이수정 ==> {}, {}", dpsIndNm, dpsIndNm.length());
				} else {
					dpsIndNm = input.getAchdNm();		// 예금주명
				}
				//** 2015.05.22_김완진_23291_End2
			}else{			//농협외에는 space 세팅
				dpsIndNm = StringUtils.lpad("", 20, " ");
			}
			
			// 예금주주민등록번호
			if(!cmbz00bean.isTarget(RTCont.TRSFCHNLDCD_ERP, input.getChnlDcd()) ) {		//채널에서 넘어온 데이터가 아닐 경우 추가_20121201
				
				if(input.getAchdRrno().length() != 10) {
					if(( "011".equals(input.getBnkCd()) || "012".equals(input.getBnkCd()))		//농협만 시행일자가 다름 
							 && today.compareTo("20140807") < 0) {
							achdRrno = input.getAchdRrno();
					} else {
						achdRrno = input.getAchdRrno().substring(0, 6).concat(StringUtils.lpad("", 7, " ")); //20140722
					}
				} else {
				
					// 주민등록번호가 10자리(사업자등록번호) 일 경우 뒤에 ' '를 추가하여 세팅				
					achdRrno = input.getAchdRrno().concat(StringUtils.lpad("", 3, " "));
				}
			}
			
			
	       			
			/********** 복기부호 생성 (복기부호 필요OMM 세팅후 처리) START **********/
			
			try{
				verfInfo.setWdmActNo(input.getActNo());					// set [출금계좌번호]
				verfInfo.setDpsActNo(rtnResult.getMoActNo().trim());	// set [입금계좌번호]
				verfInfo.setWdmAmt(input.getTrsfAmt());					// set [출금금액] : 재정의 요함
				verfInfo.setTrmsDt(today);								// set [전송일자] : 재정의 요함
				verfInfo.setTrmsAmt(input.getTrsfAmt());				// set [전송금액] : 재정의 요함
				verfInfo.setTrsfAmt(input.getTrsfAmt());				// set [이체금액] : 재정의 요함
				verfInfo.setTrsfDtm(today.concat(todayHms));			// set [이체일시] : 재정의 요함
				verfInfo.setTgmNo(tgmNo);								// set [전문번호]
				verfInfo.setDpsBnkCd(bnkCd);							// set [입금은행코드] - 2자리
				verfInfo.setInputDt(today);								// set [입력일자] : 재정의 요함
				verfInfo.setTrmsHms(todayHms);							// set [전송시간] : 재정의 요함
				verfInfo.setInputHms(todayHms);							// set [입력시간] : 재정의 요함
				verfInfo.setDpsAmt(input.getTrsfAmt());					// set [입금금액] : 재정의 요함
				verfInfo.setPrcsCd(input.getPrcsCd());					// set 프로세스코드(입금,지급)
				verfInfo.setObjBnkCd(bnkCd3);							// set 입출금대상은행코드 [T1409260036]
				
				verfMrk = cmb001bean.getTgmDataVerf(verfInfo);
				
			}catch (Exception e) {
				logger.error("Exception", e);
				
				// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
				prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
			}
			
			/********** 복기부호 생성 (복기부호 필요OMM 세팅후 처리) END **********/
				
			String  fininMgntCmpyCd3 ="";
			if(rtnResult != null && StringUtils.hasText(rtnResult.getFininMgntCmpyCd3())){
				  fininMgntCmpyCd3 = rtnResult.getFininMgntCmpyCd3();
			}else{
				// 금융기관제휴업무목록 정보가 존재하지 않습니다.
				throw new ApplicationException("APPAE0051", null);
			}
			
			// 자동집금처리 호출(입금,집금) 데이터 설정
			request.setWdmActNo(actNo);								// set [출금계좌번호(자계좌번호)]
			request.setBkbkPswd(bkbkPswd);							// set [통장비밀번호(자계좌비번)]
			request.setVerfMrk(verfMrk);							// set [복기부호]
			request.setDpsAmt(StringUtils.lpad("", 13 - dpsAmt.toString().length(), "0").concat(dpsAmt.toString()));	// set [입금금액]
			request.setDpsAfBamtMrk(StringUtils.lpad("", 1, " "));	// set [입금후잔액부호(+/-)(모계좌)]
			request.setDpsAfBamt(StringUtils.lpad("", 13, "0"));		// set [입금후잔액(모계좌번호)]
			request.setWdmBnkCd2(StringUtils.lpad("", 2, " "));		// set [출금은행코드(자 계좌은행)]
			request.setDpsActNo(rtnResult.getMoActNo().trim().concat(StringUtils.lpad("", 15 - rtnResult.getMoActNo().trim().length(), " ")));	// set [입금계좌번호(모 계좌)]
			request.setFee(StringUtils.lpad("", 9, "0"));		// set [이체수수료]
			request.setTrsfHms(todayHms);							// set [이체시각(HH:MM:SS)]
			request.setWdmBkbkAbstr(wdmIndNm + StringUtils.lpad("", 20 - wdmIndNm.length(), " "));	// set [출금인성명(자 계좌인자내용)]
//			request.setWdmBkbkAbstr(wdmIndNm);	// set [출금인성명(자 계좌인자내용)]
			request.setAchdRrno(achdRrno);						// set [주민번호(자 계좌 주민번호)]
			request.setAtrDvsn(atrDvsn);							// set [자동이체구분('20' SET)]
			request.setDpsAfBamtMrk(dpsIndNm.concat(StringUtils.lpad("", 20 - dpsIndNm.length(), " ")));	// set [입금인성명(모 계좌통장인자(농협))]
			request.setPmpsNo(rltmTrsfPmpsNo.concat(StringUtils.lpad("", 20 - rltmTrsfPmpsNo.length(), " ")));	// set [납부자번호]
//			request.setInstCd(StringUtils.lpad("", 10, " "));		// set [기관코드]
			request.setInstCd(fininMgntCmpyCd3);		// set [기관코드]			
			request.setWdmBnkCd3(bnkCd3);							// set [출금은행코드3자리(자 계좌은행)]
			request.setSmsCrtfCd(StringUtils.lpad("", 6, " "));		//SMS인증코드
			request.setMgntNo(StringUtils.lpad("", 6, " "));		//관리번호
//			request.setPprn2(rltmTrsfTxNo.concat(input.getOptnKey()).concat(StringUtils.lpad("", 12 - rltmTrsfTxNo.length(), " ")));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			request.setPprn2(StringUtils.lpad("", 12, " "));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
						
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업 (COMMA)
//			tgmCont = FwUtil.toCSV(request).replace(",", "");
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(request));
			
			// 송신전 세팅값 확인
			logger.debug("☆★☆★☆ ★☆ ====================> request 전문내용(tgmCont) START <==================== ★☆ ☆★☆★☆ ");
			logger.debug("☆★☆==========> tgmCont={}", tgmCont);
			logger.debug("☆★☆★☆★☆  ====================> request 전문내용(tgmCont) END <==================== ★☆ ☆★☆★☆ ");
		
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE START ********************************/
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = this.cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 미전송(0)이 아닐경우 오류 : insert시 입력한 전송구분코드가 미전송(0) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_0.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				// 전송구분코드 미전송(0)을 전문발송전 전송(1)로 변경하여 세팅
				trmsDcd = RTCont.TRMSDCD_1;
			}
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE
			iResult = cmb001bean.updateTrmsDcd(trmsDcd, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE END ********************************/
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
//			realTgmLog.setTgmLogPrcsDtm(today.concat(todayHms));	// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(bnkCd3);					// set [이체처리금융기관코드] : 입금은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);							// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			
			// FEP call
//			InfUtil.callAsyncFEP(request, interfaceId);
//			
//			// 옵션키(A:aSync, S:sync) 가 'S'일 경우 sync 타입으로 각 업무파트로 return값을 세팅하여 전달_20130219
//			if(RTCont.OPTNKEY_S.equals(input.getOptnKey())){
//				
//				logger.debug("입금's rltmTrsfTxNo ===> {}", rltmTrsfTxNo);
//				
//				input.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//				prcsInfo = cmb001bean.syncOptnResponse(input);
//				
//			}else{
//				prcsInfo = input;
//				prcsInfo.setPrcsBnkCd(bnkCd3);					// set [처리은행코드]
//				prcsInfo.setTrmsDcd(RTCont.TRMSDCD_1);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
//				prcsInfo.setPrcsHms(todayHms);					// set [처리시간]
//				prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//			}
			
			String mode = LApplicationContext.getSystemMode();	 
			 
			logger.debug("request---> {}",request);
			
			 //운영계
			//if("R".equals(mode)) {
			if("T".equals(mode)) {
			//if("R".equals(mode) || "D".equals(mode)) {  
				  
				  //3.동기화 방식 송신
				  response= InfUtil.callFEP(request, interfaceId, COM_F_KSNOSKSPO00004In.class);
				  
				  logger.debug("response---> {}",response);

				  responseData = response.getResponseData();
					
				  prcsInfo = cmb004bean.setDpsPrcs(responseData, rltmTrsfTxNo);
				  
					
			 //개발,테스트	  
			//} else if( "T".equals(mode) || "D".equals(mode) ) {
			} else if( "R".equals(mode) || "D".equals(mode) ) {
			//} else if("T".equals(mode)) {
			      
				  prcsInfo = input;
				  
				  prcsInfo.setPrcsBnkCd(bnkCd3);				// set [처리은행코드]
				  prcsInfo.setTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
				  prcsInfo.setPrcsHms(todayHms);				// set [처리시간]
				  prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);		// set [리얼타임이체거래번호]
				  prcsInfo.setBnkAnswCd("0000");				// set [은행결과코드]
				  
				  realTmSetInfo.setCmpyImtrsfRcd("0000");		// 업체즉시이체결과코드 : 응답코드 세팅
				  realTmSetInfo.setFininImtrsfRcd("0000");		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				  realTmSetInfo.setRltmTrsfPmpsNo(rltmTrsfPmpsNo);//리얼타임이체납부자번호
				  
				  //리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
				  iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
					
				  if(iResult != 1){
					  //SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						
					  throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
				  }
				  
			  } 
			
			logger.debug("☆★☆==========> prcsInfo={}", prcsInfo);

		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);

		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}  catch (Exception e) {
			logger.error("Exception", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}
		
		return prcsInfo;
	}
	
	/**
	 * 이체처리결과조회(이체확인) - 처리코드(03)
	 * @param trsfTrrvPrcsInfo  이체송수신처리정보
	 * @param tgmNo	전문번호
	 * @param rltmTrsfTxNo	리얼타임이체거래번호
	 * @return trsfTrrvPrcsInfo  이체송수신처리정보
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setTrsfPrcsRstInq (TrsfTrrvPrcsInfo input, String tgmNo, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo prcsInfo = new TrsfTrrvPrcsInfo();
		TBCMRTM001Io realTmInfo = new TBCMRTM001Io();			// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String prcsCd   = input.getPrcsCd();					// 거래코드
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();// (테스트용<삭제>)리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		EISResponse < COM_F_KSNOSKSPO00005In > response = null;
		COM_F_KSNOSKSPO00005In responseData = null;
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		try {
			COM_F_KSNOSKSPO00005In request = new COM_F_KSNOSKSPO00005In(); // EAI Interface request data(OMM)
			String interfaceId = "COM_F_KSNOSKSPO00005"; // EAI Interface ID

			// 필수입력값체크
			if (StringUtils.isEmpty(tgmNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "전문번호" });
			}
			
			if (StringUtils.isEmpty(rltmTrsfTxNo) || rltmTrsfTxNo.length() != 20) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "리얼타임이체거래번호" });
			}
			
			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드" });
			}
			
			if (StringUtils.isEmpty(input.getPrcsBnkCd()) || input.getPrcsBnkCd().length() != 3) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "처리은행코드" });
			}
			
			// 이체처리결과조회(이체확인) 전문송신 세팅용 변수 
			String bnkCd3 		= input.getBnkCd();						// 은행코드3자리
			String tgmCtgyCd 	= "";									// 전문종별코드
			String bzDvsnCd 	= "";									// 업무구분코드
			String prcsBnkCd 	= input.getPrcsBnkCd();					// 처리은행코드
			String trmsDcd 		= "";									// 전송구분코드
			String tgmCont 		= "";									// 전문내용
			
					
			// 처리시간 (집계처리 호출(OMM) 세팅용)
//			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			
			// 공통헤더부 세팅 위한 KS-NET 전문종별코드, 업무구분코드 정의 - 이체처리결과조회(이체확인)
			tgmCtgyCd = "0600";
			bzDvsnCd = "101";
			
			// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 이체처리결과조회(이체확인)시는 고객은행코드가 기준이 된다. (input.getBnkCd())
			if(RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){		// 입출금구분코드가 입금(1) 일 경우
				setImtrSfchCommonHeader(bnkCd3, request, tgmNo, tgmCtgyCd, bzDvsnCd, "0002", prcsCd);
			}else{
				setImtrSfchCommonHeader(prcsBnkCd, request, tgmNo, tgmCtgyCd, bzDvsnCd, "0001", prcsCd);
			}			
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE START ********************************/
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = this.cmb001dbio.selectOneTBCMRTM0010(input.getRltmTrsfTxNo());
			SecuUtil.doDecObject(realTmInfo);
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE FIRST END ********************************/
			
			// 이체처리결과조회(이체확인) 데이터 설정
			request.setOrgtrTgmNo(realTmInfo.getRltmTgmNo().substring(1,7));		// set [원거래 전문번호(이체전문번호)]
			request.setWdmActNo(StringUtils.lpad("", 15, " "));						// set [출금계좌번호]
			request.setDpsActNo(StringUtils.lpad("", 15, " "));						// set [입금계좌번호]
			request.setAmt(StringUtils.lpad("", 13, " "));							// set [금액]
			request.setFee(StringUtils.lpad("", 9, " "));							// set [수수료]
			request.setPayNo(StringUtils.lpad("", 15, " "));						// set [지급번호]
			request.setPrcsRst(StringUtils.lpad("", 4, " "));						// set [처리결과]
			request.setIdcsBnkCd2(StringUtils.lpad("", 2, " "));					// set [개별은행코드2]
			request.setPmpsNo(StringUtils.lpad("", 20, " "));						// set [납부자번호]
			
			// 리얼타임이체거래번호로 리얼타임이체원장(TBCMRTM001) 조회, 입출금구분코드가 입금(1) 일 경우 
			if(RTCont.DPWD_DCD_DPS.equals(realTmInfo.getDpwdDcd())){
				// 조흥은행 집금이체 결과조회의 경우 '20' 세팅 : 이체처리금융기관코드 세팅했음, 확인요함
				if(RTCont.BNKCD_21.equals(realTmInfo.getTrsfPrcsFininCd())){
					request.setTxDvsn("20");// set [거래구분(조흥,제일만사용)]
				}
			
			// 리얼타임이체거래번호로 리얼타임이체원장(TBCMRTM001) 조회, 입출금구분코드가 출금(2) 일 경우
			}else if(RTCont.DPWD_DCD_WDM.equals(realTmInfo.getDpwdDcd())){
				// 제일은행 송금이체 결과조회의 경우 '30' 세팅 : 이체처리금융기관코드 세팅했음, 확인요함
				if(RTCont.BNKCD_23.equals(realTmInfo.getTrsfPrcsFininCd())){
					request.setTxDvsn("30");// set [거래구분(조흥,제일만사용)]
				}
				
			}else{
				request.setTxDvsn(StringUtils.lpad("", 2, " "));		// set [거래구분(조흥,제일만사용)]
			}
			
			request.setIdcsBnkCd3(StringUtils.lpad("", 3, " "));		// set [출금은행코드3자리(출금된은행)]
//			request.setPprn2(input.getRltmTrsfTxNo().concat(input.getOptnKey()).concat(StringUtils.lpad("", 89 - rltmTrsfTxNo.length(), " ")));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			request.setPprn2(StringUtils.lpad("", 89, " "));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(request));

			// 송신전 세팅값 확인
			logger.debug("☆★☆★☆ ★☆ ====================> request 전문내용(tgmCont) START <==================== ★☆ ☆★☆★☆ ");
			logger.debug("☆★☆==========> tgmCont={}", tgmCont);
			logger.debug("☆★☆★☆★☆  ====================> request 전문내용(tgmCont) END <==================== ★☆ ☆★☆★☆ ");
		
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 미전송(0)이 아닐경우 오류 : insert시 입력한 전송구분코드가 미전송(0) 이므로..
		/*	if(realTmInfo == null || !PAZ500BEAN.TRMSDCD_0.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{*/
				// 전송구분코드 미전송(0)을 전문발송전 전송(1)로 변경하여 세팅
				trmsDcd = RTCont.TRMSDCD_1;
		/*	}*/
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE
			iResult = cmb001bean.updateTrmsDcd(trmsDcd, rltmTrsfTxNo);
			
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE END ********************************/
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/

			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]

			//realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
//			realTgmLog.setTgmLogPrcsDtm(today.concat(todayHms));	// set [전문로그처리일시]
			
			if(RTCont.DPWD_DCD_DPS.equals(realTmInfo.getDpwdDcd())){	// 입출금구분코드가 입금(1)일 경우
				realTgmLog.setTrsfPrcsFininCd(bnkCd3);				// set [이체처리금융기관코드] : 입금은행코드 세팅함 - 금융기관코드(3)
				
			}else if(RTCont.DPWD_DCD_WDM.equals(realTmInfo.getDpwdDcd())){
				realTgmLog.setTrsfPrcsFininCd(prcsBnkCd);			// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			}
			
			realTgmLog.setRltmTgmNo(tgmNo);							// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			
			// FEP call
//			InfUtil.callAsyncFEP(request, interfaceId);
//			
//			// 옵션키(A:aSync, S:sync) 가 'S'일 경우 sync 타입으로 각 업무파트로 return값을 세팅하여 전달_20130219
//			if(RTCont.OPTNKEY_S.equals(input.getOptnKey())){
//				input.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//				prcsInfo = cmb001bean.syncOptnResponse(input);
//				
//			}else{
//				prcsInfo = input;
//				
//				if(RTCont.DPWD_DCD_DPS.equals(realTmInfo.getDpwdDcd())){	// 입출금구분코드가 입금(1)일 경우
//					prcsInfo.setPrcsBnkCd(bnkCd3);				// set [처리은행코드]
//					
//				}else if(RTCont.DPWD_DCD_WDM.equals(realTmInfo.getDpwdDcd())){
//					prcsInfo.setPrcsBnkCd(prcsBnkCd);				// set [처리은행코드]
//				}
//				
//				prcsInfo.setTrmsDcd(RTCont.TRMSDCD_1);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
//				prcsInfo.setPrcsHms(todayHms);					// set [처리시간]
//				prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//			}
			
			String mode = LApplicationContext.getSystemMode();	 
			 
			 //운영계
			//if("R".equals(mode)) {
			if("T".equals(mode)) {
			//if("R".equals(mode) || "D".equals(mode)) { 				
				 
				  //3.동기화 방식 송신
				  response= InfUtil.callFEP(request, interfaceId, COM_F_KSNOSKSPO00005In.class);
				  
				  logger.debug("response---> {}",response);

				  responseData = response.getResponseData();
				  
				  prcsInfo = cmb004bean.setTrsfPrcsRstInq(responseData, rltmTrsfTxNo);
					
			 //개발,테스트	  
			  //} else if("D".equals(mode) || "T".equals(mode)) {
			} else if( "R".equals(mode) || "D".equals(mode) ) {
			  //} else if("T".equals(mode)) {
			      
				  prcsInfo = input;
					
				  if(RTCont.DPWD_DCD_DPS.equals(realTmInfo.getDpwdDcd())){	// 입출금구분코드가 입금(1)일 경우
					  prcsInfo.setPrcsBnkCd(bnkCd3);			// set [처리은행코드]
	
				  }else if(RTCont.DPWD_DCD_WDM.equals(realTmInfo.getDpwdDcd())){
					  prcsInfo.setPrcsBnkCd(prcsBnkCd);			// set [처리은행코드]
				  }

				  prcsInfo.setTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
				  prcsInfo.setPrcsHms(todayHms);				// set [처리시간]
				  prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);		// set [리얼타임이체거래번호]
				  prcsInfo.setBnkAnswCd("0000");				// set [은행결과코드]
				  
				  realTmSetInfo.setCmpyImtrsfRcd("0000");		// 업체즉시이체결과코드 : 응답코드 세팅
				  realTmSetInfo.setFininImtrsfRcd("0000");		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				  
				  //리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
				  iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
					
				  if(iResult != 1){
					  //SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						
					  throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
				  }
				  
			  } 
			
			logger.debug("☆★☆==========> prcsInfo={}", prcsInfo);

		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
			
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		} catch (Exception e) {
			logger.error("Exception", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}
		
		return prcsInfo;
	}
	
	/**
	 * 집계처리 - 처리코드(05)
	 * @param trsfTrrvPrcsInfo  이체송수신처리정보
	 * @param tgmNo	전문번호
	 * @param rltmTrsfTxNo	리얼타임이체거래번호
	 * @return trsfTrrvPrcsInfo  이체송수신처리정보
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setTotPrcs (TrsfTrrvPrcsInfo input, String tgmNo, String rltmTrsfTxNo) throws ApplicationException {
		
//		EISResponse<OAKSNTKSNP070010000000In> response = null;
//		OAKSNTKSNP070010000000In responseData = null;
//		List<SelectMultiTBCSFCR0010Out> out1 = null;
		TrsfTrrvPrcsInfo prcsInfo = new TrsfTrrvPrcsInfo();
//		OSTGMDATAVERFINFOTESTIo verfInfo = new OSTGMDATAVERFINFOTESTIo();		// 복기부호 생성용 OMM
//		SelectOneTBCSPRF0014Out custInfo = new SelectOneTBCSPRF0014Out();
		TBCMRTM006Io rtnResult = new TBCMRTM006Io();
//		TBCSFCR003Io pmpsInfo =  new TBCSFCR003Io();
		TBCMRTM001Io realTmInfo = new TBCMRTM001Io();			// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String imtrsfChnlDcd_1 = "0001";						// 즉시이체채널구분코드
		String imtrsfChnlDcd_2 = "0002";						// 즉시이체채널구분코드
		String prcsCd   = input.getPrcsCd();					// 거래코드
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();// (테스트용<삭제>)리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		EISResponse < COM_F_KSNOSKSPO00014In > response = null;
		COM_F_KSNOSKSPO00014In responseData = null;
//		BigDecimal zero = BigDecimal.ZERO;
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		try {
			COM_F_KSNOSKSPO00014In request = new COM_F_KSNOSKSPO00014In(); // EAI Interface request data(OMM)
			String interfaceId = "COM_F_KSNOSKSPO00014"; // EAI Interface ID

			// 필수입력값체크
			if (StringUtils.isEmpty(tgmNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "전문번호" });
			}
			
			if (StringUtils.isEmpty(rltmTrsfTxNo) || rltmTrsfTxNo.length() != 20) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "리얼타임이체거래번호" });
			}
			
			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드" });
			}
			
			if (StringUtils.isEmpty(input.getPrcsBnkCd()) || input.getPrcsBnkCd().length() != 3) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "처리은행코드" });
			}
			
//			if (StringUtils.isEmpty(input.getChnlDcd()) || input.getChnlDcd().length() != 4 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채널구분코드" });
//			} 
			

			// 집계처리 전문송신 세팅용 변수 
//			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
//			String txDt 		= today.substring(4);					// 거래일자 (today)
			String bnkCd3 		= input.getBnkCd();						// 은행코드3자리
//			String bnkCd 		= input.getBnkCd().substring(1);		// 은행코드
//			String actNo		= input.getActNo() + StringUtils.lpad("", 15 - input.getActNo().length(), " ");		// 계좌번호
//			String actNm		= "";									// 계좌성명
//			String rrno			= "";									// 주민번호
			String tgmCtgyCd 	= "";									// 전문종별코드
			String bzDvsnCd 	= "";									// 업무구분코드
			String prcsBnkCd 	= input.getPrcsBnkCd();					// 처리은행코드
//			String wdmIndNm 	= "";									// 출금인성명
//			String dpsIndNm 	= "";									// 입금인성명
//			String verfMrk		= "";									// 복기부호
//			String bkbkPswd		= "";									// 통장비밀번호
//			String atrDvsn		= "";									// 자동이체구분
//			BigDecimal dpsAmt 	= input.getTrsfAmt();					// 입금금액(이체금액)
//			String rltmTrsfPmpsNo = "";									// 납부자번호
//			String achdRrno 	= "";									// 예금주주민등록번호
			String trmsDcd 		= "";									// 전송구분코드
			String tgmCont 		= "";									// 전문내용
			
			// 공통헤더부 세팅 위한 KS-NET 전문종별코드, 업무구분코드 정의 - 출금이체신청(납부자번호등록)
			tgmCtgyCd = "0700";
			bzDvsnCd = "100";
			
			// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 출금이체신청(납부자번호등록)시는 고객은행코드가 기준이 된다. (input.getBnkCd())
			setImtrSfchCommonHeader(bnkCd3, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd_2, prcsCd);
				
			
			/********  납부자등록여부 집계처리에서도 필요없는것인가??????????????  *******/
			
//			// 계좌관리번호로 리얼타임출금이체동의(TBCSFCR003) 조회하여 최종이력여부가 'Y'이면서 
//			// 출금이체동의상태구분코드가 '1'인 경우만.. (납부자등록여부조회)
//			pmpsInfo = pam005dbio.selectOneTBCSFCR0030(input.getActMgntNo());
//			
//			if(!PAZ500BEAN.WTRSF_ASNT_STA_ASNT.equals(pmpsInfo.getWtrsfAsntStaDcd())){
//				// 납부자등록 미등록사항 - '납부자등록이 미등록되었습니다. 확인해주세요.'
//				throw new ApplicationException("APPAE0054", null);
//			}else{
//				rltmTrsfPmpsNo = pmpsInfo.getRltmTrsfPmpsNo();
//			}

			// 고객번호로 주민번호 조회 - 주민번호를 직접받기로 함
//			custInfo = pam005dbio.selectOneTBCSPRF0014(input.getAchdCustNo());
//			rrno = custInfo.getCustDscNo();
			
			/* 자동이체처리 업무에서는 주민등록번호를 사용하지 않음, 사용한다면 해당주석을 활성화
			rrno = input.getAchdRrno();		// 주민등록번호
			
			// 주민등록번호가 10자리(사업자등록번호) 일 경우 앞에 '999'를 추가하여 세팅
			if(rrno.length() == 10){
				rrno = "999" + input.getAchdRrno();
			}
			*/
			
			// 처리시간 (집계처리 호출(OMM) 세팅용)
//			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			
			// 공통헤더부 세팅 위한 KS-NET 전문종별코드, 업무구분코드 정의 - 집계처리
			tgmCtgyCd = "0700";
			bzDvsnCd = "100";

			// 금융기관제휴업목록 테이블 조회 (모계좌 추출)
			if(RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){		// 입출금구분코드가 입금(1)일 경우
				// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 집계처리시는 고객은행코드가 기준이 된다. (input.getBnkCd())
				setImtrSfchCommonHeader(bnkCd3, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd_2, prcsCd);
				
				rtnResult = this.cmb001dbio.selectOneTBCMRTM0060(bnkCd3, imtrsfChnlDcd_2);
				
			}else if(RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd())){		// 입출금구분코드가 출금(2)일 경우
				// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 집계처리시는 처리은행코드가 기준이 된다. (input.getPrcsBnkCd())
				setImtrSfchCommonHeader(prcsBnkCd, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd_1, prcsCd);
				
				rtnResult = cmb001dbio.selectOneTBCMRTM0060(prcsBnkCd, imtrsfChnlDcd_1);
			}
			
			SecuUtil.doDecObject(rtnResult);
			
			// 집계처리 데이터 설정
			request.setActNo(rtnResult.getMoActNo().trim().concat(StringUtils.lpad("", 15 - rtnResult.getMoActNo().trim().length(), " ")));	// set [지급(입금)계좌번호] - 업체모계좌 세팅했음
			request.setTrsfRqstCnt(StringUtils.lpad("", 5, "0"));		// set [당행이체의뢰건수]
			request.setTrsfRqstAmt(StringUtils.lpad("", 13, "0"));		// set [당행이체의뢰금액]
			request.setTrsfNrmCnt(StringUtils.lpad("", 5, "0"));		// set [당행이체정상건수]
			request.setTrsfNrmAmt(StringUtils.lpad("", 13, "0"));		// set [당행이체정상금액]
			request.setTrsfImpCnt(StringUtils.lpad("", 5, "0"));		// set [당행이체불능건수]
			request.setTrsfImpAmt(StringUtils.lpad("", 13, "0"));		// set [당행이체불능금액]
			request.setFee(StringUtils.lpad("", 9, "0"));				// set [수수료]
			request.setObnkTrsfRqstCnt(StringUtils.lpad("", 5, "0"));	// set [타행이체의뢰건수]
			request.setObnkTrsfRqstAmt(StringUtils.lpad("", 13, "0"));	// set [타행이체의뢰금액]
			request.setObnkTrsfNrmCnt(StringUtils.lpad("", 5, "0"));	// set [타행이체정상건수]
			request.setObnkTrsfNrmAmt(StringUtils.lpad("", 13, "0"));	// set [타행이체정상금액]
			request.setObnkTrsfImpCnt(StringUtils.lpad("", 5, "0"));	// set [타행이체불능건수]
			request.setObnkTrsfImpAmt(StringUtils.lpad("", 13, "0"));	// set [타행이체불능금액]
			request.setObnkTrsfFee(StringUtils.lpad("", 9, "0"));		// set [타행이체수수료]
			request.setPrcsDvsn(StringUtils.lpad("", 2, " "));			// set [처리구분]
//			request.setPprn1(rltmTrsfTxNo + StringUtils.lpad("", 59 - rltmTrsfTxNo.length(), " "));	// set [예비]	☆★☆★☆ 리얼타임이체거래번호(수신용) 세팅 ☆★☆★☆
//			request.setPprn2(rltmTrsfTxNo.concat(input.getOptnKey()).concat(StringUtils.lpad("", 56 - rltmTrsfTxNo.length(), " ")));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			request.setPprn2(StringUtils.lpad("", 56, " "));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업 (COMMA)
//			tgmCont = FwUtil.toCSV(request).replace(",", "");
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(request));
			
			// ☆★☆★☆★ OMM 에 세팅하는 함수 ☆★☆★☆★
//			FwUtil.toOMM(type, csvData);

			// 송신전 세팅값 확인
			logger.debug("☆★☆★☆ ★☆ ====================> request 전문내용(tgmCont) START <==================== ★☆ ☆★☆★☆ ");
			logger.debug("☆★☆==========> tgmCont={}", tgmCont);
			logger.debug("☆★☆★☆★☆  ====================> request 전문내용(tgmCont) END <==================== ★☆ ☆★☆★☆ ");
		
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE START ********************************/
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = this.cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 미전송(0)이 아닐경우 오류 : insert시 입력한 전송구분코드가 미전송(0) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_0.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				// 전송구분코드 미전송(0)을 전문발송전 전송(1)로 변경하여 세팅
				trmsDcd = RTCont.TRMSDCD_1;
			}
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE
			iResult = cmb001bean.updateTrmsDcd(trmsDcd, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE END ********************************/
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
//			realTgmLog.setTgmLogPrcsDtm(today.concat(todayHms));	// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(bnkCd3);					// set [이체처리금융기관코드] : 입금은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);							// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			
			// FEP call
//			InfUtil.callAsyncFEP(request, interfaceId);
////			responseData = response.getResponseData();
////			logger.debug("responseData={}", responseData.toString());
//			
//			// 처리시간 (DO세팅용)
////			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
//			
//			// 옵션키(A:aSync, S:sync) 가 'S'일 경우 sync 타입으로 각 업무파트로 return값을 세팅하여 전달_20130219
//			if(RTCont.OPTNKEY_S.equals(input.getOptnKey())){
//				input.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//				prcsInfo = cmb001bean.syncOptnResponse(input);
//				
//			}else{
//				prcsInfo = input;
//				prcsInfo.setPrcsBnkCd(bnkCd3);					// set [처리은행코드]
//				prcsInfo.setTrmsDcd(RTCont.TRMSDCD_1);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
//				prcsInfo.setPrcsHms(todayHms);					// set [처리시간]
//				prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//			}
			
			String mode = LApplicationContext.getSystemMode();	 
			 
			 //운영계
			//if("R".equals(mode)) {
			if("T".equals(mode)) {
			//if("R".equals(mode) || "D".equals(mode)) { 	
				  
				  //3.동기화 방식 송신
				  response= InfUtil.callFEP(request, interfaceId, COM_F_KSNOSKSPO00014In.class);
				  
				  logger.debug("response---> {}",response);

				  responseData = response.getResponseData();
				  
				  prcsInfo = cmb004bean.setTotPrcs(responseData, rltmTrsfTxNo);
				  
					
			 //개발,테스트	  
			 //} else if("D".equals(mode) || "T".equals(mode)) {
			//} else if("D".equals(mode) || "R".equals(mode)) {
			} else if( "R".equals(mode) || "D".equals(mode) ) {
			 //} else if("T".equals(mode)) {   
				  prcsInfo = input;
				  prcsInfo.setPrcsBnkCd(prcsBnkCd);				// set [처리은행코드]
				  prcsInfo.setTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : TRMSDCD_2(정상)]
				  prcsInfo.setPrcsHms(todayHms);				// set [처리시간]
				  prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);		// set [리얼타임이체거래번호]
				  prcsInfo.setBnkAnswCd("0000");				// set [은행결과코드]
				  
				  realTmSetInfo.setCmpyImtrsfRcd("0000");		// 업체즉시이체결과코드 : 응답코드 세팅
				  realTmSetInfo.setFininImtrsfRcd("0000");		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				  
				  //리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
				  iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
					
				  if(iResult != 1){
					  //SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						
					  throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
				  }
				  
			  } 	
			
			logger.debug("☆★☆==========> prcsInfo={}", prcsInfo);

		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);

		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		} catch (Exception e) {
			logger.error("Exception", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}
		
		return prcsInfo;
	}
	
	/**
	 * 출금이체신청(납부자번호등록) - 처리코드(06)
	 * @param trsfTrrvPrcsInfo  이체송수신처리정보
	 * @param tgmNo	전문번호
	 * @param rltmTrsfTxNo	리얼타임이체거래번호
	 * @return trsfTrrvPrcsInfo  이체송수신처리정보
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setWdmTrsfAppl (TrsfTrrvPrcsInfo input, String tgmNo, String rltmTrsfTxNo, String rltmTrsfPmpsNo) throws ApplicationException {
		
//		EISResponse<OAKSNTKSNP060050100000In> response = null;
//		OAKSNTKSNP060050100000In responseData = null;
//		List<SelectMultiTBCSFCR0010Out> out1 = null;
		TrsfTrrvPrcsInfo prcsInfo = new TrsfTrrvPrcsInfo();
//		OSTGMDATAVERFINFOTESTIo verfInfo = new OSTGMDATAVERFINFOTESTIo();		// 복기부호 생성용 OMM
//		SelectOneTBCSPRF0014Out custInfo = new SelectOneTBCSPRF0014Out();
//		TBCMRTM006Io rtnResult = new TBCMRTM006Io();
		TBCSFCR003Io pmpsInfo =  new TBCSFCR003Io();
		TBCMRTM001Io realTmInfo = new TBCMRTM001Io();			// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();// (테스트용<삭제>)리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		EISResponse < COM_F_KSNOSKSPO00003In > response = null;
		COM_F_KSNOSKSPO00003In responseData = null;
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String imtrsfChnlDcd = "0002";							// 즉시이체채널구분코드
//		BigDecimal zero = BigDecimal.ZERO;
		logger.debug("☆★☆==========> setWdmTrsfAppl={}", input);
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		try {
			COM_F_KSNOSKSPO00003In request = new COM_F_KSNOSKSPO00003In(); // EAI Interface request data(OMM)
			String interfaceId = "COM_F_KSNOSKSPO00003"; // EAI Interface ID

			// 필수입력값체크
			if (StringUtils.isEmpty(tgmNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "전문번호" });
			}
			
			if (StringUtils.isEmpty(rltmTrsfTxNo) || rltmTrsfTxNo.length() != 20) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "리얼타임이체거래번호" });
			}
			
			if (StringUtils.isEmpty(input.getActMgntNo()) ) {  // || input.getActMgntNo().length() != 20 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌관리번호" });
			}
			
			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드" });
			}
			
			if (StringUtils.isEmpty(input.getActNo())) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌번호" });
			} 
			
			if (StringUtils.isEmpty(input.getAchdRrno()) || (input.getAchdRrno().length() != 13 && input.getAchdRrno().length() != 10)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "예금주주민등록번호" });
			}
			
			if (StringUtils.isEmpty(input.getPrcsDt()) || input.getPrcsDt().length() != 8) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "처리일자(자동납부일자)" });
			}
			
			if (StringUtils.isEmpty(input.getNrmCnclDcd()) || input.getNrmCnclDcd().length() != 1) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "정상취소구분코드(신청구분)" });
			}
			
//			if (StringUtils.isEmpty(input.getChnlDcd()) || input.getChnlDcd().length() != 4 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채널구분코드" });
//			} 
			

			// 출금이체신청(납부자번호등록) 전문송신 세팅용 변수 
			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
//			String txDt 		= today.substring(4);					// 거래일자 (today)
			String bnkCd3 		= input.getBnkCd();						// 은행코드3자리
//			String bnkCd 		= input.getBnkCd().substring(1);		// 은행코드
			String actNo		= input.getActNo().concat(StringUtils.lpad("", 16 - input.getActNo().length(), " "));	// 계좌번호
//			String actNm		= "";									// 계좌성명
//			String rrno			= "";									// 주민번호
			String tgmCtgyCd 	= "";									// 전문종별코드
			String bzDvsnCd 	= "";									// 업무구분코드
//			String prcsBnkCd 	= input.getPrcsBnkCd();					// 처리은행코드
//			String wdmIndNm 	= "";									// 출금인성명
//			String dpsIndNm 	= "";									// 입금인성명
//			String verfMrk		= "";									// 복기부호
//			String bkbkPswd		= "";									// 통장비밀번호
//			String atrDvsn		= "";									// 자동이체구분
//			BigDecimal dpsAmt 	= input.getTrsfAmt();					// 입금금액(이체금액)
//			String rltmTrsfPmpsNo = "";									// 납부자번호
			String achdRrno 	= "";									// 예금주주민등록번호
			String applDvsn 	= Integer.toString(Integer.parseInt(input.getNrmCnclDcd()) + 1);	// 신청구분(정상취소구분코드사용) : 동의(1), 해지(2) 
			String trmsDcd 		= "";									// 전송구분코드
			String tgmCont 		= "";									// 전문내용
			String prcsCd       = input.getPrcsCd();					// 거래코드
			
			
			// 계좌관리번호로 리얼타임출금이체동의(TBCSFCR003) 조회하여 최종이력여부가 'Y'이면서 
			// 출금이체동의상태구분코드가 '1'인 경우만.. (납부자등록여부조회)
			if ("".equals(rltmTrsfPmpsNo)){
				if("2".equals(applDvsn)){											// 신청구분이 해지(2) 일 경우에만 체크
					pmpsInfo = this.cmb001dbio.selectOneTBCSFCR0030(input.getActMgntNo());
					
					if(pmpsInfo != null){
						if(!RTCont.WTRSF_ASNT_STA_ASNT.equals(pmpsInfo.getWtrsfAsntStaDcd())){
							// 납부자등록 미등록사항 - '납부자등록이 미등록되었습니다. 확인해주세요.'
							throw new ApplicationException("APPAE0054", null);
						}/*else{
							rltmTrsfPmpsNo = pmpsInfo.getRltmTrsfPmpsNo();
						}*/
					}else{
						// 오류!!!! '리얼타임출금이체동의 내용이 존재하지 않습니다.'
						throw new ApplicationException("APPAE0059", null);
					}
				}
			}
			
			// 처리시간 (집계처리 호출(OMM) 세팅용)
//			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

			// 고객번호로 주민번호 조회 - 주민번호를 직접받기로 함
//			custInfo = pam005dbio.selectOneTBCSPRF0014(input.getAchdCustNo());
//			rrno = custInfo.getCustDscNo();
			
			/* 자동이체처리 업무에서는 주민등록번호를 사용하지 않음, 사용한다면 해당주석을 활성화
			rrno = input.getAchdRrno();		// 주민등록번호
			
			// 주민등록번호가 10자리(사업자등록번호) 일 경우 앞에 '999'를 추가하여 세팅
			if(rrno.length() == 10){
				rrno = "999" + input.getAchdRrno();
			}
			*/
			
			// 공통헤더부 세팅 위한 KS-NET 전문종별코드, 업무구분코드 정의 - 출금이체신청(납부자번호등록)
			tgmCtgyCd = "0600";
			bzDvsnCd = "501";
			
			// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 출금이체신청(납부자번호등록)시는 고객은행코드가 기준이 된다. (input.getBnkCd())
			setImtrSfchCommonHeader(bnkCd3, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd, prcsCd);
		
/**			
			
			// 금융기관제휴업목록 테이블 조회 (모계좌 추출)
			rtnResult = pam056dbio.selectOneTBCMRTM0060(bnkCd, imtrsfChnlDcd);
			
			// 처리시간 (출금이체신청(납부자번호등록)(OMM) 세팅용)
			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			
			// 출금인성명 세팅
			if(PAZ500BEAN.BNKCD_04.equals(bnkCd) || PAZ500BEAN.BNKCD_71.equals(bnkCd)){
				wdmIndNm = "KDB생명보험";
			}else{
				wdmIndNm = "KDB생명보험(주)";
			}
			
			// 통장비밀번호(자계좌비번) 세팅
			if(PAZ500BEAN.BNKCD_21.equals(bnkCd)){		// 조흥은행(21)이면 '00000000'세팅
				bkbkPswd = "00000000";
			}else{
				bkbkPswd = StringUtils.lpad("", 8, " ");
			}
			
			// 자동이체구분 세팅
			if(PAZ500BEAN.BNKCD_20.equals(bnkCd) || PAZ500BEAN.BNKCD_71.equals(bnkCd)){		// 우리은행(20) or 우체국(71)이면 '20'세팅
				atrDvsn = "20";
			}else{
				atrDvsn = StringUtils.lpad("", 2, " ");
			}
			
			// 입금인성명 세팅
			if(PAZ500BEAN.BNKCD_11.equals(bnkCd)){		// 농협(11)이면 세팅
				dpsIndNm = input.getAchdNm();		// 예금주명
			}else{			//농협외에는 space 세팅
				dpsIndNm = StringUtils.lpad("", 20, " ");
			}
			
**/					
			if(input.getAchdRrno().length() != 10) {				
			
				// 예금주주민등록번호			
				if(( "011".equals(input.getBnkCd()) || "012".equals(input.getBnkCd()))		//농협만 시행일자가 다름 
					 && today.compareTo("20140807") < 0) {
					achdRrno = input.getAchdRrno();
				} else {
					achdRrno = input.getAchdRrno().substring(0, 6).concat(StringUtils.lpad("", 7, " ")); //20140722
				}
			} else {
				// 주민등록번호가 10자리(사업자등록번호) 일 경우 앞에 '999'를 추가하여 세팅
				achdRrno = input.getAchdRrno().concat(StringUtils.lpad("", 3, " "));
			}
			
			
			/********** 복기부호 생성 (복기부호 필요OMM 세팅후 처리) END **********/
		
			TBCMRTM006Io rtnResult = new TBCMRTM006Io();
			// 금융기관제휴업목록 테이블 조회 (금융기관관리업체코드 가져오기 위해)
			rtnResult = this.cmb001dbio.selectOneTBCMRTM0060(bnkCd3, imtrsfChnlDcd);
			
			SecuUtil.doDecObject(rtnResult);

			String  fininMgntCmpyCd3 ="";
			if(rtnResult != null && StringUtils.hasText(rtnResult.getFininMgntCmpyCd3())){
				  fininMgntCmpyCd3 = rtnResult.getFininMgntCmpyCd3();
			}else{
				// 금융기관제휴업무목록 정보가 존재하지 않습니다.
				throw new ApplicationException("APPAE0051", null);
			}
			

			logger.debug("업체등록번호=================>request.getCmpyCdH()={} ",  request.getCmpyCd()  ) ;
			logger.debug("기관번호=================> fininMgntCmpyCd3={}::bnkCd3={} ", fininMgntCmpyCd3, bnkCd3 ) ;
			
			
	//		String cmpyCdh =  request.getCmpyCdH() ;
	//		cmpyCdh =cmpyCdh.toString()+ StringUtils.lpad("", 16 - cmpyCdh.toString().length(), " ") ;		
			// 출금이체신청(납부자번호등록) 데이터 설정
			request.setIdcsDscCd("D");								// set [식별코드]
			request.setPrcsSeq("0000000");						// set [처리순번]
			request.setIdcsBnkCd2(StringUtils.lpad("", 2, " "));	// set [은행코드(대표은행코드)]
			request.setActNo(actNo);							// set [계좌번호]
			request.setApplDvsn(applDvsn);						// set [신청구분] - 신규:1, 해지:2
			request.setAutoPmpsDt(input.getPrcsDt().substring(6, 8));	// set [자동납부일자] - 고객이 이체하고자 하는 날짜(필요업체만) => 처리일자의 마지막2자리(DD) 세팅
			request.setHndlOffcCd6(StringUtils.lpad("", 6, " "));		// set [은행코드+취급접코드]
			request.setApplDt(today);							// set [신청일자(고객신청일자)]
			request.setPrcsYn(" ");		// set [처리여부] - 처리결과코드(정상:Y, 불능:N) => 은행만 던지는것인가?? 'Y'던져라
			request.setImpCd(StringUtils.lpad("", 4, " "));		// set [불능코드]
			request.setAchdRrnoChk("Y");							// set [주민등록번호 체크여부]
			request.setAchdRrno(achdRrno);							// set [주민등록번호]
			if ("".equals(rltmTrsfPmpsNo)) {
				request.setPmpsNo(input.getActMgntNo());				// set [납부자번호] - 업체에서 사용하는 납부자번호(이체DATA의 납부자번호와 같아야 출금됨) ==> 계좌관리번호 세팅
			}
			else
			{
				request.setPmpsNo(rltmTrsfPmpsNo);				// set [납부자번호] - 업체에서 사용하는 납부자번호(이체DATA의 납부자번호와 같아야 출금됨) ==> 계좌관리번호 세팅
			}
			
    		request.setCmpyUseInfo(request.getCmpyCd());                     //  set [업체/은행 사용정보]
			request.setInstCd(fininMgntCmpyCd3);	// set [기관코드]			
			request.setIdcsBnkCd3(bnkCd3);							// set [은행코드(3자리)]
			request.setHndlOffcCd7("0000000");						// set [은행코드+취급점코드]
//			request.setPprn1(rltmTrsfTxNo + StringUtils.lpad("", 82 - rltmTrsfTxNo.length(), " "));	// set [예비]	☆★☆★☆ 리얼타임이체거래번호(수신용) 세팅 ☆★☆★☆
//			request.setPprn2(rltmTrsfTxNo.concat(input.getOptnKey()).concat(StringUtils.lpad("", 81 - rltmTrsfTxNo.length(), " ")));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			request.setPprn2(StringUtils.lpad("", 81, " "));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업 (COMMA)
//			tgmCont = FwUtil.toCSV(request).replace(",", "");
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(request));
			
			// 송신전 세팅값 확인
			logger.debug("☆★☆★☆ ★☆ ====================> request 전문내용(tgmCont) START <==================== ★☆ ☆★☆★☆ ");
			logger.debug("☆★☆==========> tgmCont={}", tgmCont);
			logger.debug("☆★☆★☆★☆  ====================> request 전문내용(tgmCont) END <==================== ★☆ ☆★☆★☆ ");
		
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE START ********************************/
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = this.cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 미전송(0)이 아닐경우 오류 : insert시 입력한 전송구분코드가 미전송(0) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_0.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				// 전송구분코드 미전송(0)을 전문발송전 전송(1)로 변경하여 세팅
				trmsDcd = RTCont.TRMSDCD_1;
			}
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE
			iResult = cmb001bean.updateTrmsDcd(trmsDcd, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE END ********************************/
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/

			logger.debug("today===>{}",today);
			logger.debug("todayHms===>{}",todayHms);
			logger.debug("today.concat(todayHms)===>{}",today.concat(todayHms));
			
//			tgmLogPrcsDtm = this.cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
//			realTgmLog.setTgmLogPrcsDtm(today.concat(todayHms));	// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(bnkCd3);					// set [이체처리금융기관코드] : 입금은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);							// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			
//			// FEP call
//			InfUtil.callAsyncFEP(request, interfaceId);
////			responseData = response.getResponseData();
////			logger.debug("responseData={}", responseData.toString());
//			
//			// 처리시간 (DO세팅용)
////			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
//			
//			// 옵션키(A:aSync, S:sync) 가 'S'일 경우 sync 타입으로 각 업무파트로 return값을 세팅하여 전달_20130219
//			if(RTCont.OPTNKEY_S.equals(input.getOptnKey())){
//				input.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//				prcsInfo = cmb001bean.syncOptnResponse(input);
//				
//			}else{
//				prcsInfo = input;
//				prcsInfo.setPrcsBnkCd(bnkCd3);					// set [처리은행코드]
//				prcsInfo.setTrmsDcd(RTCont.TRMSDCD_1);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
//				prcsInfo.setPrcsHms(todayHms);					// set [처리시간]
//				prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//			}
			
			String mode = LApplicationContext.getSystemMode();	 
			 
			logger.debug("request---> {}",request);
			
			 //운영계
			if("R".equals(mode) ) {
			//if("R".equals(mode) || "D".equals(mode)) { 	
				  
				  //3.동기화 방식 송신
				  response= InfUtil.callFEP(request, interfaceId, COM_F_KSNOSKSPO00003In.class);
				  
				  logger.debug("response---> {}",response);

				  responseData = response.getResponseData();
					
//				  prcsInfo = input;
//				  
//				  prcsInfo.setPrcsBnkCd(prcsBnkCd);// set [처리은행코드] - 이체대상금융기관코드
//				  prcsInfo.setTrmsDcd(responseData.getAnswCd());		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
//				  prcsInfo.setPrcsHms(todayHms);					// set [처리시간]
//				  prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
				  
				  prcsInfo = cmb004bean.setWdmTrsfAppl(responseData, rltmTrsfTxNo);
				  
					
			 //개발,테스트	  
			 } else if("T".equals(mode) || "D".equals(mode)) {
			 //} else if("T".equals(mode)) {
			      
				  prcsInfo = input;
				  prcsInfo.setPrcsBnkCd(bnkCd3);				// set [처리은행코드]
				  prcsInfo.setTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
				  prcsInfo.setPrcsHms(todayHms);				// set [처리시간]
				  prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);		// set [리얼타임이체거래번호]
				  prcsInfo.setBnkAnswCd("0000");				// set [은행결과코드]
				  
				  realTmSetInfo.setCmpyImtrsfRcd("0000");		// 업체즉시이체결과코드 : 응답코드 세팅
				  realTmSetInfo.setFininImtrsfRcd("0000");		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				  realTmSetInfo.setRltmTrsfPmpsNo(rltmTrsfPmpsNo);//리얼타임이체납부자번호  
				  
				  //리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
				  iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
					
				  if(iResult != 1){
					  //SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						
					  throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
				  }
				  
			  } 		
			
			logger.debug("☆★☆==========> prcsInfo={}", prcsInfo);
			

		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
			
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		} catch (Exception e) {
			logger.error("Exception", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}
		
		return prcsInfo;
	}
	
	/**
	 * 예금주명 확인처리 - 처리코드(07)
	 * @param trsfTrrvPrcsInfo  이체송수신처리정보
	 * @param tgmNo	전문번호
	 * @param rltmTrsfTxNo	리얼타임이체거래번호
	 * @return trsfTrrvPrcsInfo  이체송수신처리정보
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setChkAchdNmVrfcPrcs (TrsfTrrvPrcsInfo input, String tgmNo, String rltmTrsfTxNo) throws ApplicationException {
		
//		EISResponse<OAKSNTKSNP060040000000In> response = null;
//		OAKSNTKSNP060040000000In responseData = null;
//		List<SelectMultiTBCSFCR0010Out> out1 = null;
		TrsfTrrvPrcsInfo prcsInfo = new TrsfTrrvPrcsInfo();
//		SelectOneTBCSPRF0014Out custInfo = new SelectOneTBCSPRF0014Out();
		TBCMRTM001Io realTmInfo = new TBCMRTM001Io();			// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();// (테스트용<삭제>)리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		EISResponse < COM_F_KSNOSKSFO00001In > response = null;
		COM_F_KSNOSKSFO00001In responseData = null;		
//		TBCMRTM001Io realTmSetInfo = new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String imtrsfChnlDcd = "0001";							// 즉시이체채널구분코드
		String prcsCd   = input.getPrcsCd();					// 거래코드
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);

		try {
			COM_F_KSNOSKSFO00001In request = new COM_F_KSNOSKSFO00001In(); // EAI Interface request data(OMM)
			String interfaceId = "COM_F_KSNOSKSFO00001"; // EAI Interface ID
			
			// 필수입력값체크
			if (StringUtils.isEmpty(tgmNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "전문번호" });
			}
			
			if (StringUtils.isEmpty(rltmTrsfTxNo) || rltmTrsfTxNo.length() != 20) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "리얼타임이체거래번호" });
			}
			
			if (StringUtils.isEmpty(input.getActNo())) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌번호" });
			} 
			
			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드" });
			}
			
		/*	if (StringUtils.isEmpty(input.getAchdRrno()) || (input.getAchdRrno().length() != 13 && input.getAchdRrno().length() != 10)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "주민등록번호" });
			}
			*/
//			if (StringUtils.isEmpty(input.getActMgntNo()) || input.getActMgntNo().length() != 20 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌관리번호" });
//			}
			
//			if (StringUtils.isEmpty(input.getChnlDcd()) || input.getChnlDcd().length() != 4 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채널구분코드" });
//			} 
			
			// 예금주명 확인처리 전문송신 세팅용 변수 
			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			String txDt 		= today.substring(4);					// 거래일자 (today)
			String bnkCd3 		= input.getBnkCd();						// 은행코드3자리
			String bnkCd 		= input.getBnkCd().substring(1);		// 은행코드
			String actNo		= input.getActNo().concat(StringUtils.lpad("", 16 - input.getActNo().length(), " "));	// 계좌번호
//			String actNm		= "";									// 계좌성명
			String rrno			= "";									// 주민번호
			String tgmCtgyCd 	= "";									// 전문종별코드
			String bzDvsnCd	 	= "";									// 업무구분코드
			String prcsBnkCd 	= input.getPrcsBnkCd();					// 처리은행코드
			String trmsDcd 		= "";									// 전송구분코드
			String tgmCont 		= "";									// 전문내용

			// 고객번호로 주민번호 조회 - 주민번호를 직접받기로 함
//			custInfo = pam005dbio.selectOneTBCSPRF0014(input.getAchdCustNo());
//			rrno = custInfo.getCustDscNo();					
			if(input.getAchdRrno().length() != 10) {
				// 주민등록번호
				if(( "011".equals(input.getBnkCd()) || "012".equals(input.getBnkCd()))		//농협만 시행일자가 다름 
						 && today.compareTo("20140807") < 0) {
					rrno = input.getAchdRrno();
				} else {
					//** 2015.02.25_김완진_22061_Start1
					if(input.getAchdRrno().length() > 6) {
						rrno = input.getAchdRrno().substring(0, 6).concat(StringUtils.lpad("", 7, " ")); //20140722
					} else {
						rrno = input.getAchdRrno();
					}
					//** 2015.02.25_김완진_22061_End1
				}
			} else {
				// 주민등록번호가 10자리(사업자등록번호) 일 경우 뒤에 ' '를 추가하여 세팅			
				rrno = input.getAchdRrno().concat(StringUtils.lpad("", 3, " "));
			}
			
			// 처리시간 (집계처리 호출(OMM) 세팅용)
//			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			
			// 공통헤더부 세팅 위한 KS-NET 전문종별코드, 업무구분코드 정의 - 예금주조회
			tgmCtgyCd = "0600";
			bzDvsnCd = "400";
			
			// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 예금주조회시는 처리은행코드가 기준이 된다. (input.getPrcsBnkCd())
			setImtrSfchCommonHeader(prcsBnkCd, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd, prcsCd);
			
			//setImtrSfchCommonHeader(bnkCd3, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd);
			
			// 예금주명 확인요청 데이터 설정
			request.setTxDt(txDt);									// set [거래일자] M
			request.setIdcsBnkCd2(bnkCd);							// set [은행코드] M
			request.setActNo(actNo);								// set [계좌번호] M
			request.setAchdNm(StringUtils.lpad("", 22, " "));		// set [계좌성명]
			request.setAchdRrno(rrno);								// set [주민번호] M
			request.setAchdRrnoChk(StringUtils.lpad("", 2, " "));	// set [주민번호체크여부]
			request.setBnkCd3(bnkCd3);								// set [은행코드3자리] M
			request.setAmt(StringUtils.lpad("", 13, " "));			// set [금액] M
			request.setWrbkBkbkInq(" ");							// set [우리은행통장조회] M
			request.setObnkCrtfTyp(" ");							// set [타행인증유형] M
			request.setNhbkActDvsn(" ");							// set [NH농협은행계좌구분] M
//			request.setPprn2(rltmTrsfTxNo.concat(input.getOptnKey()).concat(StringUtils.lpad("", 102 - rltmTrsfTxNo.length(), " ")));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			request.setPprn2(StringUtils.lpad("", 102, " "));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업 (COMMA)
//			tgmCont = FwUtil.toCSV(request).replace(",", "");
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(request));

			// 송신전 세팅값 확인
			logger.debug("☆★☆★☆ ★☆ ====================> request 전문내용(tgmCont) START <==================== ★☆ ☆★☆★☆ ");
			logger.debug("☆★☆==========> tgmCont={}", tgmCont);
			logger.debug("☆★☆★☆★☆  ====================> request 전문내용(tgmCont) END <==================== ★☆ ☆★☆★☆ ");
		
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE START ********************************/
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = this.cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 미전송(0)이 아닐경우 오류 : insert시 입력한 전송구분코드가 미전송(0) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_0.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요.'
				throw new ApplicationException("APPAE0056", null);
			}else{
				// 전송구분코드 미전송(0)을 전문발송전 전송(1)로 변경하여 세팅
				trmsDcd = RTCont.TRMSDCD_1;
			}
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE
			iResult = cmb001bean.updateTrmsDcd(trmsDcd, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE END ********************************/
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
//			tgmLogPrcsDtm = this.cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
//			realTgmLog.setTgmLogPrcsDtm(today.concat(todayHms));	// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(prcsBnkCd);				// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);							// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			
//			// FEP call
//			InfUtil.callAsyncFEP(request, interfaceId);
//
//			
//			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/
//			
//			// 옵션키(A:aSync, S:sync) 가 'S'일 경우 sync 타입으로 각 업무파트로 return값을 세팅하여 전달_20130219
//			if(RTCont.OPTNKEY_S.equals(input.getOptnKey())){
//				input.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//				
//				logger.debug("☆★☆==========> Sync ={}", rltmTrsfTxNo);
//				prcsInfo = cmb001bean.syncOptnResponse(input);
//				logger.debug("☆★☆==========> prcsInfo ={}", prcsInfo);
//				
//			}else{
//				prcsInfo = input;
//				prcsInfo.setPrcsBnkCd(prcsBnkCd);						// set [처리은행코드]
//				prcsInfo.setTrmsDcd(RTCont.TRMSDCD_1);				// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
//				prcsInfo.setPrcsHms(todayHms);// set [처리시간]
//				prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);// set [리얼타임이체거래번호]
//			}
			
			String mode = LApplicationContext.getSystemMode();	 
			 
			 //운영계
			//if("R".equals(mode)) {  
			if("T".equals(mode)) {
			//if("R".equals(mode) || "D".equals(mode)) {  
				  //3.동기화 방식 송신
				  response= InfUtil.callFEP(request, interfaceId, COM_F_KSNOSKSFO00001In.class);
				  
				  logger.debug("response---> {}",response);

				  responseData = response.getResponseData();
					
				  prcsInfo = cmb004bean.setChkAchdNmVrfcPrcs(responseData, rltmTrsfTxNo);
				  
					
			 //개발,테스트	  
			//} else if("D".equals(mode) || "T".equals(mode)) {
			} else if("D".equals(mode) || "R".equals(mode)) {
			//} else if("T".equals(mode)) {  
				  prcsInfo = input;
				  prcsInfo.setPrcsBnkCd(prcsBnkCd);				// set [처리은행코드]
				  prcsInfo.setTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : TRMSDCD_2(정상)]
				  prcsInfo.setPrcsHms(todayHms);				// set [처리시간]
				  prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);		// set [리얼타임이체거래번호]
				  prcsInfo.setBnkAnswCd("0000");				// set [은행결과코드]
				  prcsInfo.setAchdNm("예금주테스트");					// 예금주명 : 계좌성명 세팅
				  
				  realTmSetInfo.setCmpyImtrsfRcd("0000");		// 업체즉시이체결과코드 : 응답코드 세팅
				  realTmSetInfo.setFininImtrsfRcd("0000");		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				  realTmSetInfo.setAchdNm("예금주테스트");					// 예금주명 : 계좌성명 세팅
				  
				  
				  //리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
				  iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
					
				  if(iResult != 1){
					  //SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						
					  throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
				  }
				  
			  } 	
			
			logger.debug("☆★☆==========> prcsInfo={}", prcsInfo);

		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
			
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		} catch (Exception e) {
			logger.error("Exception", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}
		
		return prcsInfo;
	}
	
	/**
	 * 잔액조회 - 처리코드(08)
	 * @param trsfTrrvPrcsInfo  이체송수신처리정보
	 * @param tgmNo	전문번호
	 * @param rltmTrsfTxNo	리얼타임이체거래번호
	 * @return trsfTrrvPrcsInfo  이체송수신처리정보
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setBamtInq (TrsfTrrvPrcsInfo input, String tgmNo, String rltmTrsfTxNo) throws ApplicationException {
		
//		EISResponse<OAKSNTKSNP060030000000In> response = null;
//		OAKSNTKSNP060030000000In responseData = null;
//		List<SelectMultiTBCSFCR0010Out> out1 = null;
		TrsfTrrvPrcsInfo prcsInfo = new TrsfTrrvPrcsInfo();
//		SelectOneTBCSPRF0014Out custInfo = new SelectOneTBCSPRF0014Out();
		TBCMRTM006Io rtnResult = new TBCMRTM006Io();
		TBCMRTM001Io realTmInfo = new TBCMRTM001Io();			// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();// (테스트용<삭제>)리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		EISResponse < COM_F_KSNOSKSPO00013In > response = null;
		COM_F_KSNOSKSPO00013In responseData = null;
//		TBCMRTM001Io realTmSetInfo = new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String imtrsfChnlDcd_1 = "0001";						// 즉시이체채널구분코드
		String imtrsfChnlDcd_2 = "0002";						// 즉시이체채널구분코드
		String prcsCd   = input.getPrcsCd();					// 거래코드
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		

		try {
			COM_F_KSNOSKSPO00013In request = new COM_F_KSNOSKSPO00013In(); // EAI Interface request data(OMM)
			String interfaceId = "COM_F_KSNOSKSPO00013"; // EAI Interface ID
			
			// 필수입력값체크
			if (StringUtils.isEmpty(tgmNo)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "전문번호" });
			}
			
			if (StringUtils.isEmpty(rltmTrsfTxNo) || rltmTrsfTxNo.length() != 20) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "리얼타임이체거래번호" });
			}
			
//			if (StringUtils.isEmpty(input.getActNo())) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌번호" });
//			} 
			
			if (StringUtils.isEmpty(input.getBnkCd()) || input.getBnkCd().length() != 3 ) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드" });
			}
			
//			if (StringUtils.isEmpty(input.getAchdRrno()) || (input.getAchdRrno().length() != 13 && input.getAchdRrno().length() != 10)) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "주민등록번호" });
//			}
			
//			if (StringUtils.isEmpty(input.getActMgntNo()) || input.getActMgntNo().length() != 20 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계좌관리번호" });
//			}
			
//			if (StringUtils.isEmpty(input.getChnlDcd()) || input.getChnlDcd().length() != 4 ) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "채널구분코드" });
//			} 
			
			// 잔액조회 전문송신 세팅용 변수 
//			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
//			String txDt 		= today.substring(4);					// 거래일자 (today)
			String bnkCd3 		= input.getBnkCd();						// 은행코드3자리
//			String bnkCd 		= input.getBnkCd().substring(1);		// 은행코드
//			String actNo		= input.getActNo() + StringUtils.lpad("", 15 - input.getActNo().length(), " ");	// 계좌번호
//			String actNm		= "";									// 계좌성명
//			String rrno			= "";									// 주민번호
			String tgmCtgyCd 	= "";									// 전문종별코드
			String bzDvsnCd	 	= "";									// 업무구분코드
			String prcsBnkCd 	= input.getPrcsBnkCd();					// 처리은행코드
			String trmsDcd 		= "";									// 전송구분코드
			String tgmCont 		= "";									// 전문내용

			// 고객번호로 주민번호 조회 - 주민번호를 직접받기로 함
//			custInfo = pam005dbio.selectOneTBCSPRF0014(input.getAchdCustNo());
//			rrno = custInfo.getCustDscNo();
//			rrno = input.getAchdRrno();		// 주민등록번호
//			
//			// 주민등록번호가 10자리(사업자등록번호) 일 경우 뒤에 ' '를 추가하여 세팅
//			if(rrno.length() == 10){
//				rrno = input.getAchdRrno() + StringUtils.lpad("", 3, " ");
//			}
			
			// 공통헤더부 세팅 위한 KS-NET 전문종별코드, 업무구분코드 정의 - 잔액조회
			tgmCtgyCd = "0600";
			bzDvsnCd = "300";
			logger.debug("☆★☆==========>CMB002BEAN 555555555555555555 input={}" , input);
			// 금융기관제휴업목록 테이블 조회 (모계좌 추출)
			if(RTCont.DPWD_DCD_DPS.equals(input.getDpwdDcd())){		// 입출금구분코드가 입금(1)일 경우
				// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 집계처리시는 고객은행코드가 기준이 된다. (input.getBnkCd())
				setImtrSfchCommonHeader(bnkCd3, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd_2, prcsCd);
				logger.debug("☆★☆==========>CMB002BEAN 5666666666666666666666666");
				rtnResult = this.cmb001dbio.selectOneTBCMRTM0060(bnkCd3, imtrsfChnlDcd_2);
				logger.debug("☆★☆==========>CMB002BEAN 77777777777777777777777");
			}else if(RTCont.DPWD_DCD_WDM.equals(input.getDpwdDcd())){		// 입출금구분코드가 출금(2)일 경우
				// 공통헤더(OSIMTRSFCH000000Io) 세팅 : 집계처리시는 처리은행코드가 기준이 된다. (input.getPrcsBnkCd())
				setImtrSfchCommonHeader(bnkCd3, request, tgmNo, tgmCtgyCd, bzDvsnCd, imtrsfChnlDcd_1, prcsCd);
				
				rtnResult = cmb001dbio.selectOneTBCMRTM0060(prcsBnkCd, imtrsfChnlDcd_1);
			}
			
			SecuUtil.doDecObject(rtnResult);
			logger.debug("☆★☆==========>CMB002BEAN 8888888888888888888888888888");
			// 처리시간 (집계처리 호출(OMM) 세팅용)
//			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			
			// 잔액조회 데이터 설정
			request.setActNo(rtnResult.getMoActNo().trim().concat(StringUtils.lpad("", 15 - rtnResult.getMoActNo().trim().length(), " ")));// set [계좌번호]
			request.setBamtChck(" ");// set [부호]
			request.setActBamt(StringUtils.lpad("", 13, " "));// set [계좌잔액]
			request.setBamtChck(StringUtils.lpad("", 13, " "));// set [잔액-현금(현금/대체가능금액)]
			request.setBamtRmrt(StringUtils.lpad("", 13, " "));// set [잔액-(보수/가계수표)]
			request.setBamtGen(StringUtils.lpad("", 13, " "));// set [잔액-일반(어음/당좌액)]
			request.setPayPsbAmt(StringUtils.lpad("", 13, " "));// set [지급가능금액]
//			request.setPprn1(rltmTrsfTxNo + StringUtils.lpad("", 119 - rltmTrsfTxNo.length(), " "));	// set [예비]	☆★☆★☆ 리얼타임이체거래번호(수신용) 세팅 ☆★☆★☆
//			request.setPprn2(rltmTrsfTxNo.concat(input.getOptnKey()).concat(StringUtils.lpad("", 118 - rltmTrsfTxNo.length(), " ")));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			request.setPprn2(StringUtils.lpad("", 118, " "));	// set [예비부]	☆★☆★☆ 리얼타임이체거래번호(수신용), 옵션키 세팅 ☆★☆★☆
			logger.debug("☆★☆==========>CMB002BEAN 999999999999999999999999");
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업 (COMMA)
//			tgmCont = FwUtil.toCSV(request).replace(",", "");
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(request));

			// 송신전 세팅값 확인
			logger.debug("☆★☆★☆ ★☆ ====================> request 전문내용(tgmCont) START <==================== ★☆ ☆★☆★☆ ");
			logger.debug("☆★☆==========> tgmCont={}", tgmCont);
			logger.debug("☆★☆★☆★☆  ====================> request 전문내용(tgmCont) END <==================== ★☆ ☆★☆★☆ ");
		
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE START ********************************/
			
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = this.cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			logger.debug("☆★☆==========>CMB002BEAN 1212121212121212121");
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 미전송(0)이 아닐경우 오류 : insert시 입력한 전송구분코드가 미전송(0) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_0.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요.'
				throw new ApplicationException("APPAE0056", null);
			}else{
				// 전송구분코드 미전송(0)을 전문발송전 전송(1)로 변경하여 세팅
				trmsDcd = RTCont.TRMSDCD_1;
			}
			logger.debug("☆★☆==========>CMB002BEAN 13131313131313131313 trmsDcd={}::rltmTrsfTxNo={}",trmsDcd,rltmTrsfTxNo);
			// FEP call 전에 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE
			iResult = cmb001bean.updateTrmsDcd(trmsDcd, rltmTrsfTxNo);
			logger.debug("☆★☆==========>CMB002BEAN 1414141414141414");
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE END ********************************/
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			//tgmLogPrcsDtm = this.cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
			//logger.debug("☆★☆==========>CMB002BEAN getTgmLogPrcsDtm={}" , tgmLogPrcsDtm.getTgmLogPrcsDtm());
			logger.debug("☆★☆==========>CMB002BEAN prcsBnkCd ={}",bnkCd3);
			logger.debug("☆★☆==========>CMB002BEAN tgmNo={}" , tgmNo);
			logger.debug("☆★☆==========>CMB002BEAN tgmCont={}",  tgmCont);
			//realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
//			realTgmLog.setTgmLogPrcsDtm(today.concat(todayHms));	// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(bnkCd3);				// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);							// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			logger.debug("☆★☆==========>CMB002BEAN log insert ==========>" ,realTgmLog);
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			logger.debug("☆★☆==========>CMB002BEAN 161616161616161616");
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			
//			// FEP call
//			InfUtil.callAsyncFEP(request, interfaceId);
////			responseData = response.getResponseData();
////			logger.debug("responseData={}", responseData.toString());
//			
//			// 처리시간 (DO세팅용)
////			todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
//			
//			// 옵션키(A:aSync, S:sync) 가 'S'일 경우 sync 타입으로 각 업무파트로 return값을 세팅하여 전달_20130219
//			if(RTCont.OPTNKEY_S.equals(input.getOptnKey())){
//				input.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//				prcsInfo = cmb001bean.syncOptnResponse(input);
//				
//			}else{
//				prcsInfo = input;
//				prcsInfo.setPrcsBnkCd(prcsBnkCd);				// set [처리은행코드]
//				prcsInfo.setTrmsDcd(RTCont.TRMSDCD_1);		// set [전송구분코드 : TRMSDCD_1(전송)] - aSync 니까..
//				prcsInfo.setPrcsHms(todayHms);					// set [처리시간]
//				prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);			// set [리얼타임이체거래번호]
//			}
			
			String mode = LApplicationContext.getSystemMode();	 
			 
			 //운영계
			//if("R".equals(mode)) {
			if("T".equals(mode)) {
			//if("R".equals(mode) || "D".equals(mode)) {   
				  //3.동기화 방식 송신
				  response= InfUtil.callFEP(request, interfaceId, COM_F_KSNOSKSPO00013In.class);
				  
				  logger.debug("response---> {}",response);

				  responseData = response.getResponseData();
				  
				  prcsInfo = cmb004bean.setBamtInq(responseData, rltmTrsfTxNo);
				  
					
			 //개발,테스트	  
			 //} else if("D".equals(mode) || "T".equals(mode)) {
			 } else if("D".equals(mode) || "R".equals(mode)) {
			 //} else if("T".equals(mode)) {  
				  prcsInfo = input;
				  prcsInfo.setPrcsBnkCd(prcsBnkCd);				// set [처리은행코드]
				  prcsInfo.setTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : TRMSDCD_2(정상)]
				  prcsInfo.setPrcsHms(todayHms);				// set [처리시간]
				  prcsInfo.setRltmTrsfTxNo(rltmTrsfTxNo);		// set [리얼타임이체거래번호]
				  prcsInfo.setBnkAnswCd("0000");				// set [은행결과코드]
				  
				  realTmSetInfo.setCmpyImtrsfRcd("0000");		// 업체즉시이체결과코드 : 응답코드 세팅
				  realTmSetInfo.setFininImtrsfRcd("0000");		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				  
				  //리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
				  iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
					
				  if(iResult != 1){
					  //SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
						
					  throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
				  }
				  
			  } 	
			
			logger.debug("☆★☆==========> prcsInfo={}", prcsInfo);

		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
			
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		} catch (Exception e) {
			logger.error("Exception", e);
			
			// 서버프로그램단에서 오류발생시 업무파트에 DOMAIN 정보 및 오류코드 return  
			prcsInfo = cmb001bean.setErrInfo(input, rltmTrsfTxNo);
		}
		
		return prcsInfo;
	}
	
}

