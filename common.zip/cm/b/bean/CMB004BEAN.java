package cigna.cm.b.bean;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.io.COM_F_KSNOSKSPO00001In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00003In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00004In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00005In;
import cigna.cm.b.io.COM_F_KSNOSKSFO00001In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00013In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00014In;
import cigna.cm.b.io.KSN_F_COMOSKSPO00001In;
import cigna.cm.b.io.SelectOneTBCMRTM0041Out;
import cigna.cm.b.io.TBCMRTM001Io;
import cigna.cm.b.io.TBCMRTM004Io;
import cigna.cm.b.io.TBCMRTM011Io;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;





/**
 * @file         cigna.cm.b.bean.CMB004BEAN.java
 * @filetype     java source file
 * @brief		 KS-NET 수신처리
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                           성명                                               일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 2. 23.      신규 작성
 *
 */
@KlafBean
public class CMB004BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB001DBIO cmb001dbio;		// 전문번호 체크
	
	@Autowired
	private CMBZ00BEAN cmbz00bean;		// RT 공통메소드 호출
	
	@Autowired
	private CMB001BEAN cmb001bean;		// 지급이체자금이체송수신처리_메인
	
	/**
	 * 자동이체처리 호출(송금,지급) - 처리코드(01)
	 * @param OAKSNTKSNP010010000000In  자동이체처리 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setAtrPrcs(COM_F_KSNOSKSPO00001In input, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;
		
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값		
//		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String tgmCont = "";									// 전문내용
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
//		
//		todayHms = currentDate.format(toDay).toString().replace(":", "");
		
		//임시 : 2013-10-25(정상일때는 이렇게,, 비정상일때는 막아도 됨			
//		if( FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT ) {  	// 개발서버 
		if( FwUtil.getSystemType() == FwUtil.SYSTEM_TEST ||				// 검증서버 
		    FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT ) {  	// 개발서버
			input.setAnswCd("0000");
			input.setBnkAnswCd("0000");
		}

		try {
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				// 응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
				if(!"0000".equals(input.getBnkAnswCd())){
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
					
				}else{
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd(input.getAnswCd());		// 업체즉시이체결과코드 : 응답코드 세팅
				realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
			}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/
			
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
		
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
		
			// 옵션키(A:aSync, S:sync) 가 'A'일 경우 aSync 타입으로 return값을 세팅하여 각 업무파트별로 수신메소트에 전달_20130219
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
//			else{
//				if(PAZ500BEAN.BZCD_PA.equals(output.getBzDcd())) {
//					output.setOptnKey(PAZ500BEAN.OPTNKEY_S);	// set [옵션키]
//					pax001bean.callBackTgmTrrv(output);			// 업무파트에 수신내용 callBack
//			    }
//			}
			
		} catch (Exception e) {
			logger.error("Exception", e);
			// TODO: output에 오류 코드 및 오류 Message를 설정함.
			//       오류코드가 정확하게 Mapping이 되어야 한다면 예외
//		} finally {
			// TODO: 결과를 DB에 log를 남겨야 하는 경우 Logging 남기는 bean의 method() 호출하여 DB에 log를 남김.
			// BEAN의 method는 @TransactionalOperation(propagation=Propagation.REQUIRES_NEW)으로 만듦.
		}

		return output;
	}
	
	/**
	 * 자동집금처리 호출(입금,집금) - 처리코드(02)
	 * @param OAKSNTKSNP010050100000In  자동집금처리 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setDpsPrcs(COM_F_KSNOSKSPO00004In input, String rltmTrsfTxNo) throws ApplicationException {

		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회
		
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
//		String rltmTrsfTxNo = input.getPprnSb().substring(0, 20);	// 리얼타임이체거래번호 추출
//		String optnKey = input.getPprnSb().substring(20, 21);	// 옵션키
//		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String tgmCont = "";									// 전문내용
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
//		
//		todayHms = currentDate.format(toDay).toString().replace(":", "");

		//임시 : 2013-10-25(정상일때는 이렇게,, 비정상일때는 막아도 됨)		
//		if( FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT ) {  	// 개발서버 
//		if( FwUtil.getSystemType() == FwUtil.SYSTEM_TEST ||				// 검증서버 
//		    FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT ) {  	// 개발서버
//			input.setAnswCd("0000");
//			input.setBnkAnswCd("0000");
//		}

		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				// 응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
				if(!"0000".equals(input.getAnswCd()) || !"0000".equals(input.getBnkAnswCd())){
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
					
				}else{
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd(input.getAnswCd());		// 업체즉시이체결과코드 : 응답코드 세팅
				realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
			}
			
			//realTmSetInfo.setRltmTrsfPmpsNo(input.getPmpsNo().trim());  //납부자번호
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/
			
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/			
				
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
//			else{
//				output.setOptnKey(PAZ500BEAN.OPTNKEY_S);	// set [옵션키]
//				pax001bean.callBackTgmTrrv(output);			// 업무파트에 수신내용 callBack
//			}			
			
		} catch (Exception e) {
			logger.error("Exception", e);
			// TODO: output에 오류 코드 및 오류 Message를 설정함.
			//       오류코드가 정확하게 Mapping이 되어야 한다면 예외
//		} finally {
			// TODO: 결과를 DB에 log를 남겨야 하는 경우 Logging 남기는 bean의 method() 호출하여 DB에 log를 남김.
			// BEAN의 method는 @TransactionalOperation(propagation=Propagation.REQUIRES_NEW)으로 만듦.
		}

		return output;
	}
	
	/**
	 * 이체처리결과조회(이체확인) - 처리코드(03)
	 * @param OAKSNTKSNP060010100000In  이체처리결과조회 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setTrsfPrcsRstInq(COM_F_KSNOSKSPO00005In input, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회

		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		
//		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String tgmCont = "";									// 전문내용
		
		
		logger.debug("=> input <== {}" + input); 
		
		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
		/*	if(realTmInfo == null || !PAZ500BEAN.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{*/
				
			//	if(!"0000".equals(input.getAnswCdH()) || !"0000".equals(input.getBnkAnswCdH())){
				if("0000".equals(input.getBnkAnswCd()) && "0000".equals(input.getPrcsRst())){
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
					realTmSetInfo.setFininImtrsfRcd(input.getPrcsRst());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
					logger.debug("정상 & 정상인 경우");
					
				}else if (!"0000".equals(input.getBnkAnswCd())) { // 응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
 					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
 					realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
 					logger.debug("은행 비정상 경우");
				}else {
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
 					realTmSetInfo.setFininImtrsfRcd(input.getPrcsRst());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
 					logger.debug("아닌경우");
				}

			//	realTmSetInfo.setKsnetImmdtTrsfRcd(input.getAnswCdH());		// 케이에스넷즉시이체결과코드 : 응답코드 세팅
				realTmSetInfo.setCmpyImtrsfRcd(input.getAnswCd());		// 업체즉시이체결과코드 : 응답코드 세팅
				
		//	}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/

			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			
		} catch (Exception e) {
			logger.error("Exception", e);
			// TODO: output에 오류 코드 및 오류 Message를 설정함.
			//       오류코드가 정확하게 Mapping이 되어야 한다면 예외
//		} finally {
			// TODO: 결과를 DB에 log를 남겨야 하는 경우 Logging 남기는 bean의 method() 호출하여 DB에 log를 남김.
			// BEAN의 method는 @TransactionalOperation(propagation=Propagation.REQUIRES_NEW)으로 만듦.
		}

		return output;
	}
	
	/**
	 * 집계처리 - 처리코드(05)
	 * @param OAKSNTKSNP070010000000In 집계처리 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setTotPrcs(COM_F_KSNOSKSPO00014In input, String rltmTrsfTxNo) throws ApplicationException {
		
		logger.info("집계처리결과 : {} ", input);			//[T1409260036] 집계전문 결과확인용(BPAH073B)

		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회

		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		//String rltmTrsfTxNo = input.getPprn1().substring(0, 20);	// 리얼타임이체거래번호 추출
		//String optnKey = input.getPprn1().substring(20, 21);	// 옵션키
//		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String tgmCont = "";									// 전문내용

		String trsfDt = input.getTrmsDt() ;    //전송일자	
		String trsfObjFininCd = input.getBnkCd3().toString() ;
		
		trsfObjFininCd = StringUtils.lpad("", 3 - trsfObjFininCd.length(), "0") + trsfObjFininCd;
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
//		
//		todayHms = currentDate.format(toDay).toString().replace(":", "");

		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			//realTmInfo = pam056dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);	[T1409260036]
			realTmInfo = cmb001dbio.selectOneTBCMRTM0012(trsfDt, trsfObjFininCd , StringUtils.lpad(input.getTgmNo().toString(), 7, "0"));
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				// 응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
				if(!"0000".equals(input.getAnswCd()) || !"0000".equals(input.getBnkAnswCd())){
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
					
				}else{
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd(input.getAnswCd());		// 케이에스넷즉시이체결과코드 : 응답코드 세팅
				realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
			}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			//iResult = pax001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, realTmInfo.getRltmTrsfTxNo());
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/

			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
			
		} catch (Exception e) {
			// TODO: output에 오류 코드 및 오류 Message를 설정함.
			//       오류코드가 정확하게 Mapping이 되어야 한다면 예외
			logger.debug("집계처리 Exception");
//		} finally {
			// TODO: 결과를 DB에 log를 남겨야 하는 경우 Logging 남기는 bean의 method() 호출하여 DB에 log를 남김.
			// BEAN의 method는 @TransactionalOperation(propagation=Propagation.REQUIRES_NEW)으로 만듦.
		}

		return output;
	}
	
	/**
	 * 출금이체신청(납부자번호등록) - 처리코드(06)
	 * @param OAKSNTKSNP060050100000In 출금이체신청 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setWdmTrsfAppl(COM_F_KSNOSKSPO00003In input, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회

		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		
		
//		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String tgmCont = "";									// 전문내용
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
//		
//		todayHms = currentDate.format(toDay).toString().replace(":", "");

		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				
				if("0000".equals(input.getBnkAnswCd())){
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : 정상(TRMSDCD_2)]
				}else{
					// 	응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);		// set [전송구분코드 : 오류(TRMSDCD_3)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd(input.getAnswCd());		// 업체즉시이체결과코드 : 응답코드 세팅
				realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());	// 금융기관즉시이체결과코드 : 은행응답코드 세팅
			}
			
			//realTmSetInfo.setRltmTrsfPmpsNo(input.getPmpsNo().trim());  //납부자번호
			
			logger.debug("※※※※※input ===> {}", input);
			logger.debug("※※※※※realTmSetInfo ===> {}", realTmSetInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/

			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}			
			
		} catch (Exception e) {
			logger.error("Exception", e);
			// TODO: output에 오류 코드 및 오류 Message를 설정함.
			//       오류코드가 정확하게 Mapping이 되어야 한다면 예외
//		} finally {
			// TODO: 결과를 DB에 log를 남겨야 하는 경우 Logging 남기는 bean의 method() 호출하여 DB에 log를 남김.
			// BEAN의 method는 @TransactionalOperation(propagation=Propagation.REQUIRES_NEW)으로 만듦.
		}

		return output;
	}
	
	/**
	 * 예금주명 확인처리 - 처리코드(07)
	 * @param OAKSNTKSNP060040000000In 예금주명 확인처리 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setChkAchdNmVrfcPrcs(COM_F_KSNOSKSFO00001In input, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회

		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		
//		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String tgmCont = "";									// 전문내용
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
//		
//		todayHms = currentDate.format(toDay).toString().replace(":", "");

		try {
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			/*if(realTmInfo == null || !PAZ500BEAN.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{*/
				// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
				if("0000".equals(input.getBnkAnswCd())){					
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
			
				}else{
					//응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅 
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd(input.getAnswCd());		// 케이에스넷즉시이체결과코드 : 응답코드 세팅
				realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				realTmSetInfo.setAchdNm(input.getAchdNm());					// 예금주명 : 계좌성명 세팅
				
			//}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/
			logger.debug("☆★☆=예금주조회 update 정보 시작===================================");
			logger.debug("☆★☆==========> realTmSetInfo={}", realTmSetInfo);
			logger.debug("☆★☆=예금주조회 update 정보 끝===================================");
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
			
			
		} catch (Exception e) {
			logger.error("Exception", e);
			// TODO: output에 오류 코드 및 오류 Message를 설정함.
			//       오류코드가 정확하게 Mapping이 되어야 한다면 예외
//		} finally {
			// TODO: 결과를 DB에 log를 남겨야 하는 경우 Logging 남기는 bean의 method() 호출하여 DB에 log를 남김.
			// BEAN의 method는 @TransactionalOperation(propagation=Propagation.REQUIRES_NEW)으로 만듦.
		}

		return output;
	}
	
	
	/**
	 * 잔액조회 - 처리코드(08)
	 * @param OAKSNTKSNP060030000000In 잔액조회 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setBamtInq(COM_F_KSNOSKSPO00013In input, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		TBCMRTM011Io realmoAct = new TBCMRTM011Io();			// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;			// 리얼타임전문로그key를 위한 db시간조회		

		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		int iResult3 = 0;		
		
		
//		String optnKey = input.getPprn1().substring(20, 21);	// 옵션키
//		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String tgmCont = "";									// 전문내용
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
//		
//		todayHms = currentDate.format(toDay).toString().replace(":", "");
		
		logger.debug("☆★☆★☆ ★☆ =========== setBamtInq {}" + input); 

		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				
				if("0000".equals(input.getBnkAnswCd())){
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]					
				}else{
					// 응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd(input.getAnswCd());		// 케이에스넷즉시이체결과코드 : 응답코드 세팅
				realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
			}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/

			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//            
//			logger.debug("입력값 확인 1111111111111111111111 tgmLogPrcsDtm.getTgmLogPrcsDtm()={}",tgmLogPrcsDtm.getTgmLogPrcsDtm());
//			logger.debug("입력값 확인 1111111111111111111111 realTmInfo.getTrsfObjFininCd()={}", realTmInfo.getTrsfObjFininCd());
//			logger.debug("입력값 확인 1111111111111111111111 realTmInfo.getRltmTgmNo()={}", realTmInfo.getRltmTgmNo());
//			
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfObjFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			/* 모계좌 조회 table Insert Or Update */
			 
			String wkMoAmtBamt = "";
			logger.debug("☆★☆★☆ ★☆ ====================> 모계좌테이블 조회 시작<==================== ★☆ ☆★☆★☆ ");
			//wkMoAmtBamt = cmb001dbio.selectOneTBCMRTM0110(realTgmLog.getTrsfPrcsFininCd());
		
		
			realmoAct.setFininCd(realTmInfo.getTrsfObjFininCd());	// set [이체처리금융기관코드] - 금융기관코드(3)
			realmoAct.setPrcsDtm(realTmInfo.getTrsfDt() + realTmInfo.getTrsfPrcsTi());			// set [전문로그처리일시]			
			realmoAct.setMoActNo(SecuUtil.getEncValue(input.getActNo(), EncType.actNo));				// set [모계좌번호]
			realmoAct.setMoActBamt(input.getActBamt());				// set [모계좌금액]
			realmoAct.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realmoAct.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realmoAct.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			//logger.debug("☆★☆★☆ ★☆ ====================> 모계좌테이블 insert 하기전 wkMoAmtBamt={}" , wkMoAmtBamt);
			
			logger.debug("☆★☆★☆ ★☆ ====================> 모계좌테이블 insert 하기전 insert={}" , realmoAct);
			iResult3 = cmb001bean.insertmoActBamt(realmoAct, "I");
			
//			if(StringUtils.isEmpty(wkMoAmtBamt)){
//				logger.debug("☆★☆★☆ ★☆ ====================> 모계좌테이블 insert 하기전 insert={}" , realmoAct);
//				iResult3 = cmb001bean.insertmoActBamt(realmoAct, "I");
//			}else{
//				logger.debug("☆★☆★☆ ★☆ ====================> 모계좌테이블 update 하기전 update={}" , realmoAct);
//				iResult3 = cmb001bean.insertmoActBamt(realmoAct, "U");
//			}
			
			if(iResult3 != 1){
				// SQL오류, 모계좌잔액관리 테이블입력 오류가 발생했습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"모계좌잔액관리 테이블입력"});
			}
			


			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
			
		} catch (Exception e) {
			logger.error("Exception", e);
			// TODO: output에 오류 코드 및 오류 Message를 설정함.
			//       오류코드가 정확하게 Mapping이 되어야 한다면 예외
//		} finally {
			// TODO: 결과를 DB에 log를 남겨야 하는 경우 Logging 남기는 bean의 method() 호출하여 DB에 log를 남김.
			// BEAN의 method는 @TransactionalOperation(propagation=Propagation.REQUIRES_NEW)으로 만듦.
		}

		return output;
	}
	
	
}

