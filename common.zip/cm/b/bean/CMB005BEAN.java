package cigna.cm.b.bean;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.io.COM_F_KIBOSKIBO00001In;
import cigna.cm.b.io.COM_F_KIBOSKIBO00004In;
import cigna.cm.b.io.COM_F_KIBOSKIBO00005In;
import cigna.cm.b.io.COM_F_KIBOSKIBO00006In;
import cigna.cm.b.io.COM_F_KIBOSKIBO00007In;
import cigna.cm.b.io.COM_F_KIBOSKIBO00008In;
import cigna.cm.b.io.COM_F_KIBOSKIBO00011In;
import cigna.cm.b.io.KIB_F_COMOSKIBO00001In;
import cigna.cm.b.io.TBCMRTM001Io;
import cigna.cm.b.io.TBCMRTM004Io;
import cigna.cm.b.io.TBCMRTM011Io;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;


/**
 * @file         cigna.cm.b.bean.CMB005BEAN.java
 * @filetype     java source file
 * @brief        KIBNET 수신처리
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                           성명                                               일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(현승훈)             2016. 2. 23.       신규 작성
 *
 */
@KlafBean
public class CMB005BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	

	@Autowired
	private CMB001DBIO cmb001dbio;		// 전문번호 체크
	
	@Autowired
	private CMB001BEAN cmb001bean;		// 지급이체자금이체송수신처리_메인
	
	/**
	 * 자동이체처리 호출(송금,지급) - 처리코드(01)
	 * @param COM_F_KIBOS000000001In  자동이체처리 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setAtrPrcs(COM_F_KIBOSKIBO00001In input, String rltmTrsfTxNo, String propoDeptOrgNo, String moActNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값		

		String tgmCont = "";									// 전문내용
		
		try {
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				if (StringUtils.isEmpty(input.getBnkAnswCd()) || StringUtils.isEmpty(input.getBnkAnswCd())) {
					realTmSetInfo.setFininImtrsfRcd("0" + input.getAnswCd());	// 업체즉시이체결과코드 : 응답코드 세팅
				} else {
					realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				}
				
				if(!"0000".equals(input.getBnkAnswCd())){
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]					
				}else{
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd("0" + input.getAnswCd());		// 업체즉시이체결과코드 : 응답코드 세팅
				
				realTmSetInfo.setPropoDeptOrgNo(propoDeptOrgNo); //발의부서 
				realTmSetInfo.setMoActNo(moActNo);				 //모계좌
			}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/
			
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
		
			// 옵션키(A:aSync, S:sync) 가 'A'일 경우 aSync 타입으로 return값을 세팅하여 각 업무파트별로 수신메소트에 전달_20130219
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}

			
		} catch (Exception e) {
			logger.error("Exception", e);
		}

		return output;
	}
	
	/**
	 * 자동집금처리 호출(입금,집금) - 처리코드(02)
	 * @param COM_F_KIBOS000000004In  자동집금처리 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setDpsPrcs(COM_F_KIBOSKIBO00004In input, String rltmTrsfTxNo, String propoDeptOrgNo, String moActNo) throws ApplicationException {

		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값

		String tgmCont = "";									// 전문내용

		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			} else{
				
				if (StringUtils.isEmpty(input.getBnkAnswCd()) || StringUtils.isEmpty(input.getBnkAnswCd())) {
					realTmSetInfo.setFininImtrsfRcd("0" + input.getAnswCd());	// 업체즉시이체결과코드 : 응답코드 세팅
				} else {
					realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				}
				
				if(!"000".equals(input.getAnswCd()) || !"0000".equals(input.getBnkAnswCd())){
					if (!"000".equals(input.getBnkAnswCd())) {
						realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
					} else {
						realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
					}
				}else{
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd("0" + input.getAnswCd());		// 업체즉시이체결과코드 : 응답코드 세팅
				
				realTmSetInfo.setPropoDeptOrgNo(propoDeptOrgNo);
				realTmSetInfo.setMoActNo(moActNo);
			}			
			
			logger.debug("=========  입금 realTmSetInfo =========" + realTmSetInfo)     ;
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/
			
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/			
				
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
			
			logger.debug("========== 처리 결과 ===========" + output);
			
		} catch (Exception e) {
			logger.error("Exception", e);
		}

		return output;
	}
	
	/**
	 * 이체처리결과조회(이체확인) - 처리코드(03)
	 * @param COM_F_KIBOS000000008In  이체처리결과조회 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setTrsfPrcsRstInq(COM_F_KIBOSKIBO00008In input, String rltmTrsfTxNo, String dpwdDcd, String bzDcd, String bzTmKeyVl, String propoDeptOrgNo,String moActNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)

		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
				
		String tgmCont = "";									// 전문내용
		
		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
				
			if("0000".equals(input.getOrgtrAnswCd()) || "000".equals(input.getOrgtrAnswCd())){
				// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
				realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
				if (StringUtils.nvl(input.getOrgtrAnswCd()).length() == 3) {
					realTmSetInfo.setFininImtrsfRcd("0" + input.getOrgtrAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				} else {
					realTmSetInfo.setFininImtrsfRcd(input.getOrgtrAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				}
				logger.debug("정상 & 정상인 경우");
				
			}else if (!"0000".equals(input.getOrgtrAnswCd()) || !"000".equals(input.getOrgtrAnswCd())) { // 응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
				realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
				if (StringUtils.nvl(input.getOrgtrAnswCd()).length() == 3) {
					realTmSetInfo.setFininImtrsfRcd("0" + input.getOrgtrAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				} else {
					realTmSetInfo.setFininImtrsfRcd(input.getOrgtrAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				}
				logger.debug("은행 비정상 경우");
			}else {
				realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
				realTmSetInfo.setFininImtrsfRcd("0" + input.getAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				logger.debug("아닌경우");
			}

			realTmSetInfo.setCmpyImtrsfRcd("0" + input.getAnswCd());		// 업체즉시이체결과코드 : 응답코드 세팅
			
			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			
			if (bzTmKeyVl != null  && bzDcd != null) {
				if(RTCont.DPWD_DCD_DPS.equals(dpwdDcd)){		// 입출금구분코드가 입금(1) 일 경우
					iResult = cmb001dbio.updateOneTBCMRTM0012(realTmSetInfo.getCmpyImtrsfRcd(), 
							realTmSetInfo.getFininImtrsfRcd(), 
							realTmSetInfo.getRltmTrmsDcd(), 
							propoDeptOrgNo,
							moActNo,
							FwUtil.getUserId(), 
							FwUtil.getPgmId(), 
							FwUtil.getTrmNo(), 
							bzDcd, 
							bzTmKeyVl,
							"02",
							today);
				}else{
					iResult = cmb001dbio.updateOneTBCMRTM0012(realTmSetInfo.getCmpyImtrsfRcd(), 
							realTmSetInfo.getFininImtrsfRcd(), 
							realTmSetInfo.getRltmTrmsDcd(), 
							propoDeptOrgNo,
							moActNo,
							FwUtil.getUserId(), 
							FwUtil.getPgmId(), 
							FwUtil.getTrmNo(), 
							bzDcd, 
							bzTmKeyVl,
							"01",
							today);
				}	
				
				if(iResult != 1){
					// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
					throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경(원거래)"});
				}
			}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/

			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			
		} catch (Exception e) {
			logger.error("Exception", e);			
		}

		return output;
	}
	
	
	/**
	 * 출금이체신청(납부자번호등록) - 처리코드(06)
	 * @param COM_F_KIBOS000000005In 출금이체신청 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setWdmTrsfAppl(COM_F_KIBOSKIBO00005In input, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값

		String tgmCont = "";									// 전문내용
		

		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				
				if("0000".equals(input.getBnkAnswCd())){
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);		// set [전송구분코드 : 정상(TRMSDCD_2)]
				}else{
					// 	응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);		// set [전송구분코드 : 오류(TRMSDCD_3)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd("0" + input.getAnswCd());		// 업체즉시이체결과코드 : 응답코드 세팅
				if (StringUtils.isEmpty(input.getBnkAnswCd()) || input.getBnkAnswCd() == null) {
					realTmSetInfo.setFininImtrsfRcd("0" + input.getAnswCd());	// 업체즉시이체결과코드 : 응답코드 세팅
				} else {
					realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				}
			}
			
			//realTmSetInfo.setRltmTrsfPmpsNo(input.getPmpsNo().trim());  //납부자번호
			
			logger.debug("※※※※※input ===> {}", input);
			logger.debug("※※※※※realTmSetInfo ===> {}", realTmSetInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/

			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}			
			
		} catch (Exception e) {
			logger.error("Exception", e);
		}

		return output;
	}
	
	/**
	 * 수취조회 - 처리코드(10)
	 * @param COM_F_KIBOSKIBO00006In 수취조회 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setRecvInq(COM_F_KIBOSKIBO00006In input, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String tgmCont = "";									// 전문내용
		
		try {
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			/*if(realTmInfo == null || !PAZ500BEAN.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{*/
				// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
			if("0000".equals(input.getBnkAnswCd())){					
				realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
		
			}else{
				//응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅 
				realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
			}
			
			realTmSetInfo.setCmpyImtrsfRcd("0" + input.getAnswCd());		// 케이에스넷즉시이체결과코드 : 응답코드 세팅
			realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
//			realTmSetInfo.setAchdNm(input.getDpsActName());					// 예금주명 : 계좌성명 세팅
				
			//}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/
			logger.debug("☆★☆=예금주조회 update 정보 시작===================================");
			logger.debug("☆★☆==========> realTmSetInfo={}", realTmSetInfo);
			logger.debug("☆★☆=예금주조회 update 정보 끝===================================");
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
			
			
		} catch (Exception e) {
			logger.error("Exception", e);
		}

		return output;
	}
	
	
	/**
	 * 타행이체불능명세통지_KS-NET
	 * @param OAKSNTKSNP040010000000In 타행이체불능명세처리 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setImposstPrcs(KIB_F_COMOSKIBO00001In input,String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		
		String tgmCont = "";								// 전문내용
		
		try {
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
						
			SecuUtil.doEncObject(realTmInfo);

			//타행이체불능명세통지_이므로 전송구분코드에 오류(3) 세팅 
			realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
			realTmSetInfo.setFininImtrsfRcd("0" + input.getImpAnswCd()) ;   // 타행이체불능명세 오류코드로 update
			realTmSetInfo.setCmpyImtrsfRcd(input .getImpAnswCd()) ;   // 타행이체불능명세 오류코드로 update ks-net 응답
			if(input.getBnkAnswCd() != null && !"0000".equals(input.getBnkAnswCd()))	{	
				realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd()) ;
				realTmSetInfo.setCmpyImtrsfRcd("0" +  input.getAnswCd()) ;
			}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, realTmInfo.getRltmTrsfTxNo());
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/
			logger.debug("☆★☆=타행이체불능명세통지 update 정보 시작===================================");
			logger.debug("☆★☆==========> realTmSetInfo={}", realTmSetInfo);
			logger.debug("☆★☆=타행이체불능명세통지 update 정보 끝===================================");
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(realTmInfo.getRltmTrsfTxNo());
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
			
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		
		return output;
	}
	
	/**
	 * 실명조회 KIBNET
	 * @param COM_F_KIBOS000000006In 수취조회 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setRecvInq(COM_F_KIBOSKIBO00007In input,String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)

		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		
		String tgmCont = "";								// 전문내용
		
		//BigDecimal rltmTgmNo = input.getOrgtrTgmNo() ;	// 원거래전문번호 (이체마스터 전문번호(7자리)로 자리수 동기화, 2014.01.10)
		
		logger.debug("☆★☆==========> setRecvInq={}", input);
		
		try {
			
			logger.debug("☆★☆==========> setRecvInq={}", input);
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
						
			SecuUtil.doEncObject(realTmInfo);
			
			if ("023".equals(realTmInfo.getTrsfObjFininCd())) {
				if (!StringUtils.isEmpty( input.getBnkAnswCd()) &&  input.getBnkAnswCd().length() >= 3 ) {
					if("000".equals(input.getBnkAnswCd().substring(0, 3))){					
						realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
				
					}else{
						//응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅 
						realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
					}
					realTmSetInfo.setCmpyImtrsfRcd("0" +input.getAnswCd());		// 케이에스넷즉시이체결과코드 : 응답코드 세팅
					//realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
					if (StringUtils.isEmpty(input.getBnkAnswCd()) || input.getBnkAnswCd() == null) {
						realTmSetInfo.setFininImtrsfRcd("0" + input.getAnswCd());	// 업체즉시이체결과코드 : 응답코드 세팅
					} else {
						realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd().substring(0, 3));		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
					}
				} else {					
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
					
					if (StringUtils.isEmpty(input.getBnkAnswCd()) || input.getBnkAnswCd() == null) {
						realTmSetInfo.setFininImtrsfRcd("0" + input.getAnswCd());	// 업체즉시이체결과코드 : 응답코드 세팅
					} else {
						realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
					}
				}
			} else {
				if("0000".equals(input.getBnkAnswCd())){					
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]
			
				}else{
					//응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅 
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
				}
				realTmSetInfo.setCmpyImtrsfRcd("0" +input.getAnswCd());		// 케이에스넷즉시이체결과코드 : 응답코드 세팅
				//realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				if (StringUtils.isEmpty(input.getBnkAnswCd()) || input.getBnkAnswCd() == null) {
					realTmSetInfo.setFininImtrsfRcd("0" + input.getAnswCd());	// 업체즉시이체결과코드 : 응답코드 세팅
				} else {
					realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				}
			}
			
			realTmSetInfo.setAchdNm(input.getDpsActName());					// 예금주명 : 계좌성명 세팅
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, realTmInfo.getRltmTrsfTxNo());
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/			
			logger.debug("☆★☆==========> realTmSetInfo={}", realTmSetInfo);
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));

//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfPrcsFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			
			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(realTmInfo.getRltmTrsfTxNo());
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
			
		} catch (Exception e) {
			logger.error("Exception", e);
		}
		
		return output;
	}
	
	/**
	 * 잔액조회 - 처리코드(08)
	 * @param OAKSNTKSNP060030000000In 잔액조회 OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public TrsfTrrvPrcsInfo setBamtInq(COM_F_KIBOSKIBO00011In input, String rltmTrsfTxNo) throws ApplicationException {
		
		TrsfTrrvPrcsInfo output 	= null;
		TBCMRTM001Io realTmInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001)
		TBCMRTM001Io realTmSetInfo 	= new TBCMRTM001Io();		// 리얼타임이체원장(TBCMRTM001) 수신이후 원장UPDATE 세팅용
		TBCMRTM004Io realTgmLog = new TBCMRTM004Io();			// 리얼타임전문로그(TBCMRTM004)
		TBCMRTM011Io realmoAct = new TBCMRTM011Io();			// 리얼타임전문로그(TBCMRTM004)
		
		int iResult = 0;										// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 수행결과값
		int iResult2 = 0;										// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		int iResult3 = 0;		
		
//		String optnKey = input.getPprn1().substring(20, 21);	// 옵션키
//		String todayHms = "";									// 오늘일자(YYYYMMDDHHMISS)
		String tgmCont = "";									// 전문내용
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
//		
//		todayHms = currentDate.format(toDay).toString().replace(":", "");

		try {

			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE START ********************************/
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드 UPDATE 하기전 전송구분코드값 확인
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 리얼타임이체원장(TBCMRTM001) 전송구분코드가 전송(1)이 아닐경우 오류 : 전송전 update 입력한 전송구분코드가 전송(1) 이므로..
			if(realTmInfo == null || !RTCont.TRMSDCD_1.equals(realTmInfo.getRltmTrmsDcd())){
				// 오류, '리얼타임이체원장 변경을 할수 없습니다. 전송구분코드를 확인해주세요. (전송구분코드값)'
				throw new ApplicationException("APPAE0056", new Object[]{"(" + realTmInfo.getRltmTrmsDcd() + ")"});
			}else{
				
				if("0000".equals(input.getBnkAnswCd())){
					// 전송구분코드 전송(1)을 전문발송전 정상(2)로 변경하여 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_2);	// set [전송구분코드 : 정상(TRMSDCD_2)]					
				}else{
					// 응답코드가 오류코드로 수신받을시 전송구분코드에 오류(3) 세팅
					realTmSetInfo.setRltmTrmsDcd(RTCont.TRMSDCD_3);	// set [전송구분코드 : 오류(TRMSDCD_3)]
				}
				
				realTmSetInfo.setCmpyImtrsfRcd("0" + input.getAnswCd());		// 케이에스넷즉시이체결과코드 : 응답코드 세팅
				
				if (!StringUtils.isEmpty(input.getBnkAnswCd())) {
					realTmSetInfo.setFininImtrsfRcd(input.getBnkAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				} else {
					realTmSetInfo.setFininImtrsfRcd("0" + input.getAnswCd());		// 금융기관즉시이체결과코드 : 은행응답코드 세팅
				}
			}
			
			// 리얼타임이체원장(TBCMRTM001) 즉시이체결과코드, 즉시이체결과공통전환코드, 전송구분코드 UPDATE
			iResult = cmb001bean.updateImtrsf(realTmSetInfo, rltmTrsfTxNo);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임이체원장변경"});
			}
			
			/******************************** 수신이후 리얼타임이체원장(TBCMRTM001) UPDATE END ********************************/

			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			
			// 전문내용을 리얼타임전문로그(TBCMRTM004) INSERT 하기 위한 작업
			tgmCont = new String(FwUtil.toBytes(input));
			
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(realTmInfo.getTrsfObjFininCd());		// set [이체처리금융기관코드] - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(realTmInfo.getRltmTgmNo());		// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);							// set [전문내용]
//			realTgmLog.setLastChgDtm();								// set [최종변경일시]
			realTgmLog.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			/* 모계좌 조회 table Insert Or Update */
			logger.debug("☆★☆★☆ ★☆ ====================> 모계좌테이블 조회 시작<==================== ★☆ ☆★☆★☆ ");
			//wkMoAmtBamt = cmb001dbio.selectOneTBCMRTM0110(realTgmLog.getTrsfPrcsFininCd());
		
		
			realmoAct.setFininCd(realTmInfo.getTrsfObjFininCd());	// set [이체처리금융기관코드] - 금융기관코드(3)
			realmoAct.setPrcsDtm(realTmInfo.getTrsfDt() + realTmInfo.getTrsfPrcsTi());			// set [전문로그처리일시]			
			realmoAct.setMoActNo(SecuUtil.getEncValue(input.getWdmActNo().trim(), EncType.moActNo));				// set [모계좌번호]
			realmoAct.setMoActBamt(input.getTxAfActBamt());				// set [모계좌금액]
			realmoAct.setLastChgrId(FwUtil.getUserId());			// set [최종변경자ID]
			realmoAct.setLastChgPgmId(FwUtil.getPgmId());			// set [최종변경프로그램ID]
			realmoAct.setLastChgTrmNo(FwUtil.getTrmNo());			// set [최종변경단말번호]
			//logger.debug("☆★☆★☆ ★☆ ====================> 모계좌테이블 insert 하기전 wkMoAmtBamt={}" , wkMoAmtBamt);
			
			logger.debug("☆★☆★☆ ★☆ ====================> 모계좌테이블 insert 하기전 insert={}" , realmoAct);
			iResult3 = cmb001bean.insertmoActBamt(realmoAct, "I");
			
			if(iResult3 != 1){
				// SQL오류, 모계좌잔액관리 테이블입력 오류가 발생했습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"모계좌잔액관리 테이블입력"});
			}
			


			// 전문수행이후 대업무파트 응답용 DO 세팅하기 위해 리얼타임이체원장(TBCMRTM001) 조회
			realTmInfo = cmb001dbio.selectOneTBCMRTM0010(rltmTrsfTxNo);
			SecuUtil.doDecObject(realTmInfo);
			
			// 전문수행이후 조회한 리얼타임이체원장(TBCMRTM001)으로 대업무파트 응답용 DO (TrsfTrrvPrcsInfo) 세팅
			output = cmb001bean.setPrcsInfo(realTmInfo);
			
			if(output == null){
				// 오류!!!, '대업무파트 응답용 도메인이 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0079", null);
				
			}
			
		} catch (Exception e) {
			logger.error("Exception", e);
		}

		return output;
	}
}

