package cigna.cm.b.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.io.SelectMultiTBCMRTM0050Out;
import cigna.cm.b.io.SelectOneTBCMRTM0050Out;
import cigna.cm.b.io.TBCMRTM005Io;
import cigna.cm.b.io.SelectMultiTBCMRTM008aOut;

import cigna.cm.b.io.TBCMRTM008Io;
import cigna.cm.b.io.SelectOneTBCMRTM0080Out;

import cigna.zz.FwUtil;


/**
 * @file         cigna.cm.b.bean.CMB005BEAN.java
 * @filetype     java source file
 * @brief
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈       2016. 2. 23.       신규 작성
 *
 */
@KlafBean
public class CMB006BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	

	@Autowired
	private CMB001DBIO cmb001dbio;		// 전문번호 체크
	
	
	/**
	 * 지급이체 공지사항등록관리(조회)
	 * @param anceScrnNm 공지사항명
	 * @return 지급이체 공지사항등록관리 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMRTM0050Out> getAnceMtrInq(String anceScrnNm) throws ApplicationException {
		
		/*
		if (StringUtils.isEmpty(anceScrnNm)) {
			throw new ApplicationException( "APPAE0002", new Object[]{"공지사항명"} );
		}
		*/
		
		List<SelectMultiTBCMRTM0050Out> anceMtrList = cmb001dbio.selectMultiTBCMRTM00501();
		
		return anceMtrList;
	}
	
	/**
	 * 지급이체 공지사항등록관리(등록)
	 * @param answCdInqInfo 지급이체 응답코드관리정보
	 * @return 처리건수
	 * @throws ApplicationException
	 */
	public int setAnceMtrCrt(SelectMultiTBCMRTM0050Out anceMtrInqInfo) throws ApplicationException {
		
		if( anceMtrInqInfo == null || StringUtils.isEmpty(anceMtrInqInfo.getAnceScrnNm()) ) {
			throw new ApplicationException( "APPAE0006", null );
		}
		
		if( StringUtils.isEmpty(anceMtrInqInfo.getAnceStrtDt()) ) {
			throw new ApplicationException( "APPAE0002", new Object[]{"공지시작일자"} );
		}
		
		if( StringUtils.isEmpty(anceMtrInqInfo.getAnceEndTi()) ) {
			throw new ApplicationException( "APPAE0002", new Object[]{"공지시작시각"} );
		}
		
		
		TBCMRTM005Io tbcmrtm005io = new TBCMRTM005Io();
		
		tbcmrtm005io.setAnceScrnNm(anceMtrInqInfo.getAnceScrnNm());  // 공지화면명
		tbcmrtm005io.setAnceStrtDt(anceMtrInqInfo.getAnceStrtDt());  // 공지시작일자
		tbcmrtm005io.setAnceStrtTi(anceMtrInqInfo.getAnceStrtTi());  // 공지시작시각
		tbcmrtm005io.setAnceEndDt(anceMtrInqInfo.getAnceEndDt());    // 공지종료일자
		tbcmrtm005io.setAnceEndTi(anceMtrInqInfo.getAnceEndTi());    // 공지종료시각
		tbcmrtm005io.setAnceCtnt(anceMtrInqInfo.getAnceCtnt());      // 공지내용
		tbcmrtm005io.setLastChgrId(FwUtil.getUserId());              // 최종변경자ID(LAST_CHGR_ID) 설정
		tbcmrtm005io.setLastChgPgmId(FwUtil.getPgmId());             // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		tbcmrtm005io.setLastChgTrmNo(FwUtil.getTrmNo());             // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		
		int iCnt = 0;
		SelectOneTBCMRTM0050Out selectOneTBCMRTM0050out = cmb001dbio.selectOneTBCMRTM0050(anceMtrInqInfo.getAnceScrnNm());
		
		if ("N".equals(selectOneTBCMRTM0050out.getDupYn())) {
			iCnt = cmb001dbio.insertOneTBCMRTM00501(tbcmrtm005io);
			
		}else {
			iCnt = cmb001dbio.updateOneTBCMRTM00501(tbcmrtm005io);
			
		}
		

		return iCnt;
	}
	
	/**
	 * 지급이체 공지사항등록관리(수정)
	 * @param answCdInqInfo 지급이체 응답코드관리정보
	 * @return 처리건수
	 * @throws ApplicationException
	 */
	public int setAnceMtrMod(SelectMultiTBCMRTM0050Out anceMtrInqInfo) throws ApplicationException {
		
		if( anceMtrInqInfo == null || StringUtils.isEmpty(anceMtrInqInfo.getAnceScrnNm()) ) {
			throw new ApplicationException( "APPAE0006", null );
		}
		
		TBCMRTM005Io tbcmrtm005io = new TBCMRTM005Io();
		
		tbcmrtm005io.setAnceScrnNm(anceMtrInqInfo.getAnceScrnNm());  // 공지화면명
		tbcmrtm005io.setAnceStrtDt(anceMtrInqInfo.getAnceStrtDt());  // 공지시작일자
		tbcmrtm005io.setAnceStrtTi(anceMtrInqInfo.getAnceStrtTi());  // 공지시작시각
		tbcmrtm005io.setAnceEndDt(anceMtrInqInfo.getAnceEndDt());    // 공지종료일자
		tbcmrtm005io.setAnceEndTi(anceMtrInqInfo.getAnceEndTi());    // 공지종료시각
		tbcmrtm005io.setAnceCtnt(anceMtrInqInfo.getAnceCtnt());      // 공지내용
		tbcmrtm005io.setLastChgrId(FwUtil.getUserId());              // 최종변경자ID(LAST_CHGR_ID) 설정
		tbcmrtm005io.setLastChgPgmId(FwUtil.getPgmId());             // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		tbcmrtm005io.setLastChgTrmNo(FwUtil.getTrmNo());             // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		 
		int iCnt = cmb001dbio.updateOneTBCMRTM00501(tbcmrtm005io);

		return iCnt;
	}
	
	/**
	 * 지급이체 공지사항등록관리(삭제)
	 * @param anceScrnNm 공지사항명
	 * @return 처리건수
	 * @throws ApplicationException
	 */
	public int setAnceMtrDel(String anceScrnNm) throws ApplicationException {
		
		if( StringUtils.isEmpty(anceScrnNm)){
			throw new ApplicationException( "APPAE0006", null );
		}
		
		int iCnt = cmb001dbio.deleteOneTBCMRTM00501(anceScrnNm);

		return iCnt;
	}
	
	
	/**
	 * 지급이체 응답코드관리(조회)
	 * @param fininCd 처리은행
	 * @param imtrsfRcd 응답코드
	 * @return 지급이체 응답코드관리 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMRTM008aOut> getAnswCdInq(String fininCd, String imtrsfRcd, int pageNum, int pageCount) throws ApplicationException {
		
		if (StringUtils.isEmpty(fininCd)) {
			throw new ApplicationException( "APPAE0002", new Object[]{"처리은행코드"} );
		}
		
		fininCd = StringUtils.nvl(fininCd);
		imtrsfRcd = StringUtils.nvl(imtrsfRcd);
		if (imtrsfRcd == null) {
			imtrsfRcd = "%";
		}
		
		List<SelectMultiTBCMRTM008aOut> answCdList = cmb001dbio.selectMultiTBCMRTM0080(fininCd, imtrsfRcd, pageNum, pageCount);
		
		return answCdList;
	}
	
	/**
	 * 지급이체 응답코드관리(입력)
	 * @param answCdInqInfo 지급이체 응답코드관리정보
	 * @return 처리건수
	 * @throws ApplicationException
	 */
	public int setAnswCdCrt(SelectMultiTBCMRTM008aOut answCdInqInfo) throws ApplicationException {
		
		if( answCdInqInfo == null || StringUtils.isEmpty(answCdInqInfo.getFininCd()) || StringUtils.isEmpty(answCdInqInfo.getImtrsfRcd()) ){
			throw new ApplicationException( "APPAE0006", null );
		}
		
		TBCMRTM008Io tbcmrtm008io = new TBCMRTM008Io();
		
		tbcmrtm008io.setFininCd(answCdInqInfo.getFininCd());             // 금융기관코드
		tbcmrtm008io.setImtrsfRcd(answCdInqInfo.getImtrsfRcd());         // 즉시이체결과코드
		tbcmrtm008io.setRltmAnswCtnt(answCdInqInfo.getRltmAnswCtnt());   // 리얼타임응답내용
		tbcmrtm008io.setRltmCautnCtnt(answCdInqInfo.getRltmCautnCtnt()); // 리얼타임조치내용
		tbcmrtm008io.setRltmTrtmCtnt(answCdInqInfo.getRltmTrtmCtnt());   // 리얼타임주의내용
		tbcmrtm008io.setLastChgrId(FwUtil.getUserId());                  // 최종변경자ID(LAST_CHGR_ID) 설정
		tbcmrtm008io.setLastChgPgmId(FwUtil.getPgmId());                 // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		tbcmrtm008io.setLastChgTrmNo(FwUtil.getTrmNo());                 // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		int iCnt = 0;
		logger.debug("\n파라미터  {} {}" , answCdInqInfo.getFininCd(), answCdInqInfo.getImtrsfRcd());
		
		SelectOneTBCMRTM0080Out selectonetbcmrtm0080out = cmb001dbio.selectOneTBCMRTM0080(answCdInqInfo.getFininCd(), answCdInqInfo.getImtrsfRcd());
		
		if ("N".equals(selectonetbcmrtm0080out.getDupYn())) {
			iCnt = cmb001dbio.insertOneTBCMRTM00801(tbcmrtm008io);
			
		}else {
			iCnt = cmb001dbio.updateOneTBCMRTM00801(tbcmrtm008io);
			
		}
		
		return iCnt;
	}
	
	/**
	 * 지급이체 응답코드관리(수정)
	 * @param answCdInqInfo 지급이체 응답코드관리정보
	 * @return 처리건수
	 * @throws ApplicationException
	 */
	public int setAnswCdMod(SelectMultiTBCMRTM008aOut answCdInqInfo) throws ApplicationException {
		
		if( answCdInqInfo == null || StringUtils.isEmpty(answCdInqInfo.getFininCd()) || StringUtils.isEmpty(answCdInqInfo.getImtrsfRcd()) ){
			throw new ApplicationException( "APPAE0006", null );
		}
		
		TBCMRTM008Io tbcmrtm008io = new TBCMRTM008Io();
		
		tbcmrtm008io.setFininCd(answCdInqInfo.getFininCd());             // 금융기관코드
		tbcmrtm008io.setImtrsfRcd(answCdInqInfo.getImtrsfRcd());         // 즉시이체결과코드
		tbcmrtm008io.setRltmAnswCtnt(answCdInqInfo.getRltmAnswCtnt());   // 리얼타임응답내용
		tbcmrtm008io.setRltmCautnCtnt(answCdInqInfo.getRltmCautnCtnt()); // 리얼타임조치내용
		tbcmrtm008io.setRltmTrtmCtnt(answCdInqInfo.getRltmTrtmCtnt());   // 리얼타임주의내용
		tbcmrtm008io.setLastChgrId(FwUtil.getUserId());                  // 최종변경자ID(LAST_CHGR_ID) 설정
		tbcmrtm008io.setLastChgPgmId(FwUtil.getPgmId());                 // 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		tbcmrtm008io.setLastChgTrmNo(FwUtil.getTrmNo());                 // 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		int iCnt = cmb001dbio.updateOneTBCMRTM00801(tbcmrtm008io);

		return iCnt;
	}
	
	/**
	 * 지급이체 응답코드관리(삭제)
	 * @param fininCd 처리은행
	 * @param imtrsfRcd 응답코드
	 * @return 처리건수
	 * @throws ApplicationException
	 */
	public int setAnswCdDel(String fininCd, String imtrsfRcd) throws ApplicationException {
		
		if( StringUtils.isEmpty(fininCd) || StringUtils.isEmpty(imtrsfRcd) ){
			throw new ApplicationException( "APPAE0006", null );
		}
		
		int iCnt = cmb001dbio.deleteOneTBCMRTM00801(fininCd, imtrsfRcd);

		return iCnt;
	}
}

