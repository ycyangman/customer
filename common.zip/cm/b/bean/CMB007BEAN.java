package cigna.cm.b.bean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.io.COM_F_KIBOAKIBO00001In;
import cigna.cm.b.io.COM_F_KIBOSKIBO00012In;
import cigna.cm.b.io.COM_F_KSNOAKSPO00001In;
import cigna.cm.b.io.COM_F_KSNOSKSPO00009In;
import cigna.cm.b.io.SelectOneTBCMRTM0041Out;
import cigna.cm.b.io.TBCMRTM004Io;
import cigna.cm.b.io.TBCMRTM006Io;
import cigna.cm.b.io.TBCMRTM024Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;


/**
 * @file         cigna.cm.b.bean.CMB007BEAN.java
 * @filetype     java source file
 * @brief
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈        2016. 4. 14.       신규 작성
 *
 */
@KlafBean
public class CMB007BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB001DBIO cmb001dbio;		// 전문번호 체크
	
	@Autowired
	private CMB001BEAN cmb001bean;		// 지급이체자금이체송수신처리_메인
	
	@Autowired
	private CMB002BEAN cmb002bean;		// 지급이체자금이체송수신처리_메인
	
	@Autowired
	private CMB003BEAN cmb003bean;		// 지급이체자금이체송수신처리_메인
	
	
	/**
	 * KSNET  A1: 업무개시, A3: 태스트CALL
	 * @input  테스트전문유형
	 * @input  테스트은행
	 * @output 전문로그
	 * @return PAX010SVC00Out  전문로그 
	 * @throws ApplicationException
	 */
	public void  trsfKsnetBzStartA1Sync (String fininCd, String rltmBzDcd, String imtrsfChnlDcd) throws ApplicationException {
		
		String interfaceIdA1 =  "COM_F_KSNOSKSPO00009"; // 개시전문 EAI Interface ID
		String interfaceIdA3 =  "COM_F_KSNOSKSPO00012"; // 테스트콜 EAI Interface ID
		
		String tgmNo 		 =  "";						// 전문번호
		
		String tgmCtgyCd     =  "0800";
		
		String bzDvsnCdA1    =  "100";
		String bzDvsnCdA3    =  "800";
		
		String tgmCont       =  "";
		int iResult2 		 =  0;						// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String tgmLogTxNo    = "";
		String imtrsfChnlDcd2		= "0002";		//입금
		
		try {
			
			COM_F_KSNOSKSPO00009In  request   = new COM_F_KSNOSKSPO00009In();
			
			EISResponse < COM_F_KSNOSKSPO00009In > response = null;
			
			COM_F_KSNOSKSPO00009In responseData = null;
			
			TBCMRTM004Io realTgmLog 	= new TBCMRTM004Io();		// 리얼타임전문로그(TBCMRTM004)
			TBCMRTM006Io fininPtnrInfo 	= new TBCMRTM006Io();		// 금융기관제휴업무목록 업데이트
			SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;

			String today	= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
	
			// 전문번호 생성
			tgmNo = cmb001bean.setTgmNoCrt(fininCd, today);
			if(!StringUtils.hasText(tgmNo)){
				// 전문번호 생성 오류 : '전문번호가 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0057", new Object[]{"전문번호"});
			}
	
			if ("A1".equals(rltmBzDcd)) {
				cmb002bean.setImtrSfchCommonHeader(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA1, imtrsfChnlDcd, "A1");
			}
			else if ("A3".equals(rltmBzDcd)){
				cmb002bean.setImtrSfchCommonHeader(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA3, imtrsfChnlDcd, "A3");
			}
			request.setPprn2(StringUtils.lpad("", 200, " "));
			
			tgmCont = new String(FwUtil.toBytes(request));
	
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(fininCd);	// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);								// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);								// set [전문내용]
			realTgmLog.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE START ********************************/
			fininPtnrInfo.setImtrsfChnlDcd(imtrsfChnlDcd);			// 즉시이체채널구분코드
			fininPtnrInfo.setFininCd(fininCd);			// 금융기관코드
			
			if ("A1".equals(rltmBzDcd)) {
				fininPtnrInfo.setOpnRegYn("N");
			}
		    if ("A3".equals(rltmBzDcd)){
				fininPtnrInfo.setTestTgmRegYn("N");
			}
			
			fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			iResult2 = 0;
			iResult2 = cmb001dbio.updateOneTBCMRTM0060(fininPtnrInfo);
			if(iResult2 != 1){
				// SQL오류, '금융기관제휴업무목록입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록입력"});
			}

			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE END  ********************************/
			
			/******************************** 대외계 전문 호출 ********************************/
			logger.debug("========== request ========== {}" + request);
			
			// FEP call
//			if ("A1".equals(rltmBzDcd)) {
//				response = InfUtil.callFEP(request, interfaceIdA1, COM_F_KSNOSKSPO00009In.class);
//			}
//			else if ("A3".equals(rltmBzDcd)){
//				response = InfUtil.callFEP(request, interfaceIdA3, COM_F_KSNOSKSPO00009In.class);
//			}
			
			response = InfUtil.callFEP(request, interfaceIdA1, COM_F_KSNOSKSPO00009In.class);
			
			responseData = response.getResponseData();
			
			logger.debug("========== responseData ========== {}" + responseData);
			
			//입금은행코드
			fininPtnrInfo.setImtrsfChnlDcd(imtrsfChnlDcd2);			// 입금
			fininPtnrInfo.setFininCd(responseData.getBnkCd3());			// 금융기관코드
			
			if ("100".equals(responseData.getBzDvsnCd())) {
				fininPtnrInfo.setOpnRegYn("Y");
			}
			if ("800".equals(responseData.getBzDvsnCd())) {
				fininPtnrInfo.setTestTgmRegYn("Y");
			}
			
			fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			iResult2 = 0;
			iResult2 = cmb001dbio.updateOneTBCMRTM0060(fininPtnrInfo);
			
			if(iResult2 != 1){
				throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록변경"});
			}

	
		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
		}
		

	}
	
	/**
	 * KIBNET  A1: 업무개시, A2: 재개시, A3: 태스트CALL, A4:장애, A5:장애회복, A6:업무종료
	 * @input  테스트전문유형
	 * @input  테스트은행
	 * @output 전문로그
	 * @return PAX010SVC00Out  전문로그 
	 * @throws ApplicationException
	 */
	public void  trsfKIBnetBzStartA1Sync (String fininCd, String rltmBzDcd) throws ApplicationException {
		
		String interfaceIdA1 =  "COM_F_KIBOSKIBO00012"; // 개시전문 EAI Interface ID
		
		String tgmNo 		 =  "";						// 전문번호
		
		String tgmCtgyCd     =  "0800";
		
		String bzDvsnCdA1    =  "2100";
		//String bzDvsnCdA3    =  "800";
		
		String imtrsfChnlDcd1		= "0001";		//출금
		String imtrsfChnlDcd2		= "0002";		//입금
		
		String tgmCont       =  "";
		int iResult2 		 =  0;						// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String tgmLogTxNo    = "";
		
		try {
			
			COM_F_KIBOSKIBO00012In  request   = new COM_F_KIBOSKIBO00012In();
			
			EISResponse < COM_F_KIBOSKIBO00012In > response = null;
			
			COM_F_KIBOSKIBO00012In responseData = null;
			
			TBCMRTM004Io realTgmLog 	= new TBCMRTM004Io();		// 리얼타임전문로그(TBCMRTM004)
			TBCMRTM024Io fininPtnrInfo 	= new TBCMRTM024Io();		// 금융기관제휴업무목록 업데이트
			SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;

//			Date toDay = new Date();
//			
//			SimpleDateFormat currentDate = null;
//			currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
			
			String today	= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
//			String todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
			String todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
	
			// 전문번호 생성
			tgmNo = cmb001bean.setTgmNoCrt(fininCd, today);
			if(!StringUtils.hasText(tgmNo)){
				// 전문번호 생성 오류 : '전문번호가 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0057", new Object[]{"전문번호"});
			}
	
//			if ("A1".equals(rltmBzDcd)) {
				//cmb003bean.setImtrSfchCommonHeaderNew(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA1, "", fininCd,  "A1");
				//cmb003bean.setImtrSfchCommonHeaderNew(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA1, "", "A1", fininCd, "");
				
			// 전문송신 KIB-NET 헤더정보 세팅
			//(A1) 압무개시  KIB-NET
			request.setLen(RTCont.TGM_LEN);							// set [전문길이]
			request.setCustNo(RTCont.CUST_NO);						// set [CS번호]
			request.setCustMgntInstCd(RTCont.CUST_INST_CD);			// set [CS기간코드]
			request.setRerunCd(RTCont.RERUN_CD);						// set [REACTION CODE]
			request.setCtnuTxNo(RTCont.CTNU_TX_NO);					// set [연속거래번호]
			request.setTrrvYn(RTCont.SNDM_CD);						// set [송수신FLAG]			
			request.setHndlInstCd(RTCont.HNDL_INST_CD);				// set [취급기관코드]
			request.setHndlSalesOffcCd(RTCont.HNDL_SALES_CD);		// set [취급영업점코드]
			request.setMedDvsn(RTCont.MED_DVSN);						// set [매체구분)			
			request.setTgmDvsnCd(tgmCtgyCd);							// set [전문구분코드]
			request.setTxDcd(bzDvsnCdA1);								// set [거래구분코드]
			request.setAnswCd(StringUtils.lpad("", 3, " "));			// set [응답코드]
			request.setTxDt(today);									// set [겨래일자]
			request.setTxHms(todayHms);								// set [겨래시간]			
			request.setTxSrno(tgmNo);					// set [겨래일련번호]
			request.setKorCdDvsn(RTCont.KOR_CD_DVSN);				// set [한금코드구분]
			request.setAfclsDvsn("0");								// set [마감후구분]
			request.setOpenInstCd(RTCont.OPEN_INST_CD + fininCd.substring(1));	// set [개설기관코드]
			request.setTrcNo("0");									// set [TRACK번호]
			request.setUsrWrkTery(StringUtils.lpad("", 158, " "));	// set [사용자영역]
			request.setAnswMsg(StringUtils.lpad("", 40, " "));		// set [응답메시지]
			request.setOrgtrFactr(RTCont.ORG_TR_FACTR);				// set [원거래요소]
			request.setBnkAnswCd(StringUtils.lpad("", 4, " "));		// set [은행응답코드]			
			request.setPprn(StringUtils.lpad("", 10, " "));			// set [예비]
//			}
//			else if ("A3".equals(rltmBzDcd)){
//				cmb003bean.setImtrSfchCommonHeader(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA3, imtrsfChnlDcd, "A3");
//			}
			request.setBaseDt(today);										// set :기준일자
			request.setClsBfAfDvsn(" ");									// set :마감이전이후구분
			request.setHldyDcd(" ");										// set :휴일구분코드
			request.setBzKnd(" ");											// set :업무종류
			request.setObsDvsn(" ");										// set :장애구분
			request.setHostOpnSta(StringUtils.lpad("", 10, " "));			// set :HOST개시상태 
			request.setObsBnkSta(StringUtils.lpad("", 100, " "));			// set :장애은행상태
			request.setEfmsSafCnt(StringUtils.lpad("", 5, " "));			// set :EFMS SAF건수
			request.setHostNdInstSafCnt(StringUtils.lpad("", 5, " "));		// set :HOST 및 기관SAF건수
			request.setPprn2(StringUtils.lpad("", 168, " "));
			
			tgmCont = new String(FwUtil.toBytes(request));
	
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(fininCd);	// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);								// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);								// set [전문내용]
			realTgmLog.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE START ********************************/
			
			fininPtnrInfo.setMoActFininCd(fininCd);			// 금융기관코드
			
			if ("A1".equals(rltmBzDcd)) {
				fininPtnrInfo.setOpnRegYn("N");
			}
			
			fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			iResult2 = 0;
			iResult2 = cmb001dbio.updateOneTBCMRTM0240(fininPtnrInfo);
			if(iResult2 == 0){
				// SQL오류, '금융기관제휴업무목록입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록입력"});
			}

			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE END  ********************************/
			
			/******************************** 대외계 전문 호출 ********************************/
			// FEP call
			String mode = LApplicationContext.getSystemMode();
			if ("A1".equals(rltmBzDcd)) {
				 //운영계
				logger.debug("========== request ========== {}" + request);
				
//				if("R".equals(mode) || "D".equals(mode) ) {  
//					response = InfUtil.callFEP(request, interfaceIdA1, COM_F_KIBOSKIBO00012In.class);
//					//InfUtil.callAsyncFEP(request, interfaceIdA1);
//					responseData = response.getResponseData(); 
//				}
				
				response = InfUtil.callFEP(request, interfaceIdA1, COM_F_KIBOSKIBO00012In.class);
				//InfUtil.callAsyncFEP(request, interfaceIdA1);
				responseData = response.getResponseData();
				
			}

			logger.debug("========== responseData ========== {}" + responseData);
			
			logger.debug("========== getOpenInstCd ========== {}" + "0" + responseData.getOpenInstCd().substring(6));
			
			//입금은행코드
			if("R".equals(mode) ) {  
				fininPtnrInfo.setMoActFininCd("0" + responseData.getOpenInstCd().substring(6));			// 금융기관코드
			} else {	
				fininPtnrInfo.setMoActFininCd(fininCd);			// 금융기관코드
			}
			
//			if ("100".equals(input.getBzDvsnCd())) {
//				fininPtnrInfo.setOpnRegYn("Y");
//			}
//			if ("800".equals(input.getBzDvsnCd())) {
//				fininPtnrInfo.setTestTgmRegYn("Y");
//			}
			
			fininPtnrInfo.setOpnRegYn("Y");			
			fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			iResult2 = 0;
			iResult2 = cmb001dbio.updateOneTBCMRTM0240(fininPtnrInfo);
			
			if(iResult2 == 0){
				throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록변경"});
			}
	
		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
		}
		

	}
	
	/**
	 * KSNET  A1: 업무개시, A3: 태스트CALL
	 * @input  테스트전문유형
	 * @input  테스트은행
	 * @output 전문로그
	 * @return PAX010SVC00Out  전문로그 
	 * @throws ApplicationException
	 */
	public void  trsfKsnetBzStartA1 (String fininCd, String rltmBzDcd, String imtrsfChnlDcd) throws ApplicationException {
		
		String interfaceIdA1 =  "COM_F_KSNOAKSPO00001"; // 개시전문 EAI Interface ID
		String interfaceIdA3 =  "COM_F_KSNOAKSPO00001"; // 테스트콜 EAI Interface ID
		
		String tgmNo 		 =  "";						// 전문번호
		
		String tgmCtgyCd     =  "0800";
		
		String bzDvsnCdA1    =  "100";
		String bzDvsnCdA3    =  "800";
		
		String tgmCont       =  "";
		int iResult2 		 =  0;						// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String tgmLogTxNo    = "";
		
		try {
			
			COM_F_KSNOAKSPO00001In  request   = new COM_F_KSNOAKSPO00001In();
			
			TBCMRTM004Io realTgmLog 	= new TBCMRTM004Io();		// 리얼타임전문로그(TBCMRTM004)
			TBCMRTM006Io fininPtnrInfo 	= new TBCMRTM006Io();		// 금융기관제휴업무목록 업데이트
			SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;

			String today	= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
	
			// 전문번호 생성
			tgmNo = cmb001bean.setTgmNoCrt(fininCd, today);
			if(!StringUtils.hasText(tgmNo)){
				// 전문번호 생성 오류 : '전문번호가 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0057", new Object[]{"전문번호"});
			}
	
			if ("A1".equals(rltmBzDcd)) {
				cmb002bean.setImtrSfchCommonHeader(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA1, imtrsfChnlDcd, "A1");
			}
			else if ("A3".equals(rltmBzDcd)){
				cmb002bean.setImtrSfchCommonHeader(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA3, imtrsfChnlDcd, "A3");
			}
			request.setPprn2(StringUtils.lpad("", 200, " "));
			
			tgmCont = new String(FwUtil.toBytes(request));
	
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			realTgmLog.setTrsfPrcsFininCd(fininCd);	// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);								// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);								// set [전문내용]
			realTgmLog.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE START ********************************/
			fininPtnrInfo.setImtrsfChnlDcd(imtrsfChnlDcd);			// 즉시이체채널구분코드
			fininPtnrInfo.setFininCd(fininCd);			// 금융기관코드
			
			if ("A1".equals(rltmBzDcd)) {
				fininPtnrInfo.setOpnRegYn("N");
			}
		    if ("A3".equals(rltmBzDcd)){
				fininPtnrInfo.setTestTgmRegYn("N");
			}
			
			fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			iResult2 = 0;
			iResult2 = cmb001dbio.updateOneTBCMRTM0060(fininPtnrInfo);
			if(iResult2 != 1){
				// SQL오류, '금융기관제휴업무목록입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록입력"});
			}

			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE END  ********************************/
			
			/******************************** 대외계 전문 호출 ********************************/
			// FEP call
			if ("A1".equals(rltmBzDcd)) {
				InfUtil.callAsyncFEP(request, interfaceIdA1);
			}
			else if ("A3".equals(rltmBzDcd)){
				InfUtil.callAsyncFEP(request, interfaceIdA3);
			}
	
		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
		}
		

	}
	
	/**
	 * KIBNET  A1: 업무개시, A2: 재개시, A3: 태스트CALL, A4:장애, A5:장애회복, A6:업무종료
	 * @input  테스트전문유형
	 * @input  테스트은행
	 * @output 전문로그
	 * @return PAX010SVC00Out  전문로그 
	 * @throws ApplicationException
	 */
	public void  trsfKIBnetBzStartA1 (String fininCd, String rltmBzDcd, String imtrsfChnlDcd) throws ApplicationException {
		
		String interfaceIdA1 =  "COM_F_KIBOAKIBO00001"; // 개시전문 EAI Interface ID
		
		String tgmNo 		 =  "";						// 전문번호
		
		String tgmCtgyCd     =  "0800";
		
		String bzDvsnCdA1    =  "2100";
		//String bzDvsnCdA3    =  "800";
		
		String tgmCont       =  "";
		int iResult2 		 =  0;						// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String tgmLogTxNo    = "";
		
		try {
			
			COM_F_KIBOAKIBO00001In  request   = new COM_F_KIBOAKIBO00001In();
			
			EISResponse < COM_F_KIBOAKIBO00001In > response = null;
			
			TBCMRTM004Io realTgmLog 	= new TBCMRTM004Io();		// 리얼타임전문로그(TBCMRTM004)
			TBCMRTM006Io fininPtnrInfo 	= new TBCMRTM006Io();		// 금융기관제휴업무목록 업데이트
			SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;

			String today	= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
	
			// 전문번호 생성
			tgmNo = cmb001bean.setTgmNoCrt(fininCd, today);
			if(!StringUtils.hasText(tgmNo)){
				// 전문번호 생성 오류 : '전문번호가 생성되지 않았습니다. 확인해주세요.'
				throw new ApplicationException("APPAE0057", new Object[]{"전문번호"});
			}
	
//			if ("A1".equals(rltmBzDcd)) {
//				cmb003bean.setImtrSfchCommonHeaderNew( obj, tgmNo, tgmCtgyCd, bzDvsnCd, chnlDcd, prcsCd, moActBnkCd, fininMgntCmpyCd)HeaderNew(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA1, imtrsfChnlDcd, "A1");
//			}
//			else if ("A3".equals(rltmBzDcd)){
//				cmb003bean.setImtrSfchCommonHeader(fininCd, request, tgmNo, tgmCtgyCd, bzDvsnCdA3, imtrsfChnlDcd, "A3");
//			}
			request.setBaseDt(today);										// set :기준일자
			request.setClsBfAfDvsn(" ");									// set :마감이전이후구분
			request.setHldyDcd(" ");										// set :휴일구분코드
			request.setBzKnd(" ");											// set :업무종류
			request.setObsDvsn(" ");										// set :장애구분
			request.setHostOpnSta(StringUtils.lpad("", 10, " "));			// set :HOST개시상태 
			request.setObsBnkSta(StringUtils.lpad("", 100, " "));			// set :장애은행상태
			request.setEfmsSafCnt(StringUtils.lpad("", 5, " "));			// set :EFMS SAF건수
			request.setHostNdInstSafCnt(StringUtils.lpad("", 5, " "));		// set :HOST 및 기관SAF건수
			request.setPprn2(StringUtils.lpad("", 168, " "));
			
			tgmCont = new String(FwUtil.toBytes(request));
	
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(fininCd);	// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(tgmNo);								// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);								// set [전문내용]
			realTgmLog.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			// FEP call 전에 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END ********************************/
			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE START ********************************/
			fininPtnrInfo.setImtrsfChnlDcd(imtrsfChnlDcd);			// 즉시이체채널구분코드
			fininPtnrInfo.setFininCd(fininCd);			// 금융기관코드
			
			if ("A1".equals(rltmBzDcd)) {
				fininPtnrInfo.setOpnRegYn("N");
			}
//		    if ("A3".equals(rltmBzDcd)){
//				fininPtnrInfo.setTestTgmRegYn("N");
//			}
			
			fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			iResult2 = 0;
			iResult2 = cmb001dbio.updateOneTBCMRTM0060(fininPtnrInfo);
			if(iResult2 != 1){
				// SQL오류, '금융기관제휴업무목록입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록입력"});
			}

			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE END  ********************************/
			
			/******************************** 대외계 전문 호출 ********************************/
			// FEP call
			String mode = LApplicationContext.getSystemMode();
			if ("A1".equals(rltmBzDcd)) {
				 //운영계
				if("R".equals(mode) || "D".equals(mode) ) {  
					//response = InfUtil.callFEP(request, interfaceIdA1, COM_F_KIBOSKIBO00012In.class);
					InfUtil.callAsyncFEP(request, interfaceIdA1);
				}
				
			}
//			else if ("A3".equals(rltmBzDcd)){
//				InfUtil.callAsyncFEP(request, interfaceIdA3);
//			}
	
		} catch (EisExecutionException e) {
			logger.error("EisExecutionException", e);
		} catch (NotSupportedEISException e) {
			logger.error("NotSupportedEISException", e);
		}
		

	}
	
	/**
	 * 개시전문과 테스트콜-(A1, A3)
	 * @param OAKSNTKSNP080010000000In OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public void setBzStartTgm (COM_F_KSNOAKSPO00001In input) throws ApplicationException {
		
		String tgmCont       		=  "";
		TBCMRTM006Io fininPtnrInfo 	= new TBCMRTM006Io();		// 금융기관제휴업무목록 업데이트
		TBCMRTM004Io realTgmLog 	= new TBCMRTM004Io();		// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;
		
		int iResult2 		 		=  0;						// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String imtrsfChnlDcd1		= "0001";		//출금
		String imtrsfChnlDcd2		= "0002";		//입금
		
		if ("100".equals(input.getBzDvsnCd()) || "800".equals(input.getBzDvsnCd())) {
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			tgmCont = new String(FwUtil.toBytes(input));
			
//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd(input.getBnkCd3());			// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(input.getTgmNo());					// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);								// set [전문내용]
			
			realTgmLog.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END  ********************************/

			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE START ********************************/
			//출금은행코드 업데이트
//			if ("002".equals(input.getBnkCd3()) 
//				|| BizCommUtil.getMoActBnkCd(BizCommUtil.PAY_MO_ACT).equals(input.getBnkCd3())		//[T1409260036] 주거래은행 변경
//				|| "023".equals(input.getBnkCd3())
//				|| "026".equals(input.getBnkCd3())
//				|| "088".equals(input.getBnkCd3())) {
//				
//				
//				fininPtnrInfo.setImtrsfChnlDcd(imtrsfChnlDcd1);			// 출금
//				fininPtnrInfo.setFininCd(input.getBnkCd3());			// 금융기관코드
//				
//				if ("100".equals(input.getBzDvsnCd())) {
//					fininPtnrInfo.setOpnRegYn("Y");
//				}
//				if ("800".equals(input.getBzDvsnCd())) {
//					fininPtnrInfo.setTestTgmRegYn("Y");
//				}
//				
//				fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
//				fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
//				fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
//				
//				iResult2 = 0;
//				iResult2 = cmb001dbio.updateOneTBCMRTM0060(fininPtnrInfo);
//				
//				if(iResult2 != 1){
//					throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록변경"});
//				}
//			}

			//입금은행코드
			fininPtnrInfo.setImtrsfChnlDcd(imtrsfChnlDcd2);			// 입금
			fininPtnrInfo.setFininCd(input.getBnkCd3());			// 금융기관코드
			
			if ("100".equals(input.getBzDvsnCd())) {
				fininPtnrInfo.setOpnRegYn("Y");
			}
			if ("800".equals(input.getBzDvsnCd())) {
				fininPtnrInfo.setTestTgmRegYn("Y");
			}
			
			fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			iResult2 = 0;
			iResult2 = cmb001dbio.updateOneTBCMRTM0060(fininPtnrInfo);
			
			if(iResult2 != 1){
				throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록변경"});
			}

			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE END  ********************************/
		}
	}
	
	/**
	 * 개시전문
	 * @param COM_F_KIBOAKIBO00001In OMM
	 * @return null
	 * @throws ApplicationException
	 */
	public void setKibnetBzStartTgm (COM_F_KIBOAKIBO00001In input) throws ApplicationException {
		
		String tgmCont       		=  "";
		TBCMRTM006Io fininPtnrInfo 	= new TBCMRTM006Io();		// 금융기관제휴업무목록 업데이트
		TBCMRTM004Io realTgmLog 	= new TBCMRTM004Io();		// 리얼타임전문로그(TBCMRTM004)
		SelectOneTBCMRTM0041Out  tgmLogPrcsDtm = null;
		
		int iResult2 		 		=  0;						// 리얼타임전문로그(TBCMRTM004) INSERT 수행결과값
		String imtrsfChnlDcd1		= "0001";		//출금
		String imtrsfChnlDcd2		= "0002";		//입금
		
		if ("2100".equals(input.getTxDcd()) ) {
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT START ********************************/
			tgmCont = new String(FwUtil.toBytes(input));
			
//			tgmLogPrcsDtm = cmb001dbio.selectOneTBCMRTM0041();		//시간20자리 조회
//
//			realTgmLog.setTgmLogPrcsDtm(tgmLogPrcsDtm.getTgmLogPrcsDtm());		// set [전문로그처리일시]
			String tgmLogTxNo = "";
			
			tgmLogTxNo = this.cmb001dbio.selectOneTBCMRTM0042();		//시퀀스조회

			realTgmLog.setTgmLogTxNo(tgmLogTxNo);		// set [전문로그처리일시]
			
			realTgmLog.setTrsfPrcsFininCd("0" + input.getOpenInstCd().substring(8));			// set [이체처리금융기관코드] : 처리은행코드 세팅함 - 금융기관코드(3)
			realTgmLog.setRltmTgmNo(input.getTxSrno());					// set [리얼타임전문번호]
			realTgmLog.setTgmCtnt(tgmCont);								// set [전문내용]
			
			realTgmLog.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			realTgmLog.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			realTgmLog.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			// 리얼타임전문로그(TBCMRTM004) INSERT
			iResult2 = cmb001bean.insertTgmLog(realTgmLog);
			
			if(iResult2 != 1){
				// SQL오류, '리얼타임전문로그입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문로그입력"});
			}
			/******************************** 리얼타임전문로그(TBCMRTM004) INSERT END  ********************************/

			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE START ********************************/
			//출금은행코드 업데이트
			if ("020".equals("0" + input.getOpenInstCd().substring(8))) {
				
				
				fininPtnrInfo.setImtrsfChnlDcd(imtrsfChnlDcd1);			// 출금
				fininPtnrInfo.setFininCd("0" + input.getOpenInstCd().substring(8));			// 금융기관코드
				
//				if ("100".equals(input.getBzDvsnCd())) {
//					fininPtnrInfo.setOpnRegYn("Y");
//				}
//				if ("800".equals(input.getBzDvsnCd())) {
//					fininPtnrInfo.setTestTgmRegYn("Y");
//				}
				fininPtnrInfo.setOpnRegYn("Y");
				fininPtnrInfo.setTestTgmRegYn("Y");
				
				fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
				fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
				fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
				
				iResult2 = 0;
				iResult2 = cmb001dbio.updateOneTBCMRTM0060(fininPtnrInfo);
				
				if(iResult2 != 1){
					throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록변경"});
				}
			}

			//입금은행코드
			fininPtnrInfo.setImtrsfChnlDcd(imtrsfChnlDcd2);			// 입금
			fininPtnrInfo.setFininCd("0" + input.getOpenInstCd().substring(8));			// 금융기관코드
			
//			if ("100".equals(input.getBzDvsnCd())) {
//				fininPtnrInfo.setOpnRegYn("Y");
//			}
//			if ("800".equals(input.getBzDvsnCd())) {
//				fininPtnrInfo.setTestTgmRegYn("Y");
//			}
			
			fininPtnrInfo.setOpnRegYn("Y");
			fininPtnrInfo.setTestTgmRegYn("Y");
			fininPtnrInfo.setLastChgrId(FwUtil.getUserId());				// set [최종변경자ID]
			fininPtnrInfo.setLastChgPgmId(FwUtil.getPgmId());				// set [최종변경프로그램ID]
			fininPtnrInfo.setLastChgTrmNo(FwUtil.getTrmNo());				// set [최종변경단말번호]
			
			iResult2 = 0;
			iResult2 = cmb001dbio.updateOneTBCMRTM0060(fininPtnrInfo);
			
			if(iResult2 != 1){
				throw new ApplicationException("APPAE0009", new Object[]{"금융기관제휴업무목록변경"});
			}

			/******************************** 금융기관제휴업무목록(TBCMRTM006) UPDATE END  ********************************/
		}
	}
}

