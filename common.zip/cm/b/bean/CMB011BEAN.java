package cigna.cm.b.bean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA002BEAN;
import cigna.cm.a.bean.CMA004BEAN;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.dbio.CMB010DBIO;
import cigna.cm.b.domain.CardAprvReqInfo;
import cigna.cm.b.domain.CardAprvResInfo;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.io.COM_F_KSNOSKSRO00010In;
import cigna.cm.b.io.COM_F_KSNOSKSRO00010Out;
import cigna.cm.b.io.COM_F_KSNOSKSRO00011In;
import cigna.cm.b.io.COM_F_KSNOSKSRO00011Out;
import cigna.cm.b.io.SelectOneTBCMRTM015aOut;
import cigna.cm.b.io.TBCMRTM015Io;
import cigna.cm.b.io.TBCMRTM027Io;
import cigna.cm.b.io.TBCSFCR005Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;



/**
 * @file         cigna.cm.b.bean.CMB010BEAN.java
 * @filetype     java source file
 * @brief        신용카드승인(취소)처리 공통 bean
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                          성명                                                일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 2. 11.      신규 작성
 *
 */
@KlafBean
public class CMB011BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB010DBIO cmb010dbio;//신용카드
	
	@Autowired
	private CMA002BEAN cma002bean;		//
	
	@Autowired
	private CMB001DBIO cmb001dbio;		// 전문번호 체크
	
	@Autowired
	private CMA004BEAN cma004bean;		// 리얼타임이체거래번호 채번메소드 호출
	
	// 테스트 카드번호
    public static final String TEST_CARD_NO = "4518421108496824,5229719005263851,9445411582105821,9445411413312018,9445420860075812,9445421036066815,5388235098237277,"
                                            + "4101090007700504,9445421029313877,4579730600372826,3562974547262998,9410100011882324,9445421060300850,4579730612151815,"
                                            + "4579730616782807,3562974561053018,371002657946338,4119045902962377,377989618643521,6251395008693354"
                                            ;
	
	
	/**
     * <p> 신용카드승인 및 취소 처리</p>
     * @param CardAprvReqInfo   cardReqInfo 카드처리 DO
     * @return CardAprvResInfo  cardResInfo  처리결과 DO
     * @throws ApplicationException
     */
	public CardAprvResInfo setCardAprvPrcs(CardAprvReqInfo cardReqInfo) throws ApplicationException {



		if (cardReqInfo == null) {
			throw new ApplicationException("APNBE0058", null);
		}

		CardAprvResInfo cardResInfo      = null;
 
        //입금/고객에서 호출한 경우 (신계약은 호출전 정합성 체크)
		 if (!RTCont.BZ_GB_NB.equals(cardReqInfo.getBzDcd()) && !RTCont.BZ_GB_UW.equals(cardReqInfo.getBzDcd()) ) {

			 this.chkCardAprvPrcs(cardReqInfo);

		 }
		 
		 String mode = LApplicationContext.getSystemMode();	 
		 logger.debug("mode{}",mode);
		 logger.debug(" ========= cardNo ======   {}",cardReqInfo.getCardNo());
		 
		 //운영계
		 //2016.10.08
		 if("T".equals(mode) ) {
			  //개발
			  if ("1111111111111111".equals(cardReqInfo.getCardNo()) ||
			      "2222222222222222".equals(cardReqInfo.getCardNo()) ||
			      "3333333333333333".equals(cardReqInfo.getCardNo()) ||
			      "8888888888888888".equals(cardReqInfo.getCardNo()) ||
			      "9999999999999999".equals(cardReqInfo.getCardNo()) ||
			      RTCont.EXTR_NO.equals(cardReqInfo.getExTrYn())) {		
				  
				  if (RTCont.CARD_TX_DCD_CC.equals(cardReqInfo.getTxDcd())) { //취소
					  cardResInfo = this.callCnclDev(cardReqInfo);
				  }
				  else	//인증 및 승인
				  {
					  cardResInfo = this.callAprvDev(cardReqInfo);
				  }			  
			  //실제 KSNET 연동
			  } else {
				  
				  if (RTCont.CARD_TX_DCD_CC.equals(cardReqInfo.getTxDcd())) { //취소
					  cardResInfo= this.callCnclReal(cardReqInfo);
				  }
				  else	//인증 및 승인
				  {
					  cardResInfo= this.callAprvReal(cardReqInfo);
				  }
			  }			  		  
		 //개발,테스트
		 } else if( "R".equals(mode) || "D".equals(mode)) {
		   
			  //2016.01.25;현승훈;개발,테스트일 경우 callAprvDev 호출하도록 수정			  
			  if (RTCont.CARD_TX_DCD_CC.equals(cardReqInfo.getTxDcd())) { //취소
				//cardResInfo= this.callCnclReal(cardReqInfo);  //---> 애니링크 확인할 때
				  cardResInfo = this.callCnclDev(cardReqInfo);
			  }
			  else	//인증 및 승인
			  {
				  //cardResInfo= this.callAprvReal(cardReqInfo);  //---> 애니링크 확인할 때
				  cardResInfo = this.callAprvDev(cardReqInfo);
			  }
		  } 

	    return cardResInfo;

	}
	
	/**
	 * <p> 카드승인처리 입력값  확인</p>
	 * @param String  contNo 개인추가조사대상
	 * @param String  contDt 개인추가조사대상
	 * @param String  dealTpCd 개인추가조사대상
	 * @param String  ftmPrmPmMcd 첫회보험료납입방법코드
	 * @param String  sbackPayMcd 지급방법유형코드 (1:현금 2:대량이체 3:RT)
	 * @param String  contInputPathCd 계약입력경로코드(00: 00 e-Focus입력,01 KISS입력,02 ATIS입력 03 방카입력)
	 * @param inList  개인추가조사대상
	 * @throws ApplicationException
	 */
	private void chkCardAprvPrcs ( CardAprvReqInfo input ) throws ApplicationException {

		if(StringUtils.isEmpty(input.getTxDcd())) {

	        logger.debug("카드거래구분코드를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"카드거래구분코드"}, new Object[]{"카드거래구분코드"});

		}

		if(StringUtils.isEmpty(input.getCardNo())) {

	        logger.debug("카드번호를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"카드번호"}, new Object[]{"카드번호"});
		}
		
		// TODO.입금쪽은 단말기 구분코드가 필요하다.
//		if(NBZZ20BEAN.BZ_GB_DP.equals(input.getBzDcd()) && StringUtils.isEmpty(input.getTrmDcd())) {
//
//	        logger.debug("단말기구분코드를  입력하지 않았습니다");
//	        throw new ApplicationException("APPRE0000", new Object[]{"단말기구분코드"}, new Object[]{"단말기구분코드"});
//		}


		 if (RTCont.CARD_TX_DCD_IA.equals(input.getTxDcd())) { //인증 체크

				if(StringUtils.isEmpty(input.getCardOwnerCustDscNo())) {

			        logger.debug("주민번호  입력하지 않았습니다");
			        throw new ApplicationException("APPRE0000", new Object[]{"주민번호"}, new Object[]{"주민번호"});

				}

				if(StringUtils.isEmpty(input.getCardVldYm())) {

			        logger.debug("유호기간를  입력하지 않았습니다");
			        throw new ApplicationException("APPRE0000", new Object[]{"유호기간"}, new Object[]{"유호기간"});

				}

		 } else if (RTCont.CARD_TX_DCD_CC.equals(input.getTxDcd())) { //승인취소


				if ("".equals(input.getCardAprvNo()) || input.getCardAprvNo()==null) {

					logger.debug("기승인번호.");
			        throw new ApplicationException("APPRE0000", new Object[]{"기승인번호"}, new Object[]{"기승인번호"});
				}

				if ("".equals(input.getCardAprvDt()) || input.getCardAprvDt()==null) {

					logger.debug("기승인일자");
			        throw new ApplicationException("APPRE0000", new Object[]{"기승인일자"}, new Object[]{"기승인일자"});
				}

//				if (!trxDt.equals(input.getCardAprvDt())) {
//
//					logger.debug("당일건만 취소가 가능함.");
//			        throw new ApplicationException("APNBE0062", new Object[]{"당일건만 취소가 가능함"}, new Object[]{"당일건만 취소가 가능함"});
//				}


		 } else {


				if(StringUtils.isEmpty(input.getContNo())) {

			        logger.debug("계약번호를  입력하지 않았습니다");
			        throw new ApplicationException("APPRE0000", new Object[]{"계약번호"}, new Object[]{"계약번호"});
				}

				if(StringUtils.isEmpty(input.getMipMcnt().toString())) {

			        logger.debug("할부개월을  입력하지 않았습니다");
			        throw new ApplicationException("APPRE0000", new Object[]{"할부개월"}, new Object[]{"할부개월"});

				}

				if(StringUtils.isEmpty(input.getCardApplAmt())) {

			        logger.debug("사용금액을  입력하지 않았습니다");
			        throw new ApplicationException("APPRE0000", new Object[]{"사용금액"}, new Object[]{"사용금액"});

				}

				if(StringUtils.isEmpty(input.getCardOwnerCustDscNo())) {

			        logger.debug("카드소유 주민번호를  입력하지 않았습니다");
			        throw new ApplicationException("APPRE0000", new Object[]{"카드소유 주민번호"}, new Object[]{"카드소유 주민번호"});

				}

				if(StringUtils.isEmpty(input.getContrRrno())) {

			        logger.debug("계약자 주민번호를  입력하지 않았습니다");
			        throw new ApplicationException("APPRE0000", new Object[]{"계약자 주민번호"}, new Object[]{"계약자 주민번호"});

				}


				//계약자와　카드주 CHECK （동일해야함
				//2016.09.12;라이나 계약자와카드주 동일하지 않아도 처리 가능
//				if(!input.getContrRrno().equals(input.getCardOwnerCustDscNo())) {
//
//					logger.debug("카드주는 계약자와 동일해야합니다");
//			        throw new ApplicationException("APNBE0041", new Object[]{"카드주/계약자 정보불일치"}, new Object[]{"카드주/계약자 정보불일치"});
//
//				}

				if(StringUtils.isEmpty(input.getCardVldYm())) {

			        logger.debug("유효기간를  입력하지 않았습니다");
			        throw new ApplicationException("APPRE0000", new Object[]{"유효기간"}, new Object[]{"유효기간"});

				}

				//할부개월은 00만 가능- 입금은 할부가능
				if(!"00".equals(input.getMipMcnt()) &&
				   !"DP".equals(input.getBzDcd())     ) {
				
					logger.debug("할부개월은 00만 가능");
			        throw new ApplicationException("APNBE0073", new Object[]{"할부개월오류"}, new Object[]{"할부개월오류"});

				}

		 }

	}
	
	/**
     * <p> 개발/검증계용 처리process </p>
     * @param CardAprvReqInfo   cardReqInfo 카드처리 DO
     * @return CardAprvResInfo  cardResInfo  처리결과 DO
     * @throws ApplicationException
     */
	private CardAprvResInfo callAprvDev(CardAprvReqInfo cardReqInfo) throws ApplicationException {
		logger.debug("로그 : 개발/검증계용(callAprvDev) 시작");

		COM_F_KSNOSKSRO00010In request             = null;
		COM_F_KSNOSKSRO00010Out responseData = null;
		CardAprvResInfo cardResInfo      = null;
		
		try {
			
			//전문관련 로그는 대외계에서 테이블로 관리함
			String tgmNo           = cmb010dbio.selectOneTBCNBAS015a().substring(2);                    //전문번호
			String prcsEno = "";
			String orgKnd = "";
			String trmNo = "";
			
			String crdcdMgntNo = "";
			String propoDeptOrgNo = "";
			String cardCopCd = "";
			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			 
			//고객 카드 인증처리시를 제외하고는 카드관리번호 필수입력
			if (!RTCont.BZ_GB_CS.equals(cardReqInfo.getBzDcd()) ) {
				
				
				//crdcdMgntNo = cmb010dbio.selectOneTBCSFCR005a(SecuUtil.getEncValue(cardReqInfo.getCardNo(), SecuUtil.EncType.Card)); //카드관리번호
				TBCSFCR005Io tbcsfcr005io = cmb010dbio.selectOneTBCSFCR0051(SecuUtil.getEncValue(cardReqInfo.getCardNo(), SecuUtil.EncType.Card));
				SecuUtil.doDecObject(tbcsfcr005io);
				
				if(tbcsfcr005io != null){
					crdcdMgntNo = tbcsfcr005io.getCrdcdMgntNo(); 	// 카드관리번호
					cardCopCd = tbcsfcr005io.getCardCopCd();		// 카드회사번호
					/**********************************************************
					 * 즉시카드 가능 카드사 체크
					 *********************************************************/
					
					 if ( ! RTCont.IMMDT_CRDCOCD.contains(cardCopCd) )
					 {
						  //즉시카드신청 가능한 카드사가 아닙니다.
						  throw new ApplicationException("APDPE0025", null);
					 }
				}else{
					crdcdMgntNo = cardReqInfo.getCrdcdMgntNo();
				}
				
				if ( StringUtils.isEmpty(crdcdMgntNo) )
				{
					  //즉시카드신청 가능한 카드사가 아닙니다.
					throw new ApplicationException("APSLE0402", null);
				}
			}
			 
			logger.debug("crdcdMgntNo {}",crdcdMgntNo);
			 
			//prcsEno = FwUtil.getUserId();					// set [이체처리사원번호]
			if(StringUtils.isEmpty(cardReqInfo.getPyrcPrcsEno())) {
				prcsEno = FwUtil.getUserId();					// set [이체처리사원번호]
			}else{
				prcsEno = cardReqInfo.getPyrcPrcsEno();					// set [이체처리사원번호]
			}
				
			
			CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(prcsEno);
			
			//orgKnd = cmb001dbio.selectOneTBSLORG001a(commEmplInfo.getPropoDeptOrgNo());	//조직종류코드조회
			orgKnd = commEmplInfo.getOrgKcd();
			
			if (StringUtils.isEmpty(orgKnd)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직종류코드(M)" });
			}
			
			// 조직종류 TM -- 100093
			// 조직종류 GA -- 100980
			// 조직종류 스텝부서 -- 발의부서
			if (RTCont.ORG_KND_TM.equals(orgKnd)) {
				propoDeptOrgNo = RTCont.ORG_NO_TM;
			} 
//			else if (RTCont.ORG_KND_GA.equals(orgKnd)) {
//				propoDeptOrgNo = RTCont.ORG_NO_GA;
//			} 
			else {
				//2017.01.26;현승훈;김유나과장요청-발의부서가 소비자보험팀일 경우 통합모니터링팀으로 변경
				if ("DP".equals(cardReqInfo.getBzDcd()) && RTCont.ORG_NO_CNSU_SFGD_TEAM.equals(commEmplInfo.getPropoDeptOrgNo())) {
					propoDeptOrgNo = RTCont.ORG_NO_INTGR_MNT_TEAM;
				} else {
					propoDeptOrgNo = commEmplInfo.getPropoDeptOrgNo();
				}
			}
			
			trmNo =  this.cmb001dbio.selectOneTBCMRTM0243(propoDeptOrgNo,"03");
			
			if ( StringUtils.isEmpty(trmNo) && !RTCont.BZ_GB_CS.equals(cardReqInfo.getBzDcd()) )
			{
				  //해당 발의부서의 거래 모계좌 등록 필수! 빌링 담당자에게 확인하여 주시기 바랍니다.
			     throw new ApplicationException("APPAE0051", null);
			} else {
				//2017.01.26;현승훈;카드인증일 경우 발의부서를 통합모니터링팀으로 조회한다. 
				trmNo =  this.cmb001dbio.selectOneTBCMRTM0243(RTCont.ORG_NO_INTGR_MNT_TEAM,"03");
				if ( StringUtils.isEmpty(trmNo)) {
					 //해당 발의부서의 거래 모계좌 등록 필수! 빌링 담당자에게 확인하여 주시기 바랍니다.
				     throw new ApplicationException("APPAE0051", null);
				}
			}
			
			String cardTrsfTxNo = cma004bean.getNewPayMknoNo("CMRC", today.substring(0, 8), 20);
			
			cardReqInfo.setTrmDcd("01");
			
			//0.전문번호생성 및 카드관리번호 셋팅
			cardReqInfo.setTgmNo(tgmNo);                // 전문번호생성
			cardReqInfo.setCrdcdMgntNo(crdcdMgntNo);	// 카드관리번호
			cardReqInfo.setTrmNo(trmNo);				// 단말번호
			cardReqInfo.setCardTrsfTxNo(cardTrsfTxNo);	// 카드이체거래번호
			
			//1.카드 송신 데이타 변환
			request = this.getCardAprvReqInfo(cardReqInfo);
			logger.debug("request {}",request);
			logger.debug("length of request:{}",request.toString().length());
			
			//2.송신전 전문로그 저장
			SecuUtil.doEncObject(cardReqInfo);
			cmb010dbio.insertOneTBCMRTM027a(this.getTbcmrtm027Io(cardReqInfo,commEmplInfo.getOrgNo() ,propoDeptOrgNo));
				
			//3.테스트를 위해 van사 호출하지 않음
			responseData = new COM_F_KSNOSKSRO00010Out();
			responseData.setTgmNo(request.getTgmNo());//송신때 채번한 전문번호 수신때 강제셋팅작업
			
			//4.카드 수신 데이타 변환
			cardResInfo = this.getCardAprvRes(responseData,cardReqInfo.getCardNo(),RTCont.TEST_MODE);
			
			cardResInfo.setTgmNo(tgmNo);
			cardResInfo.setCrdcdMgntNo(crdcdMgntNo);
			
			
			 logger.debug("cardResInfo {}",cardResInfo);
			
			//5.송신후 전문로그 저장
			 cmb010dbio.updateOneTBCMRTM027a(this.getTbcmrtm027Io(cardResInfo));
			 
			
		} catch (ApplicationException ae) {
			
			throw ae;
		}
		
		return cardResInfo;

		 
	}
	
	/**
	 * <p> 카드송신 DO  변환</p>
	 * @param CardAprvReqInfo input   카드승인요청 DO
	 * @return NBZB40SVC00In  : 처리결과 OMM(any link 결과값)
	 * @throws ApplicationException
	 */
	private COM_F_KSNOSKSRO00010In getCardAprvReqInfo(CardAprvReqInfo input)  throws ApplicationException  {


		COM_F_KSNOSKSRO00010In request = new COM_F_KSNOSKSRO00010In();

		//공통부 셋팅
		//request.setTrlen(cmbz00bean.fillSpace(RTCont.REQUEST_SIZE_A , 4)); 						// 전문전체길이
		//request.setMsgCd(NBZZ20BEAN.MSG_CD);                                                  		//  전문코드
		//request.setBzDvsn(NBZZ20BEAN.BZ_DVSN);                                                  	// 거래구분코드
		//request.setTrnsDt(DateUtils.getCurrentDate(2));                                           	// 처리년월일 20121110
		//request.setTrnsHms(DateUtils.getCurrentTime(6));                                        	// 처리시간  131025
		//request.setPprn(NBZZ20BEAN.fillSpace("",12));
		
		//데이터부 셋팅
		//request.setLenVl(NBZZ20BEAN.fillSpace(NBZZ20BEAN.REQUEST_SIZE_A , 4));                   	// 0.전체길이
		request.setStrtSb(new String(new byte[]{(byte)0x02}));                                   	// 1.STX
        request.setTxDvsn(CMBZ00BEAN.fillSpace(input.getTxDcd(), 2));                                 // 2.거래구분코드
        
        /* 단말기번호는 업무별로 셋팅해준다. 
         * 입금 : 호출시 셋팅할 단말기구분코드를 넘겨준다. trmDcd
         * 그외 : 신계약/고객 등은 단일 셋팅  
         */
//        if (RTCont.BZ_GB_DP.equals(input.getBzDcd())) { // 입금
//
//        	if(StringUtils.isEmpty(input.getTrmDcd())){	
//        		request.setTrmNo(RTCont.TRM_NO);												// 3.단말기번호
//        	}else{
//        		// 입금파트에서 호출시 단말기번호 셋팅
//        		if("02".equals(input.getTrmDcd())){
//            		request.setTrmNo(RTCont.TRM_NO2);												
//            	}else if("03".equals(input.getTrmDcd())){
//            		request.setTrmNo(RTCont.TRM_NO3);												
//            	}else if("04".equals(input.getTrmDcd())){
//            		request.setTrmNo(RTCont.TRM_NO4);												
//            	}else if("05".equals(input.getTrmDcd())){
//            		request.setTrmNo(RTCont.TRM_NO5);											// 2013.12.30 롯데아멕스카드 다이렉트 본부인 경우
//            	}
//        	}
//        }else{ // 그외(신계약,고객)
//        	if(StringUtils.isEmpty(input.getTrmDcd())){	
//        		request.setTrmNo(RTCont.TRM_NO);												// 3.단말기번호
//        	}else{
//        		if("01".equals(input.getTrmDcd())){
//        			request.setTrmNo(RTCont.TRM_NO1);											// 2013.12.30 롯데아멕스카드 다이렉트 본부인 경우
//        		}else{
//        			request.setTrmNo(RTCont.TRM_NO);											// 3.단말기번호
//        		}
//        	}
//        	
//        }
        
        //request.setTrmNo(RTCont.TRM_NO);											// 3.단말기번호
        
        request.setTrmNo(input.getTrmNo());											// 3.단말기번호
        request.setCmpyInfo(RTCont.CMPY_NM);                                                  	// 4.업체번호
        request.setTgmNo(input.getTgmNo());                                                         // 5.전문번호 
        request.setEntDvsn(RTCont.POS_ENTRY_MD);                                             // 6.pos entry mode Key-in 방식
        
        String track = SecuUtil.getDecValue(input.getCardNo(), EncType.cardNo)+RTCont.TRACK_DC+input.getCardVldYm().substring(2)+input.getCardVldYm().substring(0,2);
        request.setTrc(CMBZ00BEAN.fillSpace(track,37));                                           // 7.track
        request.setFileSep(new String(new byte[]{(byte)0x1C}));                                 	// 8.FS
        request.setMipMcnt(StringUtils.nvl(input.getMipMcnt(),"00"));                              	// 9.할부개월수

        if (RTCont.CARD_TX_DCD_IA.equals(input.getTxDcd())) { //인증
        	
        	request.setTtlAmt(CMBZ00BEAN.fillZero(RTCont.ADMIT_DEFAULT_AMT,9));    				//10. 총금액:인증금액(실제처리금액이 아님)
        	
        } else {
        	
        	request.setTtlAmt(CMBZ00BEAN.fillZero(input.getCardApplAmt(),9));   					//10.총금액	
        }
        
        request.setSvcFee(CMBZ00BEAN.fillZero(RTCont.ZERO,9));            						//11.봉사료
        request.setPwdDvsn(RTCont.WK_KEY);   //12. Working key index
        request.setPswd(RTCont.PWD);            //13.비밀번호 미사용시 0000000000000000
        request.setPrdcd(CMBZ00BEAN.fillSpace("",6)); //14.상품코드 : 미사용시 space
        

//        if (RTCont.CARD_TX_DCD_CC.equals(input.getTxDcd())) { //승인취소
//
//            request.setOrgAprvNo(CMBZ00BEAN.fillSpace(input.getCardAprvNo(),12));                        //16.원거래승인번호
//            request.setOrgAprvDt(CMBZ00BEAN.fillSpace(input.getCardAprvDt().substring(2),6));        //17.원거래승인일자
//
//        } else {
//
//            request.setOrgAprvNo(CMBZ00BEAN.fillSpace("",12));  //16.원거래승인번호
//            request.setOrgAprvDt(CMBZ00BEAN.fillSpace("",6));     //17.원거래승인일자
//        }


        if (RTCont.CARD_TX_DCD_IA.equals(input.getTxDcd())) { //인증
        	//14.07.31 주민번호 앞자리로 변경 
        	String cardOwnerCustDscNo = SecuUtil.getDecValue(input.getCardOwnerCustDscNo(), EncType.custDscNo);
        	if(cardOwnerCustDscNo.length() == 13){
        		request.setUsrInfo(CMBZ00BEAN.fillSpace(cardOwnerCustDscNo.substring(0,6),13)); //15.사용자번호(고객주민번호앞자리)
        	}else{
        		request.setUsrInfo(CMBZ00BEAN.fillSpace(cardOwnerCustDscNo,13)); //15.사용자번호(사업자번호)
        	}
        	
        } else {

        	request.setUsrInfo(CMBZ00BEAN.fillSpace("",13));  //15.사용자번호
        }
        
        logger.debug("테스트 [{}]", request.getUsrInfo());
        
//        
//        request.setCardAffstId(CMBZ00BEAN.fillSpace("",2));            //19.가맹점ID
//        request.setCardAffstUseFd(CMBZ00BEAN.fillSpace("",30));   //20.가맹점 사용필드
//        request.setRsvr(CMBZ00BEAN.fillSpace("",4));                       //21.예약필드
//        request.setKsNetRsvr(CMBZ00BEAN.fillSpace("",20));            //22.KSNET Reserved
//        request.setPrcsDcd(CMBZ00BEAN.NO_USE);                          //23.동글 구분
//        request.setMedDcd(CMBZ00BEAN.fillSpace("",1));                //24.매체 구분
//        request.setCmDcd(CMBZ00BEAN.fillSpace("",1));                 //25.이통사구분
//        request.setCrdcdDcd(NBZZ20BEAN.fillSpace("",1));             //26.신용카드종류
//        request.setTxType(NBZZ20BEAN.NO_USE);                          //27.거래형태
//        request.seteCertYn(NBZZ20BEAN.NO_USE);                        //28.전자서명유무
        
        request.setElecTxSecuGd(CMBZ00BEAN.fillSpace("",1)); 			//16.전자상거래보안등급
        request.setDmn(CMBZ00BEAN.fillSpace("",40));					//17.도메인
        request.setCmpyIp(CMBZ00BEAN.fillSpace("",20));					//18.업체-IP
        request.setEmailBzno(CMBZ00BEAN.fillSpace("",10));				//19.이메일사업자등록번호
        request.setRsvtField(CMBZ00BEAN.fillSpace("",14));				//20.예약필드
        request.setFlg1(new String(new byte[]{(byte)0x03}));           //21.ETX
        request.setFlg2(new String(new byte[]{(byte)0x0D}));           //22.CR

		return request;
	}
	
	/**
	 * <p> 카드승인전 전문로그, DO  변환</p>
	 * @param CardAprvReqInfo input  입력데이터
	 * @return TBCMRTM015Io Tbcmrtm015  : 처리결과
	 * @throws ApplicationException
	 */
	private TBCMRTM027Io getTbcmrtm027Io (CardAprvReqInfo input , String trsfFofOrgNo, String propoDeptOrgNo )  throws ApplicationException  {

		TBCMRTM027Io Tbcmrtm027 = new TBCMRTM027Io();
		
		
		Tbcmrtm027.setCrdcdTrsfTxNo(input.getCardTrsfTxNo());                //카드번호(PK)
		Tbcmrtm027.setCardTgmNo(input.getTgmNo());	            //카드전문번호(PK)
		Tbcmrtm027.setCrdcdMgntNo(input.getCrdcdMgntNo());      //카드관리번호
		//Tbcmrtm015.setCrdcdMgntNo("111");      //카드관리번호
		Tbcmrtm027.setCardTxDt(DateUtils.getCurrentDate(2));	//카드거래일자
		Tbcmrtm027.setContNo(input.getContNo());                //계약번호				
		Tbcmrtm027.setBzCd(input.getBzDcd()); 	                //업무구분
		Tbcmrtm027.setCardTxDcd(input.getTxDcd());              //카드거래구분코드						
		Tbcmrtm027.setMipMcnt(Integer.parseInt(input.getMipMcnt())); //할부개월수 
		
		if (RTCont.CARD_TX_DCD_IA.equals(input.getTxDcd())) { //인증
			Tbcmrtm027.setContNo("@");                          //계약번호		
			Tbcmrtm027.setSprm(RTCont.ADMIT_DEFAULT_AMT); 	//인증금액(실제처리금액이 아님)		
			
		} else {
			Tbcmrtm027.setContNo(input.getContNo());            //계약번호		
			Tbcmrtm027.setSprm(input.getCardApplAmt()); 		//승인금액				
		}
			
		Tbcmrtm027.setMsgCtnt1("");	  					        //처리메시지1
		Tbcmrtm027.setMsgCtnt2("");	  					        //처리메시지2
		Tbcmrtm027.setCardAprvNo("00000000")	;            	//승인번호
		Tbcmrtm027.setCardTxRstYn("");						    //카드거래결과여부
		Tbcmrtm027.setCardAffstNo("0000000000000");				//가맹점번호
		Tbcmrtm027.setIssueCardCopCd("00");				     	//발급사코드
		Tbcmrtm027.setBuyCardCopCd("00");                    	//매입사코드
		Tbcmrtm027.setCardAprvRcd("9999");                    	//카드결과코드
		Tbcmrtm027.setPrpsNo(input.getPrpsNo());				//청약번호
		
		Tbcmrtm027.setFstCrtrId(FwUtil.getUserId());
		Tbcmrtm027.setLastChgPgmId(FwUtil.getPgmId());
		Tbcmrtm027.setLastChgrId(FwUtil.getUserId());
		Tbcmrtm027.setLastChgTrmNo(FwUtil.getTrmNo());
		Tbcmrtm027.setTrmNo(input.getTrmNo());				//단말번호
		Tbcmrtm027.setTrsfFofOrgNo(trsfFofOrgNo);
		Tbcmrtm027.setPropoDeptOrgNo(propoDeptOrgNo);
		
		SecuUtil.doEncOmm(Tbcmrtm027);


		logger.debug("=====>Tbcmrtm027<====== {}" + Tbcmrtm027);
		
		return Tbcmrtm027;
	}
	
	/**
	 * <p> 카드수신 DO  변환</p>
	 * @param COM_F_KSNOS000000010Out  output 입력데이터
	 * @param String  mode 개발/운영
	 * @return CardAprvResInfo   카드승인결과 DO
	 * @throws ApplicationException
	 */
	private CardAprvResInfo getCardAprvRes(COM_F_KSNOSKSRO00010Out output,String cardNo,String mode)   throws ApplicationException {

		CardAprvResInfo response = new CardAprvResInfo();
		
		logger.debug("=====>cardNo<====== {}" + cardNo);
		
		// 오늘일자 : YYYYMMDDHHMISS
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
//		String todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
		String todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

		String currentMin = todayHms.substring(2, 4);		
		String startMin = "00";
		String endMin = "31";
		
		logger.debug("=====>SecuUtil.getDecValue(cardNo, SecuUtil.EncType.Card).substring(0, 6)<====== {}" + SecuUtil.getDecValue(cardNo, SecuUtil.EncType.Card).substring(0, 6));
		
		String buyCardCopCd = cmb010dbio.selectOneTBCMETC013a(SecuUtil.getDecValue(cardNo, SecuUtil.EncType.Card).substring(0, 6));
		
		logger.debug("=====>buyCardCopCd 20170104<====== {}" + buyCardCopCd);

		if (RTCont.TEST_MODE.equals(mode)) {

			if("8888888888888888".equals(cardNo) ) {

				response.setProgStcd("X");                                                         //상태 (O:정상(승인/취소), X:거절)
				//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
				//response.setCardAprvDt(DateUtils.getCurrentDate(2));                //승인일자
				//response.setBuyCardCopCd("26");
				//response.setCardAffstNo("07565961");
				response.setTgmAnswCd("8314"); //응답코드 셋팅
				//response.setIssueCardCopCd("26");
				response.setTgmNo(output.getTgmNo());//전문번호
				
			} else if ("9999999999999999".equals(cardNo)) {
				
				
				response.setProgStcd("X");                                                         //상태 (O:정상(승인/취소), X:거절)
				//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
				//response.setCardAprvDt(DateUtils.getCurrentDate(2));                //승인일자
				//response.setBuyCardCopCd("26");
				//response.setCardAffstNo("07565961");
				response.setTgmAnswCd("8329"); //응답코드 셋팅
				//response.setIssueCardCopCd("26");
				response.setTgmNo(output.getTgmNo());//전문번호
				
			} else {
				
				
				response.setProgStcd("O");                                                         //상태 (O:정상(승인/취소), X:거절)
				//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
				logger.debug("=====>getCurrentTimestamp<====== {}" + getCurrentTimestamp());
				response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
				response.setCardAprvDt(DateUtils.getCurrentDate(2));                //승인일자
				if(StringUtils.isEmpty(buyCardCopCd)){
					response.setBuyCardCopCd("05");
				} else {
					response.setBuyCardCopCd(buyCardCopCd);
				}
				response.setCardAffstNo("07565961");
				response.setTgmAnswCd("0000"); //응답코드 셋팅
				response.setIssueCardCopCd("05");
				
				response.setTgmNo(output.getTgmNo());//전문번호
				
				logger.debug("=====>response.getBuyCardCopCd<====== {}" + response.getBuyCardCopCd());
			}
		      			

		} else {
			//2016.11.18;현승훈;김유나과장 다건 승인을 위해 해당 카드번호만 처리 가능토록
			if (Integer.parseInt(today) < Integer.parseInt("20170201")) {
				if (Integer.parseInt(today) < Integer.parseInt("20170101")) {
					if ("20161219".equals(today) || "20161220".equals(today)) {
						response.setProgStcd("O");
						response.setTgmAnswCd("0000"); //응답코드 셋팅
						response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
						response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
						//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
						
						logger.debug("=====>getCurrentTimestamp<====== {}" + getCurrentTimestamp());
						
						response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
						response.setIssueCardCopCd("05");
						if(StringUtils.isEmpty(buyCardCopCd)){
							response.setBuyCardCopCd("05");		 //매입사코드
						} else {
							response.setBuyCardCopCd(buyCardCopCd);
						}
						response.setTgmNo(output.getTgmNo());//전문번호			
					} else {
						if ( Integer.parseInt(currentMin) > Integer.parseInt(startMin) &&
								Integer.parseInt(currentMin) < Integer.parseInt(endMin) ) {
							response.setProgStcd(output.getSta());                               //상태 (O:정상(승인/취소), X:거절)
							response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
							response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
							
							if ("O".equals(output.getSta())) {
				
								response.setTgmAnswCd("0000"); //응답코드 셋팅
								response.setCardAprvNo(output.getAprvNo()); // 정상일때는 승인번호, 거절일때는 오류코드
				
							} else {
				
							    logger.debug("output.getCardAprvNo():{}",output.getAprvNo());
								response.setTgmAnswCd(output.getAprvNo());//오류일때는 응답코드
				
							}
							response.setIssueCardCopCd(output.getIssueCrdcoCd());							
							if(StringUtils.isEmpty(buyCardCopCd)){
								response.setBuyCardCopCd(output.getBuycoCd());		 //매입사코드
							} else {
								response.setBuyCardCopCd(buyCardCopCd);		 //매입사코드
							}
							response.setTgmNo(output.getTgmNo());//전문번호		
						} else {
							response.setProgStcd("O");
							response.setTgmAnswCd("0000"); //응답코드 셋팅
							response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
							response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
							//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
							
							logger.debug("=====>getCurrentTimestamp<====== {}" + getCurrentTimestamp());
							
							response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
							response.setIssueCardCopCd("05");
							if(StringUtils.isEmpty(buyCardCopCd)){
								response.setBuyCardCopCd("05");		 //매입사코드
							} else {
								response.setBuyCardCopCd(buyCardCopCd);
							}
							response.setTgmNo(output.getTgmNo());//전문번호			
						}
					}
					
				} else {
					response.setProgStcd("O");
					response.setTgmAnswCd("0000"); //응답코드 셋팅
					response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
					response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
					//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
					
					logger.debug("=====>getCurrentTimestamp<====== {}" + getCurrentTimestamp());
					
					response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
					response.setIssueCardCopCd("05");
					if(StringUtils.isEmpty(buyCardCopCd)){
						response.setBuyCardCopCd("05");		 //매입사코드
					} else {
						response.setBuyCardCopCd(buyCardCopCd);
					}
					response.setTgmNo(output.getTgmNo());//전문번호			
				}
			} else  {
				response.setProgStcd(output.getSta());                               //상태 (O:정상(승인/취소), X:거절)
				response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
				response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
				
				if ("O".equals(output.getSta())) {
	
					response.setTgmAnswCd("0000"); //응답코드 셋팅
					response.setCardAprvNo(output.getAprvNo()); // 정상일때는 승인번호, 거절일때는 오류코드
	
				} else {
	
				    logger.debug("output.getCardAprvNo():{}",output.getAprvNo());
					response.setTgmAnswCd(output.getAprvNo());//오류일때는 응답코드
	
				}
				response.setIssueCardCopCd(output.getIssueCrdcoCd());				
				if(StringUtils.isEmpty(buyCardCopCd)){
					response.setBuyCardCopCd(output.getBuycoCd());		 //매입사코드
				} else {
					response.setBuyCardCopCd(buyCardCopCd);		 //매입사코드
				}
				response.setTgmNo(output.getTgmNo());//전문번호		
			}
			
//			if ("4518421108496824".equals(SecuUtil.getDecValue(cardNo, EncType.cardNo))) {
//				//응답코드 필드를 따로 사용하지 않고 승인요청이 정상인 경우 승인번호를 리턴하고 비정상인 경우 승인번호항목에 오류코드를 리턴해준다.
//				//2016.10.08;현승훈;테스트를 위해 변경;원복예정
//				//========================================
//				
//				response.setProgStcd(output.getSta());                               //상태 (O:정상(승인/취소), X:거절)
//				response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
//				response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
//				
//				if ("O".equals(output.getSta())) {
//	
//					response.setTgmAnswCd("0000"); //응답코드 셋팅
//					response.setCardAprvNo(output.getAprvNo()); // 정상일때는 승인번호, 거절일때는 오류코드
//	
//				} else {
//	
//				    logger.debug("output.getCardAprvNo():{}",output.getAprvNo());
//					response.setTgmAnswCd(output.getAprvNo());//오류일때는 응답코드
//	
//				}
//				response.setIssueCardCopCd(output.getIssueCrdcoCd());
//				response.setBuyCardCopCd(output.getBuycoCd());		 //매입사코드
//				response.setTgmNo(output.getTgmNo());//전문번호			
//			
//			} else {
//				//========================================
//				
//				//2016.10.08;현승훈;테스트를 위해 변경;나중에삭제예정
//				//========================================
//				response.setProgStcd("O");
//				response.setTgmAnswCd("0000"); //응답코드 셋팅
//				response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
//				response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
//				//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
//				
//				logger.debug("=====>getCurrentTimestamp<====== {}" + getCurrentTimestamp());
//				
//				response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
//				response.setIssueCardCopCd("05");
//				response.setBuyCardCopCd("05");		 //매입사코드
//				response.setTgmNo(output.getTgmNo());//전문번호			
//				//========================================
//				//response.setIssueCardCopCd(this.cardCdChg(output.getIssueCrdcoCd()));
//			}

		}


		return response;
	}
	
	
	/**
	 * <p> 카드승인후 전문로그, DO  변환</p>
	 * @param CardAprvResInfo input  입력데이터
	 * @return  TBCMRTM015Io tbcmrtm015  : 처리결과
	 * @throws ApplicationException
	 */
	private TBCMRTM027Io getTbcmrtm027Io (CardAprvResInfo input)  throws ApplicationException  {

		TBCMRTM027Io tbcmrtm027 = new TBCMRTM027Io();
		
		tbcmrtm027.setCardTgmNo(input.getTgmNo());	                //카드전문번호(KEY)
		tbcmrtm027.setCrdcdMgntNo(input.getCrdcdMgntNo());			//카드관리번호(KEY)
		tbcmrtm027.setMsgCtnt1("");	  					            //처리메시지1
		tbcmrtm027.setMsgCtnt2("");	  					            //처리메시지2
		tbcmrtm027.setCardAprvNo(input.getCardAprvNo())	;           //승인번호
		tbcmrtm027.setCardTxRstYn("");						        //카드거래결과여부
		tbcmrtm027.setCardAffstNo(input.getCardAffstNo());			//가맹점번호
		tbcmrtm027.setIssueCardCopCd(input.getIssueCardCopCd());	//발급사코드
		tbcmrtm027.setBuyCardCopCd(input.getBuyCardCopCd());         //매입사코드
		tbcmrtm027.setCardAprvRcd(input.getTgmAnswCd());			//카드승인결과
		tbcmrtm027.setLastChgPgmId(FwUtil.getPgmId());
		tbcmrtm027.setLastChgrId(FwUtil.getUserId());
		tbcmrtm027.setLastChgTrmNo(FwUtil.getTrmNo());

		return tbcmrtm027;
	}	
	
	 /**
     * <p> 운영계용 처리process </p>
     * @param CardAprvReqInfo   cardReqInfo 카드처리 DO
     * @return CardAprvResInfo  cardResInfo  처리결과 DO
     * @throws ApplicationException
     */
	private CardAprvResInfo callAprvReal(CardAprvReqInfo cardReqInfo) throws ApplicationException {
		
		logger.debug("로그 : 운영계용(callAprvReal) 시작");
		EISResponse < COM_F_KSNOSKSRO00010Out > response = null;
		COM_F_KSNOSKSRO00010In request             = null;
		COM_F_KSNOSKSRO00010Out responseData = null;
		CardAprvResInfo cardResInfo      = null;
			
		try {
			
			String interfaceID ="COM_F_KSNOSKSRO00010";//인터페이스 아이디
			 //전문관련 로그는 대외계에서 테이블로 관리함

			String tgmNo           = cmb010dbio.selectOneTBCNBAS015a().substring(2);	// 전문번호
			String crdcdMgntNo = "";
			String cardCopCd = "";														// 카드회사번호
			String propoDeptOrgNo = "";
			String prcsEno = "";
			String orgKnd = "";
			String trmNo = "";
			
			 
			//고객 카드 인증처리시를 제외하고는 카드관리번호 필수입력
			if (!RTCont.BZ_GB_CS.equals(cardReqInfo.getBzDcd())) {
				 
				TBCSFCR005Io tbcsfcr005io = cmb010dbio.selectOneTBCSFCR0051(SecuUtil.getEncValue(cardReqInfo.getCardNo(), SecuUtil.EncType.Card));
				SecuUtil.doDecObject(tbcsfcr005io);
				
				if(tbcsfcr005io != null){
					crdcdMgntNo = tbcsfcr005io.getCrdcdMgntNo(); 	// 카드관리번호
					cardCopCd = tbcsfcr005io.getCardCopCd();		// 카드회사번호
					
					/**********************************************************
					 * 즉시카드 가능 카드사 체크
					 *********************************************************/
					
					 if ( ! RTCont.IMMDT_CRDCOCD.contains(cardCopCd) )
					 {
						  //즉시카드신청 가능한 카드사가 아닙니다.
						  throw new ApplicationException("APDPE0025", null);
					 }
				}else{
					crdcdMgntNo = cardReqInfo.getCrdcdMgntNo();
				}
				
				if ( StringUtils.isEmpty(crdcdMgntNo) )
				{
					//즉시카드신청 가능한 카드사가 아닙니다.
					throw new ApplicationException("APSLE0402", null);
				}
			}
			
			if(StringUtils.isEmpty(cardReqInfo.getPyrcPrcsEno())) {
				prcsEno = FwUtil.getUserId();					// set [이체처리사원번호]
			}else{
				prcsEno = cardReqInfo.getPyrcPrcsEno();					// set [이체처리사원번호]
			}
						
			CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(prcsEno);
			
			//orgKnd = cmb001dbio.selectOneTBSLORG001a(commEmplInfo.getPropoDeptOrgNo());	//조직종류코드조회
			orgKnd = commEmplInfo.getOrgKcd();
			
			if (StringUtils.isEmpty(orgKnd)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직종류코드(M)" });
			}
			
			// 조직종류 TM -- 100118
			// 조직종류 GA -- 100980
			// 조직종류 스텝부서 -- 발의부서
			if (RTCont.ORG_KND_TM.equals(orgKnd)) {
				propoDeptOrgNo = RTCont.ORG_NO_TM;
			} 
//			else if (RTCont.ORG_KND_GA.equals(orgKnd)) {
//				propoDeptOrgNo = RTCont.ORG_NO_GA;
//			} 
			else {
				//2017.01.26;현승훈;김유나과장요청-발의부서가 소비자보험팀일 경우 통합모니터링팀으로 변경
				if ("DP".equals(cardReqInfo.getBzDcd()) && RTCont.ORG_NO_CNSU_SFGD_TEAM.equals(commEmplInfo.getPropoDeptOrgNo())) {
					propoDeptOrgNo = RTCont.ORG_NO_INTGR_MNT_TEAM;
				} else {
					propoDeptOrgNo = commEmplInfo.getPropoDeptOrgNo();
				}
			}
			
			trmNo =  this.cmb001dbio.selectOneTBCMRTM0243(propoDeptOrgNo,"03");
					
			if ( StringUtils.isEmpty(trmNo) && !RTCont.BZ_GB_CS.equals(cardReqInfo.getBzDcd()) )
			{
				  //해당 발의부서의 거래 모계좌 등록 필수! 빌링 담당자에게 확인하여 주시기 바랍니다.
			     throw new ApplicationException("APPAE0051", null);
			} else {
				//2017.01.26;현승훈;카드인증일 경우 발의부서를 통합모니터링팀으로 조회한다. 
				trmNo =  this.cmb001dbio.selectOneTBCMRTM0243(RTCont.ORG_NO_INTGR_MNT_TEAM,"03");
				if ( StringUtils.isEmpty(trmNo)) {
					 //해당 발의부서의 거래 모계좌 등록 필수! 빌링 담당자에게 확인하여 주시기 바랍니다.
				     throw new ApplicationException("APPAE0051", null);
				}
			}

			
			cardReqInfo.setTrmDcd("01");
			
			//0.전문번호생성 및 카드관리번호 셋팅
			cardReqInfo.setTgmNo(tgmNo);                // 전문번호생성
			cardReqInfo.setCrdcdMgntNo(crdcdMgntNo);	// 카드관리번호
			cardReqInfo.setTrmNo(trmNo);				// 단말번호
		    
			//1.송신데이타 셋팅
			request  = this.getCardAprvReqInfo(cardReqInfo);
			
			logger.debug("request:{}",request);
			logger.debug("toString of request:{}",request.toString());
			logger.debug("toBytes of request:{}",new String(FwUtil.toBytes(request)));
			
			// TODO. 운영에서 테스트 후 정상인 경우 if문 해제(홍선원D:102 테스트 가능)
			//2.송신전 전문로그 저장
			SecuUtil.doEncObject(cardReqInfo);
			
			logger.debug("cardReqInfo---> {}",cardReqInfo);
			
			cmb010dbio.insertOneTBCMRTM027a(this.getTbcmrtm027Io(cardReqInfo,commEmplInfo.getOrgNo() ,propoDeptOrgNo));
			
			logger.debug("request---> {}",request);
			
			//3.동기화 방식 송신
			response= InfUtil.callFEP(request, interfaceID,COM_F_KSNOSKSRO00010Out.class);

			logger.debug("response---> {}",response);

			responseData = response.getResponseData();
			
			logger.debug("responseData---> {}",responseData);

			//4.카드 수신 결과 데이타 변환
			cardResInfo = this.getCardAprvRes(responseData,cardReqInfo.getCardNo(),RTCont.REAL_MODE);
			
			cardResInfo.setTgmNo(tgmNo);
			cardResInfo.setCrdcdMgntNo(crdcdMgntNo);
			
			// TODO. 운영에서 테스트 후 정상인 경우 if문 해제(홍선원D:102 테스트 가능)
			
			//5.송신후 전문로그 저장
			cmb010dbio.updateOneTBCMRTM027a(this.getTbcmrtm027Io(cardResInfo));
				
			
		} catch ( EisExecutionException e) {
			
            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");			
			
			throw new ApplicationException("APNBE0058", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});

		} catch ( NotSupportedEISException e) {

            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");		
			throw new ApplicationException("APNBE0058", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});
		}

		return cardResInfo;
		
	}
	
	
	/**
     * <p> 개발/검증계용 처리process </p>
     * @param CardAprvReqInfo   cardReqInfo 카드처리 DO
     * @return CardAprvResInfo  cardResInfo  처리결과 DO 
     * @throws ApplicationException
     */
	private CardAprvResInfo callCnclDev(CardAprvReqInfo cardReqInfo) throws ApplicationException {
		logger.debug("로그 : 개발/검증계용(callAprvDev) 시작");

		COM_F_KSNOSKSRO00011In request             = null;
		COM_F_KSNOSKSRO00011Out responseData = null;
		CardAprvResInfo cardResInfo      = null;
		
		try {
			
			 //전문관련 로그는 대외계에서 테이블로 관리함
			 String tgmNo           = cmb010dbio.selectOneTBCNBAS015a().substring(2);                    //전문번호

			 String crdcdMgntNo = "";
			 String trmNo = "";
			 String propoDeptOrgNo = "";
			 String prcsEno = "";
			 String orgKnd = "";
			 
			 //고객 카드 인증처리시를 제외하고는 카드관리번호 필수입력
			 if (!RTCont.BZ_GB_CS.equals(cardReqInfo.getBzDcd())) {

				 
				 
				TBCSFCR005Io tbcsfcr005io = cmb010dbio.selectOneTBCSFCR0051(SecuUtil.getEncValue(cardReqInfo.getCardNo(), SecuUtil.EncType.Card));
				SecuUtil.doDecObject(tbcsfcr005io);
				
				if(tbcsfcr005io != null){
					crdcdMgntNo = tbcsfcr005io.getCrdcdMgntNo(); 	// 카드관리번호
					//cardCopCd = tbcsfcr005io.getCardCopCd();		// 카드회사번호
				}else{
					crdcdMgntNo = cardReqInfo.getCrdcdMgntNo();
				}
				
				if ( StringUtils.isEmpty(crdcdMgntNo) )
				{
					  //즉시카드신청 가능한 카드사가 아닙니다.
					  throw new ApplicationException("APSLE0402", null);
				}
					
				 //crdcdMgntNo = cmb010dbio.selectOneTBCSFCR005a(SecuUtil.getEncValue(cardReqInfo.getCardNo(), SecuUtil.EncType.Card)); //카드관리번호

				 SelectOneTBCMRTM015aOut  tbcmrtm015io = cmb010dbio.selectOneTBCMRTM0151(crdcdMgntNo, cardReqInfo.getCardAprvNo()); //카드관리번호, 카드승인번호
					
					if(StringUtils.isEmpty(tbcmrtm015io.getTrmNo()) ){
						//기처리된 단말기번호가 존재하지 않습니다.
						  throw new ApplicationException("APCME0059", null);
					}
					
					trmNo = tbcmrtm015io.getTrmNo();
					propoDeptOrgNo = tbcmrtm015io.getPropoDeptOrgNo();
			 }
			 
			 logger.debug("crdcdMgntNo {}",crdcdMgntNo);
			 
			if(StringUtils.isEmpty(cardReqInfo.getPyrcPrcsEno())) {
				prcsEno = FwUtil.getUserId();					// set [이체처리사원번호]
			}else{
				prcsEno = cardReqInfo.getPyrcPrcsEno();					// set [이체처리사원번호]
			}
			
			CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(prcsEno);
			
			//orgKnd = cmb001dbio.selectOneTBSLORG001a(commEmplInfo.getPropoDeptOrgNo());	//조직종류코드조회
			orgKnd = commEmplInfo.getOrgKcd();
			
			if (StringUtils.isEmpty(orgKnd)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직종류코드(M)" });
			}
			 
			if ( StringUtils.isEmpty(crdcdMgntNo) )
			{
				  //즉시카드신청 가능한 카드사가 아닙니다.
				throw new ApplicationException("APSLE0402", null);
			}
			 
			//0.전문번호생성
			//0.전문번호생성 및 카드관리번호 셋팅
		    cardReqInfo.setTgmNo(tgmNo);                     //전문번호생성
		    cardReqInfo.setCrdcdMgntNo(crdcdMgntNo);//카드관리번호
		    cardReqInfo.setTrmNo(trmNo);//단말번호
		    
		    
		    //1.카드 송신 데이타 변환
			request = this.getCardCnclReqInfo(cardReqInfo);
			logger.debug("request {}",request);
			logger.debug("length of request:{}",request.toString().length());
			
			//2.송신전 전문로그 저장
			SecuUtil.doEncObject(cardReqInfo);
			cmb010dbio.insertOneTBCMRTM027a(this.getTbcmrtm027Io(cardReqInfo,commEmplInfo.getOrgNo() ,propoDeptOrgNo));
			
	       //3.테스트를 위해 van사 호출하지 않음
			responseData = new COM_F_KSNOSKSRO00011Out();
			responseData.setTgmNo(request.getTgmNo());//송신때 채번한 전문번호 수신때 강제셋팅작업

			//4.카드 수신 데이타 변환
			cardResInfo = this.getCardCnclRes(responseData,cardReqInfo.getCardNo(),RTCont.TEST_MODE);
			
			cardResInfo.setTgmNo(tgmNo);
			cardResInfo.setCrdcdMgntNo(crdcdMgntNo);
			
			 logger.debug("cardResInfo {}",cardResInfo);
			
			//5.송신후 전문로그 저장
			 cmb010dbio.updateOneTBCMRTM027a(this.getTbcmrtm027Io(cardResInfo));
			 
			
		} catch (ApplicationException ae) {
			
			throw ae;
		}
		
		return cardResInfo;

		 
	}
	
	
	/**
	 * <p> 카드승인취소송신 DO  변환</p>
	 * @param CardAprvReqInfo input   카드승인취소요청 DO
	 * @return NBZB40SVC00In  : 처리결과 OMM(any link 결과값)
	 * @throws ApplicationException
	 */
	private COM_F_KSNOSKSRO00011In getCardCnclReqInfo(CardAprvReqInfo input)  throws ApplicationException  {


		COM_F_KSNOSKSRO00011In request = new COM_F_KSNOSKSRO00011In();

		//공통부 셋팅
		//request.setTrlen(cmbz00bean.fillSpace(RTCont.REQUEST_SIZE_A , 4)); 						// 전문전체길이
		//request.setMsgCd(NBZZ20BEAN.MSG_CD);                                                  		//  전문코드
		//request.setBzDvsn(NBZZ20BEAN.BZ_DVSN);                                                  	// 거래구분코드
		//request.setTrnsDt(DateUtils.getCurrentDate(2));                                           	// 처리년월일 20121110
		//request.setTrnsHms(DateUtils.getCurrentTime(6));                                        	// 처리시간  131025
		//request.setPprn(NBZZ20BEAN.fillSpace("",12));
		
		//데이터부 셋팅
		//request.setLenVl(NBZZ20BEAN.fillSpace(NBZZ20BEAN.REQUEST_SIZE_A , 4));                   	// 0.전체길이
		request.setStrtSb(new String(new byte[]{(byte)0x02}));                                   	// 1.STX
        request.setTxDvsn(CMBZ00BEAN.fillSpace(input.getTxDcd(), 2));                                 // 2.거래구분코드
        
        /* 단말기번호는 업무별로 셋팅해준다. 
         * 입금 : 호출시 셋팅할 단말기구분코드를 넘겨준다. trmDcd
         * 그외 : 신계약/고객 등은 단일 셋팅  
         */
//        if (RTCont.BZ_GB_DP.equals(input.getBzDcd())) { // 입금
//
//        	if(StringUtils.isEmpty(input.getTrmDcd())){	
//        		request.setTrmNo(RTCont.TRM_NO);												// 3.단말기번호
//        	}else{
//        		// 입금파트에서 호출시 단말기번호 셋팅
//        		if("02".equals(input.getTrmDcd())){
//            		request.setTrmNo(RTCont.TRM_NO2);												
//            	}else if("03".equals(input.getTrmDcd())){
//            		request.setTrmNo(RTCont.TRM_NO3);												
//            	}else if("04".equals(input.getTrmDcd())){
//            		request.setTrmNo(RTCont.TRM_NO4);												
//            	}else if("05".equals(input.getTrmDcd())){
//            		request.setTrmNo(RTCont.TRM_NO5);											// 2013.12.30 롯데아멕스카드 다이렉트 본부인 경우
//            	}
//        	}
//        }else{ // 그외(신계약,고객)
//        	if(StringUtils.isEmpty(input.getTrmDcd())){	
//        		request.setTrmNo(RTCont.TRM_NO);												// 3.단말기번호
//        	}else{
//        		if("01".equals(input.getTrmDcd())){
//        			request.setTrmNo(RTCont.TRM_NO1);											// 2013.12.30 롯데아멕스카드 다이렉트 본부인 경우
//        		}else{
//        			request.setTrmNo(RTCont.TRM_NO);											// 3.단말기번호
//        		}
//        	}
//        	
//        }
        
        //request.setTrmNo(RTCont.TRM_NO);											// 3.단말기번호
        request.setTrmNo(input.getTrmNo());											// 3.단말기번호            
        request.setCmpyInfo(RTCont.CMPY_NM);                                                  	// 4.업체번호
        request.setTgmNo(input.getTgmNo());                                                         // 5.전문번호 
        request.setEntDvsn(RTCont.POS_ENTRY_MD);                                             // 6.pos entry mode Key-in 방식
        
        String track = SecuUtil.getDecValue(input.getCardNo(), EncType.cardNo) +RTCont.TRACK_DC+input.getCardVldYm().substring(2)+input.getCardVldYm().substring(0,2);
        request.setTrc(CMBZ00BEAN.fillSpace(track,37));                                           // 7.track
        request.setFileSep(new String(new byte[]{(byte)0x1C}));                                 	// 8.FS
        if(StringUtils.isEmpty(input.getMipMcnt())) {
        	request.setMipMcnt("00");                              	// 9.할부개월수
        } else {
        	request.setMipMcnt(input.getMipMcnt().concat(StringUtils.lpad("", 2, "0")));                              	// 9.할부개월수
        }
        
       	request.setTtlAmt(CMBZ00BEAN.fillZero(input.getCardApplAmt(),9));   					//10.총금액	
        request.setSvcFee(CMBZ00BEAN.fillZero(RTCont.ZERO,9));            						//11.봉사료
        request.setPwdDvsn(RTCont.WK_KEY);   //12. Working key index
        request.setPswd(RTCont.PWD);            //13.비밀번호 미사용시 0000000000000000
        request.setAprvNo(CMBZ00BEAN.fillSpace(input.getCardAprvNo(),12));                        //14.원거래승인번호
        request.setTxDt(CMBZ00BEAN.fillSpace(input.getCardAprvDt().substring(2),6));        //15.원거래승인일자        
        request.setPrdcd(CMBZ00BEAN.fillSpace("",6)); //16.상품코드 : 미사용시 space
       	request.setUsrInfo(CMBZ00BEAN.fillSpace("",13));  //17.사용자번호
       	
        logger.debug("테스트 [{}]", request.getUsrInfo());
        request.setElecTxSecuGd(CMBZ00BEAN.fillSpace("",1)); 			//18.전자상거래보안등급
        request.setRsvtField(CMBZ00BEAN.fillSpace("",14));				//20.예약필드
        request.setFlg1(new String(new byte[]{(byte)0x03}));           //21.ETX
        request.setFlg2(new String(new byte[]{(byte)0x0D}));           //22.CR

		return request;
	}
	
	/**
	 * <p> 카드수신 DO  변환</p>
	 * @param NBZB40SVC00Out  output 입력데이터
	 * @param String  mode 개발/운영
	 * @return CardAprvResInfo   카드승인결과 DO
	 * @throws ApplicationException
	 */
	private CardAprvResInfo getCardCnclRes(COM_F_KSNOSKSRO00011Out output,String cardNo,String mode)   throws ApplicationException {



		CardAprvResInfo response = new CardAprvResInfo();
		
		// 오늘일자 : YYYYMMDDHHMISS
		Date toDay = new Date();
		SimpleDateFormat currentDate = null;
		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
		String todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");

		String currentMin = todayHms.substring(2, 4);		
		String startMin = "00";
		String endMin = "31";
		
		String buyCardCopCd = cmb010dbio.selectOneTBCMETC013a(SecuUtil.getDecValue(cardNo, SecuUtil.EncType.Card).substring(0, 6));
		
		logger.debug("====== buyCardCopCd =======" + buyCardCopCd);

		if (RTCont.TEST_MODE.equals(mode)) {

			if("8888888888888888".equals(cardNo) ) {

				response.setProgStcd("X");                                      //상태 (O:정상(승인/취소), X:거절)
				//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
				//response.setCardAprvDt(DateUtils.getCurrentDate(2));          //승인일자
				//response.setBuyCardCopCd("26");
				//response.setCardAffstNo("07565961");
				response.setTgmAnswCd("8314"); //응답코드 셋팅
				//response.setIssueCardCopCd("26");
				response.setTgmNo(output.getTgmNo());//전문번호
				
			} else if ("9999999999999999".equals(cardNo)) {
				
				
				response.setProgStcd("X");                                      //상태 (O:정상(승인/취소), X:거절)
				//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
				//response.setCardAprvDt(DateUtils.getCurrentDate(2));          //승인일자
				//response.setBuyCardCopCd("26");
				//response.setCardAffstNo("07565961");
				response.setTgmAnswCd("8329"); //응답코드 셋팅
				//response.setIssueCardCopCd("26");
				response.setTgmNo(output.getTgmNo());//전문번호
				
			} else {
				
				
				response.setProgStcd("O");                                      //상태 (O:정상(승인/취소), X:거절)
				//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
				response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
				response.setCardAprvDt(DateUtils.getCurrentDate(2));                //승인일자
				
				response.setCardAffstNo("07565961");
				response.setTgmAnswCd("0000"); //응답코드 셋팅
				response.setIssueCardCopCd("05");
				response.setTgmNo(output.getTgmNo());//전문번호
				if(StringUtils.isEmpty(buyCardCopCd)){
					response.setBuyCardCopCd("05");
				} else {
					response.setBuyCardCopCd(buyCardCopCd);
				}
			}
		} else {
			
			//
			if (Integer.parseInt(today) < Integer.parseInt("20170201")) {
				if (Integer.parseInt(today) < Integer.parseInt("20170101")) {
					if ("20161219".equals(today) || "20161220".equals(today)) {
						response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
						//response.setBuyCardCopCd(this.cardCdChg(output.getBuycoCd()));		 //매입사코드		
						
						response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
						response.setProgStcd("O");                               //상태 (O:정상(승인/취소), X:거절)
						response.setTgmAnswCd("0000"); //응답코드 셋팅			
						//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
						response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
						response.setIssueCardCopCd("05");
						
						if(StringUtils.isEmpty(buyCardCopCd)){
							response.setBuyCardCopCd("05");
						} else {
							response.setBuyCardCopCd(buyCardCopCd);
						}
						//========================================

						//response.setIssueCardCopCd(this.cardCdChg(output.getIssueCrdcoCd()));
						
						response.setTgmNo(output.getTgmNo());//전문번호
					} else {
							if ( Integer.parseInt(currentMin) > Integer.parseInt(startMin) &&
									Integer.parseInt(currentMin) < Integer.parseInt(endMin) ) {
								response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
								//response.setBuyCardCopCd(this.cardCdChg(output.getBuycoCd()));		 //매입사코드		
								
								response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
	
								//응답코드 필드를 따로 사용하지 않고 승인요청이 정상인 경우 승인번호를 리턴하고 비정상인 경우 승인번호항목에 오류코드를 리턴해준다.
								//========================================
								response.setProgStcd(output.getSta());                               //상태 (O:정상(승인/취소), X:거절)
								
								if ("O".equals(output.getSta())) {
	
									response.setTgmAnswCd("0000"); //응답코드 셋팅
									response.setCardAprvNo(output.getAprvNo()); // 정상일때는 승인번호, 거절일때는 오류코드
	
								} else {
	
								    logger.debug("output.getCardAprvNo():{}",output.getAprvNo());
									response.setTgmAnswCd(output.getAprvNo());//오류일때는 응답코드
	
								}
								response.setIssueCardCopCd(output.getIssueCrdcoCd());		
								response.setTgmNo(output.getTgmNo());//전문번호
								
								
								if(StringUtils.isEmpty(buyCardCopCd)){
									response.setBuyCardCopCd(output.getBuycoCd());		 //매입사코드
								} else {
									response.setBuyCardCopCd(buyCardCopCd);
								}
								//=============================================
								
							} else {
								response.setCardAprvDt(output.getTxDtm());          //승인일자(거래일자)
								//response.setBuyCardCopCd(this.cardCdChg(output.getBuycoCd()));		 //매입사코드		
								
								response.setCardAffstNo(output.getAffstNo());		//가맹점코드
								response.setProgStcd("O");                          //상태 (O:정상(승인/취소), X:거절)
								response.setTgmAnswCd("0000"); //응답코드 셋팅			
								//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
								response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
								response.setIssueCardCopCd("05");
								
								if(StringUtils.isEmpty(buyCardCopCd)){
									response.setBuyCardCopCd("05");
								} else {
									response.setBuyCardCopCd(buyCardCopCd);
								}
								//========================================
	
								//response.setIssueCardCopCd(this.cardCdChg(output.getIssueCrdcoCd()));
								
								response.setTgmNo(output.getTgmNo());//전문번호
							}
					}
					
				} else {
						
					response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
					//response.setBuyCardCopCd(this.cardCdChg(output.getBuycoCd()));		 //매입사코드		
					
					response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
					response.setProgStcd("O");                               //상태 (O:정상(승인/취소), X:거절)
					response.setTgmAnswCd("0000"); //응답코드 셋팅			
					//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
					response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
					response.setIssueCardCopCd("05");
					
					if(StringUtils.isEmpty(buyCardCopCd)){
						response.setBuyCardCopCd("05");
					} else {
						response.setBuyCardCopCd(buyCardCopCd);
					}
					//========================================

					//response.setIssueCardCopCd(this.cardCdChg(output.getIssueCrdcoCd()));
					
					response.setTgmNo(output.getTgmNo());//전문번호
				}
			} else  {
				response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
				//response.setBuyCardCopCd(this.cardCdChg(output.getBuycoCd()));		 //매입사코드		
				
				response.setCardAffstNo(output.getAffstNo());						 //가맹점코드

				//응답코드 필드를 따로 사용하지 않고 승인요청이 정상인 경우 승인번호를 리턴하고 비정상인 경우 승인번호항목에 오류코드를 리턴해준다.
				//========================================
				
				response.setProgStcd(output.getSta());                               //상태 (O:정상(승인/취소), X:거절)
				
				if ("O".equals(output.getSta())) {

					response.setTgmAnswCd("0000"); //응답코드 셋팅
					response.setCardAprvNo(output.getAprvNo()); // 정상일때는 승인번호, 거절일때는 오류코드

				} else {

				    logger.debug("output.getCardAprvNo():{}",output.getAprvNo());
					response.setTgmAnswCd(output.getAprvNo());//오류일때는 응답코드

				}
				response.setIssueCardCopCd(output.getIssueCrdcoCd());
				response.setTgmNo(output.getTgmNo());//전문번호
				
				if(StringUtils.isEmpty(buyCardCopCd)){
					response.setBuyCardCopCd(output.getBuycoCd());		 //매입사코드
				} else {
					response.setBuyCardCopCd(buyCardCopCd);
				}
				//=============================================
			}
			
//			response.setCardAprvDt(output.getTxDtm());                           //승인일자(거래일자)
//			//response.setBuyCardCopCd(this.cardCdChg(output.getBuycoCd()));		 //매입사코드		
//			response.setBuyCardCopCd(output.getBuycoCd());		 //매입사코드
//			response.setCardAffstNo(output.getAffstNo());						 //가맹점코드
//
//			//응답코드 필드를 따로 사용하지 않고 승인요청이 정상인 경우 승인번호를 리턴하고 비정상인 경우 승인번호항목에 오류코드를 리턴해준다.
//			//2016.10.08;현승훈;테스트를 위해 변경;원복예정
//			//========================================
//			/*
//			response.setProgStcd(output.getSta());                               //상태 (O:정상(승인/취소), X:거절)
//			
//			if ("O".equals(output.getSta())) {
//
//				response.setTgmAnswCd("0000"); //응답코드 셋팅
//				response.setCardAprvNo(output.getAprvNo()); // 정상일때는 승인번호, 거절일때는 오류코드
//
//			} else {
//
//			    logger.debug("output.getCardAprvNo():{}",output.getAprvNo());
//				response.setTgmAnswCd(output.getAprvNo());//오류일때는 응답코드
//
//			}
//			response.setIssueCardCopCd(output.getIssueCrdcoCd());
//			*/
//			//=============================================
//			
//			//2016.10.08;현승훈;테스트를 위해 변경;나중에삭제예정
//			//========================================
//			response.setProgStcd("O");                               //상태 (O:정상(승인/취소), X:거절)
//			response.setTgmAnswCd("0000"); //응답코드 셋팅			
//			//response.setCardAprvNo("99"+DateUtils.getCurrentTime(6));     // 정상일때는 승인번호, 거절일때는 오류코드
//			response.setCardAprvNo("9"+ getCurrentTimestamp().substring(12, 20));     // 정상일때는 승인번호, 거절일때는 오류코드
//			response.setIssueCardCopCd("05");
//			//========================================
//
//			//response.setIssueCardCopCd(this.cardCdChg(output.getIssueCrdcoCd()));
//			
//			response.setTgmNo(output.getTgmNo());//전문번호

		}


		return response;
	}
	
	 /**
     * <p> 운영계용 처리process </p>
     * @param CardAprvReqInfo   cardReqInfo 카드처리 DO
     * @return CardAprvResInfo  cardResInfo  처리결과 DO
     * @throws ApplicationException
     */
	private CardAprvResInfo callCnclReal(CardAprvReqInfo cardReqInfo) throws ApplicationException {
		
		logger.debug("로그 : 운영계용(callAprvReal) 시작");
		EISResponse < COM_F_KSNOSKSRO00011Out > response = null;
		COM_F_KSNOSKSRO00011In request             = null;
		COM_F_KSNOSKSRO00011Out responseData = null;
		CardAprvResInfo cardResInfo      = null;
		
			
		try {
			
			String interfaceID ="COM_F_KSNOSKSRO00011";//인터페이스 아이디
			 //전문관련 로그는 대외계에서 테이블로 관리함

			String tgmNo       = cmb010dbio.selectOneTBCNBAS015a().substring(2);	// 전문번호
			String crdcdMgntNo = "";
			String cardCopCd = "";													// 카드회사번호
			String trmNo = "";
			String propoDeptOrgNo = "";
			String prcsEno = "";
			String orgKnd = "";
			 
			//고객 카드 인증처리시를 제외하고는 카드관리번호 필수입력
			if (!RTCont.BZ_GB_CS.equals(cardReqInfo.getBzDcd())) {
				 
				TBCSFCR005Io tbcsfcr005io = cmb010dbio.selectOneTBCSFCR0051(SecuUtil.getEncValue(cardReqInfo.getCardNo(), SecuUtil.EncType.Card));
				SecuUtil.doDecObject(tbcsfcr005io);
				
				if(tbcsfcr005io != null){
					crdcdMgntNo = tbcsfcr005io.getCrdcdMgntNo(); 	// 카드관리번호
					cardCopCd = tbcsfcr005io.getCardCopCd();		// 카드회사번호
				}else{
					crdcdMgntNo = cardReqInfo.getCrdcdMgntNo();
				}
				
				if ( StringUtils.isEmpty(crdcdMgntNo) )
				{
					  //즉시카드신청 가능한 카드사가 아닙니다.
					  throw new ApplicationException("APSLE0402", null);
				}
				
				SelectOneTBCMRTM015aOut  tbcmrtm015io = cmb010dbio.selectOneTBCMRTM0151(crdcdMgntNo, cardReqInfo.getCardAprvNo()); //카드관리번호, 카드승인번호
				
				if(StringUtils.isEmpty(tbcmrtm015io.getTrmNo()) ){
					//기처리된 단말기번호가 존재하지 않습니다.
					  throw new ApplicationException("APCME0059", null);
				}
				
				trmNo = tbcmrtm015io.getTrmNo();
				propoDeptOrgNo = tbcmrtm015io.getPropoDeptOrgNo();
			}
			 
			// 2013-12-30. 단말구분번호 셋팅(신계약 다이렉트본부의 롯데카드 분기용)
//			if (RTCont.BZ_GB_NB.equals(cardReqInfo.getBzDcd())){
//				if(!StringUtils.isEmpty(cardCopCd) && "47".equals(cardCopCd)){
//					// 롯데카드인 경우 (다이렉트 본부인지 확인한다)
//					
//					TBCNBAS001Io tbcnbas001io = nba030dbio.selectOneTBCNBAS001a(cardReqInfo.getContNo());
//					
//					if(tbcnbas001io != null && NBZZ20BEAN.DIRECT_HQ_TEAM.equals(tbcnbas001io.getClmnHqOrgNo())){
//						cardReqInfo.setTrmDcd("01");	
//					}
//				}
//			}
			
//		    prcsEno = FwUtil.getUserId();					// set [이체처리사원번호]
			
//			CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(prcsEno);
//			
//			orgKnd = cmb001dbio.selectOneTBSLORG001a(commEmplInfo.getPropoDeptOrgNo());	//조직종류코드조회
//			
//			if (StringUtils.isEmpty(orgKnd)) {
//				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직종류코드(M)" });
//			}
//			
//			// 조직종류 TM -- 100118
//			// 조직종류 GA -- 100980
//			// 조직종류 스텝부서 -- 발의부서
//			if (RTCont.ORG_KND_TM.equals(orgKnd)) {
//				propoDeptOrgNo = RTCont.ORG_NO_TM;
//			} else if (RTCont.ORG_KND_GA.equals(orgKnd)) {
//				propoDeptOrgNo = RTCont.ORG_NO_GA;
//			} else if (RTCont.ORG_KND_STEP.equals(orgKnd)) {
//				propoDeptOrgNo = commEmplInfo.getPropoDeptOrgNo();
//			}
//			
//			trmNo =  this.cmb001dbio.selectOneTBCMRTM0243(propoDeptOrgNo,"03");
//			
//		
//		    if ( StringUtils.isEmpty(trmNo) )
//			{
//				  //즉시카드신청 가능한 카드사가 아닙니다.
//			     throw new ApplicationException("APPAE0051", null);
//			}			
			
			if(StringUtils.isEmpty(cardReqInfo.getPyrcPrcsEno())) {
				prcsEno = FwUtil.getUserId();					// set [이체처리사원번호]
			}else{
				prcsEno = cardReqInfo.getPyrcPrcsEno();					// set [이체처리사원번호]
			}
			
			CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(prcsEno);
			
			//orgKnd = cmb001dbio.selectOneTBSLORG001a(commEmplInfo.getPropoDeptOrgNo());	//조직종류코드조회
			orgKnd = commEmplInfo.getOrgKcd();
			
			if (StringUtils.isEmpty(orgKnd)) {
				throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "조직종류코드(M)" });
			}
			
			cardReqInfo.setTrmDcd("01");
			
			//0.전문번호생성 및 카드관리번호 셋팅
			cardReqInfo.setTgmNo(tgmNo);                // 전문번호생성
			cardReqInfo.setCrdcdMgntNo(crdcdMgntNo);	// 카드관리번호
			cardReqInfo.setTrmNo(trmNo);
		    
		    
			//1.송신데이타 셋팅
			request  = this.getCardCnclReqInfo(cardReqInfo);
			
			logger.debug("request:{}",request);
			logger.debug("toString of request:{}",request.toString());
			logger.debug("toBytes of request:{}",new String(FwUtil.toBytes(request)));
			
			// TODO. 운영에서 테스트 후 정상인 경우 if문 해제(홍선원D:102 테스트 가능)
			//2.송신전 전문로그 저장
			SecuUtil.doEncObject(cardReqInfo);
			cmb010dbio.insertOneTBCMRTM027a(this.getTbcmrtm027Io(cardReqInfo, commEmplInfo.getOrgNo(),propoDeptOrgNo));
			
			//3.동기화 방식 송신
			response= InfUtil.callFEP(request, interfaceID,COM_F_KSNOSKSRO00011Out.class);

			logger.debug("response---> {}",response);

			responseData = response.getResponseData();
			
			logger.debug("responseData---> {}",responseData);

			//4.카드 수신 결과 데이타 변환
			cardResInfo = this.getCardCnclRes(responseData,cardReqInfo.getCardNo(),RTCont.REAL_MODE);
			
			cardResInfo.setTgmNo(tgmNo);
			cardResInfo.setCrdcdMgntNo(crdcdMgntNo);
			
			// TODO. 운영에서 테스트 후 정상인 경우 if문 해제(홍선원D:102 테스트 가능)
			
			//5.송신후 전문로그 저장
			cmb010dbio.updateOneTBCMRTM027a(this.getTbcmrtm027Io(cardResInfo));
				
			
		} catch ( EisExecutionException e) {
			
            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");			
			
			throw new ApplicationException("APNBE0058", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});

		} catch ( NotSupportedEISException e) {

            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");		
			throw new ApplicationException("APNBE0058", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});
		}

		return cardResInfo;
		
	}
	
	public static String getCurrentTimestamp() {
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmssSSSSSS", Locale.KOREA);
        String ff = df.format(FwUtil.getSystemDate());

        return ff;
	}
	
	public String chkTrmNo (String crdcdMgntNo, String cardAprvNo ) throws ApplicationException {
		
		String trmNo = "";
		
		SelectOneTBCMRTM015aOut  tbcmrtm015io = cmb010dbio.selectOneTBCMRTM0151(crdcdMgntNo, cardAprvNo); //카드관리번호, 카드승인번호
		
		if(StringUtils.isEmpty(tbcmrtm015io.getTrmNo()) ){
			//기처리된 단말기번호가 존재하지 않습니다.
			  throw new ApplicationException("APCME0059", null);
		}
		
		trmNo = tbcmrtm015io.getTrmNo();
		return trmNo; 
	}
	
}

