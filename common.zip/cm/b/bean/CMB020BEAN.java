package cigna.cm.b.bean;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB020DBIO;
import cigna.cm.b.domain.MblStlmReqInfo;
import cigna.cm.b.domain.MblStlmResInfo;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.io.COM_F_MOBOSMOMC00001In;
import cigna.cm.b.io.COM_F_MOBOSMOMO00001In;
import cigna.cm.b.io.COM_F_MOBOSMOMO00001Out;
import cigna.cm.b.io.TBCMRTM016Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;

import com.mobilians.mc01_v0005.McashSeed;



/**
 * @file         cigna.cm.b.bean.CMB020BEAN.java
 * @filetype     java source file
 * @brief		 RTM 모바일이체처리
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                          성명                                                일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 2. 15.      신규 작성
 *
 */
@KlafBean
public class CMB020BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/*****************************************
	 * 모바일 이체 DBIO
	 *****************************************/
	@Autowired
	private CMB020DBIO	cmb020dbio;
	
	// 테스트 카드번호
    public static final String TEST_MBL_NO = "01086073720";
	
	
	
	/**
     * <p> 모바일 결제 처리</p>
     * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
     * @return MblStlmResInfo  mblResInfo  처리결과 DO
     * @throws ApplicationException
     */
	public MblStlmResInfo setMblStlmPrcs(MblStlmReqInfo mblReqInfo) throws ApplicationException {



		if (mblReqInfo == null) {
			throw new ApplicationException("APNBE0058", null);
		}

		MblStlmResInfo mblResInfo  = null;
 
        // 정합성 체크
		 this.chkMblStlmPrcs(mblReqInfo);

		 String testDay		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		 
		 String mode = LApplicationContext.getSystemMode();	 
		 logger.debug("mode{}",mode);
		 logger.debug("======== MembMpno ======= {}",mblReqInfo.getMembMpno());
		 
		 //운영계
		 //2016.10.08
		 //2016.12.23;RTM 리얼적용 제외
		 //2017.04.11;현승훈;RTM 적용
		 if("R".equals(mode) || "D".equals(mode)) {
		 //if("R".equals(mode) && "BDPO701B".equals(FwUtil.getPgmId())) {	//2016-12-28 최영록 : 모바일청구배치 테스트를 위해 실제 모빌리언스 연동
		 //if("R".equals(mode) || ( "D".equals(mode) && TEST_MBL_NO.indexOf((SecuUtil.getDecValue(mblReqInfo.getMembMpno(), EncType.membRrno) )) >= 0 )) {
		 //2016.09.12;운영계에서 FEP시뮬레이터 환경 더이상 호출하지 않도록 처리(시뮬레이터 환경이 불안정)
		 //if( "D".equals(mode) ) {
			  //개발
			  if (Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				  
				  mblResInfo = this.callAprvDev(mblReqInfo);
				  			  
			  //실제 모빌리언스 연동
			  } else {
				  
				  mblResInfo= this.callAprvReal(mblReqInfo);
				  
			  }			  		  
		 //개발,테스트	  
		 //} else if("D".equals(mode) || "T".equals(mode)) {
		 //} else if("T".equals(mode)) {
		//2016.09.12;운영계에서 FEP시뮬레이터 환경 더이상 호출하지 않도록 처리(시뮬레이터 환경이 불안정)
		 } else if("T".equals(mode) ) {
		    
			//cardResInfo= this.callAprvReal(cardReqInfo);  //---> 애니링크 확인할 때
			  mblResInfo = this.callAprvDev(mblReqInfo);
			 
		  } 

	    return mblResInfo;

	}
	
	/**
	 * <p> 모바일결제처리 입력값  확인</p>
	 * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
	 * @throws ApplicationException
	 */
	private void chkMblStlmPrcs ( MblStlmReqInfo input ) throws ApplicationException {

		//String trxDt  = DateUtils.getCurrentDate(2);//처리일자
		BigDecimal zero = BigDecimal.ZERO;

		if(StringUtils.isEmpty(input.getMembMpno())) {

	        logger.debug("휴대전화번호를 입력하지 않았습니다.");
	        throw new ApplicationException("APPRE0000", new Object[]{"휴대전화번호"}, new Object[]{"휴대전화번호"});

		}

		if(StringUtils.isEmpty(input.getTelDcd())) {

	        logger.debug("이동동신사를 입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"이동동신사이동동신사를"}, new Object[]{"이동동신사"});
		}
		
		if(StringUtils.isEmpty(input.getMembRrno())) {

	        logger.debug("주민등록번호를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"주민등록번호"}, new Object[]{"주민등록번호"});
		}

		if (input.getTrsfAmt() == null || input.getTrsfAmt().compareTo(zero) == 0 ) {

	        logger.debug("이체금액을  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"이체금액"}, new Object[]{"이체금액"});

		}
	}
	
	/**
     * <p> 개발/검증계용 처리process </p>
     * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
     * @return MblStlmResInfo  mblResInfo  처리결과 DO
     * @throws ApplicationException
     */
	private MblStlmResInfo callAprvDev(MblStlmReqInfo mblReqInfo) throws ApplicationException {
		logger.debug("로그 : 개발/검증계용(callAprvDev) 시작");

		COM_F_MOBOSMOMO00001In request             = null;
		COM_F_MOBOSMOMO00001Out responseData = null;
		MblStlmResInfo mblResInfo      = null;
		
		try {
			
//			 //전문관련 로그는 대외계에서 테이블로 관리함
			String newMblTrsfTxNo = "";
			
			// 모바일이체거래번호 조회
			newMblTrsfTxNo =  this.getNewMblTrsfTxNo();
			
			logger.debug("crdcdMgntNo {}",newMblTrsfTxNo);
			 
		    mblReqInfo.setMblTrsfTxNo(newMblTrsfTxNo);                     //모바일이체거래번호
		    
		    logger.debug("----------mblReqInfo---------" + mblReqInfo);
		 
		    //1.모바일 결제 송신 데이타 변환
			request = this.getMblStmlAprvReqInfo(mblReqInfo);
			logger.debug("request {}",request);
			logger.debug("length of request:{}",request.toString().length());
			
			//2.송신전 전문로그 저장				
			cmb020dbio.insertOneTBCMRTM016a(this.getTbcmrtm016Io(mblReqInfo));
			
	       //3.테스트를 위해 van사 호출하지 않음
			responseData = new COM_F_MOBOSMOMO00001Out();
			responseData.setStorTxNo(request.getStorTxNo());//송신때 상점거래번호

			//4.모바일 결제 수신 데이타 변환
			mblResInfo = this.getMblAprvRes(responseData, request.getMpno(),RTCont.TEST_MODE);

			mblResInfo.setMblTrsfTxNo(newMblTrsfTxNo);
			
			 logger.debug("cardResInfo {}",mblResInfo);
			
			//5.송신후 전문로그 저장
			 cmb020dbio.updateOneTBCMRTM016a(this.getTbcmrtm016Io(mblResInfo));
			 
			
		} catch (ApplicationException ae) {
			
			throw ae;
		}
		
		return mblResInfo;

		 
	}
	
	/**
     * <p> 운영계용 처리process </p>
     * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
     * @return MblStlmResInfo  mblResInfo  처리결과 DO
     * @throws ApplicationException
     */
	private MblStlmResInfo callAprvReal(MblStlmReqInfo mblReqInfo) throws ApplicationException {
		
		logger.debug("로그 : 운영계용(callAprvReal) 시작");
		EISResponse < COM_F_MOBOSMOMO00001Out > response = null;
		COM_F_MOBOSMOMO00001In request             = null;
		COM_F_MOBOSMOMO00001Out responseData = null;
		MblStlmResInfo mblResInfo      = null;
			
		try {
			
			String interfaceID ="COM_F_MOBOSMOMO00001";//인터페이스 아이디
			
			 //전문관련 로그는 대외계에서 테이블로 관리함
			String newMblTrsfTxNo = "";
			
			// 모바일이체거래번호 조회
			newMblTrsfTxNo =  this.getNewMblTrsfTxNo();
			
			logger.debug("crdcdMgntNo {}",newMblTrsfTxNo);
			 
		    mblReqInfo.setMblTrsfTxNo(newMblTrsfTxNo);                     //모바일이체거래번호
		    
		    logger.debug("----------mblReqInfo---------" + mblReqInfo);
			//1.송신데이타 셋팅
			request  = this.getMblStmlAprvReqInfo(mblReqInfo);
			
			logger.debug("request:{}",request);
			logger.debug("toString of request:{}",request.toString());
			logger.debug("toBytes of request:{}",new String(FwUtil.toBytes(request)));
			
			// TODO. 운영에서 테스트 후 정상인 경우 if문 해제(홍선원D:102 테스트 가능)
			//2.송신전 전문로그 저장
			cmb020dbio.insertOneTBCMRTM016a(this.getTbcmrtm016Io(mblReqInfo));
			
			
			//3.동기화 방식 송신
			response= InfUtil.callFEP(request, interfaceID,COM_F_MOBOSMOMO00001Out.class);

			logger.debug("response---> {}",response);

			responseData = response.getResponseData();
			
			logger.debug("responseData---> {}",responseData);
			
			String mode = LApplicationContext.getSystemMode();	
			
			if ("R".equals(mode)) {
				//4.모바일이체 수신 결과 데이타 변환
				mblResInfo = this.getMblAprvRes(responseData,request.getMpno(),RTCont.REAL_MODE);
			} else {
				//4.모바일이체 수신 결과 데이타 변환
				mblResInfo = this.getMblAprvRes(responseData,request.getMpno(),RTCont.TEST_MODE);
			}
			
			mblResInfo.setMblTrsfTxNo(newMblTrsfTxNo);
			
			// TODO. 운영에서 테스트 후 정상인 경우 if문 해제(홍선원D:102 테스트 가능)
			
			//5.송신후 전문로그 저장
			cmb020dbio.updateOneTBCMRTM016a(this.getTbcmrtm016Io(mblResInfo));
				
			
		} catch ( EisExecutionException e) {
			
            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");			
			
			throw new ApplicationException("APCME0053", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});

		} catch ( NotSupportedEISException e) {

            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");		
			throw new ApplicationException("APCME0053", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});
		}

		return mblResInfo;
		
	}
	
	/**
	 * <p> 모바일송신 DO  변환</p>
	 * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
	 * @return NBZB40SVC00In  : 처리결과 OMM(any link 결과값)
	 * @throws ApplicationException
	 */
	private COM_F_MOBOSMOMO00001In getMblStmlAprvReqInfo(MblStlmReqInfo input)  throws ApplicationException  {


		COM_F_MOBOSMOMO00001In request = new COM_F_MOBOSMOMO00001In();
		
		String membMpno =  "";
		String membRrno =  "";
		
		String mode = LApplicationContext.getSystemMode();
		
//		if("R".equals(mode) ) {
//			membMpno = McashSeed.encodeString(input.getMembMpno(), "0805007608050076".getBytes());
//			membRrno = McashSeed.encodeString(input.getMembRrno(), "0805007608050076".getBytes());
//		}
//		else {
//			//2016.08.11;현승훈 테스트			
////			membMpno =  McashSeed.encodeString("01077253623", "0805007608050076".getBytes());
////			membRrno =  McashSeed.encodeString("7304201", "0805007608050076".getBytes());
//			membMpno =  McashSeed.encodeString("01074490230", "0805007608050076".getBytes());
//			membRrno =  McashSeed.encodeString("8101301", "0805007608050076".getBytes());
//		}
		
		logger.debug("   membMpno  ===" + input.getMembMpno() + "==="   );
		logger.debug("   membRrno  ===" + input.getMembRrno() + "==="   );
		
		membMpno = McashSeed.encodeString(input.getMembMpno().trim(), "0805007608050076".getBytes());
		membRrno = McashSeed.encodeString(input.getMembRrno().trim(), "0805007608050076".getBytes());
		
		logger.debug("   membMpno  " + membMpno    );
		logger.debug("   membRrno  " + membRrno    );
		
		String trsfAmt =  McashSeed.encodeString(input.getTrsfAmt().toString(), "0805007608050076".getBytes());
		
		logger.debug("   trsfAmt  " + trsfAmt    );
		String prdcd = "LINA KOREA";
		//공통부 셋팅
		request.setVerNo("B000");									// 1.버전번호
		request.setPwdDvsn("1");                                    // 2.암호구분
		request.setPwdSeq("0");            							// 3.암호순번
		request.setCashDvsn(RTCont.CASH_DVSN);						// 4.캐쉬구분
		request.setReqTyp(RTCont.REQ_TYP_AUT_STLM);					// 5.요청유형			
		request.setSiteNm("LINA KOREA");						// 6.사이트명
		request.setMblasIssueSvcId("080500760001");				// 7.모빌리언스발금서비스아이디
		//request.setMcc(input.getTelDcd());							// 8.이통사
		if("1".equals(input.getTelDcd())) {			 
			request.setMcc("SKT");							// 8.이통사명
		} else if("2".equals(input.getTelDcd())) {
			request.setMcc("KTF");// set [전화구분코드]
		} else if("3".equals(input.getTelDcd())) {
			request.setMcc("LGT");// set [전화구분코드]
		} else if("8".equals(input.getTelDcd())) {
			request.setMcc("KCT");// set [전화구분코드]
		} else {
			request.setMcc("CJH");// set [전화구분코드]
		}		
		
		request.setMpno(membMpno.concat(StringUtils.lpad("", 32 - membMpno.length(), " ")));						// 9.휴대전화번호 
		request.setMembRrno(membRrno.concat(StringUtils.lpad("", 32 - membRrno.length(), " ")));					// 10.가입자주민번호
		request.setStorTxNo(input.getMblTrsfTxNo());					// 11.상점거래번호(모마일이체거래번호)
		request.setProdCd(StringUtils.lpad("", 40, " "));						// 12.상품코드
		request.setProdNm(prdcd.concat(StringUtils.lpad("", 50 - prdcd.length(), " ")));						// 13.상품명
		request.setProdAmt(StringUtils.lpad("", 32 - trsfAmt.length(), "0").concat(trsfAmt));	// 14.거래금액
		request.setUsrId(StringUtils.lpad("", 20, " "));			// 15.사용자ID
		request.setUsrRrno(StringUtils.lpad("", 32, " "));			// 16.상요자주민번호
		request.setSpcfcPurpsReqOptn(StringUtils.lpad("", 30, " "));// 17.즉수목적 요청옵션 
		request.setUsrEmail(StringUtils.lpad("", 50, " "));			// 18.사용자이메일
		request.setUsrIp(StringUtils.lpad("", 20, " "));			// 19.사용자IP
		request.setTm1UsrChtsNo(StringUtils.lpad("", 15, " "));		// 20.1회 사용자고유번호
		request.setSmsCrtfNo(StringUtils.lpad("", 6, " "));			// 21.SMS인증번호
		request.setEmailSndYn("N");									// 22.이메일발송여부
		request.setCrtfNoSndMthd("S");								// 23.인증번호발송수단
		request.setLrnkAclSiteMgntCd(StringUtils.lpad("", 20, " "));// 24.하위 실사이트 관리코드
		request.setMltXcUse(StringUtils.lpad("", 8, " "));			// 25.멀티정산사용
		request.setMblasTxNo(StringUtils.lpad("", 15, " "));		// 26.모빌리언스거래번호
		request.setAclSelrNm(StringUtils.lpad("", 50, " "));		// 27.실판매자명
		request.setAclSelrCtadr(StringUtils.lpad("", 15, " "));		// 28.실판매자전화번호
		request.setRelxStlmPswd(StringUtils.lpad("", 32, " "));		// 29.안심결제 비밀번호
		//request.setCarrPinAdptYn(input.getCarrPinAdptYn());			// 30.SKT캐리어핀적용여부
		request.setCarrPinAdptYn("N");			// 30.SKT캐리어핀적용여부
		request.setCarrPin(StringUtils.lpad("", 32, " "));			// 31.캐리어핀
		//request.setAutoStlmAdptDvsn(input.getAutoStlmAdptDcd());	// 32.자동결제적용구분
		request.setAutoStlmAdptDvsn("2");	// 32.자동결제적용구분
		request.setAutoStlmFstRegKey(StringUtils.lpad("", 15, " "));// 33.자동결제최초등록KEY
		request.setAutoStlmRegBaseDy(StringUtils.lpad("", 8, " "));	// 34.자동결제등록기준일
		request.setPprn(StringUtils.lpad("", 147, " "));			// 35.공백
		
		return request;
	}
	
	
	/**
	 * 모바일이체거래번호 채번	 * 
	 * @return String newMblTrsfTxNo
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String getNewMblTrsfTxNo	() throws ApplicationException {
		
		String     newMblTrsfTxNo     		= "";				// 채번번호
		
		//그룹코드, 채번년도로 일련번호 조회.
		newMblTrsfTxNo =  this.cmb020dbio.selectOneTBCMRTM016();
		
		return newMblTrsfTxNo;

	}
	
	/**
	 * <p> 모바일이체원장, DO  변환</p>
	 * @param CardAprvReqInfo input  입력데이터
	 * @return TBCNETC016Io Tbcmrtm016  : 처리결과
	 * @throws ApplicationException
	 */
	private TBCMRTM016Io getTbcmrtm016Io (MblStlmReqInfo input)  throws ApplicationException  {

		TBCMRTM016Io Tbcmrtm016 = new TBCMRTM016Io();
		
		
		
		Tbcmrtm016.setMblTrsfTxNo(input.getMblTrsfTxNo());			// set [모바일이체거래번호(PK)]
		Tbcmrtm016.setMblBzDcd(RTCont.REQ_TYP_AUT_STLM);			// set [모바일업무구분코드]
		Tbcmrtm016.setTrsfDt(input.getTrsfDt());					// set [이체일자]
		
		if(StringUtils.isEmpty(input.getTrsfDofOrgNo())) {
			Tbcmrtm016.setTrsfDofOrgNo(FwUtil.getDeptCd());			// set [이체지점조직번호]	
		}else{
			Tbcmrtm016.setTrsfDofOrgNo(input.getTrsfDofOrgNo());	// set [이체지점조직번호]
		}
		
		if(StringUtils.isEmpty(input.getTrsfFofOrgNo())) {
			Tbcmrtm016.setTrsfFofOrgNo(FwUtil.getDeptCd());			// set [이체영업소조직번호]	
		}else{
			Tbcmrtm016.setTrsfFofOrgNo(input.getTrsfFofOrgNo());	// set [이체영업소조직번호]
		}
		
		if(StringUtils.isEmpty(input.getTrsfPrcsEno())) {
			Tbcmrtm016.setTrsfPrcsEno(FwUtil.getUserId());			// set [이체처리사원번호]
		}else{
			Tbcmrtm016.setTrsfPrcsEno(input.getTrsfPrcsEno());		// set [이체영업소조직번호]
		}
		
		Tbcmrtm016.setMembMpno(SecuUtil.getEncValue(input.getMembMpno(), EncType.membMpno));				// set [가입자휴대전화번호]
		Tbcmrtm016.setMccDcd(input.getTelDcd());					// set [전화구분코드]
		Tbcmrtm016.setTrsfAmt(input.getTrsfAmt());					// set [이체금액]
		Tbcmrtm016.setMembRrno(input.getMembRrno());				// set [가입자주민번호]
		Tbcmrtm016.setMblTgmNo("");									// set [모바일전문번호]
		Tbcmrtm016.setMblCrtfNo("");								// set [모바일인증번호]
		Tbcmrtm016.setSmsCrtfNo("");								// set [SMS인증번호]
		Tbcmrtm016.setCarrPinAdptYn("N");							// set [캐리어핀적용구분]
		Tbcmrtm016.setAutoStlmAdptDcd("2");							// set [자동결제적용구분코드]
		Tbcmrtm016.setMblTrsfRcd("");								// set [모바일이체결과코드]
		Tbcmrtm016.setMblTrsfRstMsgCtnt("");						// set [모바일이체결과메시지내용]
		Tbcmrtm016.setMblasTxNo("");								// set [모빌리언스거래번호]
		Tbcmrtm016.setRmnLmtAmt(BigDecimal.ZERO);					// set [잔여한도금액]
		Tbcmrtm016.setPrcsDtm("");									// set [처리일시]-모빌리언스리턴값
		Tbcmrtm016.setReprdRskMphonYn("");							// set [복제위험유대전화여부]
		Tbcmrtm016.setCrtfWayCd("");								// set [인증방식코드]
		Tbcmrtm016.setPyrcTxRfNoDcd(input.getPyrcTxRfNoDcd());		// set [출수납거래참조번호구분코드]
		Tbcmrtm016.setPyrcTxRfNo(input.getPyrcTxRfNo());			// set [출수납거래참조번호]
		Tbcmrtm016.setDelYn("N");									// set [삭제여부]
		Tbcmrtm016.setLastChgrId(FwUtil.getUserId());				// 최종변경자ID(LAST_CHGR_ID) 설정
		Tbcmrtm016.setLastChgPgmId(FwUtil.getPgmId());				// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		Tbcmrtm016.setLastChgTrmNo(FwUtil.getTrmNo());				// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		
		return Tbcmrtm016;
	}
	
	/**
	 * <p> 모바일수신 DO  변환</p>
	 * @param COM_F_MOBOS000000001Out  output 입력데이터
	 * @param String  mode 개발/운영
	 * @return CardAprvResInfo   모바일결과 DO
	 * @throws ApplicationException
	 */
	private MblStlmResInfo getMblAprvRes(COM_F_MOBOSMOMO00001Out output,String mpno,String mode)   throws ApplicationException {

		MblStlmResInfo response = new MblStlmResInfo();
		
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		// 처리시간 (자동이체처리 호출(OMM) 세팅용)
//		String prcsHms = currentDate.format(toDay).toString().substring(0).replace(":", "").replace(" ", "");
		String prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
//		String todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
		String todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

		String currentMin = todayHms.substring(2, 4);		
		String startMin = "00";
		String endMin = "31";
		
		BigDecimal zero = BigDecimal.ZERO;

		if (RTCont.TEST_MODE.equals(mode)) {

			if("01011111111".equals(mpno) ) {

				response.setMblTrsfRcd("0007");                          //결과코드
				response.setMblTrsfRstMsgCtnt("해지된 전화번호 입니다.");                  //결과메시지
				response.setMblasTxNo("111111111");		 				//모빌리언스거래번호		
				response.setPrcsDtm(prcsHms);						 	//처리일시				
				if (output.getRmnLmtAmt() == null || output.getRmnLmtAmt().compareTo(zero) == 0 ) {
					response.setRmnLmtAmt(zero);					//잔여한도
				}
				else
				{
					response.setRmnLmtAmt(output.getRmnLmtAmt());					//잔여한도
				}
				response.setReprdRskMphonYn(output.getReprdRskMphonYn());			//복제휴대전화번호여부
				response.setCrtfWayCd(output.getCrtfWay());							//인증방식
				
			} else if ("01022222222".equals(mpno)) {
				
				
				response.setMblTrsfRcd("0031");                          //결과코드
				response.setMblTrsfRstMsgCtnt("한도초과.");                  //결과메시지
				response.setMblasTxNo("22222222");		 				//모빌리언스거래번호		
				response.setPrcsDtm(prcsHms);						 	//처리일시
				if (output.getRmnLmtAmt() == null || output.getRmnLmtAmt().compareTo(zero) == 0 ) {
					response.setRmnLmtAmt(zero);					//잔여한도
				}
				else
				{
					response.setRmnLmtAmt(output.getRmnLmtAmt());					//잔여한도
				}
				response.setReprdRskMphonYn(output.getReprdRskMphonYn());			//복제휴대전화번호여부
				response.setCrtfWayCd(output.getCrtfWay());							//인증방식
				
			} else {
				
				if (Integer.parseInt(today) < Integer.parseInt("20170413")) {
					response.setMblTrsfRcd("0000");                          //결과코드
					response.setMblTrsfRstMsgCtnt("정상처리되었습니다.");                  //결과메시지
					response.setMblasTxNo("9999999999");		 				//모빌리언스거래번호		
					response.setPrcsDtm(prcsHms);						 	//처리일시
					if (output.getRmnLmtAmt() == null || output.getRmnLmtAmt().compareTo(zero) == 0 ) {
						response.setRmnLmtAmt(zero);					//잔여한도
					}
					else
					{
						response.setRmnLmtAmt(output.getRmnLmtAmt());					//잔여한도
					}
					response.setReprdRskMphonYn(output.getReprdRskMphonYn());			//복제휴대전화번호여부
					response.setCrtfWayCd(output.getCrtfWay());							//인증방식
				} else {
					response.setMblTrsfRcd(output.getMblTrsfRcd());                          //결과코드
					response.setMblTrsfRstMsgCtnt(output.getMblTrsfRstMsgCtnt());                  //결과메시지
					response.setMblasTxNo(output.getMblasTxNo());		 				//모빌리언스거래번호		
					response.setPrcsDtm(output.getPrcsDtm());						 	//처리일시
					response.setRmnLmtAmt(output.getRmnLmtAmt());						//잔여한도
					response.setReprdRskMphonYn(output.getReprdRskMphonYn());			//복제휴대전화번호여부
					response.setCrtfWayCd(output.getCrtfWay());							//인증방식
				}
			}
		      			

		} else {

			//2016.10.08;현승훈;테스트를위해 정상처리;원복예정
			
			if (Integer.parseInt(today) < Integer.parseInt("20170201")) {
				if (Integer.parseInt(today) < Integer.parseInt("20170101")) {
					if ("20161219".equals(today) || "20161220".equals(today)) {
						response.setMblTrsfRcd("0000");                          //결과코드
						response.setMblTrsfRstMsgCtnt("정상");                  //결과메시지
						response.setMblasTxNo("99"+DateUtils.getCurrentTime(6));		 				//모빌리언스거래번호		
						response.setPrcsDtm(output.getPrcsDtm());						 	//처리일시
						response.setRmnLmtAmt(output.getRmnLmtAmt());						//잔여한도
						response.setReprdRskMphonYn("");			//복제휴대전화번호여부
						response.setCrtfWayCd("");							//인증방식
					} else {
						if ( Integer.parseInt(currentMin) > Integer.parseInt(startMin) &&
								Integer.parseInt(currentMin) < Integer.parseInt(endMin) ) {
							response.setMblTrsfRcd(output.getMblTrsfRcd());                          //결과코드
							response.setMblTrsfRstMsgCtnt(output.getMblTrsfRstMsgCtnt());                  //결과메시지
							response.setMblasTxNo(output.getMblasTxNo());		 				//모빌리언스거래번호		
							response.setPrcsDtm(output.getPrcsDtm());						 	//처리일시
							response.setRmnLmtAmt(output.getRmnLmtAmt());						//잔여한도
							response.setReprdRskMphonYn(output.getReprdRskMphonYn());			//복제휴대전화번호여부
							response.setCrtfWayCd(output.getCrtfWay());							//인증방식
							
						} else {
							response.setMblTrsfRcd("0000");                          //결과코드
							response.setMblTrsfRstMsgCtnt("정상");                  //결과메시지
							response.setMblasTxNo("99"+DateUtils.getCurrentTime(6));		 				//모빌리언스거래번호		
							response.setPrcsDtm(output.getPrcsDtm());						 	//처리일시
							response.setRmnLmtAmt(output.getRmnLmtAmt());						//잔여한도
							response.setReprdRskMphonYn("");			//복제휴대전화번호여부
							response.setCrtfWayCd("");							//인증방식
						}
					}
					
				} else {
					response.setMblTrsfRcd("0000");                          //결과코드
					response.setMblTrsfRstMsgCtnt("정상");                  //결과메시지
					response.setMblasTxNo("99"+DateUtils.getCurrentTime(6));		 				//모빌리언스거래번호		
					response.setPrcsDtm(output.getPrcsDtm());						 	//처리일시
					response.setRmnLmtAmt(output.getRmnLmtAmt());						//잔여한도
					response.setReprdRskMphonYn("");			//복제휴대전화번호여부
					response.setCrtfWayCd("");							//인증방식
				}
			} else  {
				response.setMblTrsfRcd(output.getMblTrsfRcd());                          //결과코드
				response.setMblTrsfRstMsgCtnt(output.getMblTrsfRstMsgCtnt());                  //결과메시지
				response.setMblasTxNo(output.getMblasTxNo());		 				//모빌리언스거래번호		
				response.setPrcsDtm(output.getPrcsDtm());						 	//처리일시
				response.setRmnLmtAmt(output.getRmnLmtAmt());						//잔여한도
				response.setReprdRskMphonYn(output.getReprdRskMphonYn());			//복제휴대전화번호여부
				response.setCrtfWayCd(output.getCrtfWay());							//인증방식
			}
			
			/*===============================================
			response.setMblTrsfRcd(output.getMblTrsfRcd());                          //결과코드
			response.setMblTrsfRstMsgCtnt(output.getMblTrsfRstMsgCtnt());                  //결과메시지
			response.setMblasTxNo(output.getMblasTxNo());		 				//모빌리언스거래번호		
			response.setPrcsDtm(output.getPrcsDtm());						 	//처리일시
			response.setRmnLmtAmt(output.getRmnLmtAmt());						//잔여한도
			response.setReprdRskMphonYn(output.getReprdRskMphonYn());			//복제휴대전화번호여부
			response.setCrtfWayCd(output.getCrtfWay());							//인증방식
			===============================================*/
			
//			//2016.10.08;현승훈;테스트를 위해 정상처리:나중에삭제
//			//===============================================
//			response.setMblTrsfRcd("0000");                          //결과코드
//			response.setMblTrsfRstMsgCtnt("정상");                  //결과메시지
//			response.setMblasTxNo("99"+DateUtils.getCurrentTime(6));		 				//모빌리언스거래번호		
//			response.setPrcsDtm(output.getPrcsDtm());						 	//처리일시
//			response.setRmnLmtAmt(output.getRmnLmtAmt());						//잔여한도
//			response.setReprdRskMphonYn("");			//복제휴대전화번호여부
//			response.setCrtfWayCd("");							//인증방식
			//===============================================

		}


		return response;
	}
	
	/**
	 * <p> 모바일 결제후 전문로그, DO  변환</p>
	 * @param MblStlmResInfo input  입력데이터
	 * @return  TBCMRTM016Io tbcmrtm016  : 처리결과
	 * @throws ApplicationException
	 */
	private TBCMRTM016Io getTbcmrtm016Io (MblStlmResInfo input)  throws ApplicationException  {

		TBCMRTM016Io tbcmrtm016 = new TBCMRTM016Io();
		BigDecimal zero = BigDecimal.ZERO;
		
		
		tbcmrtm016.setMblTrsfTxNo(input.getMblTrsfTxNo());	        	//모바일이체거래번호(KEY)
		tbcmrtm016.setMblBzDcd(RTCont.REQ_TYP_AUT_STLM);				//모바일업무구분코드(KEY)
		tbcmrtm016.setMblTrsfRcd(StringUtils.nvl(input.getMblTrsfRcd()));                //결과코드
		tbcmrtm016.setMblTrsfRstMsgCtnt(StringUtils.nvl(input.getMblTrsfRstMsgCtnt()));  //결과메시지
		tbcmrtm016.setMblasTxNo(input.getMblasTxNo());		 			//모빌리언스거래번호		
		tbcmrtm016.setPrcsDtm(input.getPrcsDtm());						//처리일시
		if (input.getRmnLmtAmt() == null || input.getRmnLmtAmt().compareTo(zero) == 0 ) {
			tbcmrtm016.setRmnLmtAmt(zero);					//잔여한도
		}
		else
		{
			tbcmrtm016.setRmnLmtAmt(input.getRmnLmtAmt());					//잔여한도
		}		
		tbcmrtm016.setReprdRskMphonYn(input.getReprdRskMphonYn());		//복제휴대전화번호여부
		tbcmrtm016.setCrtfWayCd(input.getCrtfWayCd());					//인증방식
		
		
		tbcmrtm016.setLastChgrId(FwUtil.getUserId());		// set [최종변경자ID]
		tbcmrtm016.setLastChgPgmId(FwUtil.getPgmId());	// set [최종변경프로그램ID]
		tbcmrtm016.setLastChgTrmNo(FwUtil.getTrmNo());	// set [최종변경단말번호]
		
		logger.debug("============================== update 전  ==============================");
		
		logger.debug("tbcmrtm016],{}", tbcmrtm016);
		
		return tbcmrtm016;
	}	
	
	
	/**
     * <p> 모바일 결제 취소</p>
     * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
     * @return MblStlmResInfo  mblResInfo  처리결과 DO
     * @throws ApplicationException
     */
	public MblStlmResInfo setMblStlmCncl(MblStlmReqInfo mblReqInfo, String mblasTxNo) throws ApplicationException {



		if (mblReqInfo == null) {
			throw new ApplicationException("APNBE0058", null);
		}

		MblStlmResInfo mblResInfo  = null;
 
        // 정합성 체크
		 this.chkMblStlmCncl(mblReqInfo, mblasTxNo);

		 String testDay		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		 
		 String mode = LApplicationContext.getSystemMode();	 
		 logger.debug("mode{}",mode);
		 logger.debug("=========== setMblStlmCncl MembMpno ============== {}",mblReqInfo.getMembMpno());
		 
		 //운영계
		 //2016.10.08
		 //2016.12.23;현승훈 : RTM
		 //2017.04.11;현승훈;RTM
		 if("D".equals(mode) || "R".equals(mode)) {
		 //if("R".equals(mode) || ( "D".equals(mode) && TEST_MBL_NO.indexOf((SecuUtil.getDecValue(mblReqInfo.getMembMpno(), EncType.membRrno) )) >= 0 )) {
		 //if("R".equals(mode) || "D".equals(mode)) {
  		 //2016.09.12;운영계에서 FEP시뮬레이터 환경 더이상 호출하지 않도록 처리(시뮬레이터 환경이 불안정)
		 //if( "D".equals(mode) ) {
			  //개발
			  if (Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
				  mblResInfo = this.callAprvCnclDev(mblReqInfo, mblasTxNo);
			  //실제 모빌리언스 연동
			  } else {
				  mblResInfo= this.callAprvCnclReal(mblReqInfo, mblasTxNo);
			  }			  		  
		 //개발,테스트	  
		 } else if("T".equals(mode) ) {
		 //} else if("T".equals(mode)) {
		//2016.09.12;운영계에서 FEP시뮬레이터 환경 더이상 호출하지 않도록 처리(시뮬레이터 환경이 불안정)
		 //} else if("R".equals(mode) || "T".equals(mode)) {
		    
			//cardResInfo= this.callAprvReal(cardReqInfo);  //---> 애니링크 확인할 때
			  mblResInfo = this.callAprvCnclDev(mblReqInfo, mblasTxNo);
			 
		  } 

	    return mblResInfo;

	}
	
	/**
	 * <p> 모바일결제취소 입력값  확인</p>
	 * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
	 * @throws ApplicationException
	 */
	private void chkMblStlmCncl ( MblStlmReqInfo input, String mblasTxNo ) throws ApplicationException {

		//String trxDt  = DateUtils.getCurrentDate(2);//처리일자
		BigDecimal zero = BigDecimal.ZERO;

		if(StringUtils.isEmpty(input.getMembMpno())) {

	        logger.debug("휴대전화번호를 입력하지 않았습니다.");
	        throw new ApplicationException("APPRE0000", new Object[]{"휴대전화번호"}, new Object[]{"휴대전화번호"});

		}

		if(StringUtils.isEmpty(input.getTelDcd())) {

	        logger.debug("이동동신사를 입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"이동동신사이동동신사를"}, new Object[]{"이동동신사"});
		}
		
		if(StringUtils.isEmpty(input.getMembRrno())) {

	        logger.debug("주민등록번호를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"주민등록번호"}, new Object[]{"주민등록번호"});
		}

		if (input.getTrsfAmt() == null || input.getTrsfAmt().compareTo(zero) == 0 ) {

	        logger.debug("이체금액을  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"이체금액"}, new Object[]{"이체금액"});

		}

		if (StringUtils.isEmpty(mblasTxNo)) {

	        logger.debug("모빌리언스 거래번호를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"모빌리언스 거래번호"}, new Object[]{"모빌리언스 거래번호"});

		}
	}
	
	/**
     * <p> 개발/검증계용 취소 처리process </p>
     * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
     * @return MblStlmResInfo  mblResInfo  처리결과 DO
     * @throws ApplicationException
     */
	private MblStlmResInfo callAprvCnclDev(MblStlmReqInfo mblReqInfo, String mblasTxNo) throws ApplicationException {
		logger.debug("로그 : 개발/검증계용(callAprvDev) 시작");

		COM_F_MOBOSMOMC00001In request             = null;
		COM_F_MOBOSMOMC00001In responseData = null;
		MblStlmResInfo mblResInfo      = null;
		
		try {
			
//			 //전문관련 로그는 대외계에서 테이블로 관리함
			String newMblTrsfTxNo = "";
			
			// 모바일이체거래번호 조회
			newMblTrsfTxNo =  this.getNewMblTrsfTxNo();
			
			logger.debug("crdcdMgntNo {}",newMblTrsfTxNo);
			 
		    mblReqInfo.setMblTrsfTxNo(newMblTrsfTxNo);                     //모바일이체거래번호
		 
		    //1.모바일 결제 송신 데이타 변환
			request = this.getMblStmlAprvCnclReqInfo(mblReqInfo, mblasTxNo);
			logger.debug("request {}",request);
			logger.debug("length of request:{}",request.toString().length());
			
			//2.송신전 전문로그 저장				
			cmb020dbio.insertOneTBCMRTM016a(this.getCnclTbcmrtm016Io(mblReqInfo));
			
	       //3.테스트를 위해 van사 호출하지 않음
			responseData = new COM_F_MOBOSMOMC00001In();
			responseData.setStorTxNo(request.getStorTxNo());//송신때 상점거래번호

			//4.모바일 결제 수신 데이타 변환
			mblResInfo = this.getMblAprvCnclRes(responseData, mblReqInfo.getMembMpno(),RTCont.TEST_MODE);

			mblResInfo.setMblTrsfTxNo(newMblTrsfTxNo);
			
			 logger.debug("cardResInfo {}",mblResInfo);
			
			//5.송신후 전문로그 저장
			 cmb020dbio.updateOneTBCMRTM016a(this.getCnclTbcmrtm016Io(mblResInfo, "111111"));
			 
			
		} catch (ApplicationException ae) {
			
			throw ae;
		}
		
		return mblResInfo;

		 
	}
	
	/**
	 * <p> 모바일송신 DO  변환</p>
	 * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
	 * @return NBZB40SVC00In  : 처리결과 OMM(any link 결과값)
	 * @throws ApplicationException
	 */
	private COM_F_MOBOSMOMC00001In getMblStmlAprvCnclReqInfo(MblStlmReqInfo input, String mblasTxNo)  throws ApplicationException  {


		COM_F_MOBOSMOMC00001In request = new COM_F_MOBOSMOMC00001In();
		
		BigDecimal trsfAmt 	= input.getTrsfAmt();					// 거래금액
		
		
		logger.debug("====== getMblStmlAprvCnclReqInfo ======  {} " + input);
		
		//공통부 셋팅
		request.setStorNo("08050076");							// 1.상점번호
		request.setMblasIssueSvcId("080500760001");					// 2.모빌리언스발금서비스아이디
		request.setStorTxNo(input.getMblTrsfTxNo().concat(StringUtils.lpad("", 40 - input.getMblTrsfTxNo().length(), " ")));// 3.상점거래번호(모마일이체거래번호)		
		request.setProdAmt(trsfAmt.toString().concat(StringUtils.lpad("", 10 - trsfAmt.toString().length(), " ")));// 4.거래금액
		request.setMblasTxNo(mblasTxNo);							// 5.모빌리언스거래번호		
		request.setRcd("9999");										// 6.모빌리언스거래번호
		
		return request;
	}
	
	/**
	 * <p> 모바일취소수신 DO  변환</p>
	 * @param COM_F_MOBOS000000001Out  output 입력데이터
	 * @param String  mode 개발/운영
	 * @return CardAprvResInfo   모바일결과 DO
	 * @throws ApplicationException
	 */
	private MblStlmResInfo getMblAprvCnclRes(COM_F_MOBOSMOMC00001In output,String mpno,String mode)   throws ApplicationException {

		MblStlmResInfo response = new MblStlmResInfo();
		
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
		// 처리시간 (자동이체처리 호출(OMM) 세팅용)
//		String prcsHms = currentDate.format(toDay).toString().substring(0).replace(":", "").replace(" ", "");
		
		String prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		
		// 오늘일자 : YYYYMMDDHHMISS
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
//		String todayHms = currentDate.format(toDay).toString().substring(9).replace(":", "");
		String todayHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

		String currentMin = todayHms.substring(2, 4);		
		String startMin = "00";
		String endMin = "31";
		
		BigDecimal zero = BigDecimal.ZERO;

		if (RTCont.TEST_MODE.equals(mode)) {

			if("01011111111".equals(mpno) ) {

				response.setMblTrsfRcd("0007");                          //결과코드
				response.setMblTrsfRstMsgCtnt("해지된 전화번호 입니다.");                  //결과메시지
				response.setMblasTxNo("111111111");		 				//모빌리언스거래번호		
				response.setPrcsDtm(prcsHms);						 	//처리일시				
				
				
			} else if ("01022222222".equals(mpno)) {
				
				
				response.setMblTrsfRcd("0031");                          //결과코드
				response.setMblTrsfRstMsgCtnt("한도초과.");                  //결과메시지
				response.setMblasTxNo("22222222");		 				//모빌리언스거래번호		
				response.setPrcsDtm(prcsHms);						 	//처리일시
				
				
			} else {
				
				String testDay		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
				
				if (Integer.parseInt(testDay) < Integer.parseInt("20170413")) {
					response.setMblTrsfRcd("0000");                          //결과코드
					response.setMblTrsfRstMsgCtnt("정상처리되었습니다.");                  //결과메시지
					response.setMblasTxNo("9999999999");		 				//모빌리언스거래번호		
					response.setPrcsDtm(prcsHms);						 	//처리일시
				} else {
					response.setMblTrsfRcd(output.getRcd());                          //결과코드
				}
			}
		      			

		} else {

			//2016.10.08;현승훈;테스트를위해 정상처리;나중에원복
			//response.setMblTrsfRcd(output.getRcd());                          //결과코드
			
			//2016.10.08;현승훈;테스트를위해 정상처리;나중에삭제예정
			//response.setMblTrsfRcd("0000");                          //결과코드
			
			if (Integer.parseInt(today) < Integer.parseInt("20170201")) {
				if (Integer.parseInt(today) < Integer.parseInt("20170101")) {
					if ("20161219".equals(today) || "20161220".equals(today)) {
						response.setMblTrsfRcd("0000");                          //결과코드
					} else {
						if ( Integer.parseInt(currentMin) > Integer.parseInt(startMin) &&
								Integer.parseInt(currentMin) < Integer.parseInt(endMin) ) {
							response.setMblTrsfRcd(output.getRcd());                          //결과코드
						} else {
							response.setMblTrsfRcd("0000");                          //결과코드
						}
					}					
				} else {
					response.setMblTrsfRcd("0000");                          //결과코드	
				}
			} else  {
				response.setMblTrsfRcd(output.getRcd());                          //결과코드
			}
			
		}

		return response;
	}
	
	
	/**
     * <p> 운영계용 처리process </p>
     * @param MblStlmReqInfo   mblReqInfo 모바일처리 DO
     * @return MblStlmResInfo  mblResInfo  처리결과 DO
     * @throws ApplicationException
     */
	private MblStlmResInfo callAprvCnclReal(MblStlmReqInfo mblReqInfo,String mblasTxNo) throws ApplicationException {
		
		logger.debug("로그 : 운영계용(callAprvReal) 시작");
		EISResponse < COM_F_MOBOSMOMC00001In > response = null;
		COM_F_MOBOSMOMC00001In request             = null;
		COM_F_MOBOSMOMC00001In responseData = null;
		MblStlmResInfo mblResInfo      = null;
			
		try {
			
			String interfaceID ="COM_F_MOBOSMOMC00001";//인터페이스 아이디
			
			 //전문관련 로그는 대외계에서 테이블로 관리함
			String newMblTrsfTxNo = "";
			
			// 모바일이체거래번호 조회
			newMblTrsfTxNo =  this.getNewMblTrsfTxNo();
			
			logger.debug("newMblTrsfTxNo {}",newMblTrsfTxNo);
			
			logger.debug("mblReqInfo {}",mblReqInfo);
		    
			//1.송신데이타 셋팅
			request  = this.getMblStmlAprvCnclReqInfo(mblReqInfo, mblasTxNo);
			
			
			mblReqInfo.setMblTrsfTxNo(newMblTrsfTxNo);                     //모바일이체거래번호
			
			logger.debug("request:{}",request);
			logger.debug("toString of request:{}",request.toString());
			logger.debug("toBytes of request:{}",new String(FwUtil.toBytes(request)));
			
			// TODO. 운영에서 테스트 후 정상인 경우 if문 해제(홍선원D:102 테스트 가능)
			//2.송신전 전문로그 저장
			cmb020dbio.insertOneTBCMRTM016a(this.getCnclTbcmrtm016Io(mblReqInfo));
			
			
			//3.동기화 방식 송신
			response= InfUtil.callFEP(request, interfaceID,COM_F_MOBOSMOMC00001In.class);

			logger.debug("response---> {}",response);

			responseData = response.getResponseData();
			
			logger.debug("responseData---> {}",responseData);
			

			String mode = LApplicationContext.getSystemMode();	
			
			if ("R".equals(mode)) {
				//4.모바일이체 수신 결과 데이타 변환
				mblResInfo = this.getMblAprvCnclRes(responseData,mblReqInfo.getMembMpno(),RTCont.REAL_MODE);
			} else {
				//4.모바일이체 수신 결과 데이타 변환
				mblResInfo = this.getMblAprvCnclRes(responseData,mblReqInfo.getMembMpno(),RTCont.TEST_MODE);
			}
			
			mblResInfo.setMblTrsfTxNo(newMblTrsfTxNo);
			
			// TODO. 운영에서 테스트 후 정상인 경우 if문 해제(홍선원D:102 테스트 가능)
			
			//5.송신후 전문로그 저장
			cmb020dbio.updateOneTBCMRTM016a(this.getCnclTbcmrtm016Io(mblResInfo, mblasTxNo));
				
			
		} catch ( EisExecutionException e) {
			
            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");			
			
			throw new ApplicationException("APCME0053", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});

		} catch ( NotSupportedEISException e) {

            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");		
			throw new ApplicationException("APCME0053", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});
		}

		return mblResInfo;
		
	}
	
	/**
	 * <p> 모바일이체원장, DO  변환</p>
	 * @param CardAprvReqInfo input  입력데이터
	 * @return TBCNETC016Io Tbcmrtm016  : 처리결과
	 * @throws ApplicationException
	 */
	private TBCMRTM016Io getCnclTbcmrtm016Io (MblStlmReqInfo input)  throws ApplicationException  {

		TBCMRTM016Io Tbcmrtm016 = new TBCMRTM016Io();
		
		
		
		Tbcmrtm016.setMblTrsfTxNo(input.getMblTrsfTxNo());			// set [모바일이체거래번호(PK)]
		Tbcmrtm016.setMblBzDcd(RTCont.REQ_TYP_STLM_CNCL);			// set [모바일업무구분코드]
		Tbcmrtm016.setTrsfDt(input.getTrsfDt());					// set [이체일자]
		
		if(StringUtils.isEmpty(input.getTrsfDofOrgNo())) {
			Tbcmrtm016.setTrsfDofOrgNo(FwUtil.getDeptCd());			// set [이체지점조직번호]	
		}else{
			Tbcmrtm016.setTrsfDofOrgNo(input.getTrsfDofOrgNo());	// set [이체지점조직번호]
		}
		
		if(StringUtils.isEmpty(input.getTrsfFofOrgNo())) {
			Tbcmrtm016.setTrsfFofOrgNo(FwUtil.getDeptCd());			// set [이체영업소조직번호]	
		}else{
			Tbcmrtm016.setTrsfFofOrgNo(input.getTrsfFofOrgNo());	// set [이체영업소조직번호]
		}
		
		if(StringUtils.isEmpty(input.getTrsfPrcsEno())) {
			Tbcmrtm016.setTrsfPrcsEno(FwUtil.getUserId());			// set [이체처리사원번호]
		}else{
			Tbcmrtm016.setTrsfPrcsEno(input.getTrsfPrcsEno());		// set [이체영업소조직번호]
		}
		
		Tbcmrtm016.setMembMpno(SecuUtil.getEncValue(input.getMembMpno(), EncType.membMpno));				// set [가입자휴대전화번호]
		Tbcmrtm016.setMccDcd(input.getTelDcd());					// set [전화구분코드]
		Tbcmrtm016.setTrsfAmt(input.getTrsfAmt());					// set [이체금액]
		Tbcmrtm016.setMembRrno(input.getMembRrno());				// set [가입자주민번호]
		Tbcmrtm016.setMblTgmNo("");									// set [모바일전문번호]
		Tbcmrtm016.setMblCrtfNo("");								// set [모바일인증번호]
		Tbcmrtm016.setSmsCrtfNo("");								// set [SMS인증번호]
		Tbcmrtm016.setCarrPinAdptYn(input.getCarrPinAdptYn());		// set [캐리어핀적용구분]
		Tbcmrtm016.setAutoStlmAdptDcd(input.getAutoStlmAdptDcd());	// set [자동결제적용구분코드]
		Tbcmrtm016.setMblTrsfRcd("");								// set [모바일이체결과코드]
		Tbcmrtm016.setMblTrsfRstMsgCtnt("");						// set [모바일이체결과메시지내용]
		Tbcmrtm016.setMblasTxNo("");								// set [모빌리언스거래번호]
		Tbcmrtm016.setRmnLmtAmt(BigDecimal.ZERO);					// set [잔여한도금액]
		Tbcmrtm016.setPrcsDtm("");									// set [처리일시]-모빌리언스리턴값
		Tbcmrtm016.setReprdRskMphonYn("");							// set [복제위험유대전화여부]
		Tbcmrtm016.setCrtfWayCd("");								// set [인증방식코드]
		Tbcmrtm016.setPyrcTxRfNoDcd(input.getPyrcTxRfNoDcd());		// set [출수납거래참조번호구분코드]
		Tbcmrtm016.setPyrcTxRfNo(input.getPyrcTxRfNo());			// set [출수납거래참조번호]
		Tbcmrtm016.setDelYn("N");									// set [삭제여부]
		Tbcmrtm016.setLastChgrId(FwUtil.getUserId());				// 최종변경자ID(LAST_CHGR_ID) 설정
		Tbcmrtm016.setLastChgPgmId(FwUtil.getPgmId());				// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		Tbcmrtm016.setLastChgTrmNo(FwUtil.getTrmNo());				// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		
		return Tbcmrtm016;
	}
	
	/**
	 * <p> 모바일 결제후 전문로그, DO  변환</p>
	 * @param MblStlmResInfo input  입력데이터
	 * @return  TBCMRTM016Io tbcmrtm016  : 처리결과
	 * @throws ApplicationException
	 */
	private TBCMRTM016Io getCnclTbcmrtm016Io (MblStlmResInfo input, String mblasTxNo)  throws ApplicationException  {

		TBCMRTM016Io tbcmrtm016 = new TBCMRTM016Io();
		BigDecimal zero = BigDecimal.ZERO;
		
//		Date toDay = new Date();
//		SimpleDateFormat currentDate = null;
//		currentDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss", Locale.KOREA);
		
//		String prcsHms = currentDate.format(toDay).toString().substring(0).replace(":", "").replace(" ", "");
		String prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
		tbcmrtm016.setMblTrsfTxNo(input.getMblTrsfTxNo());	        	//모바일이체거래번호(KEY)
		tbcmrtm016.setMblBzDcd(RTCont.REQ_TYP_STLM_CNCL);				//모바일업무구분코드(KEY)
		tbcmrtm016.setMblTrsfRcd(StringUtils.nvl(input.getMblTrsfRcd()));                //결과코드
//		tbcmrtm016.setMblTrsfRstMsgCtnt(StringUtils.nvl(input.getMblTrsfRstMsgCtnt()));  //결과메시지
		tbcmrtm016.setMblasTxNo(mblasTxNo);		 						//모빌리언스거래번호(정상처리된 모빌리언스거래번호)		
		tbcmrtm016.setPrcsDtm(today + prcsHms);									//처리일시
//		if (input.getRmnLmtAmt() == null || input.getRmnLmtAmt().compareTo(zero) == 0 ) {
//			tbcmrtm016.setRmnLmtAmt(zero);					//잔여한도
//		}
//		else
//		{
//			tbcmrtm016.setRmnLmtAmt(input.getRmnLmtAmt());					//잔여한도
//		}		
//		tbcmrtm016.setReprdRskMphonYn(input.getReprdRskMphonYn());		//복제휴대전화번호여부
//		tbcmrtm016.setCrtfWayCd(input.getCrtfWayCd());					//인증방식
		
		
		tbcmrtm016.setLastChgrId(FwUtil.getUserId());		// set [최종변경자ID]
		tbcmrtm016.setLastChgPgmId(FwUtil.getPgmId());	// set [최종변경프로그램ID]
		tbcmrtm016.setLastChgTrmNo(FwUtil.getTrmNo());	// set [최종변경단말번호]
		
		logger.debug("============================== update 전  ==============================");
		
		logger.debug("tbcmrtm016],{}", tbcmrtm016);
		
		return tbcmrtm016;
	}	
}

