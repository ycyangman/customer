package cigna.cm.b.bean;

import java.util.Hashtable;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.inf.EisExecutionException;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB030DBIO;
import cigna.cm.b.io.STB_F_COMOSSTOA00001In;
import cigna.cm.b.io.STB_F_COMOSSTOA00002In;
import cigna.cm.b.io.STB_F_COMOSSTOA00006In;
import cigna.cm.b.io.SelectOneTBCMRTM013aOut;
import cigna.cm.b.io.TBCMRTM014Io;
import cigna.cm.b.io.TBDPEPY015Io;
import cigna.cm.b.io.TBDPEPY016Io;
import cigna.zz.BizDateInfo;
import cigna.zz.FwUtil;


/**
 * @file         cigna.cm.b.bean.CMB030BEAN.java
 * @filetype     java source file
 * @brief        가상계좌발급
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                          성명                                                일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 2. 15.      신규 작성
 *
 */
@KlafBean
public class CMB030BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/*****************************************
	 * 고객가상계좌 부여현황 조회 DBIO
	 *****************************************/
	@Autowired
	private CMB030DBIO	cmb030dbio;
	
	@Autowired
    private BizDateInfo      bizDateInfo; // 일자체크모듈
	
	
	/**
	 * 가상계좌식별번호 채번	
	 * @return String newMknoNo
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String getNewVactDscNo	() throws ApplicationException {
		
		String     newVactDscNo     		= "";				// 채번번호
		
		//그룹코드, 채번년도로 일련번호 조회.
		newVactDscNo =  this.cmb030dbio.selectOneTBCMRTM013();
		
		return newVactDscNo;

	}
		
//	/**
//	 * 가상계좌 수취인조회 처리
//	 * @param  DPA110SVC00In
//	 * @return DPA110SVC00Out
//	 * @throws ApplicationException
//	 */
//	@SuppressWarnings("unchecked")
//	public STB_F_COMOSSTOA00001In prcsVactRcpntTgmTrrv(STB_F_COMOSSTOA00001In input) throws ApplicationException , EisExecutionException{
//		Hashtable<String,Object>  oParam  =  null;
//		oParam = callPrcsVactRcpntTgmTrrv(input);
//		
//		input         =   (STB_F_COMOSSTOA00001In                   )  oParam.get("input");
//		
//		/*  2016.01.19;기존소스주석처리;현승훈
//		List <SelectMultiTBDPBAS007cOut>  bas007Out     =    null;
//		bas007Out     =   (List <SelectMultiTBDPBAS007cOut>)  oParam.get("bas007Out");
//
//		// 월대체 처리
//		if(bas007Out.size() > 0) {
//			replPrcs(bas007Out);
//		}
//		*/
//
//		return input;
//	}
//	
//	/**
//	 * 가상계좌 수신처리 처리
//	 * @param  DPA110SVC00In
//	 * @return DPA110SVC00Out
//	 * @throws ApplicationException
//	 */
//	@SuppressWarnings("unchecked")
//	public STB_F_COMOSSTOA00002In prcsVactTgmTrrv(STB_F_COMOSSTOA00002In input) throws ApplicationException , EisExecutionException{
//		Hashtable<String,Object>  oParam  =  null;
//		oParam = callPrcsVactTgmTrrv(input);
//
//		input         =   (STB_F_COMOSSTOA00002In                   )  oParam.get("input");
//		
//		/*  2016.01.19;기존소스주석처리;현승훈
//		List <SelectMultiTBDPBAS007cOut>  bas007Out     =    null;
//		bas007Out     =   (List <SelectMultiTBDPBAS007cOut>)  oParam.get("bas007Out");
//
//		// 월대체 처리
//		if(bas007Out.size() > 0) {
//			replPrcs(bas007Out);
//		}
//		*/
//
//		return input;
//	}
//	
//	/**
//	 * 가상계좌 수신처리 처리
//	 * @param  CMB030SVC00In
//	 * @return CMB030SVC00Out
//	 * @throws ApplicationException
//	 */
//	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW)
//	private Hashtable<String,Object> callPrcsVactRcpntTgmTrrv(STB_F_COMOSSTOA00001In input) throws ApplicationException , EisExecutionException{
//
//		logger.debug("mmj 가상계좌수신");
//		Hashtable<String,Object>  oParam  =  new  Hashtable<String,Object>();
//		oParam.put("input"      , input                                      );
//		//oParam.put("bas007Out"  , new ArrayList <SelectMultiTBDPBAS007cOut>());
//
//		// INPUT 값 체크
//		checkValRcpnt(input);
//		if(!"0000".equals(input.getAnswCd())) {
//			// 전문종별코드 변경
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//		
//		int iResult = 0;
//
//		// 가상계좌 발급테이블 조회
//		SelectOneTBCMRTM013aOut rtm013Out = null;
//
//		rtm013Out = cmb030dbio.selectOneTBCMRTM013a(input.getActNo());
//
//		if(rtm013Out == null) {
//			logger.error("가상계좌발급 조회중 오류발생.");
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			input.setAnswCd("V817");
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//
//		TBDPEPY016Io epy016Io  = null;
//		
//		// 고객가상계좌신청 테이블 조회
//		epy016Io  = cmb030dbio.selectOneTBDPEPY016b(input.getNwOpenBnkCd(), input.getActNo());
//
//		if(epy016Io == null) {
//			logger.error("고객가상계좌 신청내역이 존재하지 않음.");
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			input.setAnswCd("F008");
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//
////		// 가상계좌 전송시 사원번호로 헤더 정보 변경
////		ExtendedCignaSystemHeader header = FwUtil.getContextHeader();
////		header.setChrgpMpNo(epy016Io.getTrmsEno());
//		
//
//		// 가상계좌이체결과 테이블 빌드 처리
//		TBDPEPY015Io  epy015Io  = null;
//		
//		epy015Io  =  buildTbdpepy015(input,rtm013Out,epy016Io);
//		// 고객가상계좌일때 예금주명을 output으로 세팅
//		input.setAchdNm(FwUtil.substringKorean(epy015Io.getVactAchdNm(),20, "EUC-KR"));
//		
//		if(!"0000".equals(epy015Io.getVactTgmAnswCd())) {
//			input.setAnswCd(epy015Io.getVactTgmAnswCd());
//			// 전문종별코드 변경
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//
//		// 정상일때 로그 insert 처리
//		iResult  = insertTbcmrtm014(input);
//		
//		if(iResult != 1) {
//            logger.error("가상계좌수신 로그 INSERT 처리시 오류가 발생하였습니다.");
//            input.setAnswCd("V141");
//            // 전문종별코드 변경
// 			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
// 			input.setTxKcd(txKndCd);
// 			oParam.put("input"      , input                                      );
//         			
//            return oParam ;
//        }
//		
//		iResult = 0;
//
//		// 정상일때 가상계좌이체결과 테이블 insert 처리
//		if("1000,1001,3000,3001".contains(input.getTxKcd())) {
//			
//			iResult  = insertTbdpepy015(epy015Io);
//			
//			if(iResult != 1) {
//	            logger.error("가상계좌이체결과 테이블 INSERT 처리시 오류가 발생하였습니다.");
//	            input.setAnswCd("V141");
//	        }
//			
//		} else if("1010,3010".contains(input.getTxKcd())) {
//			
//			iResult  = updateTbdpepy015(epy015Io);
//			
//
//	        if(iResult != 1) {
//	            logger.error("가상계좌이체결과 테이블 UPDATE 처리시 오류가 발생하였습니다.");
//	            input.setAnswCd("V141");
//	        }
//		}
//		
//		if(!"0000".equals(input.getAnswCd())) {
//			// 전문종별코드 변경
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//		// 정상처리후 입금일경우 가상계좌입금기장처리 모듈 호출
////		if("DP".equals(epy015Io.getVactUseDcd())) {
////			if(!"2000".equals(input.getTxKndCd())) {
////				oParam  = prcsVactDpsWrtld(input,epy015Io,epy016Io);
////			}
////		}
//
//		// 정상응답코드 세팅
//		input.setAnswCd("0000");
//		String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//		input.setTxKcd(txKndCd);
//
//		logger.debug("최종OUTPUT =>{}",input);
//		oParam.put("input"      , input      );
//		return oParam;
//	}
//	
//	/**
//	 * 가상계좌 수신처리 처리
//	 * @param  CMB030SVC00In
//	 * @return CMB030SVC00Out
//	 * @throws ApplicationException
//	 */
//	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW)
//	private Hashtable<String,Object> callPrcsVactTgmTrrv(STB_F_COMOSSTOA00002In input) throws ApplicationException , EisExecutionException{
//
//		logger.debug("mmj 가상계좌수신");
//		Hashtable<String,Object>  oParam  =  new  Hashtable<String,Object>();
//		oParam.put("input"      , input                                      );
//		//oParam.put("bas007Out"  , new ArrayList <SelectMultiTBDPBAS007cOut>());
//		
//		int iResult = 0;
//
//		// INPUT 값 체크
//		checkVal(input);
//		if(!"0000".equals(input.getAnswCd())) {
//			// 전문종별코드 변경
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//
//		// 가상계좌 발급테이블 조회
//		SelectOneTBCMRTM013aOut rtm013Out = null;
//
//		rtm013Out = cmb030dbio.selectOneTBCMRTM013a(input.getActNo());
//
//		if(rtm013Out == null) {
//			logger.error("가상계좌발급 조회중 오류발생.");
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			input.setAnswCd("V817");
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//
//		TBDPEPY016Io epy016Io  = null;
//		
//		// 고객가상계좌신청 테이블 조회
//		epy016Io  = cmb030dbio.selectOneTBDPEPY016b(input.getNwOpenBnkCd(), input.getActNo());
//
//		if(epy016Io == null) {
//			logger.error("고객가상계좌 신청내역이 존재하지 않음.");
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			input.setAnswCd("F008");
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//
////		// 가상계좌 전송시 사원번호로 헤더 정보 변경
////		ExtendedCignaSystemHeader header = FwUtil.getContextHeader();
////		header.setChrgpMpNo(epy016Io.getTrmsEno());
//		
//
//		// 가상계좌이체결과 테이블 빌드 처리
//		TBDPEPY015Io  epy015Io  = null;
//		epy015Io  =  buildTbdpepy015(input,rtm013Out,epy016Io);
//		// 고객가상계좌일때 예금주명을 output으로 세팅
//		input.setAchdNm(FwUtil.substringKorean(epy015Io.getVactAchdNm(),20, "EUC-KR"));
//		
//		if(!"0000".equals(epy015Io.getVactTgmAnswCd())) {
//			input.setAnswCd(epy015Io.getVactTgmAnswCd());
//			// 전문종별코드 변경
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
//
//		// 정상일때 로그 insert 처리
//		iResult  = insertTbcmrtm014(input);
//		
//		if(iResult != 1) {
//            logger.error("가상계좌수신 로그 INSERT 처리시 오류가 발생하였습니다.");
//            input.setAnswCd("V141");
//            // 전문종별코드 변경
// 			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
// 			input.setTxKcd(txKndCd);
// 			oParam.put("input"      , input                                      );
//         			
//            return oParam ;
//        }
//		
//		iResult = 0;
//
//		// 정상일때 가상계좌이체결과 테이블 insert 처리
//		if("1000,1001,3000,3001".contains(input.getTxKcd())) {
//			
//			iResult  = insertTbdpepy015(epy015Io);
//			
//			if(iResult != 1) {
//	            logger.error("가상계좌이체결과 테이블 INSERT 처리시 오류가 발생하였습니다.");
//	            input.setAnswCd("V141");
//	        }
//			
//		} else if("1010,3010".contains(input.getTxKcd())) {
//			
//			iResult  = updateTbdpepy015(epy015Io);
//			
//
//	        if(iResult != 1) {
//	            logger.error("가상계좌이체결과 테이블 UPDATE 처리시 오류가 발생하였습니다.");
//	            input.setAnswCd("V141");
//	        }
//		}
//		
//		if(!"0000".equals(input.getAnswCd())) {
//			// 전문종별코드 변경
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			oParam.put("input"      , input                                      );
//			return oParam;
//		}
////		// 정상처리후 입금일경우 가상계좌입금기장처리 모듈 호출
////		if("DP".equals(epy015Io.getVactUsageCd())) {
////			if(!"2000".equals(input.getTxKcd())) {
////				oParam  = dpa110bean.prcsVactDpsWrtld(input,epy016Io);
////			}
////		}
//
//		// 정상응답코드 세팅
//		input.setAnswCd("0000");
//		String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//		input.setTxKcd(txKndCd);
//
//		logger.debug("최종OUTPUT =>{}",input);
//		oParam.put("input"      , input      );
//		return oParam;
//	}
//	
//	/**
//	 * INPUT값 체크
//	 * @param  CMB030SVC00In
//	 * @return CMB030SVC00In
//	 * @throws ApplicationException
//	 */
//	private STB_F_COMOSSTOA00001In checkValRcpnt(STB_F_COMOSSTOA00001In input) throws ApplicationException {
//
//		// 기관코드 체크
//		if(!"20003016".equals(input.getInstCd())) {
//			input.setAnswCd("V818");
//			return input;
//		}
//
//		// 거래종류코드 공백 체크
//		if(StringUtils.isEmpty(input.getTxKcd())) {
//			input.setAnswCd("F012");
//			return input;
//		}
//
//		// 거래종류코드 체크
//		if(!"1000,1001,3000,3001,2000,1010,3010".contains(input.getTxKcd())) {
//			input.setAnswCd("F012");
//			return input;
//		}
//
//		// 휴일체크
//		if(bizDateInfo.chkHldyYnBoolean(input.getTxDt())) {
//			logger.error("해당 처리일자는 휴일입니다.");
//			input.setAnswCd("V151");
//			return input;
//		}
//
//		// 송수신코드 체크
//		if(!"0".equals(input.getTrrvCd())) {
//			input.setAnswCd("F006");
//			return input;
//		}
//
//		// 개설은행코드 공백 체크
//		if(StringUtils.isEmpty(input.getOpenBnkCd())) {
//			input.setAnswCd("V818");
//			return input;
//		}
//
//		return input;
//	}
//	
//	/**
//	 * INPUT값 체크
//	 * @param  CMB030SVC00In
//	 * @return CMB030SVC00In
//	 * @throws ApplicationException
//	 */
//	private STB_F_COMOSSTOA00002In checkVal(STB_F_COMOSSTOA00002In input) throws ApplicationException {
//
//		// 기관코드 체크
//		if(!"20003016".equals(input.getInstCd())) {
//			input.setAnswCd("V818");
//			return input;
//		}
//
//		// 거래종류코드 공백 체크
//		if(StringUtils.isEmpty(input.getTxKcd())) {
//			input.setAnswCd("F012");
//			return input;
//		}
//
//		// 거래종류코드 체크
//		if(!"1000,1001,3000,3001,2000,1010,3010".contains(input.getTxKcd())) {
//			input.setAnswCd("F012");
//			return input;
//		}
//
//		// 휴일체크
//		if(bizDateInfo.chkHldyYnBoolean(input.getTxDt())) {
//			logger.error("해당 처리일자는 휴일입니다.");
//			input.setAnswCd("V151");
//			return input;
//		}
//
//		// 송수신코드 체크
//		if(!"0".equals(input.getTrrvCd())) {
//			input.setAnswCd("F006");
//			return input;
//		}
//
//		// 개설은행코드 공백 체크
//		if(StringUtils.isEmpty(input.getOpenBnkCd())) {
//			input.setAnswCd("V818");
//			return input;
//		}
//
//		return input;
//	}
//	
//	/**
//	 * 가상계좌이체결과 테이블 빌드 처리
//	 * @param  DPA110SVC00In
//	 * @param  SelectOneTBSLEMP026aOut
//	 * @param  TBDPEPY016Io
//	 * @return TBDPEPY015Io
//	 * @throws ApplicationException
//	 */
//	private TBDPEPY015Io buildTbdpepy015(Object input,SelectOneTBCMRTM013aOut rtm013Out,TBDPEPY016Io epy016Io) throws ApplicationException {
//		
//		TBDPEPY015Io   epy015Io  =  new  TBDPEPY015Io();
//
//		if (input instanceof STB_F_COMOSSTOA00001In ) { //2단
//			
//			STB_F_COMOSSTOA00001In stoa000001In = (STB_F_COMOSSTOA00001In)input;
//			
//			epy015Io.setFininCd              (stoa000001In.getOpenBnkCd   ()); 	//금융기관코드
//			epy015Io.setVactNo               (stoa000001In.getActNo       ()); 	//가상계좌번호
//			epy015Io.setVactTgmTxDt          (stoa000001In.getTxDt        ()); 	//가상계좌전문거래일자
//			epy015Io.setVactTgmTxNo          (stoa000001In.getTxNo        ()); 	//가상계좌전문거래번호
//			epy015Io.setFininDofCd           (stoa000001In.getHndlBnkDof  ()); 	//금융기관지점코드
//			epy015Io.setVactAchdNm           (""); 								//가상계좌예금주명
//			epy015Io.setTrsfRmtrNm           (stoa000001In.getDpsRqstpNm  ()); 	//이체송금자명
//			epy015Io.setVactTrsfPrcsAmt      (stoa000001In.getTxAmt       ()); 	//가상계좌이체처리금액
//			epy015Io.setVactFee              (0); 								//가상계좌수수료
//			epy015Io.setVactMoActNo          (""); 								//가상계좌모계좌번호
//			epy015Io.setVactTgmAnswCd        ("0000"                        ); 	//가상계좌전문응답코드
//			epy015Io.setVactOccuDcd          (stoa000001In.getOccuDvsn    ()); 	//가상계좌발생구분코드
//			epy015Io.setVactTgmTxTi          (stoa000001In.getTxHms       ()); 	//가상계좌전문거래시각
//		}
//		else if (input instanceof STB_F_COMOSSTOA00002In ) { //2단
//			
//			STB_F_COMOSSTOA00002In stoa000002In = (STB_F_COMOSSTOA00002In)input;
//			
//			epy015Io.setFininCd              (stoa000002In.getOpenBnkCd   ()); 	//금융기관코드
//			epy015Io.setVactNo               (stoa000002In.getActNo       ()); 	//가상계좌번호
//			epy015Io.setVactTgmTxDt          (stoa000002In.getTxDt        ()); 	//가상계좌전문거래일자
//			epy015Io.setVactTgmTxNo          (stoa000002In.getTxNo        ()); 	//가상계좌전문거래번호
//			epy015Io.setFininDofCd           (stoa000002In.getHndlBnkDof  ()); 	//금융기관지점코드
//			epy015Io.setVactAchdNm           (""); 								//가상계좌예금주명
//			epy015Io.setTrsfRmtrNm           (stoa000002In.getDpsRqstpNm  ()); 	//이체송금자명
//			epy015Io.setVactTrsfPrcsAmt      (stoa000002In.getTxAmt       ()); 	//가상계좌이체처리금액
//			epy015Io.setVactFee              (0); 								//가상계좌수수료
//			epy015Io.setVactMoActNo          (""); 								//가상계좌모계좌번호
//			epy015Io.setVactTgmAnswCd        ("0000"                        ); 	//가상계좌전문응답코드
//			epy015Io.setVactOccuDcd          (stoa000002In.getOccuDvsn    ()); 	//가상계좌발생구분코드
//			epy015Io.setVactTgmTxTi          (stoa000002In.getTxHms       ()); 	//가상계좌전문거래시각
//		}
//		
//		
//		epy015Io.setNrmCnclDcd           ("0"                    ); //취소구분코드
//		epy015Io.setCnclDtm              (""); //취소일시
//
//		epy015Io.setVactTrsfBzDcd        (""); //가상계좌이체업무구분코드
//		epy015Io.setBkkpSlipPropoOrgNo   (""); //경리전표발의조직번호
//		epy015Io.setBkkpSlipPropoDt      (""); //경리전표발의일자
//		epy015Io.setXcDt                 (""); //정산일자
//		epy015Io.setTrsfPrcsDofOrgNo     (""); //이체처리지점조직번호
//		epy015Io.setTrsfPrcsFofOrgNo     (""); //이체처리영업소조직번호
//
//		epy015Io.setDelYn                ("N"); //삭제여부
//		epy015Io.setLastChgrId           (FwUtil.getUserId     ()); //최종변경자ID
//		epy015Io.setLastChgPgmId         (FwUtil.getPgmId      ()); //최종변경프로그램ID
//		epy015Io.setLastChgTrmNo         (FwUtil.getTrmNo      ()); //최종변경단말번호
//
//
//		epy015Io.setVactIssueMgntNo      (rtm013Out.getVactIssueMgntNo()); //가상계좌발급관리번호
//		epy015Io.setVactUsageCd          (rtm013Out.getVactUsageCd());     //가상계좌용도코드
//		
//		// 전송구분코드가 전송취소('2')이면 오류처리
//		if("2".equals(epy016Io.getTrmsDcd())) {
//			logger.error("고객가상계좌 전송취소건.");
//			epy015Io.setVactTgmAnswCd("F008");
//			return epy015Io;
//		}
//		// 가상계좌납입금액이 총실납입보험료와 다르면 오류
//		if(!epy015Io.getVactTrsfPrcsAmt().equals(epy016Io.getTtlRldpsAmt())) {
//			logger.error("가상계좌납입금액이 총실납입보험료와 상이.");
//			epy015Io.setVactTgmAnswCd("V713");
//			return epy015Io;
//		}
//	
//		// DBIO에 세팅
//		//epy015Io.setVactAchdNm           ("라이나생명(" + prf001Io.getCustNm() + ")" ); //가상계좌예금주명			
//		//가상계좌예금주명이 40 BYTE 클 때
//		if(epy015Io.getVactAchdNm().length() > 20 ){
//			epy015Io.setVactAchdNm           (FwUtil.substringKorean(epy015Io.getVactAchdNm(),40, "EUC-KR"));
//		}
//		
//		epy015Io.setTrsfPrcsDofOrgNo     (epy016Io.getTrmsDofOrgNo()); //이체처리지점조직번호
//		epy015Io.setTrsfPrcsFofOrgNo     (epy016Io.getTrmsFofOrgNo()); //이체처리영업소조직번호
//		epy015Io.setBkkpSlipPropoOrgNo(""); //경리전표발의조직번호		
//		epy015Io.setBkkpSlipPropoDt(""); 	//경리전표발의일자
//		epy015Io.setXcDt("");				//정산일자
//
//		return epy015Io;
//	}
//	
//	/**
//	 * 가상계좌전문 로그 테이블 insert 처리
//	 * @param  CMB030SVC00In
//	 * @return CMB030SVC00In
//	 * @throws ApplicationException
//	 */
//	private int insertTbcmrtm014(Object input) throws ApplicationException {
//		
//		TBCMRTM014Io   rtm014Io  =  new  TBCMRTM014Io();
//
//		if (input instanceof STB_F_COMOSSTOA00001In ) { //2단
//			
//			STB_F_COMOSSTOA00001In stoa000001In = (STB_F_COMOSSTOA00001In)input;
//			
//			rtm014Io.setVactTgmTxDt      (stoa000001In.getTxDt        ());  //가상계좌전문거래일자
//			rtm014Io.setVactTgmTxNo      (stoa000001In.getTxNo        ());  //가상계좌전문거래번호
//			rtm014Io.setVactTgmCtgyCd    (stoa000001In.getTxKcd       ());  //가상계좌전문종별코드
//			rtm014Io.setVactTgmLen       (Integer.parseInt(stoa000001In.getLen ()));  //가상계좌전문길이
//			rtm014Io.setHndlInstCd       (stoa000001In.getHndlBnk     ());  //취급기관코드
//			rtm014Io.setTrrvDcd          (stoa000001In.getTrrvCd      ());  //송수신구분코드
//			rtm014Io.setVactTgmTxTi      (stoa000001In.getTxHms       ());  //가상계좌전문거래시각
//			rtm014Io.setFininCd          (stoa000001In.getNwOpenBnkCd ());  //금융기관코드
//			rtm014Io.setVactTgmAnswCd    (stoa000001In.getAnswCd      ());  //가상계좌전문응답코드
//			rtm014Io.setVactFee          (0);  //가상계좌수수료
//			rtm014Io.setVavsRsvtTeryVl   (stoa000001In.getRsvtTery2   ());  //VAVS예약영역값
//			rtm014Io.setUsrTxNo          (Integer.toString(stoa000001In.getUsrTxCd()));  //사용자거래코드
//			rtm014Io.setVactOccuDcd      (stoa000001In.getOccuDvsn    ());  //가상계좌발생구분코드
//			rtm014Io.setTgmTrmsDcd       (stoa000001In.getTgmTrmsWayDvsn());  //전문전송구분코드
//			rtm014Io.setRsvtTeryCd       (stoa000001In.getRsvtTery3() +  stoa000001In.getAutoCnclDvsn());  //예약영역코드
//			byte[] cntn = FwUtil.toBytes(stoa000001In, null);
//			String strCntn = new String(cntn);
//			rtm014Io.setVactTgmCtnt      (strCntn.substring(0,200));  //가상계좌전문내용
//		}
//		
//		
//		rtm014Io.setDelYn            ("N"                    );  //삭제여부
//		rtm014Io.setLastChgrId       (FwUtil.getUserId     ()); //최종변경자ID
//		rtm014Io.setLastChgPgmId     (FwUtil.getPgmId      ()); //최종변경프로그램ID
//		rtm014Io.setLastChgTrmNo     (FwUtil.getTrmNo      ()); //최종변경단말번호
//
//		logger.debug("mmj epy014Io {}", rtm014Io);
//
//		int iResult = cmb030dbio.insertOneTBCMRTM014a(rtm014Io);
//
//		return iResult;
//	}
//	
//	/**
//	 * 가상계좌이체결과 테이블 insert 처리
//	 * @param  CMB030SVC00In
//	 * @param  TBDPEPY015Io
//	 * @return CMB030SVC00In
//	 * @throws ApplicationException
//	 */
//	private int insertTbdpepy015(TBDPEPY015Io  epy015Io) throws ApplicationException {
//
//		int iResult = cmb030dbio.insertOneTBDPEPY015a(epy015Io);
//
//		return iResult;
//	}
//	
//	/**
//	 * 가상계좌이체결과 테이블 update 처리
//	 * @param  CMB030SVC00In
//	 * @return TBDPEPY015Io
//	 * @throws ApplicationException
//	 */
//	private int updateTbdpepy015(TBDPEPY015Io  epy015Io) throws ApplicationException {
//
//		epy015Io.setNrmCnclDcd           ("1"                             ); //취소구분코드
//		epy015Io.setCnclDtm              (CMBZ00BEAN.currentDateTime    ()); //취소일시
//
//		int iResult = cmb030dbio.updateOneTBDPEPY015a(epy015Io);
//
//
//		return iResult;
//	}
//	
//	/**
//	 * 가상계좌송수신처리 처리 - 집계전문 (현재 전문 발생하지 않음 => 가상계좌집계전문 테이블도 미생성(추후 결정)
//	 * @param  CMB030SVC01In
//	 * @return CMB030SVC01In
//	 * @throws ApplicationException
//	 */
//	public STB_F_COMOSSTOA00006In prcsVactTgmTrrvTot(STB_F_COMOSSTOA00006In input) throws ApplicationException {
//
//		// INPUT 값 체크
//		checkValTot(input);
//		if(!"0000".equals(input.getAnswCd())) {
//			// 전문종별코드 변경
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			return input;
//		}
//
//		// 정상일때 로그 insert 처리
//		input  = insertTbcmrtm014Tot(input);
//		if(!"0000".equals(input.getAnswCd())) {
//			// 전문종별코드 변경
//			String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//			input.setTxKcd(txKndCd);
//			return input;
//		}
//
////		// 정상일때 가상계좌이체결과 테이블 insert 처리
////		input  = insertTbdpepy015(input,eput015Io);
////
////		if(!StringUtils.isEmpty(input.getRespCd())) {
////			return input;
////		}
//		// 정상응답코드 세팅
//		String txKndCd = input.getTxKcd().substring(0,1) + "1" +  input.getTxKcd().substring(2);
//		input.setTxKcd(txKndCd);
//		input.setAnswCd("0000");
//
//		return input;
//	}
//	
//	/**
//	 * INPUT값 체크 - 집계전문
//	 * @param  CMB030SVC01In
//	 * @return CMB030SVC01In
//	 * @throws ApplicationException
//	 */
//	private STB_F_COMOSSTOA00006In checkValTot(STB_F_COMOSSTOA00006In input) throws ApplicationException {
//
//		// 기관코드 체크
//		if(!"20003016".equals(input.getInstCd())) {
//			input.setAnswCd("V818");
//			return input;
//		}
//
//		// 거래종류코드 체크
//		if(!"7000".equals(input.getTxKcd())) {
//			input.setAnswCd("F012");
//			return input;
//		}
//
//		// 휴일체크
//		if(bizDateInfo.chkHldyYnBoolean(input.getTxDt())) {
//			logger.error("해당 처리일자는 휴일입니다.");
//			input.setAnswCd("V151");
//			return input;
//		}
//
//		// 송수신코드 체크
//		if(!"0".equals(input.getTrrvCd())) {
//			input.setAnswCd("F006");
//			return input;
//		}
//
//		return input;
//	}
//	
//	/**
//	 * 가상계좌전문 로그 테이블 insert 처리 - 집계전문
//	 * @param  CMB030SVC01In
//	 * @return CMB030SVC01In
//	 * @throws ApplicationException
//	 */
//	private STB_F_COMOSSTOA00006In insertTbcmrtm014Tot(STB_F_COMOSSTOA00006In input) throws ApplicationException {
//		TBCMRTM014Io   rmt014Io  =  new  TBCMRTM014Io();
//
//		byte[] cntn = FwUtil.toBytes(input, null);
//		
//		rmt014Io.setVactTgmTxDt      (input.getTxDt        ());  //가상계좌전문거래일자
//		rmt014Io.setVactTgmTxNo      (input.getTxNo        ());  //가상계좌전문거래번호
//		rmt014Io.setVactTgmCtgyCd    (input.getTxKcd       ());  //가상계좌전문종별코드
//		rmt014Io.setVactTgmLen       (Integer.parseInt(input.getLen ()));  //가상계좌전문길이
//		rmt014Io.setHndlInstCd       (input.getInstCd  ());  //취급기관코드
//		rmt014Io.setTrrvDcd          (input.getTrrvCd      ());  //송수신구분코드
//		rmt014Io.setVactTgmTxTi      (input.getTxHms       ());  //가상계좌전문거래시각
//		rmt014Io.setFininCd          (input.getNwOpenBnkCd ());  //금융기관코드
//		rmt014Io.setVactTgmAnswCd    (input.getAnswCd      ());  //가상계좌전문응답코드
//		rmt014Io.setVactFee          (0);  //가상계좌수수료
//		rmt014Io.setVavsRsvtTeryVl   (input.getRsvtTery2   ());  //VAVS예약영역값
//		rmt014Io.setUsrTxNo          (Integer.toString(input.getUsrTxCd()));  //사용자거래번호
//		rmt014Io.setVactOccuDcd      (input.getOccuDvsn    ());  //가상계좌발생구분코드
//		rmt014Io.setTgmTrmsDcd       (input.getTgmTrmsWayDvsn  ());  //전문전송구분코드
//		rmt014Io.setRsvtTeryCd       (input.getRsvtTery3   ());  //예약영역코드
//		
//		String strCntn = new String(cntn);
//		rmt014Io.setVactTgmCtnt      (strCntn.substring(0,200));  //가상계좌전문내용
//		
//		//rmt014Io.setVactTgmCtnt      (""                     );  //가상계좌전문내용
//		rmt014Io.setDelYn            ("N"                    );  //삭제여부
//		rmt014Io.setLastChgrId       (FwUtil.getUserId     ()); //최종변경자ID
//		rmt014Io.setLastChgPgmId     (FwUtil.getPgmId      ()); //최종변경프로그램ID
//		rmt014Io.setLastChgTrmNo     (FwUtil.getTrmNo      ()); //최종변경단말번호
//
//
//
//		int iResult = cmb030dbio.insertOneTBCMRTM014a(rmt014Io);
//
//        if(iResult != 1) {
//            logger.error("가상계좌수신 로그 INSERT 처리시 오류가 발생하였습니다.");
//            input.setAnswCd("V141");
//            return input ;
//        }
//
//
//		return input;
//	}
//	
}

