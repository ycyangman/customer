package cigna.cm.b.bean;

import klaf.app.ApplicationException;
import klaf.container.annotation.KlafBean;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB040DBIO;
import cigna.cm.b.domain.WtrsfAsntDlngInfo;
import cigna.cm.b.io.TBCMETC015Io;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;


/**
 * @file         cigna.cm.b.bean.CMB040BEAN.java
 * @filetype     java source file
 * @brief        출금이체동의처리내역
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                           성명                                               일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 10. 11.     신규 작성
 *
 */
@KlafBean
public class CMB040BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB040DBIO cmb040dbio;		// 출금이체동의처리내역
	
	/**
	 * 출금이체동의처리내역 Operation
	 * @param TrsfTrrvPrcsInfo  이체송수신처리정보
	 * @return TrsfTrrvPrcsInfo  이체송수신처리정보 
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int callWtrsfAsntDlng (WtrsfAsntDlngInfo input) throws ApplicationException {
		
		int iResult = 0;
		
		iResult = insertWtrsfAnstDlng(input);
		
		return iResult;
	}
	
	/**
	 * 출금이체동의처리내역저장
	 * @param WtrsfAsntDlngInfo  이체송수신처리정보
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int insertWtrsfAnstDlng (WtrsfAsntDlngInfo input) throws ApplicationException {
		
		int iResult = 0;
		TBCMETC015Io insertInput = new TBCMETC015Io();
		
		
		insertInput.setWtrsfAsntDt(input.getWtrsfAsntDt());							// set [출금이체동의일자]
		insertInput.setWtrsfAsntTi(input.getWtrsfAsntTi());							// set [출금이체동의시각]
		insertInput.setWtrsfAsntSysCd(input.getWtrsfAsntSysCd());					// set [출금이체동의시스템코드]
		
		insertInput.setWtrsfAsntEvidDcd(input.getWtrsfAsntEvidDcd());				// set [출금이체동의증빙구분코드]
		insertInput.setWtrsfAsntEvidNo(input.getWtrsfAsntEvidNo());					// set [출금이체동의증빙번호]
		insertInput.setWtrsfAsntDcd(input.getWtrsfAsntDcd());						// set [출금이체동의구분코드]
		insertInput.setWtrsfAsntRcDcd(input.getWtrsfAsntRcDcd());					// set [출금이체동의접수구분코드]
		insertInput.setContNo(input.getContNo());									// set [계약번호]
		insertInput.setPmpsNo(input.getPmpsNo());									// set [납부자번호]
		insertInput.setContrNm(input.getContrNm());									// set [계약자명]
		insertInput.setPmpsDscNo(input.getPmpsDscNo());								// set [납부자식별번호]
		insertInput.setPmpsNm(input.getPmpsNm());									// set [납부자명]
		insertInput.setFininCd(input.getFininCd());									// set [금융기관코드]
		insertInput.setPmpsActNo(input.getPmpsActNo());								// set [납부자계좌번호]
		insertInput.setTrsfAmt(input.getTrsfAmt());									// set [이체금액]
		insertInput.setBzTxRfDcd(input.getBzTxRfDcd());								// set [업무거래참조구분코드]
		insertInput.setBzTxRfNo(input.getBzTxRfNo());								// set [업무거래참조번호]
		insertInput.setWtrsfAsntNrmYn(input.getWtrsfAsntNrmYn());					// set [출금이체동의정상여부]
		insertInput.setWtrsfAsntVcrecStrtDtm(input.getWtrsfAsntVcrecStrtDtm());		// set [출금이체동의녹취시작일시]
		insertInput.setWtrsfAsntVcrecEndDtm(input.getWtrsfAsntVcrecEndDtm());		// set [출금이체동의녹취종료일시]
		insertInput.setCentrNm(input.getCentrNm());									// set [센터명]
		insertInput.setTeamNm(input.getTeamNm());									// set [팀명]
		insertInput.setChrgpEno(input.getChrgpEno());								// set [담당자사원번호]
		insertInput.setChrgpNm(input.getChrgpNm());									// set [담당자명]
		insertInput.setLastChgrId(FwUtil.getUserId());								// 최종변경자ID(LAST_CHGR_ID) 설정
		insertInput.setLastChgPgmId(FwUtil.getPgmId());								// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		insertInput.setLastChgTrmNo(FwUtil.getTrmNo());								// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		SecuUtil.doEncObject(insertInput);
		logger.debug("☆☆☆☆☆☆☆ insertInput ===>{}", insertInput);
		iResult = this.cmb040dbio.insertOneTBCMETC0150(insertInput);
				
		return iResult;
	}
	
	
	/**
	 * 출금이체동의처리내역저장
	 * @param WtrsfAsntDlngInfo  이체송수신처리정보
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int updateWtrsfAnstDlng (String bzTxRfNo, String WtrsfAsntDt, String wtrsfAsntNrmYn) throws ApplicationException {
		
		int iResult = 0;	
		
		iResult = this.cmb040dbio.updateOneTBCMETC0150(bzTxRfNo, WtrsfAsntDt, wtrsfAsntNrmYn, FwUtil.getUserId(),FwUtil.getPgmId(),FwUtil.getTrmNo());
				
		return iResult;
	}
	
	/**
	 * 출금이체동의처리내역저장
	 * @param WtrsfAsntDlngInfo  이체송수신처리정보
	 * @return iResult 수행결과값
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int updateWtrsfAnstDlng (String bzTxRfNo, String wtrsfAsntNrmYn) throws ApplicationException {
		
		int iResult = 0;	
		
		iResult = this.cmb040dbio.updateOneTBCMETC0151(bzTxRfNo, wtrsfAsntNrmYn, FwUtil.getUserId(),FwUtil.getPgmId(),FwUtil.getTrmNo());
				
		return iResult;
	}	
}

