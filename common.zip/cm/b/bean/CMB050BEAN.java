package cigna.cm.b.bean;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.dbio.CMB040DBIO;
import cigna.cm.b.domain.CardAprvReqInfo;
import cigna.cm.b.domain.CardAprvResInfo;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.domain.WeCheckProcInfo;
import cigna.cm.b.io.COM_F_KIBOSKIBO00005In;
import cigna.cm.b.io.COM_F_KIBOSKISO00001In;
import cigna.cm.b.io.COM_F_KIBOSKISO00001Out;
import cigna.cm.b.io.COM_F_KSNOSKSRO00010In;
import cigna.cm.b.io.COM_F_KSNOSKSRO00010Out;
import cigna.cm.b.io.TBCMRTM002Io;
import cigna.cm.b.io.TBCSFCR005Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;


/**
 * @file         cigna.cm.b.bean.CMB050BEAN.java
 * @filetype     java source file
 * @brief        KIBNET스크래핑
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                           성명                                               일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 10. 11.     신규 작성
 *
 */
@KlafBean
public class CMB050BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
//	@Autowired
//	private CMB040DBIO cmb040dbio;		// 출금이체동의처리내역
	
	@Autowired
	private CMB001DBIO cmb001dbio;		// 전문번호 체크
	
	/**
	 * 스크래핑전문송수신 Operation
	 * @param TrsfTrrvPrcsInfo  이체송수신처리정보
	 * @return TrsfTrrvPrcsInfo  이체송수신처리정보 
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public WeCheckProcInfo callWeCheck (WeCheckProcInfo input) throws ApplicationException {
		
		WeCheckProcInfo prcsInfo = null;
		
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
		//================ 필수항목 체크 =============================//
		if (StringUtils.isEmpty(input.getSendDt())) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"전송일자(M)"});
		}
		
		if (StringUtils.isEmpty(input.getSendTm())) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"전송시간(M)"});
		}
		
		if (StringUtils.isEmpty(input.getBankCd())) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"기관코드(M)"});
		}
		
		if (StringUtils.isEmpty(input.getName())) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"성명(M)"});
		}
		
		if (StringUtils.isEmpty(input.getRegNo())) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"주민등록번호(M)"});
		}
		
		if ("004".equals(input.getBankCd()) && input.getRegNo().length() != 13) {
			throw new ApplicationException("APCME0025", new Object[]{"주민등록번호 길이(M)"});
		}
		
		if ("004".equals(input.getBankCd()) && StringUtils.isEmpty(input.getIssueDate())) {
			throw new ApplicationException("APCME0025", new Object[]{"발급일자 (M)"});
		}
		
		if (!"004".equals(input.getBankCd()) && StringUtils.isEmpty(input.getDriveNo())) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"면허번호(M)"});
		}
		
		if (("911".equals(input.getBankCd()) || "914".equals(input.getBankCd()) ) && StringUtils.isEmpty(input.getSecureNo())) {
			//throw new ApplicationException( "APCME0025", new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" }, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "은행코드(M)" });
			throw new ApplicationException("APCME0025", new Object[]{"암호일련번호(M)"});
		}
		
		String tgmNo = setTgmNoCrt("KIB", today);  // 
		
		if(!StringUtils.hasText(tgmNo)){
			// 전문번호 생성 오류 : '전문번호가 생성되지 않았습니다. 확인해주세요.'
			throw new ApplicationException("APPAE0057", new Object[]{"전문번호"});
		}
		
		input.setTrSeq(tgmNo);
		
		prcsInfo = callAprvReal(input);
		
		return prcsInfo;
	}
	
	 /**
     * <p> 운영계용 처리process </p>
     * @param CardAprvReqInfo   cardReqInfo 카드처리 DO
     * @return CardAprvResInfo  cardResInfo  처리결과 DO
     * @throws ApplicationException
     */
	private WeCheckProcInfo callAprvReal(WeCheckProcInfo input) throws ApplicationException {
		
		COM_F_KIBOSKISO00001In request = new COM_F_KIBOSKISO00001In(); // EAI Interface request data(OMM)
		String interfaceId = "COM_F_KIBOSKISO00001"; // EAI Interface ID
		EISResponse < COM_F_KIBOSKISO00001Out > response = null;
		COM_F_KIBOSKISO00001Out responseData = null;
			
		WeCheckProcInfo prcsInfo = new WeCheckProcInfo();
		
		logger.debug("=========  input =============" + input   );
		
		
		try {
			
			request.setTotLen("000251");																				//총길이
			request.setTrnCd1("SGWC");																					//식별코드1	
			request.setTrnCd2("     SGW");																			//식별코드2
			request.setSendFlag("1");																					//송신사Flag
			request.setGwSysNo("999");																					//GW시스템번호
			request.setSsSysNo("0000");																					//SS시스템번호
			request.setTxType("0600");																					//전문코드
			request.setTxCd("1320");																					//업무구분
			request.setSendDt(input.getSendDt());
			request.setSendTm(input.getSendTm());
			request.setRespCd("        ");																				//응답코드			
			request.setProdKey("BUQIpurpEfWGeo0r1u8H");																	//재퓸고유번호
			request.setTrSeq(input.getTrSeq());																			//거래고유번호
			request.setGroupGb("00");																					//그룹구분
			request.setSectStart("0000");																				//구간시작번호
			request.setSectEnd("0000");																					//구간종료번호
			request.setFiller("       ");																				//예비필드
			request.setBankCd(input.getBankCd());																		//기관코드
			if (StringUtils.isEmpty(input.getName())) {
				request.setName(StringUtils.lpad("", 50, " "));			//성명
			} else {
				request.setName(input.getName().concat(StringUtils.lpad("", 50 - input.getName().length(), " ")));			//성명
			}
			if (StringUtils.isEmpty(input.getRegNo())) {
				request.setRegNo(StringUtils.lpad("", 20, " "));			//주민등록번호
			} else {
				request.setRegNo(input.getRegNo().concat(StringUtils.lpad("", 20 - input.getRegNo().length(), " ")));		//주민등록번호
			}
			if (StringUtils.isEmpty(input.getDriveNo())) {
				request.setDriveNo(StringUtils.lpad("", 50, " "));			//면허번호
			} else {
				request.setDriveNo(input.getDriveNo().concat(StringUtils.lpad("", 50 - input.getDriveNo().length(), " ")));	//면허번호
			}
			if (StringUtils.isEmpty(input.getSecureNo())) {
				request.setSecureNo(StringUtils.lpad("", 20, " "));			//암호일련번호
			} else {
				request.setSecureNo(input.getSecureNo().concat(StringUtils.lpad("", 20 - input.getSecureNo().length(), " ")));	//암호일련번호
			}
			if (StringUtils.isEmpty(input.getIssueDate())) {
				request.setIssueDate(StringUtils.lpad("", 8, " "));			//암호일련번호
			} else {
				request.setIssueDate(input.getIssueDate());																	// 발급일자
			}
			
			
			String mode = LApplicationContext.getSystemMode();	 
			
			logger.debug("kibnet mode===>|{}",request+"|");
			
			logger.debug("kibnet mode===>{}",mode);
			
			logger.debug("kibnet mode===>{}",input.getRegNo().substring(7));
			
			
			String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			
			String prcsHms = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);

			String currentMin = prcsHms.substring(2, 4);		
			String startMin = "00";
			String endMin = "31";
			
			//운영계
			//2016.10.08
			if("R".equals(mode) ||  "D".equals(mode) ) {
			
				  logger.debug("request 신분증 진위  ===>|{}",request+"|");
				
				  //3.동기화 방식 송신			  
				  response= InfUtil.callFEP(request, interfaceId,COM_F_KIBOSKISO00001Out.class);
				  
				  logger.debug("response---> {}",response);

				  responseData = response.getResponseData();
				  
				  prcsInfo.setTrSeq(input.getTrSeq());
				  prcsInfo.setSendDt(input.getSendDt());
				  prcsInfo.setSendTm(input.getSendTm());				  
				  prcsInfo.setBankCd(input.getBankCd());																		//기관코드
				  prcsInfo.setName(input.getName());			//성명
				  prcsInfo.setRegNo(input.getRegNo());		//주민등록번호
				  prcsInfo.setDriveNo(input.getDriveNo());	//면허번호
				  prcsInfo.setSecureNo(input.getSecureNo());	//암호일련번호
				  prcsInfo.setIssueDate(input.getIssueDate());	
				  
				  logger.debug("========= today ==========" + today);
				  
				  if (Integer.parseInt(today) > Integer.parseInt("20170220") 
						  && Integer.parseInt(today) < Integer.parseInt("20170415")) {
					  if (input.getRegNo().length() != 13 ) {
						  prcsInfo.setRespCd("00000000");										//응답코드
						  prcsInfo.setResAgreement("Y");							//진위여부
					  } else {
						  if ("9".equals(input.getRegNo().substring(12))) {
							  prcsInfo.setRespCd("00000000");										//응답코드
							  prcsInfo.setResAgreement("N");							//진위여부
							  prcsInfo.setResDisagreementReason("(UAT)스크래핑 실패");			//불일치사유
						  } else {
							  prcsInfo.setRespCd("00000000");										//응답코드
							  prcsInfo.setResAgreement("Y");							//진위여부
						  }
					  }
					  
					} else  {
						prcsInfo.setAnswMsg(responseData.getAnswMsg());				//결과메시지
						prcsInfo.setRespCd(responseData.getRespCd());										//응답코드
						prcsInfo.setResAgreement(responseData.getAgreement());							//진위여부
						prcsInfo.setResName(responseData.getName());										//성명
						prcsInfo.setResRegNo(responseData.getRegNo());									//주민등록번호
						prcsInfo.setResDriveNo(responseData.getDriveNo());								//면허번호
						prcsInfo.setResSearchDate(responseData.getSearchDate());							//조회일시
						prcsInfo.setResIssueDate(responseData.getIssueDate());							//발급일자
						prcsInfo.setResDisagreementReason(responseData.getDisagreementReason());			//불일치사유
					}  
			//개발,테스트
			} else if( "D".equals(mode) ) {
				
				prcsInfo.setTrSeq(input.getTrSeq());
				prcsInfo.setSendDt(input.getSendDt());
				prcsInfo.setSendTm(input.getSendTm());				  
				prcsInfo.setBankCd(input.getBankCd());																		//기관코드
				prcsInfo.setName(input.getName());			//성명
				prcsInfo.setRegNo(input.getRegNo());		//주민등록번호
				prcsInfo.setDriveNo(input.getDriveNo());	//면허번호
				prcsInfo.setSecureNo(input.getSecureNo());	//암호일련번호
				prcsInfo.setIssueDate(input.getIssueDate());	
				  
			/*	if (Integer.parseInt(today) > Integer.parseInt("20170220") 
						  && Integer.parseInt(today) < Integer.parseInt("20170330")) {
						  */
					  if (input.getRegNo().length() != 13 ) {
						  if ((input.getDriveNo().lastIndexOf("9", input.getDriveNo().length()) + 1) ==input.getDriveNo().length()) {
							  prcsInfo.setRespCd("00000000");										//응답코드
							  prcsInfo.setResAgreement("N");							//진위여부
							  prcsInfo.setResDisagreementReason("(UAT)스크래핑 실패");			//불일치사유
						  } else {
							  prcsInfo.setRespCd("00000000");										//응답코드
							  prcsInfo.setResAgreement("Y");							//진위여부
						  }
					  } else {
						  if ("9".equals(input.getRegNo().substring(12))) {
							  prcsInfo.setRespCd("00000000");										//응답코드
							  prcsInfo.setResAgreement("N");							//진위여부
							  prcsInfo.setResDisagreementReason("(UAT)스크래핑 실패");			//불일치사유
						  } else {
							  prcsInfo.setRespCd("00000000");										//응답코드
							  prcsInfo.setResAgreement("Y");							//진위여부
						  }
					  }
					  /*
				} else  {
					prcsInfo.setRespCd(responseData.getRespCd());										//응답코드
					prcsInfo.setResAgreement(responseData.getAgreement());							//진위여부
					prcsInfo.setResName(responseData.getName());										//성명
					prcsInfo.setResRegNo(responseData.getRegNo());									//주민등록번호
					prcsInfo.setResDriveNo(responseData.getDriveNo());								//면허번호
					prcsInfo.setResSearchDate(responseData.getSearchDate());							//조회일시
					prcsInfo.setResIssueDate(responseData.getIssueDate());							//발급일자
					prcsInfo.setResDisagreementReason(responseData.getDisagreementReason());			//불일치사유
				}  
				*/
				
			} else if( "T".equals(mode) ) {				
				prcsInfo.setTrSeq(input.getTrSeq());
				prcsInfo.setSendDt(input.getSendDt());
				prcsInfo.setSendTm(input.getSendTm());				  
				prcsInfo.setBankCd(input.getBankCd());																		//기관코드
				prcsInfo.setName(input.getName());			//성명
				prcsInfo.setRegNo(input.getRegNo());		//주민등록번호
				prcsInfo.setDriveNo(input.getDriveNo());	//면허번호
				prcsInfo.setSecureNo(input.getSecureNo());	//암호일련번호
				prcsInfo.setIssueDate(input.getIssueDate());
				prcsInfo.setRespCd("00000000");										//응답코드
				prcsInfo.setAnswMsg("정상");				//결과메시지
				prcsInfo.setResAgreement("Y");							//진위여부
				prcsInfo.setResName(input.getName());										//성명
				prcsInfo.setResRegNo(input.getRegNo());									//주민등록번호
				prcsInfo.setResDriveNo(input.getDriveNo());								//면허번호
				prcsInfo.setResSearchDate(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+ "0000");							//조회일시
				prcsInfo.setResIssueDate(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));							//발급일자
				prcsInfo.setResDisagreementReason("");			//불일치사유

			}
		} catch ( EisExecutionException e) {
			
            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");			
			
			throw new ApplicationException("APCME0062", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});

		} catch ( NotSupportedEISException e) {

            StackTraceElement[] ss = e.getStackTrace();
            String strTrace = "\n";
            for(int i = 0; i < ss.length; i++){
                strTrace += "[" +  i + "]" + ss[i].toString() + "\n";           
            }
            logger.debug("============================== Trace Stack Start=============================={}",strTrace);       
            logger.debug("Exception]{}",e);
            logger.debug("Exception.getMessage],{}", e.getMessage());
            logger.debug("============================== Trace Stack End  ==============================");		
			throw new ApplicationException("APCME0062", new Object[]{"대외계연동"}, new Object[]{"대외계연동"});
		}

		return prcsInfo;
		
	}
	
	/**
	 * 전문번호생성
	 * @param String fnnCd       금융기관코드
	 * @param String mknoPrcsDt  채번처리일자
	 * @return String mknoTgmNo  채번전문번호 
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public String setTgmNoCrt (String fnnCd, String mknoPrcsDt) throws ApplicationException {
		
		int        iResult      		= 0;
		
		String     strMknoTgmNo     	= "";				// 조회된 채번전문번호
		String     mknoTgmNo     		= "";				// 채번전문번호
		
		logger.debug("========================  전문번호생성 채번 ======================");
		logger.debug("fnnCd = {} ", fnnCd);
		logger.debug("mknoPrcsDt = {} ", mknoPrcsDt );
		
		// 필수입력값체크
		if (StringUtils.isEmpty(fnnCd) || fnnCd.length() != 3 ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ "금융기관코드", "금융기관코드" });
		} 
		
		if (StringUtils.isEmpty(mknoPrcsDt) || mknoPrcsDt.length() != 8 ) {
			throw new ApplicationException( "APCME0005", null, new Object[]{ "채번처리일자", "채번처리일자" });
		}
		
		//strMknoTgmNo =  this.cmb001dbio.selectOneTBCMRTM0020(mknoPrcsDt, fnnCd);
		strMknoTgmNo =  this.cmb001dbio.selectOneTBCMRTM0020(mknoPrcsDt, fnnCd);
		
		logger.debug("strMknoTgmNo = {}", strMknoTgmNo );
		
		//리얼타임전문번호의 채번전문번호 조회시 전문번호가 존재하지 않으면 생성(insert) 아니면 수정(update)
		if (!StringUtils.hasText(strMknoTgmNo)) {
			//전문번호 초기화.
			mknoTgmNo = "";
			
			mknoTgmNo = "0000001";

			TBCMRTM002Io tbcmrtm002io = new TBCMRTM002Io();

			//2016.09.02
			//kibnet은 거래번호가 은행이 다르고 거래일련번호가 같은 경우 오류 처리 발생으로 
			//금융기관코드 대신 "999"로 세팅해서 처리하도록 수정
			tbcmrtm002io.setFininCd(fnnCd);						// set [금융기관코드]
			tbcmrtm002io.setMknoPrcsDt(mknoPrcsDt);				// set [채번처리일자]
			tbcmrtm002io.setMknoTgmNo(mknoTgmNo);				// set [채번전문번호]
			tbcmrtm002io.setLastChgrId(FwUtil.getUserId());		// set [최종변경자ID]
			tbcmrtm002io.setLastChgPgmId(FwUtil.getPgmId());	// set [최종변경프로그램ID]
			tbcmrtm002io.setLastChgTrmNo(FwUtil.getTrmNo());	// set [최종변경단말번호]
			
			logger.debug("tbcmrtm002io(리얼타임전문번호테이블 INSERT 세팅값)={}", tbcmrtm002io);
			
			iResult = this.cmb001dbio.insertOneTBCMRTM0020(tbcmrtm002io);
			
		} else {
			
			mknoTgmNo = Integer.toString(Integer.parseInt(strMknoTgmNo) + 1);
			
			mknoTgmNo = StringUtils.lpad(mknoTgmNo, 7, "0");
			
			logger.debug(" === mknoTgmNo === " + mknoTgmNo);
			
			TBCMRTM002Io tbcmrtm002io = new TBCMRTM002Io();
			
			//2016.09.02
			//kibnet은 거래번호가 은행이 다르고 거래일련번호가 같은 경우 오류 처리 발생으로 
			//금융기관코드 대신 "999"로 세팅해서 처리하도록 수정
			tbcmrtm002io.setFininCd(fnnCd);						// set [금융기관코드]
			tbcmrtm002io.setMknoPrcsDt(mknoPrcsDt);				// set [채번처리일자]
			tbcmrtm002io.setMknoTgmNo(mknoTgmNo);				// set [채번전문번호]
			tbcmrtm002io.setLastChgrId(FwUtil.getUserId());		// set [최종변경자ID]
			tbcmrtm002io.setLastChgPgmId(FwUtil.getPgmId());	// set [최종변경프로그램ID]
			tbcmrtm002io.setLastChgTrmNo(FwUtil.getTrmNo());	// set [최종변경단말번호]
			
			logger.debug("tbcmrtm002io(리얼타임전문번호테이블 UPDATE 세팅값)={}", tbcmrtm002io);
			
			//채번테이블 업데이트.
			iResult = this.cmb001dbio.updateOneTBCMRTM0020(tbcmrtm002io);
		}
		
		if(iResult == 1){
			logger.debug("mknoTgmNo(생성된 전문번호)={}", mknoTgmNo);
		}else{
			// SQL오류, '리얼타임전문번호입력 및 변경 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"리얼타임전문번호 입력 및 변경"});
		}
		
		return mknoTgmNo;
	}
}

