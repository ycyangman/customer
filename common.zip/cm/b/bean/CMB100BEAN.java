package cigna.cm.b.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB100DBIO;
import cigna.cm.b.io.SelectMultiTBCMRTM0014In;
import cigna.cm.b.io.SelectMultiTBCMRTM0014Out;
import cigna.cm.b.io.SelectMultiTBCMRTM0015In;
import cigna.cm.b.io.SelectMultiTBCMRTM0015Out;
import cigna.cm.b.io.SelectMultiTBCMRTM0016In;
import cigna.cm.b.io.SelectMultiTBCMRTM0016Out;
import cigna.cm.b.io.SelectMultiTBCMRTM0017Out;
import cigna.cm.b.io.SelectMultiTBCMRTM001aIn;
import cigna.cm.b.io.SelectMultiTBCMRTM001aOut;
import cigna.cm.b.io.SelectMultiTBCMRTM016aIn;
import cigna.cm.b.io.SelectMultiTBCMRTM016aOut;
import cigna.cm.b.io.SelectMultiTBCMRTM016bIn;
import cigna.cm.b.io.SelectMultiTBCMRTM016bOut;
import cigna.cm.b.io.SelectMultiTBCMRTM016cIn;
import cigna.cm.b.io.SelectMultiTBCMRTM016cOut;
import cigna.cm.b.io.SelectMultiTBDPEPY015cIn;
import cigna.cm.b.io.SelectMultiTBDPEPY015cOut;
import cigna.zz.BizCommUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;



/**
 * @file         cigna.cm.b.bean.CMB100BEAN.java
 * @filetype     java source file
 * @brief        처리현황조회
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                          성명                                                일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                            2016. 2. 24.       신규 작성
 *
 */
@KlafBean
public class CMB100BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/*****************************************
	 * 리얼타임 현황 조회 DBIO
	 *****************************************/
	@Autowired
	private CMB100DBIO	cmb100dbio;
    
	/**
     *  은행별 리얼타임 현황조회
     *
     * @param SelectMultiTBCMRTM001bIn
     * @return SelectMultiTBCMRTM001bOut
     */
    public List<SelectMultiTBCMRTM001aOut> getRltmPmPcond(SelectMultiTBCMRTM001aIn input) throws ApplicationException {
        List<SelectMultiTBCMRTM001aOut> list = null;
        // dpa999bean.chkBkkpClsYn(ioBean.getCustDpsDt(),ioBean.getPmPrcsDofOrgNo());
        // INPUT 값 체크
        
        logger.debug("mmj getFininCd {}" + input.getFininCd()); 
        logger.debug("mmj getTrsfDtFrom {}" + input.getTrsfDtFrom());
        logger.debug("mmj getTrsfDtTo {}" + input.getTrsfDtTo());
        logger.debug("mmj getTrsfFofOrgNo {}" + input.getTrsfFofOrgNo());
        logger.debug("mmj getPageCount {}" + input.getPageCount());
        logger.debug("mmj getPageNum {}" + input.getPageNum());
        
        list = cmb100dbio.selectMultiTBCMRTM001a(input);

        return list;
    }
    
    /**
     *  일자별 모바일 결제 현황 조회
     *
     * @param SelectMultiTBCMRTM001bIn
     * @return SelectMultiTBCMRTM001bOut
     */
    public List<SelectMultiTBCMRTM016aOut> getMblRltmPcond(SelectMultiTBCMRTM016aIn input) throws ApplicationException {
        List<SelectMultiTBCMRTM016aOut> list = null;
        // dpa999bean.chkBkkpClsYn(ioBean.getCustDpsDt(),ioBean.getPmPrcsDofOrgNo());
        // INPUT 값 체크
        
        logger.debug("mmj getInqDtFrom {}" + input.getInqDtFrom());
        logger.debug("mmj getInqDtTo {}" + input.getInqDtTo());
        logger.debug("mmj getTelDvsn {}" + input.getTelDvsn());
        logger.debug("mmj getTrsfFofOrgNo {}" + input.getTrsfFofOrgNo());
        logger.debug("mmj getBzDvsn {}" + input.getBzDvsn());
        logger.debug("mmj getPageCount {}" + input.getPageCount());
        logger.debug("mmj getPageNum {}" + input.getPageNum());
        
        list = cmb100dbio.selectMultiTBCMRTM016a(input);

        return list;
    }
    
    
    /**
     *  처리자별 모바일 결제 현황 조회
     *
     * @param SelectMultiTBCMRTM001bIn
     * @return SelectMultiTBCMRTM001bOut
     */
    public List<SelectMultiTBCMRTM016bOut> getPrcsEmplMblPcond(SelectMultiTBCMRTM016bIn input) throws ApplicationException {
        List<SelectMultiTBCMRTM016bOut> list = null;
        // dpa999bean.chkBkkpClsYn(ioBean.getCustDpsDt(),ioBean.getPmPrcsDofOrgNo());
        // INPUT 값 체크
        
        logger.debug("mmj getInqDtFrom {}" + input.getInqDtFrom());
        logger.debug("mmj getInqDtTo {}" + input.getInqDtTo());
        logger.debug("mmj getTelDvsn {}" + input.getTelDvsn());
        logger.debug("mmj getTrsfFofOrgNo {}" + input.getTrsfFofOrgNo());
        logger.debug("mmj getBzDvsn {}" + input.getBzDvsn());
        logger.debug("mmj getPageCount {}" + input.getPageCount());
        logger.debug("mmj getPageNum {}" + input.getPageNum());
        
        list = cmb100dbio.selectMultiTBCMRTM016b(input);

        return list;
    }
    
    /**
     *  처리자별 모바일 결제 현황 조회
     *
     * @param SelectMultiTBCMRTM001cIn
     * @return SelectMultiTBCMRTM001cOut
     */
    public List<SelectMultiTBCMRTM016cOut> getMblImmdtWdm(SelectMultiTBCMRTM016cIn input) throws ApplicationException {
        List<SelectMultiTBCMRTM016cOut> list = null;
        // dpa999bean.chkBkkpClsYn(ioBean.getCustDpsDt(),ioBean.getPmPrcsDofOrgNo());
        // INPUT 값 체크
        
        logger.debug("mmj getPrcsDtm {}" + input.getPrcsDtm());
        logger.debug("mmj getTrsfFofOrgNo {}" + input.getTrsfFofOrgNo());
        logger.debug("mmj getMembMpno {}" + input.getMembMpno());
        logger.debug("mmj getContNo {}" + input.getContNo());
        logger.debug("mmj getPageCount {}" + input.getPageCount());
        logger.debug("mmj getPageNum {}" + input.getPageNum());
        
//        String custDscNo = input.getCustDscNo();
//        custDscNo = SecuUtil.getEncValue(custDscNo, SecuUtil.EncType.Jumin);
        
        String membMpno =  SecuUtil.getEncValue(input.getMembMpno(), SecuUtil.EncType.membMpno);
        
        
        list = cmb100dbio.selectMultiTBCMRTM016c(input.getCustNo(), membMpno,  input.getContNo(), input.getPrcsDtm(), input.getTrsfFofOrgNo()
        		                                 ,input.getPageNum(), input.getPageCount());
        
        SecuUtil.doDecList(list);  //복호화

        return list;
    }
    
    /*****************************************
	 * 기관별 가상계좌송금내역 조회 		
	 * @param DPB240SVC00In 
	 * @return DPB240SVC00Out
	 * @throws ApplicationException
	 *****************************************/
	public List<SelectMultiTBDPEPY015cOut> getVactXc(SelectMultiTBDPEPY015cIn input)
			throws ApplicationException {

		List <SelectMultiTBDPEPY015cOut> dbMultiOut = null;

		/*********************
		 * *input 값 유효성 검사
		 *********************/
		//입금일자
		if(StringUtils.isEmpty(input.getBkkpSlipPropoStrtDt())){
			logger.error("입금일자가 없습니다.");
			throw new ApplicationException("APNBE0000", null);
		}
		
		//입금일자
		if(StringUtils.isEmpty(input.getBkkpSlipPropoEndDt())){
			logger.error("입금일자가 없습니다.");
			throw new ApplicationException("APNBE0000", null);
		}
				
		
		/*********************
		 * 금융기관코드 세팅
		 *********************/		
		String fininCd = null;
		
		if("000".equals(input.getFininCd())){
			fininCd = null;
		}
		else{
			fininCd = input.getFininCd();
		}
		
		logger.debug("cmb100bean {} " + input);
		
		/****************************************
		 * *기관가상계좌송금내역 조회
		 ****************************************/
		dbMultiOut = cmb100dbio.selectMultiTBDPEPY015c(input.getBkkpSlipPropoStrtDt(), input.getBkkpSlipPropoEndDt(), fininCd, input.getVactUsageCd(), input.getCustNo(), input.getPageNum(), input.getPageCount(), SecuUtil.getEncValue(input.getVactNo(), EncType.vactNo) );

		
		SecuUtil.doDecList(dbMultiOut);  //복호화

		return dbMultiOut;

	}
	
	/**
	 * 미취소건명세 조회
	 * @param trsfDt
	 * @param prcsBnk
	 * @param rcChnl
	 * @return
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMRTM0014Out> getPayTrsfCnclErrDtlsInq(SelectMultiTBCMRTM0014In input) throws ApplicationException
	{
		List<SelectMultiTBCMRTM0014Out> output = null;
		
		if (!StringUtils.hasText(input.getTrsfFofOrgNo())) {
			logger.debug("trsfFofOrgNo 입력오류");
			throw new ApplicationException( "APPAE0002", new Object[]{"처리창구"} );
		}
		if (!StringUtils.hasText(input.getTrsfDt())) {
			logger.debug("trsfDt 입력오류");
			throw new ApplicationException( "APPAE0002", new Object[]{"처리일자"} );
		}
		
	/*	if (!StringUtils.hasText(trsfPrcsEno)) {
			logger.debug("payDtTo 입력오류");
			throw new ApplicationException( "APPAE0002", new Object[]{"사원번호"} );
		}
		*/
		
		
		output = cmb100dbio.selectMultiTBCMRTM0014(input);
		
		SecuUtil.doDecList(output);  
		
		if(output == null || output.size() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return output;
	}
	
	/**
	 * 지급이체 창구별처리명세 조회
	 * @param String trsfDt 이체일자 
	 * @param String trsfDofOrgNo 이체지점조직번호
	 * @param String trsfFofOrgNo 이체영업소조직번호
	 * @param String payRcPathCd 지급접수경로코드
	 * @param String rltmTrmsDcd 리얼타임전송구분코드 
	 * @param String trsfPrcsFininCd 이체처리금융기관코드
	 * @return 지급이체 창구별처리명세 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMRTM0016Out> getPayTrsfCshwClPrcsDtls(SelectMultiTBCMRTM0016In input) throws ApplicationException {

		List<SelectMultiTBCMRTM0016Out> payTrsfList = null;
		
		if (StringUtils.isEmpty(input.getTrsfDt())) {
			throw new ApplicationException( "APPAE0002", new Object[]{"이체일자"} );
		}
		
		if (StringUtils.isEmpty(input.getTrsfFofOrgNo())) {
			throw new ApplicationException( "APPAE0002", new Object[]{"처리창구"} );
		}
		
		if ("000000".equals(input.getTrsfFofOrgNo())) {
			input.setTrsfFofOrgNo(null);
		}
		
		payTrsfList = cmb100dbio.selectMultiTBCMRTM0016(input.getTrsfDt(), input.getTrsfFofOrgNo(), 
				      input.getPayRcPathCd(), input.getRltmTrmsDcd(), input.getTrsfPrcsFininCd(),
				      input.getPageNum(), input.getPageCount());
		
		SecuUtil.doDecList(payTrsfList);  //복호화
		
		return payTrsfList;
	}
	
	/**
	 * 은행별 계좌이체 집계 조회
	 * @param trsfDt
	 * @param prcsBnk
	 * @param rcChnl
	 * @return
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMRTM0015Out> getPayTrsfTotClsPcondInq(SelectMultiTBCMRTM0015In input) throws ApplicationException
	{
		List<SelectMultiTBCMRTM0015Out> output = null;
		
		if (!StringUtils.hasText(input.getTrsfDt())) {
			logger.debug("payDtFr 입력오류");
			throw new ApplicationException( "APPAE0002", new Object[]{"이체일자"} );
		}
		
		//output = pam051dbio.selectMultiTBCMRTM0015(trsfDt, trsfPrcsFininCd, payRcPathCd);
		String moActBnkCd = BizCommUtil.getMoActBnkCd(BizCommUtil.PAY_MO_ACT);	// 2014.11.04기준 모계좌변경 적용[T1409260036]
		input.setMoActBnkCd(moActBnkCd);
		
		if ("000000".equals(input.getTrsfFofOrgNo())) {
			input.setTrsfFofOrgNo(null);
		}
		output = cmb100dbio.selectMultiTBCMRTM0015(input);
		
		if(output == null || output.size() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return output;
	}
	
	/**
	 * 지급이체 조건별 에러건검색 ==> 타이틀은 에러건 검색이나 현업요청(최대리님)으로 에러, 정상건 모두 조회_20130507
	 * @param String trsfDt 이체일자 
	 * @param String trsfRcd 이체결과코드
	 * @param String trsfAmt 이체금액
	 * @param String actNo 계좌번호
	 * @param String benfcNm 수익자명
	 * @param String benfcRrno 수익자주민등록번호
	 * @param String searchCd  조회구분 
	 * @return 지급이체 조건별 에러건 목록
	 * @throws ApplicationException
	 */
	public List<SelectMultiTBCMRTM0017Out> getCndtClErrDataInq(String trsfDt, String trsfRcd, String trsfAmt, String actNo, String benfcNm, String benfcRrno, int pageNum, int pageCount, String searchCd, String dpwdDcd) 
			                    throws ApplicationException {
		
		if (StringUtils.isEmpty(trsfDt)) {
			throw new ApplicationException( "APPAE0002", new Object[]{"이체일자"} );
		}
		if (!StringUtils.isEmpty(searchCd)) {
			if (StringUtils.isEmpty(trsfRcd) && StringUtils.isEmpty(trsfAmt) && StringUtils.isEmpty(actNo) && 
					StringUtils.isEmpty(benfcNm) && StringUtils.isEmpty(benfcRrno) ) {
				throw new ApplicationException( "APPAE0002", new Object[]{"검색내용"} );
			}
		} else {
			searchCd = "";
		}

		trsfRcd = StringUtils.nvl(trsfRcd);
		trsfAmt = StringUtils.nvl(trsfAmt);
		actNo = StringUtils.nvl(actNo);
		benfcNm = StringUtils.nvl(benfcNm);
		benfcRrno = StringUtils.nvl(benfcRrno);
		
		benfcRrno = SecuUtil.getEncValue(benfcRrno, SecuUtil.EncType.Jumin);
		actNo = SecuUtil.getEncValue(actNo, SecuUtil.EncType.Accnt);
		
		//이체오류자료 조회
		List<SelectMultiTBCMRTM0017Out> cndtClErrList  = null;
		
		if ("".equals(searchCd)) {	//전체
			cndtClErrList = cmb100dbio.selectMultiTBCMRTM001g(trsfDt, pageNum, pageCount, dpwdDcd);
		} 
		else if ("01".equals(searchCd)) {	//응답코드
			cndtClErrList = cmb100dbio.selectMultiTBCMRTM001f(trsfDt, trsfRcd, pageNum, pageCount, dpwdDcd);
		} else if ("02".equals(searchCd)) {		//이체금액
			cndtClErrList = cmb100dbio.selectMultiTBCMRTM001b(trsfDt, trsfAmt, pageNum, pageCount, dpwdDcd);
		} else if ("03".equals(searchCd)) {		//계좌번호
			cndtClErrList = cmb100dbio.selectMultiTBCMRTM001c(trsfDt, actNo,   pageNum, pageCount, dpwdDcd);
		} else if ("04".equals(searchCd)) {		//수익자
			cndtClErrList = cmb100dbio.selectMultiTBCMRTM001d(trsfDt, benfcNm, pageNum, pageCount, dpwdDcd);
		} else if ("05".equals(searchCd)) {		//수익자주민등록번호
			cndtClErrList = cmb100dbio.selectMultiTBCMRTM001e(trsfDt, benfcRrno, pageNum, pageCount, dpwdDcd);
		} else {
			throw new ApplicationException( "APPAE0002", new Object[]{"검색구분"} );
		}
		
		SecuUtil.doDecList(cndtClErrList);  //복호화
		
		return cndtClErrList;
	}
}

