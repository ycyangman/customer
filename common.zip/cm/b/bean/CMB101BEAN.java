package cigna.cm.b.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB101DBIO;
import cigna.cm.b.io.CMB101SVC01In;
import cigna.cm.b.io.CMB101SVC01Sub;
import cigna.cm.b.io.CMB101SVC02In;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;




/**
 * @file         cigna.cm.b.bean.CMB101BEAN.java
 * @filetype     java source file
 * @brief
 * @author       개발자(이보라)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(이보라)       2016. 10. 5.       신규 작성
 *
 */
@KlafBean
public class CMB101BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB101DBIO	cmb101dbio;
	
	/**
	 * 모계좌관리 조회	
	 * @return List<CMB101SVC01Sub>
	 * @throws ApplicationException
	 */
	public List<CMB101SVC01Sub> getMoActList(CMB101SVC01In input) throws ApplicationException {
		String propoDeptOrgNo = StringUtils.nvl(input.getPropoDeptOrgNo());
		String moActBzDcd =StringUtils.nvl(input.getMoActBzDcd()); 
		String moActNo = StringUtils.nvl(input.getMoActNo());
		String moActFininCd = StringUtils.nvl(input.getMoActFininCd());
		
		List<CMB101SVC01Sub> list = cmb101dbio.selectMultiTBCMRTM024a(propoDeptOrgNo, moActBzDcd, SecuUtil.getEncValue(moActNo, EncType.moActNo),moActFininCd);

		return list;
	}
	
	/**
	 * 모계좌관리 저장
	 * 
	 * @param NBE410SVC03In
	 * @return
	 * @throws ApplicationException
	 */
	public int getMergeMoActList(CMB101SVC02In input)
			throws ApplicationException {
		int rCnt = 0;
		int chkCnt = 0;
		String moActMgntNo = "";
		
		CMB101SVC01Sub list = new CMB101SVC01Sub();
		for(int i=0;i<input.getDsMoActList().size();i++){
			if("1".equals(input.getDsMoActList().get(i).getChkYn())){
				if ("I".equals((input.getDsMoActList().get(i).getFlgCd()))) {
					chkCnt = cmb101dbio.selectMultiTBCMRTM024b(SecuUtil.getEncValue(input.getDsMoActList().get(i).getMoActNo(), EncType.moActNo),
							input.getDsMoActList().get(i).getPropoDeptOrgNo(),
							input.getDsMoActList().get(i).getMoActBzDcd(),
							input.getDsMoActList().get(i).getMoActFininCd(),
							input.getDsMoActList().get(i).getAdptStrtDt());
					
					if (chkCnt > 0) {
						throw new ApplicationException("APCME0015", new Object[] { "모계좌" });
					}
					
					moActMgntNo = cmb101dbio.selectOneTBCMRTM024();
					
					list.setMoActMgntNo(moActMgntNo);
					
				} else {
					list.setMoActMgntNo(input.getDsMoActList().get(i).getMoActMgntNo());
				}
				list.setPropoDeptOrgNo(input.getDsMoActList().get(i).getPropoDeptOrgNo());
				list.setMoActBzDcd(input.getDsMoActList().get(i).getMoActBzDcd());
				list.setMoActFininCd(input.getDsMoActList().get(i).getMoActFininCd());
				String moActNo = SecuUtil.getEncValue(input.getDsMoActList().get(i).getMoActNo(), EncType.moActNo);
				list.setMoActNo(moActNo);
				list.setInstCmpyNo(input.getDsMoActList().get(i).getInstCmpyNo());
				list.setAdptStrtDt(input.getDsMoActList().get(i).getAdptStrtDt());
				list.setAdptEndDt(input.getDsMoActList().get(i).getAdptEndDt());
				list.setRegEno(FwUtil.getUserId());
				list.setDelYn("N");
				list.setLastChgrId(FwUtil.getUserId()); // 최종변경변경자ID
				list.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID
				list.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호
				
				rCnt += cmb101dbio.mergeOneTBCMRTM024(list);
			}
		}
		return rCnt;
	}
	
	/**
	 * 모계좌 중복 체크
	 * 
	 * @param NBE410SVC03In
	 * @return
	 * @throws ApplicationException
	 */
	public int getMoActCheck(CMB101SVC02In input)
			throws ApplicationException {

		int chkCnt = 0;
		int chkRowCnt = 0;
	
		for(int i=0;i<input.getDsMoActList().size();i++){
			if("1".equals(input.getDsMoActList().get(i).getChkYn())){
				if (!"S".equals((input.getDsMoActList().get(i).getFlgCd()))) {
					chkCnt = cmb101dbio.selectMultiTBCMRTM024c(SecuUtil.getEncValue(input.getDsMoActList().get(i).getMoActNo(), EncType.moActNo));
					if (chkCnt > 0 ){
						chkRowCnt++;
					}
				}
			}
		}
		return chkRowCnt;
	}
	
	
}

