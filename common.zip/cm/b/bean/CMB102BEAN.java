package cigna.cm.b.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB102DBIO;
import cigna.cm.b.io.CMB102SVC01In;
import cigna.cm.b.io.CMB102SVC01Sub;



/**
 * @file         cigna.cm.b.bean.CMB103BEAN.java
 * @filetype     java source file
 * @brief        가상계좌통계
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                           성명                                               일자                                     변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 12. 19.      신규 작성
 *
 */
@KlafBean
public class CMB102BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/*****************************************
	 * 가상계좌통계
	 *****************************************/
	@Autowired
	private CMB102DBIO	cmb102dbio;
	
	
	/**
	 * 가상계좌통계 조회	
	 * @return List<TBCMRTM023Io> rtnResult
	 * @throws ApplicationException
	 */
	public List<CMB102SVC01Sub> getVactDlngLst(CMB102SVC01In input) throws ApplicationException {
		
		List<CMB102SVC01Sub> rtnResult = null; // Return value
		
		/* INPUT VALIDATION CHECKING ... */
//		if(input.getPageNum() <= 0) {
//			//{0}업무 IT 담당자에게 문의해야 합니다.( 오류내용:화면에서 전송된 페이지 번호가 0이하 입니다. )
//			throw new ApplicationException("KIERE0016", new String[]{"${job_team_name}"});
//		}
//		if(input.getPageCount() <= 0) {
//			//{0}업무 IT 담당자에게 문의해야 합니다.( 오류내용:화면에서 전송된 페이지 크기가 0이하 입니다. )
//			throw new ApplicationException("KIERE0017", new String[]{"${job_team_name}"});
//		}
		
		if (StringUtils.isEmpty(input.getTrsfYm())) {
			throw new ApplicationException("APPRE0000", new Object[]{"조회월"}, new Object[]{"조회월"});
		}
	     
		//가상계좌통계 조회
		rtnResult = this.cmb102dbio.selectMultiTBDPEPY015a(input.getTrsfYm(), input.getFininCd(), input.getVactUsageCd());
		
		return rtnResult;

	}

	

}

