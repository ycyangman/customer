package cigna.cm.b.bean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA002BEAN;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.b.dbio.CMB103DBIO;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.io.CMB103SVC01In;
import cigna.cm.b.io.CMB103SVC01Out;
import cigna.cm.b.io.CMB103SVC02In;
import cigna.cm.b.io.CMB103SVC02Sub;
import cigna.cm.b.io.CMB103SVC03In;
import cigna.cm.b.io.CMB103SVC03Out;
import cigna.cm.b.io.CMB103SVC04In;
import cigna.cm.b.io.CMB103SVC04Out;
import cigna.cm.b.io.TBCMRTM026Io;
import cigna.cm.b.io.TBCSPRF001Io;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;



/**
 * @file         cigna.cm.b.bean.CMB103BEAN.java
 * @filetype     java source file
 * @brief        통합보험료출금
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                           성명                                               일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                            2016.12.19.        신규 작성
 *
 */
@KlafBean
public class CMB103BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/*****************************************
	 * 통합보험료출금
	 *****************************************/
	@Autowired
	private CMB103DBIO	cmb103dbio;
	
	@Autowired
	private CMA002BEAN	cma002bean;
	
	@Autowired
	private CMB001BEAN	cmb001bean;
	
	
	
	/**
	 * 통합보험료출금	
	 * @return CMB103SVC01Out rtnResult
	 * @throws ApplicationException
	 */	
	public CMB103SVC01Out procCallTgmTrrv(CMB103SVC01In input) throws ApplicationException {
		
		CMB103SVC01Out rtnResult = new CMB103SVC01Out();
		
//		String custDscNo = "";
		
		TBCSPRF001Io tbcsprf001Io = cmb103dbio.selectOneTBCNBAS001a(input.getContNo());
		
		if (tbcsprf001Io == null ) {
			throw new ApplicationException("APDPE0094", new String[] { "계약자정보가 " });
		}
		
		//custDscNo = SecuUtil.getDecValue(tbcsprf001Io.getCustDscNo(), EncType.custDscNo);
		
		CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(FwUtil.getUserId());
		
        if (StringUtils.isEmpty(input.getAchdRrno()))
        {
        	//입력하신 {0}항목을 확인하여 주세요.
        	throw new ApplicationException("APCSE0001", new String[] { "예금주 주민등록번호" });
        }


        if (StringUtils.isEmpty(input.getBnkCd()))
        {
        	//입력하신 {0}항목을 확인하여 주세요.
        	throw new ApplicationException("APCSE0001", new String[] { "은행코드" });
        }
        if (StringUtils.isEmpty(input.getActNo()))
        {
        	//입력하신 {0}항목을 확인하여 주세요.
        	throw new ApplicationException("APCSE0001", new String[] { "계좌번호" });
        }
        
        
        //출수납거래번호 채번
        String pyrcTxNo = getCmPyrcTxNo();
        
        
        TBCMRTM026Io tbcmrtm026In = new  TBCMRTM026Io();
        
        tbcmrtm026In.setPyrcTxNo(pyrcTxNo);
        tbcmrtm026In.setTrsfDt(DateUtils.getCurrentDate(2));
        tbcmrtm026In.setTrsfDofOrgNo(commEmplInfo.getDofOrgNo());
        tbcmrtm026In.setTrsfFofOrgNo(FwUtil.getDeptCd());
        tbcmrtm026In.setTrsfPrcsEno(FwUtil.getUserId());
        tbcmrtm026In.setContNo(input.getContNo());          
        tbcmrtm026In.setTrsfAmt        (input.getTrsfAmt());   // set [이체금액]
        tbcmrtm026In.setFininCd(input.getBnkCd());              // set [대표은행코드]
        tbcmrtm026In.setActMgntNo      (input.getActMgntNo());       // set [계좌관리번호]
        tbcmrtm026In.setPropoDeptOrgNo(input.getPropoDeptRrgNo());
        tbcmrtm026In.setRltmTrsfTrmsDcd    ("1");                           // set [리얼타임이체전송구분코드:미이체]
        tbcmrtm026In.setLastChgrId         (FwUtil.getUserId());            // set [최종변경자ID]
        tbcmrtm026In.setLastChgPgmId       (FwUtil.getPgmId());             // set [최종변경프로그램ID]
        tbcmrtm026In.setLastChgTrmNo       (FwUtil.getTrmNo());             // set [최종변경단말번호]
        
        this.insertTBCMRTM026(tbcmrtm026In);
        
        TrsfTrrvPrcsInfo trsftrrvprcsinfo = new TrsfTrrvPrcsInfo();

        trsftrrvprcsinfo.setOptnKey        ("S");                        // set [옵션키: sync 방식]
        trsftrrvprcsinfo.setPrcsCd         ("02");                       // set [처리코드 : 자동집금처리(출금,집금)]
       	trsftrrvprcsinfo.setChnlDcd    ("0012");                         // set [채널구분코드]
       	trsftrrvprcsinfo.setPayRcPathCd("WB");                         // set [지급접수경로코드]
        trsftrrvprcsinfo.setPayRcMcd   ("TW");                         // set [지급접수방법코드]
        trsftrrvprcsinfo.setPrcsDt         (DateUtils.getCurrentDate(2));// set [처리일자]

        trsftrrvprcsinfo.setPyprcPathCd    ("R");                         // set [지급처리경로코드:전액]
        trsftrrvprcsinfo.setTrsfAmt        (input.getTrsfAmt());   // set [이체금액]
        trsftrrvprcsinfo.setBenfcCustNo    (tbcsprf001Io.getCustNo());     // set [수익자고객번호]
        trsftrrvprcsinfo.setContrCustNo    (tbcsprf001Io.getCustNo());     // set [계약자고객번호]
        trsftrrvprcsinfo.setDpwdDcd        ("1");                        // set [입출금구분코드 : 입금]
        trsftrrvprcsinfo.setActMgntNo      (input.getActMgntNo());       // set [계좌관리번호]
        trsftrrvprcsinfo.setBnkCd          (input.getBnkCd());              // set [대표은행코드]
        trsftrrvprcsinfo.setActNo          (input.getActNo());           // set [계좌번호]
        trsftrrvprcsinfo.setAchdNm         (input.getAchdNm());          // set [예금주명]
        trsftrrvprcsinfo.setAchdRrno       (input.getAchdRrno());        // set [예금주주민등록번호]
        trsftrrvprcsinfo.setNrmCnclDcd     ("0");                        // set [정상취소구분코드 : 정상]
        trsftrrvprcsinfo.setBzDcd          ("CM");                       // set [업무구분코드]
        trsftrrvprcsinfo.setBzTmKeyVl      (pyrcTxNo);          // set [업무팀KEY값 : 출수납거래번호]
        trsftrrvprcsinfo.setReqBzTmBean    ("CMB103BEAN");               // set [요청파트BEAN]
        trsftrrvprcsinfo.setReqBzTmMethod  ("procCallTgmTrrv");         // set [요청파트Method]
        trsftrrvprcsinfo.setPyrcDofOrgNo(commEmplInfo.getDofOrgNo());
        trsftrrvprcsinfo.setPyrcFofOrgNo(FwUtil.getDeptCd());
        trsftrrvprcsinfo.setPyrcPrcsEno(FwUtil.getUserId());
		trsftrrvprcsinfo.setWtrsfAsntSysCd(input.getWtrsfAsntSysCd());// set [출금이체동의시스템코드]
		trsftrrvprcsinfo.setWtrsfAsntEvidDcd(input.getWtrsfAsntEvidDcd());// set [출금이체동의증빙구분코드]
		trsftrrvprcsinfo.setWtrsfAsntEvidNo(input.getWtrsfAsntEvidNo());// set [출금이체동의증빙번호]
		trsftrrvprcsinfo.setWtrsfAsntDcd("1");// set [출금이체동의구분코드] - '1' RTB
		trsftrrvprcsinfo.setWtrsfAsntRcDcd("03");// set [출금이체동의접수구분코드] - '03' 보험료납입
		trsftrrvprcsinfo.setContNo(input.getContNo());// set [계약번호] - 대표증권번호
		trsftrrvprcsinfo.setContrNm(tbcsprf001Io.getCustNm());// set [계약자명]
		trsftrrvprcsinfo.setWtrsfAsntDt		(input.getWtrsfAsntDt());// set [출금동의일자]
		trsftrrvprcsinfo.setWtrsfAsntVcrecStrtDtm(input.getWtrsfAsntVcrecStrtDtm());// set [출금이체동의녹취시작일시]
		trsftrrvprcsinfo.setWtrsfAsntVcrecEndDtm(input.getWtrsfAsntVcrecEndDtm());// set [출금이체동의녹취종료일시]
		trsftrrvprcsinfo.setChrgpEno(FwUtil.getUserId());// set [담당자사원번호]
		trsftrrvprcsinfo.setPropoDeptOrgNo(input.getPropoDeptRrgNo());
		
        
        logger.debug("*** MMJ trsftrrvprcsinfo : {}", trsftrrvprcsinfo);
        
           	   
         //은행별 이체처리(대외계)
        String answCd = this.callTrsfPrcs(trsftrrvprcsinfo);
        
        rtnResult.setAnswCd(answCd);
        
//        if ("CMB103M0".equals(FwUtil.getScreenId())) {
//			
//			try {
//				logger.error("==== TIMEOUT TEST START ====");
//				Thread.sleep(30000); // 1000 = 1sec
//				logger.error("==== TIMEOUT TEST END ====");
//				throw new ApplicationException("APCME0054", new String[] {"타임아웃"});
//			} catch (InterruptedException ie) {
//				logger.error("==== TIMEOUT TEST ERROR ====");
//				throw new ApplicationException("APCME0054", new String[] {"타임아웃 에러발생"});
//			}
//		}
        
        if (!StringUtils.isEmpty(answCd)) {
        	
        	if ("0000".equals(answCd)) {
        		cmb103dbio.updateOneTBCMRTM026a("2", answCd, pyrcTxNo);
        	} else {
        		cmb103dbio.updateOneTBCMRTM026a("3", answCd, pyrcTxNo);
        	}
        }
				
		return rtnResult;

	}
	
	/**
	 * RT이체_리얼타임신청결과 테이블 업데이트
	 * @param TBCMRTM026In : 통합출금관리
	 * @return void
	 * @throws ApplicationException
	 */	
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public void insertTBCMRTM026(TBCMRTM026Io input) throws ApplicationException {
		
		int iResult =0;
	
		iResult = cmb103dbio.insertOneTBCMRTM026a(input);

		if (iResult != 1) {
			// SQL오류, '신계약리얼타임이체신청결과 테이블 DBIO 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APNBE0046",
					new Object[] { "통합출금관리" });
		}
	}
	
	/**
	 * 출수납거래번호 생성
	 * @param 없음
	 * @return 출수납거래번호
	 * @throws ApplicationException
	 */

    @TransactionalOperation(propagation= Propagation.REQUIRES_NEW)
    public String getCmPyrcTxNo () throws ApplicationException {

		return  this.cmb103dbio.selectOneTBCMRTM026a();

	} 
	
	/**
	 * 리얼타임처리 조회	
	 * @return List<TBCMRTM023Io> rtnResult
	 * @throws ApplicationException
	 */
	public List<CMB103SVC02Sub> getTrsfDlngLst(CMB103SVC02In input) throws ApplicationException {
		
		List<CMB103SVC02Sub> rtnResult = null; // Return value
		
		/* INPUT VALIDATION CHECKING ... */
//		if(input.getPageNum() <= 0) {
//			//{0}업무 IT 담당자에게 문의해야 합니다.( 오류내용:화면에서 전송된 페이지 번호가 0이하 입니다. )
//			throw new ApplicationException("KIERE0016", new String[]{"${job_team_name}"});
//		}
//		if(input.getPageCount() <= 0) {
//			//{0}업무 IT 담당자에게 문의해야 합니다.( 오류내용:화면에서 전송된 페이지 크기가 0이하 입니다. )
//			throw new ApplicationException("KIERE0017", new String[]{"${job_team_name}"});
//		}
		
		if (StringUtils.isEmpty(input.getTrsfDt())) {
			throw new ApplicationException("APPRE0000", new Object[]{"처리일자"}, new Object[]{"처리일자"});
		}
	     
		//리얼타임처리 조회
		rtnResult = this.cmb103dbio.selectMultiTBCMRTM026a(input.getTrsfDt(), input.getContNo(), input.getPropoDeptOrgNo());
		
		SecuUtil.doDecList(rtnResult);
		
		return rtnResult;

	}
	
	/**
	 * 고객 조회	
	 * @return List<TBCMRTM023Io> rtnResult
	 * @throws ApplicationException
	 */
	public CMB103SVC04Out getCust(CMB103SVC04In input) throws ApplicationException {
		
		CMB103SVC04Out rtnResult = new CMB103SVC04Out(); // Return value
		
		
		
		/* INPUT VALIDATION CHECKING ... */
//		if(input.getPageNum() <= 0) {
//			//{0}업무 IT 담당자에게 문의해야 합니다.( 오류내용:화면에서 전송된 페이지 번호가 0이하 입니다. )
//			throw new ApplicationException("KIERE0016", new String[]{"${job_team_name}"});
//		}
//		if(input.getPageCount() <= 0) {
//			//{0}업무 IT 담당자에게 문의해야 합니다.( 오류내용:화면에서 전송된 페이지 크기가 0이하 입니다. )
//			throw new ApplicationException("KIERE0017", new String[]{"${job_team_name}"});
//		}
		
		if (StringUtils.isEmpty(input.getContNo())) {
			throw new ApplicationException("APPRE0000", new Object[]{"계약번호"}, new Object[]{"계약번호"});
		}
	     
		//리얼타임처리 조회
		TBCSPRF001Io tbcsprf001Io = this.cmb103dbio.selectOneTBCNBAS001a(input.getContNo());
		
		if (tbcsprf001Io != null) {
			rtnResult.setCustNo(tbcsprf001Io.getCustNo());
			rtnResult.setCustNm(tbcsprf001Io.getCustNm());
			rtnResult.setCustDscNo(SecuUtil.getDecValue(tbcsprf001Io.getCustDscNo(), EncType.custDscNo) );
		}
		return rtnResult;

	}

	/**
     * 은행별 이체처리(대외계)
     * @param TrsfTrrvPrcsInfo(이체처리 input) , 채널구분코드, 은행코드
     * @return 응답코드
     * @throws ApplicationException
     */
    @TransactionalOperation(propagation= Propagation.REQUIRES_NEW)
    private String callTrsfPrcs(TrsfTrrvPrcsInfo trsftrrvprcsinfo)  throws ApplicationException
    {
    	String answCd = "";
    	try {
    		
    		trsftrrvprcsinfo = cmb001bean.callTgmTrrv(trsftrrvprcsinfo);               

            answCd = trsftrrvprcsinfo.getBnkAnswCd();   //응답코드

    	} catch (ApplicationException e) {
			
    		throw e; 	

		} catch (Exception e) {
			throw new ApplicationException("APNBE0218", new Object[]{"RT확인오류"}, new Object[]{"RT확인오류"});
		}
    	               
        logger.info("★★★★★★★★ 응답코드 [{}]", trsftrrvprcsinfo);
    	
    	return  answCd;
    }

    
    /**
     * 리얼타임이체중 처리
     *
     * @param DPB300SVC01In
     * @return int
     */
    public CMB103SVC03Out insertRltmTrsfImp(CMB103SVC03In input) throws ApplicationException {

    	CMB103SVC03Out out = new CMB103SVC03Out();
        
        TrsfTrrvPrcsInfo trsftrrvprcsinfo = null;
        
//        // 이체중처리는 통합모니터링 팀 외에는 처리 불가
//	    if(!"101115".equals(FwUtil.getDeptCd())) {
//	    	logger.error("처리권한이 없습니다. 통합모니터링팀에 문의바랍니다.");
//            throw new ApplicationException("APDPE0276", new String[] {"통합모니터링"});  //처리권한이 없습니다. 통합모니터링팀에 문의바랍니다.
//	    }


        // 사용자 암호 유효성 체크 사용자 암호 유효성 체크
        // 1. INPUT: 사원번호, 암호
        // CMA301BEAN getLoginInfo(input.getPrcsEmpno(),input.getPswd())
        // "리얼타임이체 TABLE UPDATE
        // IN.처리구분코드 = '1'(입금) 일때 1. 조회 KEY : 출수납거래번호, 계약번호
        // 수정 항목:
        // IF IN.처리구분코드 = '1'(입금)
        // 리얼타임이체전송구분코드 = '2' (정상)
        // 금융기관처리결과코드 = '0000'
        //
        // 2. 리얼타임이체 UPDATE SQLID 호출
        
        int prcsCnt = 0;
        
        CommEmplInfo commEmplInfo = cma002bean.getEmplInfo(FwUtil.getUserId());
        
        // "리얼타임이체 전문 재전송
        // 1. IF IN.처리구분코드 = '2'(결과재요청) 이면
        // 리얼타임전문번호로 리얼타임이체전문 재전송
        // PAA003BEAN setPayRtTrsf()
        List<CMB103SVC02Sub> dsList = input.getDsCMB103SVC02Sub();
        int cnt = 0;
        for (CMB103SVC02Sub outList : dsList) {
            if ("1".equals(outList.getChkYn())) {
            	
            	 /**********************************************************
       	          * 은행별 이체처리(대외계)
       	          *********************************************************/
            	trsftrrvprcsinfo = new TrsfTrrvPrcsInfo();
            	
            	TBCSPRF001Io tbcsprf001Io = cmb103dbio.selectOneTBCNBAS001a(outList.getContNo());
        		
        		if (tbcsprf001Io == null ) {
        			throw new ApplicationException("APDPE0094", new String[] { "계약자정보가 " });
        		}

            	trsftrrvprcsinfo.setOptnKey        ("S");                        // set [옵션키: sync 방식]
            	trsftrrvprcsinfo.setPrcsCd         ("03");                       // set [처리코드 :  이체결과 )]
            	trsftrrvprcsinfo.setRltmTrsfTxNo   (outList.getRltmTrsfTxNo()) ;   //리얼타임이체거래번호

            	
        		trsftrrvprcsinfo.setChnlDcd    ("0001");                         // set [채널구분코드]
        		trsftrrvprcsinfo.setPayRcPathCd("WB");                         // set [지급접수경로코드]
        		trsftrrvprcsinfo.setPayRcMcd   ("TW");                         // set [지급접수방법코드]
            	

            	trsftrrvprcsinfo.setPrcsDt         (DateUtils.getCurrentDate(2));// set [처리일자]

            	trsftrrvprcsinfo.setPyprcPathCd    ("R");                         // set [지급처리경로코드:전액]
            	trsftrrvprcsinfo.setTrsfAmt        (outList.getTrsfAmt());   // set [이체금액]
            	trsftrrvprcsinfo.setBenfcCustNo    (tbcsprf001Io.getCustNo());     // set [수익자고객번호]
            	trsftrrvprcsinfo.setContrCustNo    (tbcsprf001Io.getCustNo());     // set [계약자고객번호]
            	trsftrrvprcsinfo.setDpwdDcd        ("1");                        // set [입출금구분코드 : 입금]
            	trsftrrvprcsinfo.setActMgntNo      (outList.getActMgntNo());       // set [계좌관리번호]         

            	trsftrrvprcsinfo.setBnkCd          (outList.getFininCd());              // set [대표은행코드]
            	trsftrrvprcsinfo.setActNo          (SecuUtil.getDecValue(outList.getActNo(), EncType.actNo) );           // set [계좌번호]


            	trsftrrvprcsinfo.setAchdNm         (outList.getAchdNm());          // set [예금주명]
            	trsftrrvprcsinfo.setAchdRrno       (SecuUtil.getDecValue(outList.getAchdRrno(), EncType.achdRrno));        // set [예금주주민등록번호]
            	trsftrrvprcsinfo.setNrmCnclDcd     ("0");                        // set [정상취소구분코드 : 정상]
            	trsftrrvprcsinfo.setBzDcd          ("CM");                       // set [업무구분코드]
            	trsftrrvprcsinfo.setBzTmKeyVl      (outList.getPyrcTxNo());                   // set [업무팀KEY값 : 출수납거래번호]
            	trsftrrvprcsinfo.setReqBzTmBean    ("CMB103BEAN");               // set [요청파트BEAN]
            	trsftrrvprcsinfo.setReqBzTmMethod  ("insertRltmTrsfImp");         // set [요청파트Method]

            	trsftrrvprcsinfo.setPyrcDofOrgNo(commEmplInfo.getDofOrgNo());
                trsftrrvprcsinfo.setPyrcFofOrgNo(FwUtil.getDeptCd());
                trsftrrvprcsinfo.setPyrcPrcsEno(FwUtil.getUserId());

            	logger.debug("*** MMJ trsftrrvprcsinfo : {}", trsftrrvprcsinfo);

            	trsftrrvprcsinfo = cmb001bean.callTgmTrrv(trsftrrvprcsinfo);

            	String answCd = trsftrrvprcsinfo.getBnkAnswCd();
                
            	if (!StringUtils.isEmpty(answCd)) {
                	
                	if ("0000".equals(answCd)) {
                		cmb103dbio.updateOneTBCMRTM026a("2", answCd, outList.getPyrcTxNo());
                		outList.setPrcsRst("정상");
                	} else {
                		cmb103dbio.updateOneTBCMRTM026a("3", answCd, outList.getPyrcTxNo());
                		Map<String, String> map = new HashMap<String, String>();
                		try {
                            map = this.getMapFinErrCd();
                        } catch (ApplicationException e) {
                        	logger.error("ApplicationException : " + e.getMessage());
                        }
                        
                        String finRcdNm = ""; // 자동이체결과코드명 
                        logger.debug("은행코드결과코드{}" ,outList.getFininCd() + answCd);
                        if (!StringUtils.isEmpty(answCd)) {
//                        	 finRcdNm = dpb260bean.getMapFinErrCd(input.getBnkCd() + output.getAnswCd());            
                        	 finRcdNm = StringUtils.isEmpty(map.get(outList.getFininCd() + answCd)) ? "기타오류" : map.get(outList.getFininCd() + answCd);
                        }             

                        outList.setPrcsRst(finRcdNm);
                	}
                }
            	
            	dsList.set(cnt++, outList);
            	prcsCnt++;
            } else {
                dsList.set(cnt++, outList);
            }
        }
        out.setOutListCnt(dsList.size());
        out.setDsCMB103SVC02Sub(dsList);


        out.setRstCnt(prcsCnt);

        return out;
    }
    
    /**
     * 은행오류코드 변환
     *
     * @param fofOrgNo
     * @return fofOrgNo
     */
    public static Map<String, String> getMapFinErrCd() throws ApplicationException {

        Map<String, String> map = new HashMap<String, String>();
        map.put("003U211", "계좌오류");
        map.put("003U212", "계좌오류");
        map.put("0040125", "계좌오류");
        map.put("0050122", "계좌오류");
        map.put("0050132", "계좌오류");
        map.put("005C204", "계좌오류");
        map.put("005C604", "계좌오류");
        map.put("005M576", "계좌오류");
        map.put("005U211", "계좌오류");
        map.put("0100125", "계좌오류");
        map.put("0110125", "계좌오류");
        map.put("0120125", "계좌오류");
        map.put("0130125", "계좌오류");
        map.put("0140125", "계좌오류");
        map.put("0150125", "계좌오류");
        map.put("0202011", "계좌오류");
        map.put("0203050", "계좌오류");
        map.put("021U212", "계좌오류");
        map.put("021U455", "계좌오류");
        map.put("021U453", "계좌오류");
        map.put("0230115", "계좌오류");
        map.put("0230211", "계좌오류");
        map.put("0230212", "계좌오류");
        map.put("0260001", "계좌오류");
        map.put("0260012", "계좌오류");
        map.put("0266282", "계좌오류");
        map.put("0266537", "계좌오류");
        map.put("0270015", "계좌오류");
        map.put("0270158", "계좌오류");
        map.put("0311302", "계좌오류");
        map.put("0320010", "계좌오류");
        map.put("0320011", "계좌오류");
        map.put("0322001", "계좌오류");
        map.put("0320418", "계좌오류");
        map.put("0341030", "계좌오류");
        map.put("0346230", "계좌오류");
        map.put("0370102", "계좌오류");
        map.put("0390102", "계좌오류");
        map.put("0390115", "계좌오류");
        map.put("081U113", "계좌오류");
        map.put("081U211", "계좌오류");
        map.put("081U212", "계좌오류");
        map.put("071Z144", "계좌오류");
        map.put("0021012", "계좌오류");
        map.put("071E311", "계좌오류");
        map.put("007H027", "계좌오류");
        map.put("0450125", "계좌오류");
        map.put("0480125", "계좌오류");
        map.put("0350125", "계좌오류");
        map.put("003U252", "주민오류");
        map.put("0040116", "주민오류");
        map.put("0050116", "주민오류");
        map.put("0100116", "주민오류");
        map.put("0110116", "주민오류");
        map.put("0120116", "주민오류");
        map.put("0130116", "주민오류");
        map.put("0140116", "주민오류");
        map.put("0150116", "주민오류");
        map.put("0203000", "주민오류");
        map.put("0230315", "주민오류");
        map.put("0230405", "주민오류");
        map.put("0260201", "주민오류");
        map.put("0270018", "주민오류");
        map.put("0312522", "주민오류");
        map.put("0322001", "주민오류");
        map.put("0344605", "주민오류");
        map.put("0370405", "주민오류");
        map.put("0390405", "주민오류");
        map.put("081U252", "주민오류");
        map.put("071E254", "주민오류");
        map.put("071E436", "주민오류");
        map.put("071Z108", "주민오류");
        map.put("0020107", "주민오류");
        map.put("071F719", "주민오류");
        map.put("007R062", "주민오류");
        map.put("0450116", "주민오류");
        map.put("0480116", "주민오류");
        map.put("0350116", "주민오류");
        map.put("0230106", "과목오류");
        map.put("0260033", "과목오류");
        map.put("0266533", "과목오류");
        map.put("0270012", "과목오류");
        map.put("071Z087", "과목오류");
        map.put("0370419", "과목오류");
        map.put("0390106", "과목오류");
        map.put("071E180", "과목오류");
        map.put("007R013", "과목오류");
        map.put("003U214", "잔고부족");
        map.put("0040133", "잔고부족");
        map.put("0050133", "잔고부족");
        map.put("005C224", "잔고부족");
        map.put("0100133", "잔고부족");
        map.put("0110133", "잔고부족");
        map.put("0120133", "잔고부족");
        map.put("0130133", "잔고부족");
        map.put("0140133", "잔고부족");
        map.put("0150133", "잔고부족");
        map.put("0201404", "잔고부족");
        map.put("0202071", "잔고부족");
        map.put("0205608", "잔고부족");
        map.put("0230608", "잔고부족");
        map.put("0261500", "잔고부족");
        map.put("0270113", "잔고부족");
        map.put("0313601", "잔고부족");
        map.put("0313610", "잔고부족");
        map.put("0320067", "잔고부족");
        map.put("0344730", "잔고부족");
        map.put("0370104", "잔고부족");
        map.put("0390104", "잔고부족");
        map.put("081U214", "잔고부족");
        map.put("0310133", "잔고부족");
        map.put("021U343", "잔고부족");
        map.put("088U343", "잔고부족");
        map.put("071Z207", "잔고부족");
        map.put("0021000", "잔고부족");
        map.put("071E659", "잔고부족");
        map.put("007T042", "잔고부족");
        map.put("0450133", "잔고부족");
        map.put("0480133", "잔고부족");
        map.put("0350133", "잔고부족");
        map.put("003U223", "해약계좌");
        map.put("0040129", "해약계좌");
        map.put("005M587", "해약계좌");
        map.put("005D207", "해약계좌");
        map.put("005D208", "해약계좌");
        map.put("005M101", "해약계좌");
        map.put("005M109", "해약계좌");
        map.put("005M154", "해약계좌");
        map.put("005M586", "해약계좌");
        map.put("0202044", "해약계좌");
        map.put("0202076", "해약계좌");
        map.put("0202134", "해약계좌");
        map.put("0205411", "해약계좌");
        map.put("0210411", "해약계좌");
        map.put("0230411", "해약계좌");
        map.put("0260040", "해약계좌");
        map.put("0260741", "해약계좌");
        map.put("0261383", "해약계좌");
        map.put("0270130", "해약계좌");
        map.put("0270163", "해약계좌");
        map.put("0312401", "해약계좌");
        map.put("0312402", "해약계좌");
        map.put("0312403", "해약계좌");
        map.put("0370109", "해약계좌");
        map.put("0390109", "해약계좌");
        map.put("081U223", "해약계좌");
        map.put("071Z113", "해약계좌");
        map.put("0020204", "해약계좌");
        map.put("071E257", "해약계좌");
        map.put("0450117", "해약계좌");
        map.put("0480117", "해약계좌");
        map.put("0350117", "해약계좌");
        map.put("003U215", "제한계좌");
        map.put("0040134", "제한계좌");
        map.put("0050134", "제한계좌");
        map.put("0202073", "제한계좌");
        map.put("0202095", "제한계좌");
        map.put("0205409", "제한계좌");
        map.put("0210409", "제한계좌");
        map.put("0230409", "제한계좌");
        map.put("0261111", "제한계좌");
        map.put("0261323", "제한계좌");
        map.put("0270051", "제한계좌");
        map.put("0270106", "제한계좌");
        map.put("0312416", "제한계좌");
        map.put("0312427", "제한계좌");
        map.put("0312461", "제한계좌");
        map.put("0320041", "제한계좌");
        map.put("0320110", "제한계좌");
        map.put("0320126", "제한계좌");
        map.put("0370417", "제한계좌");
        map.put("0390110", "제한계좌");
        map.put("081U215", "제한계좌");
        map.put("071Z114", "제한계좌");
        map.put("071Z115", "제한계좌");
        map.put("071Z120", "제한계좌");
        map.put("0020202", "제한계좌");
        map.put("071E258", "제한계좌");
        map.put("071E259", "제한계좌");
        map.put("071E276", "제한계좌");
        map.put("0230111", "압류계좌");
        map.put("0272470", "압류계좌");
        map.put("0273084", "압류계좌");
        map.put("0314350", "압류계좌");
        map.put("071A074", "압류계좌");
        map.put("071E353", "압류계좌");
        map.put("0390111", "압류계좌");
        map.put("007D056", "압류계좌");
        map.put("0040150", "증명계좌");
        map.put("0050150", "증명계좌");
        map.put("0100150", "증명계좌");
        map.put("0110150", "증명계좌");
        map.put("0120150", "증명계좌");
        map.put("0130150", "증명계좌");
        map.put("0140150", "증명계좌");
        map.put("0150150", "증명계좌");
        map.put("0202072", "증명계좌");
        map.put("021U346", "증명계좌");
        map.put("0230402", "증명계좌");
        map.put("0260176", "증명계좌");
        map.put("0270114", "증명계좌");
        map.put("0320017", "증명계좌");
        map.put("0390114", "증명계좌");
        map.put("007D095", "증명계좌");
        map.put("0450150", "증명계좌");
        map.put("0480150", "증명계좌");
        map.put("0350150", "증명계좌");
        map.put("0030000", "정상");
        map.put("0040000", "정상");
        map.put("0050000", "정상");
        map.put("0100000", "정상");
        map.put("0110000", "정상");
        map.put("0120000", "정상");
        map.put("0130000", "정상");
        map.put("0140000", "정상");
        map.put("0150000", "정상");
        map.put("0200000", "정상");
        map.put("0210000", "정상");
        map.put("0230000", "정상");
        map.put("0260000", "정상");
        map.put("0270000", "정상");
        map.put("0310000", "정상");
        map.put("0320000", "정상");
        map.put("0370000", "정상");
        map.put("0390000", "정상");
        map.put("0810000", "정상");
        map.put("0710000", "정상");
        map.put("0720000", "정상");
        map.put("0730000", "정상");
        map.put("0740000", "정상");
        map.put("0750000", "정상");
        map.put("0340000", "정상");
        map.put("0020000", "정상");
        map.put("0880000", "정상");
        map.put("0070000", "정상");
        map.put("0450000", "정상");
        map.put("0460000", "정상");
        map.put("0480000", "정상");
        map.put("0490000", "정상");
        map.put("0350000", "정상");

        return map;

    }
}

