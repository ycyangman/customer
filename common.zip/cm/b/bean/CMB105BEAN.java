package cigna.cm.b.bean;

import java.math.BigDecimal;
import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB105DBIO;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.io.CMB105SVC01In;
import cigna.cm.b.io.CMB105SVC01Sub;
import cigna.cm.b.io.CMB105SVC02In;
import cigna.cm.b.io.CMB105SVC03In;
import cigna.cm.b.io.CMB105SVC03Sub;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;


/**
 * @file         cigna.cm.b.bean.CMB105BEAN.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이보라       2016. 7. 29.       신규 작성
 *
 */
@KlafBean
public class CMB105BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB105DBIO	cmb105dbio;
	
	@Autowired
	private CMB001BEAN cmb001bean;
	
	/**
	 * 모계좌 조회
	 * @param 
	 * @return
	 * @throws ApplicationException
	 */	
	public List<CMB105SVC01Sub> getMoActList(CMB105SVC01In input) throws ApplicationException {
		
		List<CMB105SVC01Sub> list = null;
		
		logger.debug("======== input ========" + input);
		
		if (!StringUtils.isEmpty(input.getPropoDeptOrgNo()) && "100977".equals(input.getPropoDeptOrgNo())) {
			list = cmb105dbio.selectMultiTBCMRTM024b();
		} else {
			list = cmb105dbio.selectMultiTBCMRTM024a(input.getPropoDeptOrgNo());
		}
		
		
		
		//List = cmb105dbio.selectMultiTBCMRTM006a();
		
		if(list == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return list;
	}
	
	
	/**
	 * 모계좌 조회
	 * @param 
	 * @return
	 * @throws ApplicationException
	 */	
	public TrsfTrrvPrcsInfo searchBamtInq(CMB105SVC02In input) throws ApplicationException {
		
		String imtrsfChnlDcd1 = "0001";   //출금은행조회
		TrsfTrrvPrcsInfo trsftrrvprcsinfo = new TrsfTrrvPrcsInfo();

		TrsfTrrvPrcsInfo prcsInfo = null;
		
		// 예금주조회와 동일하게 Input 값 Setting
		 
		 trsftrrvprcsinfo.setPrcsCd("08");                       	// set [처리코드 : 자동집금처리(출금,집금)]
		 trsftrrvprcsinfo.setPrcsDt(DateUtils.getCurrentDate(2));	// set [처리일자]
		 trsftrrvprcsinfo.setDpwdDcd("2");                       	// set [입출금구분코드 : 출금]
		 trsftrrvprcsinfo.setBnkCd(input.getFininCd());          	// set [은행코드]
		 trsftrrvprcsinfo.setTrsfAmt(BigDecimal.ZERO) ;         	//이체금액
		 trsftrrvprcsinfo.setNrmCnclDcd("0");                    	// set [정상취소구분코드 : 정상]
		 trsftrrvprcsinfo.setBzDcd("PA");                        	// 업무구분코드
		 trsftrrvprcsinfo.setChnlDcd(imtrsfChnlDcd1) ;           	// 출금은행조회
		 trsftrrvprcsinfo.setReqBzTmBean("CMB105BEAN");         	// set [요청파트BEAN]
		 trsftrrvprcsinfo.setReqBzTmMethod("searchBamtInq");    	// set [요청파트Method]
		 trsftrrvprcsinfo.setOptnKey("S");           				// set [옵션키: sync 방식]
		 trsftrrvprcsinfo.setPropoDeptOrgNo(input.getPropoDeptOrgNo());
		 
		 logger.debug("*** MMJ trsftrrvprcsinfo : {}", trsftrrvprcsinfo);
		 
		 prcsInfo = cmb001bean.callTgmTrrv(trsftrrvprcsinfo);
		 
		 logger.debug("*** MMJ prcsInfo : {}", prcsInfo);
		 
		 return prcsInfo;
	}
	
	/** 
	 * RT 이체불능 MSG 상세조회
     * @param   contNo  	계약번호
     * 			inputDt	    이체일자
     * @return  String   RT 
     * @throws ApplicationException
     */
	public String getRtPrcsDtlInfo(String finInCd,String fininPrcsRcd) throws ApplicationException{
		
		logger.debug("NBBR10BEAN.getRtPrcsDtlInfo 시작");
		//대표코드 변환 + 이체결과조회
		//String newFininCd= this.changeFininCd(finInCd);
		String rstCtnt = cmb105dbio.selectOneTBCMRTM008a(finInCd,fininPrcsRcd);
		
		if(!StringUtils.isEmpty(rstCtnt) && rstCtnt != null){
			
			return rstCtnt;
		
		}else{
			
			rstCtnt = "오류코드를 확인하세요. 에러코드 : "+ fininPrcsRcd;
			return rstCtnt;
		}
	}
	
	/**
	 * 금융기관코드 변환
	 * @param fininCd : 금융기관코드
	 * @return fininCd : 변환된 금융기관코드
	 * @throws ApplicationException
	 */
	public String changeFininCd(String sFininCd) throws ApplicationException {

		String fininCd = sFininCd;
		
		// 사용불가한 은행코드 체크
		if ("000".equals(fininCd)) {
			logger.debug("#### 사용불가한 은행코드입니다");
			// Excepiton 처리 혹은 메시지 처리.
		}else 
		// 은행코드변환 (이체,확인만 사용, 삭제는 사용안함)
		// 농협코드 변환
		if ("012".equals(fininCd) || "013".equals(fininCd)
				|| "014".equals(fininCd) || "015".equals(fininCd)) {
			logger.debug("#### 농협 코드변환 ");
			fininCd = "012";
		}else // 정보통신은행코드 변환
		if ("072".equals(fininCd) || "073".equals(fininCd)
				|| "074".equals(fininCd) || "075".equals(fininCd)) {
			logger.debug("#### 정보통신은행코드 코드변환 ");
			fininCd = "071";
		}else{
			
			String newFfininCd = cmb105dbio.selectOneTBCSFCR007a(fininCd);
			return newFfininCd;
		}
		 
		
		return fininCd;
	}
	
	/**
	 * 모계좌 일시/잔액 조회
	 * @param 
	 * @return
	 * @throws ApplicationException
	 */	
	public List<CMB105SVC03Sub> getMoActBlncMgnt(CMB105SVC03In input) throws ApplicationException {
		
		
		List<CMB105SVC03Sub> list = cmb105dbio.selectMultiTBCMRTM011a(input.getFininCd(),SecuUtil.getEncValue(input.getMoActNo(),EncType.moActNo), input.getInqDt());
		
		if(list == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return list;
	}
	
}

