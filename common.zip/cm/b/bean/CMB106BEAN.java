package cigna.cm.b.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB106DBIO;
import cigna.cm.b.io.CDP_E_COTOS000000001In;
import cigna.cm.b.io.CDP_E_COTOS000000001Out;
import cigna.cm.b.io.CMB106SVC01In;
import cigna.cm.b.io.CMB106SVC01Sub;
import cigna.cm.b.io.CMB106SVC02In;
import cigna.cm.b.io.CMB106SVC03In;
import cigna.cm.b.io.CMB108SVC01In;
import cigna.cm.b.io.CMB108SVC01Out;
import cigna.cm.b.io.CMB108SVC02In;
import cigna.cm.b.io.CMB108SVC02Out;
import cigna.cm.b.io.COM_E_VOCOS000000001In;
import cigna.cm.b.io.COM_E_VOCOS000000001Out;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;


/**
 * @file         cigna.cm.b.bean.CMB106BEAN.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이보라                       2016. 10. 10.       신규 작성
 *
 */
@KlafBean
public class CMB106BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB106DBIO	cmb106dbio;
	
	@Autowired
	private CMB200BEAN	cmb200bean;
	
	/**
	 * 출금동의검수리스트 조회
	 * @param  CMB106SVC01In
	 * @return List<CMB106SVC01Sub>
	 * @throws ApplicationException
	 */	
	public List<CMB106SVC01Sub> getWtrsfAsntList(CMB106SVC01In input) throws ApplicationException {
		
		String wtrsfAsntDtFrom = input.getWtrsfAsntDtFrom();
		String wtrsfAsntDtTo = input.getWtrsfAsntDtTo();
		String contNo = input.getContNo();
		String pmpsDscNo = SecuUtil.getEncValue(input.getPmpsDscNo(), EncType.custDscNo);
		String pmpsNo = input.getPmpsNo();
		String wtrsfAsntSysCd = input.getWtrsfAsntSysCd();
		String wtrsfAsntRcDcd = input.getWtrsfAsntRcDcd();
		String wtrsfAsntEvidDcd = input.getWtrsfAsntEvidDcd();
		String wtrsfAsntEvidNo = input.getWtrsfAsntEvidNo();
		String inspRcd = input.getInspRcd();
		String complRcd = input.getComplRcd();
		String evidInspDtmFrom = input.getEvidInspDtmFrom();
		String evidInspDtmTo = input.getEvidInspDtmTo();
		String evidInspEno = input.getEvidInspEno();
		Integer pageNum = input.getPageNum();
		Integer pageCount = input.getPageCount();
		
		
		List<CMB106SVC01Sub> List = null;
		
		List = cmb106dbio.selectMultiTBCMETC014a(wtrsfAsntDtFrom, wtrsfAsntDtTo, contNo, pmpsDscNo, pmpsNo, wtrsfAsntSysCd, wtrsfAsntRcDcd, wtrsfAsntEvidDcd, wtrsfAsntEvidNo, inspRcd, complRcd, evidInspDtmFrom, evidInspDtmTo, evidInspEno, pageNum, pageCount);
		
		
		return List;
	}
	
	/**
	 * 출금동의검수리스트 조회(세부내역-팝업)
	 * @param  CMB106SVC01In
	 * @return CMB106SVC01Sub
	 * @throws ApplicationException
	 */	
	public CMB106SVC01Sub getWtrsfAsntDtlList(CMB106SVC03In input) throws ApplicationException {
		
		String wtrsfAsntVerfMgntNo = input.getWtrsfAsntVerfMgntNo();
		
		
		CMB106SVC01Sub List = null;
		
		List = cmb106dbio.selectOneTBCMETC014a(wtrsfAsntVerfMgntNo);
		
		
		return List;
	}
	
	/**
	 * 출금동의검수리스트 조회(랜덤)
	 * @param  CMB106SVC01In
	 * @return List<CMB106SVC01Sub>
	 * @throws ApplicationException
	 */	
	public List<CMB106SVC01Sub> getWtrsfAsntRandomList(CMB106SVC01In input) throws ApplicationException {
		
		String wtrsfAsntDtFrom = input.getWtrsfAsntDtFrom();
		String wtrsfAsntDtTo = input.getWtrsfAsntDtTo();
		String contNo = StringUtils.nvl(input.getContNo());
		String pmpsDscNo = StringUtils.nvl(SecuUtil.getEncValue(input.getPmpsDscNo(), EncType.custDscNo));
		String pmpsNo = StringUtils.nvl(input.getPmpsNo());
		String wtrsfAsntSysCd = StringUtils.nvl(input.getWtrsfAsntSysCd());
		String wtrsfAsntRcDcd = StringUtils.nvl(input.getWtrsfAsntRcDcd());
		String wtrsfAsntEvidDcd = StringUtils.nvl(input.getWtrsfAsntEvidDcd());
		String wtrsfAsntEvidNo = StringUtils.nvl(input.getWtrsfAsntEvidNo());
		String inspRcd = StringUtils.nvl(input.getInspRcd());
		String complRcd = StringUtils.nvl(input.getComplRcd());
		String evidInspDtmFrom = StringUtils.nvl(input.getEvidInspDtmFrom());
		String evidInspDtmTo = StringUtils.nvl(input.getEvidInspDtmTo());
		String evidInspEno = StringUtils.nvl(input.getEvidInspEno());
		Integer pageNum = input.getPageNum();
		Integer pageCount = input.getPageCount();
		
		List<CMB106SVC01Sub> List = null;
		
		List = cmb106dbio.selectMultiTBCMETC014b(wtrsfAsntDtFrom, wtrsfAsntDtTo, contNo, pmpsDscNo, pmpsNo, wtrsfAsntSysCd, wtrsfAsntRcDcd, wtrsfAsntEvidDcd, wtrsfAsntEvidNo, inspRcd, complRcd, evidInspDtmFrom, evidInspDtmTo, evidInspEno,StringUtils.nvl(input.getRandomWtrsfAsntVerfMgntNo()));
		
		
		return List;
	}
	
	/**
	 * 출금동의검수리스트 저장
	 * @param  CMB106SVC02In
	 * @return int
	 * @throws ApplicationException
	 */	
	public int updateWtrsfAsntList(CMB106SVC02In input) throws ApplicationException {
		int rCnt=0;
		
		if (StringUtils.isEmpty(input.getWtrsfAsntEvidNo())) {
			throw new ApplicationException("APPRE0000", new Object[]{"출금이체동의증빙번호"}, new Object[]{"출금이체동의증빙번호"});
		}
		
		input.setLastChgrId(FwUtil.getUserId()); // 최종변경변경자ID
		input.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID
		input.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호
		
		rCnt = cmb106dbio.updateOneTBCMETC014(input);	
		
//		try {
//			
//			logger.debug("녹취처리내역");					
//			VcrecDlngInfo vcrecDlngInfo = new VcrecDlngInfo();				
//			
//			vcrecDlngInfo.setVcrecSysCd("00");				// 녹취시스템코드
//			vcrecDlngInfo.setBzTxRfDcd("CM");								// 업무거래참조구분코드
//			vcrecDlngInfo.setBzTxRfDtlDcd("01");						// 업무거래참조상세구분코드
//			vcrecDlngInfo.setBzTxRfNo("1");								// 업무거래참조번호
//			vcrecDlngInfo.setVcrecId("1");									// 녹취ID
//			vcrecDlngInfo.setCnslNo("9999");									// 상담번호
//			
//			logger.debug("vcrecDlngInfo:{}",vcrecDlngInfo);
//			cmb200bean.callVcrecDlng(vcrecDlngInfo);
//		
//		
//			} catch (ApplicationException ae) {
//				logger.debug("녹취저장 오류:",ae);
//			}
		
		return rCnt;
	}
	
	/**
	 * CS 출금이체동의증빙번호 조회
	 * @param  CMB108SVC01In
	 * @return CMB108SVC01Out
	 * @throws ApplicationException
	 */	
	public CMB108SVC01Out getCsWtrsfAsntEvidNo(CMB108SVC01In input) throws ApplicationException {
		
		CMB108SVC01Out output = new CMB108SVC01Out();
		
		EISResponse<CDP_E_COTOS000000001Out> response = null;
		CDP_E_COTOS000000001Out responseData = null;
		
		CDP_E_COTOS000000001In callEAIInput = new CDP_E_COTOS000000001In();
			
		callEAIInput.setUsrId(FwUtil.getUserId());
		
		try{
			
			String interfaceId = "CDP_E_COTOS000000001"; //CS 녹취키 
			
			//response = InfUtil.callEAI(callEAIInput, interfaceId, CDP_E_COTOS000000001Out.class);
			
			response = InfUtil.callEAI(callEAIInput, interfaceId, "CC", "CCLCH1SVC", "selectSingle0", FwUtil.getDeptCd(), FwUtil.getUserId(), CDP_E_COTOS000000001Out.class);
			
			logger.debug("response={}", response);
			responseData = response.getResponseData();
		    logger.debug("response data:{}", responseData);
		} catch (EisExecutionException e) {
			logger.error("EAI송수신에러_EisExecutionException :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		} catch (NotSupportedEISException e) {
			logger.error("EAI송수신에러_NotSupportedEISException :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		} catch (Exception e) {
			logger.error("EAI송수신에러_Exception :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		}
		
		
		output.setWtrsfAsntEvidNo(responseData.getVcrecId());
		output.setCnslNo(responseData.getCnslNo());
		
		return output;
	}
	
	/**
	 * VOC 출금이체동의증빙 관련조회
	 * @param  CMB108SVC02In
	 * @return CMB108SVC02Out
	 * @throws ApplicationException
	 */	
	public CMB108SVC02Out getVocWtrsfAsntEvidLst(CMB108SVC02In input) throws ApplicationException {
		
		CMB108SVC02Out output = new CMB108SVC02Out();
		
		EISResponse<COM_E_VOCOS000000001Out> response = null;
		COM_E_VOCOS000000001Out responseData = null;
		
		COM_E_VOCOS000000001In callEAIInput = new COM_E_VOCOS000000001In();
			
		callEAIInput.setVocRcNo(input.getVocRcNo());
		callEAIInput.setCustNo(input.getCustNo());
		callEAIInput.setWtrsfAsntDcd(input.getWtrsfAsntDcd());
		
		
		try{
			
			String interfaceId = "COM_E_VOCOS000000001"; //CS 녹취키 
			
			//response = InfUtil.callEAI(callEAIInput, interfaceId, CDP_E_COTOS000000001Out.class);
			
			response = InfUtil.callEAI(callEAIInput, interfaceId, "VC", "VCZZ02SVC", "selectSingle1", FwUtil.getDeptCd(), FwUtil.getUserId(), COM_E_VOCOS000000001Out.class);
			
			logger.debug("response={}", response);
			responseData = response.getResponseData();
		    logger.debug("response data:{}", responseData);
		} catch (EisExecutionException e) {
			logger.error("EAI송수신에러_EisExecutionException :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		} catch (NotSupportedEISException e) {
			logger.error("EAI송수신에러_NotSupportedEISException :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		} catch (Exception e) {
			logger.error("EAI송수신에러_Exception :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		}
		
		output.setWtrsfAsntEvidDcd(responseData.getWtrsfAsntEvidDcd());
		output.setWtrsfAsntEvidNo(responseData.getWtrsfAsntEvidNo());
		output.setWtrsfAsntApplDt(responseData.getWtrsfAsntApplDt());
		output.setWtrsfAsntVcrecStrtDtm(responseData.getWtrsfAsntVcrecStrtDtm());
		output.setWtrsfAsntVcrecEndDtm(responseData.getWtrsfAsntVcrecEndDtm());
		
		
		
		
		return output;
	}
}

