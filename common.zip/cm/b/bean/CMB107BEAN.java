package cigna.cm.b.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB107DBIO;
import cigna.cm.b.io.CMB107SVC01In;
import cigna.cm.b.io.CMB107SVC01Sub;
import cigna.cm.b.io.CMB107SVC02In;
import cigna.cm.b.io.CMB107SVC03In;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;


/**
 * @file         cigna.cm.b.bean.CMB107BEAN.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이보라       2016. 10. 12.       신규 작성
 *
 */
@KlafBean
public class CMB107BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB107DBIO	cmb107dbio;
	
	@Autowired
	private CMB200BEAN	cmb200bean;
	
	
	
	/**
	 * 보완콜리스트 조회
	 * @param  CMB107SVC01In
	 * @return List<CMB107SVC01Sub>
	 * @throws ApplicationException
	 */	
	public List<CMB107SVC01Sub> getComplCallList(CMB107SVC01In input) throws ApplicationException {
		
		String wtrsfAsntDtFrom = input.getWtrsfAsntDtFrom();
		String wtrsfAsntDtTo = input.getWtrsfAsntDtTo();
		String contNo = input.getContNo();
		String pmpsDscNo = SecuUtil.getEncValue(input.getPmpsDscNo(), EncType.custDscNo);
		String pmpsNo = input.getPmpsNo();
		String wtrsfAsntSysCd = input.getWtrsfAsntSysCd();
		String wtrsfAsntRcDcd = input.getWtrsfAsntRcDcd();
		String wtrsfAsntEvidDcd = input.getWtrsfAsntEvidDcd();
		String wtrsfAsntEvidNo = input.getWtrsfAsntEvidNo();
		String inspRcd = input.getInspRcd();
		String complRcd = input.getComplRcd();
		String complCallReqDtmFrom = input.getComplCallReqDtmFrom();
		String complCallReqDtmTo = input.getComplCallReqDtmTo();
		String complCmptDtmFrom = input.getComplCmptDtmFrom();
		String complCmptDtmTo = input.getComplCmptDtmTo();
		String complEno = input.getComplEno();
		Integer pageNum = input.getPageNum();
		Integer pageCount = input.getPageCount();
		List<CMB107SVC01Sub> List = null;
		
		List = cmb107dbio.selectMultiTBCMETC014a(wtrsfAsntDtFrom, wtrsfAsntDtTo, contNo, pmpsDscNo, pmpsNo, wtrsfAsntSysCd, wtrsfAsntRcDcd, wtrsfAsntEvidDcd, wtrsfAsntEvidNo, inspRcd, complRcd, complCallReqDtmFrom, complCallReqDtmTo, complCmptDtmFrom,complCmptDtmTo,complEno,pageNum,pageCount);
		
		
		return List;
	}
	
	/**
	 * 보완콜리스트 상세조회
	 * @param  CMB107SVC03In
	 * @return CMB107SVC01Su
	 * @throws ApplicationException
	 */	
	public CMB107SVC01Sub getComplCallDtlList(CMB107SVC03In input) throws ApplicationException {
		
		logger.debug("======= input  ========" + input);
		
		String wtrsfAsntVerfMgntNo = input.getWtrsfAsntVerfMgntNo();
		
		CMB107SVC01Sub List = null;
		
		List = cmb107dbio.selectOneTBCMETC014a(wtrsfAsntVerfMgntNo);
		
		return List;
	}
	
	/**
	 * 보완콜리스트 저장
	 * @param  CMB107SVC02In
	 * @return int
	 * @throws ApplicationException
	 */	
	public int updateComplCallList(CMB107SVC02In input) throws ApplicationException {
		int rCnt=0;
		int iResult = 0;
		
		input.setLastChgrId(FwUtil.getUserId()); // 최종변경변경자ID
		input.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID
		input.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호
		
		rCnt = cmb107dbio.updateOneTBCMETC014(input);	
		
//		//2016.11.21;현승훈;녹취처리
//		if (rCnt == 1) {
//			try {
//				VcrecDlngInfo vcrcDlngInfoIn = new VcrecDlngInfo();
//				
//				vcrcDlngInfoIn.setVcrecId(input.getVcrecId());   	//녹취ID
//				vcrcDlngInfoIn.setBzTxRfDcd("CM");   	//업무거래참조구분코드
//				vcrcDlngInfoIn.setBzTxRfDtlDcd("01");   //업무거래참조상세구분코드
//				vcrcDlngInfoIn.setBzTxRfNo("1231321311231");   	//업무거래참조번호(해당업무접수번호)
//				
//				iResult = cmb200bean.callVcrecDlng(vcrcDlngInfoIn);
//				
//			} catch (ApplicationException ae) {
//				logger.debug("SMS전송오류:",ae);
//			}
//		}
		
		return rCnt;
	}
}

