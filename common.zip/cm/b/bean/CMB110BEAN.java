package cigna.cm.b.bean;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.inf.EisExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA007BEAN;
import cigna.cm.a.io.SelectMultiTBCMCCD024Out;
import cigna.cm.b.dbio.CMB110DBIO;
import cigna.cm.b.io.CMB110SVC01In;
import cigna.cm.b.io.CMB110SVC01Sub;
import cigna.cm.b.io.CMB110SVC02In;
import cigna.cm.b.io.CMB110SVC02Out;
import cigna.cm.b.io.CMB110SVC03In;
import cigna.cm.b.io.CMB110SVC03Sub;
import cigna.cm.b.io.CMB110SVC04In;
import cigna.cm.b.io.CMB110SVC04Out;
import cigna.cm.b.io.CMB110SVC05In;
import cigna.cm.b.io.CMB110SVC05Out;
import cigna.zz.BizDateInfo;
import cigna.zz.FileUtil;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;


/**
 * @file         cigna.cm.b.bean.CMB110BEAN.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈       2016. 12. 01.       신규 작성
 *
 */
@KlafBean
public class CMB110BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB110DBIO	cmb110dbio;
	
	@Autowired
	private CMA007BEAN	cma007bean;
	
	@Autowired
	private BizDateInfo bizDateInfo; // 일자체크모듈
	
	/**
	 * 출금이체동의금결원증빙내역  조회
	 * @param  CMB110SVC01In
	 * @return List<CMB110SVC01Sub>
	 * @throws ApplicationException
	 */	
	public List<CMB110SVC01Sub> getWtrsfAsntKftcList(CMB110SVC01In input) throws ApplicationException {
		
		String kftcTxDt = StringUtils.nvl(input.getKftcTxDt());
		String kftcDochdReqDt = StringUtils.nvl(input.getKftcDochdReqDt());
		String svcKcd = StringUtils.nvl(input.getSvcKcd());
		
		
		List<CMB110SVC01Sub> List = null;
		
		List = cmb110dbio.selectMultiTBCMETC017a(kftcTxDt, kftcDochdReqDt, svcKcd);
		
		
		return List;
	}

	/**
	 * 출금이체동의금결원증빙데이터내역  조회
	 * @param  CMB110SVC03In
	 * @return List<CMB110SVC03Sub>
	 * @throws ApplicationException
	 */	
	public List<CMB110SVC03Sub> getWtrsfAsntKftcDataList(CMB110SVC03In input) throws ApplicationException {
		
		String kftcReqFileNm = input.getKftcReqFileNm();
		String kftcTxDt = StringUtils.nvl(input.getKftcTxDt());
		String kftcTxTi = StringUtils.nvl(input.getKftcTxTi());
		
		
		List<CMB110SVC03Sub> List = null;
		
		List = cmb110dbio.selectMultiTBCMETC017b(kftcReqFileNm, kftcTxDt, kftcTxTi);
		
		SecuUtil.doDecList(List);
		
		return List;
	}
	
	/**
	 * 출금이체동의 금융결제원 파일 처리
	 * @param  CMB110SVC01In
	 * @throws ApplicationException
	 * @throws InterruptedException 
	 */  
	public CMB110SVC02Out insertFileDataSet(CMB110SVC02In input ) throws ApplicationException{
		
		
		CMB110SVC02Out output = new CMB110SVC02Out();
		
		// 필수입력값 validation check
		if (!StringUtils.hasText(input.getKftcReqFileNm())) {
			throw new ApplicationException( "APPAE0002", new Object[]{"금결원요청파일명"} );
		}
		if (!StringUtils.hasText(input.getProcFileNm())) {
			throw new ApplicationException( "APPAE0002", new Object[]{"처리파일명"} );
		}
		
		
		String kftcTxDt = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		String kftcTxTi = DateUtils.getCurrentTime(0).replace(":", "");
		String kftcReqFileNm = "";
		
		logger.debug("====== arrRfNo ===  " + input.getKftcReqFileNm().indexOf("."));
		
		if (input.getKftcReqFileNm().indexOf(".") > 0) {
			
			kftcReqFileNm = input.getKftcReqFileNm().substring(0, input.getKftcReqFileNm().indexOf("."));
			
		} else {
			kftcReqFileNm = input.getKftcReqFileNm();
		}
		
		logger.debug("====== kftcReqFileNm ===  " + kftcReqFileNm);
		
		String eno = FwUtil.getUserId();
        //String scrnNo = FwUtil.getPgmId();        
        String trmsSuccYn = "N";
        
        String[] retResult = new String[3];
        
        
		/*
		 * Batch 실행
		 */
		String errorTxt = "";
		try {			
				errorTxt = "출금이체동의 금융결제원 요청";
				
				SelectMultiTBCMCCD024Out  out = null;
				
				// @param jobName  실행할 Job Name
				// @param parameters  Batch 실행에 필요한 key=value의 쌍에 대한 문자열 배열
				
				InfUtil.startBatch("BCMR005O", new String[] {"sProcFileNm="+input.getProcFileNm(),"sKftcReqFileNm="+kftcReqFileNm,"sKftcTxDt="+kftcTxDt,"sKftcTxTi="+kftcTxTi});
				// @param jobName  실행할 Job Name
				// @param parameters  Batch 실행에 필요한 key=value의 쌍에 대한 문자열 배열
				//InfUtil.startBatch("BAIE231O", new String[] {"dataCalcoDcd="+dataCalcoDcd,"i=" + AIEC50BEAN.getCurrentTimestamp()});
				
				logger.info("정상적으로 처리되었습니다.");
				
				for ( int i=0;i < 30; i++) {
					
					//Thread.sleep(getSynctime());
					
					logger.debug("waiting 횟수:{}",i);
					
					
					out = cma007bean.getOnBatchRstInfo(kftcTxDt,eno,"","CMB110M0");
					
					logger.debug("조회결과");
					logger.debug("out:{}",out);
					
					if ( null != out ) {
						if( "Y".equals(out.getTrmsSuccYn()))	break;
					}
					
				}				
				if ( null != out ) {
					trmsSuccYn = out.getTrmsSuccYn();
					
					output.setTrmsSuccYn(trmsSuccYn);
					output.setKftcTxDt(kftcTxDt);
					output.setKftcTxTi(kftcTxTi);
					output.setKftcReqFileNm(kftcReqFileNm);
				}
			
		} catch (EisExecutionException e) {
			//성공이 아닌경우 push message로 알림
			// 변경해야됨
			throw new ApplicationException("APCME0031", new String[] {errorTxt});
		}
		
		return output;
	}
	
	/**
	 * 출금이체동의금결원증빙데이터내역  조회
	 * @param  CMB110SVC03In
	 * @return List<CMB110SVC03Sub>
	 * @throws ApplicationException
	 * @throws InterruptedException 
	 */	
	public CMB110SVC04Out getWtrsfAsntKftc(CMB110SVC04In input) throws ApplicationException, InterruptedException {
		
		CMB110SVC04Out output = new CMB110SVC04Out();
		
		List<CMB110SVC01Sub> listOut = null;
		
		logger.debug("===========" + input.getKftcReqFileNm());
		logger.debug("===========" + input.getKftcTxDt());
		logger.debug("===========" + input.getKftcTxTi());
		
		String kftcReqFileNm = input.getKftcReqFileNm();
		
		for ( int i=0;i < 30; i++) {
			
			Thread.sleep(getSynctime());
			
			logger.debug("waiting 횟수:{}",i);
			
			listOut = cmb110dbio.selectMultiTBCMETC017c(kftcReqFileNm, input.getKftcTxDt(), input.getKftcTxTi());
			
			
			if ( null != listOut ) {
				break;
			}
			
		}		
		
		List<CMB110SVC01Sub> List = null;
		
		List = cmb110dbio.selectMultiTBCMETC017c(kftcReqFileNm, input.getKftcTxDt(), input.getKftcTxTi());
		
		List<CMB110SVC03Sub> List2 = null;
		
		List2 = cmb110dbio.selectMultiTBCMETC017b(kftcReqFileNm, input.getKftcTxDt(), input.getKftcTxTi());
		
		SecuUtil.doDecList(List2);
		
		output.setRstCnt(List.size());					
		output.setDsWtrsfAsntKftcList(List);
		output.setDataRstCnt(List2.size());
		output.setDsWtrsfAsntKftcDataList(List2);
		
		
		return output;
	}

	public int getSynctime()	{
		
		String mode = LApplicationContext.getSystemMode();
		
		// 운영계인 경우 syncTime 넉넉하게 받을 수 있도록 조치
		return("D".equals(mode)?100:100);
		
	}
		
//	/**
//	 * 보완콜리스트 저장
//	 * @param  CMB107SVC02In
//	 * @return int
//	 * @throws ApplicationException
//	 */	
//	public int updateComplCallList(CMB107SVC02In input) throws ApplicationException {
//		int rCnt=0;
//		int iResult = 0;
//		
//		input.setLastChgrId(FwUtil.getUserId()); // 최종변경변경자ID
//		input.setLastChgPgmId(FwUtil.getPgmId()); // 최종변경프로그램ID
//		input.setLastChgTrmNo(FwUtil.getTrmNo()); // 최종변경단말번호
//		
//		rCnt = cmb107dbio.updateOneTBCMETC014(input);	
//		
////		//2016.11.21;현승훈;녹취처리
////		if (rCnt == 1) {
////			try {
////				VcrecDlngInfo vcrcDlngInfoIn = new VcrecDlngInfo();
////				
////				vcrcDlngInfoIn.setVcrecId(input.getVcrecId());   	//녹취ID
////				vcrcDlngInfoIn.setBzTxRfDcd("CM");   	//업무거래참조구분코드
////				vcrcDlngInfoIn.setBzTxRfDtlDcd("01");   //업무거래참조상세구분코드
////				vcrcDlngInfoIn.setBzTxRfNo("1231321311231");   	//업무거래참조번호(해당업무접수번호)
////				
////				iResult = cmb200bean.callVcrecDlng(vcrcDlngInfoIn);
////				
////			} catch (ApplicationException ae) {
////				logger.debug("SMS전송오류:",ae);
////			}
////		}
//		
//		return rCnt;
//	}
	
	/**
	 * 출금이체동의금결원증빙데이터내역  조회
	 * @param  CMB110SVC03In
	 * @return List<CMB110SVC03Sub>
	 * @throws ApplicationException
	 * @throws InterruptedException 
	 */	
	public CMB110SVC05Out getAE5119File(CMB110SVC05In input) throws ApplicationException, InterruptedException {
		
		CMB110SVC05Out output = new CMB110SVC05Out();
		
		List<CMB110SVC03Sub> dsWtrsfAsntKftcDataList = input.getDsWtrsfAsntKftcDataList();
		
		logger.debug("=========== dsWtrsfAsntKftcDataList : " + dsWtrsfAsntKftcDataList);
		
		int lineSeq = 1;
		
		FileOutputStream fos = null;
		
		String today		= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		
		if(bizDateInfo.chkHldyYnBoolean(today)) {
			
			throw new ApplicationException("APDPE0221", null);
		}
		
		String outSavFileNm = dsWtrsfAsntKftcDataList.get(0).getKftcReqFileNm().replace("4119", "5119"); // 출력파일저장명
		
		logger.debug("=========== outSavFileNm : " + outSavFileNm);
		
		outSavFileNm = outSavFileNm.substring(0, 10) + today.substring(4) + outSavFileNm.substring(10);
		
		String outOrgcpFileNm = outSavFileNm; // 출력파일명
		String outFilePathNm = "/sdata/doc/cm"; // 출력경로명
		String utilInstId = "";	//이용기관코드
		
		
		Integer sizeCnt = 0;
		long totSize = 0;
		Integer blockCnt = 0;
		
		output.setAtchOrgcpFileNm(outOrgcpFileNm);
		output.setAtchSavFileNm(outSavFileNm);
		output.setFilePathNm(outFilePathNm);
		
		FileUtil.delete("/sdata/doc/cm/cmb110/" + outSavFileNm);
		
		try {
			// 출력스트림
			fos = new FileOutputStream(outFilePathNm + "/" + outSavFileNm);
			
			fos.write("AE5119".getBytes()); // 업무구분코드 AN 6
        	fos.write("11".getBytes()); // 데이터구분코드 N 2
        	fos.write(StringUtils.lpad("", 7, "0").getBytes()); // 일련번호 N 7
        	fos.write(dsWtrsfAsntKftcDataList.get(0).getKftcDochdReqDt().getBytes());		//요청일자
        	fos.write(dsWtrsfAsntKftcDataList.get(0).getSvcKcd().getBytes()); // 요청유형(1.사후점검 2.고객열람) N 1
        	fos.write(StringUtils.rpad(dsWtrsfAsntKftcDataList.get(0).getUtilInstId(), 20, " ").getBytes()); // 이용기관코드 AN 20
        	utilInstId = dsWtrsfAsntKftcDataList.get(0).getUtilInstId();
        	fos.write(StringUtils.rpad(dsWtrsfAsntKftcDataList.get(0).getFbsResalInstYn(), 1, " ").getBytes()); // 펌재판매여부 AN 1
        	fos.write(StringUtils.rpad(dsWtrsfAsntKftcDataList.get(0).getBzno(), 10, " ").getBytes()); // 사업자등록번호 AN 10
        	fos.write(StringUtils.lpad(dsWtrsfAsntKftcDataList.get(0).getReqDataRecCnt().toString(), 7, "0").getBytes()); // 총데이터건수 AN 8
        	fos.write(StringUtils.lpad("", 962, " ").getBytes()); // 공백
        	fos.flush();
        	
			for (CMB110SVC03Sub dsWtrsfAsntKftcData : dsWtrsfAsntKftcDataList) {
				
				String filePathNm = dsWtrsfAsntKftcData.getFilePathNm(); // 파일경로
				String atchSavFileNm = dsWtrsfAsntKftcData.getAtchSavFileNm(); // 파일저장명
				String atchOrgcpFileNm = dsWtrsfAsntKftcData.getAtchOrgcpFileNm(); // 파일명
				
				// 파일경로가 없다면 패스
				if (StringUtils.isEmpty(filePathNm) || StringUtils.isEmpty(filePathNm)) {
					continue;
				}
				
				if (atchOrgcpFileNm == null) {
					atchOrgcpFileNm = "";
				}
				
				String fileKind = "";
				String[] split = atchOrgcpFileNm.split("\\.");
				if (split != null && split.length > 0) {
					fileKind = split[split.length-1];
				}
				
				logger.debug( "filePathNm : {} atchSavFileNm : {} " , filePathNm, atchSavFileNm );
				
				File file = null; 
				
				FileInputStream fis = null;
				
				try {
		            file = new File(filePathNm + "/" + atchSavFileNm);
		            
		            if ( file.exists() ) {
		            	logger.debug("lineSeq : " + lineSeq);
		            	fos.write("AE5119".getBytes()); // 업무구분코드 AN 6
		            	fos.write("22".getBytes()); // 데이터구분코드 N 2
		            	fos.write(StringUtils.lpad(lineSeq+"", 7, "0").getBytes()); // 일련번호 N 7
		            	fos.write(StringUtils.lpad(dsWtrsfAsntKftcData.getReqTpcd(), 1, " ").getBytes()); // 요청유형(1.사후점검 2.고객열람) N 1
		            	fos.write("          ".getBytes()); // FILLER(SPACE) AN 10
		            	fos.write(StringUtils.rpad(utilInstId, 20, " ").getBytes()); // 이용기관코드 AN 20
		            	fos.write(StringUtils.rpad(dsWtrsfAsntKftcData.getKftcPmpsNo(), 30, " ").getBytes()); // 납부자번호 AN 30
		            	fos.write(StringUtils.rpad(dsWtrsfAsntKftcData.getFininCd(), 3, " ").getBytes()); // 금융회사코드 AN 3
		            	fos.write(StringUtils.rpad(SecuUtil.getDecValue(dsWtrsfAsntKftcData.getActNo(), EncType.actNo), 20, " ").getBytes()); // 계좌번호 AN 20
		            	fos.write(StringUtils.rpad(dsWtrsfAsntKftcData.getApplDt(), 8, " ").getBytes()); // (요청결과)신청일 AN 8
		            	fos.write(StringUtils.lpad(dsWtrsfAsntKftcData.getWtrsfAsntEvidDcd(), 1, " ").getBytes()); // (요청결과)동의자료구분(1.서면 2.공인전자서명 3.일반전자서명 4.녹취 5.ARS) N 1
		            	fos.write("          ".getBytes()); // 하위이용기관코드(SPACE) AN 10
		            	fos.write("          ".getBytes()); // 하위이용기관사업자번호(SPACE) AN 10
		            	fos.write(StringUtils.rpad("Y", 1, " ").getBytes()); // 요청결과여부 AN 1
		            	fos.write(StringUtils.rpad(fileKind, 5, " ").getBytes()); // 동의자료확장자 AN 5
		            	fos.write(StringUtils.lpad(file.length()+"", 7, "0").getBytes()); // 동의자료길이 N 7
		            	fos.flush();		            	
		            	
		            	logger.debug("========= file.length() =======" + file.length());
		            	
		            	totSize = file.length() + 141;
		            	
		            	if (totSize / 1024 > 0) {
		            		sizeCnt =  Integer.parseInt(String.valueOf(totSize / 1024)) + 1;
		            	} else {
		            		sizeCnt =  Integer.parseInt(String.valueOf(totSize / 1024));
		            	}
		            	
						fis = new FileInputStream(file);
						
						int readCnt = 0;
						
						// 처음읽을때는 883길이만 읽는다
						byte[] buf = new byte[883];
						boolean fstFlag = true;
						while((readCnt = fis.read(buf)) != -1) {
							// 처음읽을때는 883길이만 읽고 이후에는 1024길이를 읽는다
							fos.write(buf, 0, readCnt);
							
							if (readCnt < buf.length) {
								logger.debug("buf.length : " + buf.length);
								logger.debug("readCnt : " + readCnt);
								fos.write(StringUtils.lpad(" ", buf.length - readCnt, " ").getBytes()); // 1024바이트보다 적으면 공백입력
							}
							
							if (fstFlag) {
								buf = new byte[1024];
							}
						}
						
						fos.flush();
						blockCnt += sizeCnt;
						lineSeq++;
					} else {
						//logger.error("File Path Not Found!!");
						throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "File Path Not Found!!" } );
					}
					
				} catch(FileNotFoundException e) {
					//APCME0000 : 처리중 오류가 발생했습니다.
				    throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[FileNotFoundException] 파일 Binary Data로 변환중 에러발생" }, e );
					
				} catch(IOException e) {
					//APCME0000 : 처리중 오류가 발생했습니다.
					throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 에러발생" }, e );
				
				} catch(Exception e) {
					//APCME0000 : 처리중 오류가 발생했습니다.
					throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 에러발생" }, e );
					
				}  finally {
					
					try { 
						if(fis != null) fis.close();
					} catch(IOException e) {
						//APCME0000 : 처리중 오류가 발생했습니다.
						throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 파일객체 close시 에러발생" }, e );
					}
				}
				
			}
			
			logger.debug("======  blockCnt =======" + blockCnt);
			
			//트레일러부분 
			fos.write("AE5119".getBytes()); // 업무구분코드 AN 6
        	fos.write("33".getBytes()); // 데이터구분코드 N 2
        	fos.write(StringUtils.lpad("", 7, "9").getBytes()); // 일련번호 N 7
        	fos.write(StringUtils.rpad(dsWtrsfAsntKftcDataList.get(0).getUtilInstId(), 20, " ").getBytes()); // 이용기관코드 AN 20
        	fos.write(StringUtils.lpad(dsWtrsfAsntKftcDataList.get(0).getReqDataRecCnt().toString(), 7, "0").getBytes()); // 총데이터건수 AN 8
        	fos.write(StringUtils.lpad(blockCnt.toString(), 10, "0").getBytes()); // 총data block수
        	fos.write(StringUtils.lpad("", 972, " ").getBytes()); // 공백
        	fos.flush();
        	
        	
		} catch(FileNotFoundException e) {
			//APCME0000 : 처리중 오류가 발생했습니다.
		    throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[FileNotFoundException] 파일 Binary Data로 변환중 에러발생" }, e );
			
		} catch(IOException e) {
			//APCME0000 : 처리중 오류가 발생했습니다.
			throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 에러발생" }, e );
		
		}  finally {
			
			try { 
				if(fos != null) fos.close();
				FileUtil.deleteFiles("/sdata/doc/cm/cmb110/");
			} catch(IOException e) {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "[IOException] 파일생성 Binary Data로 변환중 파일객체 close시 에러발생" }, e );
			}
		}
		
		
		return output;
	}
}

