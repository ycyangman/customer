package cigna.cm.b.bean;

import klaf.app.ApplicationException;
import klaf.container.annotation.KlafBean;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.dbio.CMB200DBIO;
import cigna.cm.b.domain.VcrecDlngInfo;
import cigna.cm.b.io.CMB108SVC01In;
import cigna.cm.b.io.CMB108SVC01Out;
import cigna.cm.b.io.TBCMETC016Io;
import cigna.zz.FwUtil;


/**
 * @file         cigna.cm.b.bean.CMB107BEAN.java
 * @filetype     java source file
 * @brief        (공통)녹취처리내역
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                           성명                                               일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                            2016. 11. 17.      신규 작성
 *
 */
@KlafBean
public class CMB200BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB200DBIO	cmb200dbio;
	
	@Autowired
	private CMB106BEAN	cmb106bean;
	
	/**
	 * 녹취처리내역 Operation
	 * @param VcrecDlngInfo  녹취처리내역
	 * @return iResult   
	 * @throws ApplicationException
	 */
	@TransactionalOperation(propagation = Propagation.REQUIRES_NEW)
	public int callVcrecDlng (VcrecDlngInfo input) throws ApplicationException {
		
		int iResult = 0;
		
		logger.debug("☆☆☆☆☆☆☆ input ===>{}", input);
		
		TBCMETC016Io insertInput = new TBCMETC016Io();
		
		String vcrecId = "";
		String vcrecSysCd = "";
		String cnslNo = "";
		
		if ("COR".equals(FwUtil.getMedTyp())) {
			vcrecSysCd = "00";   	//녹취시스템코드 (00:기간계, 01:CC)
			vcrecId = input.getVcrecId();   	//녹취ID
		} else if ("COT".equals(FwUtil.getMedTyp())) {
			//input.setVcrecSysCd("01");   	//녹취시스템코드 (00:기간계, 01:CC)
			vcrecSysCd = "01";   	//녹취시스템코드 (00:기간계, 01:CC)
			
			
			CMB108SVC01Out output = new CMB108SVC01Out();
			
			CMB108SVC01In inputCs = new CMB108SVC01In();

			output = cmb106bean.getCsWtrsfAsntEvidNo(inputCs);
			
			//input.setVcrecId(output.getWtrsfAsntEvidNo());   	//녹취ID
			vcrecId = output.getWtrsfAsntEvidNo();   	//녹취ID
			cnslNo = output.getCnslNo();				//상담번호
		}
		
		insertInput.setVcrecSysCd(vcrecSysCd);							// 녹취시스템코드
		insertInput.setBzTxRfDcd(input.getBzTxRfDcd());								// 업무거래참조구분코드
		insertInput.setBzTxRfNo(input.getBzTxRfNo());								// 업무거래참조번호
		insertInput.setVcrecId(vcrecId);									// 녹취ID
		insertInput.setCnslNo(cnslNo);									// 상담번호
		insertInput.setLastChgrId(FwUtil.getUserId());								// 최종변경자ID(LAST_CHGR_ID) 설정
		insertInput.setLastChgPgmId(FwUtil.getPgmId());								// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		insertInput.setLastChgTrmNo(FwUtil.getTrmNo());								// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		logger.debug("☆☆☆☆☆☆☆ insertInput ===>{}", insertInput);
		iResult = this.cmb200dbio.insertOneTBCMETC0160(insertInput);
		
		return iResult;
	}
	
}

