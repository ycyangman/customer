package cigna.cm.b.bean;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.container.annotation.KlafBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @file         cigna.cm.b.bean.CMBZ00BEAN.java
 * @filetype     java source file
 * @brief
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                          성명                                                일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 2. 3.       신규 작성
 *
 */
@KlafBean
public class CMBZ00BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	/**
	 * <pre>
	 * 대상항목 리스트에서 대상 항목 존재여부 체크
	 * </pre>
	 * @param itemList	대상항목List
	 * @param targetItem	대상항목
	 * @return true 존재 false 미존재
	 * @throws ApplicationException
	 * @example
	 */
	public boolean isTarget(String[] itemList, String targetItem){

		for (int i = 0; i < itemList.length; i++) {
			if (targetItem.equals(itemList[i])) {
				return true;
			}
		}

		return false;
	}
	
	 /**
     * <p>space생성</p>
     *  String 뒤에 space를 채운다.
     * @param strVal1 String
     * @param strVal2 String
     * @return String
     */

	public static  String fillSpace(String s, int i) {

        int j = 0;
        int k = 0;
        String s1 = "";
        s1 = s.trim();
        j = s1.length();
        k = i - j;

        if (k > 0){
            for (; j < i; j++)
                s1 = s1 + " ";

        }
        return s1;
    }
	
    /**
     * <p>숫자치환</p>
     *  숫자앞에 0을 채운다. (ex) 1 -> 01, 11 -> 011
     * @param strVal1 String
     * @param strVal2 String
     * @return String
     */
	public static  String fillZero(String s, int i){

        int k = 0;
        int l = 0;
        String s1 = "";
        s1 = s.trim();
        l = s1.length();
        k = i - l;
        if (k > 0){
            for (int j = 0; j < k; j++)
                s1 = "0" + s1;

        }
        return s1;
    }
	
	/**
     * 현재 날짜,시간을 문자열로 반환한다. (EX) 20120812123023
     *
     * @param
     * @return String 현재날짜, 시간 문자열
     */
    public static String currentDateTime() {
        String result = null;

        result = DateUtils.getCurrentDate(2) + DateUtils.getCurrentTime(6);

        return result;
    }
	
}

