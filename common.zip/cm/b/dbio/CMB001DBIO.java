/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Mon Apr 24 19:09:49 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB001DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB001DBIO
{

	/**
	 * @TestValues 	pyrcTxRfNo=PATX2013000000124035;	pyrcTxRfNoDcd=PA;	trsfDt=20121201;	rltmBzDcd=;
	 */
	cigna.cm.b.io.TBCMRTM001Io selectOneTBCMRTM0011(@Param("pyrcTxRfNo")
			java.lang.String pyrcTxRfNo, @Param("pyrcTxRfNoDcd")
			java.lang.String pyrcTxRfNoDcd, @Param("trsfDt")
			java.lang.String trsfDt, @Param("rltmBzDcd")
			java.lang.String rltmBzDcd);

	/**
	 * @TestValues 	rltmTrsfTxNo=;
	 */
	cigna.cm.b.io.TBCMRTM001Io selectOneTBCMRTM0010(
			@Param("rltmTrsfTxNo")
			java.lang.String rltmTrsfTxNo);

	/**
	 * @TestValues 	mknoPrcsDt=20120101;	fininCd=002;
	 */
	java.lang.String selectOneTBCMRTM0020(
			@Param("mknoPrcsDt")
			java.lang.String mknoPrcsDt, @Param("fininCd")
			java.lang.String fininCd);

	/**
	 * 전문번호 생성
	 * @TestValues 	fininCd=;	mknoPrcsDt=;	mknoTgmNo=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMRTM0020(cigna.cm.b.io.TBCMRTM002Io tBCMRTM002Io);

	/**
	 * @TestValues 	fininCd=;	mknoPrcsDt=;	mknoTgmNo=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM0020(cigna.cm.b.io.TBCMRTM002Io tBCMRTM002Io);

	/**
	 * @TestValues 	actMgntNo=30305312350111118002;
	 */
	cigna.cm.b.io.TBCSFCR001Io selectOneTBCSFCR0010(@Param("actMgntNo")
	java.lang.String actMgntNo);

	/**
	 * @TestValues 	fininCd=023;	imtrsfChnlDcd=0001;
	 */
	cigna.cm.b.io.TBCMRTM006Io selectOneTBCMRTM0060(
			@Param("fininCd")
			java.lang.String fininCd, @Param("imtrsfChnlDcd")
			java.lang.String imtrsfChnlDcd);

	/**
	 * 리얼타임이체원장 입력
	 * @TestValues 	rltmTrsfTxNo=1;	rltmBzDcd=2;	trsfDt=3;	trsfDofOrgNo=4;	trsfFofOrgNo=5;	trsfPrcsEno=6;	payRcPathCd=7;	pyprcPathCd=8;	pyprcCd=9;	payRcMcd=1;	tpayAmt=2;	trsfAmt=3;	benfcCustNo=4;	contrCustNo=5;	dpwdDcd=6;	trsfObjFininCd=7;	actNo=;	achdNm=8;	achdRrno=1;	rltmTrsfPmpsNo=;	trsfPrcsFininCd=2;	rltmTrmsDcd=3;	trsfPrcsTi=4;	cmpyImtrsfRcd=5;	fininImtrsfRcd=6;	bfCmpyImtrsfRcd=7;	bfFininImtrsfRcd=8;	rltmTgmNo=9;	kftcTgmNo=1;	rfActMgntNo=2;	pyrcTxRfNoDcd=3;	pyrcTxRfNo=4;	reqPgmId=5;	reqMetdId=6;	nrmCnclDcd=7;	wtrsfAsntEvidDcd=;	propoDeptOrgNo=;	moActNo=;	delYn=8;	lastChgDtm=;	lastChgrId=9;	lastChgPgmId=1;	lastChgTrmNo=2;
	 */
	int insertOneTBCMRTM0010(cigna.cm.b.io.TBCMRTM001Io tBCMRTM001Io);

	/**
	 * @TestValues 	rltmTrsfTxNo=;	rltmBzDcd=;	trsfDt=;	trsfDofOrgNo=;	trsfFofOrgNo=;	trsfPrcsEno=;	payRcPathCd=;	pyprcPathCd=;	pyprcCd=;	payRcMcd=;	tpayAmt=;	trsfAmt=;	benfcCustNo=;	contrCustNo=;	dpwdDcd=;	trsfObjFininCd=;	actNo=;	achdNm=;	achdRrno=;	rltmTrsfPmpsNo=;	trsfPrcsFininCd=;	rltmTrmsDcd=;	trsfPrcsTi=;	cmpyImtrsfRcd=;	fininImtrsfRcd=;	bfCmpyImtrsfRcd=;	bfFininImtrsfRcd=;	rltmTgmNo=;	kftcTgmNo=;	rfActMgntNo=;	pyrcTxRfNoDcd=;	pyrcTxRfNo=;	reqPgmId=;	reqMetdId=;	nrmCnclDcd=;	wtrsfAsntEvidDcd=;	propoDeptOrgNo=;	moActNo=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM0010(cigna.cm.b.io.TBCMRTM001Io tBCMRTM001Io);

	/**
	 * @TestValues 	rltmTrsfTxNo=;	rltmBzDcd=;	trsfDt=;	trsfDofOrgNo=;	trsfFofOrgNo=;	trsfPrcsEno=;	payRcPathCd=;	pyprcPathCd=;	pyprcCd=;	payRcMcd=;	tpayAmt=;	trsfAmt=;	benfcCustNo=;	contrCustNo=;	dpwdDcd=;	trsfObjFininCd=;	actNo=;	achdNm=;	achdRrno=;	rltmTrsfPmpsNo=;	trsfPrcsFininCd=;	rltmTrmsDcd=;	trsfPrcsTi=;	cmpyImtrsfRcd=;	fininImtrsfRcd=;	bfCmpyImtrsfRcd=;	bfFininImtrsfRcd=;	rltmTgmNo=;	kftcTgmNo=;	rfActMgntNo=;	pyrcTxRfNoDcd=;	pyrcTxRfNo=;	reqPgmId=;	reqMetdId=;	nrmCnclDcd=;	wtrsfAsntEvidDcd=;	propoDeptOrgNo=;	moActNo=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM0011(cigna.cm.b.io.TBCMRTM001Io tBCMRTM001Io);

	/**
	 * 리얼타임전문로그 입력
	 * @TestValues 	tgmLogTxNo=;	logPrcsDt=;	logPrcsTi=;	trsfPrcsFininCd=;	rltmTgmNo=;	tgmCtnt=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMRTM0040(cigna.cm.b.io.TBCMRTM004Io tBCMRTM004Io);

	/**
	 * @TestValues 	fininCd=;	prcsDtm=;	moActNo=;	moActBamt=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMRTM0110(cigna.cm.b.io.TBCMRTM011Io tBCMRTM011Io);

	/**
	 * @TestValues 	fininCd=;	prcsDtm=;	moActNo=;	moActBamt=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM0110(cigna.cm.b.io.TBCMRTM011Io tBCMRTM011Io);

	/**
	 * 리얼타임착오전문 입력
	 * @TestValues 	rltmTgmNo=1;	mstkTgmSeq=2;	trsfMstkDt=3;	rltmTrsfTxNo=4;	mstkTgmPrcsDofOrgNo=5;	mstkTgmPrcsFofOrgNo=6;	mstkTgmPrcsTi=7;	trsfPrcsFininCd=8;	mstkTpcd=9;	mstkStaVrfcYn=1;	fininCd=2;	actNo=3;	dpwdDcd=4;	rltmPrcsAmt=5;	tgmCtnt=6;	lastChgDtm=;	lastChgrId=7;	lastChgPgmId=8;	lastChgTrmNo=9;
	 */
	int insertOneTBCMRTM0030(cigna.cm.b.io.TBCMRTM003Io tBCMRTM003Io);

	/**
	 * @TestValues 	rltmTgmNo=;	mstkTgmSeq=;	trsfMstkDt=;	rltmTrsfTxNo=;	mstkTgmPrcsDofOrgNo=;	mstkTgmPrcsFofOrgNo=;	mstkTgmPrcsTi=;	trsfPrcsFininCd=;	mstkTpcd=;	mstkStaVrfcYn=;	fininCd=;	actNo=;	dpwdDcd=;	rltmPrcsAmt=;	tgmCtnt=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM0030(cigna.cm.b.io.TBCMRTM003Io tBCMRTM003Io);

	cigna.cm.b.io.SelectOneTBCMRTM0041Out selectOneTBCMRTM0041();

	/**
	 * 리얼타임출금이체동의 단건조회 sql
	 * @TestValues 	actMgntNo=;
	 */
	cigna.cm.b.io.TBCSFCR003Io selectOneTBCSFCR0030(@Param("actMgntNo")
	java.lang.String actMgntNo);

	/**
	 * @TestValues 	trsfDt=20130819;	trsfObjFininCd=048;	rltmTgmNo=100005;
	 */
	cigna.cm.b.io.TBCMRTM001Io selectOneTBCMRTM0012(
			@Param("trsfDt")
			java.lang.String trsfDt, @Param("trsfObjFininCd")
			java.lang.String trsfObjFininCd, @Param("rltmTgmNo")
			java.lang.String rltmTgmNo);

	/**
	 * 모계좌잔액조회
	 * @TestValues 	fininCd=;
	 */
	java.lang.String selectOneTBCMRTM0110(
			@Param("fininCd")
			java.lang.String fininCd);

	/**
	 * @TestValues 	anceScrnNm=1;
	 */
	int deleteOneTBCMRTM00501(@Param("anceScrnNm")
	java.lang.String anceScrnNm);

	/**
	 * @TestValues 	anceScrnNm=1;	anceStrtDt=1;	anceStrtTi=1;	anceEndDt=1;	anceEndTi=1;	anceCtnt=1;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int insertOneTBCMRTM00501(cigna.cm.b.io.TBCMRTM005Io tBCMRTM005Io);

	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0050Out> selectMultiTBCMRTM00501();

	/**
	 * @TestValues 	anceScrnNm=;
	 */
	cigna.cm.b.io.SelectOneTBCMRTM0050Out selectOneTBCMRTM0050(
			@Param("anceScrnNm")
			java.lang.String anceScrnNm);

	/**
	 * @TestValues 	anceScrnNm=11;	anceStrtDt=1;	anceStrtTi=1;	anceEndDt=1;	anceEndTi=1;	anceCtnt=1;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int updateOneTBCMRTM00501(cigna.cm.b.io.TBCMRTM005Io tBCMRTM005Io);

	/**
	 * 응답코드조회
	 * @TestValues 	fininCd=;	imtrsfRcd=;	pageNum=0;	pageCount=0;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM008aOut> selectMultiTBCMRTM0080(
			@Param("fininCd")
			java.lang.String fininCd, @Param("imtrsfRcd")
			java.lang.String imtrsfRcd, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount);

	/**
	 * 응답코드등록
	 * @TestValues 	fininCd=;	imtrsfRcd=;	rltmAnswCtnt=;	rltmTrtmCtnt=;	rltmCautnCtnt=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMRTM00801(cigna.cm.b.io.TBCMRTM008Io tBCMRTM008Io);

	/**
	 * 응답코드중복조회
	 * @TestValues 	fininCd=;	imtrsfRcd=;
	 */
	cigna.cm.b.io.SelectOneTBCMRTM0080Out selectOneTBCMRTM0080(
			@Param("fininCd")
			java.lang.String fininCd, @Param("imtrsfRcd")
			java.lang.String imtrsfRcd);

	/**
	 * 응답코드수정
	 * @TestValues 	fininCd=;	imtrsfRcd=;	rltmAnswCtnt=;	rltmTrtmCtnt=;	rltmCautnCtnt=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM00801(cigna.cm.b.io.TBCMRTM008Io tBCMRTM008Io);

	/**
	 * 응답코드삭제
	 * @TestValues 	fininCd=;	imtrsfRcd=;
	 */
	int deleteOneTBCMRTM00801(@Param("fininCd")
			java.lang.String fininCd, @Param("imtrsfRcd")
			java.lang.String imtrsfRcd);

	/**
	 * 응답코드삭제
	 * @TestValues 	fininCd=;
	 */
	int deleteOneTBCMRTM00802(@Param("fininCd")
	java.lang.String fininCd);

	/**
	 * 대표은행코드조회
	 * @TestValues 	fininCd=015;
	 */
	java.lang.String selectOneTBCSFCR0071(
			@Param("fininCd")
			java.lang.String fininCd);

	/**
	 * 리얼타임출금이체 동의이력등록
	 * @TestValues 	actMgntNo=1111;	wtrsfAsntHisSeq=;	rltmTrsfPmpsNo=1;	wtrsfAsntStaDcd=1;	rltmTrsfPmpsRegDcd=1;	wtrsfAsntMcd=1;	wtrsfAsntPrcsDt=1;	wtrsfAsntRescsDt=1;	fininRltmAnswCd=1;	rltmTrsfTxNo=1;	lastHisYn=;	fstCrtDtm=;	fstCrtOrgNo=1;	fstCrtrId=1;	delYn=;	lastChgDtm=;	lastChgOrgNo=1;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int insertOneTBCSFCR003(cigna.cm.b.io.TBCSFCR003Io tBCSFCR003Io);

	/**
	 * 리얼타임 출금이체동의정보 수정
	 * @TestValues 	actMgntNo=1;	wtrsfAsntHisSeq=;	rltmTrsfPmpsNo=1;	wtrsfAsntStaDcd=1;	rltmTrsfPmpsRegDcd=1;	wtrsfAsntMcd=1;	wtrsfAsntPrcsDt=1;	wtrsfAsntRescsDt=1;	fininRltmAnswCd=1;	rltmTrsfTxNo=1;	lastHisYn=1;	fstCrtDtm=;	fstCrtOrgNo=;	fstCrtrId=;	delYn=1;	lastChgDtm=;	lastChgOrgNo=1;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int updateOneTBCSFCR003(cigna.cm.b.io.TBCSFCR003Io tBCSFCR003Io);

	java.lang.String selectOneTBCMRTM0042();

	/**
	 * @TestValues 	imtrsfChnlDcd=;	fininCd=;	fininNm=;	moActNo=;	fininMgntCmpyCd1=;	fininMgntCmpyCd2=;	fininMgntCmpyCd3=;	bzPtnrDcd=;	dpwdPtnrDcd=;	fininPdofOrgNo=;	fininPtnrFofOrgNo=;	opnRegYn=;	restaRegYn=;	wdmRegYn=;	trsfIcmpRegYn=;	totPrcsRegYn=;	endPrcsRegYn=;	testTgmRegYn=;	obsNotifRegYn=;	obsRcovRegYn=;	endRsvRegYn=;	notifEndRegYn=;	trrvTxNo=;	regEno=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM0060(cigna.cm.b.io.TBCMRTM006Io tBCMRTM006Io);

	/**
	 *리얼타임납부자번호조회
	 */
	java.lang.String selectOneTBCMRTM0013();

	/**
	 * @TestValues 	imtrsfChnlDcd2=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0060Out> selectMultiTBCMRTM0060(
			@Param("imtrsfChnlDcd2")
			java.lang.String imtrsfChnlDcd2);

	/**
	 * @TestValues 	fininCd=;	actNo=;
	 */
	cigna.cm.b.io.TBCSFCR001Io selectOneTBCSFCR0011(@Param("fininCd")
	java.lang.String fininCd, @Param("actNo")
	java.lang.String actNo);

	/**
	 * 발의부서,업무구분별 모계좌금융기관조회
	 * @TestValues 	propoDeptOrgNo=100980;	moActBzDcd=01;
	 */
	java.lang.String selectOneTBCMRTM0240(
			@Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo, @Param("moActBzDcd")
			java.lang.String moActBzDcd);

	/**
	 * 발의부서,업무구분,모계좌금융기관은행별 모계좌조회
	 * @TestValues 	propoDeptOrgNo=100980;	moActBzDcd=01;	moActFininCd=003;
	 */
	cigna.cm.b.io.TBCMRTM024Io selectOneTBCMRTM0241(
			@Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo, @Param("moActBzDcd")
			java.lang.String moActBzDcd, @Param("moActFininCd")
			java.lang.String moActFininCd);

	/**
	 * 발의부서별 입금 모계좌 조회
	 * @TestValues 	propoDeptOrgNo=;	moActBzDcd=;	moActFininCd=;
	 */
	java.lang.String selectOneTBCMRTM0242(
			@Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo, @Param("moActBzDcd")
			java.lang.String moActBzDcd, @Param("moActFininCd")
			java.lang.String moActFininCd);

	/**
	 * RTB 처리 중 대상 조회
	 * @TestValues 	pyrcTxRfNo=;	pyrcTxRfNoDcd=;	trsfDt=;	rltmBzDcd=;
	 */
	cigna.cm.b.io.TBCMRTM001Io selectOneTBCMRTM0014(
			@Param("pyrcTxRfNo")
			java.lang.String pyrcTxRfNo, @Param("pyrcTxRfNoDcd")
			java.lang.String pyrcTxRfNoDcd, @Param("trsfDt")
			java.lang.String trsfDt, @Param("rltmBzDcd")
			java.lang.String rltmBzDcd);

	/**
	 * 발의부서의 조직종류조회
	 * @TestValues 	orgNo=;
	 */
	java.lang.String selectOneTBSLORG001a(@Param("orgNo")
	java.lang.String orgNo);

	/**
	 * 카드단말기번호 조회
	 * @TestValues 	propoDeptOrgNo=;	moActBzDcd=;
	 */
	java.lang.String selectOneTBCMRTM0243(
			@Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo, @Param("moActBzDcd")
			java.lang.String moActBzDcd);

	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0240Out> selectMultiTBCMRTM0240();

	/**
	 * @TestValues 	moActMgntNo=;	propoDeptOrgNo=;	moActBzDcd=;	moActFininCd=;	moActNo=;	instCmpyNo=;	adptStrtDt=;	adptEndDt=;	regEno=;	opnRegYn=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM0240(cigna.cm.b.io.TBCMRTM024Io tBCMRTM024Io);

	/**
	 * 이체처리결과전문 처리 후 원거래 결과코드 UPDATE
	 * @TestValues 	cmpyImtrsfRcd=;	fininImtrsfRcd=;	rltmTrmsDcd=;	propoDeptOrgNo=;	moActNo=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;	pyrcTxRfNoDcd=;	pyrcTxRfNo=;	rltmBzDcd=;	trsfDt=;
	 */
	int updateOneTBCMRTM0012(
			@Param("cmpyImtrsfRcd")
			java.lang.String cmpyImtrsfRcd, @Param("fininImtrsfRcd")
			java.lang.String fininImtrsfRcd, @Param("rltmTrmsDcd")
			java.lang.String rltmTrmsDcd, @Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo, @Param("moActNo")
			java.lang.String moActNo, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo, @Param("pyrcTxRfNoDcd")
			java.lang.String pyrcTxRfNoDcd, @Param("pyrcTxRfNo")
			java.lang.String pyrcTxRfNo, @Param("rltmBzDcd")
			java.lang.String rltmBzDcd, @Param("trsfDt")
			java.lang.String trsfDt);

	/**
	 * 은행응답코드 조회
	 * @TestValues 	fininCd=;	imtrsfRcd=;
	 */
	java.lang.String selectOneTBCMRTM0081(
			@Param("fininCd")
			java.lang.String fininCd, @Param("imtrsfRcd")
			java.lang.String imtrsfRcd);
}