/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Sun Apr 16 19:32:26 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB010DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB010DBIO
{

	/**
	 * 카드관리번호조회
	 * @TestValues 	cardNo=;
	 */
	java.lang.String selectOneTBCSFCR005a(
			@Param("cardNo")
			java.lang.String cardNo);

	/**
	 * 카드전문번호채번
	 */
	java.lang.String selectOneTBCNBAS015a();

	/**
	 * 신용카드단건승인 저장
	 * @TestValues 	cardNo=QF7Op/nYKGX24Gwvr5YgLfTY;	cardTgmNo=134335290547;	crdcdMgntNo=null;	cardTxDt=20160613;	contNo=1130016025;	bzCd=DP;	cardTxDcd=FA;	mipMcnt=;	sprm=53195;	msgCtnt1=;	msgCtnt2=;	cardAprvNo=00000000;	cardTxRstYn=;	cardAffstNo=0000000000000;	issueCardCopCd=00;	buyCardCopCd=00;	cardAprvRcd=;	fstCrtDtm=;	fstCrtrId=T00000020N;	lastChgDtm=;	lastChgrId=T00000020N;	lastChgPgmId=DPB010SVC;	lastChgTrmNo=10.128.71.237;	trmNo=;	prpsNo=;	trsfFofOrgNo=;	propoDeptOrgNo=;
	 */
	int insertOneTBCMRTM015a(cigna.cm.b.io.TBCMRTM015Io tBCMRTM015Io);

	/**
	 * 신용카드단건승인 수정
	 * @TestValues 	cardNo=;	cardTgmNo=;	crdcdMgntNo=;	cardTxDt=;	contNo=;	bzCd=;	cardTxDcd=;	mipMcnt=;	sprm=;	msgCtnt1=;	msgCtnt2=;	cardAprvNo=;	cardTxRstYn=;	cardAffstNo=;	issueCardCopCd=;	buyCardCopCd=;	cardAprvRcd=;	fstCrtDtm=;	fstCrtrId=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;	trmNo=;	prpsNo=;	trsfFofOrgNo=;	propoDeptOrgNo=;
	 */
	int updateOneTBCMRTM015a(cigna.cm.b.io.TBCMRTM015Io tBCMRTM015Io);

	/**
	 * 신용카드 조회(카드번호로조회)
	 * @TestValues 	cardNo=;
	 */
	cigna.cm.b.io.TBCSFCR005Io selectOneTBCSFCR0051(
			@Param("cardNo")
			java.lang.String cardNo);

	/**
	 * @TestValues 	crdcdMgntNno=;	cardAprvNo=;
	 */
	cigna.cm.b.io.SelectOneTBCMRTM015aOut selectOneTBCSFCR0052(
			@Param("crdcdMgntNno")
			java.lang.String crdcdMgntNno, @Param("cardAprvNo")
			java.lang.String cardAprvNo);

	/**
	 * 신용카드단건승인조회
	 * @TestValues 	crdcdMgntNno=;	cardAprvNo=;
	 */
	cigna.cm.b.io.SelectOneTBCMRTM015aOut selectOneTBCMRTM0151(
			@Param("crdcdMgntNno")
			java.lang.String crdcdMgntNno, @Param("cardAprvNo")
			java.lang.String cardAprvNo);

	/**
	 * binno 테이블에서 매입사코드조회
	 * @TestValues 	binNo=;
	 */
	java.lang.String selectOneTBCMETC013a(@Param("binNo")
	java.lang.String binNo);

	/**
	 * 신용카드이체원장insert
	 * @TestValues 	crdcdTrsfTxNo=;	cardTgmNo=;	crdcdMgntNo=;	cardTxDt=;	contNo=;	bzCd=;	cardTxDcd=;	mipMcnt=;	sprm=;	msgCtnt1=;	msgCtnt2=;	cardAprvNo=;	cardTxRstYn=;	cardAffstNo=;	issueCardCopCd=;	buyCardCopCd=;	cardAprvRcd=;	fstCrtDtm=;	fstCrtrId=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;	trmNo=;	prpsNo=;	trsfFofOrgNo=;	propoDeptOrgNo=;
	 */
	int insertOneTBCMRTM027a(cigna.cm.b.io.TBCMRTM027Io tBCMRTM027Io);

	/**
	 * 신용카드이체원장 update
	 * @TestValues 	crdcdTrsfTxNo=;	cardTgmNo=;	crdcdMgntNo=;	cardTxDt=;	contNo=;	bzCd=;	cardTxDcd=;	mipMcnt=;	sprm=;	msgCtnt1=;	msgCtnt2=;	cardAprvNo=;	cardTxRstYn=;	cardAffstNo=;	issueCardCopCd=;	buyCardCopCd=;	cardAprvRcd=;	fstCrtDtm=;	fstCrtrId=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;	trmNo=;	prpsNo=;	trsfFofOrgNo=;	propoDeptOrgNo=;
	 */
	int updateOneTBCMRTM027a(cigna.cm.b.io.TBCMRTM027Io tBCMRTM027Io);

	/**
	 * 카드번호 건수 조회
	 * @TestValues 	cardNo=;
	 */
	java.lang.Integer selectOneTBCSFCR0053(
			@Param("cardNo") java.lang.String cardNo);
}