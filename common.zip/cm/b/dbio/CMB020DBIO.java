/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Thu Aug 11 12:15:41 KST 2016
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB020DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB020DBIO
{

	/**
	 * 모바일이체원장거래번호 채번
	 */
	java.lang.String selectOneTBCMRTM016();

	/**
	 * 모바일이체원장 저장
	 * @TestValues 	mblTrsfTxNo=;	mblBzDcd=;	trsfDt=;	trsfDofOrgNo=;	trsfFofOrgNo=;	trsfPrcsEno=;	membMpno=;	mccDcd=;	trsfAmt=;	membRrno=;	mblTgmNo=;	mblCrtfNo=;	smsCrtfNo=;	carrPinAdptYn=;	autoStlmAdptDcd=;	mblTrsfRcd=;	mblTrsfRstMsgCtnt=;	mblasTxNo=;	rmnLmtAmt=;	prcsDtm=;	reprdRskMphonYn=;	crtfWayCd=;	pyrcTxRfNoDcd=;	pyrcTxRfNo=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMRTM016a(cigna.cm.b.io.TBCMRTM016Io tBCMRTM016Io);

	/**
	 * 모바일이체원장 거래 후 수정
	 * @TestValues 	mblTrsfTxNo=;	mblBzDcd=;	trsfDt=;	trsfDofOrgNo=;	trsfFofOrgNo=;	trsfPrcsEno=;	membMpno=;	telDcd=;	trsfAmt=;	membRrno=;	mblTgmNo=;	mblCrtfNo=;	smsCrtfNo=;	carrPinAdptYn=;	autoStlmAdptDcd=;	mblTrsfRcd=;	mblTrsfRstMsgCtnt=;	mblasTxNo=;	rmnLmtAmt=;	prcsDtm=;	reprdRskMphonYn=;	crtfWayCd=;	pyrcTxRfNoDcd=;	pyrcTxRfNo=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMRTM016a(cigna.cm.b.io.TBCMRTM016Io tBCMRTM016Io);
}