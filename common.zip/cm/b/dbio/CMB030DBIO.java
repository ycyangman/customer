/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue Apr 25 18:12:13 KST 2017
 */
package cigna.cm.b.dbio;

import java.util.List;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

import cigna.cm.b.io.SelectMultiTBCMRTM013aOut;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB030DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB030DBIO
{

	/**
	 * 가상계좌발급내역조회
	 * @TestValues 	vactIssueMgntNo=004538654;	vactUsageCd=02;	pageNum=1;	pageCount=5;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM013aOut> selectMultiTBCMRTM013a(
			@Param("vactIssueMgntNo")
			java.lang.String vactIssueMgntNo, @Param("vactUsageCd")
			java.lang.String vactUsageCd, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount);

	/**
	 * 미발급 가상계좌 조회
	 * @TestValues 	useYn=N;	fininCd=004;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM013aOut> selectMultiTBCMRTM012a(
			@Param("useYn")
			java.lang.String useYn, @Param("fininCd")
			java.lang.String fininCd);

	/**
	 * 가상계좌채번
	 */
	java.lang.String selectOneTBCMRTM013();

	/**
	 *  고객가상계좌 테이블 사용여부 수정처리
	 * @TestValues 	useYn=N;	vactNo=13792680206137;	lastChgTrmNo=;	fininCd=;	vactDscNo=;	delYn=;	lastChgPgmId=;	lastChgrId=;
	 */
	int updateOneTBCMRTM012a(@Param("useYn")
			java.lang.String useYn, @Param("vactNo")
			java.lang.String vactNo, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo, @Param("fininCd")
			java.lang.String fininCd, @Param("vactDscNo")
			java.lang.String vactDscNo, @Param("delYn")
			java.lang.String delYn, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgrId")
			java.lang.String lastChgrId);

	/**
	 * 고객가상계좌발급 테이블 발급 처리
	 * @TestValues 	vactDscNo=1000000;	vactUsageCd=;	vactIssueMgntNo=831128001;	contNo=;	vldStrtDt=20160216;	vldEndDt=20160216;	fstCrtrId=1600002000;	delYn=N;	lastChgrId=1600002000;	lastChgPgmId=DPF260SVC;	lastChgTrmNo=10.128.71.237;
	 */
	int insertOneTBCMRTM013a(@Param("vactDscNo")
			java.lang.String vactDscNo, @Param("vactUsageCd")
			java.lang.String vactUsageCd, @Param("vactIssueMgntNo")
			java.lang.String vactIssueMgntNo, @Param("contNo")
			java.lang.String contNo, @Param("vldStrtDt")
			java.lang.String vldStrtDt, @Param("vldEndDt")
			java.lang.String vldEndDt, @Param("fstCrtrId")
			java.lang.String fstCrtrId, @Param("delYn")
			java.lang.String delYn, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo);

	/**
	 * 고객가상계좌발급 수정처리
	 * @TestValues 	fstCrtrId=;	vactIssueMgntNo=;	vactUsageCd=;	vactDscNo=;	vldStrtDt=;	delYn=;	vldEndDt=;	contNo=;	lastChgTrmNo=;	lastChgPgmId=;	lastChgrId=;	rescsDt=;
	 */
	int updateOneTBCMRTM013a(@Param("fstCrtrId")
			java.lang.String fstCrtrId, @Param("vactIssueMgntNo")
			java.lang.String vactIssueMgntNo, @Param("vactUsageCd")
			java.lang.String vactUsageCd, @Param("vactDscNo")
			java.lang.String vactDscNo, @Param("vldStrtDt")
			java.lang.String vldStrtDt, @Param("delYn")
			java.lang.String delYn, @Param("vldEndDt")
			java.lang.String vldEndDt, @Param("contNo")
			java.lang.String contNo, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("rescsDt")
			java.lang.String rescsDt);

	/**
	 * 고객가상계좌발급 내역 조회
	 * @TestValues 	vactNo=;
	 */
	cigna.cm.b.io.SelectOneTBCMRTM013aOut selectOneTBCMRTM013a(@Param("vactNo")
	java.lang.String vactNo);

	/**
	 * 고객가상계좌이체신청내역
	 * @TestValues 	fininCd=011;	vactNo=1;
	 */
	cigna.cm.b.io.TBDPEPY016Io selectOneTBDPEPY016b(
			@Param("fininCd")
			java.lang.String fininCd, @Param("vactNo")
			java.lang.String vactNo);

	/**
	 * 가상계좌이체결과
	 * @TestValues 	fininCd=;	vactNo=;	vactTgmTxDt=;	vactTgmTxNo=;	vactIssueMgntNo=;	vactUsageCd=;	fininDofCd=;	vactAchdNm=;	trsfRmtrNm=;	vactTrsfPrcsAmt=;	vactFee=;	vactMoActNo=;	vactTgmAnswCd=;	vactOccuDcd=;	vactTgmTxTi=;	nrmCnclDcd=;	cnclDtm=;	vactTrsfBzDcd=;	bkkpSlipPropoOrgNo=;	bkkpSlipPropoDt=;	xcDt=;	trsfPrcsDofOrgNo=;	trsfPrcsFofOrgNo=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBDPEPY015a(cigna.cm.b.io.TBDPEPY015Io tBDPEPY015Io);

	/**
	 * 가상계좌이체결과 수정
	 * @TestValues 	fininCd=;	vactNo=;	vactTgmTxDt=;	vactTgmTxNo=;	vactIssueMgntNo=;	vactUsageCd=;	fininDofCd=;	vactAchdNm=;	trsfRmtrNm=;	vactTrsfPrcsAmt=;	vactFee=;	vactMoActNo=;	vactTgmAnswCd=;	vactOccuDcd=;	vactTgmTxTi=;	nrmCnclDcd=;	cnclDtm=;	vactTrsfBzDcd=;	bkkpSlipPropoOrgNo=;	bkkpSlipPropoDt=;	xcDt=;	trsfPrcsDofOrgNo=;	trsfPrcsFofOrgNo=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBDPEPY015a(cigna.cm.b.io.TBDPEPY015Io tBDPEPY015Io);

	/**
	 * 고객가상계좌전문 입력
	 * @TestValues 	vactTgmTxDt=;	vactTgmTxNo=;	vactTgmCtgyCd=;	vactTgmLen=;	hndlInstCd=;	trrvDcd=;	vactTgmTxTi=;	fininCd=;	vactTgmAnswCd=;	vactFee=;	vavsRsvtTeryVl=;	usrTxNo=;	vactOccuDcd=;	tgmTrmsDcd=;	rsvtTeryCd=;	vactTgmCtnt=;	delYn=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMRTM014a(cigna.cm.b.io.TBCMRTM014Io tBCMRTM014Io);

	/**
	 * 가상계좌채번조회
	 * @TestValues 	vactTgmTxDt=20160321;	vactTgmCtgyCd=2000;
	 */
	java.lang.String selectOneTBCMRTM014(
			@Param("vactTgmTxDt")
			java.lang.String vactTgmTxDt, @Param("vactTgmCtgyCd")
			java.lang.String vactTgmCtgyCd);

	/**
	 * 가상계좌집계 데이터 insert
	 * @TestValues 	vactTgmTxDt=;	vactTgmTxNo=;	vactTgmCtgyCd=;	fininCd=;	nrmDpsCnt=;	nrmDpsAmt=;	cnclDpsCnt=;	cnclDpsAmt=;	nrmWdmCnt=;	nrmWdmAmt=;	cnclWdmCnt=;	cnclWdmAmt=;	feeCnt=;	feeAmt=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMRTM020a(cigna.cm.b.io.TBCMRTM020Io tBCMRTM020Io);

	/**
	 * 가상계좌 사용현황
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM012aOut> selectMultiTBCMRTM012b();

	/**
	 * 가상계좌 입금 처리건 조회
	 * @TestValues 	fininCd=;	vactNo=;
	 */
	cigna.cm.b.io.TBDPEPY016Io selectOneTBDPEPY016c(
			@Param("fininCd")
			java.lang.String fininCd, @Param("vactNo")
			java.lang.String vactNo);

	/**
	 * @TestValues 	contNo=1;
	 */
	java.lang.String selectOneTBCNBAS001a(
			@Param("contNo")
			java.lang.String contNo);
}