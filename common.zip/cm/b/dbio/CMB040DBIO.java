/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Thu Jan 12 17:00:39 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB040DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB040DBIO
{

	/**
	 * 출금이체동의처리내역 INSERT
	 * @TestValues 	wtrsfAsntPrcsMgntNo=;	wtrsfAsntDt=1;	wtrsfAsntTi=1;	wtrsfAsntSysCd=1;	wtrsfAsntEvidDcd=1;	wtrsfAsntEvidNo=1;	wtrsfAsntDcd=1;	wtrsfAsntRcDcd=1;	contNo=1;	pmpsNo=1;	contrNm=1;	pmpsDscNo=1;	pmpsNm=1;	fininCd=1;	pmpsActNo=1;	trsfAmt=1;	wtrsfAsntVcrecStrtDtm=1;	wtrsfAsntVcrecEndDtm=1;	centrNm=1;	teamNm=1;	chrgpEno=1;	chrgpNm=1;	bzTxRfDcd=1;	bzTxRfNo=1;	wtrsfAsntNrmYn=1;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int insertOneTBCMETC0150(cigna.cm.b.io.TBCMETC015Io tBCMETC015Io);

	/**
	 * 출금이체동의 정상여부 UPDATE
	 * @TestValues 	bzTxRfNo=;	wtrsfAsntDt=;	wtrsfAsntNrmYn=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMETC0150(@Param("bzTxRfNo")
			java.lang.String bzTxRfNo, @Param("wtrsfAsntDt")
			java.lang.String wtrsfAsntDt, @Param("wtrsfAsntNrmYn")
			java.lang.String wtrsfAsntNrmYn, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo);

	/**
	 * 이체처리결과확인 후 출금이체동의 정상여부 update
	 * @TestValues 	bzTxRfNo=;	wtrsfAsntNrmYn=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMETC0151(@Param("bzTxRfNo")
			java.lang.String bzTxRfNo, @Param("wtrsfAsntNrmYn")
			java.lang.String wtrsfAsntNrmYn, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo);

	/**
	 * 출금이체동의 정상처리 대상 조회
	 * @TestValues 	wtrsfAsntPrcsDt=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMETC015Out> selectMultiTBCMETC0150(
			@Param("wtrsfAsntPrcsDt")
			java.lang.String wtrsfAsntPrcsDt);

	/**
	 * 출금이체동의증빙검수내역 insert
	 * @TestValues 	wtrsfAsntVerfMgntNo=;	wtrsfAsntDt=;	wtrsfAsntTi=;	wtrsfAsntSysCd=;	wtrsfAsntEvidDcd=;	wtrsfAsntEvidNo=;	wtrsfAsntDcd=;	wtrsfAsntRcDcd=;	contNo=;	pmpsNo=;	contrNm=;	pmpsDscNo=;	pmpsNm=;	fininCd=;	pmpsActNo=;	trsfAmt=;	wtrsfAsntVcrecStrtDtm=;	wtrsfAsntVcrecEndDtm=;	centrNm=;	teamNm=;	chrgpEno=;	chrgpNm=;	inspRcd=;	evidInspDtm=;	evidInspEno=;	evidInspEmplNm=;	complRcd=;	complUablRscd=;	complUablRsnCtnt=;	complVcrecNo=;	complCallReqDtm=;	complCmptDtm=;	complEno=;	complEmplNm=;	callDcd=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMETC0140(cigna.cm.b.io.TBCMETC014Io tBCMETC014Io);

	/**
	 * 처리여부 update
	 * @TestValues 	wtrsfAsntPrcsMgntNo=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMETC0152(
			@Param("wtrsfAsntPrcsMgntNo")
			java.lang.String wtrsfAsntPrcsMgntNo, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo);
}