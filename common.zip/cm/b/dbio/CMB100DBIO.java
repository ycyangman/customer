/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Thu Apr 20 17:00:59 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB100DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB100DBIO
{

	/**
	 * 은행별 리얼타임현황 조회
	 * @TestValues 	pageNum=;	pageCount=;	trsfDtFrom=20161116;	trsfDtTo=20161106;	fininCd=%;	trsfFofOrgNo=%;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM001aOut> selectMultiTBCMRTM001a(
			cigna.cm.b.io.SelectMultiTBCMRTM001aIn selectMultiTBCMRTM001aIn);

	/**
	 * 일자별 모바일 이체현황
	 * @TestValues 	pageNum=;	pageCount=;	inqDtFrom=20160801;	inqDtTo=20160810;	telDvsn=;	trsfFofOrgNo=;	bzDvsn=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM016aOut> selectMultiTBCMRTM016a(
			cigna.cm.b.io.SelectMultiTBCMRTM016aIn selectMultiTBCMRTM016aIn);

	/**
	 * 처리자별 모바일 결제 현황
	 * @TestValues 	pageNum=;	pageCount=;	inqDtFrom=20160901;	inqDtTo=20190923;	telDvsn=;	trsfFofOrgNo=;	bzDvsn=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM016bOut> selectMultiTBCMRTM016b(
			cigna.cm.b.io.SelectMultiTBCMRTM016bIn selectMultiTBCMRTM016bIn);

	/**
	 * 모바일 즉시 출금
	 * @TestValues 	custNo=;	membMpno=;	contNo=;	prcsDtm=20160919;	trsfFofOrgNo=;	pageNum=1;	pageCount=10;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM016cOut> selectMultiTBCMRTM016c(
			@Param("custNo")
			java.lang.String custNo, @Param("membMpno")
			java.lang.String membMpno, @Param("contNo")
			java.lang.String contNo, @Param("prcsDtm")
			java.lang.String prcsDtm, @Param("trsfFofOrgNo")
			java.lang.String trsfFofOrgNo, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount);

	/**
	 * 가상계좌 송금내역
	 * @TestValues 	bkkpSlipPropoStrtDt=20160301;	bkkpSlipPropoEndDt=20160331;	fininCd=;	vactUsageCd=;	custNo=;	pageNum=1;	pageCount=1;	vactNo=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBDPEPY015cOut> selectMultiTBDPEPY015c(			
			@Param("bkkpSlipPropoStrtDt")
			java.lang.String bkkpSlipPropoStrtDt, @Param("bkkpSlipPropoEndDt")
			java.lang.String bkkpSlipPropoEndDt, @Param("fininCd")
			java.lang.String fininCd, @Param("vactUsageCd")
			java.lang.String vactUsageCd, @Param("custNo")
			java.lang.String custNo, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount, @Param("vactNo")
			java.lang.String vactNo);

	/**
	 * 미취소명세
	 * @TestValues 	trsfFofOrgNo=326006;	trsfDt=20160302;	payRcPathCd=;	trsfPrcsEno=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0014Out> selectMultiTBCMRTM0014(
			cigna.cm.b.io.SelectMultiTBCMRTM0014In selectMultiTBCMRTM0014In);

	/**
	 * 창구별 계좌이체 처리명세
	 * @TestValues 	trsfDt=20161206;	trsfFofOrgNo=1;	payRcPathCd=1;	rltmTrmsDcd=1;	trsfPrcsFininCd=1;	pageNum=1;	pageCount=5;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0016Out> selectMultiTBCMRTM0016(
			@Param("trsfDt")
			java.lang.String trsfDt, @Param("trsfFofOrgNo")
			java.lang.String trsfFofOrgNo, @Param("payRcPathCd")
			java.lang.String payRcPathCd, @Param("rltmTrmsDcd")
			java.lang.String rltmTrmsDcd, @Param("trsfPrcsFininCd")
			java.lang.String trsfPrcsFininCd, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);

	/**
	 * 은행별계좌이체집계마감
	 * @TestValues 	trsfDt=20161205;	trsfPrcsFininCd=;	trsfFofOrgNo=;	moActBnkCd=020;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0015Out> selectMultiTBCMRTM0015(
			cigna.cm.b.io.SelectMultiTBCMRTM0015In selectMultiTBCMRTM0015In);

	/**
	 * 지급이체 조건별 에러건검색(이체금액)
	 * @TestValues 	trsfDt=20161212;	trsfAmt=1000;	pageNum=1;	pageCount=5;	dpwdDcd=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0017Out> selectMultiTBCMRTM001b(
			@Param("trsfDt")
			java.lang.String trsfDt, @Param("trsfAmt")
			java.lang.String trsfAmt, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount, @Param("dpwdDcd")
			java.lang.String dpwdDcd);

	/**
	 * 지급이체 조건별 에러건검색(계좌번호)
	 * @TestValues 	trsfDt=20160303;	actNo=111;	pageNum=1;	pageCount=5;	dpwdDcd=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0017Out> selectMultiTBCMRTM001c(
			@Param("trsfDt")
			java.lang.String trsfDt, @Param("actNo")
			java.lang.String actNo, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount, @Param("dpwdDcd")
			java.lang.String dpwdDcd);

	/**
	 * 지급이체 조건별 에러건검색(수익자성명)
	 * @TestValues 	trsfDt=20160304;	benfcNm=홍길동;	pageNum=1;	pageCount=4;	dpwdDcd=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0017Out> selectMultiTBCMRTM001d(@Param("trsfDt")
	java.lang.String trsfDt, @Param("benfcNm")
	java.lang.String benfcNm, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount, @Param("dpwdDcd")
	java.lang.String dpwdDcd);

	/**
	 * 지급이체 조건별 에러건검색(주민등록번호)
	 * @TestValues 	trsfDt=20160305;	benfcRrno=111;	pageNum=1;	pageCount=5;	dpwdDcd=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0017Out> selectMultiTBCMRTM001e(@Param("trsfDt")
	java.lang.String trsfDt, @Param("benfcRrno")
	java.lang.String benfcRrno, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount, @Param("dpwdDcd")
	java.lang.String dpwdDcd);

	/**
	 * 지급이체 조건별 에러건검색(응답코드)
	 * @TestValues 	trsfDt=20160306;	trsfRcd=0000;	pageNum=1;	pageCount=5;	dpwdDcd=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0017Out> selectMultiTBCMRTM001f(
			@Param("trsfDt")
			java.lang.String trsfDt, @Param("trsfRcd")
			java.lang.String trsfRcd, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount, @Param("dpwdDcd")
			java.lang.String dpwdDcd);

	/**
	 * @TestValues 	pyrcTxRfNo=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM016cOut> selectMultiTBCMRTM016d(@Param("pyrcTxRfNo")
	java.lang.String pyrcTxRfNo);

	/**
	 * 조건별 - 조건없음
	 * @TestValues 	trsfDt=;	pageNum=;	pageCount=;	dpwdDcd=;
	 */
	java.util.List<cigna.cm.b.io.SelectMultiTBCMRTM0017Out> selectMultiTBCMRTM001g(@Param("trsfDt")
			java.lang.String trsfDt, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount, @Param("dpwdDcd")
			java.lang.String dpwdDcd);
}