/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Fri Feb 17 14:12:29 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB101DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB101DBIO
{

	/**
	 * 모계좌 관리 조회
	 * @TestValues 	propoDeptOrgNo=;	moActBzDcd=;	moActNo=;	moActFininCd=;
	 */
	java.util.List<cigna.cm.b.io.CMB101SVC01Sub> selectMultiTBCMRTM024a(
			@Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo, @Param("moActBzDcd")
			java.lang.String moActBzDcd, @Param("moActNo")
			java.lang.String moActNo, @Param("moActFininCd")
			java.lang.String moActFininCd);

	/**
	 * 모계좌관리 저장
	 * @TestValues 	moActList.moActMgntNo=;	moActList.propoDeptOrgNo=;	moActList.propoDeptOrgNm=;	moActList.moActBzDcd=;	moActList.moActFininCd=;	moActList.moActNo=;	moActList.instCmpyNo=;	moActList.adptStrtDt=;	moActList.adptEndDt=;	moActList.regEno=;	moActList.delYn=;	moActList.lastChgDtm=;	moActList.lastChgrId=;	moActList.lastChgPgmId=;	moActList.lastChgTrmNo=;	moActList.chkYn=;	moActList.flgCd=;
	 */
	int mergeOneTBCMRTM024(
			@Param("moActList")
			cigna.cm.b.io.CMB101SVC01Sub moActList);

	/**
	 * 모계좌 중복 확인
	 * @TestValues 	moActNo=QF5evxUxa/4hfSXkBfrZ8j8f;	propoDeptOrgNo=100980;	moActBzDcd=01;	moActFininCd=003;	adpt_strt_dt=20101001;
	 */
	java.lang.Integer selectMultiTBCMRTM024b(
			@Param("moActNo")
			java.lang.String moActNo, @Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo, @Param("moActBzDcd")
			java.lang.String moActBzDcd, @Param("moActFininCd")
			java.lang.String moActFininCd, @Param("adpt_strt_dt")
			java.lang.String adpt_strt_dt);

	/**
	 * 관리번호 채번
	 */
	java.lang.String selectOneTBCMRTM024();

	/**
	 * 모계좌 중복 건수 조회
	 * @TestValues 	moActNo=;
	 */
	java.lang.Integer selectMultiTBCMRTM024c(
			@Param("moActNo")
			java.lang.String moActNo);
}