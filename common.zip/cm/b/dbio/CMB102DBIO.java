/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Mon Dec 19 14:50:38 KST 2016
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB102DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB102DBIO
{

	/**
	 * 가상계좌통계조회
	 * @TestValues 	trsfYm=;	fininCd=;	vactUsageCd=;
	 */
	java.util.List<cigna.cm.b.io.CMB102SVC01Sub> selectMultiTBDPEPY015a(@Param("trsfYm")
	java.lang.String trsfYm, @Param("fininCd")
	java.lang.String fininCd, @Param("vactUsageCd")
	java.lang.String vactUsageCd);
}