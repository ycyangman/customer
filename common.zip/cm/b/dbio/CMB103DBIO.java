/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Mon Mar 06 20:31:25 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB103DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB103DBIO
{

	/**
	 * 단말기번호관리
	 * @TestValues 	rltmSysCd=01;	pageNum=1;	pageCount=20;
	 */
	java.util.List<cigna.cm.b.io.TBCMRTM023Io> selectMultiTBCMRTM023a(@Param("rltmSysCd")
	java.lang.String rltmSysCd, @Param("pageNum")
	int pageNum, @Param("pageCount")
	int pageCount);

	/**
	 * 단말기번호입력
	 * @TestValues 	trmInfo.chkYn=;	trmInfo.rltmSysCd=;	trmInfo.centrCd=;	trmInfo.trmBzDcd=;	trmInfo.trmDscNo=;	trmInfo.testTrmDscNo=;	trmInfo.useYn=;	trmInfo.delYn=;	trmInfo.lastChgDtm=;	trmInfo.lastChgrId=;	trmInfo.lastChgPgmId=;	trmInfo.lastChgTrmNo=;
	 */
	int insertOneTBCMRTM023a(
			@Param("trmInfo")
			cigna.cm.b.io.TBCMRTM023Io trmInfo);

	/**
	 * 단말기번호수정
	 * @TestValues 	trmInfo.chkYn=;	trmInfo.rltmSysCd=10;	trmInfo.centrCd=001;	trmInfo.trmBzDcd=BCA;	trmInfo.trmDscNo=10;	trmInfo.testTrmDscNo=10;	trmInfo.useYn=Y;	trmInfo.delYn=N;	trmInfo.lastChgDtm=;	trmInfo.lastChgrId=999999999;	trmInfo.lastChgPgmId=MIG;	trmInfo.lastChgTrmNo=00000;
	 */
	int updateOneTBCMRTM023a(
			@Param("trmInfo")
			cigna.cm.b.io.TBCMRTM023Io trmInfo);

	/**
	 * 단말기번호삭제
	 * @TestValues 	trmInfo.chkYn=;	trmInfo.rltmSysCd=;	trmInfo.centrCd=;	trmInfo.trmBzDcd=;	trmInfo.trmDscNo=;	trmInfo.testTrmDscNo=;	trmInfo.useYn=;	trmInfo.delYn=;	trmInfo.lastChgDtm=;	trmInfo.lastChgrId=;	trmInfo.lastChgPgmId=;	trmInfo.lastChgTrmNo=;
	 */
	int deleteOneTBCMRTM023a(
			@Param("trmInfo")
			cigna.cm.b.io.TBCMRTM023Io trmInfo);

	/**
	 * @TestValues 	rltmSysCd=10;	centrCd=001;	trmBzDcd=BCA;
	 */
	java.lang.Integer selectOneTBCMRTM023a(@Param("rltmSysCd")
	java.lang.String rltmSysCd, @Param("centrCd")
	java.lang.String centrCd, @Param("trmBzDcd")
	java.lang.String trmBzDcd);

	/**
	 * 계약자조회
	 * @TestValues 	contNo=;
	 */
	cigna.cm.b.io.TBCSPRF001Io selectOneTBCNBAS001a(
			@Param("contNo")
			java.lang.String contNo);

	/**
	 * 리얼타임 처리 현황
	 * @TestValues 	trsfDt=20161219;	contNo=;
	 */
	java.util.List<cigna.cm.b.io.CMB103SVC02Sub> selectOneTBCMRTM001a(
			@Param("trsfDt")
			java.lang.String trsfDt, @Param("contNo")
			java.lang.String contNo);

	/**
	 * 통합출금관리 출수납거래번호 채번
	 */
	java.lang.String selectOneTBCMRTM026a();

	/**
	 * 통합출금관리 INSERt
	 * @TestValues 	pyrcTxNo=;	trsfDt=;	trsfDofOrgNo=;	trsfFofOrgNo=;	trsfPrcsEno=;	contNo=;	trsfAmt=;	fininCd=;	actMgntNo=;	propoDeptOrgNo=;	fininPrcsRcd=;	rltmTrsfTrmsDcd=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMRTM026a(cigna.cm.b.io.TBCMRTM026Io tBCMRTM026Io);

	/**
	 * 통합출금관리 처리현황
	 * @TestValues 	trsfDt=;	contNo=;	propoDeptOrgNo=;
	 */
	java.util.List<cigna.cm.b.io.CMB103SVC02Sub> selectMultiTBCMRTM026a(
			@Param("trsfDt")
			java.lang.String trsfDt, @Param("contNo")
			java.lang.String contNo, @Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo);

	/**
	 * 리얼타임 처리 결과 update
	 * @TestValues 	rltmTrsfTrmsDcd=;	fininPrcsRcd=;	pyrcTxNo=;
	 */
	int updateOneTBCMRTM026a(
			@Param("rltmTrsfTrmsDcd")
			java.lang.String rltmTrsfTrmsDcd, @Param("fininPrcsRcd")
			java.lang.String fininPrcsRcd, @Param("pyrcTxNo")
			java.lang.String pyrcTxNo);
}