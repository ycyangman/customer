/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Sun Apr 16 15:12:22 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB105DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB105DBIO
{

	/**
	 * 금융기관제휴업무목록( 안씀 )
	 */
	java.util.List<cigna.cm.b.io.CMB105SVC01Sub> selectMultiTBCMRTM006a();

	/**
	 * @TestValues 	oldFininCd=;
	 */
	java.lang.String selectOneTBCSFCR007a(
			@Param("oldFininCd")
			java.lang.String oldFininCd);

	/**
	 * @TestValues 	fininCd=;	imtrsfRcd=;
	 */
	java.lang.String selectOneTBCMRTM008a(
			@Param("fininCd")
			java.lang.String fininCd, @Param("imtrsfRcd")
			java.lang.String imtrsfRcd);

	/**
	 * @TestValues 	fininCd=;	moActNo=;	prcsDtm=20160805;
	 */
	java.util.List<cigna.cm.b.io.CMB105SVC03Sub> selectMultiTBCMRTM011a(@Param("fininCd")
			java.lang.String fininCd, @Param("moActNo")
			java.lang.String moActNo, @Param("prcsDtm")
			java.lang.String prcsDtm);

	/**
	 * @TestValues 	propoDeptOrgNo=;
	 */
	java.util.List<cigna.cm.b.io.CMB105SVC01Sub> selectMultiTBCMRTM024a(
			@Param("propoDeptOrgNo")
			java.lang.String propoDeptOrgNo);

	/**
	 * 모계좌잔액조회 - 고객서비스팀
	 */
	java.util.List<cigna.cm.b.io.CMB105SVC01Sub> selectMultiTBCMRTM024b();
}