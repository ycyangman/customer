/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Mon Jan 30 14:34:37 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB106DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB106DBIO
{

	/**
	 * 출금동의검수리스트 조회
	 * @TestValues 	wtrsfAsntDtFrom=;	wtrsfAsntDtTo=;	contNo=;	pmpsDscNo=;	pmpsNo=;	wtrsfAsntSysCd=;	wtrsfAsntRcDcd=;	wtrsfAsntEvidDcd=;	wtrsfAsntEvidNo=;	inspRcd=;	complRcd=;	evidInspDtmFrom=;	evidInspDtmTo=;	evidInspEno=;	pageNum=;	pageCount=;
	 */
	java.util.List<cigna.cm.b.io.CMB106SVC01Sub> selectMultiTBCMETC014a(
			@Param("wtrsfAsntDtFrom")
			java.lang.String wtrsfAsntDtFrom, @Param("wtrsfAsntDtTo")
			java.lang.String wtrsfAsntDtTo, @Param("contNo")
			java.lang.String contNo, @Param("pmpsDscNo")
			java.lang.String pmpsDscNo, @Param("pmpsNo")
			java.lang.String pmpsNo, @Param("wtrsfAsntSysCd")
			java.lang.String wtrsfAsntSysCd, @Param("wtrsfAsntRcDcd")
			java.lang.String wtrsfAsntRcDcd, @Param("wtrsfAsntEvidDcd")
			java.lang.String wtrsfAsntEvidDcd, @Param("wtrsfAsntEvidNo")
			java.lang.String wtrsfAsntEvidNo, @Param("inspRcd")
			java.lang.String inspRcd, @Param("complRcd")
			java.lang.String complRcd, @Param("evidInspDtmFrom")
			java.lang.String evidInspDtmFrom, @Param("evidInspDtmTo")
			java.lang.String evidInspDtmTo, @Param("evidInspEno")
			java.lang.String evidInspEno, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);

	/**
	 * 출금동의검수리스트 저장
	 * @TestValues 	dsWtrsfAsnt.wtrsfAsntVerfMgntNo=;	dsWtrsfAsnt.wtrsfAsntEvidNo=;	dsWtrsfAsnt.inspRcd=;	dsWtrsfAsnt.evidInspDtm=;	dsWtrsfAsnt.evidInspEno=;	dsWtrsfAsnt.evidInspEmplNm=;	dsWtrsfAsnt.complCallReqDtm=;	dsWtrsfAsnt.lastChgrId=;	dsWtrsfAsnt.lastChgPgmId=;	dsWtrsfAsnt.lastChgTrmNo=;
	 */
	int updateOneTBCMETC014(
			@Param("dsWtrsfAsnt")
			cigna.cm.b.io.CMB106SVC02In dsWtrsfAsnt);

	/**
	 * @TestValues 	wtrsfAsntDtFrom=20161101;	wtrsfAsntDtTo=20161129;	contNo=;	pmpsDscNo=;	pmpsNo=;	wtrsfAsntSysCd=;	wtrsfAsntRcDcd=;	wtrsfAsntEvidDcd=;	wtrsfAsntEvidNo=;	inspRcd=;	complRcd=;	evidInspDtmFrom=;	evidInspDtmTo=;	evidInspEno=;	randomWtrsfAsntVerfMgntNo=;
	 */
	java.util.List<cigna.cm.b.io.CMB106SVC01Sub> selectMultiTBCMETC014b(
			@Param("wtrsfAsntDtFrom")
			java.lang.String wtrsfAsntDtFrom, @Param("wtrsfAsntDtTo")
			java.lang.String wtrsfAsntDtTo, @Param("contNo")
			java.lang.String contNo, @Param("pmpsDscNo")
			java.lang.String pmpsDscNo, @Param("pmpsNo")
			java.lang.String pmpsNo, @Param("wtrsfAsntSysCd")
			java.lang.String wtrsfAsntSysCd, @Param("wtrsfAsntRcDcd")
			java.lang.String wtrsfAsntRcDcd, @Param("wtrsfAsntEvidDcd")
			java.lang.String wtrsfAsntEvidDcd, @Param("wtrsfAsntEvidNo")
			java.lang.String wtrsfAsntEvidNo, @Param("inspRcd")
			java.lang.String inspRcd, @Param("complRcd")
			java.lang.String complRcd, @Param("evidInspDtmFrom")
			java.lang.String evidInspDtmFrom, @Param("evidInspDtmTo")
			java.lang.String evidInspDtmTo, @Param("evidInspEno")
			java.lang.String evidInspEno, @Param("randomWtrsfAsntVerfMgntNo")
			java.lang.String randomWtrsfAsntVerfMgntNo);

	/**
	 * 출금동의검수리스트 조회(세부내역-팝업)
	 * @TestValues 	wtrsfAsntVerfMgntNo=;
	 */
	cigna.cm.b.io.CMB106SVC01Sub selectOneTBCMETC014a(
			@Param("wtrsfAsntVerfMgntNo")
			java.lang.String wtrsfAsntVerfMgntNo);
}