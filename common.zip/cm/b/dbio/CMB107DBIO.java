/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Thu Mar 09 10:26:02 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB107DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB107DBIO
{

	/**
	 * 보완콜 리스트 조회
	 * @TestValues 	wtrsfAsntDtFrom=;	wtrsfAsntDtTo=;	contNo=;	pmpsDscNo=;	pmpsNo=;	wtrsfAsntSysCd=;	wtrsfAsntRcDcd=;	wtrsfAsntEvidDcd=;	wtrsfAsntEvidNo=;	inspRcd=;	complRcd=;	complCallReqDtmFrom=;	complCallReqDtmTo=;	complCmptDtmFrom=;	complCmptDtmTo=;	complEno=;	pageNum=;	pageCount=;
	 */
	java.util.List<cigna.cm.b.io.CMB107SVC01Sub> selectMultiTBCMETC014a(@Param("wtrsfAsntDtFrom")
	java.lang.String wtrsfAsntDtFrom, @Param("wtrsfAsntDtTo")
	java.lang.String wtrsfAsntDtTo, @Param("contNo")
	java.lang.String contNo, @Param("pmpsDscNo")
	java.lang.String pmpsDscNo, @Param("pmpsNo")
	java.lang.String pmpsNo, @Param("wtrsfAsntSysCd")
	java.lang.String wtrsfAsntSysCd, @Param("wtrsfAsntRcDcd")
	java.lang.String wtrsfAsntRcDcd, @Param("wtrsfAsntEvidDcd")
	java.lang.String wtrsfAsntEvidDcd, @Param("wtrsfAsntEvidNo")
	java.lang.String wtrsfAsntEvidNo, @Param("inspRcd")
	java.lang.String inspRcd, @Param("complRcd")
	java.lang.String complRcd, @Param("complCallReqDtmFrom")
	java.lang.String complCallReqDtmFrom, @Param("complCallReqDtmTo")
	java.lang.String complCallReqDtmTo, @Param("complCmptDtmFrom")
	java.lang.String complCmptDtmFrom, @Param("complCmptDtmTo")
	java.lang.String complCmptDtmTo, @Param("complEno")
	java.lang.String complEno, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount);

	/**
	 * 보완콜 리스트 저장
	 * @TestValues 	dsComplCall.wtrsfAsntVerfMgntNo=;	dsComplCall.complRcd=;	dsComplCall.complUablRscd=;	dsComplCall.complUablRsnCtnt=;	dsComplCall.complEmplNm=;	dsComplCall.complEno=;	dsComplCall.complCmptDtm=;	dsComplCall.lastChgrId=;	dsComplCall.lastChgPgmId=;	dsComplCall.lastChgTrmNo=;	dsComplCall.complVcrecNo=;	dsComplCall.inspRcd=;	dsComplCall.vcrecId=;	dsComplCall.wtrsfAsntEvidNo=;
	 */
	int updateOneTBCMETC014(
			@Param("dsComplCall")
			cigna.cm.b.io.CMB107SVC02In dsComplCall);

	/**
	 * 보완콜리스트상세(팝업)
	 * @TestValues 	wtrsfAsntVerfMgntNo=;
	 */
	cigna.cm.b.io.CMB107SVC01Sub selectOneTBCMETC014a(
			@Param("wtrsfAsntVerfMgntNo")
			java.lang.String wtrsfAsntVerfMgntNo);
}