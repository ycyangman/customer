/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Fri Feb 24 16:54:46 KST 2017
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB110DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB110DBIO
{

	/**
	 * 출금이체동의금결원증빙내역 헤더 조회
	 * @TestValues 	kftcTxDt=;	kftcDochdReqDt=20161024;	svcKcd=2;
	 */
	java.util.List<cigna.cm.b.io.CMB110SVC01Sub> selectMultiTBCMETC017a(
			@Param("kftcTxDt")
			java.lang.String kftcTxDt, @Param("kftcDochdReqDt")
			java.lang.String kftcDochdReqDt, @Param("svcKcd")
			java.lang.String svcKcd);

	/**
	 * 출금이체동의금융결제원요청파일데이터 INSERT
	 * @TestValues 	wtrsfAsntKftcEvidMgntNo=;	kftcReqFileNm=;	kftcTxDt=;	kftcTxTi=;	kftcBzDcd=;	kftcDochdDcd=;	kftcDochdSrno=;	kftcDochdReqDt=;	svcKcd=;	utilInstId=;	fbsResalInstYn=;	bzno=;	reqDataRecCnt=;	dochdPprnFieldVl=;	kftcDocDataDcd=;	dataSrno=;	reqTpcd=;	dataPprnFieldVl=;	kftcPmpsNo=;	fininCd=;	actNo=;	applDt=;	wtrsfAsntEvidDcd=;	lrnkUtilInstId=;	lrnkBzno=;	reqRstYn=;	asntDataExpdId=;	asntDataLen=;	reqPprnFieldVl=;	kftcDoctrDcd=;	kftcDoctrSrno=;	ttlReqCnt=;	dataBlkNum=;	doctrPprnFieldVl=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMETC0170(cigna.cm.b.io.TBCMETC017Io tBCMETC017Io);

	/**
	 * 출금이체동의금융결제원요청파일 UPDATE
	 * @TestValues 	wtrsfAsntKftcEvidMgntNo=;	kftcReqFileNm=;	kftcTxDt=;	kftcTxTi=;	kftcBzDcd=;	kftcDochdDcd=;	kftcDochdSrno=;	kftcDochdReqDt=;	svcKcd=;	utilInstId=;	fbsResalInstYn=;	bzno=;	reqDataRecCnt=;	dochdPprnFieldVl=;	kftcDocDataDcd=;	dataSrno=;	reqTpcd=;	dataPprnFieldVl=;	kftcPmpsNo=;	fininCd=;	actNo=;	applDt=;	wtrsfAsntEvidDcd=;	lrnkUtilInstId=;	lrnkBzno=;	reqRstYn=;	asntDataExpdId=;	asntDataLen=;	reqPprnFieldVl=;	kftcDoctrDcd=;	kftcDoctrSrno=;	ttlReqCnt=;	dataBlkNum=;	doctrPprnFieldVl=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMETC0170(cigna.cm.b.io.TBCMETC017Io tBCMETC017Io);

	/**
	 * 금융결제원증빙데이터내역
	 * @TestValues 	kftcReqFileNm=AE41191024099996601003;	kftcTxDt=20161205;	kftcTxTi=120438;
	 */
	java.util.List<cigna.cm.b.io.CMB110SVC03Sub> selectMultiTBCMETC017b(@Param("kftcReqFileNm")
	java.lang.String kftcReqFileNm, @Param("kftcTxDt")
	java.lang.String kftcTxDt, @Param("kftcTxTi")
	java.lang.String kftcTxTi);

	/**
	 * 출금이체동의 4119 파일 처리 후 조회
	 * @TestValues 	kftcReqFileNm=;	kftcTxDt=20161206;	kftcTxTi=;
	 */
	java.util.List<cigna.cm.b.io.CMB110SVC01Sub> selectMultiTBCMETC017c(
			@Param("kftcReqFileNm")
			java.lang.String kftcReqFileNm, @Param("kftcTxDt")
			java.lang.String kftcTxDt, @Param("kftcTxTi")
			java.lang.String kftcTxTi);
}