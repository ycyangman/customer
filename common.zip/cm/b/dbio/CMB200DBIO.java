/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Fri Nov 25 15:42:08 KST 2016
 */
package cigna.cm.b.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/b/dbio/CMB200DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMB200DBIO
{

	/**
	 * 녹취처리내역 insert
	 * @TestValues 	vcrecPrcsMgntNo=;	vcrecSysCd=;	bzTxRfDcd=;	bzTxRfDtlDcd=;	bzTxRfNo=;	vcrecId=;	cnslNo=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMETC0160(cigna.cm.b.io.TBCMETC016Io tBCMETC016Io);

	/**
	 * 녹취처리내역 업무참조번호 조회
	 * @TestValues 	vcrecId=;
	 */
	java.util.List<cigna.cm.b.io.TBCMETC016Io> selectMultiTBCMETC0160(
			@Param("vcrecId")
			java.lang.String vcrecId);
}