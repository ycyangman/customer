package cigna.cm.b.domain;

public class CALLEAI {

	public static final String bf10mMthyCrdStcd 	= "10개월전월별신용상태코드";	
	
	
	@Override
	public String toString() {
		return "bf10mMthyCrdStcd";
	}
}
