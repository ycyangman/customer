/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 *
 * @Generated Tue Nov 20 19:21:49 KST 2012
 *
 */
package cigna.cm.b.domain;

import java.io.Serializable;

/**
 * @DataObjectName CardAprvReqInfo
 * @Description
 */
public class CardAprvReqInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 1507273444L;

	/**
	 * @Type java.lang.String
	 * @Name trmDcd
	 * @Description 단말구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String trmDcd;
	
	
	/**
	 * @Type java.lang.String
	 * @Name exTrYn
	 * @Description 대외계연동여부
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String exTrYn;


	/**
	 * @Type java.lang.String
	 * @Name bzDcd
	 * @Description 업구구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String bzDcd;

	/**
	 * @Type java.lang.String
	 * @Name cardNo
	 * @Description 카드번호
	 * @Length 16
	 * @Decimal 0
	 */
	private java.lang.String cardNo;
	/**
	 * @Type java.lang.String
	 * @Name cardVldYm
	 * @Description 카드유효년월
	 * @Length 4
	 * @Decimal 0
	 */
	private java.lang.String cardVldYm;
	/**
	 * @Type java.lang.Integer
	 * @Name mipMcnt
	 * @Description 할부개월수
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String mipMcnt;

	/**
	 * @Type java.lang.String
	 * @Name cardApplAmt
	 * @Description 카드신청금액
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String cardApplAmt;
	/**
	 * @Type java.lang.String
	 * @Name contNo
	 * @Description 계약번호
	 * @Length 13
	 * @Decimal 0
	 */
	private java.lang.String contNo;

	/**
	 * @Type java.lang.String
	 * @Name trxCd
	 * @Description 카드처리구분코드 (JA:신용카드승인,JC:신용카드승인취소,JW:카드인증요청)
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String txDcd;


	/**
	 * @Type java.lang.String
	 * @Name contrRrno
	 * @Description 계약자주민번호
	 * @Length 13
	 * @Decimal 0
	 */
	private java.lang.String contrRrno;


	/**
	 * @Type java.lang.String
	 * @Name cardOwnerCustDscNo
	 * @Description 카드소유주주민등록번호
	 * @Length 13
	 * @Decimal 0
	 */
	private java.lang.String cardOwnerCustDscNo;

	/**
	 * @Type java.lang.String
	 * @Name cardAprvNo
	 * @Description 원거래카드승인번호
	 * @Length 12
	 * @Decimal 0
	 */
	private java.lang.String cardAprvNo;

	/**
	 * @Type java.lang.String
	 * @Name cardAprvDt
	 * @Description 원거래카드승인일자
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String cardAprvDt;

	
	/**
	 * @Type java.lang.String
	 * @Name tgmNo
	 * @Description 전문번호
	 * @Length 12
	 * @Decimal 0
	 */
	private java.lang.String tgmNo;	
	
	
	/**
	 * @Type java.lang.String
	 * @Name crdcdMgntNo
	 * @Description 카드관리번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String crdcdMgntNo;	

	/**
	 * @Type java.lang.String
	 * @Name pyrcPrcsEno
	 * @Description 이체처리사운번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String pyrcPrcsEno;
	
	/**
	 * @Type java.lang.String
	 * @Name trmNo
	 * @Description 단말번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String trmNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prpsNo
	 * @Description 청약번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String prpsNo;
    
	/**
	 * @Type java.lang.String
	 * @Name cardTrsfTxNo
	 * @Description 카드이체거래번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String cardTrsfTxNo;

	public java.lang.String getTrmDcd() {
		return trmDcd;
	}

	public void setTrmDcd(java.lang.String trmDcd) {
		this.trmDcd = trmDcd;
	}

	public java.lang.String getExTrYn() {
		return exTrYn;
	}

	public void setExTrYn(java.lang.String exTrYn) {
		this.exTrYn = exTrYn;
	}

	public java.lang.String getBzDcd() {
		return bzDcd;
	}

	public void setBzDcd(java.lang.String bzDcd) {
		this.bzDcd = bzDcd;
	}

	public java.lang.String getCardNo() {
		return cardNo;
	}

	public void setCardNo(java.lang.String cardNo) {
		this.cardNo = cardNo;
	}

	public java.lang.String getCardVldYm() {
		return cardVldYm;
	}

	public void setCardVldYm(java.lang.String cardVldYm) {
		this.cardVldYm = cardVldYm;
	}

	public java.lang.String getMipMcnt() {
		return mipMcnt;
	}

	public void setMipMcnt(java.lang.String mipMcnt) {
		this.mipMcnt = mipMcnt;
	}

	public java.lang.String getCardApplAmt() {
		return cardApplAmt;
	}

	public void setCardApplAmt(java.lang.String cardApplAmt) {
		this.cardApplAmt = cardApplAmt;
	}

	public java.lang.String getContNo() {
		return contNo;
	}

	public void setContNo(java.lang.String contNo) {
		this.contNo = contNo;
	}

	public java.lang.String getTxDcd() {
		return txDcd;
	}

	public void setTxDcd(java.lang.String txDcd) {
		this.txDcd = txDcd;
	}

	public java.lang.String getContrRrno() {
		return contrRrno;
	}

	public void setContrRrno(java.lang.String contrRrno) {
		this.contrRrno = contrRrno;
	}

	public java.lang.String getCardOwnerCustDscNo() {
		return cardOwnerCustDscNo;
	}

	public void setCardOwnerCustDscNo(java.lang.String cardOwnerCustDscNo) {
		this.cardOwnerCustDscNo = cardOwnerCustDscNo;
	}

	public java.lang.String getCardAprvNo() {
		return cardAprvNo;
	}

	public void setCardAprvNo(java.lang.String cardAprvNo) {
		this.cardAprvNo = cardAprvNo;
	}

	public java.lang.String getCardAprvDt() {
		return cardAprvDt;
	}

	public void setCardAprvDt(java.lang.String cardAprvDt) {
		this.cardAprvDt = cardAprvDt;
	}

	public java.lang.String getTgmNo() {
		return tgmNo;
	}

	public void setTgmNo(java.lang.String tgmNo) {
		this.tgmNo = tgmNo;
	}

	public java.lang.String getCrdcdMgntNo() {
		return crdcdMgntNo;
	}

	public void setCrdcdMgntNo(java.lang.String crdcdMgntNo) {
		this.crdcdMgntNo = crdcdMgntNo;
	}

	public java.lang.String getPyrcPrcsEno() {
		return pyrcPrcsEno;
	}

	public void setPyrcPrcsEno(java.lang.String pyrcPrcsEno) {
		this.pyrcPrcsEno = pyrcPrcsEno;
	}

	public java.lang.String getTrmNo() {
		return trmNo;
	}

	public void setTrmNo(java.lang.String trmNo) {
		this.trmNo = trmNo;
	}

	public java.lang.String getPrpsNo() {
		return prpsNo;
	}

	public void setPrpsNo(java.lang.String prpsNo) {
		this.prpsNo = prpsNo;
	}

	public java.lang.String getCardTrsfTxNo() {
		return cardTrsfTxNo;
	}

	public void setCardTrsfTxNo(java.lang.String cardTrsfTxNo) {
		this.cardTrsfTxNo = cardTrsfTxNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bzDcd == null) ? 0 : bzDcd.hashCode());
		result = prime * result
				+ ((cardApplAmt == null) ? 0 : cardApplAmt.hashCode());
		result = prime * result
				+ ((cardAprvDt == null) ? 0 : cardAprvDt.hashCode());
		result = prime * result
				+ ((cardAprvNo == null) ? 0 : cardAprvNo.hashCode());
		result = prime * result + ((cardNo == null) ? 0 : cardNo.hashCode());
		result = prime
				* result
				+ ((cardOwnerCustDscNo == null) ? 0 : cardOwnerCustDscNo
						.hashCode());
		result = prime * result
				+ ((cardTrsfTxNo == null) ? 0 : cardTrsfTxNo.hashCode());
		result = prime * result
				+ ((cardVldYm == null) ? 0 : cardVldYm.hashCode());
		result = prime * result + ((contNo == null) ? 0 : contNo.hashCode());
		result = prime * result
				+ ((contrRrno == null) ? 0 : contrRrno.hashCode());
		result = prime * result
				+ ((crdcdMgntNo == null) ? 0 : crdcdMgntNo.hashCode());
		result = prime * result + ((exTrYn == null) ? 0 : exTrYn.hashCode());
		result = prime * result + ((mipMcnt == null) ? 0 : mipMcnt.hashCode());
		result = prime * result + ((prpsNo == null) ? 0 : prpsNo.hashCode());
		result = prime * result
				+ ((pyrcPrcsEno == null) ? 0 : pyrcPrcsEno.hashCode());
		result = prime * result + ((tgmNo == null) ? 0 : tgmNo.hashCode());
		result = prime * result + ((trmDcd == null) ? 0 : trmDcd.hashCode());
		result = prime * result + ((trmNo == null) ? 0 : trmNo.hashCode());
		result = prime * result + ((txDcd == null) ? 0 : txDcd.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CardAprvReqInfo other = (CardAprvReqInfo) obj;
		if (bzDcd == null) {
			if (other.bzDcd != null)
				return false;
		} else if (!bzDcd.equals(other.bzDcd))
			return false;
		if (cardApplAmt == null) {
			if (other.cardApplAmt != null)
				return false;
		} else if (!cardApplAmt.equals(other.cardApplAmt))
			return false;
		if (cardAprvDt == null) {
			if (other.cardAprvDt != null)
				return false;
		} else if (!cardAprvDt.equals(other.cardAprvDt))
			return false;
		if (cardAprvNo == null) {
			if (other.cardAprvNo != null)
				return false;
		} else if (!cardAprvNo.equals(other.cardAprvNo))
			return false;
		if (cardNo == null) {
			if (other.cardNo != null)
				return false;
		} else if (!cardNo.equals(other.cardNo))
			return false;
		if (cardOwnerCustDscNo == null) {
			if (other.cardOwnerCustDscNo != null)
				return false;
		} else if (!cardOwnerCustDscNo.equals(other.cardOwnerCustDscNo))
			return false;
		if (cardTrsfTxNo == null) {
			if (other.cardTrsfTxNo != null)
				return false;
		} else if (!cardTrsfTxNo.equals(other.cardTrsfTxNo))
			return false;
		if (cardVldYm == null) {
			if (other.cardVldYm != null)
				return false;
		} else if (!cardVldYm.equals(other.cardVldYm))
			return false;
		if (contNo == null) {
			if (other.contNo != null)
				return false;
		} else if (!contNo.equals(other.contNo))
			return false;
		if (contrRrno == null) {
			if (other.contrRrno != null)
				return false;
		} else if (!contrRrno.equals(other.contrRrno))
			return false;
		if (crdcdMgntNo == null) {
			if (other.crdcdMgntNo != null)
				return false;
		} else if (!crdcdMgntNo.equals(other.crdcdMgntNo))
			return false;
		if (exTrYn == null) {
			if (other.exTrYn != null)
				return false;
		} else if (!exTrYn.equals(other.exTrYn))
			return false;
		if (mipMcnt == null) {
			if (other.mipMcnt != null)
				return false;
		} else if (!mipMcnt.equals(other.mipMcnt))
			return false;
		if (prpsNo == null) {
			if (other.prpsNo != null)
				return false;
		} else if (!prpsNo.equals(other.prpsNo))
			return false;
		if (pyrcPrcsEno == null) {
			if (other.pyrcPrcsEno != null)
				return false;
		} else if (!pyrcPrcsEno.equals(other.pyrcPrcsEno))
			return false;
		if (tgmNo == null) {
			if (other.tgmNo != null)
				return false;
		} else if (!tgmNo.equals(other.tgmNo))
			return false;
		if (trmDcd == null) {
			if (other.trmDcd != null)
				return false;
		} else if (!trmDcd.equals(other.trmDcd))
			return false;
		if (trmNo == null) {
			if (other.trmNo != null)
				return false;
		} else if (!trmNo.equals(other.trmNo))
			return false;
		if (txDcd == null) {
			if (other.txDcd != null)
				return false;
		} else if (!txDcd.equals(other.txDcd))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CardAprvReqInfo [\n  trmDcd: ");
		builder.append(trmDcd);
		builder.append("\n  exTrYn: ");
		builder.append(exTrYn);
		builder.append("\n  bzDcd: ");
		builder.append(bzDcd);
		builder.append("\n  cardNo: ");
		builder.append(cardNo);
		builder.append("\n  cardVldYm: ");
		builder.append(cardVldYm);
		builder.append("\n  mipMcnt: ");
		builder.append(mipMcnt);
		builder.append("\n  cardApplAmt: ");
		builder.append(cardApplAmt);
		builder.append("\n  contNo: ");
		builder.append(contNo);
		builder.append("\n  txDcd: ");
		builder.append(txDcd);
		builder.append("\n  contrRrno: ");
		builder.append(contrRrno);
		builder.append("\n  cardOwnerCustDscNo: ");
		builder.append(cardOwnerCustDscNo);
		builder.append("\n  cardAprvNo: ");
		builder.append(cardAprvNo);
		builder.append("\n  cardAprvDt: ");
		builder.append(cardAprvDt);
		builder.append("\n  tgmNo: ");
		builder.append(tgmNo);
		builder.append("\n  crdcdMgntNo: ");
		builder.append(crdcdMgntNo);
		builder.append("\n  pyrcPrcsEno: ");
		builder.append(pyrcPrcsEno);
		builder.append("\n  trmNo: ");
		builder.append(trmNo);
		builder.append("\n  prpsNo: ");
		builder.append(prpsNo);
		builder.append("\n  cardTrsfTxNo: ");
		builder.append(cardTrsfTxNo);
		builder.append("\n]");
		return builder.toString();
	}
		
}
