/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 *
 * @Generated Wed Nov 21 17:22:47 KST 2012
 *
 */
package cigna.cm.b.domain;

import java.io.Serializable;

/**
 * @DataObjectName CardAprvResInfo
 * @Description
 */
public class CardAprvResInfo implements Serializable, Cloneable {


	private static final long serialVersionUID = 1509120486L;
	/**
	 * @Type java.lang.String
	 * @Name tgmNo
	 * @Description 전문번호
	 * @Length 14
	 * @Decimal 0
	 */
	private java.lang.String tgmNo;
	/**
	 * @Type java.lang.String
	 * @Name progStcd
	 * @Description 요청결과
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String progStcd;
	/**
	 * @Type java.lang.String
	 * @Name aprvDt
	 * @Description 승인일자
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String cardAprvDt;
	/**
	 * @Type java.lang.String
	 * @Name cardAprvNo
	 * @Description 카드승인번호
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String cardAprvNo;

	/**
	 * @Type java.lang.String
	 * @Name tgmAnswCd
	 * @Description 응답코드
	 * @Length 4
	 * @Decimal 0
	 */
	private java.lang.String tgmAnswCd;

	/**
	 * @Type java.lang.String
	 * @Name buyCardCopCd
	 * @Description 매입카드회사코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String buyCardCopCd;
	/**
	 * @Type java.lang.String
	 * @Name issueCardCopCd
	 * @Description 발급사회사코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String issueCardCopCd;
	/**
	 * @Type java.lang.String
	 * @Name cardAffstNo
	 * @Description 카드가맹점번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String cardAffstNo;
	
	
	
	/**
	 * @Type java.lang.String
	 * @Name crdcdMgntNo
	 * @Description 카드관리번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String crdcdMgntNo;	
	
	
	/**
	 * @Type java.lang.String
	 * @Name prpsNo
	 * @Description 청약번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String prpsNo;


	public java.lang.String getTgmNo() {
		return tgmNo;
	}


	public void setTgmNo(java.lang.String tgmNo) {
		this.tgmNo = tgmNo;
	}


	public java.lang.String getProgStcd() {
		return progStcd;
	}


	public void setProgStcd(java.lang.String progStcd) {
		this.progStcd = progStcd;
	}


	public java.lang.String getCardAprvDt() {
		return cardAprvDt;
	}


	public void setCardAprvDt(java.lang.String cardAprvDt) {
		this.cardAprvDt = cardAprvDt;
	}


	public java.lang.String getCardAprvNo() {
		return cardAprvNo;
	}


	public void setCardAprvNo(java.lang.String cardAprvNo) {
		this.cardAprvNo = cardAprvNo;
	}


	public java.lang.String getTgmAnswCd() {
		return tgmAnswCd;
	}


	public void setTgmAnswCd(java.lang.String tgmAnswCd) {
		this.tgmAnswCd = tgmAnswCd;
	}


	public java.lang.String getBuyCardCopCd() {
		return buyCardCopCd;
	}


	public void setBuyCardCopCd(java.lang.String buyCardCopCd) {
		this.buyCardCopCd = buyCardCopCd;
	}


	public java.lang.String getIssueCardCopCd() {
		return issueCardCopCd;
	}


	public void setIssueCardCopCd(java.lang.String issueCardCopCd) {
		this.issueCardCopCd = issueCardCopCd;
	}


	public java.lang.String getCardAffstNo() {
		return cardAffstNo;
	}


	public void setCardAffstNo(java.lang.String cardAffstNo) {
		this.cardAffstNo = cardAffstNo;
	}


	public java.lang.String getCrdcdMgntNo() {
		return crdcdMgntNo;
	}


	public void setCrdcdMgntNo(java.lang.String crdcdMgntNo) {
		this.crdcdMgntNo = crdcdMgntNo;
	}


	public java.lang.String getPrpsNo() {
		return prpsNo;
	}


	public void setPrpsNo(java.lang.String prpsNo) {
		this.prpsNo = prpsNo;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((buyCardCopCd == null) ? 0 : buyCardCopCd.hashCode());
		result = prime * result
				+ ((cardAffstNo == null) ? 0 : cardAffstNo.hashCode());
		result = prime * result
				+ ((cardAprvDt == null) ? 0 : cardAprvDt.hashCode());
		result = prime * result
				+ ((cardAprvNo == null) ? 0 : cardAprvNo.hashCode());
		result = prime * result
				+ ((crdcdMgntNo == null) ? 0 : crdcdMgntNo.hashCode());
		result = prime * result
				+ ((issueCardCopCd == null) ? 0 : issueCardCopCd.hashCode());
		result = prime * result
				+ ((progStcd == null) ? 0 : progStcd.hashCode());
		result = prime * result + ((prpsNo == null) ? 0 : prpsNo.hashCode());
		result = prime * result
				+ ((tgmAnswCd == null) ? 0 : tgmAnswCd.hashCode());
		result = prime * result + ((tgmNo == null) ? 0 : tgmNo.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CardAprvResInfo other = (CardAprvResInfo) obj;
		if (buyCardCopCd == null) {
			if (other.buyCardCopCd != null)
				return false;
		} else if (!buyCardCopCd.equals(other.buyCardCopCd))
			return false;
		if (cardAffstNo == null) {
			if (other.cardAffstNo != null)
				return false;
		} else if (!cardAffstNo.equals(other.cardAffstNo))
			return false;
		if (cardAprvDt == null) {
			if (other.cardAprvDt != null)
				return false;
		} else if (!cardAprvDt.equals(other.cardAprvDt))
			return false;
		if (cardAprvNo == null) {
			if (other.cardAprvNo != null)
				return false;
		} else if (!cardAprvNo.equals(other.cardAprvNo))
			return false;
		if (crdcdMgntNo == null) {
			if (other.crdcdMgntNo != null)
				return false;
		} else if (!crdcdMgntNo.equals(other.crdcdMgntNo))
			return false;
		if (issueCardCopCd == null) {
			if (other.issueCardCopCd != null)
				return false;
		} else if (!issueCardCopCd.equals(other.issueCardCopCd))
			return false;
		if (progStcd == null) {
			if (other.progStcd != null)
				return false;
		} else if (!progStcd.equals(other.progStcd))
			return false;
		if (prpsNo == null) {
			if (other.prpsNo != null)
				return false;
		} else if (!prpsNo.equals(other.prpsNo))
			return false;
		if (tgmAnswCd == null) {
			if (other.tgmAnswCd != null)
				return false;
		} else if (!tgmAnswCd.equals(other.tgmAnswCd))
			return false;
		if (tgmNo == null) {
			if (other.tgmNo != null)
				return false;
		} else if (!tgmNo.equals(other.tgmNo))
			return false;
		return true;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CardAprvResInfo [\n  tgmNo: ");
		builder.append(tgmNo);
		builder.append("\n  progStcd: ");
		builder.append(progStcd);
		builder.append("\n  cardAprvDt: ");
		builder.append(cardAprvDt);
		builder.append("\n  cardAprvNo: ");
		builder.append(cardAprvNo);
		builder.append("\n  tgmAnswCd: ");
		builder.append(tgmAnswCd);
		builder.append("\n  buyCardCopCd: ");
		builder.append(buyCardCopCd);
		builder.append("\n  issueCardCopCd: ");
		builder.append(issueCardCopCd);
		builder.append("\n  cardAffstNo: ");
		builder.append(cardAffstNo);
		builder.append("\n  crdcdMgntNo: ");
		builder.append(crdcdMgntNo);
		builder.append("\n  prpsNo: ");
		builder.append(prpsNo);
		builder.append("\n]");
		return builder.toString();
	}
	
}
