/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Fri Feb 19 15:29:11 KST 2016
 * 
 */
package cigna.cm.b.domain;

import java.io.Serializable;

/**
 * @DataObjectName MblStlmResInfo
 * @Description 
 */
public class MblStlmResInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 447559145L;
	/**
	 * @Type java.lang.String
	 * @Name mblTrsfTxNo
	 * @Description 모바일이체거래번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String mblTrsfTxNo;
	/**
	 * @Type java.lang.String
	 * @Name mblBzDcd
	 * @Description 모바일업무구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String mblBzDcd;
	/**
	 * @Type java.lang.String
	 * @Name trsfDt
	 * @Description 이체일자
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String trsfDt;
	/**
	 * @Type java.lang.String
	 * @Name trsfDofOrgNo
	 * @Description 이체지점조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String trsfDofOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name trsfFofOrgNo
	 * @Description 이체영업소조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String trsfFofOrgNo;
	/**
	 * @Type java.lang.String
	 * @Name trsfPrcsEno
	 * @Description 이체처리사원번호
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String trsfPrcsEno;
	/**
	 * @Type java.lang.String
	 * @Name membMpno
	 * @Description 가입자휴대전화번호
	 * @Length 82
	 * @Decimal 0
	 */
	private java.lang.String membMpno;
	/**
	 * @Type java.lang.String
	 * @Name telDcd
	 * @Description 전화구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String telDcd;
	/**
	 * @Type java.math.BigDecimal
	 * @Name trsfAmt
	 * @Description 이체금액
	 * @Length 15
	 * @Decimal 0
	 */
	private java.math.BigDecimal trsfAmt;
	/**
	 * @Type java.lang.String
	 * @Name membRrno
	 * @Description 가입자주민등록번호
	 * @Length 82
	 * @Decimal 0
	 */
	private java.lang.String membRrno;
	/**
	 * @Type java.lang.String
	 * @Name mblTgmNo
	 * @Description 모바일전문번호
	 * @Length 14
	 * @Decimal 0
	 */
	private java.lang.String mblTgmNo;
	/**
	 * @Type java.lang.String
	 * @Name mblCrtfNo
	 * @Description 모바일인증번호
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String mblCrtfNo;
	/**
	 * @Type java.lang.String
	 * @Name smsCrtfNo
	 * @Description SMS인증번호
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String smsCrtfNo;
	/**
	 * @Type java.lang.String
	 * @Name carrPinAdptYn
	 * @Description 캐리어핀적용여부
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String carrPinAdptYn;
	/**
	 * @Type java.lang.String
	 * @Name autoStlmAdptDcd
	 * @Description 자동결제적용구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String autoStlmAdptDcd;
	/**
	 * @Type java.lang.String
	 * @Name mblTrsfRcd
	 * @Description 모바일이체결과코드
	 * @Length 4
	 * @Decimal 0
	 */
	private java.lang.String mblTrsfRcd;
	/**
	 * @Type java.lang.String
	 * @Name mblTrsfRstMsgCtnt
	 * @Description 모바일이체결과메시지내용
	 * @Length 100
	 * @Decimal 0
	 */
	private java.lang.String mblTrsfRstMsgCtnt;
	/**
	 * @Type java.lang.String
	 * @Name mblasTxNo
	 * @Description 모빌리언스거래번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String mblasTxNo;
	/**
	 * @Type java.lang.String
	 * @Name rmnLmtAmt
	 * @Description 잔여한도금액
	 * @Length 15
	 * @Decimal 0
	 */	
	private java.math.BigDecimal rmnLmtAmt;
	/**
	 * @Type java.lang.String
	 * @Name prcsDtm
	 * @Description 처리일시
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String prcsDtm;
	/**
	 * @Type java.lang.String
	 * @Name reprdRskMphonYn
	 * @Description 복제위험휴대전화여부
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String reprdRskMphonYn;
	/**
	 * @Type java.lang.String
	 * @Name crtfWayCd
	 * @Description 인증방식코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String crtfWayCd;
	/**
	 * @Type java.lang.String
	 * @Name pyrcTxRfNoDcd
	 * @Description 출수납거래참조번호구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String pyrcTxRfNoDcd;
	/**
	 * @Type java.lang.String
	 * @Name pyrcTxRfNo
	 * @Description 출수납거래참조번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String pyrcTxRfNo;
	/**
	 * @Type java.lang.String
	 * @Name delYn
	 * @Description 삭제여부
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String delYn;
	/**
	 * @Type java.util.Date
	 * @Name lastChgDtm
	 * @Description 최종변경일시
	 * @Length 30
	 * @Decimal 0
	 */
	private java.util.Date lastChgDtm;
	/**
	 * @Type java.lang.String
	 * @Name lastChgrId
	 * @Description 최종변경자ID
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String lastChgrId;
	/**
	 * @Type java.lang.String
	 * @Name lastChgPgmId
	 * @Description 최종변경프로그램ID
	 * @Length 15
	 * @Decimal 0
	 */
	private java.lang.String lastChgPgmId;
	/**
	 * @Type java.lang.String
	 * @Name lastChgTrmNo
	 * @Description 최종변경단말번호
	 * @Length 40
	 * @Decimal 0
	 */
	private java.lang.String lastChgTrmNo;

	/**
	 * GET 모바일이체거래번호
	 */
	public java.lang.String getMblTrsfTxNo() {
		return this.mblTrsfTxNo;
	}

	/**
	 * SET 모바일이체거래번호
	 */
	public void setMblTrsfTxNo(java.lang.String mblTrsfTxNo) {
		this.mblTrsfTxNo = mblTrsfTxNo;
	}
	
	/**
	 * GET 모바일이체결과코드
	 */
	public java.lang.String getMblTrsfRcd() {
		return this.mblTrsfRcd;
	}

	/**
	 * SET 모바일이체결과코드
	 */
	public void setMblTrsfRcd(java.lang.String mblTrsfRcd) {
		this.mblTrsfRcd = mblTrsfRcd;
	}

	/**
	 * GET 모바일이체결과메시지내용
	 */
	public java.lang.String getMblTrsfRstMsgCtnt() {
		return this.mblTrsfRstMsgCtnt;
	}

	/**
	 * SET 모바일이체결과메시지내용
	 */
	public void setMblTrsfRstMsgCtnt(java.lang.String mblTrsfRstMsgCtnt) {
		this.mblTrsfRstMsgCtnt = mblTrsfRstMsgCtnt;
	}

	/**
	 * GET 모빌리언스거래번호
	 */
	public java.lang.String getMblasTxNo() {
		return this.mblasTxNo;
	}

	/**
	 * SET 모빌리언스거래번호
	 */
	public void setMblasTxNo(java.lang.String mblasTxNo) {
		this.mblasTxNo = mblasTxNo;
	}
	
	/**
	 * GET 잔여한도금액
	 */
	public java.math.BigDecimal getRmnLmtAmt() {
		return this.rmnLmtAmt;
	}

	/**
	 * SET 잔여한도금액
	 */
	public void setRmnLmtAmt(java.math.BigDecimal rmnLmtAmt) {
		this.trsfAmt = rmnLmtAmt;
	}

	/**
	 * GET 복제위험휴대전화여부
	 */
	public java.lang.String getReprdRskMphonYn() {
		return this.reprdRskMphonYn;
	}

	/**
	 * SET 복제위험휴대전화여부
	 */
	public void setReprdRskMphonYn(java.lang.String reprdRskMphonYn) {
		this.reprdRskMphonYn = reprdRskMphonYn;
	}

	/**
	 * GET 인증방식코드
	 */
	public java.lang.String getCrtfWayCd() {
		return this.crtfWayCd;
	}

	/**
	 * SET 인증방식코드
	 */
	public void setCrtfWayCd(java.lang.String crtfWayCd) {
		this.crtfWayCd = crtfWayCd;
	}
	
	/**
	 * GET 처리일시
	 */
	public java.lang.String getPrcsDtm() {
		return this.prcsDtm;
	}

	/**
	 * SET 처리일시
	 */
	public void setPrcsDtm(java.lang.String prcsDtm) {
		this.prcsDtm = prcsDtm;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((mblTrsfTxNo == null) ? 0 : mblTrsfTxNo.hashCode());
		result = prime * result
				+ ((mblBzDcd == null) ? 0 : mblBzDcd.hashCode());
		result = prime * result + ((trsfDt == null) ? 0 : trsfDt.hashCode());
		result = prime * result
				+ ((trsfDofOrgNo == null) ? 0 : trsfDofOrgNo.hashCode());
		result = prime * result
				+ ((trsfFofOrgNo == null) ? 0 : trsfFofOrgNo.hashCode());
		result = prime * result
				+ ((trsfPrcsEno == null) ? 0 : trsfPrcsEno.hashCode());
		result = prime * result
				+ ((membMpno == null) ? 0 : membMpno.hashCode());
		result = prime * result + ((telDcd == null) ? 0 : telDcd.hashCode());
		result = prime * result + ((trsfAmt == null) ? 0 : trsfAmt.hashCode());
		result = prime * result
				+ ((membRrno == null) ? 0 : membRrno.hashCode());
		result = prime * result
				+ ((mblTgmNo == null) ? 0 : mblTgmNo.hashCode());
		result = prime * result
				+ ((mblCrtfNo == null) ? 0 : mblCrtfNo.hashCode());
		result = prime * result
				+ ((smsCrtfNo == null) ? 0 : smsCrtfNo.hashCode());
		result = prime * result
				+ ((carrPinAdptYn == null) ? 0 : carrPinAdptYn.hashCode());
		result = prime * result
				+ ((autoStlmAdptDcd == null) ? 0 : autoStlmAdptDcd.hashCode());
		result = prime * result
				+ ((mblTrsfRcd == null) ? 0 : mblTrsfRcd.hashCode());
		result = prime
				* result
				+ ((mblTrsfRstMsgCtnt == null) ? 0 : mblTrsfRstMsgCtnt
						.hashCode());
		result = prime * result
				+ ((mblasTxNo == null) ? 0 : mblasTxNo.hashCode());
		result = prime * result
				+ ((rmnLmtAmt == null) ? 0 : rmnLmtAmt.hashCode());
		result = prime * result + ((prcsDtm == null) ? 0 : prcsDtm.hashCode());
		result = prime * result
				+ ((reprdRskMphonYn == null) ? 0 : reprdRskMphonYn.hashCode());
		result = prime * result
				+ ((crtfWayCd == null) ? 0 : crtfWayCd.hashCode());
		result = prime * result
				+ ((pyrcTxRfNoDcd == null) ? 0 : pyrcTxRfNoDcd.hashCode());
		result = prime * result
				+ ((pyrcTxRfNo == null) ? 0 : pyrcTxRfNo.hashCode());
		result = prime * result + ((delYn == null) ? 0 : delYn.hashCode());
		result = prime * result
				+ ((lastChgDtm == null) ? 0 : lastChgDtm.hashCode());
		result = prime * result
				+ ((lastChgrId == null) ? 0 : lastChgrId.hashCode());
		result = prime * result
				+ ((lastChgPgmId == null) ? 0 : lastChgPgmId.hashCode());
		result = prime * result
				+ ((lastChgTrmNo == null) ? 0 : lastChgTrmNo.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MblStlmResInfo other = (MblStlmResInfo) obj;
		if (mblTrsfTxNo == null) {
			if (other.mblTrsfTxNo != null)
				return false;
		} else if (!mblTrsfTxNo.equals(other.mblTrsfTxNo))
			return false;
		if (mblBzDcd == null) {
			if (other.mblBzDcd != null)
				return false;
		} else if (!mblBzDcd.equals(other.mblBzDcd))
			return false;
		if (trsfDt == null) {
			if (other.trsfDt != null)
				return false;
		} else if (!trsfDt.equals(other.trsfDt))
			return false;
		if (trsfDofOrgNo == null) {
			if (other.trsfDofOrgNo != null)
				return false;
		} else if (!trsfDofOrgNo.equals(other.trsfDofOrgNo))
			return false;
		if (trsfFofOrgNo == null) {
			if (other.trsfFofOrgNo != null)
				return false;
		} else if (!trsfFofOrgNo.equals(other.trsfFofOrgNo))
			return false;
		if (trsfPrcsEno == null) {
			if (other.trsfPrcsEno != null)
				return false;
		} else if (!trsfPrcsEno.equals(other.trsfPrcsEno))
			return false;
		if (membMpno == null) {
			if (other.membMpno != null)
				return false;
		} else if (!membMpno.equals(other.membMpno))
			return false;
		if (telDcd == null) {
			if (other.telDcd != null)
				return false;
		} else if (!telDcd.equals(other.telDcd))
			return false;
		if (trsfAmt == null) {
			if (other.trsfAmt != null)
				return false;
		} else if (!trsfAmt.equals(other.trsfAmt))
			return false;
		if (membRrno == null) {
			if (other.membRrno != null)
				return false;
		} else if (!membRrno.equals(other.membRrno))
			return false;
		if (mblTgmNo == null) {
			if (other.mblTgmNo != null)
				return false;
		} else if (!mblTgmNo.equals(other.mblTgmNo))
			return false;
		if (mblCrtfNo == null) {
			if (other.mblCrtfNo != null)
				return false;
		} else if (!mblCrtfNo.equals(other.mblCrtfNo))
			return false;
		if (smsCrtfNo == null) {
			if (other.smsCrtfNo != null)
				return false;
		} else if (!smsCrtfNo.equals(other.smsCrtfNo))
			return false;
		if (carrPinAdptYn == null) {
			if (other.carrPinAdptYn != null)
				return false;
		} else if (!carrPinAdptYn.equals(other.carrPinAdptYn))
			return false;
		if (autoStlmAdptDcd == null) {
			if (other.autoStlmAdptDcd != null)
				return false;
		} else if (!autoStlmAdptDcd.equals(other.autoStlmAdptDcd))
			return false;
		if (mblTrsfRcd == null) {
			if (other.mblTrsfRcd != null)
				return false;
		} else if (!mblTrsfRcd.equals(other.mblTrsfRcd))
			return false;
		if (mblTrsfRstMsgCtnt == null) {
			if (other.mblTrsfRstMsgCtnt != null)
				return false;
		} else if (!mblTrsfRstMsgCtnt.equals(other.mblTrsfRstMsgCtnt))
			return false;
		if (mblasTxNo == null) {
			if (other.mblasTxNo != null)
				return false;
		} else if (!mblasTxNo.equals(other.mblasTxNo))
			return false;
		if (rmnLmtAmt == null) {
			if (other.rmnLmtAmt != null)
				return false;
		} else if (!rmnLmtAmt.equals(other.rmnLmtAmt))
			return false;
		if (prcsDtm == null) {
			if (other.prcsDtm != null)
				return false;
		} else if (!prcsDtm.equals(other.prcsDtm))
			return false;
		if (reprdRskMphonYn == null) {
			if (other.reprdRskMphonYn != null)
				return false;
		} else if (!reprdRskMphonYn.equals(other.reprdRskMphonYn))
			return false;
		if (crtfWayCd == null) {
			if (other.crtfWayCd != null)
				return false;
		} else if (!crtfWayCd.equals(other.crtfWayCd))
			return false;
		if (pyrcTxRfNoDcd == null) {
			if (other.pyrcTxRfNoDcd != null)
				return false;
		} else if (!pyrcTxRfNoDcd.equals(other.pyrcTxRfNoDcd))
			return false;
		if (pyrcTxRfNo == null) {
			if (other.pyrcTxRfNo != null)
				return false;
		} else if (!pyrcTxRfNo.equals(other.pyrcTxRfNo))
			return false;
		if (delYn == null) {
			if (other.delYn != null)
				return false;
		} else if (!delYn.equals(other.delYn))
			return false;
		if (lastChgDtm == null) {
			if (other.lastChgDtm != null)
				return false;
		} else if (!lastChgDtm.equals(other.lastChgDtm))
			return false;
		if (lastChgrId == null) {
			if (other.lastChgrId != null)
				return false;
		} else if (!lastChgrId.equals(other.lastChgrId))
			return false;
		if (lastChgPgmId == null) {
			if (other.lastChgPgmId != null)
				return false;
		} else if (!lastChgPgmId.equals(other.lastChgPgmId))
			return false;
		if (lastChgTrmNo == null) {
			if (other.lastChgTrmNo != null)
				return false;
		} else if (!lastChgTrmNo.equals(other.lastChgTrmNo))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("MblStlmResInfo[\n");
		sb.append("	mblTrsfTxNo(모바일이체거래번호) = " + mblTrsfTxNo);
		sb.append("\n");
		sb.append("	mblBzDcd(모바일업무구분코드) = " + mblBzDcd);
		sb.append("\n");
		sb.append("	trsfDt(이체일자) = " + trsfDt);
		sb.append("\n");
		sb.append("	trsfDofOrgNo(이체지점조직번호) = " + trsfDofOrgNo);
		sb.append("\n");
		sb.append("	trsfFofOrgNo(이체영업소조직번호) = " + trsfFofOrgNo);
		sb.append("\n");
		sb.append("	trsfPrcsEno(이체처리사원번호) = " + trsfPrcsEno);
		sb.append("\n");
		sb.append("	membMpno(가입자휴대전화번호) = " + membMpno);
		sb.append("\n");
		sb.append("	telDcd(전화구분코드) = " + telDcd);
		sb.append("\n");
		sb.append("	trsfAmt(이체금액) = " + trsfAmt);
		sb.append("\n");
		sb.append("	membRrno(가입자주민등록번호) = " + membRrno);
		sb.append("\n");
		sb.append("	mblTgmNo(모바일전문번호) = " + mblTgmNo);
		sb.append("\n");
		sb.append("	mblCrtfNo(모바일인증번호) = " + mblCrtfNo);
		sb.append("\n");
		sb.append("	smsCrtfNo(SMS인증번호) = " + smsCrtfNo);
		sb.append("\n");
		sb.append("	carrPinAdptYn(캐리어핀적용여부) = " + carrPinAdptYn);
		sb.append("\n");
		sb.append("	autoStlmAdptDcd(자동결제적용구분코드) = " + autoStlmAdptDcd);
		sb.append("\n");
		sb.append("	mblTrsfRcd(모바일이체결과코드) = " + mblTrsfRcd);
		sb.append("\n");
		sb.append("	mblTrsfRstMsgCtnt(모바일이체결과메시지내용) = " + mblTrsfRstMsgCtnt);
		sb.append("\n");
		sb.append("	mblasTxNo(모빌리언스거래번호) = " + mblasTxNo);
		sb.append("\n");
		sb.append("	rmnLmtAmt(잔여한도금액) = " + rmnLmtAmt);
		sb.append("\n");
		sb.append("	prcsDtm(처리일시) = " + prcsDtm);
		sb.append("\n");
		sb.append("	reprdRskMphonYn(복제위험휴대전화여부) = " + reprdRskMphonYn);
		sb.append("\n");
		sb.append("	crtfWayCd(인증방식코드) = " + crtfWayCd);
		sb.append("\n");
		sb.append("	pyrcTxRfNoDcd(출수납거래참조번호구분코드) = " + pyrcTxRfNoDcd);
		sb.append("\n");
		sb.append("	pyrcTxRfNo(출수납거래참조번호) = " + pyrcTxRfNo);
		sb.append("\n");
		sb.append("	delYn(삭제여부) = " + delYn);
		sb.append("\n");
		sb.append("	lastChgDtm(최종변경일시) = " + lastChgDtm);
		sb.append("\n");
		sb.append("	lastChgrId(최종변경자ID) = " + lastChgrId);
		sb.append("\n");
		sb.append("	lastChgPgmId(최종변경프로그램ID) = " + lastChgPgmId);
		sb.append("\n");
		sb.append("	lastChgTrmNo(최종변경단말번호) = " + lastChgTrmNo);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
