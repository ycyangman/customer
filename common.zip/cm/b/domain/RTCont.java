package cigna.cm.b.domain;

import java.math.BigDecimal;

/**
 * RT 관련 상수값 관리
 */
public class RTCont {
	
	/*** [대외계송수신] 처리코드(업무별 구분코드) ***/
    
	/**자동이체처리(송금,지급)*/
	public static final String PRCSCD_01 				= "01";	
    /**자동집금처리(출금,집금)*/
	public static final String PRCSCD_02 				= "02";	
    /**이체처리결과조회(이체확인)*/
	public static final String PRCSCD_03 				= "03";	
    /**이체취소(SC만)*/
	public static final String PRCSCD_04 				= "04";	
    /**집계처리*/
	public static final String PRCSCD_05 				= "05";	
    /**출금이체신청(납부자번호등록)*/
	public static final String PRCSCD_06 				= "06";	
    /**성명조회(예금주조회)*/
	public static final String PRCSCD_07 				= "07";	
    /**잔액조회(이체모계좌조회)*/
	public static final String PRCSCD_08 				= "08";
	/**입금불능*/
	public static final String PRCSCD_09 				= "09";
	/**실명조회*/
	public static final String PRCSCD_10 				= "10";
	/**리얼타임출금이체해지(납부자번호해지)*/
	public static final String PRCSCD_11 				= "11";
	/**리얼타임출금이체신청(납부자번호신청)*/
	public static final String PRCSCD_12 				= "12";
	/**업무개시*/
	public static final String PRCSCD_A1 				= "A1";
	/**테스트콜*/
	public static final String PRCSCD_A3 				= "A3";
	
	
	/*** [대외계송수신] 입출금구분코드 ***/
    
	/**입금*/
	public static final String DPWD_DCD_DPS				= "1";	
    /**출금*/
	public static final String DPWD_DCD_WDM 			= "2";	
    /**인터넷입금*/
	public static final String DPWD_DCD_INTRN			= "3";	
    /**모바일입금*/
	public static final String DPWD_DCD_MBL				= "4";
	
	/*** [대외계송수신] 금융기관코드(3자리) : 은행외 코드포함 ***/
    
	/**산업*/
	public static final String FININCD_002 				= "002";	
    /**기업*/
	public static final String FININCD_003 				= "003";	
    /**국민*/
	public static final String FININCD_004 				= "004";	
    /**외환*/
	public static final String FININCD_005              = "005";	
    /**주택*/
	public static final String FININCD_006              = "006";	
    /**수협*/
	public static final String FININCD_007              = "007";	
    /**장기신용*/
	public static final String FININCD_009              = "009";	
    /**농협(10)*/
	public static final String FININCD_010              = "010";	
    /**농협(11)*/
	public static final String FININCD_011              = "011";	
    /**단위농협(12)*/
	public static final String FININCD_012              = "012";	
    /**단위농협(13)*/
	public static final String FININCD_013              = "013";	
    /**단위농협(14)*/
	public static final String FININCD_014              = "014";	
    /**단위농협(15)*/
	public static final String FININCD_015              = "015";	
    /**축협*/
	public static final String FININCD_016              = "016";	
    /**단위농협*/
	public static final String FININCD_017              = "017";	
    /**우리*/
	public static final String FININCD_020              = "020";	
    /**조흥*/
	public static final String FININCD_021              = "021";	
    /**상업*/
	public static final String FININCD_022              = "022";	
    /**SC제일*/
	public static final String FININCD_023              = "023";	
    /**한일*/
	public static final String FININCD_024              = "024";	
    /**서울*/
	public static final String FININCD_025              = "025";	
    /**신한*/
	public static final String FININCD_026              = "026";	
    /**한미*/
	public static final String FININCD_027              = "027";	
    /**동화*/
	public static final String FININCD_028              = "028";	
    /**동남*/
	public static final String FININCD_029              = "029";	
    /**대동*/
	public static final String FININCD_030              = "030";	
    /**대구*/
	public static final String FININCD_031              = "031";	
    /**부산*/
	public static final String FININCD_032              = "032";	
    /**충청*/
	public static final String FININCD_033              = "033";	
    /**광주*/
	public static final String FININCD_034              = "034";	
    /**제주*/
	public static final String FININCD_035              = "035";	
    /**경기*/
	public static final String FININCD_036              = "036";	
    /**전북*/
	public static final String FININCD_037              = "037";	
    /**경남*/
	public static final String FININCD_039              = "039";	
    /**충북*/
	public static final String FININCD_040              = "040";	
    /**새마을금고(45)*/
	public static final String FININCD_045              = "045";	
    /**새마을금고(46)*/
	public static final String FININCD_046              = "046";	
    /**신용협동조합(48)*/
	public static final String FININCD_048              = "048";	
    /**신용협동조합(49)*/
	public static final String FININCD_049              = "049";	
    /**상호신용금고*/
	public static final String FININCD_050              = "050";	
    /**씨티*/
	public static final String FININCD_053              = "053";	
    /**HSBC*/
	public static final String FININCD_054              = "054";	
    /**B0A*/
	public static final String FININCD_060              = "060";	
    /**산림조합*/
	public static final String FININCD_064              = "064";	
    /**우체국(71)*/
	public static final String FININCD_071              = "071";	
    /**우체국(72)*/
	public static final String FININCD_072              = "072";	
    /**우체국(73)*/
	public static final String FININCD_073              = "073";	
    /**우체국(74)*/
	public static final String FININCD_074              = "074";	
    /**우체국(75)*/
	public static final String FININCD_075              = "075";	
    /**하나*/
	public static final String FININCD_081              = "081";	
    /**보람*/
	public static final String FININCD_082              = "082";	
    /**평화*/
	public static final String FININCD_083              = "083";	
    /**통합신한*/
	public static final String FININCD_088              = "088";	
    /**동양증권(209)*/
	public static final String FININCD_209              = "209";	
    /**현대증권(218)*/
	public static final String FININCD_218              = "218";	
    /**미래에셋(230)*/
	public static final String FININCD_230              = "230";	
    /**대우증권(238)*/
	public static final String FININCD_238              = "238";	
    /**삼성증권(240)*/
	public static final String FININCD_240              = "240";	
    /**한국투자(243)*/
	public static final String FININCD_243              = "243";	
    /**우리투자(247)*/
	public static final String FININCD_247              = "247";	
    /**교보증권(261)*/
	public static final String FININCD_261              = "261";	
    /**하이증권(262)*/
	public static final String FININCD_262              = "262";	
    /**HMC증권(263)*/
	public static final String FININCD_263              = "263";	
    /**키움증권(264)*/
	public static final String FININCD_264              = "264";	
    /**이트레이드(265)*/
	public static final String FININCD_265              = "265";	
    /**SK증권(266)*/
	public static final String FININCD_266              = "266";	
    /**대신증권(267)*/
	public static final String FININCD_267              = "267";	
    /**솔로몬증권(268)*/
	public static final String FININCD_268              = "268";	
    /**한화증권(269)*/
	public static final String FININCD_269              = "269";	
    /**하나대투(270)*/
	public static final String FININCD_270              = "270";	
    /**굿모닝신한(278)*/
	public static final String FININCD_278              = "278";	
    /**동부증권(279)*/
	public static final String FININCD_279              = "279";	
    /**유진증권(280)*/
	public static final String FININCD_280              = "280";	
    /**메리츠증권(287)*/
	public static final String FININCD_287              = "287";	
    /**NH증권(289)*/
	public static final String FININCD_289              = "289";	
    /**부국증권(290)*/
	public static final String FININCD_290              = "290";	
    /**신영증권(291)*/
	public static final String FININCD_291              = "291";	
    /**LIG증권(292)*/
	public static final String FININCD_292              = "292";	

	
	/*** [대외계송수신] 은행코드(2자리) : 은행코드만 ***/
    
	/**산업*/
	public static final String BNKCD_02 				= "02";	
    /**기업*/
	public static final String BNKCD_03                 = "03";	
    /**국민*/
	public static final String BNKCD_04                 = "04";	
    /**외환*/
	public static final String BNKCD_05                 = "05";	
    /**주택*/
	public static final String BNKCD_06                 = "06";	
    /**수협*/
	public static final String BNKCD_07                 = "07";	
    /**장기신용*/
	public static final String BNKCD_09                 = "09";	
    /**농협(10)*/
	public static final String BNKCD_10                 = "10";	
    /**농협(11)*/
	public static final String BNKCD_11                 = "11";	
    /**단위농협(12)*/
	public static final String BNKCD_12                 = "12";	
    /**단위농협(13)*/
	public static final String BNKCD_13                 = "13";	
    /**단위농협(14)*/
	public static final String BNKCD_14                 = "14";	
    /**단위농협(15)*/
	public static final String BNKCD_15                 = "15";	
    /**축협*/
	public static final String BNKCD_16                 = "16";	
    /**단위농협*/
	public static final String BNKCD_17                 = "17";	
    /**우리*/
	public static final String BNKCD_20                 = "20";	
    /**조흥*/
	public static final String BNKCD_21                 = "21";	
    /**상업*/
	public static final String BNKCD_22                 = "22";	
    /**SC제일*/
	public static final String BNKCD_23                 = "23";	
    /**한일*/
	public static final String BNKCD_24                 = "24";	
    /**서울*/
	public static final String BNKCD_25                 = "25";	
    /**신한*/
	public static final String BNKCD_26                 = "26";	
    /**한미*/
	public static final String BNKCD_27                 = "27";	
    /**동화*/
	public static final String BNKCD_28                 = "28";	
    /**동남*/
	public static final String BNKCD_29                 = "29";	
    /**대동*/
	public static final String BNKCD_30                 = "30";	
    /**대구*/
	public static final String BNKCD_31                 = "31";	
    /**부산*/
	public static final String BNKCD_32                 = "32";	
    /**충청*/
	public static final String BNKCD_33                 = "33";	
    /**광주*/
	public static final String BNKCD_34                 = "34";	
    /**제주*/
	public static final String BNKCD_35                 = "35";	
    /**경기*/
	public static final String BNKCD_36                 = "36";	
    /**전북*/
	public static final String BNKCD_37                 = "37";	
    /**경남*/
	public static final String BNKCD_39                 = "39";	
    /**충북*/
	public static final String BNKCD_40                 = "40";	
    /**새마을금고(45)*/
	public static final String BNKCD_45                 = "45";	
    /**새마을금고(46)*/
	public static final String BNKCD_46                 = "46";	
    /**신용협동조합(48)*/
	public static final String BNKCD_48                 = "48";	
    /**신용협동조합(49)*/
	public static final String BNKCD_49                 = "49";	
    /**상호신용금고*/
	public static final String BNKCD_50                 = "50";	
    /**씨티*/
	public static final String BNKCD_53                 = "53";	
    /**HSBC*/
	public static final String BNKCD_54                 = "54";	
    /**B0A*/
	public static final String BNKCD_60                 = "60";	
    /**산림조합*/
	public static final String BNKCD_64                 = "64";	
    /**우체국(71)*/
	public static final String BNKCD_71                 = "71";	
    /**우체국(72)*/
	public static final String BNKCD_72                 = "72";	
    /**우체국(73)*/
	public static final String BNKCD_73                 = "73";	
    /**우체국(74)*/
	public static final String BNKCD_74                 = "74";	
    /**우체국(75)*/
	public static final String BNKCD_75                 = "75";	
    /**하나*/
	public static final String BNKCD_81                 = "81";	
    /**보람*/
	public static final String BNKCD_82                 = "82";	
    /**평화*/
	public static final String BNKCD_83                 = "83";	
    /**통합신한*/
	public static final String BNKCD_88                 = "88";	
	
	/*** [대외계송수신] 전송구분코드 ***/
    
	/**미전송*/
	public static final String TRMSDCD_0 				= "0";	
    /**전송*/
	public static final String TRMSDCD_1 				= "1";	
    /**정상*/
	public static final String TRMSDCD_2 				= "2";	
    /**오류*/
	public static final String TRMSDCD_3 				= "3";	
    /**미이체*/
	public static final String TRMSDCD_5 				= "5";	
    /**전체*/
	public static final String TRMSDCD_9 				= "9";	
	
	/*** [대외계송수신] 채널구분코드 (전문송수신이체처리 처리은행구분값) 배열 ***/
	
	public static final String[] TRSFCHNLDCD_026 = {"ERP1","UVC1","UVT1","LNFD"};
	
	public static final String[] TRSFCHNLDCD_023 = {"ERP4","ERP5","ERP6","ERP7","ERP8","ERP9","ERPA","ERPC","ERPD","ERPE","ERPF"};
	
	public static final String[] TRSFCHNLDCD_ERP = {"ERP1","UVC1","UVT1","LNFD","ERP4","ERP5","ERP6","ERP7",
		"ERP8","ERP9","ERPA","ERPC","ERPD","ERPE","ERPF"};
	
	/*** [대외계송수신] 즉시이체채널구분코드 (금융기관제휴업무목록 테이블용) ***/	
	
	/**출금계좌*/
	public static final String IMTRSF_CHNL_DCD_DPS 		= "0001";	
    /**입금계좌*/
	public static final String IMTRSF_CHNL_DCD_WDM		= "0002";	
    /**ERP1*/
	public static final String IMTRSF_CHNL_DCD_ERP1		= "ERP1";	
    /**ERP4*/
	public static final String IMTRSF_CHNL_DCD_ERP4		= "ERP4";	
    /**ERP5*/
	public static final String IMTRSF_CHNL_DCD_ERP5		= "ERP5";	
    /**ERP6*/
	public static final String IMTRSF_CHNL_DCD_ERP6		= "ERP6";	
    /**ERP7*/
	public static final String IMTRSF_CHNL_DCD_ERP7		= "ERP7";	
    /**ERP8*/
	public static final String IMTRSF_CHNL_DCD_ERP8		= "ERP8";	
    /**ERP9*/
	public static final String IMTRSF_CHNL_DCD_ERP9		= "ERP9";	
    /**ERPA*/
	public static final String IMTRSF_CHNL_DCD_ERPA		= "ERPA";	
    /**ERPC*/
	public static final String IMTRSF_CHNL_DCD_ERPC		= "ERPC";	
    /**ERPD*/
	public static final String IMTRSF_CHNL_DCD_ERPD		= "ERPD";	
    /**ERPE*/
	public static final String IMTRSF_CHNL_DCD_ERPE		= "ERPE";	
    /**ERPF*/
	public static final String IMTRSF_CHNL_DCD_ERPF		= "ERPF";	
    /**LNFD*/
	public static final String IMTRSF_CHNL_DCD_LNFD		= "ERPC";	
    /**UVC1*/
	public static final String IMTRSF_CHNL_DCD_UVC1		= "ERPC";	
    /**UVT1*/
	public static final String IMTRSF_CHNL_DCD_UVT1		= "ERPC";	

	/*** [대외계송수신] 정상취소구분코드 ***/
    
	/**정상*/
	public static final String NRM_CNCL_DCD_NRM 		= "0";	
    /**취소*/
	public static final String NRM_CNCL_DCD_CNCL 		= "1";	
	
	/*** [대외계송수신] 복기부호처리_23 구해오기 위한 SAFECARD 배열 ***/
	public static final String[] SAFECARD = {"0998", "1061", "3070", "8934", "8684", "1228", "7140", "6793", "8690", "3670",
											 "8990", "8267", "5675", "5589", "6887", "6566", "2249", "1097", "4209", "8145",
											 "9365", "3260", "2963", "5008", "1879", "6469", "7479", "4770", "4283", "6481"};

	// TEST 복기부호
	public static final String[] SAFECARD_In_T = {"1232", "3985", "1357", "2354", "6654", "3123", "5487", "5432", "6546", "8721",
			                                      "3213", "4548", "4213", "4684", "6846", "6575", "3256", "9841", "5248", "8556",
			                                      "9874", "2655", "4122", "1453", "3658", "5241", "3574", "3213", "5451", "3566"};
	//운영	
	public static final String[] SAFECARD_In = {"0481", "2993", "1253", "5931", "4044", "2574", "8757", "4279", "9444", "9613",
		 										"5009", "4981", "8204", "1834", "8795", "4811", "4628", "3735", "0931", "8131",
		 										"5960", "7622", "3552", "9129", "9873", "6418", "0821", "7247", "0621", "9762"};
	
	/*** [대외계송수신] 복기부호처리_71 구해오기 위한 HEX_CON 배열 ***/
	public static final String[] ARRAYHEX_0 = {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"};
	public static final String[] ARRAYHEX_1 = {"4","P","B","E","X","G","9","A","D","1","R","Q","F","8","K","C"};
	public static final String[] ARRAYHEX_2 = {"R","Z","G","T","D","F","E","B","I","A","M","K","X","Q","C","7"};
	public static final String[] ARRAYHEX_3 = {"8","3","C","B","5","F","E","Z","Q","7","A","D","4","2","6","T"};
	public static final String[] ARRAYHEX_4 = {"D","A","4","9","7","5","Z","6","B","8","0","E","3","C","R","F"};
	public static final String[] ARRAYHEX_5 = {"1","7","F","Q","K","9","5","E","8","R","D","3","4","A","C","B"};
	public static final String[] ARRAYHEX_6 = {"5","A","D","M","C","6","E","0","B","P","X","8","Z","F","9","2"};
	public static final String[] ARRAYHEX_7 = {"X","6","7","1","F","I","2","9","E","5","C","B","M","E","A","0"};
	
/*** [대외계송수신] 업무코드 ***/
    
	/**계리*/
	public static final String BZCD_AT 					= "AT";	
    /**고객*/
	public static final String BZCD_CS 					= "CS";	
    /**방카*/
	public static final String BZCD_BS 					= "BS";	
    /**변액*/
	public static final String BZCD_VI 					= "VI";	
    /**보전*/
	public static final String BZCD_PR 					= "PR";	
    /**사고*/
	public static final String BZCD_AI 					= "AI";	
    /**상품*/
	public static final String BZCD_PD 					= "PD";	
    /**신계약*/
	public static final String BZCD_NB 					= "NB";	
    /**영업*/
	public static final String BZCD_SL 					= "SL";	
    /**융자*/
	public static final String BZCD_LN 					= "LN";	
    /**입금*/
	public static final String BZCD_DP 					= "DP";	
    /**재보험*/
	public static final String BZCD_RI 					= "RI";	
    /**지급*/
	public static final String BZCD_PA 					= "PA";	
    /**회계*/
	public static final String BZCD_AC 					= "AC";	
	
	/*** [대외계송수신] 은행응답코드(서버프로그램 오류코드) ***/
	public static final String BNK_ANSW_CD_9999 		= "9999";
	public static final String BNK_ANSW_CD_0000 		= "0000";
	
	/*** [대외계송수신] 옵션키(A:aSync, S:sync) ***/
    
    /**aSync*/
	public static final String OPTNKEY_A 				= "A";	
    /**sync*/
	public static final String OPTNKEY_S 				= "S";
	
/*** [대외계송수신] 출금이체동의상태구분코드 ***/
    
	/**출금이체동의*/
	public static final String WTRSF_ASNT_STA_ASNT 		= "1";	
    /**출금이체해지*/
	public static final String WTRSF_ASNT_STA_RESCS		= "2";
	
	/***  KSNET 카드 ***/
	public final static String EXTR_YES   = "Y";     //대외계연동 처리 구분
	public final static String EXTR_NO   = "N";     //대외계연동 처리 구분
	
	/* 업무 처리 구분 */
	public final static String BZ_GB_NB = "NB"; //신계약
	public final static String BZ_GB_DP = "DP"; //입금
	public final static String BZ_GB_CS = "CS"; //고객
	public final static String BZ_GB_UW = "UW"; //언더
	
	
	/* 카드 처리구분 */
//	public final static String CARD_TX_DCD_JA    = "JA";      //신용카드 승인 요청
//	public final static String CARD_TX_DCD_JC    = "JC";      // 신용카드 취소 요청
//	public final static String CARD_TX_DCD_JW    = "JW";      //신용카드 인증 요청
//
//	public final static String CARD_TX_DCD_JB    = "JB";      //신용카드 승인 응답
//	public final static String CARD_TX_DCD_JD    = "JD";      // 신용카드 취소 응답
//	public final static String CARD_TX_DCD_JX    = "JX";      //신용카드 인증 응답
	
	public final static String CARD_TX_DCD_FA    = "FA";      //신용카드 승인 요청
	public final static String CARD_TX_DCD_CC    = "CC";      // 신용카드 취소 요청
	public final static String CARD_TX_DCD_IA    = "IA";      //신용카드 인증 요청

	public final static String CARD_TX_DCD_FB    = "FB";      //신용카드 승인 응답
	public final static String CARD_TX_DCD_CD    = "CD";      // 신용카드 취소 응답
	public final static String CARD_TX_DCD_IB    = "IB";      //신용카드 인증 응답	
	
	public final static String REQUEST_SIZE_A  = "200";        //승인요청 전문SIZE
	public final static String REPLY_SIZE_A      = "189";        //승인요청응답 전문SIZE

	public final static String REQUEST_SIZE_R  = "59";     //승인취소 전문SIZE
	public final static String REPLY_SIZE_R      = "3";         //승인취소응답 전문SIZE
	
	// //////////////////////////////////////////////
    // 즉시카드신청 가능한 카드사 코드 //
    // /////////////////////////////////////////////
    public static final String IMMDT_CRDCOCD = "01,02,03,04,05,08,09,10,11,15,99";
    
    
	public final static String TRM_NO   = "DPT0007603";	// 단말기번호(신계약/고객용)
//	public final static String TRM_NO1  = "DPT0Q08499";	// 단말기번호(신계약/고객용) ---> 2013.12.30 롯데아멕스카드 다이렉트 본부인 경우
//	public final static String TRM_NO2  = "DPT0Q06718";	// 단말기번호(계속보헙료:입금파트용)
//	public final static String TRM_NO3  = "DPT0Q06719";	// 단말기번호(계속보헙료:입금파트용)
//	public final static String TRM_NO4  = "DPT0Q06720";	// 단말기번호(계속보헙료:입금파트용)
//	public final static String TRM_NO5  = "DPT0Q08500";	// 단말기번호(계속보헙료:입금파트용) ---> 2013.12.30 롯데아멕스카드 다이렉트 본부인 경우
	
	public final static String CMPY_NM  = "L51";            //업체번호
	
	public final static String NO_USE                 = "N"; //미사용
	public final static String POS_ENTRY_MD    = "K"; //KEY-IN
	public final static String TRACK_DC             = "="; //트랙구분
	public final static String ZERO                      = "0"; //봉사료,세금,공급금액
	public final static String WK_KEY                 = "AA"; //AA:비밀번호 미사용시
	public final static String PWD                       = "0000000000000000";   //비밀번호 미사용시: 0000000000000000
	
	public final static String ADMIT_DEFAULT_AMT    = "1000";                     //신용카드 인증 금액(실제 승인금액이 아님) : 5000원이하만 테스트 가능
	public final static String TEST_CONT_NO               = "0186180110003";      //테스트용 계약번호
	
	public final static String TEST_MODE   = "TEST";     //테스트
	public final static String REAL_MODE   = "REAL";    //리얼
	
	/***********  KIBNET *************/
	public final static String TGM_LEN   = "0600";    //전문길이
	public final static String CUST_NO   = "0009";    //CS번호
	public final static String CUST_INST_CD   = "20035007";    //CS기관코드
	public final static String CUST_INST_CD2   = "20035010";    //CS기관코드
	public final static String RERUN_CD   = "0";    //REACTION CODE
	public final static String CTNU_TX_NO   = "000";    //연속거래번호	
	
	public final static String SNDM_CD   = "5";    //송신코드
	public final static String RECE_CD   = "6";    //수신코드
	
	public final static String HNDL_INST_CD   = "20035007";    //취급기관코드
	public final static String HNDL_SALES_CD   = "20035007 ";    //취급영업점코드
	
	public final static String HNDL_INST_CD2   = "20035010";    //취급기관코드
	public final static String HNDL_SALES_CD2   = "20035010 ";    //취급영업점코드
	
	public final static String MED_DVSN   = "3";    //매체구분(3:제휴기관)
	public final static String KOR_CD_DVSN   = "2";    //한금코드국분
	
	public final static String ORG_TR_FACTR   = "      ";    //원거래요소
	public final static String OPEN_INST_CD  = "000009";    //개설기관코드
	
	
	/*** [대외계송수신] 모빌리언스 ***/
	public final static String CASH_DVSN   = "MC";    		//캐쉬구분
	
	public final static String REQ_TYP_STLM_CRTF  	= "04";    	//요청유형(결제인증)
	public final static String REQ_TYP_SMS_RTRNS  	= "06";    	//요청유형(SMS재전송)
	public final static String REQ_TYP_CRTF_NO_VRFC = "07";    	//요청유형(인증번호확인)
	public final static String REQ_TYP_STLM_APPV    = "21";    	//요청유형(결제승인)
	public final static String REQ_TYP_AUT_STLM   	= "43";    	//요청유형(자동결제)
	public final static String REQ_TYP_STLM_CNCL   	= "44";    	//요청유형(결재취소)
	
	
	/*** [대외계송수신] 가상계좌 ***/
	public final static String VACT_USAGE_CD_01  	= "01";    	//01:정기
	public final static String VACT_USAGE_CD_02  	= "02";    	//02:임시
	public final static String VACT_USAGE_CD_03  	= "03";    	//03:지료
	public final static String VACT_USAGE_CD_04  	= "04";    	//04:대출원리금상환
	public final static String VACT_USAGE_CD_05  	= "05";    	//05:부활보험료
	public final static String VACT_USAGE_CD_06  	= "06";    	//06:변경차액
	public final static String VACT_USAGE_CD_07  	= "07";    	//07:틀별부활
	public final static String VACT_USAGE_CD_08 	= "08";    	//08:제지급금회수
	public final static String VACT_USAGE_CD_09 	= "09";    	//09:보험금환수
	
	
	
	/*** 모계좌 발의부서 ***/
	public final static String ORG_NO_TM = "100903";// TM  101088 --> 100903
	public final static String ORG_NO_GA = "100918";//영업대면지원팀
	public final static String ORG_NO_UW_TEAM = "100971";//언더라이팅팀
	public final static String ORG_NO_AC_TEAM = "100974";//보험금심사팀
	public final static String ORG_NO_SVC_TEAM = "100977";//고객서비스팀	
	public final static String ORG_NO_CPS_TEAM = "100980";//계약유지서비스팀
	public final static String ORG_NO_DM_TEAM = "100995";//디지털마케팅팀
	public final static String ORG_NO_CNSU_SFGD_TEAM = "100981";//소비자보호팀
	public final static String ORG_NO_INTGR_MNT_TEAM = "101115";//통합모니터링
	
	/*조직종류 */
	public final static String ORG_KND_TM= "31";//조직종류코드 31 : TM	
	public final static String ORG_KND_GA= "40";//조직종류코드 40 : GA
	public final static String ORG_KND_BANCA= "33";//조직종류코드 33 : BANCA
	public final static String ORG_KND_CS= "90";//조직종류코드 90 : CS
	public final static String ORG_KND_STEP= "70";//조직종류코드 70 : 스텝부서
	
}