/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Tue Nov 13 15:00:50 KST 2012
 * 
 */
package cigna.cm.b.domain;

import java.io.Serializable;

/**
 * @DataObjectName TrsfTrrvPrcsInfo
 * @Description 
 */
public class TrsfTrrvPrcsInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = -1201219437L;
	/**
	 * @Type java.lang.String
	 * @Name prcsCd
	 * @Description 처리코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String prcsCd;
	/**
	 * @Type java.lang.String
	 * @Name chnlDcd
	 * @Description 채널구분코드
	 * @Length 4
	 * @Decimal 0
	 */
	private java.lang.String chnlDcd;
	/**
	 * @Type java.lang.String
	 * @Name prcsDt
	 * @Description 처리일자
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String prcsDt;
	/**
	 * @Type java.lang.String
	 * @Name payRcPathCd
	 * @Description 지급접수경로코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String payRcPathCd;
	/**
	 * @Type java.lang.String
	 * @Name payRcMcd
	 * @Description 지급접수방법코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String payRcMcd;
	/**
	 * @Type java.lang.String
	 * @Name pyprcPathCd
	 * @Description 지급처리경로코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String pyprcPathCd;
	/**
	 * @Type java.math.BigDecimal
	 * @Name trsfAmt
	 * @Description 이체금액
	 * @Length 15
	 * @Decimal 0
	 */
	private java.math.BigDecimal trsfAmt;
	/**
	 * @Type java.lang.String
	 * @Name benfcCustNo
	 * @Description 수익자고객번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String benfcCustNo;
	/**
	 * @Type java.lang.String
	 * @Name contrCustNo
	 * @Description 계약자고객번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String contrCustNo;
	/**
	 * @Type java.lang.String
	 * @Name dpwdDcd
	 * @Description 입출금구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String dpwdDcd;
	/**
	 * @Type java.lang.String
	 * @Name actMgntNo
	 * @Description 계좌관리번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String actMgntNo;
	/**
	 * @Type java.lang.String
	 * @Name bnkCd
	 * @Description 은행코드
	 * @Length 3
	 * @Decimal 0
	 */
	private java.lang.String bnkCd;
	/**
	 * @Type java.lang.String
	 * @Name actNo
	 * @Description 계좌번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String actNo;
	/**
	 * @Type java.lang.String
	 * @Name achdNm
	 * @Description 예금주명
	 * @Length 40
	 * @Decimal 0
	 */
	private java.lang.String achdNm;
	/**
	 * @Type java.lang.String
	 * @Name achdRrno
	 * @Description 예금주주민등록번호
	 * @Length 13
	 * @Decimal 0
	 */
	private java.lang.String achdRrno;
	/**
	 * @Type java.lang.String
	 * @Name nrmCnclDcd
	 * @Description 정상취소구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String nrmCnclDcd;
	/**
	 * @Type java.lang.String
	 * @Name bzDcd
	 * @Description 업무구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String bzDcd;
	/**
	 * @Type java.lang.String
	 * @Name bzTmKeyVl
	 * @Description 업무팀KEY값
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String bzTmKeyVl;
	/**
	 * @Type java.lang.String
	 * @Name reqBzTmBean
	 * @Description 요청파트BEAN
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String reqBzTmBean;
	/**
	 * @Type java.lang.String
	 * @Name reqBzTmMethod
	 * @Description 요청파트Method
	 * @Length 100
	 * @Decimal 0
	 */
	private java.lang.String reqBzTmMethod;
	/**
	 * @Type java.lang.String
	 * @Name prcsBnkCd
	 * @Description 처리은행코드
	 * @Length 3
	 * @Decimal 0
	 */
	private java.lang.String prcsBnkCd;
	/**
	 * @Type java.lang.String
	 * @Name trmsDcd
	 * @Description 전송구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String trmsDcd;
	/**
	 * @Type java.lang.String
	 * @Name bnkAnswCd
	 * @Description 은행응답코드
	 * @Length 4
	 * @Decimal 0
	 */
	private java.lang.String bnkAnswCd;
	/**
	 * @Type java.lang.String
	 * @Name prcsHms
	 * @Description 처리시간
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String prcsHms;
	/**
	 * @Type java.lang.String
	 * @Name rltmTrsfTxNo
	 * @Description 리얼타임이체거래번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String rltmTrsfTxNo;
	/**
	 * @Type java.lang.String
	 * @Name optnKey
	 * @Description 옵션키(A:aSync, S:sync)
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String optnKey;

	/**
	 * @Type java.lang.String
	 * @Name pyrcDofOrgNo
	 * @Description pyrcDofOrgNo 기처리자 조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String pyrcDofOrgNo;
  
	/**
	 * @Type java.lang.String
	 * @Name pyrcFofOrgNo
	 * @Description pyrcDofOrgNo 기처리자 Fof 조직번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String pyrcFofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name pyrcPrcsEno
	 * @Description pyrcPrcsEno 기처리자 사원번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String pyrcPrcsEno;
	
	/**
	 * @Type java.lang.String
	 * @Name propoDeptOrgNo
	 * @Description propoDeptOrgNo 발의부서
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String propoDeptOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntSysCd
	 * @Description 출금이체동의시스템코드
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntSysCd;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntEvidDcd
	 * @Description 출금이체동의증빙구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntEvidDcd;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntEvidNo
	 * @Description 출금이체동의증빙번호
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntEvidNo;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntDcd
	 * @Description 출금이체동의구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntDcd;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntRcDcd
	 * @Description 출금이체동의접수구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntRcDcd;
	/**
	 * @Type java.lang.String
	 * @Name contNo
	 * @Description 계약번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String contNo;
	
	/**
	 * @Type java.lang.String
	 * @Name contrNm
	 * @Description 계약자명
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String contrNm;
	
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntVcrecStrtDtm
	 * @Description 출금이체동의녹취시작일시
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntVcrecStrtDtm;
	
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntVcrecEndDtm
	 * @Description 출금이체동의녹취종료일시
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntVcrecEndDtm;
	
	/**
	 * @Type java.lang.String
	 * @Name centrNm
	 * @Description 센터명
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String centrNm;
	
	/**
	 * @Type java.lang.String
	 * @Name teamNm
	 * @Description 팀명
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String teamNm;
	
	/**
	 * @Type java.lang.String
	 * @Name chrgpEno
	 * @Description 담당자사원번호
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String chrgpEno;
	
	/**
	 * @Type java.lang.String
	 * @Name chrgpNm
	 * @Description 담당자사원명
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String chrgpNm;
	
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntDt
	 * @Description 출금이체동의일자
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntDt;
	
	@Override
    public TrsfTrrvPrcsInfo clone()
    {
		TrsfTrrvPrcsInfo obj = null;
        
        try
        {
            obj = (TrsfTrrvPrcsInfo) super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            return null;
        }
        
        return obj;
    }

	public java.lang.String getPrcsCd() {
		return prcsCd;
	}

	public void setPrcsCd(java.lang.String prcsCd) {
		this.prcsCd = prcsCd;
	}

	public java.lang.String getChnlDcd() {
		return chnlDcd;
	}

	public void setChnlDcd(java.lang.String chnlDcd) {
		this.chnlDcd = chnlDcd;
	}

	public java.lang.String getPrcsDt() {
		return prcsDt;
	}

	public void setPrcsDt(java.lang.String prcsDt) {
		this.prcsDt = prcsDt;
	}

	public java.lang.String getPayRcPathCd() {
		return payRcPathCd;
	}

	public void setPayRcPathCd(java.lang.String payRcPathCd) {
		this.payRcPathCd = payRcPathCd;
	}

	public java.lang.String getPayRcMcd() {
		return payRcMcd;
	}

	public void setPayRcMcd(java.lang.String payRcMcd) {
		this.payRcMcd = payRcMcd;
	}

	public java.lang.String getPyprcPathCd() {
		return pyprcPathCd;
	}

	public void setPyprcPathCd(java.lang.String pyprcPathCd) {
		this.pyprcPathCd = pyprcPathCd;
	}

	public java.math.BigDecimal getTrsfAmt() {
		return trsfAmt;
	}

	public void setTrsfAmt(java.math.BigDecimal trsfAmt) {
		this.trsfAmt = trsfAmt;
	}

	public java.lang.String getBenfcCustNo() {
		return benfcCustNo;
	}

	public void setBenfcCustNo(java.lang.String benfcCustNo) {
		this.benfcCustNo = benfcCustNo;
	}

	public java.lang.String getContrCustNo() {
		return contrCustNo;
	}

	public void setContrCustNo(java.lang.String contrCustNo) {
		this.contrCustNo = contrCustNo;
	}

	public java.lang.String getDpwdDcd() {
		return dpwdDcd;
	}

	public void setDpwdDcd(java.lang.String dpwdDcd) {
		this.dpwdDcd = dpwdDcd;
	}

	public java.lang.String getActMgntNo() {
		return actMgntNo;
	}

	public void setActMgntNo(java.lang.String actMgntNo) {
		this.actMgntNo = actMgntNo;
	}

	public java.lang.String getBnkCd() {
		return bnkCd;
	}

	public void setBnkCd(java.lang.String bnkCd) {
		this.bnkCd = bnkCd;
	}

	public java.lang.String getActNo() {
		return actNo;
	}

	public void setActNo(java.lang.String actNo) {
		this.actNo = actNo;
	}

	public java.lang.String getAchdNm() {
		return achdNm;
	}

	public void setAchdNm(java.lang.String achdNm) {
		this.achdNm = achdNm;
	}

	public java.lang.String getAchdRrno() {
		return achdRrno;
	}

	public void setAchdRrno(java.lang.String achdRrno) {
		this.achdRrno = achdRrno;
	}

	public java.lang.String getNrmCnclDcd() {
		return nrmCnclDcd;
	}

	public void setNrmCnclDcd(java.lang.String nrmCnclDcd) {
		this.nrmCnclDcd = nrmCnclDcd;
	}

	public java.lang.String getBzDcd() {
		return bzDcd;
	}

	public void setBzDcd(java.lang.String bzDcd) {
		this.bzDcd = bzDcd;
	}

	public java.lang.String getBzTmKeyVl() {
		return bzTmKeyVl;
	}

	public void setBzTmKeyVl(java.lang.String bzTmKeyVl) {
		this.bzTmKeyVl = bzTmKeyVl;
	}

	public java.lang.String getReqBzTmBean() {
		return reqBzTmBean;
	}

	public void setReqBzTmBean(java.lang.String reqBzTmBean) {
		this.reqBzTmBean = reqBzTmBean;
	}

	public java.lang.String getReqBzTmMethod() {
		return reqBzTmMethod;
	}

	public void setReqBzTmMethod(java.lang.String reqBzTmMethod) {
		this.reqBzTmMethod = reqBzTmMethod;
	}

	public java.lang.String getPrcsBnkCd() {
		return prcsBnkCd;
	}

	public void setPrcsBnkCd(java.lang.String prcsBnkCd) {
		this.prcsBnkCd = prcsBnkCd;
	}

	public java.lang.String getTrmsDcd() {
		return trmsDcd;
	}

	public void setTrmsDcd(java.lang.String trmsDcd) {
		this.trmsDcd = trmsDcd;
	}

	public java.lang.String getBnkAnswCd() {
		return bnkAnswCd;
	}

	public void setBnkAnswCd(java.lang.String bnkAnswCd) {
		this.bnkAnswCd = bnkAnswCd;
	}

	public java.lang.String getPrcsHms() {
		return prcsHms;
	}

	public void setPrcsHms(java.lang.String prcsHms) {
		this.prcsHms = prcsHms;
	}

	public java.lang.String getRltmTrsfTxNo() {
		return rltmTrsfTxNo;
	}

	public void setRltmTrsfTxNo(java.lang.String rltmTrsfTxNo) {
		this.rltmTrsfTxNo = rltmTrsfTxNo;
	}

	public java.lang.String getOptnKey() {
		return optnKey;
	}

	public void setOptnKey(java.lang.String optnKey) {
		this.optnKey = optnKey;
	}

	public java.lang.String getPyrcDofOrgNo() {
		return pyrcDofOrgNo;
	}

	public void setPyrcDofOrgNo(java.lang.String pyrcDofOrgNo) {
		this.pyrcDofOrgNo = pyrcDofOrgNo;
	}

	public java.lang.String getPyrcFofOrgNo() {
		return pyrcFofOrgNo;
	}

	public void setPyrcFofOrgNo(java.lang.String pyrcFofOrgNo) {
		this.pyrcFofOrgNo = pyrcFofOrgNo;
	}

	public java.lang.String getPyrcPrcsEno() {
		return pyrcPrcsEno;
	}

	public void setPyrcPrcsEno(java.lang.String pyrcPrcsEno) {
		this.pyrcPrcsEno = pyrcPrcsEno;
	}

	public java.lang.String getPropoDeptOrgNo() {
		return propoDeptOrgNo;
	}

	public void setPropoDeptOrgNo(java.lang.String propoDeptOrgNo) {
		this.propoDeptOrgNo = propoDeptOrgNo;
	}

	public java.lang.String getWtrsfAsntSysCd() {
		return wtrsfAsntSysCd;
	}

	public void setWtrsfAsntSysCd(java.lang.String wtrsfAsntSysCd) {
		this.wtrsfAsntSysCd = wtrsfAsntSysCd;
	}

	public java.lang.String getWtrsfAsntEvidDcd() {
		return wtrsfAsntEvidDcd;
	}

	public void setWtrsfAsntEvidDcd(java.lang.String wtrsfAsntEvidDcd) {
		this.wtrsfAsntEvidDcd = wtrsfAsntEvidDcd;
	}

	public java.lang.String getWtrsfAsntEvidNo() {
		return wtrsfAsntEvidNo;
	}

	public void setWtrsfAsntEvidNo(java.lang.String wtrsfAsntEvidNo) {
		this.wtrsfAsntEvidNo = wtrsfAsntEvidNo;
	}

	public java.lang.String getWtrsfAsntDcd() {
		return wtrsfAsntDcd;
	}

	public void setWtrsfAsntDcd(java.lang.String wtrsfAsntDcd) {
		this.wtrsfAsntDcd = wtrsfAsntDcd;
	}

	public java.lang.String getWtrsfAsntRcDcd() {
		return wtrsfAsntRcDcd;
	}

	public void setWtrsfAsntRcDcd(java.lang.String wtrsfAsntRcDcd) {
		this.wtrsfAsntRcDcd = wtrsfAsntRcDcd;
	}

	public java.lang.String getContNo() {
		return contNo;
	}

	public void setContNo(java.lang.String contNo) {
		this.contNo = contNo;
	}

	public java.lang.String getContrNm() {
		return contrNm;
	}

	public void setContrNm(java.lang.String contrNm) {
		this.contrNm = contrNm;
	}

	public java.lang.String getWtrsfAsntVcrecStrtDtm() {
		return wtrsfAsntVcrecStrtDtm;
	}

	public void setWtrsfAsntVcrecStrtDtm(java.lang.String wtrsfAsntVcrecStrtDtm) {
		this.wtrsfAsntVcrecStrtDtm = wtrsfAsntVcrecStrtDtm;
	}

	public java.lang.String getWtrsfAsntVcrecEndDtm() {
		return wtrsfAsntVcrecEndDtm;
	}

	public void setWtrsfAsntVcrecEndDtm(java.lang.String wtrsfAsntVcrecEndDtm) {
		this.wtrsfAsntVcrecEndDtm = wtrsfAsntVcrecEndDtm;
	}

	public java.lang.String getCentrNm() {
		return centrNm;
	}

	public void setCentrNm(java.lang.String centrNm) {
		this.centrNm = centrNm;
	}

	public java.lang.String getTeamNm() {
		return teamNm;
	}

	public void setTeamNm(java.lang.String teamNm) {
		this.teamNm = teamNm;
	}

	public java.lang.String getChrgpEno() {
		return chrgpEno;
	}

	public void setChrgpEno(java.lang.String chrgpEno) {
		this.chrgpEno = chrgpEno;
	}

	public java.lang.String getChrgpNm() {
		return chrgpNm;
	}

	public void setChrgpNm(java.lang.String chrgpNm) {
		this.chrgpNm = chrgpNm;
	}

	public java.lang.String getWtrsfAsntDt() {
		return wtrsfAsntDt;
	}

	public void setWtrsfAsntDt(java.lang.String wtrsfAsntDt) {
		this.wtrsfAsntDt = wtrsfAsntDt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((achdNm == null) ? 0 : achdNm.hashCode());
		result = prime * result
				+ ((achdRrno == null) ? 0 : achdRrno.hashCode());
		result = prime * result
				+ ((actMgntNo == null) ? 0 : actMgntNo.hashCode());
		result = prime * result + ((actNo == null) ? 0 : actNo.hashCode());
		result = prime * result
				+ ((benfcCustNo == null) ? 0 : benfcCustNo.hashCode());
		result = prime * result
				+ ((bnkAnswCd == null) ? 0 : bnkAnswCd.hashCode());
		result = prime * result + ((bnkCd == null) ? 0 : bnkCd.hashCode());
		result = prime * result + ((bzDcd == null) ? 0 : bzDcd.hashCode());
		result = prime * result
				+ ((bzTmKeyVl == null) ? 0 : bzTmKeyVl.hashCode());
		result = prime * result + ((centrNm == null) ? 0 : centrNm.hashCode());
		result = prime * result + ((chnlDcd == null) ? 0 : chnlDcd.hashCode());
		result = prime * result
				+ ((chrgpEno == null) ? 0 : chrgpEno.hashCode());
		result = prime * result + ((chrgpNm == null) ? 0 : chrgpNm.hashCode());
		result = prime * result + ((contNo == null) ? 0 : contNo.hashCode());
		result = prime * result
				+ ((contrCustNo == null) ? 0 : contrCustNo.hashCode());
		result = prime * result + ((contrNm == null) ? 0 : contrNm.hashCode());
		result = prime * result + ((dpwdDcd == null) ? 0 : dpwdDcd.hashCode());
		result = prime * result
				+ ((nrmCnclDcd == null) ? 0 : nrmCnclDcd.hashCode());
		result = prime * result + ((optnKey == null) ? 0 : optnKey.hashCode());
		result = prime * result
				+ ((payRcMcd == null) ? 0 : payRcMcd.hashCode());
		result = prime * result
				+ ((payRcPathCd == null) ? 0 : payRcPathCd.hashCode());
		result = prime * result
				+ ((prcsBnkCd == null) ? 0 : prcsBnkCd.hashCode());
		result = prime * result + ((prcsCd == null) ? 0 : prcsCd.hashCode());
		result = prime * result + ((prcsDt == null) ? 0 : prcsDt.hashCode());
		result = prime * result + ((prcsHms == null) ? 0 : prcsHms.hashCode());
		result = prime * result
				+ ((propoDeptOrgNo == null) ? 0 : propoDeptOrgNo.hashCode());
		result = prime * result
				+ ((pyprcPathCd == null) ? 0 : pyprcPathCd.hashCode());
		result = prime * result
				+ ((pyrcDofOrgNo == null) ? 0 : pyrcDofOrgNo.hashCode());
		result = prime * result
				+ ((pyrcFofOrgNo == null) ? 0 : pyrcFofOrgNo.hashCode());
		result = prime * result
				+ ((pyrcPrcsEno == null) ? 0 : pyrcPrcsEno.hashCode());
		result = prime * result
				+ ((reqBzTmBean == null) ? 0 : reqBzTmBean.hashCode());
		result = prime * result
				+ ((reqBzTmMethod == null) ? 0 : reqBzTmMethod.hashCode());
		result = prime * result
				+ ((rltmTrsfTxNo == null) ? 0 : rltmTrsfTxNo.hashCode());
		result = prime * result + ((teamNm == null) ? 0 : teamNm.hashCode());
		result = prime * result + ((trmsDcd == null) ? 0 : trmsDcd.hashCode());
		result = prime * result + ((trsfAmt == null) ? 0 : trsfAmt.hashCode());
		result = prime * result
				+ ((wtrsfAsntDcd == null) ? 0 : wtrsfAsntDcd.hashCode());
		result = prime * result
				+ ((wtrsfAsntDt == null) ? 0 : wtrsfAsntDt.hashCode());
		result = prime
				* result
				+ ((wtrsfAsntEvidDcd == null) ? 0 : wtrsfAsntEvidDcd.hashCode());
		result = prime * result
				+ ((wtrsfAsntEvidNo == null) ? 0 : wtrsfAsntEvidNo.hashCode());
		result = prime * result
				+ ((wtrsfAsntRcDcd == null) ? 0 : wtrsfAsntRcDcd.hashCode());
		result = prime * result
				+ ((wtrsfAsntSysCd == null) ? 0 : wtrsfAsntSysCd.hashCode());
		result = prime
				* result
				+ ((wtrsfAsntVcrecEndDtm == null) ? 0 : wtrsfAsntVcrecEndDtm
						.hashCode());
		result = prime
				* result
				+ ((wtrsfAsntVcrecStrtDtm == null) ? 0 : wtrsfAsntVcrecStrtDtm
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrsfTrrvPrcsInfo other = (TrsfTrrvPrcsInfo) obj;
		if (achdNm == null) {
			if (other.achdNm != null)
				return false;
		} else if (!achdNm.equals(other.achdNm))
			return false;
		if (achdRrno == null) {
			if (other.achdRrno != null)
				return false;
		} else if (!achdRrno.equals(other.achdRrno))
			return false;
		if (actMgntNo == null) {
			if (other.actMgntNo != null)
				return false;
		} else if (!actMgntNo.equals(other.actMgntNo))
			return false;
		if (actNo == null) {
			if (other.actNo != null)
				return false;
		} else if (!actNo.equals(other.actNo))
			return false;
		if (benfcCustNo == null) {
			if (other.benfcCustNo != null)
				return false;
		} else if (!benfcCustNo.equals(other.benfcCustNo))
			return false;
		if (bnkAnswCd == null) {
			if (other.bnkAnswCd != null)
				return false;
		} else if (!bnkAnswCd.equals(other.bnkAnswCd))
			return false;
		if (bnkCd == null) {
			if (other.bnkCd != null)
				return false;
		} else if (!bnkCd.equals(other.bnkCd))
			return false;
		if (bzDcd == null) {
			if (other.bzDcd != null)
				return false;
		} else if (!bzDcd.equals(other.bzDcd))
			return false;
		if (bzTmKeyVl == null) {
			if (other.bzTmKeyVl != null)
				return false;
		} else if (!bzTmKeyVl.equals(other.bzTmKeyVl))
			return false;
		if (centrNm == null) {
			if (other.centrNm != null)
				return false;
		} else if (!centrNm.equals(other.centrNm))
			return false;
		if (chnlDcd == null) {
			if (other.chnlDcd != null)
				return false;
		} else if (!chnlDcd.equals(other.chnlDcd))
			return false;
		if (chrgpEno == null) {
			if (other.chrgpEno != null)
				return false;
		} else if (!chrgpEno.equals(other.chrgpEno))
			return false;
		if (chrgpNm == null) {
			if (other.chrgpNm != null)
				return false;
		} else if (!chrgpNm.equals(other.chrgpNm))
			return false;
		if (contNo == null) {
			if (other.contNo != null)
				return false;
		} else if (!contNo.equals(other.contNo))
			return false;
		if (contrCustNo == null) {
			if (other.contrCustNo != null)
				return false;
		} else if (!contrCustNo.equals(other.contrCustNo))
			return false;
		if (contrNm == null) {
			if (other.contrNm != null)
				return false;
		} else if (!contrNm.equals(other.contrNm))
			return false;
		if (dpwdDcd == null) {
			if (other.dpwdDcd != null)
				return false;
		} else if (!dpwdDcd.equals(other.dpwdDcd))
			return false;
		if (nrmCnclDcd == null) {
			if (other.nrmCnclDcd != null)
				return false;
		} else if (!nrmCnclDcd.equals(other.nrmCnclDcd))
			return false;
		if (optnKey == null) {
			if (other.optnKey != null)
				return false;
		} else if (!optnKey.equals(other.optnKey))
			return false;
		if (payRcMcd == null) {
			if (other.payRcMcd != null)
				return false;
		} else if (!payRcMcd.equals(other.payRcMcd))
			return false;
		if (payRcPathCd == null) {
			if (other.payRcPathCd != null)
				return false;
		} else if (!payRcPathCd.equals(other.payRcPathCd))
			return false;
		if (prcsBnkCd == null) {
			if (other.prcsBnkCd != null)
				return false;
		} else if (!prcsBnkCd.equals(other.prcsBnkCd))
			return false;
		if (prcsCd == null) {
			if (other.prcsCd != null)
				return false;
		} else if (!prcsCd.equals(other.prcsCd))
			return false;
		if (prcsDt == null) {
			if (other.prcsDt != null)
				return false;
		} else if (!prcsDt.equals(other.prcsDt))
			return false;
		if (prcsHms == null) {
			if (other.prcsHms != null)
				return false;
		} else if (!prcsHms.equals(other.prcsHms))
			return false;
		if (propoDeptOrgNo == null) {
			if (other.propoDeptOrgNo != null)
				return false;
		} else if (!propoDeptOrgNo.equals(other.propoDeptOrgNo))
			return false;
		if (pyprcPathCd == null) {
			if (other.pyprcPathCd != null)
				return false;
		} else if (!pyprcPathCd.equals(other.pyprcPathCd))
			return false;
		if (pyrcDofOrgNo == null) {
			if (other.pyrcDofOrgNo != null)
				return false;
		} else if (!pyrcDofOrgNo.equals(other.pyrcDofOrgNo))
			return false;
		if (pyrcFofOrgNo == null) {
			if (other.pyrcFofOrgNo != null)
				return false;
		} else if (!pyrcFofOrgNo.equals(other.pyrcFofOrgNo))
			return false;
		if (pyrcPrcsEno == null) {
			if (other.pyrcPrcsEno != null)
				return false;
		} else if (!pyrcPrcsEno.equals(other.pyrcPrcsEno))
			return false;
		if (reqBzTmBean == null) {
			if (other.reqBzTmBean != null)
				return false;
		} else if (!reqBzTmBean.equals(other.reqBzTmBean))
			return false;
		if (reqBzTmMethod == null) {
			if (other.reqBzTmMethod != null)
				return false;
		} else if (!reqBzTmMethod.equals(other.reqBzTmMethod))
			return false;
		if (rltmTrsfTxNo == null) {
			if (other.rltmTrsfTxNo != null)
				return false;
		} else if (!rltmTrsfTxNo.equals(other.rltmTrsfTxNo))
			return false;
		if (teamNm == null) {
			if (other.teamNm != null)
				return false;
		} else if (!teamNm.equals(other.teamNm))
			return false;
		if (trmsDcd == null) {
			if (other.trmsDcd != null)
				return false;
		} else if (!trmsDcd.equals(other.trmsDcd))
			return false;
		if (trsfAmt == null) {
			if (other.trsfAmt != null)
				return false;
		} else if (!trsfAmt.equals(other.trsfAmt))
			return false;
		if (wtrsfAsntDcd == null) {
			if (other.wtrsfAsntDcd != null)
				return false;
		} else if (!wtrsfAsntDcd.equals(other.wtrsfAsntDcd))
			return false;
		if (wtrsfAsntDt == null) {
			if (other.wtrsfAsntDt != null)
				return false;
		} else if (!wtrsfAsntDt.equals(other.wtrsfAsntDt))
			return false;
		if (wtrsfAsntEvidDcd == null) {
			if (other.wtrsfAsntEvidDcd != null)
				return false;
		} else if (!wtrsfAsntEvidDcd.equals(other.wtrsfAsntEvidDcd))
			return false;
		if (wtrsfAsntEvidNo == null) {
			if (other.wtrsfAsntEvidNo != null)
				return false;
		} else if (!wtrsfAsntEvidNo.equals(other.wtrsfAsntEvidNo))
			return false;
		if (wtrsfAsntRcDcd == null) {
			if (other.wtrsfAsntRcDcd != null)
				return false;
		} else if (!wtrsfAsntRcDcd.equals(other.wtrsfAsntRcDcd))
			return false;
		if (wtrsfAsntSysCd == null) {
			if (other.wtrsfAsntSysCd != null)
				return false;
		} else if (!wtrsfAsntSysCd.equals(other.wtrsfAsntSysCd))
			return false;
		if (wtrsfAsntVcrecEndDtm == null) {
			if (other.wtrsfAsntVcrecEndDtm != null)
				return false;
		} else if (!wtrsfAsntVcrecEndDtm.equals(other.wtrsfAsntVcrecEndDtm))
			return false;
		if (wtrsfAsntVcrecStrtDtm == null) {
			if (other.wtrsfAsntVcrecStrtDtm != null)
				return false;
		} else if (!wtrsfAsntVcrecStrtDtm.equals(other.wtrsfAsntVcrecStrtDtm))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TrsfTrrvPrcsInfo [\n  prcsCd: ");
		builder.append(prcsCd);
		builder.append("\n  chnlDcd: ");
		builder.append(chnlDcd);
		builder.append("\n  prcsDt: ");
		builder.append(prcsDt);
		builder.append("\n  payRcPathCd: ");
		builder.append(payRcPathCd);
		builder.append("\n  payRcMcd: ");
		builder.append(payRcMcd);
		builder.append("\n  pyprcPathCd: ");
		builder.append(pyprcPathCd);
		builder.append("\n  trsfAmt: ");
		builder.append(trsfAmt);
		builder.append("\n  benfcCustNo: ");
		builder.append(benfcCustNo);
		builder.append("\n  contrCustNo: ");
		builder.append(contrCustNo);
		builder.append("\n  dpwdDcd: ");
		builder.append(dpwdDcd);
		builder.append("\n  actMgntNo: ");
		builder.append(actMgntNo);
		builder.append("\n  bnkCd: ");
		builder.append(bnkCd);
		builder.append("\n  actNo: ");
		builder.append(actNo);
		builder.append("\n  achdNm: ");
		builder.append(achdNm);
		builder.append("\n  achdRrno: ");
		builder.append(achdRrno);
		builder.append("\n  nrmCnclDcd: ");
		builder.append(nrmCnclDcd);
		builder.append("\n  bzDcd: ");
		builder.append(bzDcd);
		builder.append("\n  bzTmKeyVl: ");
		builder.append(bzTmKeyVl);
		builder.append("\n  reqBzTmBean: ");
		builder.append(reqBzTmBean);
		builder.append("\n  reqBzTmMethod: ");
		builder.append(reqBzTmMethod);
		builder.append("\n  prcsBnkCd: ");
		builder.append(prcsBnkCd);
		builder.append("\n  trmsDcd: ");
		builder.append(trmsDcd);
		builder.append("\n  bnkAnswCd: ");
		builder.append(bnkAnswCd);
		builder.append("\n  prcsHms: ");
		builder.append(prcsHms);
		builder.append("\n  rltmTrsfTxNo: ");
		builder.append(rltmTrsfTxNo);
		builder.append("\n  optnKey: ");
		builder.append(optnKey);
		builder.append("\n  pyrcDofOrgNo: ");
		builder.append(pyrcDofOrgNo);
		builder.append("\n  pyrcFofOrgNo: ");
		builder.append(pyrcFofOrgNo);
		builder.append("\n  pyrcPrcsEno: ");
		builder.append(pyrcPrcsEno);
		builder.append("\n  propoDeptOrgNo: ");
		builder.append(propoDeptOrgNo);
		builder.append("\n  wtrsfAsntSysCd: ");
		builder.append(wtrsfAsntSysCd);
		builder.append("\n  wtrsfAsntEvidDcd: ");
		builder.append(wtrsfAsntEvidDcd);
		builder.append("\n  wtrsfAsntEvidNo: ");
		builder.append(wtrsfAsntEvidNo);
		builder.append("\n  wtrsfAsntDcd: ");
		builder.append(wtrsfAsntDcd);
		builder.append("\n  wtrsfAsntRcDcd: ");
		builder.append(wtrsfAsntRcDcd);
		builder.append("\n  contNo: ");
		builder.append(contNo);
		builder.append("\n  contrNm: ");
		builder.append(contrNm);
		builder.append("\n  wtrsfAsntVcrecStrtDtm: ");
		builder.append(wtrsfAsntVcrecStrtDtm);
		builder.append("\n  wtrsfAsntVcrecEndDtm: ");
		builder.append(wtrsfAsntVcrecEndDtm);
		builder.append("\n  centrNm: ");
		builder.append(centrNm);
		builder.append("\n  teamNm: ");
		builder.append(teamNm);
		builder.append("\n  chrgpEno: ");
		builder.append(chrgpEno);
		builder.append("\n  chrgpNm: ");
		builder.append(chrgpNm);
		builder.append("\n  wtrsfAsntDt: ");
		builder.append(wtrsfAsntDt);
		builder.append("\n]");
		return builder.toString();
	}

	
}
