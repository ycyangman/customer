/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Thu Nov 17 17:13:12 KST 2016
 * 
 */
package cigna.cm.b.domain;

import java.io.Serializable;

/**
 * @DataObjectName VcrecDlngInfo
 * @Description 
 */
public class VcrecDlngInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 1887235454L;
	/**
	 * @Type java.lang.String
	 * @Name vcrecPrcsMgntNo
	 * @Description 녹취처리관리번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String vcrecPrcsMgntNo;
	/**
	 * @Type java.lang.String
	 * @Name vcrecSysCd
	 * @Description 녹취시스템코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String vcrecSysCd;
	/**
	 * @Type java.lang.String
	 * @Name bzTxRfDcd
	 * @Description 업무거래참조구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String bzTxRfDcd;
	/**
	 * @Type java.lang.String
	 * @Name bzTxRfDtlDcd
	 * @Description 업무거래참조상세구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String bzTxRfDtlDcd;
	/**
	 * @Type java.lang.String
	 * @Name bzTxRfNo
	 * @Description 업무거래참조번호
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String bzTxRfNo;
	/**
	 * @Type java.lang.String
	 * @Name vcrecId
	 * @Description 녹취ID
	 * @Length 30
	 * @Decimal 0
	 */
	private java.lang.String vcrecId;
	/**
	 * @Type java.lang.String
	 * @Name cnslNo
	 * @Description 상담번호
	 * @Length 19
	 * @Decimal 0
	 */
	private java.lang.String cnslNo;
	/**
	 * @Type java.lang.String
	 * @Name delYn
	 * @Description 삭제여부
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String delYn;
	/**
	 * @Type java.util.Date
	 * @Name lastChgDtm
	 * @Description 최종변경일시
	 * @Length 30
	 * @Decimal 0
	 */
	private java.util.Date lastChgDtm;
	/**
	 * @Type java.lang.String
	 * @Name lastChgrId
	 * @Description 최종변경자ID
	 * @Length 10
	 * @Decimal 0
	 */
	private java.lang.String lastChgrId;
	/**
	 * @Type java.lang.String
	 * @Name lastChgPgmId
	 * @Description 최종변경프로그램ID
	 * @Length 15
	 * @Decimal 0
	 */
	private java.lang.String lastChgPgmId;
	/**
	 * @Type java.lang.String
	 * @Name lastChgTrmNo
	 * @Description 최종변경단말번호
	 * @Length 40
	 * @Decimal 0
	 */
	private java.lang.String lastChgTrmNo;

	/**
	 * GET 녹취시스템코드
	 */
	public java.lang.String getVcrecSysCd() {
		return this.vcrecSysCd;
	}

	/**
	 * SET 녹취시스템코드
	 */
	public void setVcrecSysCd(java.lang.String vcrecSysCd) {
		this.vcrecSysCd = vcrecSysCd;
	}

	/**
	 * GET 업무거래참조구분코드
	 */
	public java.lang.String getBzTxRfDcd() {
		return this.bzTxRfDcd;
	}

	/**
	 * SET 업무거래참조구분코드
	 */
	public void setBzTxRfDcd(java.lang.String bzTxRfDcd) {
		this.bzTxRfDcd = bzTxRfDcd;
	}

	/**
	 * GET 업무거래참조상세구분코드
	 */
	public java.lang.String getBzTxRfDtlDcd() {
		return this.bzTxRfDtlDcd;
	}

	/**
	 * SET 업무거래참조상세구분코드
	 */
	public void setBzTxRfDtlDcd(java.lang.String bzTxRfDtlDcd) {
		this.bzTxRfDtlDcd = bzTxRfDtlDcd;
	}

	/**
	 * GET 업무거래참조번호
	 */
	public java.lang.String getBzTxRfNo() {
		return this.bzTxRfNo;
	}

	/**
	 * SET 업무거래참조번호
	 */
	public void setBzTxRfNo(java.lang.String bzTxRfNo) {
		this.bzTxRfNo = bzTxRfNo;
	}

	/**
	 * GET 녹취ID
	 */
	public java.lang.String getVcrecId() {
		return this.vcrecId;
	}

	/**
	 * SET 녹취ID
	 */
	public void setVcrecId(java.lang.String vcrecId) {
		this.vcrecId = vcrecId;
	}

	/**
	 * GET 상담번호
	 */
	public java.lang.String getCnslNo() {
		return this.cnslNo;
	}

	/**
	 * SET 상담번호
	 */
	public void setCnslNo(java.lang.String cnslNo) {
		this.cnslNo = cnslNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((vcrecPrcsMgntNo == null) ? 0 : vcrecPrcsMgntNo.hashCode());
		result = prime * result
				+ ((vcrecSysCd == null) ? 0 : vcrecSysCd.hashCode());
		result = prime * result
				+ ((bzTxRfDcd == null) ? 0 : bzTxRfDcd.hashCode());
		result = prime * result
				+ ((bzTxRfDtlDcd == null) ? 0 : bzTxRfDtlDcd.hashCode());
		result = prime * result
				+ ((bzTxRfNo == null) ? 0 : bzTxRfNo.hashCode());
		result = prime * result + ((vcrecId == null) ? 0 : vcrecId.hashCode());
		result = prime * result + ((cnslNo == null) ? 0 : cnslNo.hashCode());
		result = prime * result + ((delYn == null) ? 0 : delYn.hashCode());
		result = prime * result
				+ ((lastChgDtm == null) ? 0 : lastChgDtm.hashCode());
		result = prime * result
				+ ((lastChgrId == null) ? 0 : lastChgrId.hashCode());
		result = prime * result
				+ ((lastChgPgmId == null) ? 0 : lastChgPgmId.hashCode());
		result = prime * result
				+ ((lastChgTrmNo == null) ? 0 : lastChgTrmNo.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VcrecDlngInfo other = (VcrecDlngInfo) obj;
		if (vcrecPrcsMgntNo == null) {
			if (other.vcrecPrcsMgntNo != null)
				return false;
		} else if (!vcrecPrcsMgntNo.equals(other.vcrecPrcsMgntNo))
			return false;
		if (vcrecSysCd == null) {
			if (other.vcrecSysCd != null)
				return false;
		} else if (!vcrecSysCd.equals(other.vcrecSysCd))
			return false;
		if (bzTxRfDcd == null) {
			if (other.bzTxRfDcd != null)
				return false;
		} else if (!bzTxRfDcd.equals(other.bzTxRfDcd))
			return false;
		if (bzTxRfDtlDcd == null) {
			if (other.bzTxRfDtlDcd != null)
				return false;
		} else if (!bzTxRfDtlDcd.equals(other.bzTxRfDtlDcd))
			return false;
		if (bzTxRfNo == null) {
			if (other.bzTxRfNo != null)
				return false;
		} else if (!bzTxRfNo.equals(other.bzTxRfNo))
			return false;
		if (vcrecId == null) {
			if (other.vcrecId != null)
				return false;
		} else if (!vcrecId.equals(other.vcrecId))
			return false;
		if (cnslNo == null) {
			if (other.cnslNo != null)
				return false;
		} else if (!cnslNo.equals(other.cnslNo))
			return false;
		if (delYn == null) {
			if (other.delYn != null)
				return false;
		} else if (!delYn.equals(other.delYn))
			return false;
		if (lastChgDtm == null) {
			if (other.lastChgDtm != null)
				return false;
		} else if (!lastChgDtm.equals(other.lastChgDtm))
			return false;
		if (lastChgrId == null) {
			if (other.lastChgrId != null)
				return false;
		} else if (!lastChgrId.equals(other.lastChgrId))
			return false;
		if (lastChgPgmId == null) {
			if (other.lastChgPgmId != null)
				return false;
		} else if (!lastChgPgmId.equals(other.lastChgPgmId))
			return false;
		if (lastChgTrmNo == null) {
			if (other.lastChgTrmNo != null)
				return false;
		} else if (!lastChgTrmNo.equals(other.lastChgTrmNo))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("VcrecDlngInfo[\n");
		sb.append("	vcrecPrcsMgntNo(녹취처리관리번호) = " + vcrecPrcsMgntNo);
		sb.append("\n");
		sb.append("	vcrecSysCd(녹취시스템코드) = " + vcrecSysCd);
		sb.append("\n");
		sb.append("	bzTxRfDcd(업무거래참조구분코드) = " + bzTxRfDcd);
		sb.append("\n");
		sb.append("	bzTxRfDtlDcd(업무거래참조상세구분코드) = " + bzTxRfDtlDcd);
		sb.append("\n");
		sb.append("	bzTxRfNo(업무거래참조번호) = " + bzTxRfNo);
		sb.append("\n");
		sb.append("	vcrecId(녹취ID) = " + vcrecId);
		sb.append("\n");
		sb.append("	cnslNo(상담번호) = " + cnslNo);
		sb.append("\n");
		sb.append("	delYn(삭제여부) = " + delYn);
		sb.append("\n");
		sb.append("	lastChgDtm(최종변경일시) = " + lastChgDtm);
		sb.append("\n");
		sb.append("	lastChgrId(최종변경자ID) = " + lastChgrId);
		sb.append("\n");
		sb.append("	lastChgPgmId(최종변경프로그램ID) = " + lastChgPgmId);
		sb.append("\n");
		sb.append("	lastChgTrmNo(최종변경단말번호) = " + lastChgTrmNo);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
