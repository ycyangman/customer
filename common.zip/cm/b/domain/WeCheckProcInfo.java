/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Tue Dec 06 18:23:04 KST 2016
 * 
 */
package cigna.cm.b.domain;

import java.io.Serializable;

/**
 * @DataObjectName WeCheckProcInfo
 * @Description 
 */
public class WeCheckProcInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 867185706L;
	/**
	 * @Type java.lang.String
	 * @Name sendDt
	 * @Description 전송일자
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String sendDt;
	/**
	 * @Type java.lang.String
	 * @Name sendTm
	 * @Description 전송일간
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String sendTm;
	/**
	 * @Type java.lang.String
	 * @Name respCd
	 * @Description 응답코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String respCd;
	/**
	 * @Type java.lang.String
	 * @Name trSeq
	 * @Description 거래고유번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String trSeq;
	/**
	 * @Type java.lang.String
	 * @Name bankCd
	 * @Description 기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bankCd;
	/**
	 * @Type java.lang.String
	 * @Name name
	 * @Description 성명
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String name;
	/**
	 * @Type java.lang.String
	 * @Name regNo
	 * @Description 주민등록번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String regNo;
	/**
	 * @Type java.lang.String
	 * @Name driveNo
	 * @Description 면허번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String driveNo;
	/**
	 * @Type java.lang.String
	 * @Name secureNo
	 * @Description 암호일련번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String secureNo;
	/**
	 * @Type java.lang.String
	 * @Name issueDate
	 * @Description 발급일자
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String issueDate;
	/**
	 * @Type java.lang.String
	 * @Name resAgreement
	 * @Description 진위여부(응답)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String resAgreement;
	/**
	 * @Type java.lang.String
	 * @Name resName
	 * @Description 성명(응답)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String resName;
	/**
	 * @Type java.lang.String
	 * @Name resRegNo
	 * @Description 주민등록번호(응답)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String resRegNo;
	/**
	 * @Type java.lang.String
	 * @Name resDriveNo
	 * @Description 면허번호(응답)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String resDriveNo;
	/**
	 * @Type java.lang.String
	 * @Name resSearchDate
	 * @Description 조회일시(응답)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String resSearchDate;
	/**
	 * @Type java.lang.String
	 * @Name resIssueDate
	 * @Description 발급일자(응답)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String resIssueDate;
	/**
	 * @Type java.lang.String
	 * @Name resDisagreementReason
	 * @Description 불일치사유(응답)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String resDisagreementReason;
	
	/**
	 * @Type java.lang.String
	 * @Name answMsg
	 * @Description 응답메시지
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String answMsg;

	public java.lang.String getSendDt() {
		return sendDt;
	}

	public void setSendDt(java.lang.String sendDt) {
		this.sendDt = sendDt;
	}

	public java.lang.String getSendTm() {
		return sendTm;
	}

	public void setSendTm(java.lang.String sendTm) {
		this.sendTm = sendTm;
	}

	public java.lang.String getRespCd() {
		return respCd;
	}

	public void setRespCd(java.lang.String respCd) {
		this.respCd = respCd;
	}

	public java.lang.String getTrSeq() {
		return trSeq;
	}

	public void setTrSeq(java.lang.String trSeq) {
		this.trSeq = trSeq;
	}

	public java.lang.String getBankCd() {
		return bankCd;
	}

	public void setBankCd(java.lang.String bankCd) {
		this.bankCd = bankCd;
	}

	public java.lang.String getName() {
		return name;
	}

	public void setName(java.lang.String name) {
		this.name = name;
	}

	public java.lang.String getRegNo() {
		return regNo;
	}

	public void setRegNo(java.lang.String regNo) {
		this.regNo = regNo;
	}

	public java.lang.String getDriveNo() {
		return driveNo;
	}

	public void setDriveNo(java.lang.String driveNo) {
		this.driveNo = driveNo;
	}

	public java.lang.String getSecureNo() {
		return secureNo;
	}

	public void setSecureNo(java.lang.String secureNo) {
		this.secureNo = secureNo;
	}

	public java.lang.String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(java.lang.String issueDate) {
		this.issueDate = issueDate;
	}

	public java.lang.String getResAgreement() {
		return resAgreement;
	}

	public void setResAgreement(java.lang.String resAgreement) {
		this.resAgreement = resAgreement;
	}

	public java.lang.String getResName() {
		return resName;
	}

	public void setResName(java.lang.String resName) {
		this.resName = resName;
	}

	public java.lang.String getResRegNo() {
		return resRegNo;
	}

	public void setResRegNo(java.lang.String resRegNo) {
		this.resRegNo = resRegNo;
	}

	public java.lang.String getResDriveNo() {
		return resDriveNo;
	}

	public void setResDriveNo(java.lang.String resDriveNo) {
		this.resDriveNo = resDriveNo;
	}

	public java.lang.String getResSearchDate() {
		return resSearchDate;
	}

	public void setResSearchDate(java.lang.String resSearchDate) {
		this.resSearchDate = resSearchDate;
	}

	public java.lang.String getResIssueDate() {
		return resIssueDate;
	}

	public void setResIssueDate(java.lang.String resIssueDate) {
		this.resIssueDate = resIssueDate;
	}

	public java.lang.String getResDisagreementReason() {
		return resDisagreementReason;
	}

	public void setResDisagreementReason(java.lang.String resDisagreementReason) {
		this.resDisagreementReason = resDisagreementReason;
	}

	public java.lang.String getAnswMsg() {
		return answMsg;
	}

	public void setAnswMsg(java.lang.String answMsg) {
		this.answMsg = answMsg;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((answMsg == null) ? 0 : answMsg.hashCode());
		result = prime * result + ((bankCd == null) ? 0 : bankCd.hashCode());
		result = prime * result + ((driveNo == null) ? 0 : driveNo.hashCode());
		result = prime * result
				+ ((issueDate == null) ? 0 : issueDate.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((regNo == null) ? 0 : regNo.hashCode());
		result = prime * result
				+ ((resAgreement == null) ? 0 : resAgreement.hashCode());
		result = prime
				* result
				+ ((resDisagreementReason == null) ? 0 : resDisagreementReason
						.hashCode());
		result = prime * result
				+ ((resDriveNo == null) ? 0 : resDriveNo.hashCode());
		result = prime * result
				+ ((resIssueDate == null) ? 0 : resIssueDate.hashCode());
		result = prime * result + ((resName == null) ? 0 : resName.hashCode());
		result = prime * result
				+ ((resRegNo == null) ? 0 : resRegNo.hashCode());
		result = prime * result
				+ ((resSearchDate == null) ? 0 : resSearchDate.hashCode());
		result = prime * result + ((respCd == null) ? 0 : respCd.hashCode());
		result = prime * result
				+ ((secureNo == null) ? 0 : secureNo.hashCode());
		result = prime * result + ((sendDt == null) ? 0 : sendDt.hashCode());
		result = prime * result + ((sendTm == null) ? 0 : sendTm.hashCode());
		result = prime * result + ((trSeq == null) ? 0 : trSeq.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WeCheckProcInfo other = (WeCheckProcInfo) obj;
		if (answMsg == null) {
			if (other.answMsg != null)
				return false;
		} else if (!answMsg.equals(other.answMsg))
			return false;
		if (bankCd == null) {
			if (other.bankCd != null)
				return false;
		} else if (!bankCd.equals(other.bankCd))
			return false;
		if (driveNo == null) {
			if (other.driveNo != null)
				return false;
		} else if (!driveNo.equals(other.driveNo))
			return false;
		if (issueDate == null) {
			if (other.issueDate != null)
				return false;
		} else if (!issueDate.equals(other.issueDate))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (regNo == null) {
			if (other.regNo != null)
				return false;
		} else if (!regNo.equals(other.regNo))
			return false;
		if (resAgreement == null) {
			if (other.resAgreement != null)
				return false;
		} else if (!resAgreement.equals(other.resAgreement))
			return false;
		if (resDisagreementReason == null) {
			if (other.resDisagreementReason != null)
				return false;
		} else if (!resDisagreementReason.equals(other.resDisagreementReason))
			return false;
		if (resDriveNo == null) {
			if (other.resDriveNo != null)
				return false;
		} else if (!resDriveNo.equals(other.resDriveNo))
			return false;
		if (resIssueDate == null) {
			if (other.resIssueDate != null)
				return false;
		} else if (!resIssueDate.equals(other.resIssueDate))
			return false;
		if (resName == null) {
			if (other.resName != null)
				return false;
		} else if (!resName.equals(other.resName))
			return false;
		if (resRegNo == null) {
			if (other.resRegNo != null)
				return false;
		} else if (!resRegNo.equals(other.resRegNo))
			return false;
		if (resSearchDate == null) {
			if (other.resSearchDate != null)
				return false;
		} else if (!resSearchDate.equals(other.resSearchDate))
			return false;
		if (respCd == null) {
			if (other.respCd != null)
				return false;
		} else if (!respCd.equals(other.respCd))
			return false;
		if (secureNo == null) {
			if (other.secureNo != null)
				return false;
		} else if (!secureNo.equals(other.secureNo))
			return false;
		if (sendDt == null) {
			if (other.sendDt != null)
				return false;
		} else if (!sendDt.equals(other.sendDt))
			return false;
		if (sendTm == null) {
			if (other.sendTm != null)
				return false;
		} else if (!sendTm.equals(other.sendTm))
			return false;
		if (trSeq == null) {
			if (other.trSeq != null)
				return false;
		} else if (!trSeq.equals(other.trSeq))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("WeCheckProcInfo [\n  sendDt: ");
		builder.append(sendDt);
		builder.append("\n  sendTm: ");
		builder.append(sendTm);
		builder.append("\n  respCd: ");
		builder.append(respCd);
		builder.append("\n  trSeq: ");
		builder.append(trSeq);
		builder.append("\n  bankCd: ");
		builder.append(bankCd);
		builder.append("\n  name: ");
		builder.append(name);
		builder.append("\n  regNo: ");
		builder.append(regNo);
		builder.append("\n  driveNo: ");
		builder.append(driveNo);
		builder.append("\n  secureNo: ");
		builder.append(secureNo);
		builder.append("\n  issueDate: ");
		builder.append(issueDate);
		builder.append("\n  resAgreement: ");
		builder.append(resAgreement);
		builder.append("\n  resName: ");
		builder.append(resName);
		builder.append("\n  resRegNo: ");
		builder.append(resRegNo);
		builder.append("\n  resDriveNo: ");
		builder.append(resDriveNo);
		builder.append("\n  resSearchDate: ");
		builder.append(resSearchDate);
		builder.append("\n  resIssueDate: ");
		builder.append(resIssueDate);
		builder.append("\n  resDisagreementReason: ");
		builder.append(resDisagreementReason);
		builder.append("\n  answMsg: ");
		builder.append(answMsg);
		builder.append("\n]");
		return builder.toString();
	}
	
	

}
