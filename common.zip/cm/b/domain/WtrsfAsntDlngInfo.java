/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Tue Nov 13 15:00:50 KST 2012
 * 
 */
package cigna.cm.b.domain;

import java.io.Serializable;

/**
 * @DataObjectName TrsfTrrvPrcsInfo
 * @Description 
 */
public class WtrsfAsntDlngInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = -1201219437L;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntDt
	 * @Description 출금이체동의일자
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntDt;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntTi
	 * @Description 출금이체동의시각
	 * @Length 4
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntTi;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntSysCd
	 * @Description 출금이체동의시스템코드
	 * @Length 8
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntSysCd;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntEvidDcd
	 * @Description 출금이체동의증빙구분코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntEvidDcd;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntEvidNo
	 * @Description 출금이체동의증빙번호
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntEvidNo;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntDcd
	 * @Description 출금이체동의구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntDcd;
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntRcDcd
	 * @Description 출금이체동의접수구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntRcDcd;
	/**
	 * @Type java.lang.String
	 * @Name contNo
	 * @Description 계약번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String contNo;
	/**
	 * @Type java.lang.String
	 * @Name pmpsNo
	 * @Description 납부자번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String pmpsNo;
	/**
	 * @Type java.lang.String
	 * @Name contrNm
	 * @Description 계약자명
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String contrNm;
	/**
	 * @Type java.lang.String
	 * @Name pmpsDscNo
	 * @Description 납부자식별번호
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String pmpsDscNo;
	/**
	 * @Type java.lang.String
	 * @Name pmpsNm
	 * @Description 납부자명
	 * @Length 3
	 * @Decimal 0
	 */
	private java.lang.String pmpsNm;
	/**
	 * @Type java.lang.String
	 * @Name fininCd
	 * @Description 금융기관코드
	 * @Length 20
	 * @Decimal 0
	 */
	private java.lang.String fininCd;
	/**
	 * @Type java.lang.String
	 * @Name pmpsActNo
	 * @Description 납부자계좌번호
	 * @Length 40
	 * @Decimal 0
	 */
	private java.lang.String pmpsActNo;
	/**
	 * @Type java.math.BigDecimal
	 * @Name trsfAmt
	 * @Description 이체금액
	 * @Length 15
	 * @Decimal 0
	 */
	private java.math.BigDecimal trsfAmt;
	/**
	 * @Type java.lang.String
	 * @Name bzTxRfDcd
	 * @Description 업무거래참조구분코드
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String bzTxRfDcd;
	
	/**
	 * @Type java.lang.String
	 * @Name bzTxRfNo
	 * @Description 업무거래참조번호
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String bzTxRfNo;
	
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntVcrecStrtDtm
	 * @Description 출금이체동의녹취시작일시
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntVcrecStrtDtm;
	
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntVcrecEndDtm
	 * @Description 출금이체동의녹취종료일시
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntVcrecEndDtm;
	
	/**
	 * @Type java.lang.String
	 * @Name centrNm
	 * @Description 센터명
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String centrNm;
	
	/**
	 * @Type java.lang.String
	 * @Name teamNm
	 * @Description 팀명
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String teamNm;
	
	/**
	 * @Type java.lang.String
	 * @Name chrgpEno
	 * @Description 담당자사원번호
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String chrgpEno;
	
	/**
	 * @Type java.lang.String
	 * @Name chrgpNm
	 * @Description 담당자사원명
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String chrgpNm;
	
	/**
	 * @Type java.lang.String
	 * @Name wtrsfAsntNrmYn
	 * @Description 출금이체동의정상여부
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String wtrsfAsntNrmYn;

	public java.lang.String getWtrsfAsntDt() {
		return wtrsfAsntDt;
	}

	public void setWtrsfAsntDt(java.lang.String wtrsfAsntDt) {
		this.wtrsfAsntDt = wtrsfAsntDt;
	}

	public java.lang.String getWtrsfAsntTi() {
		return wtrsfAsntTi;
	}

	public void setWtrsfAsntTi(java.lang.String wtrsfAsntTi) {
		this.wtrsfAsntTi = wtrsfAsntTi;
	}

	public java.lang.String getWtrsfAsntSysCd() {
		return wtrsfAsntSysCd;
	}

	public void setWtrsfAsntSysCd(java.lang.String wtrsfAsntSysCd) {
		this.wtrsfAsntSysCd = wtrsfAsntSysCd;
	}

	public java.lang.String getWtrsfAsntEvidDcd() {
		return wtrsfAsntEvidDcd;
	}

	public void setWtrsfAsntEvidDcd(java.lang.String wtrsfAsntEvidDcd) {
		this.wtrsfAsntEvidDcd = wtrsfAsntEvidDcd;
	}

	public java.lang.String getWtrsfAsntEvidNo() {
		return wtrsfAsntEvidNo;
	}

	public void setWtrsfAsntEvidNo(java.lang.String wtrsfAsntEvidNo) {
		this.wtrsfAsntEvidNo = wtrsfAsntEvidNo;
	}

	public java.lang.String getWtrsfAsntDcd() {
		return wtrsfAsntDcd;
	}

	public void setWtrsfAsntDcd(java.lang.String wtrsfAsntDcd) {
		this.wtrsfAsntDcd = wtrsfAsntDcd;
	}

	public java.lang.String getWtrsfAsntRcDcd() {
		return wtrsfAsntRcDcd;
	}

	public void setWtrsfAsntRcDcd(java.lang.String wtrsfAsntRcDcd) {
		this.wtrsfAsntRcDcd = wtrsfAsntRcDcd;
	}

	public java.lang.String getContNo() {
		return contNo;
	}

	public void setContNo(java.lang.String contNo) {
		this.contNo = contNo;
	}

	public java.lang.String getPmpsNo() {
		return pmpsNo;
	}

	public void setPmpsNo(java.lang.String pmpsNo) {
		this.pmpsNo = pmpsNo;
	}

	public java.lang.String getContrNm() {
		return contrNm;
	}

	public void setContrNm(java.lang.String contrNm) {
		this.contrNm = contrNm;
	}

	public java.lang.String getPmpsDscNo() {
		return pmpsDscNo;
	}

	public void setPmpsDscNo(java.lang.String pmpsDscNo) {
		this.pmpsDscNo = pmpsDscNo;
	}

	public java.lang.String getPmpsNm() {
		return pmpsNm;
	}

	public void setPmpsNm(java.lang.String pmpsNm) {
		this.pmpsNm = pmpsNm;
	}

	public java.lang.String getFininCd() {
		return fininCd;
	}

	public void setFininCd(java.lang.String fininCd) {
		this.fininCd = fininCd;
	}

	public java.lang.String getPmpsActNo() {
		return pmpsActNo;
	}

	public void setPmpsActNo(java.lang.String pmpsActNo) {
		this.pmpsActNo = pmpsActNo;
	}

	public java.math.BigDecimal getTrsfAmt() {
		return trsfAmt;
	}

	public void setTrsfAmt(java.math.BigDecimal trsfAmt) {
		this.trsfAmt = trsfAmt;
	}

	public java.lang.String getBzTxRfDcd() {
		return bzTxRfDcd;
	}

	public void setBzTxRfDcd(java.lang.String bzTxRfDcd) {
		this.bzTxRfDcd = bzTxRfDcd;
	}

	public java.lang.String getBzTxRfNo() {
		return bzTxRfNo;
	}

	public void setBzTxRfNo(java.lang.String bzTxRfNo) {
		this.bzTxRfNo = bzTxRfNo;
	}

	public java.lang.String getWtrsfAsntVcrecStrtDtm() {
		return wtrsfAsntVcrecStrtDtm;
	}

	public void setWtrsfAsntVcrecStrtDtm(java.lang.String wtrsfAsntVcrecStrtDtm) {
		this.wtrsfAsntVcrecStrtDtm = wtrsfAsntVcrecStrtDtm;
	}

	public java.lang.String getWtrsfAsntVcrecEndDtm() {
		return wtrsfAsntVcrecEndDtm;
	}

	public void setWtrsfAsntVcrecEndDtm(java.lang.String wtrsfAsntVcrecEndDtm) {
		this.wtrsfAsntVcrecEndDtm = wtrsfAsntVcrecEndDtm;
	}

	public java.lang.String getCentrNm() {
		return centrNm;
	}

	public void setCentrNm(java.lang.String centrNm) {
		this.centrNm = centrNm;
	}

	public java.lang.String getTeamNm() {
		return teamNm;
	}

	public void setTeamNm(java.lang.String teamNm) {
		this.teamNm = teamNm;
	}

	public java.lang.String getChrgpEno() {
		return chrgpEno;
	}

	public void setChrgpEno(java.lang.String chrgpEno) {
		this.chrgpEno = chrgpEno;
	}

	public java.lang.String getChrgpNm() {
		return chrgpNm;
	}

	public void setChrgpNm(java.lang.String chrgpNm) {
		this.chrgpNm = chrgpNm;
	}

	public java.lang.String getWtrsfAsntNrmYn() {
		return wtrsfAsntNrmYn;
	}

	public void setWtrsfAsntNrmYn(java.lang.String wtrsfAsntNrmYn) {
		this.wtrsfAsntNrmYn = wtrsfAsntNrmYn;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((bzTxRfDcd == null) ? 0 : bzTxRfDcd.hashCode());
		result = prime * result
				+ ((bzTxRfNo == null) ? 0 : bzTxRfNo.hashCode());
		result = prime * result + ((centrNm == null) ? 0 : centrNm.hashCode());
		result = prime * result
				+ ((chrgpEno == null) ? 0 : chrgpEno.hashCode());
		result = prime * result + ((chrgpNm == null) ? 0 : chrgpNm.hashCode());
		result = prime * result + ((contNo == null) ? 0 : contNo.hashCode());
		result = prime * result + ((contrNm == null) ? 0 : contrNm.hashCode());
		result = prime * result + ((fininCd == null) ? 0 : fininCd.hashCode());
		result = prime * result
				+ ((pmpsActNo == null) ? 0 : pmpsActNo.hashCode());
		result = prime * result
				+ ((pmpsDscNo == null) ? 0 : pmpsDscNo.hashCode());
		result = prime * result + ((pmpsNm == null) ? 0 : pmpsNm.hashCode());
		result = prime * result + ((pmpsNo == null) ? 0 : pmpsNo.hashCode());
		result = prime * result + ((teamNm == null) ? 0 : teamNm.hashCode());
		result = prime * result + ((trsfAmt == null) ? 0 : trsfAmt.hashCode());
		result = prime * result
				+ ((wtrsfAsntDcd == null) ? 0 : wtrsfAsntDcd.hashCode());
		result = prime * result
				+ ((wtrsfAsntDt == null) ? 0 : wtrsfAsntDt.hashCode());
		result = prime
				* result
				+ ((wtrsfAsntEvidDcd == null) ? 0 : wtrsfAsntEvidDcd.hashCode());
		result = prime * result
				+ ((wtrsfAsntEvidNo == null) ? 0 : wtrsfAsntEvidNo.hashCode());
		result = prime * result
				+ ((wtrsfAsntNrmYn == null) ? 0 : wtrsfAsntNrmYn.hashCode());
		result = prime * result
				+ ((wtrsfAsntRcDcd == null) ? 0 : wtrsfAsntRcDcd.hashCode());
		result = prime * result
				+ ((wtrsfAsntSysCd == null) ? 0 : wtrsfAsntSysCd.hashCode());
		result = prime * result
				+ ((wtrsfAsntTi == null) ? 0 : wtrsfAsntTi.hashCode());
		result = prime
				* result
				+ ((wtrsfAsntVcrecEndDtm == null) ? 0 : wtrsfAsntVcrecEndDtm
						.hashCode());
		result = prime
				* result
				+ ((wtrsfAsntVcrecStrtDtm == null) ? 0 : wtrsfAsntVcrecStrtDtm
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WtrsfAsntDlngInfo other = (WtrsfAsntDlngInfo) obj;
		if (bzTxRfDcd == null) {
			if (other.bzTxRfDcd != null)
				return false;
		} else if (!bzTxRfDcd.equals(other.bzTxRfDcd))
			return false;
		if (bzTxRfNo == null) {
			if (other.bzTxRfNo != null)
				return false;
		} else if (!bzTxRfNo.equals(other.bzTxRfNo))
			return false;
		if (centrNm == null) {
			if (other.centrNm != null)
				return false;
		} else if (!centrNm.equals(other.centrNm))
			return false;
		if (chrgpEno == null) {
			if (other.chrgpEno != null)
				return false;
		} else if (!chrgpEno.equals(other.chrgpEno))
			return false;
		if (chrgpNm == null) {
			if (other.chrgpNm != null)
				return false;
		} else if (!chrgpNm.equals(other.chrgpNm))
			return false;
		if (contNo == null) {
			if (other.contNo != null)
				return false;
		} else if (!contNo.equals(other.contNo))
			return false;
		if (contrNm == null) {
			if (other.contrNm != null)
				return false;
		} else if (!contrNm.equals(other.contrNm))
			return false;
		if (fininCd == null) {
			if (other.fininCd != null)
				return false;
		} else if (!fininCd.equals(other.fininCd))
			return false;
		if (pmpsActNo == null) {
			if (other.pmpsActNo != null)
				return false;
		} else if (!pmpsActNo.equals(other.pmpsActNo))
			return false;
		if (pmpsDscNo == null) {
			if (other.pmpsDscNo != null)
				return false;
		} else if (!pmpsDscNo.equals(other.pmpsDscNo))
			return false;
		if (pmpsNm == null) {
			if (other.pmpsNm != null)
				return false;
		} else if (!pmpsNm.equals(other.pmpsNm))
			return false;
		if (pmpsNo == null) {
			if (other.pmpsNo != null)
				return false;
		} else if (!pmpsNo.equals(other.pmpsNo))
			return false;
		if (teamNm == null) {
			if (other.teamNm != null)
				return false;
		} else if (!teamNm.equals(other.teamNm))
			return false;
		if (trsfAmt == null) {
			if (other.trsfAmt != null)
				return false;
		} else if (!trsfAmt.equals(other.trsfAmt))
			return false;
		if (wtrsfAsntDcd == null) {
			if (other.wtrsfAsntDcd != null)
				return false;
		} else if (!wtrsfAsntDcd.equals(other.wtrsfAsntDcd))
			return false;
		if (wtrsfAsntDt == null) {
			if (other.wtrsfAsntDt != null)
				return false;
		} else if (!wtrsfAsntDt.equals(other.wtrsfAsntDt))
			return false;
		if (wtrsfAsntEvidDcd == null) {
			if (other.wtrsfAsntEvidDcd != null)
				return false;
		} else if (!wtrsfAsntEvidDcd.equals(other.wtrsfAsntEvidDcd))
			return false;
		if (wtrsfAsntEvidNo == null) {
			if (other.wtrsfAsntEvidNo != null)
				return false;
		} else if (!wtrsfAsntEvidNo.equals(other.wtrsfAsntEvidNo))
			return false;
		if (wtrsfAsntNrmYn == null) {
			if (other.wtrsfAsntNrmYn != null)
				return false;
		} else if (!wtrsfAsntNrmYn.equals(other.wtrsfAsntNrmYn))
			return false;
		if (wtrsfAsntRcDcd == null) {
			if (other.wtrsfAsntRcDcd != null)
				return false;
		} else if (!wtrsfAsntRcDcd.equals(other.wtrsfAsntRcDcd))
			return false;
		if (wtrsfAsntSysCd == null) {
			if (other.wtrsfAsntSysCd != null)
				return false;
		} else if (!wtrsfAsntSysCd.equals(other.wtrsfAsntSysCd))
			return false;
		if (wtrsfAsntTi == null) {
			if (other.wtrsfAsntTi != null)
				return false;
		} else if (!wtrsfAsntTi.equals(other.wtrsfAsntTi))
			return false;
		if (wtrsfAsntVcrecEndDtm == null) {
			if (other.wtrsfAsntVcrecEndDtm != null)
				return false;
		} else if (!wtrsfAsntVcrecEndDtm.equals(other.wtrsfAsntVcrecEndDtm))
			return false;
		if (wtrsfAsntVcrecStrtDtm == null) {
			if (other.wtrsfAsntVcrecStrtDtm != null)
				return false;
		} else if (!wtrsfAsntVcrecStrtDtm.equals(other.wtrsfAsntVcrecStrtDtm))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("WtrsfAsntDlngInfo [\n  wtrsfAsntDt: ");
		builder.append(wtrsfAsntDt);
		builder.append("\n  wtrsfAsntTi: ");
		builder.append(wtrsfAsntTi);
		builder.append("\n  wtrsfAsntSysCd: ");
		builder.append(wtrsfAsntSysCd);
		builder.append("\n  wtrsfAsntEvidDcd: ");
		builder.append(wtrsfAsntEvidDcd);
		builder.append("\n  wtrsfAsntEvidNo: ");
		builder.append(wtrsfAsntEvidNo);
		builder.append("\n  wtrsfAsntDcd: ");
		builder.append(wtrsfAsntDcd);
		builder.append("\n  wtrsfAsntRcDcd: ");
		builder.append(wtrsfAsntRcDcd);
		builder.append("\n  contNo: ");
		builder.append(contNo);
		builder.append("\n  pmpsNo: ");
		builder.append(pmpsNo);
		builder.append("\n  contrNm: ");
		builder.append(contrNm);
		builder.append("\n  pmpsDscNo: ");
		builder.append(pmpsDscNo);
		builder.append("\n  pmpsNm: ");
		builder.append(pmpsNm);
		builder.append("\n  fininCd: ");
		builder.append(fininCd);
		builder.append("\n  pmpsActNo: ");
		builder.append(pmpsActNo);
		builder.append("\n  trsfAmt: ");
		builder.append(trsfAmt);
		builder.append("\n  bzTxRfDcd: ");
		builder.append(bzTxRfDcd);
		builder.append("\n  bzTxRfNo: ");
		builder.append(bzTxRfNo);
		builder.append("\n  wtrsfAsntVcrecStrtDtm: ");
		builder.append(wtrsfAsntVcrecStrtDtm);
		builder.append("\n  wtrsfAsntVcrecEndDtm: ");
		builder.append(wtrsfAsntVcrecEndDtm);
		builder.append("\n  centrNm: ");
		builder.append(centrNm);
		builder.append("\n  teamNm: ");
		builder.append(teamNm);
		builder.append("\n  chrgpEno: ");
		builder.append(chrgpEno);
		builder.append("\n  chrgpNm: ");
		builder.append(chrgpNm);
		builder.append("\n  wtrsfAsntNrmYn: ");
		builder.append(wtrsfAsntNrmYn);
		builder.append("\n]");
		return builder.toString();
	}
	

}
