package cigna.cm.b.service;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CALLEAIBEAN;
import cigna.cm.b.io.COR_E_EAIOS000000001;


/**
 * @file         cigna.cm.b.service.CALLEAISVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2016. 2. 5.       신규 작성
 *
 */
@KlafService("CALLEAISVC")
public class CALLEAISVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CALLEAIBEAN callEaiBean;
	
	@KlafServiceOperation("selectList0")
	public void selectList0(COR_E_EAIOS000000001 input) throws ApplicationException {
		logger.debug("=============  Start");
		
		callEaiBean.callEai(input);
		
		// TODO: 업무에 맞게 정상 처리 메시지코드와  값은 설정해주세요.
		LApplicationContext.addMessage("KIOKI0009", null, null);
	}
}

