package cigna.cm.b.service;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CALLFEPBEAN;
import cigna.cm.b.io.COM_F_KSNOSKSPO00004In;


/**
 * @file         cigna.cm.b.service.CALLFEPSVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2016. 2. 11.       신규 작성
 *
 */
@KlafService("CALLFEPSVC")
public class CALLFEPSVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CALLFEPBEAN callFepBean;
	
	@KlafServiceOperation("selectList0")
	public void selectList0(COM_F_KSNOSKSPO00004In input) throws ApplicationException {
		logger.debug("=============  Start");
		
		callFepBean.callFep(input);
		
		// TODO: 업무에 맞게 정상 처리 메시지코드와  값은 설정해주세요.
		LApplicationContext.addMessage("KIOKI0009", null, null);
	}
	
	/**
	 * 자동집금처리 호출(입금,집금)_KS-NET - 처리코드(02)
	 * 
	 * @param input 자동집금처리 호출(입금,집금) OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate12")
	@TransactionalOperation
	public void changeUpdate12(COM_F_KSNOSKSPO00004In input) throws ApplicationException {
		
		callFepBean.callFep(input);

		// 정상처리 결과 메시지 : 입력하신 내용이 변경 되었습니다.
		LApplicationContext.addMessage("KIOKI0007", null, null);
	}
}

