package cigna.cm.b.service;

import klaf.app.ApplicationException;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB001BEAN;
import cigna.cm.b.bean.CMB007BEAN;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.io.CMB001SVC00In;
import cigna.cm.b.io.CMB001SVC00Out;
import cigna.cm.b.io.COM_F_KIBOAKIBO00001In;
import cigna.cm.b.io.COM_F_KSNOAKSPO00001In;


/**
 * @file         cigna.cm.b.service.CMB001SVC.java
 * @filetype     java source file
 * @brief
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈       2016. 5. 20.       신규 작성
 *
 */
@KlafService("CMB001SVC")
public class CMB001SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	//private PAX001BEAN pax001bean;
	private CMB001BEAN cmb001bean;
	
	@Autowired
	//private PAX001BEAN pax001bean;
	private CMB007BEAN cmb007bean;
	
	/**
     * 은행별 이체처리(대외계)
     * @param contrCustNo
     * @param actMgntNo
     * @return
     * @throws ApplicationException
     */
	@KlafServiceOperation("changeInsert0")
    public CMB001SVC00Out changeInsert0(CMB001SVC00In input)  throws ApplicationException
    {
    	String answCd = "";
    	
    	logger.info("★★★★★★★★CBM001 SVC  input [{}]", input);
    	
    	TrsfTrrvPrcsInfo trsftrrvprcsinfo = new TrsfTrrvPrcsInfo();
    	
    	CMB001SVC00Out out = null;
    	
    	trsftrrvprcsinfo.setPrcsCd(             input.getPrcsCd(             ));
    	trsftrrvprcsinfo.setChnlDcd(            input.getChnlDcd(            ));
    	trsftrrvprcsinfo.setPrcsDt(             input.getPrcsDt(             ));
    	trsftrrvprcsinfo.setPayRcPathCd(        input.getPayRcPathCd(        ));
    	trsftrrvprcsinfo.setPayRcMcd(           input.getPayRcMcd(           ));
    	trsftrrvprcsinfo.setPyprcPathCd(        input.getPyprcPathCd(        ));
    	trsftrrvprcsinfo.setTrsfAmt(            input.getTrsfAmt(            ));
    	trsftrrvprcsinfo.setBenfcCustNo(        input.getBenfcCustNo(        ));
    	trsftrrvprcsinfo.setContrCustNo(        input.getContrCustNo(        ));
    	trsftrrvprcsinfo.setDpwdDcd(            input.getDpwdDcd(            ));
    	trsftrrvprcsinfo.setActMgntNo(          input.getActMgntNo(          ));
    	trsftrrvprcsinfo.setBnkCd(              input.getBnkCd(              ));
    	trsftrrvprcsinfo.setActNo(              input.getActNo(              ));
    	trsftrrvprcsinfo.setAchdNm(             input.getAchdNm(             ));
    	trsftrrvprcsinfo.setAchdRrno(           input.getAchdRrno(           ));
    	trsftrrvprcsinfo.setNrmCnclDcd(         input.getNrmCnclDcd(         ));
    	trsftrrvprcsinfo.setBzDcd(              input.getBzDcd(              ));
    	trsftrrvprcsinfo.setBzTmKeyVl(          input.getBzTmKeyVl(          ));
    	trsftrrvprcsinfo.setReqBzTmBean(        input.getReqBzTmBean(        ));
    	trsftrrvprcsinfo.setReqBzTmMethod(      input.getReqBzTmMethod(      ));
    	trsftrrvprcsinfo.setPrcsBnkCd(          input.getPrcsBnkCd(          ));
    	trsftrrvprcsinfo.setTrmsDcd(            input.getTrmsDcd(            ));
    	trsftrrvprcsinfo.setPrcsHms(            input.getPrcsHms(            ));
    	trsftrrvprcsinfo.setRltmTrsfTxNo(       input.getRltmTrsfTxNo(       ));
    	trsftrrvprcsinfo.setOptnKey(            input.getOptnKey(            ));
    	trsftrrvprcsinfo.setPyrcDofOrgNo(       input.getPyrcDofOrgNo(       ));
    	trsftrrvprcsinfo.setPyrcFofOrgNo(       input.getPyrcFofOrgNo(       ));
    	trsftrrvprcsinfo.setPyrcPrcsEno(        input.getPyrcPrcsEno(        ));
    	
    	logger.info("★★★★★★★★CBM001 SVC trsftrrvprcsinfo  [{}]", trsftrrvprcsinfo);

    	trsftrrvprcsinfo = cmb001bean.callTgmTrrv(trsftrrvprcsinfo);
    	
    	
    	logger.info("★★★★★★★★CBM001 SVC trsftrrvprcsinfo  [{}]", trsftrrvprcsinfo);

    	answCd = trsftrrvprcsinfo.getBnkAnswCd();   //응답코드
       
    	out.setAnswCd(answCd);
//    	logger.info("★★★★★★★★ 응답코드 [{}]", trsftrrvprcsinfo);

    	return  out;
    }
	
	/**
     * 은행별 업무개시(대외계)
     * @param contrCustNo
     * @param actMgntNo
     * @return
     * @throws ApplicationException
     */
	@KlafServiceOperation("changeInsert1")
    public void changeInsert1(COM_F_KSNOAKSPO00001In input)  throws ApplicationException
    {	
    	if(RTCont.FININCD_027.equals(input.getBnkCd3()) || RTCont.FININCD_045.equals(input.getBnkCd3()) || 
				RTCont.FININCD_071.equals(input.getBnkCd3()) ){
    		if ("A".equals(input.getDscCd()))
    		{
    			if ("A3".equals(input.getBzDvsnCd()))
    			{
    				cmb007bean.trsfKsnetBzStartA1(input.getBnkCd3(), "A3", input.getBnkTgmNo());
    			}
    			else
    			{
    				cmb007bean.trsfKsnetBzStartA1(input.getBnkCd3(), "A1", input.getBnkTgmNo());
    			}
    		}
    		else
    		{
    			if ("A3".equals(input.getBzDvsnCd()))
    			{
    				cmb007bean.trsfKsnetBzStartA1Sync(input.getBnkCd3(), "A3", input.getBnkTgmNo());
    			}
    			else
    			{
    				cmb007bean.trsfKsnetBzStartA1Sync(input.getBnkCd3(), "A1", input.getBnkTgmNo());
    			}
    			
    		}
    		
    	}
    	else {
    		if ("A".equals(input.getDscCd()))
    		{
    			cmb007bean.trsfKIBnetBzStartA1(input.getBnkCd3(),  "A1", input.getBnkTgmNo());
    		}
//    		else
//    		{
//    			cmb007bean.trsfKIBnetBzStartA1Sync(input.getBnkCd3(),  "A1", input.getBnkTgmNo());
//    		}
		}
       
    }
	
	
	/**
     * 은행별 업무개시(대외계)
     * @param contrCustNo
     * @param actMgntNo
     * @return
     * @throws ApplicationException
     */
	@KlafServiceOperation("changeInsert2")
    public void changeInsert2(COM_F_KSNOAKSPO00001In input)  throws ApplicationException
    {	
    	if(RTCont.FININCD_027.equals(input.getBnkCd3()) || RTCont.FININCD_045.equals(input.getBnkCd3()) || 
				RTCont.FININCD_071.equals(input.getBnkCd3()) ){
    		cmb007bean.trsfKsnetBzStartA1Sync(input.getBnkCd3(), "A1", input.getBnkTgmNo());
    	}
//    	else {
//			cmb007bean.trsfKIBnetBzStartA1Sync(input.getBnkCd3(),  "A1", input.getBnkTgmNo());
//		}
       
    }
	
	/**
	 * 업무개시_KS-NET (TEST CALL 포함)
	 * 
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate0")
	@TransactionalOperation
	public void changeUpdate0(COM_F_KSNOAKSPO00001In input) throws ApplicationException {
		
			
		if ("0810".equals(input.getMsgCd())) {
			//if ("0000".equals(input.getAnswCdH()) || "    ".equals(input.getAnswCdH())) {   
			if ("0000".equals(input.getBnkAnswCd()) || "    ".equals(input.getBnkAnswCd())) {  // 은행 return 코드	
				cmb007bean.setBzStartTgm(input);
			}
		}
		
	}
	
	/**
	 * 업무개시_KIB-NET
	 * 
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate1")
	@TransactionalOperation
	public void changeUpdate1(COM_F_KIBOAKIBO00001In input) throws ApplicationException {
		
			
		if ("0810".equals(input.getTgmDvsnCd())) {
			//if ("0000".equals(input.getAnswCdH()) || "    ".equals(input.getAnswCdH())) {   
			if ("0000".equals(input.getBnkAnswCd()) || "    ".equals(input.getBnkAnswCd())) {  // 은행 return 코드	
				cmb007bean.setKibnetBzStartTgm(input);
			}
		}
		
	}
}

