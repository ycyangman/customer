package cigna.cm.b.service;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.inf.EisExecutionException;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.io.CMB030SVC00In;
import cigna.cm.b.io.CMB030SVC01In;
import cigna.cm.b.bean.CMB030BEAN;

import cigna.cm.b.io.STB_F_COMOSSTOA00001In;
import cigna.cm.b.io.STB_F_COMOSSTOA00002In;
import cigna.cm.b.io.STB_F_COMOSSTOA00006In;



/**
 * @file         cigna.cm.b.service.CMB030SVC.java
 * @filetype     java source file
 * @brief        가상계좌 수신처리
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                          성명                                                일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016. 2. 22.      신규 작성
 *
 */
@KlafService("CMB030SVC")
public class CMB030SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private	CMB030BEAN cmb030bean; // 가상계좌 수신처리
	
	/***************************************
	 * 가상계좌 수신처리(처리)
	 ***************************************/
	/**
	 * 가상계좌 수신처리(처리)
	 * @param  input
	 * @return output
	 * @throws ApplicationException
	 */
//	@KlafServiceOperation("changeUpdate0")
//	@TransactionalOperation
//	public STB_F_COMOSSTOA00001In changeUpdate0(STB_F_COMOSSTOA00001In input) throws ApplicationException, EisExecutionException {
//		STB_F_COMOSSTOA00001In output = null;
//
//		input.setOpenBnkCd("0" + input.getOpenBnkCd());
//		input.setHndlBnk  ("0" + input.getHndlBnk  ());
//
//		output = cmb030bean.prcsVactRcpntTgmTrrv(input);
//
//		input.setOpenBnkCd(output.getOpenBnkCd().substring(1));
//		input.setHndlBnk  (output.getHndlBnk  ().substring(1));
//
//		LApplicationContext.addMessage("KIOKI0009", null, null);
//
//		return output;
//	}
//
//	@KlafServiceOperation("changeUpdate1")
//	@TransactionalOperation
//	public STB_F_COMOSSTOA00002In changeUpdate1(STB_F_COMOSSTOA00002In input) throws ApplicationException, EisExecutionException {
//		STB_F_COMOSSTOA00002In output = null;
//		
//		input.setOpenBnkCd("0" + input.getOpenBnkCd());
//		input.setHndlBnk  ("0" + input.getHndlBnk  ());
//
//		output = cmb030bean.prcsVactTgmTrrv(input);
//
//		input.setOpenBnkCd(output.getOpenBnkCd().substring(1));
//		input.setHndlBnk  (output.getHndlBnk  ().substring(1));
//
//		LApplicationContext.addMessage("KIOKI0009", null, null);
//		
//
//
//		return output;
//	}
//	
//	@KlafServiceOperation("changeUpdate2")
//	@TransactionalOperation
//	public STB_F_COMOSSTOA00006In changeUpdate2(STB_F_COMOSSTOA00006In input) throws ApplicationException {
//		STB_F_COMOSSTOA00006In output = null;
//
//		output = cmb030bean.prcsVactTgmTrrvTot(input);
//
//		LApplicationContext.addMessage("KIOKI0009", null, null);
//
//		return output;
//	}
}

