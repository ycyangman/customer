package cigna.cm.b.service;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB050BEAN;
import cigna.cm.b.domain.WeCheckProcInfo;
import cigna.cm.b.io.CMB050SVC01In;
import cigna.cm.b.io.CMB050SVC01Out;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;


/**
 * @file         cigna.cm.b.service.CMB001SVC.java
 * @filetype     java source file
 * @brief
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈       2016. 5. 20.       신규 작성
 *
 */
@KlafService("CMB050SVC")
public class CMB050SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB050BEAN cmb050bean;
	
	
	/**
     * KIBNET 스크래핑 ( 신분증진위여부조회 )
     * @param contrCustNo
     * @param actMgntNo
     * @return
     * @throws ApplicationException
     */
	@KlafServiceOperation("selectList0")
	public CMB050SVC01Out selectList0(CMB050SVC01In input) throws ApplicationException {
		
		CMB050SVC01Out out = new CMB050SVC01Out();
		
		WeCheckProcInfo procInfo = new WeCheckProcInfo();
		WeCheckProcInfo resProcInfo = null;
		
		
		
		procInfo.setSendDt(input.getSendDt());
		procInfo.setSendTm(input.getSendTm());
		procInfo.setTrSeq(input.getTrSeq());
		procInfo.setBankCd(input.getBankCd());
		procInfo.setName(input.getName());
		if ("004".equals(input.getBankCd())) {
			procInfo.setRegNo(SecuUtil.getDecValue(input.getRegNo(),  EncType.custDscNo) );
		} else {
			procInfo.setRegNo(input.getRegNo());
		}
		
		//2017.03.28;현승훈;TM 요청으로 면허번호, 발급일자 복호화 처리
		if ("ILS".equals(FwUtil.getMedTyp())) {
			procInfo.setDriveNo(SecuUtil.getDecValue(input.getDriveNo(),  EncType.Etc));
			procInfo.setIssueDate(SecuUtil.getDecValue(input.getIssueDate(), EncType.Etc));
		} else {
			procInfo.setDriveNo(input.getDriveNo());
			procInfo.setIssueDate(input.getIssueDate());
		}
		procInfo.setSecureNo(input.getSecureNo());
		
		resProcInfo = cmb050bean.callWeCheck(procInfo);
		
		out.setTrSeq(resProcInfo.getTrSeq());
		out.setSendDt(resProcInfo.getSendDt());
		out.setSendTm(resProcInfo.getSendTm());				  
		out.setBankCd(resProcInfo.getBankCd());																		//기관코드
		out.setName(resProcInfo.getName());			//성명
		if ("004".equals(input.getBankCd())) {
			out.setRegNo(SecuUtil.getEncValue(resProcInfo.getRegNo(),  EncType.custDscNo) );
		} else {
			out.setRegNo(resProcInfo.getRegNo());		//주민등록번호
		}
		
		//2017.03.28;현승훈;TM 요청으로 면허번호, 발급일자 복호화 처리
		if ("ILS".equals(FwUtil.getMedTyp())) {
			out.setDriveNo(SecuUtil.getEncValue(input.getDriveNo(),  EncType.Etc));
			out.setIssueDate(SecuUtil.getEncValue(input.getIssueDate(), EncType.Etc));
		} else {
			out.setDriveNo(input.getDriveNo());
			out.setIssueDate(input.getIssueDate());
		}
		out.setSecureNo(resProcInfo.getSecureNo());	//암호일련번호
		out.setAgreement(resProcInfo.getResAgreement());							//진위여부
		out.setRespCd(resProcInfo.getRespCd());
		out.setAnswMsg(resProcInfo.getAnswMsg());
		out.setResName(resProcInfo.getResName());
		out.setResRegNo(resProcInfo.getResRegNo());
		out.setResDriveNo(resProcInfo.getResDriveNo());
		out.setResSearchDate(resProcInfo.getResSearchDate());
		out.setResIssueDate(resProcInfo.getResIssueDate());
		out.setResDisagreementReason(resProcInfo.getResDisagreementReason());
		
		
		return out;
		
	}
}

