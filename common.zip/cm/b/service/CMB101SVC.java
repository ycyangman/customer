package cigna.cm.b.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.inf.EisExecutionException;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB101BEAN;
import cigna.cm.b.io.CMB101SVC01In;
import cigna.cm.b.io.CMB101SVC01Out;
import cigna.cm.b.io.CMB101SVC01Sub;
import cigna.cm.b.io.CMB101SVC02In;
import cigna.zz.SecuUtil;



/**
 * @file         cigna.cm.b.service.CMB101SVC.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이보라                      2016. 10. 5.       신규 작성
 *
 */
@KlafService("CMB101SVC")
public class CMB101SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB101BEAN cmb101bean;
	
	/**
	 * 모계좌조회
	 * 
	 * @param NBE410SVC01In
	 * @return NBE410SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMB101SVC01Out selectList1(CMB101SVC01In input)
			throws ApplicationException {
		
		CMB101SVC01Out output = new CMB101SVC01Out();
		
		List<CMB101SVC01Sub> list = cmb101bean.getMoActList(input);
		
		if (list.size() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage("KIOKI0004", null, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",
					new Object[] { list.size() }, null);
		}
		SecuUtil.doDecList(list);
		output.setDsMoActList(list);
		
		return output;
	}
	
	/**
	 * 모계좌 체크
	 * 
	 * @param NBE410SVC03In
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMB101SVC01Out selectList2 (CMB101SVC02In input) throws ApplicationException {
		
		CMB101SVC01Out output = new CMB101SVC01Out();
		
		int rCnt =0;
		
		rCnt = cmb101bean.getMoActCheck(input);
		
		output.setRstCnt(rCnt);
		
		return output;
	}
	
	
	/**
	 * 모계좌 저장
	 * 
	 * @param NBE410SVC03In
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify")
	public void changeModify (CMB101SVC02In input) throws ApplicationException {
		int rCnt =0;
		
		rCnt = cmb101bean.getMergeMoActList(input);
		
		if (rCnt > 0 ){
			// 입력하신내용 {0}건이 저장 되었습니다. 
			LApplicationContext.addMessage("KIOKI0010", new Object[]{ Integer.toString(rCnt)}, null);
		}else{
			// 입력하신 내용을 저장할 수 없습니다. 
			LApplicationContext.addMessage("KIERE0005", new Object[]{ Integer.toString(rCnt)}, null);	
		}
	}
	
}

