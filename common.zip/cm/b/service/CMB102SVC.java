package cigna.cm.b.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.inf.EisExecutionException;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB102BEAN;
import cigna.cm.b.io.CMB102SVC01In;
import cigna.cm.b.io.CMB102SVC01Out;
import cigna.cm.b.io.CMB102SVC01Sub;
import cigna.cm.b.io.CMB103SVC02In;
import cigna.cm.b.io.CMB103SVC02Out;



/**
 * @file         cigna.cm.b.service.CMB103SVC.java
 * @filetype     java source file
 * @brief        가상계좌통계
 * @author       현승훈
 * @version      0.1
 * @history
 *
 * 버전                           성명                                               일자                                    변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈                                             2016.12.19.      신규 작성
 *
 */
@KlafService("CMB102SVC")
public class CMB102SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private	CMB102BEAN cmb102bean; // 가상계좌통계조회
	

	/**
	 * 가상계좌통계
	 * @param  input CMB102SVC01In
	 * @return output CMB102SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	@TransactionalOperation
	public CMB102SVC01Out selectList1(CMB102SVC01In input) throws ApplicationException, EisExecutionException {
		
		CMB102SVC01Out output = new CMB102SVC01Out();
		
		List<CMB102SVC01Sub> rtnResult = cmb102bean.getVactDlngLst(input);
		
		// 조회건수가 없는 경우
		if(rtnResult.size() == 0) {
			throw new ApplicationException("KIOKI0004", null);
		}
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if(DasUtils.existNextResult(rtnResult)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		output.setDsCMB102SVC01Sub(rtnResult);
		output.setOutListCnt(rtnResult.size()); // 건수
		
		if("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003", new String[] {String.valueOf(rtnResult.size())}, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002", new String[] {String.valueOf(rtnResult.size())}, null);
		}

		return output;
	}

}

