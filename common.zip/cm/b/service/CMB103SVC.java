package cigna.cm.b.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.inf.EisExecutionException;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB103BEAN;
import cigna.cm.b.io.CMB103SVC01In;
import cigna.cm.b.io.CMB103SVC01Out;
import cigna.cm.b.io.CMB103SVC02In;
import cigna.cm.b.io.CMB103SVC02Out;
import cigna.cm.b.io.CMB103SVC02Sub;
import cigna.cm.b.io.CMB103SVC03In;
import cigna.cm.b.io.CMB103SVC03Out;
import cigna.cm.b.io.CMB103SVC04In;
import cigna.cm.b.io.CMB103SVC04Out;

/**
 * @file         cigna.cm.b.service.CMB103SVC.java
 * @filetype     java source file
 * @brief        단말기번호관리
 * @author       송경원
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           송경원                 2016. 7. 14.      신규 작성
 *
 */
@KlafService("CMB103SVC")
public class CMB103SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private	CMB103BEAN cmb103bean; // 단말기번호관리
	

	/**
	 * 통합보험료출금
	 * @param  input CMB103SVC01In
	 * @return output CMB103SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public CMB103SVC01Out changeInsert1(CMB103SVC01In input) throws ApplicationException, EisExecutionException {
		
		CMB103SVC01Out output = new CMB103SVC01Out();
		
		Map<String, String> map = new HashMap<String, String>();
		
		output = cmb103bean.procCallTgmTrrv(input);
		
		if ("0000".equals(output.getAnswCd())) {  //응답코드가 정상이면
			output.setAnswMsgCtnt("정상처리");
			LApplicationContext.addMessage("APDPI0003",  null, null);
		} else {
			// 금융기관결과오류코드 세팅
            try {
                map = cmb103bean.getMapFinErrCd();
            } catch (ApplicationException e) {
            	logger.error("ApplicationException : " + e.getMessage());
            }
            
            String finRcdNm = ""; // 자동이체결과코드명 
            logger.debug("은행코드결과코드{}" ,input.getBnkCd() + output.getAnswCd());
            if (!StringUtils.isEmpty(output.getAnswCd())) {
//            	 finRcdNm = dpb260bean.getMapFinErrCd(input.getBnkCd() + output.getAnswCd());            
            	 finRcdNm = StringUtils.isEmpty(map.get(input.getBnkCd() + output.getAnswCd())) ? "기타오류" : map.get(input.getBnkCd() + output.getAnswCd());
            }             

            output.setAnswMsgCtnt(finRcdNm);
			 //리얼타임이체 불능으로 처리 되었습니다.
		     LApplicationContext.addMessage("APDPE0210",  new Object[]{finRcdNm}, null);
		}

		return output;
	}

	/**
	 * 통합출금관리조회
	 * @param  input CMB102SVC01In
	 * @return output CMB102SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	@TransactionalOperation
	public CMB103SVC02Out selectList1(CMB103SVC02In input) throws ApplicationException, EisExecutionException {
		
		CMB103SVC02Out output = new CMB103SVC02Out();
		
		List<CMB103SVC02Sub> rtnResult = cmb103bean.getTrsfDlngLst(input);
		
		// 조회건수가 없는 경우
		if(rtnResult.size() == 0) {
			throw new ApplicationException("KIOKI0004", null);
		}
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if(DasUtils.existNextResult(rtnResult)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		output.setDsCMB103SVC02Sub(rtnResult);
		output.setOutListCnt(rtnResult.size()); // 건수
		
		if("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003", new String[] {String.valueOf(rtnResult.size())}, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002", new String[] {String.valueOf(rtnResult.size())}, null);
		}

		return output;
	}
	
	/**
	 * 통합출금관리조회
	 * @param  input CMB102SVC01In
	 * @return output CMB102SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList4")
	@TransactionalOperation
	public CMB103SVC04Out selectList4(CMB103SVC04In input) throws ApplicationException, EisExecutionException {
		
		CMB103SVC04Out output = new CMB103SVC04Out();
		
		output = cmb103bean.getCust(input);
		
		// 조회건수가 없는 경우
		if(output == null) {
			throw new ApplicationException("KIOKI0004", null);
		}
				
		return output;
	}
	
	/**
     * 리얼타임이체중 처리
     *
     * @param CMB103SVC03In
     *
     */
    @KlafServiceOperation("changeInsert2")
    @TransactionalOperation
    public CMB103SVC03Out changeInsert2(CMB103SVC03In input) throws ApplicationException {
    	CMB103SVC03Out output = null;

        // 이체일자에 리얼타임 전문이 수신시 장애로 인해 미이체, 미출금된 계약의 입금기장처리
        output = cmb103bean.insertRltmTrsfImp(input);
        /* 정상처리 결과 메시지: 입력하신 내용 {0}건이 저장 되었습니다. */

        LApplicationContext.addMessage("KIOKI0008", new Object[]{ Integer.toString(output.getRstCnt())},  null);

        return output;

    }

}

