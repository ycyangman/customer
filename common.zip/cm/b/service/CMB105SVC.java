package cigna.cm.b.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB105BEAN;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.io.CMB105SVC01Out;
import cigna.cm.b.io.CMB105SVC01Sub;
import cigna.cm.b.io.CMB105SVC01In;
import cigna.cm.b.io.CMB105SVC02In;
import cigna.cm.b.io.CMB105SVC02Out;
import cigna.cm.b.io.CMB105SVC03In;
import cigna.cm.b.io.CMB105SVC03Out;
import cigna.cm.b.io.CMB105SVC03Sub;
import cigna.zz.SecuUtil;

/**
 * @file cigna.cm.b.service.CMB105SVC.java
 * @filetype java source file
 * @brief
 * @author 이보라
 * @version 0.1
 * @history
 * 
 *          버전 성명 일자 변경내용 ------- ---------------- ----------- -----------------
 *          0.1 이보라 2016. 7. 29. 신규 작성
 * 
 */
@KlafService("CMB105SVC")
public class CMB105SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CMB105BEAN cmb105bean; // 모계좌 잔액
	
	/**
	 * 모계좌 조회(계좌/은행 조회)
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList")
	public CMB105SVC01Out selectList(CMB105SVC01In input) throws ApplicationException {

		CMB105SVC01Out output = new CMB105SVC01Out();

		List<CMB105SVC01Sub> List = cmb105bean.getMoActList(input);
		
		SecuUtil.doDecList(List);
		output.setDsMoActList(List);

		return output;
	}
	
	
	
	/**
	 * 모계좌 조회(정상조회인지 확인)
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMB105SVC02Out selectList1(CMB105SVC02In input) throws ApplicationException {
		
		CMB105SVC02Out output = new CMB105SVC02Out();

		TrsfTrrvPrcsInfo prcsInfo = cmb105bean.searchBamtInq(input);
		
		output.setReturnCd(prcsInfo.getBnkAnswCd());
		
		logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+prcsInfo.getBnkAnswCd());

		if ("0000".equals(prcsInfo.getBnkAnswCd())) {
			output.setReturnMsg("정상조회");
		}
		else {
			String rstCtnt = cmb105bean.getRtPrcsDtlInfo(prcsInfo.getBnkCd(), prcsInfo.getBnkAnswCd());
			
			output.setReturnMsg(rstCtnt);
			logger.debug("aaa");
		}
 
		return output;
	}
	
	
	/**
	 * 모계좌 조회(일시/금액 조회)
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMB105SVC03Out selectList2(CMB105SVC03In input) throws ApplicationException {
		
		CMB105SVC03Out output = new CMB105SVC03Out();

		List<CMB105SVC03Sub> List = cmb105bean.getMoActBlncMgnt(input);
		
		// 조회된 내용이 첫페이지부터 없는 경우, 오류처리
		if (input.getPageNum() <= 1 && List.size() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}

		if (DasUtils.existNextResult(List)) {
				output.setRecrdNxtYn("Y");
		} else {
				output.setRecrdNxtYn("N");
		}

		if (List.size() == 0) {
				// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
				LApplicationContext.addMessage("KIOKI0004", null, null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003",	new Object[] { List.size() }, null);
		} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002",new Object[] { List.size() }, null);
		}
		output.setDsMoActBlncMgnt(List);
		return output;
	}
}
