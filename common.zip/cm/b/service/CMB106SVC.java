package cigna.cm.b.service;


import java.util.List;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB106BEAN;
import cigna.cm.b.io.CMB106SVC01In;
import cigna.cm.b.io.CMB106SVC01Out;
import cigna.cm.b.io.CMB106SVC01Sub;
import cigna.cm.b.io.CMB106SVC02In;
import cigna.cm.b.io.CMB106SVC03In;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;



/**
 * @file         cigna.cm.b.service.CMB106SVC.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이보라                       2016. 10. 10.       신규 작성
 *
 */
@KlafService("CMB106SVC")
public class CMB106SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB106BEAN cmb106bean; //출금동의검수리스트
	
	/**
	 * 출금동의검수리스트
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMB106SVC01Out selectList(CMB106SVC01In input) throws ApplicationException {

		CMB106SVC01Out output = new CMB106SVC01Out();

		List<CMB106SVC01Sub> List = cmb106bean.getWtrsfAsntList(input);
		if (DasUtils.existNextResult(List)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		if (List.size() == 0) {			
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003",
					new Object[] { List.size() }, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",
					new Object[] { List.size() }, null);
		}
		SecuUtil.doDecList(List);
		
		output.setDsWtrsfAsntList(List);
		
		return output;
	}
	
	/**
	 * 출금동의검수리스트(랜덤)
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMB106SVC01Out selectList1(CMB106SVC01In input) throws ApplicationException {

		CMB106SVC01Out output = new CMB106SVC01Out();

		List<CMB106SVC01Sub> List = cmb106bean.getWtrsfAsntRandomList(input);
		if (DasUtils.existNextResult(List)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		if (List.size() == 0) {
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003",
					new Object[] { List.size() }, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",
					new Object[] { List.size() }, null);
		}
		
		for ( int i =0; i<List.size();i++) {
			List.get(i).setPmpsDscNo(SecuUtil.getDecValue(List.get(i).getPmpsDscNo(), EncType.custDscNo));
			List.get(i).setPmpsActNo(SecuUtil.getDecValue(List.get(i).getPmpsActNo(), EncType.actNo));
			
		}
		output.setDsWtrsfAsntList(List);
		
		return output;
	}
	
	/**
	 * 출금동의검수리스트(팝업)
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMB106SVC01Sub selectList3(CMB106SVC03In input) throws ApplicationException {

		CMB106SVC01Sub List = cmb106bean.getWtrsfAsntDtlList(input);
		

		if (List == null ) {			
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		} 
		
		List.setPmpsDscNo(SecuUtil.getDecValue(List.getPmpsDscNo(), EncType.custDscNo));
		List.setPmpsActNo(SecuUtil.getDecValue(List.getPmpsActNo(), EncType.actNo));
		
		return List;
	}
	
	/**
	 * 출금동의검수리스트
	 * @param  CMB106SVC02In
	 * @return void
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate")
	public void changeUpdate(CMB106SVC02In input) throws ApplicationException {

		int rCnt = 0;
		
		rCnt = cmb106bean.updateWtrsfAsntList(input);
		
		if (rCnt > 0 ){
			// 입력하신내용 {0}건이 저장 되었습니다. 
			LApplicationContext.addMessage("KIOKI0010", new Object[]{ Integer.toString(rCnt)}, null);
		}else{
			// 입력하신 내용을 저장할 수 없습니다. 
			LApplicationContext.addMessage("KIERE0005", new Object[]{ Integer.toString(rCnt)}, null);	
		}
		

	}
}

