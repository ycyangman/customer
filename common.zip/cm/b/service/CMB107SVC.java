package cigna.cm.b.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB107BEAN;
import cigna.cm.b.io.CMB107SVC01In;
import cigna.cm.b.io.CMB107SVC01Out;
import cigna.cm.b.io.CMB107SVC01Sub;
import cigna.cm.b.io.CMB107SVC02In;
import cigna.cm.b.io.CMB107SVC03In;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;


/**
 * @file         cigna.cm.b.service.CMB107SVC.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이보라       2016. 10. 12.       신규 작성
 *
 */
@KlafService("CMB107SVC")
public class CMB107SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB107BEAN cmb107bean; //출금동의검수리스트
	
	/**
	 * 보완콜리스트
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMB107SVC01Out selectList(CMB107SVC01In input) throws ApplicationException {

		CMB107SVC01Out output = new CMB107SVC01Out();

		List<CMB107SVC01Sub> List = cmb107bean.getComplCallList(input);
		if (DasUtils.existNextResult(List)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		if (List.size() == 0) {
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003",
					new Object[] { List.size() }, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",
					new Object[] { List.size() }, null);
		}
		
		for ( int i =0; i<List.size();i++) {
			List.get(i).setPmpsDscNo(SecuUtil.getDecValue(List.get(i).getPmpsDscNo(), EncType.custDscNo));
			List.get(i).setPmpsActNo(SecuUtil.getDecValue(List.get(i).getPmpsActNo(), EncType.actNo));
			
		}
		
		output.setDsComplCallList(List);
		
		return output;
	}
	
	/**
	 * 보완콜리스트
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMB107SVC01Sub selectList3(CMB107SVC03In input) throws ApplicationException {

		
		CMB107SVC01Sub List = cmb107bean.getComplCallDtlList(input);

		if (List == null ) {			
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		} 
		
		List.setPmpsDscNo(SecuUtil.getDecValue(List.getPmpsDscNo(), EncType.custDscNo));
		List.setPmpsActNo(SecuUtil.getDecValue(List.getPmpsActNo(), EncType.actNo));
		
		return List;
	}
	
	/**
	 * 보완콜리스트
	 * @param  CMB107SVC02In
	 * @return void
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate")
	public void changeUpdate(CMB107SVC02In input) throws ApplicationException {

		int rCnt = 0;
		
		rCnt = cmb107bean.updateComplCallList(input);
		
		if (rCnt > 0 ){
			// 입력하신내용 {0}건이 저장 되었습니다. 
			LApplicationContext.addMessage("KIOKI0010", new Object[]{ Integer.toString(rCnt)}, null);
		}else{
			// 입력하신 내용을 저장할 수 없습니다. 
			LApplicationContext.addMessage("KIERE0005", new Object[]{ Integer.toString(rCnt)}, null);	
		}
		

	}
}

