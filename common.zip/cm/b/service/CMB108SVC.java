package cigna.cm.b.service;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB106BEAN;
import cigna.cm.b.io.CMB108SVC01In;
import cigna.cm.b.io.CMB108SVC01Out;
import cigna.cm.b.io.CMB108SVC02In;
import cigna.cm.b.io.CMB108SVC02Out;



/**
 * @file         cigna.cm.b.service.CMB106SVC.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이보라                       2016. 10. 10.       신규 작성
 *
 */
@KlafService("CMB108SVC")
public class CMB108SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB106BEAN cmb106bean; //출금동의검수리스트
	
	/**
	 * CS 녹취번호 조회
	 * @param
	 * @return CMB108SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMB108SVC01Out selectList0(CMB108SVC01In input) throws ApplicationException {

		CMB108SVC01Out output = new CMB108SVC01Out();

		output = cmb106bean.getCsWtrsfAsntEvidNo(input);
		
		if (output == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		LApplicationContext.addMessage("KIOKI0001", null, null);
		
		return output;
	}
	
	/**
	 * VOC 녹취관련 조회
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMB108SVC02Out selectList1(CMB108SVC02In input) throws ApplicationException {

		CMB108SVC02Out output = new CMB108SVC02Out();

		output = cmb106bean.getVocWtrsfAsntEvidLst(input);
		
		if ( output == null || StringUtils.isEmpty(output.getWtrsfAsntEvidNo())) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		LApplicationContext.addMessage("KIOKI0001", null, null);
		
		return output;
	}
	
}

