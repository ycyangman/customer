package cigna.cm.b.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.b.bean.CMB110BEAN;
import cigna.cm.b.io.CMB110SVC01In;
import cigna.cm.b.io.CMB110SVC01Out;
import cigna.cm.b.io.CMB110SVC01Sub;
import cigna.cm.b.io.CMB110SVC02In;
import cigna.cm.b.io.CMB110SVC02Out;
import cigna.cm.b.io.CMB110SVC03In;
import cigna.cm.b.io.CMB110SVC03Out;
import cigna.cm.b.io.CMB110SVC03Sub;
import cigna.cm.b.io.CMB110SVC04In;
import cigna.cm.b.io.CMB110SVC04Out;
import cigna.cm.b.io.CMB110SVC05In;
import cigna.cm.b.io.CMB110SVC05Out;


/**
 * @file         cigna.cm.b.service.CMB107SVC.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           현승훈       2016. 12. 01.       신규 작성
 *
 */
@KlafService("CMB110SVC")
public class CMB110SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB110BEAN cmb110bean; //출금이체동의금결원증빙내역
	
	/**
	 * 출금이체동의금결원요청자료조회
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMB110SVC01Out selectList(CMB110SVC01In input) throws ApplicationException {

		CMB110SVC01Out output = new CMB110SVC01Out();

		List<CMB110SVC01Sub> List = cmb110bean.getWtrsfAsntKftcList(input);
		if (DasUtils.existNextResult(List)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		if (List.size() == 0) {
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003",
					new Object[] { List.size() }, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",
					new Object[] { List.size() }, null);
		}
		//SecuUtil.doDecList(List);
		
		output.setDsWtrsfAsntKftcList(List);
		
		return output;
	}
	
	/**
	 * 출금이체동의금결원요청자료조회
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMB110SVC03Out selectList1(CMB110SVC03In input) throws ApplicationException {

		CMB110SVC03Out output = new CMB110SVC03Out();

		List<CMB110SVC03Sub> List = cmb110bean.getWtrsfAsntKftcDataList(input);
		if (DasUtils.existNextResult(List)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		if (List.size() == 0) {
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003",
					new Object[] { List.size() }, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",
					new Object[] { List.size() }, null);
		}
		//SecuUtil.doDecList(List);
		
		output.setDsWtrsfAsntKftcDataList(List);
		
		return output;
	}
	
//	/**
//	 * 보완콜리스트
//	 * @param  CMB107SVC02In
//	 * @return void
//	 * @throws ApplicationException
//	 */
//	@KlafServiceOperation("changeUpdate")
//	public void changeUpdate(CMB107SVC02In input) throws ApplicationException {
//
//		int rCnt = 0;
//		
//		rCnt = cmb107bean.updateComplCallList(input);
//		
//		if (rCnt > 0 ){
//			// 입력하신내용 {0}건이 저장 되었습니다. 
//			LApplicationContext.addMessage("KIOKI0010", new Object[]{ Integer.toString(rCnt)}, null);
//		}else{
//			// 입력하신 내용을 저장할 수 없습니다. 
//			LApplicationContext.addMessage("KIERE0005", new Object[]{ Integer.toString(rCnt)}, null);	
//		}
//		
//
//	}
	
	
	/**
	 * 출금이체동의 금융결제원 요청파일 처리
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public CMB110SVC02Out changeInsert1(CMB110SVC02In input) throws ApplicationException {
		
		
		CMB110SVC02Out output = new CMB110SVC02Out();
		
		output = cmb110bean.insertFileDataSet( input );
		
		//output = cmb110bean.getWtrsfAsntKftc(input, outParam);

		LApplicationContext.addMessage("APCMI0000",  new Object[]{"1"}, null);
		
		return output;
	}
	
	/**
	 * 출금이체동의금결원요청자료조회
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMB110SVC04Out selectList2(CMB110SVC04In input) throws ApplicationException, InterruptedException {

		CMB110SVC04Out output = new CMB110SVC04Out();

		output = cmb110bean.getWtrsfAsntKftc(input);
		
		
		return output;
	}
	
	/**
	 * AE5119생성
	 * @param
	 * @return CMB105SVC01Out
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle0")
	public CMB110SVC05Out selectSingle0(CMB110SVC05In input) throws ApplicationException, InterruptedException {

		CMB110SVC05Out output = new CMB110SVC05Out();

		output = cmb110bean.getAE5119File(input);
		
		
		return output;
	}
}

