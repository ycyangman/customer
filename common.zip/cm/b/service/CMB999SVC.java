package cigna.cm.b.service;

import java.math.BigDecimal;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA010BEAN;
import cigna.cm.b.bean.CMB001BEAN;
import cigna.cm.b.bean.CMB010BEAN;
import cigna.cm.b.bean.CMB020BEAN;
import cigna.cm.b.bean.CMB050BEAN;
import cigna.cm.b.dbio.CMB001DBIO;
import cigna.cm.b.domain.RTCont;
import cigna.cm.b.domain.TrsfTrrvPrcsInfo;
import cigna.cm.b.domain.WeCheckProcInfo;
import cigna.cm.b.io.CMB999SVC00In;
import cigna.cm.b.io.CMB999SVC00Out;
import cigna.cm.b.io.CMB999SVC01In;
import cigna.cm.b.io.TBCSFCR001Io;
import cigna.zz.FwUtil;
import cigna.zz.RptUtil;
import cigna.zz.SecuUtil;


/**
 * @file         cigna.cm.b.service.CALLFEPSVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2016. 2. 11.       신규 작성
 *
 */
@KlafService("CMB999SVC")
public class CMB999SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMB001BEAN cmb001bean;
	
	@Autowired
	private CMB001DBIO cmb001dbio;
	
	@Autowired
	private CMB010BEAN cmb010bean;
	
	@Autowired
	private CMB020BEAN cmb020bean;
	
	@Autowired
	private CMA010BEAN cma010bean;
	
	@Autowired
	private CMB050BEAN cmb050bean;
	
	@KlafServiceOperation("selectSingle")
	public CMB999SVC00Out selectSingle(CMB999SVC00In input) throws ApplicationException {
		
		logger.debug("=============  FEPTESTSVC_selectList0 Start");
		
		logger.debug("input" + input);
		
		CMB999SVC00Out out = new CMB999SVC00Out();
		TBCSFCR001Io actInfo = cmb001dbio.selectOneTBCSFCR0011(input.getBnkCd(), SecuUtil.getEncValue(input.getActNo(), SecuUtil.EncType.actNo));
		
		logger.debug("actInfo : " + actInfo); 
		
		if( null != actInfo )	{
			
			out.setActMgntNo		(actInfo.getActMgntNo());
			out.setActNo				(SecuUtil.getDecValue(actInfo.getActNo(), SecuUtil.EncType.actNo));
			out.setAchdNm			(actInfo.getAchdNm());
			out.setAchdRrno		(SecuUtil.getDecValue(actInfo.getAchdCustDscNo(), SecuUtil.EncType.rrno));
			out.setBnkCd				(input.getBnkCd());
			
		}
		
		logger.debug("ScreenID : " + FwUtil.getScreenId());
		logger.debug("PgmId : " + FwUtil.getPgmId());
		logger.debug("DeptCd : " + FwUtil.getDeptCd());
		logger.debug("BatchDeptCd : " + RptUtil.getBatchDeptCd());
		
		/** TODO SMS 전송 테스트 임시용
		String docCd = "B01920001";	// 서식코드(금융거래정보제공통보안내(보건복지부))
		
		HashMap<String, String> msgInfo = new HashMap<String, String>();
		
		msgInfo.put("custNm"		,   "테스터");     // 고객명
		msgInfo.put("crinfofDt"	,   "20160101");  // 정보제공일자
		
		String rptXml = RptUtil. getRootMapXmlString(msgInfo);
		
		COM_E_DMIBS000000001Io headerIo = new COM_E_DMIBS000000001Io();
		
		headerIo.setReqSysId					("COR");					// 시스템ID
		headerIo.setFormtDcd					("0");							// 서식구분코드(0:단일서식)
		headerIo.setDocCd						(docCd);					// 서식코드
		headerIo.setNotclSndMedcd 		("09");						// 안내장발송매체코드(09:LMS)
		headerIo.setReceMphonTeldno	("010");
		headerIo.setReceMphonTelsno	("9159");
		headerIo.setReceMphonTelino	("0596");
		
		String rptData = RptUtil.toRptBatchData(headerIo	// HeaderIO
				  ,rptXml );  // xmlData
		
		msgInfo.put("msg",  "테스트입니다.");     // 메세지내용
		
		String rptXml2 = RptUtil. getRootMapXmlString(msgInfo);
		
		COM_E_DMIOS000000001In req = new COM_E_DMIOS000000001In();
		
		req.setFormtDcd						("0");														// 서식구분코드(0:단일서식)
		req.setDocCd							("B00000001");									// 문서코드(B00000001:자유형식문자메시지)
		req.setNotclSndMedcd 		("09");													// 안내장발송매체코드(09:LMS)
		req.setPrintData     					(rptXml2);												// 출력정보
		req.setReceMphonTeldno	("010");													// 휴대전화전화식별번호
		req.setReceMphonTelsno	("9159");												// 휴대전화전화국번호
		req.setReceMphonTelino		("0596");												// 휴대전화전화개별번호
		
		logger.debug("eaiRequest data:{}", req);
		
		COM_E_DMIOS000000001Out res = cma010bean.callEAINotcl(req);
		*/
		
		return out;
		
	}
	
	@KlafServiceOperation("selectList0")
	public CMB999SVC00Out selectList0(CMB999SVC00In input) throws ApplicationException {
		logger.debug("=============  FEPTESTSVC_selectList0 Start");
		
		logger.debug("FEPTESTSVC input : " + input);
		
		CMB999SVC00Out out = new CMB999SVC00Out();
		
		TrsfTrrvPrcsInfo  trsftrrvprcsinfoIn = new TrsfTrrvPrcsInfo();
		TrsfTrrvPrcsInfo  trsftrrvprcsinfoOut = null;
		
		// 지급이체
		if( RTCont.PRCSCD_01.equals(input.getPrcsCd()) )	{
			
			trsftrrvprcsinfoIn.setPrcsCd(input.getPrcsCd());
			trsftrrvprcsinfoIn.setTrsfAmt(input.getTrsfAmt());                        	          									//이체금액
			trsftrrvprcsinfoIn.setBenfcCustNo(input.getBenfcCustNo());                     								//수익자고객번호:출금일때 필수
			trsftrrvprcsinfoIn.setActMgntNo(input.getActMgntNo());                              							//계좌관리번호
			trsftrrvprcsinfoIn.setBnkCd(input.getBnkCd());                                    											//은행코드
			trsftrrvprcsinfoIn.setActNo(input.getActNo());                                       										//계좌번호
			trsftrrvprcsinfoIn.setAchdNm(input.getAchdNm());                                     								//예금주명
			trsftrrvprcsinfoIn.setAchdRrno(input.getAchdRrno());                                 								//예금주주민등록번호
			trsftrrvprcsinfoIn.setChnlDcd(input.getChnlDcd());                        												//채널구분코드
			     
			trsftrrvprcsinfoIn.setPrcsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	//처리일자
			trsftrrvprcsinfoIn.setPayRcPathCd("CM");                                          												//지급접수경로코드
			trsftrrvprcsinfoIn.setPayRcMcd("TW");                                             												//지급접수방법코드
			trsftrrvprcsinfoIn.setPyprcPathCd("Z");                                           													//지급처리경로코드(E;자동이체처리,S;송금처리,R:전액즉시자동송금)
			trsftrrvprcsinfoIn.setContrCustNo("");                                            													//계약자고객번호
			trsftrrvprcsinfoIn.setDpwdDcd("2");                                               													//입출금구분코드 1:입금, 2:출금
			trsftrrvprcsinfoIn.setNrmCnclDcd("0");                                            												//정상취소구분코드  0:정상(신청), 1:취소(해지)
	    	
			trsftrrvprcsinfoIn.setBzDcd("CM");																									// set [업무구분코드]
			trsftrrvprcsinfoIn.setReqBzTmBean("FEPTESTSVC");																	// set [요청파트BEAN]
			trsftrrvprcsinfoIn.setReqBzTmMethod("FEPTESTSVC");																// set [요청파트Method]
			trsftrrvprcsinfoIn.setOptnKey("S");																									// set옵션키 : 전송유형(S/sync),(A/async)
			
			
		// 즉시출금(입금,집금)
		}else if( RTCont.PRCSCD_02.equals(input.getPrcsCd()) )	{
			
			trsftrrvprcsinfoIn.setPrcsCd(input.getPrcsCd());
			trsftrrvprcsinfoIn.setTrsfAmt(input.getTrsfAmt());                        	          									//이체금액
			trsftrrvprcsinfoIn.setActMgntNo(input.getActMgntNo());                              							//계좌관리번호
			trsftrrvprcsinfoIn.setBnkCd(input.getBnkCd());                                    											//은행코드
			trsftrrvprcsinfoIn.setActNo(input.getActNo());                                       										//계좌번호
			trsftrrvprcsinfoIn.setAchdNm(input.getAchdNm());                                     								//예금주명
			trsftrrvprcsinfoIn.setAchdRrno(input.getAchdRrno());                                 								//예금주주민등록번호
			trsftrrvprcsinfoIn.setChnlDcd(input.getChnlDcd());                        												//채널구분코드
			
			trsftrrvprcsinfoIn.setPrcsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	//처리일자
			trsftrrvprcsinfoIn.setPayRcPathCd("CM");                                          												//지급접수경로코드
			trsftrrvprcsinfoIn.setPayRcMcd("TW");                                             												//지급접수방법코드
			trsftrrvprcsinfoIn.setPyprcPathCd("Z");                                           													//지급처리경로코드
			trsftrrvprcsinfoIn.setContrCustNo("");                                            													//계약자고객번호
			trsftrrvprcsinfoIn.setDpwdDcd("1");                                               													//입출금구분코드 1:입금, 2:출금
			trsftrrvprcsinfoIn.setNrmCnclDcd("0");                                            												//정상취소구분코드  0:정상(신청), 1:취소(해지)
	    	
			trsftrrvprcsinfoIn.setBzDcd("CM");																									// set [업무구분코드]
			trsftrrvprcsinfoIn.setReqBzTmBean("FEPTESTSVC");																	// set [요청파트BEAN]
			trsftrrvprcsinfoIn.setReqBzTmMethod("FEPTESTSVC");																// set [요청파트Method]
			trsftrrvprcsinfoIn.setOptnKey("S");																									// set옵션키 : 전송유형(S/sync),(A/async)
			
			
		// 출금이체신청(납부자번호등록)
		}else if( RTCont.PRCSCD_06.equals(input.getPrcsCd()) )	{
			
			trsftrrvprcsinfoIn.setPrcsCd(input.getPrcsCd());
			trsftrrvprcsinfoIn.setActMgntNo(input.getActMgntNo());                              							//계좌관리번호
			trsftrrvprcsinfoIn.setBnkCd(input.getBnkCd());                                    											//은행코드
			trsftrrvprcsinfoIn.setActNo(input.getActNo());                                       										//계좌번호
			trsftrrvprcsinfoIn.setAchdNm(input.getAchdNm());                                     								//예금주명
			trsftrrvprcsinfoIn.setAchdRrno(input.getAchdRrno());                                 								//예금주주민등록번호
			trsftrrvprcsinfoIn.setChnlDcd(input.getChnlDcd());                        												//채널구분코드
			trsftrrvprcsinfoIn.setNrmCnclDcd(input.getNrmCnclDcd());														// set [정상취소구분코드]등록(정상취소구분(0), 해지(정상취소구분(1)로 세팅)
			
			trsftrrvprcsinfoIn.setPrcsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	//처리일자
			trsftrrvprcsinfoIn.setTrsfAmt(BigDecimal.ZERO);																			// set [이체금액]
			trsftrrvprcsinfoIn.setDpwdDcd("1");																									// set [입출금구분코드] 1:입금, 2:출금
			
			trsftrrvprcsinfoIn.setBzDcd("CM");																									// set [업무구분코드]
			trsftrrvprcsinfoIn.setReqBzTmBean("FEPTESTSVC");																	// set [요청파트BEAN]
			trsftrrvprcsinfoIn.setReqBzTmMethod("FEPTESTSVC");																// set [요청파트Method]
			trsftrrvprcsinfoIn.setOptnKey("S");																									// set옵션키 : 전송유형(S/sync),(A/async)
			
		// 수취조회
		}else if( RTCont.PRCSCD_10.equals(input.getPrcsCd()) )	{
			
			throw new ApplicationException("APCSE0025", new Object[]{"After"}, new Object[]{"After","After" });
			
		// 이체처리결과조회
		}else if( RTCont.PRCSCD_03.equals(input.getPrcsCd()) )	{
			
			trsftrrvprcsinfoIn.setPrcsCd(input.getPrcsCd());
			trsftrrvprcsinfoIn.setTrsfAmt(input.getTrsfAmt());                        	          									//이체금액
			trsftrrvprcsinfoIn.setBenfcCustNo(input.getBenfcCustNo());                     								//수익자고객번호:출금일때 필수
			trsftrrvprcsinfoIn.setActMgntNo(input.getActMgntNo());                              							//계좌관리번호
			trsftrrvprcsinfoIn.setBnkCd(input.getBnkCd());                                    											//은행코드
			trsftrrvprcsinfoIn.setActNo(input.getActNo());                                       										//계좌번호
			trsftrrvprcsinfoIn.setAchdNm(input.getAchdNm());                                     								//예금주명
			trsftrrvprcsinfoIn.setAchdRrno(input.getAchdRrno());                                 								//예금주주민등록번호
			trsftrrvprcsinfoIn.setRltmTrsfTxNo(input.getRltmTrsfTxNo());													//실시간전송거래번호
			
			trsftrrvprcsinfoIn.setChnlDcd("0001");                                             												//채널구분코드     
			trsftrrvprcsinfoIn.setPrcsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));	//처리일자
			trsftrrvprcsinfoIn.setPayRcPathCd("PR");                                          												//지급접수경로코드
			trsftrrvprcsinfoIn.setPayRcMcd("TW");                                             												//지급접수방법코드
			trsftrrvprcsinfoIn.setPyprcPathCd("Z");                                           													//지급처리경로코드
			trsftrrvprcsinfoIn.setContrCustNo("");                                            													//계약자고객번호
			trsftrrvprcsinfoIn.setDpwdDcd("2");                                               													//입출금구분코드 1:입금, 2:출금
			trsftrrvprcsinfoIn.setNrmCnclDcd("0");                                            												//정상취소구분코드  0:정상(신청), 1:취소(해지)
	    	
			trsftrrvprcsinfoIn.setBzDcd("CM");																									// set [업무구분코드]
			trsftrrvprcsinfoIn.setReqBzTmBean("FEPTESTSVC");																	// set [요청파트BEAN]
			trsftrrvprcsinfoIn.setReqBzTmMethod("FEPTESTSVC");																// set [요청파트Method]
			trsftrrvprcsinfoIn.setOptnKey("S");																									// set옵션키 : 전송유형(S/sync),(A/async)
			
		// 실명조회
		}else if( RTCont.PRCSCD_07.equals(input.getPrcsCd()) )	{
			
			// 화면 입력값
			trsftrrvprcsinfoIn.setPrcsCd(input.getPrcsCd());																			// set [처리코드(07/성명조회]
			trsftrrvprcsinfoIn.setActMgntNo(input.getActMgntNo());														// set [계좌관리번호]
			trsftrrvprcsinfoIn.setBnkCd(input.getBnkCd());																				// set [은행코드]
			trsftrrvprcsinfoIn.setActNo(input.getActNo());																				// set [계좌번호]
			
			// 나머지 값
			trsftrrvprcsinfoIn.setChnlDcd("");																										// set [채널구분코드]
			trsftrrvprcsinfoIn.setPrcsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE ));	// set [처리일자]
			trsftrrvprcsinfoIn.setTrsfAmt(BigDecimal.ZERO);																			// set [이체금액]
			trsftrrvprcsinfoIn.setDpwdDcd("2");																									// set [입출금구분코드] 2:출금
			trsftrrvprcsinfoIn.setAchdRrno(input.getAchdRrno());																// set [예금주주민등록번호]
			trsftrrvprcsinfoIn.setAchdNm(input.getAchdNm());                                     								// set [예금주명]
			trsftrrvprcsinfoIn.setNrmCnclDcd("0");																							// set [정상취소구분코드]
			
			trsftrrvprcsinfoIn.setBzDcd("CS");																									// set [업무구분코드]
			trsftrrvprcsinfoIn.setReqBzTmBean("FEPTESTSVC");																	// set [요청파트BEAN]
			trsftrrvprcsinfoIn.setReqBzTmMethod("FEPTESTSVC");																// set [요청파트Method]
			trsftrrvprcsinfoIn.setOptnKey("S");																									// set옵션키 : 전송유형(S/sync),(A/async)
			
		// 잔액조회
		}else if( RTCont.PRCSCD_08.equals(input.getPrcsCd()) )	{
			
			trsftrrvprcsinfoIn.setPrcsCd(input.getPrcsCd());
			trsftrrvprcsinfoIn.setBnkCd(input.getBnkCd());          																	// set [은행코드]
			trsftrrvprcsinfoIn.setChnlDcd(input.getChnlDcd()) ;           															// 채널구분코드
			
			trsftrrvprcsinfoIn.setPrcsDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE ));	// set [처리일자]
			trsftrrvprcsinfoIn.setDpwdDcd("2");                       																			// set [입출금구분코드 : 출금]
			trsftrrvprcsinfoIn.setTrsfAmt(BigDecimal.ZERO) ;         																//이체금액
			trsftrrvprcsinfoIn.setNrmCnclDcd("0");                    																		// set [정상취소구분코드 : 정상]

			trsftrrvprcsinfoIn.setBzDcd("CM");																									// set [업무구분코드]
			trsftrrvprcsinfoIn.setReqBzTmBean("FEPTESTSVC");																	// set [요청파트BEAN]
			trsftrrvprcsinfoIn.setReqBzTmMethod("FEPTESTSVC");																// set [요청파트Method]
			trsftrrvprcsinfoIn.setOptnKey("S");																									// set옵션키 : 전송유형(S/sync),(A/async)
			 
		}
		
		trsftrrvprcsinfoOut = cmb001bean.callTgmTrrv(trsftrrvprcsinfoIn);
		//trsftrrvprcsinfoOut = cmb001bean.callTgmTrrv(trsftrrvprcsinfoIn);
		
		if( null == trsftrrvprcsinfoOut )	{
			logger.error("예금주명조회 대외계오류");
			throw new ApplicationException("APCSE0025", new Object[]{"예금주명 조회"}, new Object[]{"대외계","대외계 오류" });
		}
		
		if( null != trsftrrvprcsinfoOut )		{
			// 결과코드
			out.setBnkAnswCd	( trsftrrvprcsinfoOut.getBnkAnswCd() );
			out.setRltmTrsfTxNo	( trsftrrvprcsinfoOut.getRltmTrsfTxNo() );
		}
		
		logger.debug("FEPTESTSVC_selectList0 trsftrrvprcsinfoOut : " + trsftrrvprcsinfoOut);
		
		return out;
		
	}
	
/**
	@KlafServiceOperation("selectList1")
	public CMB999SVC00Out selectList1(CMB999SVC01In input) throws ApplicationException {
		
		CMB999SVC00Out out = null;
		
		// 카드승인 요청 및 취소
		CardAprvResInfo cardResInfo		= null;
		CardAprvReqInfo cardReqInfo	= null;
		
		// 카드승인 요청
		if()	{
			
			String vldYm =  input.getCardVldYm().substring(4,6) + input.getCardVldYm().substring(2,4);
			
			cardReqInfo.setCardNo								(input.getCardNo());																					// set [카드번호]
			cardReqInfo.setCardVldYm							(vldYm);																										// set [카드유효년월]
			cardReqInfo.setMipMcnt								(StringUtils.lpad(String.valueOf(input.getMipMcnt()), 2, "0"));	// set [할부개월수]2014.07.22.수정(할부개월적용 변경)				
			cardReqInfo.setContNo								(input.getContNo());																					// set [계약번호]
			cardReqInfo.setTxDcd									("FA");																											// set [카드처리구분코드 (FA:신용카드승인,CC:신용카드승인취소,IA:카드인증요청,JE:신용카드 망취소)]
			cardReqInfo.setCardAprvNo						(input.getCardAprvNo());																		// set [원거래카드승인번호]
			cardReqInfo.setCardOwnerCustDscNo	(input.getCardOwnerCustDscNo());														// set [카드소유주주민등록번호]
			cardReqInfo.setBzDcd									("CM");																											// set [업구구분코드]
			cardReqInfo.setContrRrno							(input.getCustDscNo());																			// set [계약자주민번호]
			cardReqInfo.setCardApplAmt					(input.getAprvAmt().toPlainString());													// set [카드신청금액]
			cardReqInfo.setCardAprvDt						(input.getPmPrcsDt());																				// set [원거래카드승인일자]
			
			cardResInfo = cmb010bean.setCardAprvPrcs(cardReqInfo);
			
		// 카드승인 취소
		}else	{
			
			String vldYm =  input.getCardVldYm().substring(4,6) + input.getCardVldYm().substring(2,4);
			
			cardReqInfo.setCardNo								(input.getCardNo());																					// set [카드번호]
			cardReqInfo.setCardVldYm							(vldYm);																										// set [카드유효년월]
			cardReqInfo.setMipMcnt								(StringUtils.lpad(String.valueOf(input.getMipMcnt()), 2, "0"));	// set [할부개월수]2014.07.22.수정(할부개월적용 변경)				
			cardReqInfo.setContNo								(input.getContNo());																					// set [계약번호]
			cardReqInfo.setTxDcd									("CC");																											// set [카드처리구분코드 (FA:신용카드승인,CC:신용카드승인취소,IA:카드인증요청,JE:신용카드 망취소)]
			cardReqInfo.setCardAprvNo						(input.getCardAprvNo());																		// set [원거래카드승인번호]
			cardReqInfo.setCardOwnerCustDscNo	(input.getCardOwnerCustDscNo());														// set [카드소유주주민등록번호]
			cardReqInfo.setBzDcd									("CM");																											// set [업구구분코드]
			cardReqInfo.setContrRrno							(input.getCustDscNo());																			// set [계약자주민번호]
			cardReqInfo.setCardApplAmt					(input.getAprvAmt().toPlainString());													// set [카드신청금액]
			cardReqInfo.setCardAprvDt						(input.getPmPrcsDt());																				// set [원거래카드승인일자]
			
			cardResInfo = cmb010bean.setCardAprvPrcs(cardReqInfo);
			
		}else if	{
			
		}else if	{
			
		}
		
		return out;
		
	}
	
	**/
	
	
	@KlafServiceOperation("selectList2")
	public CMB999SVC01In selectList2(CMB999SVC01In input) throws ApplicationException {
		
		CMB999SVC01In out = new CMB999SVC01In();
		
		WeCheckProcInfo procInfo = new WeCheckProcInfo();
		WeCheckProcInfo resProcInfo = null;
		
		
		procInfo.setSendDt(input.getSendDt());
		procInfo.setSendTm(input.getSendTm());
		procInfo.setTrSeq(input.getTrSeq());
		procInfo.setBankCd(input.getBankCd());
		procInfo.setName(input.getName());
		procInfo.setRegNo(input.getRegNo());
		procInfo.setDriveNo(input.getDriveNo());
		procInfo.setSecureNo(input.getSecureNo());
		procInfo.setIssueDate(input.getIssueDate());
		
		resProcInfo = cmb050bean.callWeCheck(procInfo);
		
		out.setRespCd(resProcInfo.getRespCd());
		out.setAgreement(resProcInfo.getResAgreement());
		out.setResName(resProcInfo.getResName());
		out.setResRegNo(resProcInfo.getResRegNo());
		out.setResDriveNo(resProcInfo.getResDriveNo());
		out.setResSearchDate(resProcInfo.getResSearchDate());
		out.setResIssueDate(resProcInfo.getResIssueDate());
		out.setResDisagreementReason(resProcInfo.getResDisagreementReason());
		
		
		return out;
		
	}
}
