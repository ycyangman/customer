package cigna.cm.r.bean;

import java.math.BigDecimal;
import java.util.List;

import cigna.cm.r.dbio.CMR002DBIO;
import cigna.cm.r.io.CMR001SVC00In;
import cigna.cm.r.io.CMR001SVC00Out;
import cigna.cm.r.io.TBCMETC008Io;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.r.bean.CMR002BEAN.java
 * @filetype     java source file
 * @brief
 * @author       김정국
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김정국                 2015. 5. 28.      신규 작성
 *
 */
@KlafBean
public class CMR010BEAN {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMR002DBIO cmr002dbio;
	
	/**
	 * SMS 업무 알림을 받을 수신자들을 조회
	 * @param input {@link CMR001SVC00In}
	 * @return 수신자 목록을 포함한 OMM {@link CMR001SVC00Out}
	 * @throws ApplicationException
	 */
	public CMR001SVC00Out getSMSReceivers(CMR001SVC00In input) throws ApplicationException {
		
		//입력값 체크
		if(input == null) {
			/*
			 * 기본메시지:수신자들을 조회할 업무적 구분값이 필요합니다.
			 * 부가메시지:KDB생명 서비스 ID, 이케어 서비스번호(IT 업무 담당자에게 확인요청 필요)
			 * SMS 업무수신자를 조회시 조회에 필요한 조건값이 없을 경우 발생
			 */
			throw new ApplicationException("APCME0046", null);
		}
		
		List<TBCMETC008Io> smsReceiverList = getSMSReceiverList(input.getLinalifeSvcId(), input.getEcaSvcNo());
		
		CMR001SVC00Out cmr001svc00out = new CMR001SVC00Out();
		
		cmr001svc00out.setSmsReceEmplCnt(smsReceiverList != null ? smsReceiverList.size() : 0);
		cmr001svc00out.setSmsReceEmplList(smsReceiverList);
		
		return cmr001svc00out;
	}
	
	/**
	 * 라이나생명 서비스 ID와 이케어서비스번호를 통해서 SMS 업무알림을 받을 수신자를 조회하여 리턴
	 * @param linalifeSvcId 라이나생명 서비스 ID
	 * @param ecaSvcNo 이케어 서비스 번호
	 * @return
	 * @throws ApplicationException
	 */
	private List<TBCMETC008Io> getSMSReceiverList(final String linalifeSvcId, final BigDecimal ecaSvcNo) throws ApplicationException {
		
		logger.debug("SMS 수신인 목록 조회를 시작합니다.(라이나생명서비스ID:{} / 이케어서비스번호:{})", linalifeSvcId, ecaSvcNo);
		
		//입력값 체크
		if(StringUtils.isEmpty(linalifeSvcId) || (ecaSvcNo == null || ecaSvcNo.intValue() < 0)) {
			/*
			 * 기본메시지:수신자들을 조회할 업무적 구분값이 필요합니다.
			 * 부가메시지:KDB생명 서비스 ID, 이케어 서비스번호(IT 업무 담당자에게 확인요청 필요)
			 * SMS 업무수신자를 조회시 조회에 필요한 조건값이 없을 경우 발생
			 */
			throw new ApplicationException("APCME0046", null);
		}
		
		List<TBCMETC008Io> smsReceiverList = cmr002dbio.selectMultiTBCMETC008a(linalifeSvcId, ecaSvcNo, null, null);
		SecuUtil.doDecList(smsReceiverList);
		
		logger.debug("SMS 수신인 조회 결과건수:{}", smsReceiverList != null ? smsReceiverList.size() : 0);
		
		return smsReceiverList;
	}
	
	/**
	 * SMS 업무 알림을 받을 사람들의 정보를 저장(입력)
	 * @param input {@link CMR001SVC00In}
	 * @throws ApplicationException
	 */
	public int saveSMSReceiverInfo(CMR001SVC00In input) throws ApplicationException {
		
		if(input == null) {
			/*
			 * 기본메시지:SMS 업무알림을 받을 수신자 정보가 없습니다.
			 * 부가메시지:{0}
			 * UI에서 저장할 정보를 받지 못한 경우에 발생
			 */
			throw new ApplicationException("APCME0047", new Object[]{}, new Object[]{});
		}
		
		int savingTargetInfoCount = input.getSmsReceEmplList() != null ? input.getSmsReceEmplList().size() : 0;
		int savingSuccessCount = 0;
		
		logger.debug("SMS 수신인 정보 저장 대상건수:{}", savingTargetInfoCount);
		
		for(int i=0;i<savingTargetInfoCount;i++) {
			
			TBCMETC008Io receiverInfo = input.getSmsReceEmplList().get(i);
			
			//SMS 수신자 정보 건별 저장
			savingSuccessCount += saveSMSReceiverInfo(receiverInfo);
		}
		
		return savingSuccessCount;
	}
	
	/**
	 * SMS 업무 알림을 받을 사람의 정보를 저장(입력)
	 * @param receiverInfo SMS 업무 알림을 받을 사람의 정보를 가진 {@link TBCMETC008Io}
	 * @throws ApplicationException
	 */
	private int saveSMSReceiverInfo(TBCMETC008Io receiverInfo) throws ApplicationException {
		
		logger.debug("SMS 수신자 정보 추가를 시작합니다.");
		
		if(StringUtils.isEmpty(receiverInfo.getLinalifeSvcId())) {
			/*
			 * 기본메시지:SMS 업무알림을 받을 수신자 정보가 없습니다.
			 * 부가메시지:{0}
			 * UI에서 저장할 정보를 받지 못한 경우에 발생
			 */
			throw new ApplicationException("APCME0047", new Object[]{}, new Object[]{"KDB생명 서비스 ID가 필요합니다."});
		}
		
		if(receiverInfo.getEcaSvcNo() == null || receiverInfo.getEcaSvcNo().intValue() < 0) {
			/*
			 * 기본메시지:SMS 업무알림을 받을 수신자 정보가 없습니다.
			 * 부가메시지:{0}
			 * UI에서 저장할 정보를 받지 못한 경우에 발생
			 */
			throw new ApplicationException("APCME0047", new Object[]{}, new Object[]{"이케어 서비스 번호가 필요합니다."});
		}
		
		if(StringUtils.isEmpty(receiverInfo.getEno())) {
			/*
			 * 기본메시지:SMS 업무알림을 받을 수신자 정보가 없습니다.
			 * 부가메시지:{0}
			 * UI에서 저장할 정보를 받지 못한 경우에 발생
			 */
			throw new ApplicationException("APCME0047", new Object[]{}, new Object[]{"사원번호가 필요합니다."});
		}
		
		if(StringUtils.isEmpty(receiverInfo.getEmplNm())) {
			/*
			 * 기본메시지:SMS 업무알림을 받을 수신자 정보가 없습니다.
			 * 부가메시지:{0}
			 * UI에서 저장할 정보를 받지 못한 경우에 발생
			 */
			throw new ApplicationException("APCME0047", new Object[]{}, new Object[]{"사원명이 필요합니다."});
		}
		
		if(StringUtils.isEmpty(receiverInfo.getChrgEmplReceMpno())) {
			/*
			 * 기본메시지:SMS 업무알림을 받을 수신자 정보가 없습니다.
			 * 부가메시지:{0}
			 * UI에서 저장할 정보를 받지 못한 경우에 발생
			 */
			throw new ApplicationException("APCME0047", new Object[]{}, new Object[]{"담당사원수신 휴대전화번호가 필요합니다."});
		}
		
		//KDB생명 서비스 ID, 이케어 서비스번호, 사원번호로 기존에 저장된 내역이 있는지 확인
		String maxSrno = cmr002dbio.selectOneTBCMETC008b(receiverInfo.getLinalifeSvcId(), receiverInfo.getEcaSvcNo(), receiverInfo.getEno());
		
		if(StringUtils.isEmpty(maxSrno))
			maxSrno = "S001";
		else
			maxSrno = "S" + StringUtils.lpad(String.valueOf(Integer.parseInt(maxSrno.substring(1)) + 1), 3, "0");
		
		receiverInfo.setSrno(maxSrno);
		receiverInfo.setLastChgrId(FwUtil.getUserId());
		receiverInfo.setLastChgPgmId(FwUtil.getPgmId());
		receiverInfo.setLastChgTrmNo(FwUtil.getTrmNo());
		
		logger.debug("SMS 업무알림 수신자 정보:{}", receiverInfo);
		
		SecuUtil.doEncObject(receiverInfo);
		
		int addCount = cmr002dbio.insertOneTBCMETC008a(receiverInfo);
		
		if(addCount != 1) {
			/*
			 * 기본메시지:SMS 업무알림 수신자 정보를 저장하지 못 했습니다.
			 * 부가메시지:저장에 실패한 정보는 다음과 같습니다.
			 * {0}
			 * SMS 업무알림 수신자 정보를 저장하지 못 했을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0048", new Object[]{}, new Object[]{receiverInfo});
		}
		
		return addCount;
	}
	
	/**
	 * SMS 업무 알림을 받을 사람들의 정보를 저장(수정)
	 * @param input {@link CMR001SVC00In}
	 * @return 수정성공건수
	 * @throws ApplicationException
	 */
	public int modifySMSReceiverInfo(CMR001SVC00In input) throws ApplicationException {
		
		if(input == null) {
			/*
			 * 기본메시지:SMS 수신자정보 수정에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 수정 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0051", new Object[]{}, new Object[]{});
		}
		
		int modifyTargetInfoCount = input.getSmsReceEmplList() != null ? input.getSmsReceEmplList().size() : 0;
		int modifySuccessCount = 0;
		
		logger.debug("SMS 수신인 정보 수정 대상건수:{}", modifyTargetInfoCount);
		
		for(int i=0;i<modifyTargetInfoCount;i++) {
			
			TBCMETC008Io receiverInfo = input.getSmsReceEmplList().get(i);
			
			//SMS 수신자 정보 건별 수정
			modifySuccessCount += modifySMSReceiverInfo(receiverInfo);
		}
		
		return modifySuccessCount;
	}
	
	/**
	 * SMS 업무 알림을 받을 사람들의 정보를 저장(수정)
	 * @param receiverInfo
	 * @return
	 * @throws ApplicationException
	 */
	private int modifySMSReceiverInfo(TBCMETC008Io receiverInfo) throws ApplicationException {
		
		logger.debug("SMS 수신자 정보 수정을 시작합니다.");
		
		if(StringUtils.isEmpty(receiverInfo.getLinalifeSvcId())) {
			/*
			 * 기본메시지:SMS 수신자정보 수정에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 수정 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0051", new Object[]{}, new Object[]{"KDB생명 서비스 ID가 필요합니다."});
		}
		
		if(receiverInfo.getEcaSvcNo() == null || receiverInfo.getEcaSvcNo().intValue() < 0) {
			/*
			 * 기본메시지:SMS 수신자정보 수정에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 수정 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0051", new Object[]{}, new Object[]{"이케어 서비스 번호가 필요합니다."});
		}
		
		if(StringUtils.isEmpty(receiverInfo.getEno())) {
			/*
			 * 기본메시지:SMS 수신자정보 수정에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 수정 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0051", new Object[]{}, new Object[]{"사원번호가 필요합니다."});
		}
		
		if(StringUtils.isEmpty(receiverInfo.getSrno())) {
			/*
			 * 기본메시지:SMS 수신자정보 수정에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 수정 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0051", new Object[]{}, new Object[]{"일련번호가 필요합니다."});
		}
		
		if(StringUtils.isEmpty(receiverInfo.getEmplNm()) && StringUtils.isEmpty(receiverInfo.getChrgEmplReceMpno())) {
			/*
			 * 기본메시지:SMS 수신자정보 수정에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 수정 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0051", new Object[]{}
			, new Object[]{"사원명이나 담당사원수신휴대전화번호 두개 항목 중에 한개는 있어야 합니다."});
		}
		
		receiverInfo.setLastChgPgmId(FwUtil.getPgmId());
		receiverInfo.setLastChgrId(FwUtil.getUserId());
		receiverInfo.setLastChgTrmNo(FwUtil.getTrmNo());
		
		SecuUtil.doEncObject(receiverInfo);
		int modifyCount = cmr002dbio.updateOneTBCMETC008b(receiverInfo);
		
		logger.debug("변경처리건수:{}", modifyCount);
		
		if(modifyCount != 1) {
			/*
			 * 기본메시지:SMS 수신자 정보 수정을 하지 못 했습니다.
			 * 부가메시지:수정에 실패한 정보는 다음과 같습니다.
			 * {0}
			 * SMS 업무알림 수신자 정보를 수정하지 못 했을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0052", new Object[]{}, new Object[]{modifyCount});
		}
		
		return modifyCount;
	}
	
	/**
	 * SMS 업무 수신자 정보를 삭제
	 * @param input {@link CMR001SVC00In}
	 * @throws ApplicationException
	 */
	public int deleteSMSReceiverInfo(final CMR001SVC00In input) throws ApplicationException {
		
		if(input == null) {
			/*
			 * 기본메시지:SMS 수신자정보 삭제에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 삭제 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0049", new Object[]{}, new Object[]{});
		}
		
		int deleteTargetInfoCount = input.getSmsReceEmplList() != null ? input.getSmsReceEmplList().size() : 0;
		int deleteSuccessCount = 0;
		
		logger.debug("SMS 업무 수신자 정보 삭제 대상건수:{}", deleteTargetInfoCount);
		
		for(int i=0;i<deleteTargetInfoCount;i++) {
			
			TBCMETC008Io deleteTargetInfo = input.getSmsReceEmplList().get(i);
			
			//SMS 수신자 정보 삭제처리
			deleteSuccessCount += deleteSMSReceiverInfo(deleteTargetInfo.getLinalifeSvcId(), deleteTargetInfo.getEcaSvcNo()
					, deleteTargetInfo.getEno(), deleteTargetInfo.getSrno());
		}
		
		return deleteSuccessCount;
	}
	
	/**
	 * SMS 업무 수신자 정보를 삭제처리
	 * @param linalifeSvcId
	 * @param ecaSvcNo
	 * @param eno
	 * @param srno
	 * @throws ApplicationException
	 */
	private int deleteSMSReceiverInfo(final String linalifeSvcId, final BigDecimal ecaSvcNo, final String eno, final String srno)
			throws ApplicationException {
		
		logger.debug("SMS 수신자 정보 삭제를 시작합니다.");
		
		if(StringUtils.isEmpty(linalifeSvcId)) {
			/*
			 * 기본메시지:SMS 수신자정보 삭제에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 삭제 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0049", new Object[]{}, new Object[]{"KDB생명 서비스 ID가 필요합니다."});
		}
		
		if(ecaSvcNo == null || ecaSvcNo.intValue() < 0) {
			/*
			 * 기본메시지:SMS 수신자정보 삭제에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 삭제 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0049", new Object[]{}, new Object[]{"이케어 서비스 번호가 필요합니다."});
		}
		
		if(StringUtils.isEmpty(eno)) {
			/*
			 * 기본메시지:SMS 수신자정보 삭제에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 삭제 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0049", new Object[]{}, new Object[]{"사원번호가 필요합니다."});
		}
		
		if(StringUtils.isEmpty(srno)) {
			/*
			 * 기본메시지:SMS 수신자정보 삭제에 필요한 정보가 불충분 합니다.
			 * 부가메시지:{0}
			 * SMS 수신자정보 삭제 처리시 입력값 체크에서 필요 정보가 없을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0049", new Object[]{}, new Object[]{"사원명이 필요합니다."});
		}
		
		TBCMETC008Io deleteTargetInfo = new TBCMETC008Io();
		deleteTargetInfo.setLinalifeSvcId(linalifeSvcId);
		deleteTargetInfo.setEcaSvcNo(ecaSvcNo);
		deleteTargetInfo.setEno(eno);
		deleteTargetInfo.setSrno(srno);
		deleteTargetInfo.setLastChgrId(FwUtil.getUserId());
		deleteTargetInfo.setLastChgPgmId(FwUtil.getPgmId());
		deleteTargetInfo.setLastChgTrmNo(FwUtil.getTrmNo());
		
		int deleteCount = cmr002dbio.updateOneTBCMETC008a(deleteTargetInfo);
		
		logger.debug("삭제처리건수:{}", deleteCount);
		
		if(deleteCount != 1) {
			/*
			 * 기본메시지:SMS 수신자 정보 삭제를 하지 못 했습니다.
			 * 부가메시지:삭제에 실패한 정보는 다음과 같습니다.
			 * {0}
			 * SMS 업무알림 수신자 정보를 삭제하지 못 했을때 발생하는 메시지
			 */
			throw new ApplicationException("APCME0050", new Object[]{}, new Object[]{deleteTargetInfo});
		}
		
		return deleteCount;
	}
}