/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue May 03 18:35:08 KST 2016
 */
package cigna.cm.r.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/r/dbio/CMR002DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMR002DBIO
{

	/**
	 * @TestValues 	linalifeSvcId=1;	ecaSvcNo=2;	eno=3;	srno=4;
	 */
	java.util.List<cigna.cm.r.io.TBCMETC008Io> selectMultiTBCMETC008a(@Param("linalifeSvcId")
	java.lang.String linalifeSvcId, @Param("ecaSvcNo")
	java.math.BigDecimal ecaSvcNo, @Param("eno")
	java.lang.String eno, @Param("srno")
	java.lang.String srno);

	/**
	 * @TestValues 	linalifeSvcId=1;	ecaSvcNo=2;	eno=3;	srno=4;	emplNm=5;	chrgEmplReceMpno=6;	delYn=;	lastChgDtm=;	lastChgrId=7;	lastChgPgmId=8;	lastChgTrmNo=9;
	 */
	int insertOneTBCMETC008a(cigna.cm.r.io.TBCMETC008Io tBCMETC008Io);

	/**
	 * @TestValues 	linalifeSvcId=1;	ecaSvcNo=2;	eno=3;
	 */
	java.lang.String selectOneTBCMETC008b(
			@Param("linalifeSvcId")
			java.lang.String linalifeSvcId, @Param("ecaSvcNo")
			java.math.BigDecimal ecaSvcNo, @Param("eno")
			java.lang.String eno);

	/**
	 * @TestValues 	linalifeSvcId=1;	ecaSvcNo=2;	eno=3;	srno=4;	emplNm=;	chrgEmplReceMpno=;	delYn=;	lastChgDtm=;	lastChgrId=5;	lastChgPgmId=6;	lastChgTrmNo=7;
	 */
	int updateOneTBCMETC008a(
			cigna.cm.r.io.TBCMETC008Io tBCMETC008Io);

	/**
	 * @TestValues 	linalifeSvcId=;	ecaSvcNo=222;	eno=111;	srno=11;	emplNm=;	chrgEmplReceMpno=01046645077;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMETC008b(cigna.cm.r.io.TBCMETC008Io tBCMETC008Io);
}