package cigna.cm.r.service;

import cigna.cm.r.bean.CMR010BEAN;
import cigna.cm.r.io.CMR001SVC00In;
import cigna.cm.r.io.CMR001SVC00Out;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.r.service.CMR001SVC.java
 * @filetype     java source file
 * @brief
 * @author       김정국
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김정국                 2015. 5. 28.       신규 작성
 *
 */
@KlafService("CMR001SVC")
public class CMR001SVC {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMR010BEAN cmr002bean;
	
	/**
	 * SMS 수신자를 조회하여 리턴
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMR001SVC00Out selectList0(CMR001SVC00In input) throws ApplicationException {
		
		//업무알림 SMS 수신자 목록 조회
		CMR001SVC00Out output = cmr002bean.getSMSReceivers(input);
		
		//조회된 내용이 없는 경우, 오류처리하려면
		if(output.getSmsReceEmplCnt() == null || output.getSmsReceEmplCnt() == 0) {
			//KIOKI0004:요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		else {
			//KIOKI0002:요청하신 내용 {0}건이 조회 되었습니다.
			LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getSmsReceEmplCnt()}, null);
		}
		
		return output;
	}
	
	/**
	 * SMS 수신자 정보를 저장
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate0")
	@TransactionalOperation
	public void changeUpdate0(CMR001SVC00In input) throws ApplicationException {

		//업무알림 SMS 수신자 정보를 저장
		int savingCount = cmr002bean.saveSMSReceiverInfo(input);

		/*
		 * 기본메시지:정상적으로 {0}건이 처리 되었습니다.
		 */
		LApplicationContext.addMessage("APCMI0000", new Object[]{savingCount}, null);
	}
	
	/**
	 * SMS 수신자 정보를 수정
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate1")
	@TransactionalOperation
	public void changeUpdate1(CMR001SVC00In input) throws ApplicationException {
		
		//업무알림 SMS 수신자 정보를 저장(수정)
		int savingCount = cmr002bean.modifySMSReceiverInfo(input);

		/*
		 * 기본메시지:정상적으로 {0}건이 처리 되었습니다.
		 */
		LApplicationContext.addMessage("APCMI0000", new Object[]{savingCount}, null);
	}
	
	/**
	 * SMS 수신자 정보를 삭제
	 * @param input
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate2")
	@TransactionalOperation
	public void changeUpdate2(CMR001SVC00In input) throws ApplicationException {
		
		int deleteCount = cmr002bean.deleteSMSReceiverInfo(input);
		
		/*
		 * 기본메시지:정상적으로 {0} 건이 삭제 되었습니다.
		 */
		LApplicationContext.addMessage("KIOKI0018", new Object[]{deleteCount}, null);
	}
}