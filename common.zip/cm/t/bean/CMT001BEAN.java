package cigna.cm.t.bean;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;
import klaf.transaction.Propagation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA004BEAN;
import cigna.cm.t.dbio.CMT001DBIO;
import cigna.cm.t.domain.BfFininRegCtntAddInqDO;
import cigna.cm.t.domain.BfFininRegCtntInqDO;
import cigna.cm.t.domain.RlvActNoRegCtntInqDO;
import cigna.cm.t.domain.SavgKcdDetlDtlcAddInqDO;
import cigna.cm.t.domain.SavgKcdDetlDtlcInqDO;
import cigna.cm.t.domain.SavgKcdDetlRegCtntInqDO;
import cigna.cm.t.domain.TaxPfrLmtInqDO;
import cigna.cm.t.domain.TaxpfCorrcDO;
import cigna.cm.t.domain.TaxpfDelDO;
import cigna.cm.t.domain.TaxpfRegDO;
import cigna.cm.t.domain.TaxpfReptMtrDO;
import cigna.cm.t.domain.TaxpfRescsCnclDO;
import cigna.cm.t.domain.TaxpfRescsDO;
import cigna.cm.t.domain.TaxpfSavgKndClLmtInqDO;
import cigna.cm.t.io.COM_F_KLIOAKOTS00001In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00004In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00004Sub0;
import cigna.cm.t.io.COM_F_KLIOAKOTS00006In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00007In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00008In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00010In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00013In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00013Sub0;
import cigna.cm.t.io.COM_F_KLIOSKOTS00002In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00002Sub0;
import cigna.cm.t.io.COM_F_KLIOSKOTS00003In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00003Sub0;
import cigna.cm.t.io.COM_F_KLIOSKOTS00005In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00005Sub0;
import cigna.cm.t.io.COM_F_KLIOSKOTS00009In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00011In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00012In;
import cigna.cm.t.io.SelectOneTBCNETC0010Out;
import cigna.cm.t.io.SelectOntTBCNETC026bOut;
import cigna.cm.t.io.SelectOntTBCNETC035aOut;
import cigna.cm.t.io.TBCNETC026Io;
import cigna.cm.t.io.TBCNETC035Io;
import cigna.zz.CommonCons;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;



/**
 * @file         cigna.ai.z.bean.AIZBA1BEAN.java
 * @filetype     java source file
 * @brief        세금우대 통합처리 BEAN
 * @author       연제경
 * @version      0.2
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.2           연제경                 2013. 7. 16.      추가 작성
 *
 */
@KlafBean
public class CMT001BEAN {

	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	@Autowired
	private CMA004BEAN cma004bean;		// 채번관련 BEAN
	
	@Autowired
	private CMT001DBIO cmt001dbio;		// DBIO BEAN
	
	/**
	 * 세금우대저축종류별한도조회
	 * 
	 * @param  TaxpfSavgKndClLmtInqDO 세금우대저축종류별한도조회DO
	 * @return TaxpfSavgKndClLmtInqDO 세금우대저축종류별한도조회DO
	 * @throws ApplicationException
	 */
	public TaxpfSavgKndClLmtInqDO taxpfSavgKndClLmtInq(TaxpfSavgKndClLmtInqDO input
			) throws ApplicationException {
		
		return this.taxpfSavgKndClLmtInq(input, "S");
	}
	
	/**
	 * 세금우대저축종류별한도조회
	 * 
	 * @param  TaxpfSavgKndClLmtInqDO 세금우대저축종류별한도조회DO
	 * @return TaxpfSavgKndClLmtInqDO 세금우대저축종류별한도조회DO
	 * @throws ApplicationException
	 */
	public TaxpfSavgKndClLmtInqDO taxpfSavgKndClLmtInq(TaxpfSavgKndClLmtInqDO input, String type
			) throws ApplicationException {
		
		TaxpfSavgKndClLmtInqDO output = new TaxpfSavgKndClLmtInqDO();
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00001";	// EAI Interface ID
		COM_F_KLIOAKOTS00001In request = new COM_F_KLIOAKOTS00001In();	// 세금우대한도조회 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		//필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getLmtInqSavgKnd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"한도조회저축종류"}, new Object[]{ "세금우대전문", "한도조회저축종류" });
		}
		if (StringUtils.isEmpty(input.getInfoMnbdyDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"정보주체(구장애인)구분"}, new Object[]{ "세금우대전문", "정보주체(구장애인)구분" });
		}
		if (StringUtils.isEmpty(input.getIncmrDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"저소득자구분(농어가저축)"}, new Object[]{ "세금우대전문", "저소득자구분(농어가저축)" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		//정합성체크
		// 주민등록번호 암호화된 값으로 들어오므로 13자리 체크로직 주석처리 (2016/10/19)
//		if (input.getRrno().length() != 13) {
//			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
//		}
		if (!("1".equals(input.getRrnoDvsn()) || "2".equals(input.getRrnoDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getLmtInqSavgKnd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"한도조회저축종류"}, new Object[]{ "세금우대전문", "한도조회저축종류" });
		}
		if (input.getInfoMnbdyDvsn().length() != 1) {
			throw new ApplicationException( "APCME0005", new Object[]{"정보주체(구장애인)구분"}, new Object[]{ "세금우대전문", "정보주체(구장애인)구분" });
		}
		if (!("1".equals(input.getIncmrDvsn()) || "0".equals(input.getIncmrDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"저소득자구분(농어가저축)"}, new Object[]{ "세금우대전문", "저소득자구분(농어가저축)" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input ------------//
		//처리일시
		String prcsDtm 						= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String taxpfTgmNo 				= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);
		String prcsDt	 						= prcsDtm.substring(0,8);				//처리일자
		String dpsTxNo 						= "";														//입금거래번호
		String prcsDofOrgNo 			= input.getPrcsDofOrgNo();			//처리지점조직번호
		String prcsFofOrgNo 				= input.getPrcsFofOrgNo();				//처리영업소조직번호
		String prcsEno							= input.getPrcsEno();						//처리사원번호
		String contNo							= "";														//계약번호
		String savgPrdcd						= "";														//저축상품코드
		String prcsYn							= " ";														//처리여부
		String taxpfRcd						= " ";														//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 				= "0200";												//세금우대전문종류코드
		String taxpfBzDcd					= "205";													//세금우대업무구분코드
		String taxpfBzPrcsDcd 			= input.getTaxpfBzPrcsDcd();			//세금우대업무처리구분코드	
		String nrmCnclDcd					= "0";														//정상취소구분코드
		String taxpfTgmDataCtnt 	= " ";														//세금우대전문데이터내용
		int dataLength 						= 0;															//DATA LENGTH
		String strDataLength 			= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();										//저축상품코드
		}
		
	    //데이터 길이
		dataLength = 13 + 1 + 2 + 1 + 1 + 40 + 20 + 1 + 10 + 10 + 7;													//input.getRrno().length() + input.getRrnoDvsn().length() + input.getLmtInqSavgKnd().length() + input.getInfoMnbdyDvsn().length() + input.getIncmrDvsn().length();
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {                     
			
//			taxpfTgmNo = "0" + taxpfTgmNo;

			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
			    	/** 오픈시 변경!! */
			        request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
			request.setSysId						("KL");										//SYSTEM-ID
			request.setTgmKndCd			(taxpfTgmKcd);						//전문종별코드
			request.setAssoBusiGb			(taxpfBzDcd);							//업무구분코드
			request.setTrnsDtm				(prcsDtm); 								//전문전송일시
			request.setMgntTgmCd		(taxpfTgmNo); 						//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd			("L51"); 										//송신기관코드
			request.setRcvInstCd				("L00"); 										//수신기관코드
			request.setAssoTrnsGb			("      "); 										//거래구분코드	 		- 공백[6](AS-IS동일)
			request.setDataLen				(strDataLength); 					//DATA LENGTH			
			request.setTerId						("LINA-ID   "); 							//단말기ID					- 공백[10](AS-IS동일)
			request.setTerOpId				("KLICS-ID  "); 							//단말기조작자ID		- 공백[10](AS-IS동일)
			request.setTerOwnNm			("LINA                "); 					//단말기조작자성명	- 공백[20](AS-IS동일)
			request.setDataEtc					("            "); 								//예비필드					- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno						(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn				(input.getRrnoDvsn());																	// set [주민(사업자)등록번호구분]
			request.setLmtInqSavgKnd	(input.getLmtInqSavgKnd());														// set [한도조회저축종류]
			request.setInfoMnbdyDvsn	(input.getInfoMnbdyDvsn());														// set [정보주체(구장애인)구분]
			request.setIncmrDvsn			(input.getIncmrDvsn());																// set [저소득자구분(농어가저축)]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));					// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm							(prcsDtm);										//처리일시
			tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);								//세금우대전문번호
			tbcnetc026io.setPrcsDt							(prcsDt);											//처리일자
			tbcnetc026io.setDpsTxNo						(dpsTxNo);										//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo				(prcsDofOrgNo);								//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo				(prcsFofOrgNo);								//처리영업소조직번호
			tbcnetc026io.setPrcsEno							(prcsEno);											//처리사원번호
			tbcnetc026io.setContNo							(contNo);											//계약번호
			tbcnetc026io.setSavgPrdcd						(savgPrdcd);										//저축상품코드
			tbcnetc026io.setPrcsYn							(prcsYn);											//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);										//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);								//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);									//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd			(taxpfBzPrcsDcd);							//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);									//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);						//세금우대전문데이터내용
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			tbcnetc026io.setRdsnBznoDcd				(input.getRrnoDvsn());					//주민사업자등록번호구분코드
			tbcnetc026io.setLmtInqSavgKndVl		(input.getLmtInqSavgKnd());		//한도조회저축종류값
			tbcnetc026io.setInfoMnbdyDcd			(input.getInfoMnbdyDvsn());		//정보주체구분코드
			tbcnetc026io.setLrnkIncmrDcd				(input.getIncmrDvsn());				//하위소득자구분코드
			
			tbcnetc026io.setLastChgrId					(FwUtil.getUserId());						// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId				(FwUtil.getPgmId());						// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo			(FwUtil.getTrmNo());						// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
			//response = InfUtil.callFEP(request, interfaceId, COM_F_KLIOSKOTS00001In.class);
			InfUtil.callAsyncFEP(request, interfaceId);
			
			//type : S - sync
			if ("S".equals(type)) {
				output = this.getTaxpfSavgKndClLmtRece(prcsDt, taxpfTgmNo);
			}
			
		} catch (EisExecutionException e) {
			
			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		
		

		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대저축종류별한도조회 수신결과
	 * @param prcsDtm,taxpfTgmNo 
	 * @return TaxpfSavgKndClLmtInqDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public TaxpfSavgKndClLmtInqDO getTaxpfSavgKndClLmtRece(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		TaxpfSavgKndClLmtInqDO output = new TaxpfSavgKndClLmtInqDO();
		
		logger.debug("call TaxpfSavgKndClLmtInqDO");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    //세금우대
			    TaxpfSavgKndClLmtInqDO taxpfSavgKndClLmtInq  = null;
				
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( null != out ) {
					
					taxpfSavgKndClLmtInq = new TaxpfSavgKndClLmtInqDO();
					
					taxpfSavgKndClLmtInq.setTgmKndCd						(out.getTaxpfTgmKcd());						// set [전문종별코드]
					taxpfSavgKndClLmtInq.setAssoBusiGb					(out.getTaxpfBzDcd());							// set [협회업무구분]
					taxpfSavgKndClLmtInq.setTrnsDtm							(out.getPrcsDtm());								// set [전문전송일시]
					taxpfSavgKndClLmtInq.setMgntTgmCd					(out.getTaxpfTgmNo().toString());	// set [전문관리번호]
					taxpfSavgKndClLmtInq.setSndInstCd						("L51");														// set [전송기관코드]
					taxpfSavgKndClLmtInq.setRcvInstCd						("L00");														// set [수신기관코드]
					taxpfSavgKndClLmtInq.setAssoRspCd						(out.getTaxpfRcd());								// set [협회응답코드]
					
					taxpfSavgKndClLmtInq.setRrnoDvsn						(out.getRdsnBznoDcd());						// set [주민(사업자)등록번호구분]
					taxpfSavgKndClLmtInq.setConm								(out.getConmNm());								// set [상호(기업체명)]
					taxpfSavgKndClLmtInq.setName								(out.getTaxpfTgtpNm());						// set [성명(대표자)]
					taxpfSavgKndClLmtInq.setRlvSavgKndDupYn		(out.getSavgKndDupVl());					// set [해당저축종류중복여부]
					taxpfSavgKndClLmtInq.setSavgKndClEntAmt		(out.getSavgCtgyEntAmt());				// set [저축종류별가입금액]
					taxpfSavgKndClLmtInq.setSavgKndClUusdAmt	(out.getSavgCtgyUusdAmt());			// set [저축종류별미사용금액]
					taxpfSavgKndClLmtInq.setEntInstOffcCd				(out.getEntInstOffcId());						// set [가입기관점포코드]
					
					taxpfSavgKndClLmtInq.setSavgKndEntSamt			(out.getInqReqSavgKndEntSamt());			// set [조회요청저축종류가입합계금액]
					taxpfSavgKndClLmtInq.setSavgKndLmtAmt			(out.getInqReqSavgKndLmtAmt());			// set [조회요청저축종류한도금액]
					taxpfSavgKndClLmtInq.setSavgKndLmtRmnAmt	(out.getInqReqSavgKndLmtRmnAmt());	// set [조회요청저축종류한도잔여금액]
					
					output = taxpfSavgKndClLmtInq;
					
					// 결과코드가 들어오는 경우
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
				}
			}
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 세금우대저축종류별한도조회 수신(0210/205)
	 * 
	 * @param  TaxpfSavgKndClLmtInqDO 세금우대저축종류별한도조회DO
	 * @return TaxpfSavgKndClLmtInqDO 세금우대저축종류별한도조회DO
	 * @throws ApplicationException
	 */
	public void setTaxpfSavgKndClLmtInqRcv(COM_F_KLIOAKOTS00001In input
			) throws ApplicationException {
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		String prcsDt	 						= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		String prcsYn							= " ";														//처리여부
		String taxpfRcd						= " ";														//세금우대결과코드 - 응답코드
		String prcsDtm 						= "";														//처리일시
		String taxpfTgmNo 				= "";														//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd					= "0";														//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            			= input.getTrnsDtm();								//전문전송일시
		taxpfTgmNo         		= input.getMgntTgmCd();						//세금우대전문번호
		prcsYn 							= "Y";																//처리여부
		taxpfRcd 						= input.getAssoRspCd(); 							//세금우대결과코드 - 응답코드
		//taxpfTgmKcd 				= input.getTgmKndCd();							//세금우대전문종류코드
		//taxpfBzDcd					= input.getAssoBusiGb();							//세금우대업무구분코드
		//taxpfTgmDataCtnt		= new String(FwUtil.toBytes(input));	//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt						(prcsDt);													//처리일자
		tbcnetc026io.setTaxpfTgmNo			(taxpfTgmNo);										//세금우대전문번호
		tbcnetc026io.setPrcsDtm						(prcsDtm);												//처리일시
		tbcnetc026io.setPrcsYn						(prcsYn);													//처리여부
		tbcnetc026io.setTaxpfRcd					(taxpfRcd);												//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd			(nrmCnclDcd);											//정상취소구분코드
		tbcnetc026io.setRdsnBznoDcd			(input.getRrnoDvsn());							//주민(사업자)등록번호구분
		tbcnetc026io.setConmNm					(input.getConm());								//상호명
		tbcnetc026io.setTaxpfTgtpNm			(input.getName());								//세금우대대상자명
		tbcnetc026io.setSavgKndDupVl		(input.getRlvSavgKndDupYn());		//저축종류중복값
		tbcnetc026io.setSavgCtgyEntAmt	(input.getSavgKndClEntAmt());			//저축종별가입금액
		tbcnetc026io.setSavgCtgyUusdAmt	(input.getSavgKndClUusdAmt());		//저축종별미사용금액
		tbcnetc026io.setEntInstOffcId			(input.getEntInstOffcCd());					//가입기관점포ID
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		//updateLog(tbcnetc026io);
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0261(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
			
	}
	
	/**
	 * 세금우대전금융기관등록내용조회
	 * 
	 * @param  BfFininRegCtntInqDO 세금우대전금융기관등록내용조회
	 * @return BfFininRegCtntInqDO 세금우대전금융기관등록내용조회
	 * @throws ApplicationException
	 */
	public BfFininRegCtntInqDO bfFininRegCtntInq(BfFininRegCtntInqDO input
			) throws ApplicationException {
		
		return bfFininRegCtntInq(input, "S");
		
	}
	/**
	 * 세금우대전금융기관등록내용조회
	 * 
	 * @param  BfFininRegCtntInqDO 세금우대전금융기관등록내용조회
	 * @return BfFininRegCtntInqDO 세금우대전금융기관등록내용조회
	 * @throws ApplicationException
	 */
	public BfFininRegCtntInqDO bfFininRegCtntInq(BfFininRegCtntInqDO input, String type
			) throws ApplicationException {
		
		BfFininRegCtntInqDO output = new BfFininRegCtntInqDO();

		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026 OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00002";						// EAI Interface ID
		
		COM_F_KLIOSKOTS00002In request = new COM_F_KLIOSKOTS00002In();	// 세금우대전금융기관등록내용조회 요청전문
		
		//2017.03.10;현승훈;GA에서 세금우대한도조회 시 주민등록번호 암호화
		//input.setRrno(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		// 필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		// 정합성체크
		/*
		if (input.getRrno().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (!("1".equals(input.getRrnoDvsn()) || "2".equals(input.getRrnoDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input START ------------//
		String prcsDtm 					= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 			= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		logger.debug("채번taxpfTgmNo IO  [{}]", new Object [] {taxpfTgmNo});
		
		String prcsDt	 					= prcsDtm.substring(0,8);																		//처리일자
		String dpsTxNo 					= "";																												//입금거래번호
		String prcsDofOrgNo 		= input.getPrcsDofOrgNo();																	//처리지점조직번호
		String prcsFofOrgNo			= input.getPrcsFofOrgNo();																		//처리영업소조직번호
		String prcsEno						= input.getPrcsEno();																				//처리사원번호
		String contNo						= "";																												//계약번호
		String savgPrdcd					= "";																												//저축상품코드
		String prcsYn						= " ";																												//처리여부
		String taxpfRcd					= " ";																												//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 			= "0200";																										//세금우대전문종류코드
		String taxpfBzDcd				= "210";																											//세금우대업무구분코드
		String taxpfBzPrcsDcd 		= input.getTaxpfBzPrcsDcd();																	//세금우대업무처리구분코드	
		String nrmCnclDcd				= "0";																												//정상취소구분코드
		String taxpfTgmDataCtnt	= " ";																												//세금우대전문데이터내용
		int dataLength 					= 0;																													//DATA LENGTH
		String strDataLength 		= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
		// ------------- 세금우대처리로그테이블 input END --------------//
		
	    // 데이터 길이
		dataLength = 13 + 1 + 40 + 20 + 1 + 1 + 10 + 10 + 1 + 2 + 1 + 2; 																//input.getRrno().length() + input.getRrnoDvsn().length();
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {
			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) {
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
			request.setSysId								("KL");																//SYSTEM-ID
			request.setTgmKndCd					(taxpfTgmKcd);												//전문종별코드
			request.setAssoBusiGb					(taxpfBzDcd);													//업무구분코드
			request.setTrnsDtm						(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)
					+ DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE)); 		//전문전송일시
			request.setMgntTgmCd				(taxpfTgmNo); 												//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd					("L51"); 																//송신기관코드
			request.setRcvInstCd						("L00"); 																//수신기관코드
			request.setAssoTrnsGb					("      "); 																//거래구분코드	 	- 공백[6](AS-IS동일)
			request.setDataLen						(strDataLength); 											//DATA LENGTH
			request.setTerId								("LINA-ID   "); 													//단말기ID		 	- 공백[10](AS-IS동일)
			request.setTerOpId						("KLICS-ID  "); 													//단말기조작자ID 	- 공백[10](AS-IS동일)
			request.setTerOwnNm					("LINA                "); 											//단말기조작자성명  - 공백[20](AS-IS동일)
			request.setDataEtc							("            "); 														//예비필드			- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno								
				(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));							// set [주민(사업자)등록번호]
			request.setRrnoDvsn						(input.getRrnoDvsn());									// set [주민(사업자)등록번호구분]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm							(prcsDtm);						//처리일시
			tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);				//세금우대전문번호
			tbcnetc026io.setPrcsDt							(prcsDt);							//처리일자
			tbcnetc026io.setDpsTxNo						(dpsTxNo);						//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo				(prcsDofOrgNo);				//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo				(prcsFofOrgNo);				//처리영업소조직번호
			tbcnetc026io.setPrcsEno							(prcsEno);							//처리사원번호
			tbcnetc026io.setContNo							(contNo);							//계약번호
			tbcnetc026io.setSavgPrdcd						(savgPrdcd);						//저축상품코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd			(taxpfBzPrcsDcd);			//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			tbcnetc026io.setRdsnBznoDcd				(input.getRrnoDvsn());	// set [주민(사업자)등록번호구분]
			
			tbcnetc026io.setLastChgrId					(FwUtil.getUserId());		// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId				(FwUtil.getPgmId());		// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo			(FwUtil.getTrmNo());		// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
			InfUtil.callAsyncFEP(request, interfaceId);
			
			//type : S - sync
			if ("S".equals(type)) {
				output = this.getBfFininRegCtntInq(prcsDt, taxpfTgmNo);
			}
			// ------------- 응답 전문 MOVE END --------------------- //
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));			// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);					//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);						//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);								//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);							//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);						//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);			//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});			
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		

		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대저축종류별한도조회 수신결과
	 * @param prcsDtm,taxpfTgmNo 
	 * @return TaxpfSavgKndClLmtInqDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public BfFininRegCtntInqDO getBfFininRegCtntInq(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		BfFininRegCtntInqDO output = new BfFininRegCtntInqDO();
		
		List<SelectOntTBCNETC035aOut>  outSub = new ArrayList<SelectOntTBCNETC035aOut>();
		
		List<TaxpfReptMtrDO> subResult = new ArrayList<TaxpfReptMtrDO>();					//ARRAY 값
		
		logger.debug("call TaxpfSavgKndClLmtInqDO");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    //세금우대
			    BfFininRegCtntInqDO bfFininRegCtntInq  = null;
				
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( null != out ) {
					
					bfFininRegCtntInq = new BfFininRegCtntInqDO();
					
					bfFininRegCtntInq.setTgmKndCd				(out.getTaxpfTgmKcd());									// set [전문종별코드]
					bfFininRegCtntInq.setAssoBusiGb				(out.getTaxpfBzDcd());										// set [협회업무구분]
					bfFininRegCtntInq.setTrnsDtm					(out.getPrcsDtm());											// set [전문전송일시]
					bfFininRegCtntInq.setMgntTgmCd			(out.getTaxpfTgmNo().toString());				// set [전문관리번호]
					bfFininRegCtntInq.setSndInstCd				("L51");																	// set [전송기관코드]
					bfFininRegCtntInq.setRcvInstCd					("L00");																	// set [수신기관코드]
					bfFininRegCtntInq.setAssoRspCd				(out.getTaxpfRcd());											// set [협회응답코드]
					
					bfFininRegCtntInq.setRrnoDvsn					(out.getRdsnBznoDcd());									// set [주민(사업자)등록번호구분]
					bfFininRegCtntInq.setConm						(out.getConmNm());											// set [상호(기업체명)]
					bfFininRegCtntInq.setName						(out.getTaxpfTgtpNm());									// set [성명(대표자)]
					bfFininRegCtntInq.setTaxpfDupYn			(out.getInqReqSavgKndDupVl());					// set [조회요청저축종류중복여부]
					bfFininRegCtntInq.setTaxpfEntAmt			(out.getInqReqSavgKndEntSamt());				// set [조회요청저축종류가입총액]
					bfFininRegCtntInq.setTaxpfLmtAmt			(out.getInqReqSavgKndLmtRmnAmt());		// set [조회요청저축종류한도잔여액]
					bfFininRegCtntInq.setTaxpfTtlRegCnt		
																(String.valueOf(out.getInqReqSavgKndTtlCnt()));					// set [조회요청저축종류총건수]
					
					outSub = cmt001dbio.selectOneTBCNETC035a(prcsDt, taxpfTgmNo);
					
					if (outSub !=null) {
						
						for(int j = 0; j < outSub.size(); j++){
							
							TaxpfReptMtrDO taxpfReptMtrDO = new TaxpfReptMtrDO();
							
							taxpfReptMtrDO.setRescsDcd					(outSub.get(j).getRescsDvsnVl()); 				// set [해지구분코드]
							taxpfReptMtrDO.setRegOffc						(outSub.get(j).getOpenOffcNm()); 				// set [등록점포]
							taxpfReptMtrDO.setActNo							(outSub.get(j).getActNo()); 							// set [계좌번호]
							taxpfReptMtrDO.setSavgKcd						(outSub.get(j).getSavgKndVl()); 					// set [저축종류]
							taxpfReptMtrDO.setSavgNewDt				(outSub.get(j).getSavgNewDt()); 					// set [저축신규일]
							taxpfReptMtrDO.setSavgLastChgDt			(outSub.get(j).getSavgLastChgDt()); 			// set [저축최종변경일]
							taxpfReptMtrDO.setTaxpfEntAmt				(outSub.get(j).getTaxpfEntAmt()); 				// set [세금우대가입금액]
							taxpfReptMtrDO.setExpiDt							(outSub.get(j).getExpiDt()); 							// set [만기일]
							taxpfReptMtrDO.setTaxpfRescsDt				(outSub.get(j).getTaxPfrRescsDt()); 				// set [세금우대해지일]
							taxpfReptMtrDO.setIntDividPayAmt			(outSub.get(j).getIntDivdPayAmt()); 			// set [이자배당지급액]
							taxpfReptMtrDO.setHeirYn							(outSub.get(j).getInhrtVl()); 							// set [상속여부]
							taxpfReptMtrDO.setHousPrpsDpstDcd	(outSub.get(j).getHousPrpsDpstDvsnVl());	// set [주택청약예부금구분]
							
							subResult.add(taxpfReptMtrDO);
							
						}	
						
						bfFininRegCtntInq.setTaxpfReptMtrDO(subResult);
						
					}
					
					output = bfFininRegCtntInq;
					
					// 결과코드가 들어오는 경우
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 세금우대 전 금융기관 등록내용 조회 수신(0210/210)
	 * 
	 * @param  COM_F_KLIOSKOTS00002In 세금우대 전 금융기관 등록내용 조회OMM
	 * @throws ApplicationException
	 */
	public void bfFininRegCtntInqRcv(COM_F_KLIOSKOTS00002In input
			) throws ApplicationException {
		
		List<COM_F_KLIOSKOTS00002Sub0> taxpfReptMtr = null;		// 세금우대회보사항
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();		// TBCNETC026       OMM
		
		String prcsYn							= " ";												//처리여부
		String taxpfRcd						= " ";												//세금우대결과코드 - 응답코드
		String prcsDtm 						= "";												//처리일시        
		String taxpfTgmNo 				= "";												//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd					= "0";												//정상취소구분코드
		String prcsDt	 						= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		
		logger.debug("수신전문 [{}]", input);
		
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm			= input.getTrnsDtm();						//전문전송일시
		taxpfTgmNo    = input.getMgntTgmCd();				//세금우대전문번호
		prcsYn 				= "Y";														//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 					//세금우대결과코드 - 응답코드
		//taxpfTgmKcd 		= input.getTgmKndCd();					//세금우대전문종류코드
		//taxpfBzDcd			= input.getAssoBusiGb();					//세금우대업무구분코드
		//taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
		
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) { 
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt											(prcsDt);																		//처리일자
		tbcnetc026io.setTaxpfTgmNo								(taxpfTgmNo);															//세금우대전문번호
		tbcnetc026io.setPrcsDtm											(prcsDtm);																	//처리일시
		tbcnetc026io.setPrcsYn											(prcsYn);																		//처리여부
		tbcnetc026io.setTaxpfRcd										(taxpfRcd);																	//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd								(nrmCnclDcd);																//정상취소구분코드
		tbcnetc026io.setRdsnBznoDcd								(input.getRrnoDvsn());												//주민(사업자)등록번호구분
		tbcnetc026io.setConmNm										(input.getConm());													//상호명
		tbcnetc026io.setTaxpfTgtpNm								(input.getName());													//세금우대대상자명
		tbcnetc026io.setInfoMnbdyDcd							(input.getInfoMnbdyDvsn());									//정보주체구분코드
		tbcnetc026io.setLrnkIncmrDcd								(input.getIncmrDvsn());											//하위소득자구분코드
		tbcnetc026io.setInqReqSavgKndLmtRmnAmt	(input.getTaxpfLmtAmt());										// set [세금우대한도잔여액]
		tbcnetc026io.setInqReqSavgKndEntSamt			(input.getTaxpfEntAmt());										// set [세금우대가입총액]
		tbcnetc026io.setInqReqSavgKndDupVl				(input.getTaxpfDupYn());										// set [세금우대중복여부]
		if( !StringUtils.isEmpty(input.getTaxpfTtlRegCnt()) )	{
			tbcnetc026io.setInqReqSavgKndTtlCnt			(Integer.parseInt(input.getTaxpfTtlRegCnt()));	// set [세금우대총등록건수]
		}
		
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		//updateLog(tbcnetc026io);
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0268(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
		
		//세금우대회보사항
		taxpfReptMtr = input.getTaxpfReptMtr();
		
		iResult = 0;
		
		for(int i = 0; i < input.getTaxpfReptCnt(); i++ ){
			
			TBCNETC035Io tbcnetc035io = new TBCNETC035Io();
			
			tbcnetc035io.setPrcsDt							(prcsDt); 																		// set [처리일시]
			tbcnetc035io.setTaxpfTgmNo				(Integer.parseInt(taxpfTgmNo)); 							// set [등록점포]
			tbcnetc035io.setRescsDvsnVl					(taxpfReptMtr.get(i).getRescsDcd()); 					// set [해지구분값]			
			tbcnetc035io.setOpenOffcNm				(taxpfReptMtr.get(i).getRegOffc());						// set [개설점포명]
			tbcnetc035io.setActNo							(SecuUtil.getEncValue(taxpfReptMtr.get(i).getActNo(), SecuUtil.EncType.actNo));	// set [계좌번호]
			tbcnetc035io.setSavgKndVl					(taxpfReptMtr.get(i).getSavgKcd());						// set [저축종류값]	
			tbcnetc035io.setSavgNewDt					(taxpfReptMtr.get(i).getSavgNewDt());				// set [저축신규일자]
			tbcnetc035io.setSavgLastChgDt			(taxpfReptMtr.get(i).getSavgLastChgDt());		// set [저축최종변경일자]
			tbcnetc035io.setTaxpfEntAmt				(taxpfReptMtr.get(i).getTaxpfEntAmt());			// set [세금우대가입금액]
			tbcnetc035io.setExpiDt							(taxpfReptMtr.get(i).getExpiDt());						// set [만기일자]
			tbcnetc035io.setTaxPfrRescsDt				(taxpfReptMtr.get(i).getTaxpfRescsDt());			// set [세금우대해지일자]
			tbcnetc035io.setIntDivdPayAmt			(taxpfReptMtr.get(i).getIntDividPayAmt());		// set [이자배당지급금액]
			tbcnetc035io.setInhrtVl							(taxpfReptMtr.get(i).getHeirYn());						// set [상속값]
			tbcnetc035io.setHousPrpsDpstDvsnVl	(taxpfReptMtr.get(i).getHousPrpsDpstDcd());	// set [주택청약예금구분값]
			
			tbcnetc035io.setLastChgrId					("KLI");																			// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc035io.setLastChgPgmId				("KLI");																			// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc035io.setLastChgTrmNo			("KLI");																			// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iResult = cmt001dbio.insertOneTBCNETC0350(tbcnetc035io);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
			}
			
		}
		
	}
	
	/**
	 * 세금우대전금융기관등록내용추가조회
	 * 
	 * @param  BfFininRegCtntAddInqDO 세금우대전금융기관등록내용추가조회
	 * @return BfFininRegCtntAddInqDO 세금우대전금융기관등록내용추가조회
	 * @throws ApplicationException
	 */
	public BfFininRegCtntAddInqDO bfFininRegCtntAddInq(BfFininRegCtntAddInqDO input
			) throws ApplicationException {
		return bfFininRegCtntAddInq(input, "S");
	}
	
	/**
	 * 세금우대전금융기관등록내용추가조회
	 * 
	 * @param  BfFininRegCtntAddInqDO 세금우대전금융기관등록내용추가조회
	 * @return BfFininRegCtntAddInqDO 세금우대전금융기관등록내용추가조회
	 * @throws ApplicationException
	 */
	public BfFininRegCtntAddInqDO bfFininRegCtntAddInq(BfFininRegCtntAddInqDO input, String type
			) throws ApplicationException {
		
		BfFininRegCtntAddInqDO output = new BfFininRegCtntAddInqDO();
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM

		String interfaceId = "COM_F_KLIOAKOTS00003";	// EAI Interface ID
		
		COM_F_KLIOSKOTS00003In request = new COM_F_KLIOSKOTS00003In();	// 세금우대전금융기관등록내용추가조회 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		// 필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		} 
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getMgntTgmCd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"전문관리번호"}, new Object[]{ "세금우대전문", "전문관리번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		// 정합성체크
		/*
		if (input.getRrno().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (!("1".equals(input.getRrnoDvsn()) || "2".equals(input.getRrnoDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getMgntTgmCd().length() != 7) {
			throw new ApplicationException( "APCME0005", new Object[]{"전문관리번호"}, new Object[]{ "세금우대전문", "전문관리번호" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input ------------//
		//처리일시
		String prcsDtm 					= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		String taxpfTgmNo 			= input.getMgntTgmCd();				//세금우대전문번호 - 채번
		String prcsDt	 					= prcsDtm.substring(0, 8);				//처리일자
		String dpsTxNo 					= "";														//입금거래번호
		String prcsDofOrgNo 		= input.getPrcsDofOrgNo();			//처리지점조직번호
		String prcsFofOrgNo 			= input.getPrcsFofOrgNo();				//처리영업소조직번호
		String prcsEno						= input.getPrcsEno();						//처리사원번호
		String contNo						= "";														//계약번호
		String savgPrdcd					= "";														//저축상품코드
		String prcsYn						= " ";														//처리여부
		String taxpfRcd					= " ";														//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 			= "0300";												//세금우대전문종류코드
		String taxpfBzDcd				= "210";													//세금우대업무구분코드
		String taxpfBzPrcsDcd 		= input.getTaxpfBzPrcsDcd();			//세금우대업무처리구분코드
		String nrmCnclDcd				= "0";														//정상취소구분코드
		String taxpfTgmDataCtnt = " ";														//세금우대전문데이터내용
		int dataLength 					= 0;															//DATA LENGTH
		String strDataLength			= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
	    // 데이터 길이
		dataLength = 13 + 1 + 40 + 20 + 1 + 1 + 10 + 10 + 1 + 2 + 1 + 2; 	//input.getRrno().length() + input.getRrnoDvsn().length();
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {

			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
			request.setSysId					("KL");									//SYSTEM-ID
			request.setTgmKndCd		(taxpfTgmKcd);					//전문종별코드
			request.setAssoBusiGb		(taxpfBzDcd);						//업무구분코드
			request.setTrnsDtm			(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)
					+ DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE)); 		//전문전송일시
			request.setMgntTgmCd	(taxpfTgmNo); 					//전문관리번호(채번해야함!! - 0000001)
			
			request.setSndInstCd		("L51"); 									//송신기관코드
			request.setRcvInstCd			("L00"); 									//수신기관코드
			request.setAssoTrnsGb		("      "); 									//거래구분코드	 	- 공백[6](AS-IS동일)
			request.setDataLen			(strDataLength); 				//DATA LENGTH
			request.setTerId					("LINA-ID   "); 						//단말기ID		 	- 공백[10](AS-IS동일)
			request.setTerOpId			("KLICS-ID  "); 						//단말기조작자ID 	- 공백[10](AS-IS동일)
			request.setTerOwnNm		("LINA                "); 				//단말기조작자성명  - 공백[20](AS-IS동일)
			request.setDataEtc				("            "); 							//예비필드			- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno					
				(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn			(input.getRrnoDvsn());		// set [주민(사업자)등록번호구분]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDt						(prcsDt);							//처리일자
			tbcnetc026io.setTaxpfTgmNo			(taxpfTgmNo);				//세금우대전문번호
			tbcnetc026io.setPrcsDtm						(prcsDtm);						//처리일시
			tbcnetc026io.setDpsTxNo					(dpsTxNo);						//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo			(prcsDofOrgNo);				//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo			(prcsFofOrgNo);				//처리영업소조직번호
			tbcnetc026io.setPrcsEno						(prcsEno);							//처리사원번호
			tbcnetc026io.setContNo						(contNo);							//계약번호
			tbcnetc026io.setSavgPrdcd					(savgPrdcd);						//저축상품코드
			tbcnetc026io.setPrcsYn						(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd					(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd			(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd				(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd		(taxpfBzPrcsDcd);			//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd			(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt(taxpfTgmDataCtnt);	//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			
			tbcnetc026io.setLastChgrId				(FwUtil.getUserId());		// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId			(FwUtil.getPgmId());		// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo		(FwUtil.getTrmNo());		// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
			 InfUtil.callAsyncFEP(request, interfaceId);
			 
			 //sync 방식
			 if( "S".equals(type) )	{
				 output = this.getBfFininRegCtntAddInq(prcsDt, taxpfTgmNo);
			 }
			
			// ------------- 응답 전문 MOVE END --------------------- //
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));			// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);					//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);						//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);								//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);							//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);						//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);			//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		
	
				
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대전금융기관등록내용추가조회 수신결과
	 * @param prcsDtm,taxpfTgmNo 
	 * @return BfFininRegCtntAddInqDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public BfFininRegCtntAddInqDO getBfFininRegCtntAddInq(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		BfFininRegCtntAddInqDO output = new BfFininRegCtntAddInqDO();
		
		logger.debug("call getBfFininRegCtntAddInq");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    //세금우대
			    BfFininRegCtntAddInqDO bfFininRegCtntAddInq  = null;
				
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공
				if ( null != out ) {
					
					bfFininRegCtntAddInq = new BfFininRegCtntAddInqDO();
					
					bfFininRegCtntAddInq.setTgmKndCd				(out.getTaxpfTgmKcd());									// set [전문종별코드]
					bfFininRegCtntAddInq.setAssoBusiGb				(out.getTaxpfBzDcd());										// set [협회업무구분]
					bfFininRegCtntAddInq.setTrnsDtm					(out.getPrcsDtm());											// set [전문전송일시]
					bfFininRegCtntAddInq.setMgntTgmCd			(out.getTaxpfTgmNo().toString());				// set [전문관리번호]
					bfFininRegCtntAddInq.setSndInstCd				("L51");																	// set [전송기관코드]
					bfFininRegCtntAddInq.setRcvInstCd					("L00");																	// set [수신기관코드]
					bfFininRegCtntAddInq.setAssoRspCd				(out.getTaxpfRcd());											// set [협회응답코드]
					bfFininRegCtntAddInq.setRrnoDvsn					(out.getRdsnBznoDcd());									// set [주민(사업자)등록번호구분]
					bfFininRegCtntAddInq.setConm						(out.getConmNm());											// set [상호(기업체명)]
					bfFininRegCtntAddInq.setName						(out.getTaxpfTgtpNm());									// set [성명(대표자)]
					bfFininRegCtntAddInq.setTaxpfDupYn			(out.getInqReqSavgKndDupVl());					// set [조회요청저축종류중복여부]
					bfFininRegCtntAddInq.setTaxpfEntAmt			(out.getInqReqSavgKndEntSamt());				// set [조회요청저축종류가입총액]
					bfFininRegCtntAddInq.setTaxpfLmtAmt			(out.getInqReqSavgKndLmtRmnAmt());		// set [조회요청저축종류한도잔여액]
					bfFininRegCtntAddInq.setTaxpfReptCnt			(out.getInqReqSavgKndTtlCnt());					// set [조회요청저축종류총건수]
					
					output = bfFininRegCtntAddInq;
					
					// 결과코드가 들어오는 경우
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 세금우대 전 금융기관 등록내용 조회 수신(0310/210)
	 * 
	 * @param  COM_F_KLIOSKOTS00002In 세금우대 전 금융기관 등록내용 조회OMM
	 * @throws ApplicationException
	 */
	public void bfFininRegCtntInqAddRcv(COM_F_KLIOSKOTS00003In input
			) throws ApplicationException {
		
		List<COM_F_KLIOSKOTS00003Sub0> taxpfReptMtr = null;		// 세금우대회보사항
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();		// TBCNETC026       OMM
		
		String prcsYn							= " ";												//처리여부
		String taxpfRcd						= " ";												//세금우대결과코드 - 응답코드
		String prcsDtm 						= "";												//처리일시        
		String taxpfTgmNo 				= "";												//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd					= "0";												//정상취소구분코드
		String prcsDt	 						= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		
		logger.debug("수신전문 [{}]", input);
		
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm			= input.getTrnsDtm();						//전문전송일시
		taxpfTgmNo    = input.getMgntTgmCd();				//세금우대전문번호
		prcsYn 				= "Y";														//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 					//세금우대결과코드 - 응답코드
		//taxpfTgmKcd 		= input.getTgmKndCd();					//세금우대전문종류코드
		//taxpfBzDcd			= input.getAssoBusiGb();					//세금우대업무구분코드
		//taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
		
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) { 
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt											(prcsDt);																		//처리일자
		tbcnetc026io.setTaxpfTgmNo								(taxpfTgmNo);															//세금우대전문번호
		tbcnetc026io.setPrcsDtm											(prcsDtm);																	//처리일시
		tbcnetc026io.setPrcsYn											(prcsYn);																		//처리여부
		tbcnetc026io.setTaxpfRcd										(taxpfRcd);																	//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd								(nrmCnclDcd);																//정상취소구분코드
		tbcnetc026io.setRdsnBznoDcd								(input.getRrnoDvsn());												//주민(사업자)등록번호구분
		tbcnetc026io.setConmNm										(input.getConm());													//상호명
		tbcnetc026io.setTaxpfTgtpNm								(input.getName());													//세금우대대상자명
		tbcnetc026io.setInfoMnbdyDcd							(input.getInfoMnbdyDvsn());									//정보주체구분코드
		tbcnetc026io.setLrnkIncmrDcd								(input.getIncmrDvsn());											//하위소득자구분코드
		tbcnetc026io.setInqReqSavgKndLmtRmnAmt	(input.getTaxpfLmtAmt());										// set [세금우대한도잔여액]
		tbcnetc026io.setInqReqSavgKndEntSamt			(input.getTaxpfEntAmt());										// set [세금우대가입총액]
		tbcnetc026io.setInqReqSavgKndDupVl				(input.getTaxpfDupYn());										// set [세금우대중복여부]
		if( !StringUtils.isEmpty(input.getTaxpfTtlRegCnt()) )	{
			tbcnetc026io.setInqReqSavgKndTtlCnt			(Integer.parseInt(input.getTaxpfTtlRegCnt()));	// set [세금우대총등록건수]
		}
		
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		//updateLog(tbcnetc026io);
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0268(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
		
		//세금우대회보사항
		taxpfReptMtr = input.getTaxpfReptMtr();
		
		iResult = 0;
		
		for(int i = 0; i < input.getTaxpfReptCnt(); i++ ){
			
			TBCNETC035Io tbcnetc035io = new TBCNETC035Io();
			
			tbcnetc035io.setPrcsDt							(prcsDt); 																		// set [처리일시]
			tbcnetc035io.setTaxpfTgmNo				(Integer.parseInt(taxpfTgmNo)); 							// set [등록점포]
			tbcnetc035io.setRescsDvsnVl					(taxpfReptMtr.get(i).getRescsDcd()); 					// set [해지구분값]			
			tbcnetc035io.setOpenOffcNm				(taxpfReptMtr.get(i).getRegOffc());						// set [개설점포명]
			tbcnetc035io.setActNo							(SecuUtil.getEncValue(taxpfReptMtr.get(i).getActNo(), SecuUtil.EncType.actNo));	// set [계좌번호]
			tbcnetc035io.setSavgKndVl					(taxpfReptMtr.get(i).getSavgKcd());						// set [저축종류값]	
			tbcnetc035io.setSavgNewDt					(taxpfReptMtr.get(i).getSavgNewDt());				// set [저축신규일자]
			tbcnetc035io.setSavgLastChgDt			(taxpfReptMtr.get(i).getSavgLastChgDt());		// set [저축최종변경일자]
			tbcnetc035io.setTaxpfEntAmt				(taxpfReptMtr.get(i).getTaxpfEntAmt());			// set [세금우대가입금액]
			tbcnetc035io.setExpiDt							(taxpfReptMtr.get(i).getExpiDt());						// set [만기일자]
			tbcnetc035io.setTaxPfrRescsDt				(taxpfReptMtr.get(i).getTaxpfRescsDt());			// set [세금우대해지일자]
			tbcnetc035io.setIntDivdPayAmt			(taxpfReptMtr.get(i).getIntDividPayAmt());		// set [이자배당지급금액]
			tbcnetc035io.setInhrtVl							(taxpfReptMtr.get(i).getHeirYn());						// set [상속값]
			tbcnetc035io.setHousPrpsDpstDvsnVl	(taxpfReptMtr.get(i).getHousPrpsDpstDcd());	// set [주택청약예금구분값]
			
			tbcnetc035io.setLastChgrId					("KLI");																			// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc035io.setLastChgPgmId				("KLI");																			// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc035io.setLastChgTrmNo			("KLI");																			// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iResult = cmt001dbio.insertOneTBCNETC0350(tbcnetc035io);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
			}
			
		}
		
	}
	
	/**
	 * 저축종류별세부내역조회
	 * 
	 * @param  SavgKcdDetlDtlcInqDO 저축종류별세부내역조회
	 * @return SavgKcdDetlDtlcInqDO 저축종류별세부내역조회
	 * @throws ApplicationException
	 */
	public SavgKcdDetlDtlcInqDO savgKcdDetlDtlcInq(SavgKcdDetlDtlcInqDO input
			) throws ApplicationException {
		
		return this.savgKcdDetlDtlcInq(input, "S");
		
	}
	/**
	 * 저축종류별세부내역조회
	 * 
	 * @param  SavgKcdDetlDtlcInqDO 저축종류별세부내역조회
	 * @return SavgKcdDetlDtlcInqDO 저축종류별세부내역조회
	 * @throws ApplicationException
	 */
	public SavgKcdDetlDtlcInqDO savgKcdDetlDtlcInq(SavgKcdDetlDtlcInqDO input, String type
			) throws ApplicationException {
		
		SavgKcdDetlDtlcInqDO output = new SavgKcdDetlDtlcInqDO();
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00004";	// EAI Interface ID
		
		COM_F_KLIOAKOTS00004In request = new COM_F_KLIOAKOTS00004In();	// 저축종류별세부내역조회 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		// 필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		} 
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getInqReqSavgKcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"조회요청저축종류"}, new Object[]{ "세금우대전문", "조회요청저축종류" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		// 정합성체크
		/*
		if (input.getRrno().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (!("1".equals(input.getRrnoDvsn()) || "2".equals(input.getRrnoDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getInqReqSavgKcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"조회요청저축종류"}, new Object[]{ "세금우대전문", "조회요청저축종류" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input ------------//
		String prcsDtm 					= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 			= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String prcsDt	 					= prcsDtm.substring(0,8);				//처리일자
		String dpsTxNo 					= "";														//입금거래번호
		String prcsDofOrgNo 		= input.getPrcsDofOrgNo();			//처리지점조직번호
		String prcsFofOrgNo	 		= input.getPrcsFofOrgNo();				//처리영업소조직번호
		String prcsEno						= input.getPrcsEno();						//처리사원번호
		String contNo						= "";														//계약번호
		String savgPrdcd					= "";														//저축상품코드
		String prcsYn						= " ";														//처리여부
		String taxpfRcd					= " ";														//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 			= "0200";												//세금우대전문종류코드
		String taxpfBzDcd				= "216";													//세금우대업무구분코드
		String taxpfBzPrcsDcd 		= input.getTaxpfBzPrcsDcd();			//세금우대업무처리구분코드
		String nrmCnclDcd				= "0";														//정상취소구분코드
		String taxpfTgmDataCtnt	= " ";														//세금우대전문데이터내용
		int dataLength 					= 0;															//DATA LENGTH
		String strDataLength			= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
		
	    //데이터 길이
		dataLength = 13 + 1 + 2 + 40 + 20 + 1 + 1 + 10 + 10 + 10 + 1 + 3 + 1 + 2; 	//input.getRrno().length() + input.getRrnoDvsn().length() + input.getInqReqSavgKcd().length();
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {

			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
			request.setSysId						("KL");											//SYSTEM-ID
			request.setTgmKndCd			(taxpfTgmKcd);							//전문종별코드
			request.setAssoBusiGb			(taxpfBzDcd);								//업무구분코드
			request.setTrnsDtm				(prcsDtm); 									//전문전송일시
			request.setMgntTgmCd		(taxpfTgmNo); 							//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd			("L51"); 											//송신기관코드
			request.setRcvInstCd				("L00"); 											//수신기관코드
			request.setAssoTrnsGb			("      "); 											//거래구분코드	 		- 공백[6](AS-IS동일)
			request.setDataLen				(strDataLength); 						//DATA LENGTH			
			request.setTerId						("LINA-ID   "); 								//단말기ID		 	- 공백[10](AS-IS동일)
			request.setTerOpId				("KLICS-ID  "); 								//단말기조작자ID 	- 공백[10](AS-IS동일)
			request.setTerOwnNm			("LINA                "); 						//단말기조작자성명  - 공백[20](AS-IS동일)
			request.setDataEtc					("            "); 									//예비필드					- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno						(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));						// set [주민(사업자)등록번호]
			request.setRrnoDvsn				(input.getRrnoDvsn());				// set [주민(사업자)등록번호구분]
			request.setInqReqSavgKcd	(input.getInqReqSavgKcd());	// set [조회요청저축종류]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm							(prcsDtm);										//처리일시
			tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);								//세금우대전문번호
			tbcnetc026io.setPrcsDt							(prcsDt);											//처리일자
			tbcnetc026io.setDpsTxNo						(dpsTxNo);										//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo				(prcsDofOrgNo);								//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo				(prcsFofOrgNo);								//처리영업소조직번호
			tbcnetc026io.setPrcsEno							(prcsEno);											//처리사원번호
			tbcnetc026io.setContNo							(contNo);											//계약번호
			tbcnetc026io.setSavgPrdcd						(savgPrdcd);										//저축상품코드
			tbcnetc026io.setPrcsYn							(prcsYn);											//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);										//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);								//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);									//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd			(taxpfBzPrcsDcd);							//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);									//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);						//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			tbcnetc026io.setRdsnBznoDcd				(input.getRrnoDvsn());					// set [주민(사업자)등록번호구분]
			tbcnetc026io.setSavgKndVl					(input.getInqReqSavgKcd());		// set [조회요청저축종류]
			
			tbcnetc026io.setLastChgrId					(FwUtil.getUserId());						// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId				(FwUtil.getPgmId());						// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo			(FwUtil.getTrmNo());						// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if("S".equals(type)) {
				output = this.getSavgKcdDetlDtlcInq(prcsDt, taxpfTgmNo);
			}
			// ------------- 응답 전문 MOVE END --------------------- //
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		
		
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 저축종류별세부내역조회
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfSavgKndClLmtInqDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public SavgKcdDetlDtlcInqDO getSavgKcdDetlDtlcInq(String prcsDt, String taxpfTgmNo)  throws ApplicationException {

		SavgKcdDetlDtlcInqDO output = new SavgKcdDetlDtlcInqDO();
		
		logger.debug("call TaxpfSavgKndClLmtInqDO");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			List<TaxpfReptMtrDO> subResult = new ArrayList<TaxpfReptMtrDO>();					//ARRAY 값
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    //세금우대
			    SavgKcdDetlDtlcInqDO savgKcdDetlDtlcInq   = null;
				
			    SelectOntTBCNETC026bOut  out = null;
			    List<SelectOntTBCNETC035aOut>  outSub = new ArrayList<SelectOntTBCNETC035aOut>();
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( out !=null ) {
					
					savgKcdDetlDtlcInq = new SavgKcdDetlDtlcInqDO();
					
					savgKcdDetlDtlcInq.setTgmKndCd					(out.getTaxpfTgmKcd());								// set [전문종별코드]
					savgKcdDetlDtlcInq.setAssoBusiGb					(out.getTaxpfBzDcd());									// set [협회업무구분]
					savgKcdDetlDtlcInq.setTrnsDtm							(out.getPrcsDtm());										// set [전문전송일시]
					savgKcdDetlDtlcInq.setMgntTgmCd					(out.getTaxpfTgmNo().toString());			// set [전문관리번호]
					savgKcdDetlDtlcInq.setSndInstCd						("L51");																// set [전송기관코드]
					savgKcdDetlDtlcInq.setRcvInstCd						("L00");																// set [수신기관코드]
					savgKcdDetlDtlcInq.setAssoRspCd					(out.getTaxpfRcd());										// set [협회응답코드]
					
					savgKcdDetlDtlcInq.setRrnoDvsn						(out.getRdsnBznoDcd());								// set [주민(사업자)등록번호구분]
					savgKcdDetlDtlcInq.setConm								(out.getConmNm());										// set [상호(기업체명)]
					savgKcdDetlDtlcInq.setName								(out.getTaxpfTgtpNm());								// set [성명(대표자)]
					savgKcdDetlDtlcInq.setInfoMnbdyDvsn			(out.getInfoMnbdyDcd());							// set [정보주체(구 장애인)구분]
					savgKcdDetlDtlcInq.setIncmrDvsn						(out.getLrnkIncmrDcd());								// set [저소득자구분(농어가저축)]
					savgKcdDetlDtlcInq.setInqReqSavgLmt			(out.getInqReqSavgKndLmtAmt());			// set [조회요청저축종류한도]
					savgKcdDetlDtlcInq.setInqReqSavgEntAmt	(out.getInqReqSavgKndEntSamt());			// set [조회요청저축종류가입총액]
					savgKcdDetlDtlcInq.setInqReqSavgLmtAmt	(out.getInqReqSavgKndLmtRmnAmt());	// set [조회요청저축종류한도잔여액]
					savgKcdDetlDtlcInq.setInqReqSavgDupYn		(out.getInqReqSavgKndDupVl());				// set [조회요청저축종류중복여부]
					savgKcdDetlDtlcInq.setInqReqSavgTtlCnt		(out.getInqReqSavgKndTtlCnt());				// set [조회요청저축종류총건수]
					
					outSub = cmt001dbio.selectOneTBCNETC035a(prcsDt, taxpfTgmNo);
					
					if (outSub !=null) {
						
						savgKcdDetlDtlcInq.setTaxpfReptCnt		(outSub.size());					// set [세금우대회보건수]
						
						for(int j = 0; j < outSub.size(); j++){
							
							TaxpfReptMtrDO taxpfReptMtrDO = new TaxpfReptMtrDO();
							
							taxpfReptMtrDO.setRescsDcd					(outSub.get(j).getRescsDvsnVl()); 				// set [해지구분코드]
							taxpfReptMtrDO.setRegOffc						(outSub.get(j).getOpenOffcNm()); 				// set [등록점포]
							taxpfReptMtrDO.setActNo							(outSub.get(j).getActNo()); 							// set [계좌번호]
							taxpfReptMtrDO.setSavgKcd						(outSub.get(j).getSavgKndVl()); 					// set [저축종류]
							taxpfReptMtrDO.setSavgNewDt				(outSub.get(j).getSavgNewDt()); 					// set [저축신규일]
							taxpfReptMtrDO.setSavgLastChgDt			(outSub.get(j).getSavgLastChgDt()); 			// set [저축최종변경일]
							taxpfReptMtrDO.setTaxpfEntAmt				(outSub.get(j).getTaxpfEntAmt()); 				// set [세금우대가입금액]
							taxpfReptMtrDO.setExpiDt							(outSub.get(j).getExpiDt()); 							// set [만기일]
							taxpfReptMtrDO.setTaxpfRescsDt				(outSub.get(j).getTaxPfrRescsDt()); 				// set [세금우대해지일]
							taxpfReptMtrDO.setIntDividPayAmt			(outSub.get(j).getIntDivdPayAmt()); 			// set [이자배당지급액]
							taxpfReptMtrDO.setHeirYn							(outSub.get(j).getInhrtVl()); 							// set [상속여부]
							taxpfReptMtrDO.setHousPrpsDpstDcd	(outSub.get(j).getHousPrpsDpstDvsnVl());	// set [주택청약예부금구분]
							
							subResult.add(taxpfReptMtrDO);
							
						}	
						
						savgKcdDetlDtlcInq.setTaxpfReptMtrDO(subResult);
						
					}
					
					output = savgKcdDetlDtlcInq;
					
					// 결과코드가 들어오는 경우
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 저축종류별세부내역조회 수신(0210/216)
	 * 
	 * @param  COM_F_KLIOAKOTS00004In 저축종류별세부내역조회OMM
	 * @throws ApplicationException
	 */
	public void savgKcdDetlCtntInqRcv(COM_F_KLIOAKOTS00004In input
			) throws ApplicationException {
		
		List<COM_F_KLIOAKOTS00004Sub0> taxpfReptMtr = null;		// 세금우대회보사항
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String prcsDt	 				= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);	//처리일자
		String prcsYn					= " ";																											//처리여부
		String taxpfRcd				= " ";																											//세금우대결과코드 - 응답코드
		String prcsDtm 				= "";																											//처리일시
		String taxpfTgmNo 		= "";																											//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd			= "0";																											//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            = input.getTrnsDtm();						//전문전송일시
		taxpfTgmNo    = input.getMgntTgmCd();				//세금우대전문번호
		prcsYn 				= "Y";														//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 					//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();				//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();				//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt											(prcsDt);																		//처리일자
		tbcnetc026io.setTaxpfTgmNo								(taxpfTgmNo);															//세금우대전문번호
		tbcnetc026io.setPrcsDtm											(prcsDtm);																	//처리일시
		tbcnetc026io.setPrcsYn											(prcsYn);																		//처리여부
		tbcnetc026io.setTaxpfRcd										(taxpfRcd);																	//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd								(nrmCnclDcd);																//정상취소구분코드
		tbcnetc026io.setRdsnBznoDcd								(input.getRrnoDvsn());												//주민(사업자)등록번호구분
		tbcnetc026io.setConmNm										(input.getConm());													//상호명
		tbcnetc026io.setTaxpfTgtpNm								(input.getName());													//세금우대대상자명
		tbcnetc026io.setInfoMnbdyDcd							(input.getInfoMnbdyDvsn());									//정보주체구분코드
		tbcnetc026io.setLrnkIncmrDcd								(input.getIncmrDvsn());											//하위소득자구분코드
		tbcnetc026io.setInqReqSavgKndLmtAmt			(input.getInqReqSavgLmt());									//조회요청저축종류한도금액
		tbcnetc026io.setInqReqSavgKndEntSamt			(input.getInqReqSavgEntAmt());							//조회요청저축종류가입합계금액
		tbcnetc026io.setInqReqSavgKndLmtRmnAmt	(input.getInqReqSavgLmtAmt());							//조회요청저축종류한도잔여금액
		tbcnetc026io.setInqReqSavgKndDupVl				(input.getInqReqSavgDupYn());							//조회요청저축종류중복값
		tbcnetc026io.setInqReqSavgKndTtlCnt				(input.getInqReqSavgTtlCnt());								//조회요청저축종류총건수
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		//updateLog(tbcnetc026io);
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0267(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
		
		//세금우대회보사항
		taxpfReptMtr = input.getTaxpfReptMtr();
		
		iResult = 0;
		
		for(int i = 0; i < input.getTaxpfReptCnt(); i++ ){
			
			TBCNETC035Io tbcnetc035io = new TBCNETC035Io();				// TBCNETC035       OMM
			
			tbcnetc035io.setPrcsDt							(prcsDt); 																		// set [처리일시]
			tbcnetc035io.setTaxpfTgmNo				(Integer.parseInt(taxpfTgmNo)); 							// set [등록점포]
			tbcnetc035io.setRescsDvsnVl					(taxpfReptMtr.get(i).getRescsDcd()); 					// set [해지구분값]			
			tbcnetc035io.setOpenOffcNm				(taxpfReptMtr.get(i).getRegOffc());						// set [개설점포명]
			tbcnetc035io.setActNo							(SecuUtil.getEncValue(taxpfReptMtr.get(i).getActNo(), SecuUtil.EncType.actNo));	// set [계좌번호]
			tbcnetc035io.setSavgKndVl					(taxpfReptMtr.get(i).getSavgKcd());						// set [저축종류값]	
			tbcnetc035io.setSavgNewDt					(taxpfReptMtr.get(i).getSavgNewDt());				// set [저축신규일자]
			tbcnetc035io.setSavgLastChgDt			(taxpfReptMtr.get(i).getSavgLastChgDt());		// set [저축최종변경일자]
			tbcnetc035io.setTaxpfEntAmt				(taxpfReptMtr.get(i).getTaxpfEntAmt());			// set [세금우대가입금액]
			tbcnetc035io.setExpiDt							(taxpfReptMtr.get(i).getExpiDt());						// set [만기일자]
			tbcnetc035io.setTaxPfrRescsDt				(taxpfReptMtr.get(i).getTaxpfRescsDt());			// set [세금우대해지일자]
			tbcnetc035io.setIntDivdPayAmt			(taxpfReptMtr.get(i).getIntDividPayAmt());		// set [이자배당지급금액]
			tbcnetc035io.setInhrtVl							(taxpfReptMtr.get(i).getHeirYn());						// set [상속값]
			tbcnetc035io.setHousPrpsDpstDvsnVl	(taxpfReptMtr.get(i).getHousPrpsDpstDcd());	// set [주택청약예금구분값]
			
			tbcnetc035io.setLastChgrId					("KLI");																			// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc035io.setLastChgPgmId				("KLI");																			// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc035io.setLastChgTrmNo			("KLI");																			// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iResult = cmt001dbio.insertOneTBCNETC0350(tbcnetc035io);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
			}
			
		}

	}
	
	/**
	 * 저축종류별세부내역추가조회
	 * 
	 * @param  BfFininRegCtntAddInqDO 저축종류별세부내역추가조회
	 * @return BfFininRegCtntAddInqDO 저축종류별세부내역추가조회
	 * @throws ApplicationException
	 */
	public SavgKcdDetlDtlcAddInqDO savgKcdDetlDtlcAddInq(SavgKcdDetlDtlcAddInqDO input
			) throws ApplicationException {
		
		return savgKcdDetlDtlcAddInq(input, "S");
		
	}
	
	/**
	 * 저축종류별세부내역추가조회
	 * 
	 * @param  SavgKcdDetlDtlcAddInqDO 저축종류별세부내역추가조회
	 * @return SavgKcdDetlDtlcAddInqDO 저축종류별세부내역추가조회
	 * @throws ApplicationException
	 */
	public SavgKcdDetlDtlcAddInqDO savgKcdDetlDtlcAddInq(SavgKcdDetlDtlcAddInqDO input, String type
			) throws ApplicationException {
		
		SavgKcdDetlDtlcAddInqDO output = new SavgKcdDetlDtlcAddInqDO();
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM

		String interfaceId = "COM_F_KLIOAKOTS00005";								// EAI Interface ID
		
		COM_F_KLIOSKOTS00005In request = new COM_F_KLIOSKOTS00005In();			// 저축종류별세부내역추가조회 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		// 필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		} 
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getInqReqSavgKcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"조회요청저축종류"}, new Object[]{ "세금우대전문", "조회요청저축종류" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getMgntTgmCd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"전문관리번호"}, new Object[]{ "세금우대전문", "전문관리번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		// 정합성체크
		/*
		if (input.getRrno().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (!("1".equals(input.getRrnoDvsn()) || "2".equals(input.getRrnoDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getInqReqSavgKcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"조회요청저축종류"}, new Object[]{ "세금우대전문", "조회요청저축종류" });
		}
		if (input.getMgntTgmCd().length() != 7) {
			throw new ApplicationException( "APCME0005", new Object[]{"전문관리번호"}, new Object[]{ "세금우대전문", "전문관리번호" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input ------------//
		String prcsDtm 					= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 			= input.getMgntTgmCd();																		//세금우대전문번호 - 채번
		String prcsDt	 					= prcsDtm.substring(0,8);																		//처리일자
		String dpsTxNo 					= "";																												//입금거래번호
		String prcsDofOrgNo 		= input.getPrcsDofOrgNo();																	//처리지점조직번호
		String prcsFofOrgNo 			= input.getPrcsFofOrgNo();																		//처리영업소조직번호
		String prcsEno						= input.getPrcsEno();																				//처리사원번호
		String contNo						= "";																												//계약번호
		String savgPrdcd					= "";																												//저축상품코드
		String prcsYn						= " ";																												//처리여부
		String taxpfRcd					= " ";																												//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 			= "0300";																										//세금우대전문종류코드
		String taxpfBzDcd				= "216";																											//세금우대업무구분코드
		String taxpfBzPrcsDcd 		= input.getTaxpfBzPrcsDcd();																	//세금우대업무처리구분코드 		
		String nrmCnclDcd				= "0";																												//정상취소구분코드
		String taxpfTgmDataCtnt = " ";																												//세금우대전문데이터내용
		int dataLength 					= 0;																													//DATA LENGTH
		String strDataLength 		= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
		
	    //데이터 길이
		dataLength = 13 + 1 + 2 + 40 + 20 + 1 + 1 + 10 + 10 + 10 + 1 + 3 + 1 + 2; 	//input.getRrno().length() + input.getRrnoDvsn().length() + input.getInqReqSavgKcd().length();
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {
			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 											// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 											// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
		    request.setSysId					("KL");									//SYSTEM-ID
			request.setTgmKndCd		(taxpfTgmKcd);					//전문종별코드
			request.setAssoBusiGb		(taxpfBzDcd);						//업무구분코드
			request.setTrnsDtm			(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)
					+ DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE)); 		//전문전송일시
			request.setMgntTgmCd	(taxpfTgmNo); 					//전문관리번호(채번해야함!! - 0000001)
			
			request.setSndInstCd		("L51"); 									//송신기관코드
			request.setRcvInstCd			("L00"); 									//수신기관코드
			request.setAssoTrnsGb		("      "); 									//거래구분코드	 	- 공백[6](AS-IS동일)
			request.setDataLen			(strDataLength); 				//DATA LENGTH
			request.setTerId					("LINA-ID   "); 						//단말기ID		 	- 공백[10](AS-IS동일)
			request.setTerOpId			("KLICS-ID  "); 						//단말기조작자ID 	- 공백[10](AS-IS동일)
			request.setTerOwnNm		("LINA                "); 				//단말기조작자성명  - 공백[20](AS-IS동일)
			request.setDataEtc				("            "); 							//예비필드			- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno						
				(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));		// set [주민(사업자)등록번호]
			request.setRrnoDvsn				(input.getRrnoDvsn());						// set [주민(사업자)등록번호구분]
			request.setInqReqSavgKcd	(input.getInqReqSavgKcd());			// set [조회요청저축종류]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));					// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDt						(prcsDt);							//처리일자
			tbcnetc026io.setTaxpfTgmNo			(taxpfTgmNo);				//세금우대전문번호
			tbcnetc026io.setPrcsDtm						(prcsDtm);						//처리일시
			tbcnetc026io.setDpsTxNo					(dpsTxNo);						//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo			(prcsDofOrgNo);				//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo			(prcsFofOrgNo);				//처리영업소조직번호
			tbcnetc026io.setPrcsEno						(prcsEno);							//처리사원번호
			tbcnetc026io.setContNo						(contNo);							//계약번호
			tbcnetc026io.setSavgPrdcd					(savgPrdcd);						//저축상품코드
			tbcnetc026io.setPrcsYn						(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd					(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd			(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd				(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd		(taxpfBzPrcsDcd);			//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd			(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt(taxpfTgmDataCtnt);	//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			
			tbcnetc026io.setLastChgrId				(FwUtil.getUserId());		// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId			(FwUtil.getPgmId());		// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo		(FwUtil.getTrmNo());		// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
			InfUtil.callAsyncFEP(request, interfaceId);
			
			//sync 방식
			 if( "S".equals(type) )	{
				 output = this.getSavgKcdDetlDtlcAddInq(prcsDt, taxpfTgmNo);
			 }
			
			// ------------- 응답 전문 MOVE END --------------------- //
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}

		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	
	/**
	 * 저축종류별세부내역추가조회 수신결과
	 * @param prcsDtm,taxpfTgmNo 
	 * @return BfFininRegCtntAddInqDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public SavgKcdDetlDtlcAddInqDO getSavgKcdDetlDtlcAddInq(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		SavgKcdDetlDtlcAddInqDO output = new SavgKcdDetlDtlcAddInqDO();
		
		logger.debug("call getSavgKcdDetlDtlcAddInq");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			List<TaxpfReptMtrDO> subResult = new ArrayList<TaxpfReptMtrDO>();					//ARRAY 값
			
			//세금우대
		    SavgKcdDetlDtlcAddInqDO savgKcdDetlDtlcAddInq  = null;
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    List<SelectOntTBCNETC035aOut>  outSub = new ArrayList<SelectOntTBCNETC035aOut>();
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공
				if ( null != out ) {
					
					savgKcdDetlDtlcAddInq = new SavgKcdDetlDtlcAddInqDO();
					
					savgKcdDetlDtlcAddInq.setTgmKndCd					(out.getTaxpfTgmKcd());													// set [전문종별코드]
					savgKcdDetlDtlcAddInq.setAssoBusiGb					(out.getTaxpfBzDcd());														// set [협회업무구분]
					savgKcdDetlDtlcAddInq.setTrnsDtm							(out.getPrcsDtm());															// set [전문전송일시]
					savgKcdDetlDtlcAddInq.setMgntTgmCd					(out.getTaxpfTgmNo().toString());								// set [전문관리번호]
					savgKcdDetlDtlcAddInq.setSndInstCd						("L51");																					// set [전송기관코드]
					savgKcdDetlDtlcAddInq.setRcvInstCd						("L00");																					// set [수신기관코드]
					savgKcdDetlDtlcAddInq.setAssoRspCd					(out.getTaxpfRcd());															// set [협회응답코드]
					savgKcdDetlDtlcAddInq.setRrnoDvsn						(out.getRdsnBznoDcd());													// set [주민(사업자)등록번호구분]
					savgKcdDetlDtlcAddInq.setConm								(out.getConmNm());															// set [상호(기업체명)]
					savgKcdDetlDtlcAddInq.setName								(out.getTaxpfTgtpNm());													// set [성명(대표자)]
					savgKcdDetlDtlcAddInq.setInfoMnbdyDvsn			(out.getInfoMnbdyDcd());												// set [정보주체(구 장애인)구분]
					savgKcdDetlDtlcAddInq.setIncmrDvsn						(out.getLrnkIncmrDcd());													// set [저소득자구분(농어가저축)]
					savgKcdDetlDtlcAddInq.setInqReqSavgLmt			(out.getInqReqSavgKndLmtAmt());								// set [조회요청저축종류한도]
					savgKcdDetlDtlcAddInq.setInqReqSavgEntAmt	(out.getInqReqSavgKndEntSamt());								// set [조회요청저축종류가입총액]
					savgKcdDetlDtlcAddInq.setInqReqSavgLmtAmt	(out.getInqReqSavgKndLmtRmnAmt());						// set [조회요청저축종류한도잔여액]
					savgKcdDetlDtlcAddInq.setInqReqSavgDupYn		(out.getInqReqSavgKndDupVl());									// set [조회요청저축종류중복여부]
					savgKcdDetlDtlcAddInq.setInqReqSavgTtlCnt		(String.valueOf(out.getInqReqSavgKndTtlCnt()));	// set [조회요청저축종류총건수]
					
					outSub = cmt001dbio.selectOneTBCNETC035a(prcsDt, taxpfTgmNo);
					
					if (outSub !=null) {
						
						savgKcdDetlDtlcAddInq.setTaxpfReptCnt	(outSub.size());					// set [세금우대회보건수]
						
						for(int j = 0; j < outSub.size(); j++){
							
							TaxpfReptMtrDO taxpfReptMtrDO = new TaxpfReptMtrDO();
							
							taxpfReptMtrDO.setRescsDcd					(outSub.get(j).getRescsDvsnVl()); 				// set [해지구분코드]
							taxpfReptMtrDO.setRegOffc						(outSub.get(j).getOpenOffcNm()); 				// set [등록점포]
							taxpfReptMtrDO.setActNo							(outSub.get(j).getActNo()); 							// set [계좌번호]
							taxpfReptMtrDO.setSavgKcd						(outSub.get(j).getSavgKndVl()); 					// set [저축종류]
							taxpfReptMtrDO.setSavgNewDt				(outSub.get(j).getSavgNewDt()); 					// set [저축신규일]
							taxpfReptMtrDO.setSavgLastChgDt			(outSub.get(j).getSavgLastChgDt()); 			// set [저축최종변경일]
							taxpfReptMtrDO.setTaxpfEntAmt				(outSub.get(j).getTaxpfEntAmt()); 				// set [세금우대가입금액]
							taxpfReptMtrDO.setExpiDt							(outSub.get(j).getExpiDt()); 							// set [만기일]
							taxpfReptMtrDO.setTaxpfRescsDt				(outSub.get(j).getTaxPfrRescsDt()); 				// set [세금우대해지일]
							taxpfReptMtrDO.setIntDividPayAmt			(outSub.get(j).getIntDivdPayAmt()); 			// set [이자배당지급액]
							taxpfReptMtrDO.setHeirYn							(outSub.get(j).getInhrtVl()); 							// set [상속여부]
							taxpfReptMtrDO.setHousPrpsDpstDcd	(outSub.get(j).getHousPrpsDpstDvsnVl());	// set [주택청약예부금구분]
							
							subResult.add(taxpfReptMtrDO);
							
						}	
						
						savgKcdDetlDtlcAddInq.setTaxpfReptMtrDO(subResult);
						
					}
					
					// 결과코드가 들어오는 경우
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
				logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
				
				logger.debug("output---->:{}",output);
	
			}
			
			output = savgKcdDetlDtlcAddInq;
			
		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 저축종류별세부내역추가조회 수신(0310/216)
	 * 
	 * @param  COM_F_KLIOAKOTS00004In 저축종류별세부내역추가조회OMM
	 * @throws ApplicationException
	 */
	public void savgKcdDetlCtntInqAddRcv(COM_F_KLIOSKOTS00005In input
			) throws ApplicationException {
		
		List<COM_F_KLIOSKOTS00005Sub0> taxpfReptMtr = null;		// 세금우대회보사항
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String prcsDt	 				= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);	//처리일자
		String prcsYn					= " ";																											//처리여부
		String taxpfRcd				= " ";																											//세금우대결과코드 - 응답코드
		String prcsDtm 				= "";																											//처리일시
		String taxpfTgmNo 		= "";																											//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd			= "0";																											//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            = input.getTrnsDtm();						//전문전송일시
		taxpfTgmNo    = input.getMgntTgmCd();				//세금우대전문번호
		prcsYn 				= "Y";														//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 					//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();				//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();				//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt											(prcsDt);																		//처리일자
		tbcnetc026io.setTaxpfTgmNo								(taxpfTgmNo);															//세금우대전문번호
		tbcnetc026io.setPrcsDtm											(prcsDtm);																	//처리일시
		tbcnetc026io.setPrcsYn											(prcsYn);																		//처리여부
		tbcnetc026io.setTaxpfRcd										(taxpfRcd);																	//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd								(nrmCnclDcd);																//정상취소구분코드
		tbcnetc026io.setRdsnBznoDcd								(input.getRrnoDvsn());												//주민(사업자)등록번호구분
		tbcnetc026io.setConmNm										(input.getConm());													//상호명
		tbcnetc026io.setTaxpfTgtpNm								(input.getName());													//세금우대대상자명
		tbcnetc026io.setInfoMnbdyDcd							(input.getInfoMnbdyDvsn());									//정보주체구분코드
		tbcnetc026io.setLrnkIncmrDcd								(input.getIncmrDvsn());											//하위소득자구분코드
		tbcnetc026io.setInqReqSavgKndLmtAmt			(input.getInqReqSavgLmt());									//조회요청저축종류한도금액
		tbcnetc026io.setInqReqSavgKndEntSamt			(input.getInqReqSavgEntAmt());							//조회요청저축종류가입합계금액
		tbcnetc026io.setInqReqSavgKndLmtRmnAmt	(input.getInqReqSavgLmtAmt());							//조회요청저축종류한도잔여금액
		tbcnetc026io.setInqReqSavgKndDupVl				(input.getInqReqSavgDupYn());							//조회요청저축종류중복값
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		//updateLog(tbcnetc026io);
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0267(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
		
		//세금우대회보사항
		taxpfReptMtr = input.getTaxpfReptMtr();
		
		iResult = 0;
		
		for(int i = 0; i < input.getTaxpfReptCnt(); i++ ){
			
			TBCNETC035Io tbcnetc035io = new TBCNETC035Io();				// TBCNETC035       OMM
			
			tbcnetc035io.setPrcsDt							(prcsDt); 																		// set [처리일시]
			tbcnetc035io.setTaxpfTgmNo				(Integer.parseInt(taxpfTgmNo)); 							// set [등록점포]
			tbcnetc035io.setRescsDvsnVl					(taxpfReptMtr.get(i).getRescsDcd()); 					// set [해지구분값]			
			tbcnetc035io.setOpenOffcNm				(taxpfReptMtr.get(i).getRegOffc());						// set [개설점포명]
			tbcnetc035io.setActNo							(SecuUtil.getEncValue(taxpfReptMtr.get(i).getActNo(), SecuUtil.EncType.actNo));	// set [계좌번호]
			tbcnetc035io.setSavgKndVl					(taxpfReptMtr.get(i).getSavgKcd());						// set [저축종류값]	
			tbcnetc035io.setSavgNewDt					(taxpfReptMtr.get(i).getSavgNewDt());				// set [저축신규일자]
			tbcnetc035io.setSavgLastChgDt			(taxpfReptMtr.get(i).getSavgLastChgDt());		// set [저축최종변경일자]
			tbcnetc035io.setTaxpfEntAmt				(taxpfReptMtr.get(i).getTaxpfEntAmt());			// set [세금우대가입금액]
			tbcnetc035io.setExpiDt							(taxpfReptMtr.get(i).getExpiDt());						// set [만기일자]
			tbcnetc035io.setTaxPfrRescsDt				(taxpfReptMtr.get(i).getTaxpfRescsDt());			// set [세금우대해지일자]
			tbcnetc035io.setIntDivdPayAmt			(taxpfReptMtr.get(i).getIntDividPayAmt());		// set [이자배당지급금액]
			tbcnetc035io.setInhrtVl							(taxpfReptMtr.get(i).getHeirYn());						// set [상속값]
			tbcnetc035io.setHousPrpsDpstDvsnVl	(taxpfReptMtr.get(i).getHousPrpsDpstDcd());	// set [주택청약예금구분값]
			
			tbcnetc035io.setLastChgrId					("KLI");																			// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc035io.setLastChgPgmId				("KLI");																			// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc035io.setLastChgTrmNo			("KLI");																			// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iResult = cmt001dbio.insertOneTBCNETC0350(tbcnetc035io);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
			}
			
		}

	}
	
	/**
	 * 해당계좌번호 등록내용 조회
	 * 
	 * @param  RlvActNoRegCtntInqDO 해당계좌번호등록내용조회DO
	 * @return RlvActNoRegCtntInqDO 해당계좌번호등록내용조회DO
	 * @throws ApplicationException
	 */
	public RlvActNoRegCtntInqDO rlvActNoRegCtntInq(RlvActNoRegCtntInqDO   input) throws ApplicationException {
		
		return this.rlvActNoRegCtntInq(input, "S");
	}
	
	/**
	 * 해당계좌번호 등록내용 조회
	 * 
	 * @param  RlvActNoRegCtntInqDO 해당계좌번호등록내용조회 DO
	 * @return RlvActNoRegCtntInqDO 해당계좌번호등록내용조회 DO
	 * @throws ApplicationException
	 */
	public RlvActNoRegCtntInqDO rlvActNoRegCtntInq(RlvActNoRegCtntInqDO   input, String type) throws ApplicationException {
		
		RlvActNoRegCtntInqDO output = new RlvActNoRegCtntInqDO();
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00006";	// EAI Interface ID
		
		COM_F_KLIOAKOTS00006In request = new COM_F_KLIOAKOTS00006In();	// 해당계좌번호등록내용조회 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		// 필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		} 
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getInqActNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"조회계좌번호"}, new Object[]{ "세금우대전문", "조회계좌번호" });
		}
		if (StringUtils.isEmpty(input.getRegOffcCd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"등록점포코드"}, new Object[]{ "세금우대전문", "등록점포코드" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		// 정합성체크
		/*
		if (input.getRrno().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (!("1".equals(input.getRrnoDvsn()) || "2".equals(input.getRrnoDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
//		if (input.getInqActNo().length() != 16) {
//			throw new ApplicationException( "APCME0005", new Object[]{""}, new Object[]{ "세금우대전문", "조회계좌번호" });
//		}
		if (input.getRegOffcCd().length() != 7) {
			throw new ApplicationException( "APCME0005", new Object[]{"등록점포코드"}, new Object[]{ "세금우대전문", "등록점포코드" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input ------------//
		String prcsDtm 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 	= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		logger.debug("채번taxpfTgmNo IO  [{}]", new Object [] {taxpfTgmNo});
		
		String prcsDt	 					= prcsDtm.substring(0,8);				//처리일자
		String dpsTxNo 					= "";														//입금거래번호
		String prcsDofOrgNo 		= input.getPrcsDofOrgNo();			//처리지점조직번호
		String prcsFofOrgNo 			= input.getPrcsFofOrgNo();				//처리영업소조직번호
		String prcsEno						= input.getPrcsEno();						//처리사원번호
		String contNo						= "";														//계약번호
		String savgPrdcd					= "";														//저축상품코드
		String prcsYn						= " ";														//처리여부
		String taxpfRcd					=	" ";														//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 			= "0200";												//세금우대전문종류코드
		String taxpfBzDcd				= "215";													//세금우대업무구분코드
		String taxpfBzPrcsDcd 		= input.getTaxpfBzPrcsDcd();			//세금우대업무처리구분코드		
		String nrmCnclDcd				= "0";														//정상취소구분코드
		String taxpfTgmDataCtnt	= " ";														//세금우대전문데이터내용
		int dataLength 					= 0;															//DATA LENGTH
		String strDataLength 		= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
				
	    //데이터 길이
		dataLength = 13 + 1 + 16 + 7 + 40 + 20 + 1 + 1 + 2 + 2 + 8 + 10 + 8 + 8 + 10 + 1 + 1; 													 	//input.getRrno().length() + input.getRrnoDvsn().length() + input.getRegOffcCd().length();
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {
			
			//taxpfTgmNo = "0" + taxpfTgmNo;
			
			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
			request.setSysId					("KL");								//SYSTEM-ID
			request.setTgmKndCd		(taxpfTgmKcd);				//전문종별코드
			request.setAssoBusiGb		(taxpfBzDcd);					//업무구분코드
			request.setTrnsDtm			(prcsDtm); 						//전문전송일시
			request.setMgntTgmCd	(taxpfTgmNo); 				//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd		("L51"); 								//송신기관코드
			request.setRcvInstCd			("L00"); 								//수신기관코드
			request.setAssoTrnsGb		("      "); 								//거래구분코드	 	- 공백[6](AS-IS동일)
			request.setDataLen			(strDataLength); 			//DATA LENGTH
			request.setTerId					("LINA-ID   "); 					//단말기ID		 	- 공백[10](AS-IS동일)
			request.setTerOpId			("KLICS-ID  "); 					//단말기조작자ID 	- 공백[10](AS-IS동일)
			request.setTerOwnNm		("LINA                "); 			//단말기조작자성명  - 공백[20](AS-IS동일)
			request.setDataEtc				("            "); 						//예비필드			- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno					
				(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn			(input.getRrnoDvsn());	// set [주민(사업자)등록번호구분]
			
			// 2013-11-15 : old계좌번호를 조회하는 모듈로 수정
			//request.setInqActNo	(this.getOldContNo(input.getInqActNo()));
			request.setInqActNo	(input.getInqActNo());			// set [입력계좌번호]
			request.setRegOffcCd(input.getRegOffcCd());		// set [등록점포코드]
			//20140325 추가 
			request.setSavgKnd(input.getSavgKnd());				// set [저축종류코드]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm							(prcsDtm);																//처리일시
			tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);														//세금우대전문번호
			tbcnetc026io.setPrcsDt							(prcsDt);																	//처리일자
			tbcnetc026io.setDpsTxNo						(dpsTxNo);																//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo				(prcsDofOrgNo);														//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo				(prcsFofOrgNo);														//처리영업소조직번호
			tbcnetc026io.setPrcsEno							(prcsEno);																	//처리사원번호
			tbcnetc026io.setContNo							(contNo);																	//계약번호
			tbcnetc026io.setSavgPrdcd						(savgPrdcd);																//저축상품코드
			tbcnetc026io.setPrcsYn							(prcsYn);																	//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);																//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);														//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);															//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd			(taxpfBzPrcsDcd);													//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);															//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);												//세금우대전문데이터내용
			tbcnetc026io.setRdsnBzno						
										(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			tbcnetc026io.setRdsnBznoDcd				(input.getRrnoDvsn());											//주민사업자등록번호구분코드
			tbcnetc026io.setActNo							(this.getOldContNo(input.getInqActNo()));	//조회계좌번호
			tbcnetc026io.setOpenOffcId					(input.getRegOffcCd());										//등록점포코드
			
			tbcnetc026io.setLastChgrId					(FwUtil.getUserId());												// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId				(FwUtil.getPgmId());												// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo			(FwUtil.getTrmNo());												// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(ASYNC 방식) ------ //
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if("S".equals(type)) {
				output = this.getRlvActNoRegCtntInqRece(prcsDt, taxpfTgmNo);
			}
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.debug("e");
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});			
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.debug("e");
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}
		
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 저축종류별세부등록내용조회
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfSavgKndClLmtInqDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public RlvActNoRegCtntInqDO getRlvActNoRegCtntInqRece(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		 RlvActNoRegCtntInqDO rlvActNoRegCtntInq  = null;
		 
		RlvActNoRegCtntInqDO output = new RlvActNoRegCtntInqDO();
		
		logger.debug("call RlvActNoRegCtntInqDO");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( out !=null ) {
					
					rlvActNoRegCtntInq  = new RlvActNoRegCtntInqDO();
					
					rlvActNoRegCtntInq.setTgmKndCd			(out.getTaxpfTgmKcd());						// set [전문종별코드]
					rlvActNoRegCtntInq.setAssoBusiGb			(out.getTaxpfBzDcd());							// set [협회업무구분]
					rlvActNoRegCtntInq.setTrnsDtm				(out.getPrcsDtm());								// set [전문전송일시]
					rlvActNoRegCtntInq.setMgntTgmCd		(out.getTaxpfTgmNo().toString());	// set [전문관리번호]
					rlvActNoRegCtntInq.setSndInstCd			("L51");														// set [전송기관코드]
					rlvActNoRegCtntInq.setRcvInstCd				("L00");														// set [수신기관코드]
					rlvActNoRegCtntInq.setAssoRspCd			(out.getTaxpfRcd());								// set [협회응답코드]
					rlvActNoRegCtntInq.setRrnoDvsn				(out.getRdsnBznoDcd());						// set [주민(사업자)등록번호구분]
					rlvActNoRegCtntInq.setConm					(out.getConmNm());								// set [상호(기업체명)]
					rlvActNoRegCtntInq.setName					(out.getTaxpfTgtpNm());						// set [성명(대표자)]
					rlvActNoRegCtntInq.setInfoMnbdyDvsn	(out.getInfoMnbdyDcd());					// set [정보주체(구 장애인)구분]
					rlvActNoRegCtntInq.setIncmrDvsn			(out.getLrnkIncmrDcd());						// set [저소득자구분(농어가저축)]
					rlvActNoRegCtntInq.setRescsDcd				(out.getRescsDvsnVl());						// set [해지구분코드]
					rlvActNoRegCtntInq.setSavgKnd				(out.getSavgKndVl());							// set [저축종류]
					rlvActNoRegCtntInq.setSavgNewDy			(out.getSavgNewDt());							// set [저축신규일]
					rlvActNoRegCtntInq.setTaxpfAmt				(out.getTaxpfAmt());							// set [세금우대금액]
					rlvActNoRegCtntInq.setExpiDy					(out.getExpiDt());									// set [만기일]
					rlvActNoRegCtntInq.setRescsDy					(out.getRescsDt());								// set [해지일]
					rlvActNoRegCtntInq.setIntDivdAmt			(out.getIntDivdPayAmt());					// set [이자,배당지급액]
					rlvActNoRegCtntInq.setInhrtYn					(out.getInhrtVl());									// set [상속여부]
					rlvActNoRegCtntInq.setHousPrpsDvsn		(out.getHousPrpsDpstDvsnVl());		// set [주택청약예부금구분]
					
					// 결과코드가 들어오는 경우
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			
			output = rlvActNoRegCtntInq;
			
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);
			
		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 해당계좌번호 등록내용 조회 수신(0210/215)
	 * 
	 * @param  COM_F_KLIOAKOTS00006In 해당계좌번호 등록내용 조회OMM
	 * @throws ApplicationException
	 */
	public void rlvActNoRegCtntInqRcv(COM_F_KLIOAKOTS00006In input
			) throws ApplicationException {
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String prcsDt	 					= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);	//처리일자
		String prcsYn						= " ";																											//처리여부
		String taxpfRcd					= " ";																											//세금우대결과코드 - 응답코드
		String prcsDtm 					= "";																											//처리일시        
		String taxpfTgmNo 			= "";																											//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd				= "0";																											//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            	= input.getTrnsDtm();				//전문전송일시
		taxpfTgmNo			= input.getMgntTgmCd();		//세금우대전문번호
		prcsYn 					= "Y";												//처리여부
		taxpfRcd 				= input.getAssoRspCd(); 			//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();			//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();			//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt								(prcsDt);											//처리일자
		tbcnetc026io.setTaxpfTgmNo					(taxpfTgmNo);								//세금우대전문번호
		tbcnetc026io.setPrcsDtm								(prcsDtm);										//처리일시
		tbcnetc026io.setPrcsYn								(prcsYn);											//처리여부
		tbcnetc026io.setTaxpfRcd							(taxpfRcd);										//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd					(nrmCnclDcd);									//정상취소구분코드
		tbcnetc026io.setRdsnBznoDcd					(input.getRrnoDvsn());					//주민(사업자)등록번호구분
		tbcnetc026io.setConmNm							(input.getConm());						//상호명
		tbcnetc026io.setTaxpfTgtpNm					(input.getName());						//세금우대대상자명
		tbcnetc026io.setInfoMnbdyDcd				(input.getInfoMnbdyDvsn());		//정보주체구분코드
		tbcnetc026io.setLrnkIncmrDcd					(input.getIncmrDvsn());				//하위소득자구분코드
		tbcnetc026io.setRescsDvsnVl						(input.getRescsDcd());					//해지구분값
		tbcnetc026io.setSavgKndVl						(input.getSavgKnd());					//저축종류값
		tbcnetc026io.setSavgNewDt						(input.getSavgNewDy());				//저축신규일자
		tbcnetc026io.setTaxpfAmt							(input.getTaxpfAmt());					//세금우대금액
		tbcnetc026io.setExpiDt								(input.getExpiDy());						//만기일자
		tbcnetc026io.setRescsDt								(input.getRescsDy());						//해지일자
		tbcnetc026io.setIntDivdPayAmt				(input.getIntDivdAmt());				//이자배당지급금액
		tbcnetc026io.setInhrtVl								(input.getInhrtYn());						//상속값
		tbcnetc026io.setHousPrpsDpstDvsnVl		(input.getHousPrpsDvsn());			//주택청약예금구분값
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0263(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
			
	}
	
	/**
	 * 세금우대등록
	 * 
	 * @param  TaxpfRegDO 세금우대등록DO
	 * @return TaxpfRegDO 세금우대등록DO
	 * @throws ApplicationException
	 */
	public TaxpfRegDO taxpfReg(TaxpfRegDO input
			) throws ApplicationException {
		
		return taxpfReg(input, "S");
	}
	
	/**
	 * 세금우대등록
	 * 
	 * @param  TaxpfRegDO 세금우대등록DO
	 * @return TaxpfRegDO 세금우대등록DO
	 * @throws ApplicationException
	 */
	public TaxpfRegDO taxpfReg(TaxpfRegDO input, String type) throws ApplicationException {
		
		TaxpfRegDO output = new TaxpfRegDO();
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00007";	// EAI Interface ID
		
		COM_F_KLIOAKOTS00007In request = new COM_F_KLIOAKOTS00007In();	// 세금우대등록 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		// 필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
//		if (StringUtils.isEmpty(input.getConm())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "상호(기업체명)" });
//		}
		if (StringUtils.isEmpty(input.getName())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"성명(대표자)"}, new Object[]{ "세금우대전문", "성명(대표자)" });
		}
		if (StringUtils.isEmpty(input.getInfoMnbdyDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"정보주체(구장애인)구분"}, new Object[]{ "세금우대전문", "정보주체(구장애인)구분" });
		}
		if (StringUtils.isEmpty(input.getIncmrDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"저소득자구분(농어가저축)"}, new Object[]{ "세금우대전문", "저소득자구분(농어가저축)" });
		}
		if (StringUtils.isEmpty(input.getSavgKnd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"저축종류"}, new Object[]{ "세금우대전문", "저축종류" });
		}
		if (StringUtils.isEmpty(input.getOpenOffcCd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"개설점포코드"}, new Object[]{ "세금우대전문", "개설점포코드" });
		}
		if (StringUtils.isEmpty(input.getActNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"계좌번호"}, new Object[]{ "세금우대전문", "계좌번호" });
		}
		if (StringUtils.isEmpty(input.getActOpenDy())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"계좌개설일"}, new Object[]{ "세금우대전문", "계좌개설일" });
		}
		if (input.getTaxpfAmt().compareTo(BigDecimal.ZERO) == 0)  {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대금액(단위:원)"}, new Object[]{ "세금우대전문", "세금우대금액(단위:원)" });
		}
		if (StringUtils.isEmpty(input.getExpiDy())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"만기일"}, new Object[]{ "세금우대전문", "만기일" });
		}
		if (StringUtils.isEmpty(input.getInhrtYn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"상속여부"}, new Object[]{ "세금우대전문", "상속여부" });
		}
		if (StringUtils.isEmpty(input.getHousPrpsDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주택청약예부금구분"}, new Object[]{ "세금우대전문", "주택청약예부금구분" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		//String rrno = SecuUtil.getDecValue(input.getRrno(), EncType.rrno);
		
		// 정합성체크
		/*
		if (rrno.length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (input.getRrnoDvsn().length() != 1) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
//		if (input.getConm().length() != 40) {
//			throw new ApplicationException( "APCME0005", new Object[]{"상호(기업체명)"}, new Object[]{ "세금우대전문", "상호(기업체명)" });
//		}
//		if (input.getName().length() != 20) {
//			throw new ApplicationException( "APCME0005", new Object[]{"성명(대표자)"}, new Object[]{ "세금우대전문", "성명(대표자)" });
//		}
		if (input.getInfoMnbdyDvsn().length() != 1) {
			throw new ApplicationException( "APCME0005", new Object[]{"정보주체(구장애인)구분"}, new Object[]{ "세금우대전문", "정보주체(구장애인)구분" });
		}
		if (input.getIncmrDvsn().length() != 1) {
			throw new ApplicationException( "APCME0005", new Object[]{"저소득자구분(농어가저축)"}, new Object[]{ "세금우대전문", "저소득자구분(농어가저축)" });
		}
		if (input.getSavgKnd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"저축종류"}, new Object[]{ "세금우대전문", "저축종류" });
		}
		if (input.getOpenOffcCd().length() != 7) {
			throw new ApplicationException( "APCME0005", new Object[]{"개설점포코드"}, new Object[]{ "세금우대전문", "개설점포코드" });
		}
		/*
		if (input.getActNo().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"계좌번호"}, new Object[]{ "세금우대전문", "계좌번호" });
		}
		*/
		if (input.getActOpenDy().length() != 8) {
			throw new ApplicationException( "APCME0005", new Object[]{"계좌개설일"}, new Object[]{ "세금우대전문", "계좌개설일" });
		}
		if (input.getExpiDy().length() != 8) {
			throw new ApplicationException( "APCME0005", new Object[]{"만기일"}, new Object[]{ "세금우대전문", "만기일" });
		}
		if (input.getInhrtYn().length() != 1) {
			throw new ApplicationException( "APCME0005", new Object[]{"상속여부"}, new Object[]{ "세금우대전문", "상속여부" });
		}
		if (input.getHousPrpsDvsn().length() != 1) {
			throw new ApplicationException( "APCME0005", new Object[]{"주택청약예부금구분"}, new Object[]{ "세금우대전문", "주택청약예부금구분" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		
		// ------------- 세금우대처리로그테이블 input ------------//
		String prcsDtm 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 	= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		logger.debug("채번taxpfTgmNo IO  [{}]", new Object [] {taxpfTgmNo});
		
		String prcsDt	 						= prcsDtm.substring(0,8);		//처리일자
		String dpsTxNo 						= "";												//입금거래번호
		String prcsDofOrgNo 			= input.getPrcsDofOrgNo();	//처리지점조직번호
		String prcsFofOrgNo 				= input.getPrcsFofOrgNo();		//처리영업소조직번호
		String prcsEno							= input.getPrcsEno();				//처리사원번호
		String contNo							= "";												//계약번호
		String savgPrdcd						= "";												//저축상품코드
		String prcsYn							= " ";												//처리여부
		String taxpfRcd						= " ";												//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 				= "0400";										//세금우대전문종류코드
		String taxpfBzDcd					= "210";											//세금우대업무구분코드
		String taxpfBzPrcsDcd 			= input.getTaxpfBzPrcsDcd();	//세금우대업무처리구분코드 
		String nrmCnclDcd					= "0";												//정상취소구분코드
		String taxpfTgmDataCtnt		= " ";												//세금우대전문데이터내용
		int dataLength = 0;																		//DATA LENGTH
		String strDataLength = "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
		
	    //데이터 길이
		dataLength = 13 + 1 + 40 + 20 + 1 + 1 + 2 + 7 + 16 + 8 + 10 + 8 + 1 + 1 + 14;
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {
			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		    
		    //taxpfTgmNo = "0" + taxpfTgmNo;
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
		    request.setSysId						("KL");										//SYSTEM-ID
			request.setTgmKndCd			(taxpfTgmKcd);						//전문종별코드
			request.setAssoBusiGb			(taxpfBzDcd);							//업무구분코드
			request.setTrnsDtm				(prcsDtm); 								//전문전송일시
			request.setMgntTgmCd		(taxpfTgmNo); 						//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd			("L51"); 										//송신기관코드
			request.setRcvInstCd				("L00"); 										//수신기관코드
			request.setAssoTrnsGb			("      "); 										//거래구분코드	 		- 공백[6](AS-IS동일)
			request.setDataLen				(strDataLength); 					//DATA LENGTH			
			request.setTerId						("LINA-ID   "); 							//단말기ID					- 공백[10](AS-IS동일)
			request.setTerOpId				("KLICS-ID  "); 							//단말기조작자ID		- 공백[10](AS-IS동일)
			request.setTerOwnNm			("LINA                "); 					//단말기조작자성명	- 공백[20](AS-IS동일)
			request.setDataEtc					("            "); 								//예비필드					- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno						(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn				(input.getRrnoDvsn());																	// set [주민(사업자)등록번호구분]
			request.setConm					(input.getConm());																		// set [상호(기업체명)]
			request.setName					(input.getName());																		// set [성명(대표자)]
			request.setInfoMnbdyDvsn	(input.getInfoMnbdyDvsn());														// set [정보주체(구장애인)구분]
			request.setIncmrDvsn			(input.getIncmrDvsn());																// set [저소득자구분(농어가저축)]
			request.setSavgKnd				(input.getSavgKnd());																	// set [저축종류]
			request.setOpenOffcCd		(input.getOpenOffcCd());															// set [개설점포코드]
			request.setActNo					
					(SecuUtil.getDecValue(input.getActNo(), SecuUtil.EncType.actNo));							// set [계좌번호]
			request.setActOpenDy			(input.getActOpenDy());																// set [계좌개설일]
			request.setTaxpfAmt				(input.getTaxpfAmt());																	// set [세금우대금액(단위:원)]
			request.setExpiDy					(input.getExpiDy());																		// set [만기일]
			request.setInhrtYn					(input.getInhrtYn());																		// set [상속여부]
			request.setHousPrpsDvsn	(input.getHousPrpsDvsn());															// set [주택청약예부금구분]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm							(prcsDtm);										//처리일시
			tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);								//세금우대전문번호
			tbcnetc026io.setPrcsDt							(prcsDt);											//처리일자
			tbcnetc026io.setDpsTxNo						(dpsTxNo);										//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo				(prcsDofOrgNo);								//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo				(prcsFofOrgNo);								//처리영업소조직번호
			tbcnetc026io.setPrcsEno							(prcsEno);											//처리사원번호
			tbcnetc026io.setContNo							(contNo);											//계약번호
			tbcnetc026io.setSavgPrdcd						(savgPrdcd);										//저축상품코드
			tbcnetc026io.setPrcsYn							(prcsYn);											//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);										//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);								//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);									//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd			(taxpfBzPrcsDcd);							//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);									//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);						//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			tbcnetc026io.setRdsnBznoDcd				(input.getRrnoDvsn());					// set [주민(사업자)등록번호구분]
			tbcnetc026io.setInfoMnbdyDcd			(input.getInfoMnbdyDvsn());		// set [정보주체(구장애인)구분]
			tbcnetc026io.setLrnkIncmrDcd				(input.getIncmrDvsn());				// set [저소득자구분(농어가저축)]
			tbcnetc026io.setConmNm						(input.getConm());						// set [상호(기업체명)]
			tbcnetc026io.setTaxpfTgtpNm				(input.getName());						// set [성명(대표자)]
			tbcnetc026io.setSavgKndVl					(input.getSavgKnd());					// set [저축종류]
			tbcnetc026io.setActNo							
				(SecuUtil.getEncValue(input.getActNo(), SecuUtil.EncType.actNo));	// set [계좌번호]
			tbcnetc026io.setOpenOffcId					(input.getOpenOffcCd());			// set [개설점포코드]
			tbcnetc026io.setActOpenDt					(input.getActOpenDy());				// set [계좌개설일]
			tbcnetc026io.setTaxpfAmt						(input.getTaxpfAmt());					// set [세금우대금액(단위:원)]
			tbcnetc026io.setExpiDt							(input.getExpiDy());						// set [만기일]
			tbcnetc026io.setInhrtVl							(input.getInhrtYn());						// set [상속여부]
			tbcnetc026io.setHousPrpsDpstDvsnVl	(input.getHousPrpsDvsn());			// set [주택청약예부금구분]
			
			tbcnetc026io.setLastChgrId					(FwUtil.getUserId());						// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId				(FwUtil.getPgmId());						// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo			(FwUtil.getTrmNo());						// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if ("S".equals(type)) {
				output = this.getTaxpfRegRece(prcsDt, taxpfTgmNo);
			}
			// ------------- 응답 전문 MOVE END --------------------- //
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		
		
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대등록
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfRegDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public TaxpfRegDO getTaxpfRegRece(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		TaxpfRegDO taxpfReg  = null;
		
		TaxpfRegDO output = new TaxpfRegDO();
		
		logger.debug("call TaxpfRegDO");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( out !=null && !StringUtils.isEmpty(out.getTaxpfRcd()) ) {
					
					taxpfReg = new TaxpfRegDO();
					
					taxpfReg.setTgmKndCd				(out.getTaxpfTgmKcd());							// set [전문종별코드]
					taxpfReg.setAssoBusiGb				(out.getTaxpfBzDcd());								// set [협회업무구분]
					taxpfReg.setTrnsDtm					(out.getPrcsDtm());									// set [전문전송일시]
					taxpfReg.setMgntTgmCd			(out.getTaxpfTgmNo().toString());		// set [전문관리번호]
					taxpfReg.setSndInstCd					("L51");															// set [전송기관코드]
					taxpfReg.setRcvInstCd					("L00");															// set [수신기관코드]
					taxpfReg.setAssoRspCd				(out.getTaxpfRcd());									// set [협회응답코드]
					
					taxpfReg.setRrnoErr						(out.getRdsnBznoErrVl());						// set [주민등록번호error]
					taxpfReg.setRrnoDvsnErr				(out.getRdsnBznoDcdErrVl());				// set [주민등록번호구분error]
					taxpfReg.setConmErr					(out.getConmErrVl());								// set [상호error]
					taxpfReg.setNameErr					(out.getTaxpfTgtpNmErrVl());				// set [성명error]
					taxpfReg.setInfoMnbdyDvsnErr	(out.getInfoMnbdyDcdErrVl());				// set [정보주체(구장애인)구분error]
					taxpfReg.setIncmrDvsnErr			(out.getLrnkIncmrDcdErrVl());				// set [저소득자구분error]
					taxpfReg.setSavgKndErr				(out.getSavgKndErrVl());							// set [저축종류error]
					taxpfReg.setOpenOffcCdErr		(out.getOpenOffcIdErrVl());					// set [개설점포코드error]
					taxpfReg.setActNoErr					(out.getActNoErrVl());								// set [계좌번호error]
					taxpfReg.setActOpenDyErr			(out.getActOpenDtErrVl());						// set [계좌개설일error]
					taxpfReg.setTaxpfAmtErr				(out.getTaxpfAmtErrVl());						// set [세금우대금액error]
					taxpfReg.setExpiDyErr					(out.getExpiDtErrVl());								// set [만기일error]
					taxpfReg.setInhrtYnErr					(out.getInhrtErrVl());									// set [상속여부error]
					taxpfReg.setHousPrpsDvsnErr	(out.getHousPrpsDpstDvsnVlErrVl());	// set [주택청약예부금구분error]
					
					// 결과코드가 들어오는 경우
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			
			output = taxpfReg;
			
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 세금우대등록 수신(0410/210)
	 * 
	 * @param  COM_F_KLIOAKOTS00007In 해당계좌번호 등록내용 조회OMM
	 * @throws ApplicationException
	 */
	public void taxpfRegRcv(COM_F_KLIOAKOTS00007In input
			) throws ApplicationException {
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		String prcsDt	 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		String prcsYn				= " ";														//처리여부
		String taxpfRcd			= " ";														//세금우대결과코드 - 응답코드
		String prcsDtm 			= "";														//처리일시        
		String taxpfTgmNo 	= "";														//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd		= "0";														//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            = input.getTrnsDtm();						//전문전송일시
		taxpfTgmNo    = input.getMgntTgmCd();				//세금우대전문번호
		prcsYn 				= "Y";														//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 					//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();				//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();				//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt										(prcsDt);											//처리일자
		tbcnetc026io.setTaxpfTgmNo							(taxpfTgmNo);								//세금우대전문번호
		tbcnetc026io.setPrcsDtm										(prcsDtm);										//처리일시
		tbcnetc026io.setPrcsYn										(prcsYn);											//처리여부
		tbcnetc026io.setTaxpfRcd									(taxpfRcd);										//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd							(nrmCnclDcd);									//정상취소구분코드
		tbcnetc026io.setRdsnBznoErrVl							(input.getRrnoErr());						// set [주민등록번호error]
		tbcnetc026io.setRdsnBznoDcdErrVl					(input.getRrnoDvsnErr());			// set [주민등록번호구분error]		
		tbcnetc026io.setConmErrVl								(input.getConmErr());					// set [상호error]
		tbcnetc026io.setTaxpfTgtpNmErrVl					(input.getNameErr());					// set [성명error]
		tbcnetc026io.setInfoMnbdyDcdErrVl				(input.getInfoMnbdyDvsnErr());// set [정보주체(구장애인)구분error]
		tbcnetc026io.setLrnkIncmrDcdErrVl					(input.getIncmrDvsnErr());			// set [저소득자구분error]
		tbcnetc026io.setSavgKndErrVl							(input.getSavgKndErr());				// set [저축종류error]
		tbcnetc026io.setOpenOffcIdErrVl						(input.getOpenOffcCdErr());		// set [개설점포코드error]
		tbcnetc026io.setActNoErrVl								(input.getActNoErr());					// set [계좌번호error]
		tbcnetc026io.setActOpenDtErrVl						(input.getActOpenDyErr());			// set [계좌개설일error]
		tbcnetc026io.setTaxpfAmtErrVl							(input.getTaxpfAmtErr());			// set [세금우대금액error]
		tbcnetc026io.setExpiDtErrVl								(input.getExpiDyErr());					// set [만기일error]
		tbcnetc026io.setInhrtErrVl									(input.getInhrtYnErr());				// set [상속여부error]
		tbcnetc026io.setHousPrpsDpstDvsnVlErrVl	(input.getHousPrpsDvsnErr());	// set [주택청약예부금구분error]
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0264(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
				
	}
	
	/**
	 * 세금우대해지
	 * 
	 * @param  TaxpfRescsDO 세금우대해지DO
	 * @return TaxpfRescsDO 세금우대해지DO
	 * @throws ApplicationException
	 */
	public TaxpfRescsDO taxpfRescs(TaxpfRescsDO input) throws ApplicationException {
		return taxpfRescs(input, "S");
	}
	
	/**
	 * 세금우대해지
	 * 
	 * @param  TaxpfRescsDO 세금우대해지DO
	 * @return TaxpfRescsDO 세금우대해지DO
	 * @throws ApplicationException
	 */
	public TaxpfRescsDO taxpfRescs(TaxpfRescsDO input, String type) throws ApplicationException {
		
		TaxpfRescsDO output = new TaxpfRescsDO();
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00008";	// EAI Interface ID
		
		COM_F_KLIOAKOTS00008In request = new COM_F_KLIOAKOTS00008In();	// 세금우대해지 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
//		if (StringUtils.isEmpty(input.getConm())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "상호(기업체명)" });
//		}
		if (StringUtils.isEmpty(input.getName())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"성명(대표자)"}, new Object[]{ "세금우대전문", "성명(대표자)" });
		}
		if (StringUtils.isEmpty(input.getRescsKnd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"해지종류"}, new Object[]{ "세금우대전문", "해지종류" });
		}
		if (StringUtils.isEmpty(input.getSavgKnd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"저축종류"}, new Object[]{ "세금우대전문", "저축종류" });
		}
		if (StringUtils.isEmpty(input.getOpenOffcCd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"개설점포코드"}, new Object[]{ "세금우대전문", "개설점포코드" });
		}
		if (StringUtils.isEmpty(input.getActNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"계좌번호"}, new Object[]{ "세금우대전문", "계좌번호" });
		}
		if (StringUtils.isEmpty(input.getActRescsDy())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"계좌해지일"}, new Object[]{ "세금우대전문", "계좌해지일" });
		}
//		if (BigDecimal.ZERO == input.getTaxpfAmt()) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "세금우대금액(단위:원)" });
//		}
//		if (BigDecimal.ZERO == input.getIntDivdAmt()) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "이자배당지급액(단위:원)" });
//		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		//String rrno = SecuUtil.getDecValue(input.getRrno(), EncType.rrno);
		
		// 정합성체크
		/*
		if (rrno.length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (input.getRrnoDvsn().length() != 1) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
//		if (input.getConm().length() != 40) {
//			throw new ApplicationException( "APCME0005", new Object[]{""}, new Object[]{ "세금우대전문", "상호(기업체명)" });
//		}
//		if (input.getName().length() != 20) {
//			throw new ApplicationException( "APCME0005", new Object[]{""}, new Object[]{ "세금우대전문", "성명(대표자)" });
//		}
		if (input.getRescsKnd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"해지종류"}, new Object[]{ "세금우대전문", "해지종류" });
		}
		if (input.getSavgKnd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"저축종류"}, new Object[]{ "세금우대전문", "저축종류" });
		}
		if (input.getOpenOffcCd().length() != 7) {
			throw new ApplicationException( "APCME0005", new Object[]{"개설점포코드"}, new Object[]{ "세금우대전문", "개설점포코드" });
		}
		/*
		if (input.getActNo().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"계좌번호"}, new Object[]{ "세금우대전문", "계좌번호" });
		}
		*/
		if (input.getActRescsDy().length() != 8) {
			throw new ApplicationException( "APCME0005", new Object[]{"계좌해지일"}, new Object[]{ "세금우대전문", "계좌해지일" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input ------------//
		String prcsDtm 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 	= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		logger.debug("채번taxpfTgmNo IO  [{}]", new Object [] {taxpfTgmNo});
		
		String prcsDt	 						= prcsDtm.substring(0,8);		//처리일자
		String dpsTxNo 						= "";												//입금거래번호
		String prcsDofOrgNo 			= input.getPrcsDofOrgNo();	//처리지점조직번호
		String prcsFofOrgNo 				= input.getPrcsFofOrgNo();		//처리영업소조직번호
		String prcsEno							= input.getPrcsEno();				//처리사원번호
		String contNo							= "";												//계약번호
		String savgPrdcd						= "";												//저축상품코드
		String prcsYn							= " ";												//처리여부
		String taxpfRcd						= " ";												//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 				= "0500";										//세금우대전문종류코드
		String taxpfBzDcd					= "210";											//세금우대업무구분코드
		String taxpfBzPrcsDcd 			= input.getTaxpfBzPrcsDcd();	//세금우대업무처리구분코드 
		String nrmCnclDcd					= "0";												//정상취소구분코드
		String taxpfTgmDataCtnt		= " ";												//세금우대전문데이터내용
		int dataLength 						= 0;													//DATA LENGTH
		String strDataLength 			= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();										//저축상품코드
		}
		
	    //데이터 길이
		dataLength = 13 + 1 + 40 + 20 + 2 + 2 + 7 + 16 + 8 + 10 + 10 + 11;
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {
			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    //taxpfTgmNo = "0" + taxpfTgmNo;
		    
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
			request.setSysId					("KL");							//SYSTEM-ID
			request.setTgmKndCd		(taxpfTgmKcd);			//전문종별코드
			request.setAssoBusiGb		(taxpfBzDcd);				//업무구분코드
			request.setTrnsDtm			(prcsDtm); 					//전문전송일시
			request.setMgntTgmCd	(taxpfTgmNo); 			//전문관리번호(채번해야함!! - 0000001)
			
			request.setSndInstCd		("L51"); 							//송신기관코드
			request.setRcvInstCd			("L00"); 							//수신기관코드
			request.setAssoTrnsGb		("      "); 							//거래구분코드	 	- 공백[6](AS-IS동일)
			request.setDataLen			(strDataLength); 		//DATA LENGTH			
			request.setTerId					("LINA-ID   "); 				//단말기ID		 	- 공백[10](AS-IS동일)
			request.setTerOpId			("KLICS-ID  "); 				//단말기조작자ID 	- 공백[10](AS-IS동일)
			request.setTerOwnNm		("LINA                "); 		//단말기조작자성명  - 공백[20](AS-IS동일)
			request.setDataEtc				("            "); 					//예비필드			- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno					(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn			(input.getRrnoDvsn());																	// set [주민(사업자)등록번호구분]
			request.setConm				(input.getConm());																		// set [상호(기업체명)]
			request.setName				(input.getName());																		// set [성명(대표자)]
			request.setRescsKnd			(input.getRescsKnd());																	// set [해지종류]
			request.setSavgKnd			(input.getSavgKnd());																	// set [저축종류]
			request.setOpenOffcCd	(input.getOpenOffcCd());															// set [개설점포코드]

			// 2013-11-15 : OLD 계좌번호 조회부분 추가
			request.setActNo				
				(SecuUtil.getDecValue(this.getOldContNo(input.getActNo()), EncType.actNo));	// set [계좌번호]
			request.setActRescsDy		(input.getActRescsDy());																// set [계좌해지일]
			request.setTaxpfAmt			(input.getTaxpfAmt());																	// set [세금우대금액(단위:원)]
			request.setIntDivdAmt		(input.getIntDivdAmt());																// set [이자배당지급액(단위:원)]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm						(prcsDtm);						//처리일시
			tbcnetc026io.setTaxpfTgmNo			(taxpfTgmNo);				//세금우대전문번호
			tbcnetc026io.setPrcsDt						(prcsDt);							//처리일자
			tbcnetc026io.setDpsTxNo					(dpsTxNo);						//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo			(prcsDofOrgNo);				//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo			(prcsFofOrgNo);				//처리영업소조직번호
			tbcnetc026io.setPrcsEno						(prcsEno);							//처리사원번호
			tbcnetc026io.setContNo						(contNo);							//계약번호
			tbcnetc026io.setSavgPrdcd					(savgPrdcd);						//저축상품코드
			tbcnetc026io.setPrcsYn						(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd					(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd			(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd				(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd		(taxpfBzPrcsDcd);			//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd			(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt(taxpfTgmDataCtnt);	//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
								(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			tbcnetc026io.setRdsnBznoDcd			(input.getRrnoDvsn());										// set [주민(사업자)등록번호구분]			
			tbcnetc026io.setConmNm					(input.getConm());											// set [상호(기업체명)]
			tbcnetc026io.setTaxpfTgtpNm			(input.getName());											// set [성명(대표자)]
			tbcnetc026io.setSavgKndVl				(input.getSavgKnd());										// set [저축종류]
			tbcnetc026io.setActNo						
				(SecuUtil.getEncValue(this.getOldContNo(input.getActNo()), SecuUtil.EncType.actNo));		// set [계좌번호]
			tbcnetc026io.setOpenOffcId				(input.getOpenOffcCd());								// set [개설점포코드]
			tbcnetc026io.setRescsKcd					(input.getRescsKnd());	   									// set [해지종류]
			tbcnetc026io.setTaxpfAmt					(input.getTaxpfAmt());										// set [세금우대금액(단위:원)]
			tbcnetc026io.setActRescsDt				(input.getActRescsDy());									// set [계좌해지일]			
			tbcnetc026io.setIntDivdPayAmt		(input.getIntDivdAmt());									// set [이자배당지급액]
			
			tbcnetc026io.setLastChgrId				(FwUtil.getUserId());					// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId			(FwUtil.getPgmId());					// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo		(FwUtil.getTrmNo());					// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if ("S".equals(type)) {
				output = this.getTaxpfRescsRece(prcsDt, taxpfTgmNo);
			}
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});	
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		
		
		
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대해지
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfRegDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public TaxpfRescsDO getTaxpfRescsRece(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		TaxpfRescsDO taxpfRescs  = null;
		
		TaxpfRescsDO output = new TaxpfRescsDO();
		
		logger.debug("call TaxpfRegDO");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( out != null ) {
					
					taxpfRescs = new TaxpfRescsDO();
					
					taxpfRescs.setTgmKndCd		(out.getTaxpfTgmKcd());						// set [전문종별코드]
					taxpfRescs.setAssoBusiGb		(out.getTaxpfBzDcd());							// set [협회업무구분]
					taxpfRescs.setTrnsDtm				(out.getPrcsDtm());								// set [전문전송일시]
					taxpfRescs.setMgntTgmCd		(out.getTaxpfTgmNo().toString());	// set [전문관리번호]
					taxpfRescs.setSndInstCd			("L51");														// set [전송기관코드]
					taxpfRescs.setRcvInstCd			("L00");														// set [수신기관코드]
					taxpfRescs.setAssoRspCd			(out.getTaxpfRcd());								// set [협회응답코드]
					
					taxpfRescs.setRrnoErr				(out.getRdsnBznoErrVl());					// set [주민등록번호error]
					taxpfRescs.setRrnoDvsnErr		(out.getRdsnBznoDcdErrVl());			// set [주민등록번호구분error]
					taxpfRescs.setConmErr				(out.getConmErrVl());							// set [상호error]
					taxpfRescs.setNameErr				(out.getTaxpfTgtpNmErrVl());			// set [성명error]
					taxpfRescs.setRescsKndErr		(out.getRescsKcdErrVl());						// set [해지종류error]
					taxpfRescs.setSavgKndErr		(out.getSavgKndErrVl());						// set [저축종류error]
					taxpfRescs.setOpenOffcCdErr(out.getOpenOffcIdErrVl());				// set [개설점포코드error]
					taxpfRescs.setActNoErr			(out.getActNoErrVl());							// set [계좌번호error]					
					taxpfRescs.setActRescsDyErr	(out.getActRescsDtErrVl());					// set [계좌해지일error]
					taxpfRescs.setTaxpfAmtErr		(out.getTaxpfAmtErrVl());					// set [세금우대금액error]
					taxpfRescs.setIntDivdAmtErr	(out.getIntDivdPayAmtErrVl());			// set [이자배당지급액error]
					
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			
			output = taxpfRescs;
					
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 세금우대해지 수신(0510/210)
	 * 
	 * @param  COM_F_KLIOAKOTS00008In 해당계좌번호 등록내용 조회OMM
	 * @throws ApplicationException
	 */
	public void taxpfRescsRcv(COM_F_KLIOAKOTS00008In input
			) throws ApplicationException {
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		String prcsDt	 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		String prcsYn				= " ";														//처리여부
		String taxpfRcd			= " ";														//세금우대결과코드 - 응답코드
		String prcsDtm 			= "";														//처리일시        
		String taxpfTgmNo 	= "";														//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd		= "0";														//정상취소구분코드
		
		
		logger.debug("수신전문 [{}]", input);
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm             	= input.getTrnsDtm();				//전문전송일시
		taxpfTgmNo        = input.getMgntTgmCd();		//세금우대전문번호
		prcsYn 					= "Y";												//처리여부
		taxpfRcd 				= input.getAssoRspCd(); 			//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();			//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();			//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt							(prcsDt);										//처리일자
		tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);							//세금우대전문번호
		tbcnetc026io.setPrcsDtm							(prcsDtm);									//처리일시
		tbcnetc026io.setPrcsYn							(prcsYn);										//처리여부
		tbcnetc026io.setTaxpfRcd						(taxpfRcd);									//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);								//정상취소구분코드
		tbcnetc026io.setRdsnBznoErrVl				(input.getRrnoErr());					// set [주민등록번호error]
		tbcnetc026io.setRdsnBznoDcdErrVl		(input.getRrnoDvsnErr());		// set [주민등록번호구분error]		
		tbcnetc026io.setConmErrVl					(input.getConmErr());				// set [상호error]
		tbcnetc026io.setTaxpfTgtpNmErrVl		(input.getNameErr());				// set [성명error]
		tbcnetc026io.setRescsKcdErrVl				(input.getRescsKndErr());			// set [정보주체(구장애인)구분error]
		tbcnetc026io.setSavgKndErrVl				(input.getSavgKndErr());			// set [저축종류error]
		tbcnetc026io.setOpenOffcIdErrVl			(input.getOpenOffcCdErr());	// set [개설점포코드error]
		tbcnetc026io.setActNoErrVl					(input.getActNoErr());				// set [계좌번호error]
		tbcnetc026io.setActRescsDtErrVl			(input.getActRescsDyErr());		// set [계좌해지일error]
		tbcnetc026io.setTaxpfAmtErrVl				(input.getTaxpfAmtErr());		// set [세금우대금액error]		
		tbcnetc026io.setIntDivdPayAmtErrVl	(input.getIntDivdAmtErr());		// set [이자배당지급금액error]
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0265(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
				
	}
	
	/**
	 * 세금우대해지취소
	 * 
	 * @param  TaxpfRescsCnclDO 세금우대해지취소DO
	 * @return TaxpfRescsCnclDO 세금우대해지취소DO
	 * @throws ApplicationException
	 */
	public TaxpfRescsCnclDO taxpfRescsCncl(TaxpfRescsCnclDO input
			) throws ApplicationException {
		
		return taxpfRescsCncl(input, "S");
		
	}
	
	/**
	 * 세금우대해지취소
	 * 
	 * @param  TaxpfRescsCnclDO 세금우대해지취소DO
	 * @return TaxpfRescsCnclDO 세금우대해지취소DO
	 * @throws ApplicationException
	 */
	public TaxpfRescsCnclDO taxpfRescsCncl(TaxpfRescsCnclDO input, String type
			) throws ApplicationException {
		
		TaxpfRescsCnclDO output = new TaxpfRescsCnclDO();
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00009";	// EAI Interface ID
		
		COM_F_KLIOSKOTS00009In request = new COM_F_KLIOSKOTS00009In();	// 세금우대해지취소 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getSavgKnd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"저축종류"}, new Object[]{ "세금우대전문", "저축종류" });
		}
		if (StringUtils.isEmpty(input.getOpenOffcCd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"개설점포코드"}, new Object[]{ "세금우대전문", "개설점포코드" });
		}
		if (StringUtils.isEmpty(input.getActNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"계좌번호"}, new Object[]{ "세금우대전문", "계좌번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		// 정합성체크
		/*
		if (input.getRrno().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (input.getRrnoDvsn().length() != 1) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getSavgKnd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"저축종류"}, new Object[]{ "세금우대전문", "저축종류" });
		}
		if (input.getOpenOffcCd().length() != 7) {
			throw new ApplicationException( "APCME0005", new Object[]{"개설점포코드"}, new Object[]{ "세금우대전문", "개설점포코드" });
		}
		/*
		if (input.getActNo().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"계좌번호"}, new Object[]{ "세금우대전문", "계좌번호" });
		}
		*/
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input ------------//
		String prcsDtm 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 	= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		logger.debug("채번taxpfTgmNo IO  [{}]", new Object [] {taxpfTgmNo});
		
		String prcsDt	 					= prcsDtm.substring(0,8);				//처리일자
		String dpsTxNo 					= "";														//입금거래번호
		String prcsDofOrgNo 		= input.getPrcsDofOrgNo();			//처리지점조직번호
		String prcsFofOrgNo 			= input.getPrcsFofOrgNo();				//처리영업소조직번호
		String prcsEno						= input.getPrcsEno();						//처리사원번호
		String contNo						= "";														//계약번호
		String savgPrdcd					= "";														//저축상품코드
		String prcsYn						= " ";														//처리여부
		String taxpfRcd					=	" ";														//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 			= "0600";												//세금우대전문종류코드
		String taxpfBzDcd				= "260";													//세금우대업무구분코드
		String taxpfBzPrcsDcd 		= input.getTaxpfBzPrcsDcd();			//세금우대업무처리구분코드		
		String nrmCnclDcd				= "0";														//정상취소구분코드
		String taxpfTgmDataCtnt	= " ";														//세금우대전문데이터내용
		int dataLength 					= 0;															//DATA LENGTH
		String strDataLength 		= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
		
	    //데이터 길이
		dataLength = 13 + 1 + 2 + 7 + 16 + 5;
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {

			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
			request.setSysId					("KL");										//SYSTEM-ID
			request.setTgmKndCd		(taxpfTgmKcd);						//전문종별코드
			request.setAssoBusiGb		(taxpfBzDcd);							//업무구분코드
			request.setTrnsDtm			(prcsDtm); 								//전문전송일시
			request.setMgntTgmCd	(taxpfTgmNo); 						//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd		("L51"); 										//송신기관코드
			request.setRcvInstCd			("L00"); 										//수신기관코드
			request.setAssoTrnsGb		("      "); 										//거래구분코드	 	- 공백[6](AS-IS동일)
			request.setDataLen			(strDataLength); 					//DATA LENGTH
			request.setTerId					("LINA-ID   "); 							//단말기ID		 	- 공백[10](AS-IS동일)
			request.setTerOpId			("KLICS-ID  "); 							//단말기조작자ID 	- 공백[10](AS-IS동일)
			request.setTerOwnNm		("LINA                "); 					//단말기조작자성명  - 공백[20](AS-IS동일)
			request.setDataEtc				("            "); 								//예비필드			- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno					
				(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn			(input.getRrnoDvsn());			// set [주민(사업자)등록번호구분]
			request.setSavgKnd			(input.getSavgKnd());			// set [저축종류]
			request.setOpenOffcCd	(input.getOpenOffcCd());	// set [개설점포코드]
			
			// 2013-11-15 : OLD 계좌번호 조회사항 추가
			request.setActNo		(this.getOldContNo(input.getActNo()));				// set [계좌번호]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm						(prcsDtm);					//처리일시
			tbcnetc026io.setTaxpfTgmNo			(taxpfTgmNo);			//세금우대전문번호
			tbcnetc026io.setPrcsDt						(prcsDt);						//처리일자
			tbcnetc026io.setDpsTxNo					(dpsTxNo);					//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo			(prcsDofOrgNo);			//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo			(prcsFofOrgNo);			//처리영업소조직번호
			tbcnetc026io.setPrcsEno						(prcsEno);						//처리사원번호
			tbcnetc026io.setContNo						(contNo);						//계약번호
			tbcnetc026io.setSavgPrdcd					(savgPrdcd);					//저축상품코드
			tbcnetc026io.setPrcsYn						(prcsYn);						//처리여부
			tbcnetc026io.setTaxpfRcd					(taxpfRcd);					//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd			(taxpfTgmKcd);			//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd				(taxpfBzDcd);				//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd		(taxpfBzPrcsDcd);		//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd			(nrmCnclDcd);				//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt(taxpfTgmDataCtnt);//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			
			tbcnetc026io.setLastChgrId				(FwUtil.getUserId());	// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId			(FwUtil.getPgmId());	// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo		(FwUtil.getTrmNo());	// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(ASYNC 방식) START ------ //
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if("S".equals(type)) {
				output = this.getTaxpfRescsCncl(prcsDt, taxpfTgmNo);
			}
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.debug("e");
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.debug("e");
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		

		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대해지취소
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfRescsCnclDO output  : 처리결과
	 * @throws ApplicationException
	 */	
	public TaxpfRescsCnclDO getTaxpfRescsCncl(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
	    TaxpfRescsCnclDO taxpfRegCncl  = null;
	    
		TaxpfRescsCnclDO output = new TaxpfRescsCnclDO();
		
		logger.debug("call TaxpfRescsCnclDO");
		
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for (int i=0; i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( out !=null ) {
					
					taxpfRegCncl = new TaxpfRescsCnclDO();
					
					taxpfRegCncl.setTgmKndCd				(out.getTaxpfTgmKcd());							// set [전문종별코드]
					taxpfRegCncl.setAssoBusiGb				(out.getTaxpfBzDcd());								// set [협회업무구분]
					taxpfRegCncl.setTrnsDtm					(out.getPrcsDtm());									// set [전문전송일시]
					taxpfRegCncl.setMgntTgmCd			(out.getTaxpfTgmNo().toString());		// set [전문관리번호]
					taxpfRegCncl.setSndInstCd					("L51");															// set [전송기관코드]
					taxpfRegCncl.setRcvInstCd					("L00");															// set [수신기관코드]
					taxpfRegCncl.setAssoRspCd				(out.getTaxpfRcd());									// set [협회응답코드]
					
					taxpfRegCncl.setRrnoErr						(out.getRdsnBznoErrVl());						// set [주민등록번호error]
					taxpfRegCncl.setRrnoDvsnErr				(out.getRdsnBznoDcdErrVl());				// set [주민등록번호구분error]
					taxpfRegCncl.setSavgKndErr				(out.getSavgKndErrVl());							// set [저축종류error]
					taxpfRegCncl.setOpenOffcCdErr		(out.getOpenOffcIdErrVl());					// set [개설점포코드error]
					taxpfRegCncl.setActNoErr					(out.getActNoErrVl());								// set [계좌번호error]
					
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			
			output = taxpfRegCncl;
			
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 세금우대해지취소 수신(0610/260)
	 * 
	 * @param  COM_F_KLIOAKOTS00009In 세금우대해지취소 OMM
	 * @throws ApplicationException
	 */
	public void taxpfRescsCnclRcv(COM_F_KLIOSKOTS00009In input
			) throws ApplicationException {
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		String prcsDt	 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		String prcsYn				= " ";														//처리여부
		String taxpfRcd			= " ";														//세금우대결과코드 - 응답코드
		String prcsDtm 			= "";														//처리일시        
		String taxpfTgmNo 	= "";														//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd		= "0";														//정상취소구분코드
		
		
		logger.debug("수신전문 [{}]", input);
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm             	= input.getTrnsDtm();				//전문전송일시
		taxpfTgmNo        = input.getMgntTgmCd();		//세금우대전문번호
		prcsYn 					= "Y";												//처리여부
		taxpfRcd 				= input.getAssoRspCd(); 			//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();			//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();			//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt							(prcsDt);										//처리일자
		tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);							//세금우대전문번호
		tbcnetc026io.setPrcsDtm							(prcsDtm);									//처리일시
		tbcnetc026io.setPrcsYn							(prcsYn);										//처리여부
		tbcnetc026io.setTaxpfRcd						(taxpfRcd);									//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);								//정상취소구분코드
		
		tbcnetc026io.setRdsnBznoErrVl				(input.getRrnoErr());					// set [주민등록번호error]
		tbcnetc026io.setRdsnBznoDcdErrVl		(input.getRrnoDvsnErr());		// set [주민등록번호구분error]
		tbcnetc026io.setSavgKndErrVl				(input.getSavgKndErr());			// set [저축종류error]
		tbcnetc026io.setOpenOffcIdErrVl			(input.getOffcCdErr());				// set [개설점포코드error]
		tbcnetc026io.setActNoErrVl					(input.getActNoErr());				// set [계좌번호error]
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0269(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
				
	}
	
	/**
	 * 세금우대정정
	 * 
	 * @param  TaxpfCorrcDO 세금우대정정DO
	 * @return TaxpfCorrcDO 세금우대정정DO
	 * @throws ApplicationException
	 */
	public TaxpfCorrcDO taxpfCorrc(TaxpfCorrcDO input
			) throws ApplicationException {
		
		 return this.taxpfCorrc(input, "S");		
	}
	
	/**
	 * 세금우대정정
	 * 
	 * @param  TaxpfCorrcDO 세금우대정정DO
	 * @return TaxpfCorrcDO 세금우대정정DO
	 * @throws ApplicationException
	 */
	public TaxpfCorrcDO taxpfCorrc(TaxpfCorrcDO input, String type
			) throws ApplicationException {
		
		TaxpfCorrcDO output = new TaxpfCorrcDO();
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00010";	// EAI Interface ID
		
		COM_F_KLIOAKOTS00010In request = new COM_F_KLIOAKOTS00010In();	// 세금우대정정 요청전문
		
		BigDecimal varAfchIntDivdAmt  = new BigDecimal(0);
		BigDecimal tempAfchIntDivdAmt = new BigDecimal(1);
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		
		if (StringUtils.isEmpty(input.getAfchRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후주민등록번호"}, new Object[]{ "세금우대전문", "변경후주민등록번호" });
		} 
		if (StringUtils.isEmpty(input.getAfchRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후주민등록번호구분"}, new Object[]{ "세금우대전문", "변경후주민등록번호구분" });
		} 
//		if (StringUtils.isEmpty(input.getBfchRrno())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경전주민등록번호" });
//		} 
//		if (StringUtils.isEmpty(input.getBfchRrnoDvsn())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경전주민등록번호구분" });
//		} 
//		if (StringUtils.isEmpty(input.getAfchConm())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후상호(기업체명)" });
//		} 
		if (StringUtils.isEmpty(input.getAfchName())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후성명(대표자)"}, new Object[]{ "세금우대전문", "변경후성명(대표자)" });
		} 
		if (StringUtils.isEmpty(input.getAfchInfoMnbdyDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후정보주체(구장애인)구분"}, new Object[]{ "세금우대전문", "변경후정보주체(구장애인)구분" });
		} 
		if (StringUtils.isEmpty(input.getAfchIncmrDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후저소득자구분(농어가저축)"}, new Object[]{ "세금우대전문", "변경후저소득자구분(농어가저축)" });
		} 
		if (StringUtils.isEmpty(input.getBfchSavgKnd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경전저축종류"}, new Object[]{ "세금우대전문", "변경전저축종류" });
		} 
		if (StringUtils.isEmpty(input.getBfchOpenOffcCd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경전개설점포코드"}, new Object[]{ "세금우대전문", "변경전개설점포코드" });
		} 
		if (StringUtils.isEmpty(input.getBfchActNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경전계좌번호"}, new Object[]{ "세금우대전문", "변경전계좌번호" });
		} 
//		if (StringUtils.isEmpty(input.getAfchSavgKnd())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후저축종류" });
//		} 
//		if (StringUtils.isEmpty(input.getAfchOpenOffcCd())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후개설점포코드" });
//		} 
//		if (StringUtils.isEmpty(input.getAfchActNo())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후계좌번호" });
//		} 
//		if (StringUtils.isEmpty(input.getAfchActOpenDy())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후계좌개설일" });
//		}
//		if (BigDecimal.ZERO == input.getAfchTaxpfAmt()) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후세금우대금액(단위:원)" });
//		} 
//		if (StringUtils.isEmpty(input.getAfchExpiDy())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후만기일" });
//		} 
//		if (StringUtils.isEmpty(input.getAfchFstExpiExtnDy())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후최초만기연장일" });
//		} 
		
		//생보협회에서 금액을 0으로 안 받음. 0인 경우 더해서 처리
		if (BigDecimal.ZERO.equals(input.getAfchIntDivdAmt())) {
			varAfchIntDivdAmt = varAfchIntDivdAmt.add(tempAfchIntDivdAmt);
		} else {
			varAfchIntDivdAmt = varAfchIntDivdAmt.add(input.getAfchIntDivdAmt());
		}
//		if (StringUtils.isEmpty(input.getAfchRescsKnd())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후해지종류" });
//		} 
//		if (StringUtils.isEmpty(input.getAfchInhrtYn())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후상속여부" });
//		} 
//		if (StringUtils.isEmpty(input.getAfchHousPrpsDvsn())) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후주택청약예부금구분" });
//		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		String afchRrno = SecuUtil.getDecValue(input.getAfchRrno(), EncType.rrno);
		// 정합성체크
		if (afchRrno.length() != 13) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후주민등록번호"}, new Object[]{ "세금우대전문", "변경후주민등록번호" });
		} 
		if (input.getAfchRrnoDvsn().length() != 1) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후주민등록번호구분"}, new Object[]{ "세금우대전문", "변경후주민등록번호구분" });
		} 
//		if (input.getBfchRrno().length() != 13) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경전주민등록번호" });
//		} 
//		if (input.getBfchRrnoDvsn().length() != 1) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경전주민등록번호구분" });
//		} 
//		if (input.getAfchConm().length() != 40) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후상호(기업체명)" });
//		} 
//		if (input.getAfchName().length() != 20) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후성명(대표자)" });
//		} 
		if (input.getAfchInfoMnbdyDvsn().length() != 1) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후정보주체(구장애인)구분"}, new Object[]{ "세금우대전문", "변경후정보주체(구장애인)구분" });
		} 
		if (input.getAfchIncmrDvsn().length() != 1) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경후저소득자구분"}, new Object[]{ "세금우대전문", "변경후저소득자구분(농어가저축)" });
		} 
		if (input.getBfchSavgKnd().length() != 2) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경전저축종류"}, new Object[]{ "세금우대전문", "변경전저축종류" });
		} 
		if (input.getBfchOpenOffcCd().length() != 7) {
			throw new ApplicationException( "APPAE0005", new Object[]{"변경전개설점포코드"}, new Object[]{ "세금우대전문", "변경전개설점포코드" });
		}
		
//		if (input.getBfchActNo().length() != 13) {
//			throw new ApplicationException( "APPAE0005", new Object[]{"변경전계좌번호"}, new Object[]{ "세금우대전문", "변경전계좌번호" });
//		} 
//		if (input.getAfchSavgKnd().length() != 2) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후저축종류" });
//		} 
//		if (input.getAfchOpenOffcCd().length() != 7) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후개설점포코드" });
//		} 
//		if (input.getAfchActNo().length() != 16) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후계좌번호" });
//		} 
//		if (input.getAfchActOpenDy().length() != 8) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후계좌개설일" });
//		}
//		if (input.getAfchExpiDy().length() != 8) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후만기일" });
//		} 
//		if (input.getAfchFstExpiExtnDy().length() != 8) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후최초만기연장일" });
//		} 
//		if (input.getAfchRescsKnd().length() != 2) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후해지종류" });
//		} 
//		if (input.getAfchInhrtYn().length() != 1) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후상속여부" });
//		} 
//		if (input.getAfchHousPrpsDvsn().length() != 1) {
//			throw new ApplicationException( "APPAE0005", new Object[]{""}, new Object[]{ "세금우대전문", "변경후주택청약예부금구분" });
//		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		// ------------- 세금우대처리로그테이블 input ------------//
		String prcsDtm 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 	= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		logger.debug("채번taxpfTgmNo IO  [{}]", new Object [] {taxpfTgmNo});
		
		String prcsDt	 						= prcsDtm.substring(0,8);		//처리일자
		String dpsTxNo 						= "";												//입금거래번호
		String prcsDofOrgNo 			= input.getPrcsDofOrgNo();	//처리지점조직번호
		String prcsFofOrgNo 				= input.getPrcsFofOrgNo();		//처리영업소조직번호
		String prcsEno							= input.getPrcsEno();				//처리사원번호
		String contNo							= "";												//계약번호
		String savgPrdcd						= "";												//저축상품코드
		String prcsYn							= " ";												//처리여부
		String taxpfRcd						= " ";												//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 				= "0600";										//세금우대전문종류코드
		String taxpfBzDcd					= "210";											//세금우대업무구분코드
		String taxpfBzPrcsDcd 			= input.getTaxpfBzPrcsDcd();	//세금우대업무처리구분코드 
		String nrmCnclDcd					= "0";												//정상취소구분코드
		String taxpfTgmDataCtnt		= " ";												//세금우대전문데이터내용
		int dataLength							= 0;													//DATA LENGTH
		String strDataLength 			= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
	    //데이터 길이
		dataLength = 13 + 1 + 13 + 1 + 40 + 20 + 1 + 1 + 2 + 7 + 16 + 2 + 7 + 16 + 8 + 10 + 8 + 8 + 10 + 2 + 1 + 1 + 22; 
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {

			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    //taxpfTgmNo = "0" + taxpfTgmNo;
		    
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
		    request.setSysId						("KL");										//SYSTEM-ID
			request.setTgmKndCd			(taxpfTgmKcd);						//전문종별코드
			request.setAssoBusiGb			(taxpfBzDcd);							//업무구분코드
			request.setTrnsDtm				(prcsDtm); 								//전문전송일시
			request.setMgntTgmCd		(taxpfTgmNo); 						//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd			("L51"); 										//송신기관코드
			request.setRcvInstCd				("L00"); 										//수신기관코드
			request.setAssoTrnsGb			("      "); 										//거래구분코드	 		- 공백[6](AS-IS동일)
			request.setDataLen				(strDataLength); 					//DATA LENGTH			
			request.setTerId						("LINA-ID   "); 							//단말기ID					- 공백[10](AS-IS동일)
			request.setTerOpId				("KLICS-ID  "); 							//단말기조작자ID		- 공백[10](AS-IS동일)
			request.setTerOwnNm			("LINA                "); 					//단말기조작자성명	- 공백[20](AS-IS동일)
			request.setDataEtc					("            "); 								//예비필드					- 공백(AS-IS동일)
			
			// DATA 부분
			request.setAfchRrno						(SecuUtil.getDecValue(input.getAfchRrno(), EncType.rrno));	// set [변경후주민등록번호				]					
			request.setAfchRrnoDvsn			(input.getAfchRrnoDvsn	   ());															// set [변경후주민등록번호구분			]						
			request.setBfchRrno						(SecuUtil.getDecValue(input.getBfchRrno(), EncType.rrno));	// set [변경전주민등록번호				]					
			request.setBfchRrnoDvsn				(input.getBfchRrnoDvsn      ());															// set [변경전주민등록번호구분			]					
			request.setAfchConm					(input.getAfchConm          ());																// set [변경후상호(기업체명)			]						
			request.setAfchName					(input.getAfchName	       ())	;																// set [변경후성명(대표자)				]					
			request.setAfchInfoMnbdyDvsn(input.getAfchInfoMnbdyDvsn ());													// set [변경후정보주체(구장애인)구분	]								
			request.setAfchIncmrDvsn			(input.getAfchIncmrDvsn     ());															// set [변경후저소득자구분(농어가저축)	]							
			request.setBfchSavgKnd				(input.getBfchSavgKnd       ());															// set [변경전저축종류					]			
			request.setBfchOpenOffcCd		(input.getBfchOpenOffcCd    ());														// set [변경전개설점포코드				]
			
			// 2013-11-15 : OLD계좌번호 조회추가
			//request.setBfchActNo		   			(this.getOldContNo(input.getBfchActNo()));	// set [변경전계좌번호]
			request.setBfchActNo		   			(input.getBfchActNo());											// set [변경전계좌번호]
			request.setAfchSavgKnd        		(input.getAfchSavgKnd       ());								// set [변경후저축종류					]				
			request.setAfchOpenOffcCd      (input.getAfchOpenOffcCd    ());							// set [변경후개설점포코드				]
			
			// 2013-11-15 : OLD계좌번호 조회추가
			//request.setAfchActNo		   			(this.getOldContNo(input.getAfchActNo()));	// set [변경후계좌번호]
			request.setAfchActNo		   			(input.getAfchActNo());											// set [변경후계좌번호]
			request.setAfchActOpenDy			(input.getAfchActOpenDy	   ());							// set [변경후계좌개설일				]						
			request.setAfchTaxpfAmt			(input.getAfchTaxpfAmt      ());								// set [변경후세금우대금액(단위:원)		]								
			request.setAfchExpiDy 					(input.getAfchExpiDy        ());									// set [변경후만기일					]			
			request.setAfchFstExpiExtnDy 	(input.getAfchFstExpiExtnDy ());							// set [변경후최초만기연장일			]						
			request.setAfchIntDivdAmt			(varAfchIntDivdAmt			 );										// set [변경후이자,배당지급액(단위:원)	]									
			request.setAfchRescsKnd				(input.getAfchRescsKnd	   ());								// set [변경후해지종류					]	
			request.setAfchInhrtYn				(input.getAfchInhrtYn       ());									// set [변경후상속여부					]				
			request.setAfchHousPrpsDvsn	(input.getAfchHousPrpsDvsn  ());							// set [변경후주택청약예부금구분		]								
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm								 	(prcsDtm);																	//처리일시
			tbcnetc026io.setTaxpfTgmNo						(taxpfTgmNo);															//세금우대전문번호
			tbcnetc026io.setPrcsDt								 	(prcsDt);																		//처리일자
			tbcnetc026io.setDpsTxNo								(dpsTxNo);																	//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo					 	(prcsDofOrgNo);															//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo					 	(prcsFofOrgNo);															//처리영업소조직번호
			tbcnetc026io.setPrcsEno								 	(prcsEno);																		//처리사원번호
			tbcnetc026io.setContNo								 	(contNo);																		//계약번호
			tbcnetc026io.setSavgPrdcd							 	(savgPrdcd);																	//저축상품코드
			tbcnetc026io.setPrcsYn								 	(prcsYn);																		//처리여부
			tbcnetc026io.setTaxpfRcd							 	(taxpfRcd);																	//세금우대결과코드-응답코드
			tbcnetc026io.setTaxpfTgmKcd						(taxpfTgmKcd);															//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd						 	(taxpfBzDcd);																//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd				 	(taxpfBzPrcsDcd);														//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd						(nrmCnclDcd);																//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt			(taxpfTgmDataCtnt);													//세금우대전문데이터내용

			tbcnetc026io.setAfchRdsnBzno					 	
										(SecuUtil.getEncValue(input.getAfchRrno(),EncType.rrno));							//set[변경후주민등록번호]
			tbcnetc026io.setAfchRdsnBznoDcd				(input.getAfchRrnoDvsn());									//set[변경후주민등록번호구분]
			tbcnetc026io.setBfchRdsnBzno
										(SecuUtil.getEncValue(input.getBfchRrno(),EncType.rrno));								//set[변경전주민등록번호]
			tbcnetc026io.setBfchRdsnBznoDcd				(input.getBfchRrnoDvsn());										//set[변경전주민등록번호구분]
			tbcnetc026io.setAfchConmNm						(input.getAfchConm());											//set[변경후상호(기업체명)																									]
			tbcnetc026io.setAfchTaxpfTgtpNm				(input.getAfchName());											//set[변경후성명(대표자)]
			tbcnetc026io.setAfchInfoMnbdyDcd			(input.getAfchInfoMnbdyDvsn());							//set[변경후정보주체(구장애인)구분]
			tbcnetc026io.setAfchLrnkIncmrDcd			 	(input.getAfchIncmrDvsn());									//set[변경후저소득자구분(농어가저축)]
			tbcnetc026io.setBfchSavgKndVl					(input.getBfchSavgKnd());										//set[변경전저축종류]
			tbcnetc026io.setBfchOpenOffcId				 	(input.getBfchOpenOffcCd());								//set[변경전개설점포코드]
			tbcnetc026io.setBfchActNo							(this.getOldContNo(input.getBfchActNo()));	//set[변경전계좌번호]
			tbcnetc026io.setAfchSavgKndVl					(input.getAfchSavgKnd());										//set[변경후저축종류]
			tbcnetc026io.setAfchOpenOffcId				 	(input.getAfchOpenOffcCd());								//set[변경후개설점포코드]
			tbcnetc026io.setAfchActNo							(this.getOldContNo(input.getAfchActNo()));	//set[변경후계좌번호]
			tbcnetc026io.setAfchActOpenDt					(input.getAfchActOpenDy());									//set[변경후계좌개설일]
			tbcnetc026io.setAfchTaxpfAmt					 	(input.getAfchTaxpfAmt());									//set[변경후세금우대금액(단위:원)]
			tbcnetc026io.setAfchExpiDt						 	(input.getAfchExpiDy());											//set[변경후만기일																																																		]
			tbcnetc026io.setAfchFstExpiExtnDt			 	(input.getAfchFstExpiExtnDy());								//set[변경후최초만기연장일]
			tbcnetc026io.setAfchIntDivdPayAmt			(varAfchIntDivdAmt);												//set[변경후이자,배당지급액(단위:원)]
			tbcnetc026io.setAfchRescsKcd					 	(input.getAfchRescsKnd());										//set[변경후해지종류]
			tbcnetc026io.setAfchInhrtVl							(input.getAfchInhrtYn());										//set[변경후상속여부]
			tbcnetc026io.setAfchHousPrpsDpstDvsnVl(input.getAfchHousPrpsDvsn());							//set[변경후주택청약예부금구분]

			tbcnetc026io.setLastChgrId						 	(FwUtil.getUserId());													//최종변경자ID(LAST_CHGR_ID)설정
			tbcnetc026io.setLastChgPgmId					 	(FwUtil.getPgmId());													//최종변경프로그램ID(LAST_CHG_PGM_ID)설정
			tbcnetc026io.setLastChgTrmNo					(FwUtil.getTrmNo());													//최종변경단말번호(LAST_CHG_TRM_NO)설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if ("S".equals(type)) {
				output = this.getTaxpfCorrcRece(prcsDt, taxpfTgmNo);
			}
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});		
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}					
			
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대정정
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfRegDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public TaxpfCorrcDO getTaxpfCorrcRece(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		TaxpfCorrcDO taxpfCorrc  = null;
		
		TaxpfCorrcDO output = new TaxpfCorrcDO();
		
		logger.debug("call TaxpfRegDO");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0; i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( null != out ) {
					
					taxpfCorrc = new TaxpfCorrcDO();
					
					taxpfCorrc.setTgmKndCd						(out.getTaxpfTgmKcd());						// set [전문종별코드]
					taxpfCorrc.setAssoBusiGb						(out.getTaxpfBzDcd());							// set [협회업무구분]
					taxpfCorrc.setTrnsDtm								(out.getPrcsDtm());								// set [전문전송일시]
					taxpfCorrc.setMgntTgmCd						(out.getTaxpfTgmNo().toString());	// set [전문관리번호]
					taxpfCorrc.setSndInstCd							("L51");														// set [전송기관코드]
					taxpfCorrc.setRcvInstCd							("L00");														// set [수신기관코드]
					taxpfCorrc.setAssoRspCd							(out.getTaxpfRcd());								// set [협회응답코드]
					
					taxpfCorrc.setAfchRrnoErr						(out.getAfchRdsnBznoErrVl());			// set [변경후주민등록번호				]
					taxpfCorrc.setAfchRrnoDvsnErr				(out.getAfchRdsnBznoDcdErrVl());	// set [변경후주민등록번호구분			]					
					taxpfCorrc.setBfchRrnoErr						(out.getBfchRdsnBznoErrVl());			// set [변경전주민등록번호				]					
					taxpfCorrc.setBfchRrnoDvsnErr				(out.getBfchRdsnBznoDcdErrVl());	// set [변경전주민등록번호구분			]				
					taxpfCorrc.setAfchConmErr					(out.getAfchConmErrVl());					// set [변경후상호(기업체명)			]					
					taxpfCorrc.setAfchNameErr					(out.getAfchTaxpfTgtpNmErrVl());	// set [변경후성명(대표자)				]					
					taxpfCorrc.setAfchInfoMnbdyDvsnErr	(out.getAfchInfoMnbdyDcdErrVl());	// set [변경후정보주체(구장애인)구분	]					
					taxpfCorrc.setAfchIncmrDvsnErr			(out.getAfchLrnkIncmrDcdErrVl	());	// set [변경후저소득자구분(농어가저축)	]	
					taxpfCorrc.setBfchSavgKndErr				(out.getBfchSavgKndErrVl());         	// set [변경전저축종류					]			
					taxpfCorrc.setBfchOffcCdErr					(out.getBfchOpenOffcIdErrVl());       // set [변경전점포코드					]				
					taxpfCorrc.setBfchActNoErr					(out.getBfchActNoErrVl());					// set [변경전계좌번호					]				
					taxpfCorrc.setAfchSavgKndErr				(out.getAfchSavgKndErrVl());				// set [변경후저축종류					]				
					taxpfCorrc.setAfchOffcCdErr					(out.getAfchOpenOffcIdErrVl());		// set [변경후점포코드					]					
					taxpfCorrc.setAfchActNoErr					(out.getAfchActNoErrVl());					// set [변경후계좌번호					]				
					taxpfCorrc.setAfchActOpenDyErr			(out.getAfchActOpenDtErrVl());		// set [변경후계좌개설일				]					
					taxpfCorrc.setAfchTaxpfAmtErr				(out.getAfchTaxpfAmtErrVl());			// set [변경후세금우대금액(단위:원)	]					
					taxpfCorrc.setAfchExpiDyErr					(out.getAfchExpiDtErrVl());					// set [변경후만기일					]			
					taxpfCorrc.setAfchFstExpiExtnDyErr		(out.getAfchFstExpiExtnDtErrVl());	// set [변경후최초만기연장일			]					
					taxpfCorrc.setAfchIntDivdAmtErr			(out.getAfchIntDivdPayAmtErrVl());	// set [변경후이자,배당지급액(단위:원)	]				
					taxpfCorrc.setAfchRescsKndErr				(out.getAfchRescsKcdErrVl());			// set [변경후해지종류					]	
					taxpfCorrc.setAfchInhrtYnErr					(out.getAfchInhrtYnErrVl());				// set [변경후상속여부					]				
					taxpfCorrc.setAfchHousPrpsDvsnErr	(out.getAfchHousPrpsDpstErrVl());	// set [변경후주택청약예부금구분		]		
					
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			
			output = taxpfCorrc;
			
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 세금우대정정 수신(0610/210)
	 * 
	 * @param  COM_F_KLIOAKOTS00010In 세금우대정정 OMM
	 * @throws ApplicationException
	 */
	public void taxpfCorrcRcv(COM_F_KLIOAKOTS00010In input
			) throws ApplicationException {
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String prcsDt	 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		String prcsYn				= " ";														//처리여부
		String taxpfRcd			= " ";														//세금우대결과코드 - 응답코드
		String prcsDtm 			= "";														//처리일시        
		String taxpfTgmNo 	= "";														//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd		= "0";														//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            = input.getTrnsDtm();				//전문전송일시
		taxpfTgmNo    = input.getMgntTgmCd();		//세금우대전문번호
		prcsYn 				= "Y";												//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 			//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();		//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();		//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt									(prcsDt);														//처리일자
		tbcnetc026io.setTaxpfTgmNo						(taxpfTgmNo);											//세금우대전문번호
		tbcnetc026io.setPrcsDtm									(prcsDtm);													//처리일시

		tbcnetc026io.setPrcsYn									(prcsYn);														//처리여부
		tbcnetc026io.setTaxpfRcd								(taxpfRcd);													//세금우대결과코드-응답코드
		tbcnetc026io.setNrmCnclDcd						(nrmCnclDcd);												//정상취소구분코드
		tbcnetc026io.setAfchRdsnBznoErrVl			(input.getAfchRrnoErr());						//set[변경후주민등록번호]
		tbcnetc026io.setAfchRdsnBznoDcdErrVl	(input.getAfchRrnoDvsnErr());				//set[변경후주민등록번호구분]
		tbcnetc026io.setBfchRdsnBznoErrVl			(input.getBfchRrnoErr());							//set[변경전주민등록번호]
		tbcnetc026io.setBfchRdsnBznoDcdErrVl		(input.getBfchRrnoDvsnErr());				//set[변경전주민등록번호구분]
		tbcnetc026io.setAfchConmErrVl					(input.getAfchConmErr());						//set[변경후상호(기업체명)]
		tbcnetc026io.setAfchTaxpfTgtpNmErrVl	(input.getAfchNameErr());						//set[변경후성명(대표자)]
		tbcnetc026io.setAfchInfoMnbdyDcdErrVl	(input.getAfchInfoMnbdyDvsnErr());	//set[변경후정보주체(구장애인)구분]
		tbcnetc026io.setAfchLrnkIncmrDcdErrVl	(input.getAfchIncmrDvsnErr());				//set[변경후저소득자구분(농어가저축)]
		tbcnetc026io.setBfchSavgKndErrVl				(input.getBfchSavgKndErr());					//set[변경전저축종류]
		tbcnetc026io.setBfchOpenOffcIdErrVl			(input.getBfchOffcCdErr());					//set[변경전점포코드]
		tbcnetc026io.setBfchActNoErrVl					(input.getBfchActNoErr());						//set[변경전계좌번호]
		tbcnetc026io.setAfchSavgKndErrVl				(input.getAfchSavgKndErr());					//set[변경후저축종류]
		tbcnetc026io.setAfchOpenOffcIdErrVl		(input.getAfchOffcCdErr());					//set[변경후점포코드]
		tbcnetc026io.setAfchActNoErrVl					(input.getAfchActNoErr());						//set[변경후계좌번호]
		tbcnetc026io.setAfchActOpenDtErrVl			(input.getAfchActOpenDyErr());			//set[변경후계좌개설일]
		tbcnetc026io.setAfchTaxpfAmtErrVl			(input.getAfchTaxpfAmtErr());				//set[변경후세금우대금액(단위:원)]
		tbcnetc026io.setAfchExpiDtErrVl					(input.getAfchExpiDyErr());						//set[변경후만기일]
		tbcnetc026io.setAfchFstExpiExtnDtErrVl		(input.getAfchFstExpiExtnDyErr());		//set[변경후최초만기연장일]
		tbcnetc026io.setAfchIntDivdPayAmtErrVl	(input.getAfchIntDivdAmtErr());			//set[변경후이자,배당지급액(단위:원)]
		tbcnetc026io.setAfchRescsKcdErrVl				(input.getAfchRescsKndErr());				//set[변경후해지종류]
		tbcnetc026io.setAfchInhrtYnErrVl				(input.getAfchInhrtYnErr());					//set[변경후상속여부]
		tbcnetc026io.setAfchHousPrpsDpstErrVl	(input.getAfchHousPrpsDvsnErr());		//set[변경후주택청약예부금구분]
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0266(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
				
	}
	
	/**
	 * 세금우대삭제
	 * 
	 * @param  TaxpfDelDO 세금우대삭제DO
	 * @return TaxpfDelDO 세금우대삭제DO
	 * @throws ApplicationException
	 */
	public TaxpfDelDO taxpfDel(TaxpfDelDO input
			) throws ApplicationException {
		
		return taxpfDel(input, "S");
		
	}
	
	/**
	 * 세금우대삭제
	 * 
	 * @param  TaxpfDelDO 세금우대삭제DO
	 * @return TaxpfDelDO 세금우대삭제DO
	 * @throws ApplicationException
	 */
	public TaxpfDelDO taxpfDel(TaxpfDelDO input, String type
			) throws ApplicationException {
		
		TaxpfDelDO output = new TaxpfDelDO();
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00011";	// EAI Interface ID
		
		COM_F_KLIOSKOTS00011In request = new COM_F_KLIOSKOTS00011In();	// 세금우대삭제 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		// 필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		} 
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getSavgKnd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"저축종류"}, new Object[]{ "세금우대전문", "저축종류" });
		} 
		if (StringUtils.isEmpty(input.getOffcCd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"점포코드"}, new Object[]{ "세금우대전문", "점포코드" });
		}
		if (StringUtils.isEmpty(input.getActNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"계좌번호"}, new Object[]{ "세금우대전문", "계좌번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		// 정합성체크
		/*
		if (input.getRrno().length() != 13) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		} 
		*/
		if (input.getRrnoDvsn().length() != 1) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getSavgKnd().length() != 2) {
			throw new ApplicationException( "APPAE0005", new Object[]{"저축종류"}, new Object[]{ "세금우대전문", "저축종류" });
		} 
		if (input.getOffcCd().length() != 7) {
			throw new ApplicationException( "APPAE0005", new Object[]{"점포코드"}, new Object[]{ "세금우대전문", "점포코드" });
		}
		
//		if (input.getActNo().length() != 13) {
//			throw new ApplicationException( "APPAE0005", new Object[]{"계좌번호"}, new Object[]{ "세금우대전문", "계좌번호" });
//		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		
		// ------------- 세금우대처리로그테이블 input ------------//
		String prcsDtm 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 	= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		logger.debug("채번taxpfTgmNo IO  [{}]", new Object [] {taxpfTgmNo});
		
		String prcsDt	 						= prcsDtm.substring(0,8);		//처리일자
		String dpsTxNo 						= "";												//입금거래번호
		String prcsDofOrgNo 			= input.getPrcsDofOrgNo();	//처리지점조직번호
		String prcsFofOrgNo 				= input.getPrcsFofOrgNo();		//처리영업소조직번호
		String prcsEno							= input.getPrcsEno();				//처리사원번호
		String contNo							= "";												//계약번호
		String savgPrdcd						= "";												//저축상품코드
		String prcsYn							= " ";												//처리여부
		String taxpfRcd						= " ";												//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 				= "0600";										//세금우대전문종류코드
		String taxpfBzDcd					= "230";											//세금우대업무구분코드
		String taxpfBzPrcsDcd 			= input.getTaxpfBzPrcsDcd();	//세금우대업무처리구분코드 
		String nrmCnclDcd					= "0";												//정상취소구분코드
		String taxpfTgmDataCtnt		= " ";												//세금우대전문데이터내용
		int dataLength 						= 0;													//DATA LENGTH
		String strDataLength 			= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}

	    //데이터 길이
		dataLength = 13 + 1 + 2 + 7 + 16 + 5;
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {

			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
		    request.setSysId						("KL");										//SYSTEM-ID
			request.setTgmKndCd			(taxpfTgmKcd);						//전문종별코드
			request.setAssoBusiGb			(taxpfBzDcd);							//업무구분코드
			request.setTrnsDtm				(prcsDtm); 								//전문전송일시
			request.setMgntTgmCd		(taxpfTgmNo); 						//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd			("L51"); 										//송신기관코드
			request.setRcvInstCd				("L00"); 										//수신기관코드
			request.setAssoTrnsGb			("      "); 										//거래구분코드	 		- 공백[6](AS-IS동일)
			request.setDataLen				(strDataLength); 					//DATA LENGTH			
			request.setTerId						("LINA-ID   "); 							//단말기ID					- 공백[10](AS-IS동일)
			request.setTerOpId				("KLICS-ID  "); 							//단말기조작자ID		- 공백[10](AS-IS동일)
			request.setTerOwnNm			("LINA                "); 					//단말기조작자성명	- 공백[20](AS-IS동일)
			request.setDataEtc					("            "); 								//예비필드					- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno						
				(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn				(input.getRrnoDvsn());			// set [주민(사업자)등록번호구분]
			request.setSavgKnd				(input.getSavgKnd());			// set [저축종류]
			request.setOffcCd					(input.getOffcCd());				// set [점포코드]
			
			//2013-11-15 : OLD계좌번호 추가 
			//request.setActNo	(this.getOldContNo(input.getActNo()));				// set [계좌번호]
			request.setActNo					(input.getActNo());				// set [계좌번호]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm							(prcsDtm);										//처리일시
			tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);								//세금우대전문번호
			tbcnetc026io.setPrcsDt							(prcsDt);											//처리일자
			tbcnetc026io.setDpsTxNo						(dpsTxNo);										//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo				(prcsDofOrgNo);								//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo				(prcsFofOrgNo);								//처리영업소조직번호
			tbcnetc026io.setPrcsEno							(prcsEno);											//처리사원번호
			tbcnetc026io.setContNo							(contNo);											//계약번호
			tbcnetc026io.setSavgPrdcd						(savgPrdcd);										//저축상품코드
			tbcnetc026io.setPrcsYn							(prcsYn);											//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);										//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);								//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);									//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd			(taxpfBzPrcsDcd);							//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);									//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);						//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			tbcnetc026io.setRdsnBznoDcd				(input.getRrnoDvsn());					// set [주민(사업자)등록번호구분]
			tbcnetc026io.setSavgKndVl					(input.getSavgKnd());					// set [저축종류]
			tbcnetc026io.setOpenOffcId					(input.getOffcCd());						// set [개설점포코드]
			
			tbcnetc026io.setLastChgrId					(FwUtil.getUserId());						// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId				(FwUtil.getPgmId());						// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo			(FwUtil.getTrmNo());						// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(ASYNC 방식) START ------ //
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if ("S".equals(type)) {
				output = this.getTaxpfDel(prcsDt, taxpfTgmNo);
			}
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 										// 세금우대결과코드 - 응답코드
																				// 정상취소구분코드
																				// 세금우대전문종류코드는 처음값
																				// 세금우대업무구분코드는 처음값
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));			// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd		(taxpfTgmKcd);						//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd		(taxpfBzDcd);						//세금우대업무구분코드
			tbcnetc026io.setPrcsYn			(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd		(taxpfRcd);							//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd		(nrmCnclDcd);						//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt(taxpfTgmDataCtnt);					//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.debug("e");
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});			
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 										// 세금우대결과코드 - 응답코드
																				// 정상취소구분코드
																				// 세금우대전문종류코드는 처음값
																				// 세금우대업무구분코드는 처음값
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));			// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd		(taxpfTgmKcd);						//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd		(taxpfBzDcd);						//세금우대업무구분코드
			tbcnetc026io.setPrcsYn			(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd		(taxpfRcd);							//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd		(nrmCnclDcd);						//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt(taxpfTgmDataCtnt);					//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.debug("e");
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}			
		
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대삭제
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfDelDO output  : 처리결과
	 * @throws ApplicationException
	 */
	public TaxpfDelDO getTaxpfDel(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
	    TaxpfDelDO taxpfDel  = null;
	    
		TaxpfDelDO output = new TaxpfDelDO();
		
		logger.debug("call TaxpfDelDO");
		
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0; i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( out !=null ) {
					
					taxpfDel = new TaxpfDelDO();
					
					taxpfDel.setTgmKndCd				(out.getTaxpfTgmKcd());							// set [전문종별코드]
					taxpfDel.setAssoBusiGb				(out.getTaxpfBzDcd());								// set [협회업무구분]
					taxpfDel.setTrnsDtm						(out.getPrcsDtm());									// set [전문전송일시]
					taxpfDel.setMgntTgmCd				(out.getTaxpfTgmNo().toString());		// set [전문관리번호]
					taxpfDel.setSndInstCd					("L51");															// set [전송기관코드]
					taxpfDel.setRcvInstCd					("L00");															// set [수신기관코드]
					taxpfDel.setAssoRspCd					(out.getTaxpfRcd());									// set [협회응답코드]
					
					taxpfDel.setRrnoErr						(out.getRdsnBznoErrVl());						// set [주민등록번호error]
					taxpfDel.setRrnoDvsnErr				(out.getRdsnBznoDcdErrVl());				// set [주민등록번호구분error]
					taxpfDel.setSavgKndErr				(out.getSavgKndErrVl());							// set [저축종류error]
					taxpfDel.setOffcCdErr					(out.getOpenOffcIdErrVl());					// set [개설점포코드error]
					taxpfDel.setActNoErr					(out.getActNoErrVl());								// set [계좌번호error]
					
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			
			output = taxpfDel;
			
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
	
	}
	
	/**
	 * 세금우대삭제 수신(0610/230)
	 * 
	 * @param  COM_F_KLIOSKOTS00011In 세금우대삭제 OMM
	 * @throws ApplicationException
	 */
	public void taxpfDelRcv(COM_F_KLIOSKOTS00011In input
			) throws ApplicationException {
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String prcsDt	 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		String prcsYn				= " ";														//처리여부
		String taxpfRcd			= " ";														//세금우대결과코드 - 응답코드
		String prcsDtm 			= "";														//처리일시        
		String taxpfTgmNo 	= "";														//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd		= "0";														//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            = input.getTrnsDtm();				//전문전송일시
		taxpfTgmNo    = input.getMgntTgmCd();		//세금우대전문번호
		prcsYn 				= "Y";												//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 			//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();		//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();		//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt									(prcsDt);														//처리일자
		tbcnetc026io.setTaxpfTgmNo						(taxpfTgmNo);											//세금우대전문번호
		tbcnetc026io.setPrcsDtm									(prcsDtm);													//처리일시
		tbcnetc026io.setPrcsYn									(prcsYn);														//처리여부
		tbcnetc026io.setTaxpfRcd								(taxpfRcd);													//세금우대결과코드-응답코드
		tbcnetc026io.setNrmCnclDcd						(nrmCnclDcd);												//정상취소구분코드
		
		tbcnetc026io.setRdsnBznoErrVl						(input.getRrnoErr());									// set [주민등록번호error]
		tbcnetc026io.setRdsnBznoDcdErrVl				(input.getRrnoDvsnErr());						// set [주민등록번호구분error]
		tbcnetc026io.setSavgKndErrVl						(input.getSavgKndErr());							// set [저축종류error]
		tbcnetc026io.setOpenOffcIdErrVl					(input.getOffcCdErr());								// set [개설점포코드error]
		tbcnetc026io.setActNoErrVl							(input.getActNoErr());								// set [계좌번호error]
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0269(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
				
	}
	
	/**
	 * 세금우대한도조회
	 * 
	 * @param  TaxPfrLmtInqDO 세금우대한도조회DO
	 * @return TaxPfrLmtInqDO 세금우대한도조회DO
	 * @throws ApplicationException
	 */
	public TaxPfrLmtInqDO taxPfrLmtInq(TaxPfrLmtInqDO input
			) throws ApplicationException {
		
		return taxPfrLmtInq(input, "S");
		
	}
	
	/**
	 * 세금우대한도조회
	 * 
	 * @param  TaxPfrLmtInqDO 세금우대한도조회DO
	 * @return TaxPfrLmtInqDO 세금우대한도조회DO
	 * @throws ApplicationException
	 */
	public TaxPfrLmtInqDO taxPfrLmtInq(TaxPfrLmtInqDO input, String type
			) throws ApplicationException {
		
		TaxPfrLmtInqDO output = new TaxPfrLmtInqDO();
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00012";						// EAI Interface ID
		
		COM_F_KLIOSKOTS00012In request = new COM_F_KLIOSKOTS00012In();	// 세금우대한도조회 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		//필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		} 
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		
		//정합성체크
		/*
		if (input.getRrno().length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (!("1".equals(input.getRrnoDvsn()) || "2".equals(input.getRrnoDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		String prcsDtm 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);	//처리일시
		String taxpfTgmNo 	= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		logger.debug("채번taxpfTgmNo IO  [{}]", new Object [] {taxpfTgmNo});
		
		String prcsDt	 					= prcsDtm.substring(0,8);				//처리일자
		String dpsTxNo 					= "";														//입금거래번호
		String prcsDofOrgNo 		= input.getPrcsDofOrgNo();			//처리지점조직번호
		String prcsFofOrgNo 			= input.getPrcsFofOrgNo();				//처리영업소조직번호
		String prcsEno						= input.getPrcsEno();						//처리사원번호
		String contNo						= "";														//계약번호
		String savgPrdcd					= "";														//저축상품코드
		String prcsYn						= " ";														//처리여부
		String taxpfRcd					=	" ";														//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 			= "0200";												//세금우대전문종류코드
		String taxpfBzDcd				= "200";													//세금우대업무구분코드
		String taxpfBzPrcsDcd 		= input.getTaxpfBzPrcsDcd();			//세금우대업무처리구분코드		
		String nrmCnclDcd				= "0";														//정상취소구분코드
		String taxpfTgmDataCtnt	= " ";														//세금우대전문데이터내용
		int dataLength 					= 0;															//DATA LENGTH
		String strDataLength 		= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();										//저축상품코드
		}
		
	    //데이터 길이
		dataLength = 13 + 1 + 40 + 20 + 1 + 1 + 10 + 10; 																//input.getRrno().length() + input.getRrnoDvsn().length();
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {

			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
		    request.setSysId					("KL");										//SYSTEM-ID
			request.setTgmKndCd		(taxpfTgmKcd);						//전문종별코드
			request.setAssoBusiGb		(taxpfBzDcd);							//업무구분코드
			request.setTrnsDtm			(prcsDtm); 								//전문전송일시
			request.setMgntTgmCd	(taxpfTgmNo); 						//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd		("L51"); 										//송신기관코드
			request.setRcvInstCd			("L00"); 										//수신기관코드
			request.setAssoTrnsGb		("      "); 										//거래구분코드	 	- 공백[6](AS-IS동일)
			request.setDataLen			(strDataLength); 					//DATA LENGTH
			request.setTerId					("LINA-ID   "); 							//단말기ID		 	- 공백[10](AS-IS동일)
			request.setTerOpId			("KLICS-ID  "); 							//단말기조작자ID 	- 공백[10](AS-IS동일)
			request.setTerOwnNm		("LINA                "); 					//단말기조작자성명  - 공백[20](AS-IS동일)
			request.setDataEtc				("            "); 								//예비필드			- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno					
				(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn			(input.getRrnoDvsn());			// set [주민(사업자)등록번호구분]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));	// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDtm						(prcsDtm);					//처리일시
			tbcnetc026io.setTaxpfTgmNo			(taxpfTgmNo);			//세금우대전문번호
			tbcnetc026io.setPrcsDt						(prcsDt);						//처리일자
			tbcnetc026io.setDpsTxNo					(dpsTxNo);					//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo			(prcsDofOrgNo);			//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo			(prcsFofOrgNo);			//처리영업소조직번호
			tbcnetc026io.setPrcsEno						(prcsEno);						//처리사원번호
			tbcnetc026io.setContNo						(contNo);						//계약번호
			tbcnetc026io.setSavgPrdcd					(savgPrdcd);					//저축상품코드
			tbcnetc026io.setPrcsYn						(prcsYn);						//처리여부
			tbcnetc026io.setTaxpfRcd					(taxpfRcd);					//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd			(taxpfTgmKcd);			//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd				(taxpfBzDcd);				//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd		(taxpfBzPrcsDcd);		//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd			(nrmCnclDcd);				//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt(taxpfTgmDataCtnt);//세금우대전문데이터내용
			
			tbcnetc026io.setRdsnBzno						
				(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			
			tbcnetc026io.setLastChgrId				(FwUtil.getUserId());	// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId			(FwUtil.getPgmId());	// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo		(FwUtil.getTrmNo());	// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			// ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if ("S".equals(type)) {
				output = this.getTaxPfrLmtInq(prcsDt, taxpfTgmNo);
			}
			
		} catch (EisExecutionException e) {
			
			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		
		
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 세금우대한도조회
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfRegDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public TaxPfrLmtInqDO getTaxPfrLmtInq(String prcsDt, String taxpfTgmNo)  throws ApplicationException {

		TaxPfrLmtInqDO taxPfrLmtInq = null;
		
		TaxPfrLmtInqDO output = new TaxPfrLmtInqDO();
		
		logger.debug("call TaxPfrLmtInqDO");
		
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0; i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( null != out ) {
					
					taxPfrLmtInq = new TaxPfrLmtInqDO();
					
					taxPfrLmtInq.setTgmKndCd						(out.getTaxpfTgmKcd());								// set [전문종별코드]
					taxPfrLmtInq.setAssoBusiGb						(out.getTaxpfBzDcd());									// set [협회업무구분]
					taxPfrLmtInq.setTrnsDtm								(out.getPrcsDtm());										// set [전문전송일시]
					taxPfrLmtInq.setMgntTgmCd						(out.getTaxpfTgmNo().toString());			// set [전문관리번호]
					taxPfrLmtInq.setSndInstCd							("L51");																// set [전송기관코드]
					taxPfrLmtInq.setRcvInstCd							("L00");																// set [수신기관코드]
					taxPfrLmtInq.setAssoRspCd						(out.getTaxpfRcd());										// set [협회응답코드]
					
					taxPfrLmtInq.setRrno									(out.getRdsnBzno());									// set [주민(사업자)등록번호]
					taxPfrLmtInq.setRrnoDvsn							(out.getRdsnBznoDcd());								// set [주민(사업자)등록번호구분]
					taxPfrLmtInq.setConm									(out.getConmNm());										// set [상호(기업체명)]
					taxPfrLmtInq.setName									(out.getTaxpfTgtpNm());								// set [성명(대표자)]
					taxPfrLmtInq.setInfoMnbdyDvsn				(out.getInfoMnbdyDcd());							// set [정보주체(구 장애인)구분]
					taxPfrLmtInq.setTaxpfDupYn						(out.getInqReqSavgKndDupVl());				// set [조회요청저축종류중복여부]
					taxPfrLmtInq.setTaxpfTtlLmtAmt				(out.getInqReqSavgKndLmtAmt());			// set [조회요청저축종류총한도금액]
					taxPfrLmtInq.setTaxpfUusdLmtAmt			(out.getInqReqSavgKndLmtRmnAmt());	// set [조회요청저축종류미사용한도금액]
					
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}
			
			output = taxPfrLmtInq;
			
			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 세금우대한도조회 수신(0210/200)
	 * 
	 * @param  COM_F_KLIOAKOTS00012In 세금우대한도조회 OMM
	 * @throws ApplicationException
	 */
	public void setTaxpfLmtInqRcv(COM_F_KLIOSKOTS00012In input
			) throws ApplicationException {
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String prcsDt	 			= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		String prcsYn				= " ";														//처리여부
		String taxpfRcd			= " ";														//세금우대결과코드 - 응답코드
		String prcsDtm 			= "";														//처리일시        
		String taxpfTgmNo 	= "";														//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd		= "0";														//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            = input.getTrnsDtm();				//전문전송일시
		taxpfTgmNo    = input.getMgntTgmCd();		//세금우대전문번호
		prcsYn 				= "Y";												//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 			//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();		//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();		//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt											(prcsDt);												//처리일자
		tbcnetc026io.setTaxpfTgmNo								(taxpfTgmNo);									//세금우대전문번호
		tbcnetc026io.setPrcsDtm											(prcsDtm);											//처리일시
		tbcnetc026io.setPrcsYn											(prcsYn);												//처리여부
		tbcnetc026io.setTaxpfRcd										(taxpfRcd);											//세금우대결과코드-응답코드
		tbcnetc026io.setNrmCnclDcd								(nrmCnclDcd);										//정상취소구분코드
		
		tbcnetc026io.setRdsnBzno										(input.getRrno());								// set [주민(사업자)등록번호]
		tbcnetc026io.setRdsnBznoDcd								(input.getRrnoDvsn());						// set [주민(사업자)등록번호구분]
		tbcnetc026io.setConmNm										(input.getConm());							// set [상호(기업체명)]
		tbcnetc026io.setTaxpfTgtpNm								(input.getName());							// set [성명(대표자)]
		tbcnetc026io.setInfoMnbdyDcd							(input.getInfoMnbdyDvsn());			// set [정보주체(구 장애인)구분]
		tbcnetc026io.setInqReqSavgKndDupVl				(input.getTaxpfDupYn());				// set [조회요청저축종류중복여부]
		tbcnetc026io.setInqReqSavgKndLmtAmt			(input.getTaxpfTtlLmtAmt());			// set [조회요청저축종류총한도금액]
		tbcnetc026io.setInqReqSavgKndLmtRmnAmt	(input.getTaxpfUusdLmtAmt());	// set [조회요청저축종류미사용한도금액]
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0266(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
				
	}
	
	/**
	 * 저축종류별세부등록내용조회
	 * 
	 * @param  savgKcdDetlRegCtntInqDO 저축종류별세부등록내용조회
	 * @return savgKcdDetlRegCtntInqDO 저축종류별세부등록내용조회
	 * @throws ApplicationException
	 */
	public SavgKcdDetlRegCtntInqDO savgKcdDetlRegCtntInq(SavgKcdDetlDtlcInqDO input
			) throws ApplicationException {
	
		return this.savgKcdDetlRegCtntInq(input, "S");
	}
	
	/**
	 * 저축종류별세부등록내용조회
	 * 
	 * @param  SavgKcdDetlRegCtntInqDO 저축종류별세부등록내용조회
	 * @return SavgKcdDetlRegCtntInqDO 저축종류별세부등록내용조회
	 * @throws ApplicationException
	 */
	public SavgKcdDetlRegCtntInqDO savgKcdDetlRegCtntInq(SavgKcdDetlDtlcInqDO input, String type
			) throws ApplicationException {
		
		SavgKcdDetlRegCtntInqDO output = new SavgKcdDetlRegCtntInqDO();
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		
		String interfaceId = "COM_F_KLIOAKOTS00013";	// EAI Interface ID
		
		COM_F_KLIOAKOTS00013In request = new COM_F_KLIOAKOTS00013In();	// 저축종류별세부등록내용조회 요청전문
		
		logger.debug("최초input IO [{}]", new Object [] {input});
		// ------------- VALIDATION CHECK START -------------------//
		// 필수입력체크
		if (StringUtils.isEmpty(input.getRrno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		} 
		if (StringUtils.isEmpty(input.getRrnoDvsn())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (StringUtils.isEmpty(input.getInqReqSavgKcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"조회요청저축종류"}, new Object[]{ "세금우대전문", "조회요청저축종류" });
		}
		if (StringUtils.isEmpty(input.getPrcsDofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리지점조직번호"}, new Object[]{ "세금우대전문", "처리지점조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsFofOrgNo())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리영업소조직번호"}, new Object[]{ "세금우대전문", "처리영업소조직번호" });
		}
		if (StringUtils.isEmpty(input.getPrcsEno())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"처리사원번호"}, new Object[]{ "세금우대전문", "처리사원번호" });
		}
		if (StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {
			throw new ApplicationException( "APPAE0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		//String rrno = SecuUtil.getDecValue(input.getRrno(), EncType.rrno);
		// 정합성체크
		/*
		if (rrno.length() != 13) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호" });
		}
		*/
		if (!("1".equals(input.getRrnoDvsn()) || "2".equals(input.getRrnoDvsn()))) {
			throw new ApplicationException( "APCME0005", new Object[]{"주민(사업자)등록번호구분"}, new Object[]{ "세금우대전문", "주민(사업자)등록번호구분" });
		}
		if (input.getInqReqSavgKcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"조회요청저축종류"}, new Object[]{ "세금우대전문", "조회요청저축종류" });
		}
		if (input.getTaxpfBzPrcsDcd().length() != 2) {
			throw new ApplicationException( "APCME0005", new Object[]{"세금우대업무처리구분코드"}, new Object[]{ "세금우대전문", "세금우대업무처리구분코드" });
		}
		// ------------- VALIDATION CHECK END -----------------------//
		
		
		// ------------- 세금우대처리로그테이블 input ------------//
		//처리일시
		String prcsDtm 						= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String taxpfTgmNo 				= cma004bean.getNewPayMkno("CMTP" , DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) , 15).substring(8);
		String prcsDt	 						= prcsDtm.substring(0,8);				//처리일자
		String dpsTxNo 						= "";														//입금거래번호
		String prcsDofOrgNo 			= input.getPrcsDofOrgNo();			//처리지점조직번호
		String prcsFofOrgNo 				= input.getPrcsFofOrgNo();				//처리영업소조직번호
		String prcsEno							= input.getPrcsEno();						//처리사원번호
		String contNo							= "";														//계약번호
		String savgPrdcd						= "";														//저축상품코드
		String prcsYn							= " ";														//처리여부
		String taxpfRcd						= " ";														//세금우대결과코드 - 응답코드
		String taxpfTgmKcd 				= "0200";												//세금우대전문종류코드
		String taxpfBzDcd					= "211";													//세금우대업무구분코드
		String taxpfBzPrcsDcd 			= input.getTaxpfBzPrcsDcd();			//세금우대업무처리구분코드	
		String nrmCnclDcd					= "0";														//정상취소구분코드
		String taxpfTgmDataCtnt 	= " ";														//세금우대전문데이터내용
		int dataLength 						= 0;															//DATA LENGTH
		String strDataLength 			= "";
		
		if (StringUtils.isEmpty(input.getDpsTxNo())) {
			dpsTxNo 			= " ";
		} else {
			dpsTxNo 			= input.getDpsTxNo();										//입금거래번호
		}
		if (StringUtils.isEmpty(input.getContNo())) {
			contNo				= " ";
		} else {
			contNo				= input.getContNo();										//계약번호
		}
		if (StringUtils.isEmpty(input.getSavgPrdcd())) {
			savgPrdcd			= " ";
		} else {
			savgPrdcd			= input.getSavgPrdcd();									//저축상품코드
		}
		
	    //데이터 길이
		dataLength = 13 + 1 + 2 + 40 + 20 + 1 + 1 + 10 + 10 + 10 + 1 + 2; 															//input.getRrno().length() + input.getRrnoDvsn().length() + input.getInqReqSavgKcd().length();
		
		strDataLength = String.valueOf(dataLength);
		
		if(strDataLength.length() == 1){
			strDataLength = "000" + strDataLength;
		} else if(strDataLength.length() == 2){
			strDataLength = "00" + strDataLength;
		} else if(strDataLength.length() == 3){
			strDataLength = "0" + strDataLength;
		}
		
		try {

			//taxpfTgmNo = "0" + taxpfTgmNo;
			
			// 시스템 구분에 따른 TRANSACTION CODE 설정
		    if(FwUtil.getSystemType() == FwUtil.SYSTEM_REAL) { 
		    	if( CommonCons.CUTOVER_DATE.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0 )	{
		    		request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    	}else	{
		    		/** 오픈시 변경!! */
		    		request.setTrCd("KLTAXONLR"); 									// 운영서버(real) KLTAXONLR ->오픈시변경
		    	}
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_DEVELOPMENT) { 
		    	request.setTrCd("KLTAXONLT"); 									// 개발서버(test)
		    } else if(FwUtil.getSystemType() == FwUtil.SYSTEM_TEST) { 
		        request.setTrCd("KLTAXONLT"); 									// 검증서버(test)
		    }
		 	
		    // ------------- 요청전문 값 MAPPING START ----------------- // 
		    // 공통 부분
		    // 채번만하면 완성
		    request.setSysId						("KL");										//SYSTEM-ID
			request.setTgmKndCd			(taxpfTgmKcd);						//전문종별코드
			request.setAssoBusiGb			(taxpfBzDcd);							//업무구분코드
			request.setTrnsDtm				(prcsDtm); 								//전문전송일시
			request.setMgntTgmCd		(taxpfTgmNo); 						//전문관리번호(채번해야함!! - 0000001)
			request.setSndInstCd			("L51"); 										//송신기관코드
			request.setRcvInstCd				("L00"); 										//수신기관코드
			request.setAssoTrnsGb			("      "); 										//거래구분코드	 		- 공백[6](AS-IS동일)
			request.setDataLen				(strDataLength); 					//DATA LENGTH			
			request.setTerId						("LINA-ID   "); 							//단말기ID					- 공백[10](AS-IS동일)
			request.setTerOpId				("KLICS-ID  "); 							//단말기조작자ID		- 공백[10](AS-IS동일)
			request.setTerOwnNm			("LINA                "); 					//단말기조작자성명	- 공백[20](AS-IS동일)
			request.setDataEtc					("            "); 								//예비필드					- 공백(AS-IS동일)
			
			// DATA 부분
			request.setRrno						(SecuUtil.getDecValue(input.getRrno(), EncType.rrno));	// set [주민(사업자)등록번호]
			request.setRrnoDvsn				(input.getRrnoDvsn());																	// set [주민(사업자)등록번호구분]
			request.setInqReqSavgKcd	(input.getInqReqSavgKcd());														// set [조회요청저축종류]
			// ------------- 요청전문 값 MAPPING END --------------------- // 
			
			// ------------- 세금우대처리로그 INSERT START --------------- //
			taxpfTgmDataCtnt 	= new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026) INSERT 하기 위한 작업
			
			tbcnetc026io.setPrcsDt							(prcsDt);										//처리일자
			tbcnetc026io.setTaxpfTgmNo				(taxpfTgmNo);							//세금우대전문번호
			tbcnetc026io.setPrcsDtm							(prcsDtm);									//처리일시
			tbcnetc026io.setDpsTxNo						(dpsTxNo);									//입금거래번호
			tbcnetc026io.setPrcsDofOrgNo				(prcsDofOrgNo);							//처리지점조직번호
			tbcnetc026io.setPrcsFofOrgNo				(prcsFofOrgNo);							//처리영업소조직번호
			tbcnetc026io.setPrcsEno							(prcsEno);										//처리사원번호
			tbcnetc026io.setContNo							(contNo);										//계약번호
			tbcnetc026io.setSavgPrdcd						(savgPrdcd);									//저축상품코드
			tbcnetc026io.setPrcsYn							(prcsYn);										//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);									//세금우대결과코드 - 응답코드
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);							//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);								//세금우대업무구분코드
			tbcnetc026io.setTaxpfBzPrcsDcd			(taxpfBzPrcsDcd);						//세금우대업무처리구분코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);								//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);					//세금우대전문데이터내용
			tbcnetc026io.setRdsnBzno						
			(SecuUtil.getEncValue(input.getRrno(), SecuUtil.EncType.Jumin));	//주민등록번호
			tbcnetc026io.setRdsnBznoDcd				(input.getRrnoDvsn());				//주민사업자등록번호구분코드
			tbcnetc026io.setLmtInqSavgKndVl		(input.getInqReqSavgKcd());	//조회요청저축종류
			
			tbcnetc026io.setLastChgrId					(FwUtil.getUserId());					// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc026io.setLastChgPgmId				(FwUtil.getPgmId());					// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc026io.setLastChgTrmNo			(FwUtil.getTrmNo());					// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			logger.debug("로그INSERT IO [{}]", new Object [] {tbcnetc026io});
			
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			insertLog(tbcnetc026io);
			// ------------- 세금우대처리로그 INSERT END ------------------ //
			
			logger.debug("송신전문request IO [{}]", new Object [] {request});
			
			// ------------- 대외계 인터페이스 호출(ASYNC 방식) START ------ //
			InfUtil.callAsyncFEP(request, interfaceId);
			
			if ("S".equals(type)) {
				output = this.getSavgKcdDetlRegCtntInqRece(prcsDt, taxpfTgmNo);
			}
			
		} catch (EisExecutionException e) {

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		} catch (NotSupportedEISException e){

			// ------------- 세금우대처리로그 UPDATE START ---------------- //
			prcsYn 				= "N";											// 처리여부
			taxpfRcd 			= "888"; 									// 세금우대결과코드 - 응답코드
			
			taxpfTgmDataCtnt	= new String(FwUtil.toBytes(request));		// 송신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
			
			tbcnetc026io.setTaxpfTgmKcd				(taxpfTgmKcd);				//세금우대전문종류코드
			tbcnetc026io.setTaxpfBzDcd					(taxpfBzDcd);					//세금우대업무구분코드
			tbcnetc026io.setPrcsYn							(prcsYn);							//처리여부
			tbcnetc026io.setTaxpfRcd						(taxpfRcd);						//세금우대결과코드 - 응답코드
			tbcnetc026io.setNrmCnclDcd				(nrmCnclDcd);					//정상취소구분코드
			tbcnetc026io.setTaxpfTgmDataCtnt	(taxpfTgmDataCtnt);		//세금우대전문데이터내용
			
			logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
			/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
			updateLog(tbcnetc026io);											
			// ------------- 세금우대처리로그 UPDATE END ------------------- //
			
			logger.error("error: ", e);
			throw new ApplicationException("APAIE0000", new Object[]{"생보협회"}, new Object[]{"생보협회"});
			
		}		
		
		logger.debug("최종output IO [{}]", new Object [] {output});
		return output;
		
	}
	
	/**
	 * 저축종류별세부등록내용조회
	 * @param prcsDt, taxpfTgmNo : 처리일자, 세금우대전문번호
	 * @return TaxpfSavgKndClLmtInqDO output  : 처리결과
	 * @throws ApplicationException
	 */		
	public SavgKcdDetlRegCtntInqDO getSavgKcdDetlRegCtntInqRece(String prcsDt, String taxpfTgmNo)  throws ApplicationException {
		
		SavgKcdDetlRegCtntInqDO savgKcdDetlRegCtntInq  = null;
		  
		SavgKcdDetlRegCtntInqDO output = new SavgKcdDetlRegCtntInqDO();
		
		logger.debug("call TaxpfSavgKndClLmtInqDO");
	
		try {
			
			//For문을 1초에 한번씩 수행
			//값이 있으면 BREAK
			long startTime = System.currentTimeMillis();
			List<TaxpfReptMtrDO> subResult = new ArrayList<TaxpfReptMtrDO>();					//ARRAY 값
			
		    String currentTime = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			logger.debug("currentTime:{}",currentTime);
			
			logger.debug("#######처리시간 체크 START=>{}  ", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			for ( int i=0;i < 30; i++) {
				
				logger.debug("waiting 횟수:{}",i);
				//10초동안 결과 조회
			    Thread.sleep(getSynctime());
			     
			    SelectOntTBCNETC026bOut  out = null;
			    List<SelectOntTBCNETC035aOut>  outSub = new ArrayList<SelectOntTBCNETC035aOut>();
			    
			    out = cmt001dbio.selectOneTBCNETC026a(prcsDt, taxpfTgmNo);
				
				logger.debug("조회결과");
				logger.debug("out:{}",out);
				
				//수신성공						
				if ( out !=null ) {
					
					savgKcdDetlRegCtntInq = new SavgKcdDetlRegCtntInqDO();
					
					savgKcdDetlRegCtntInq.setTgmKndCd					(out.getTaxpfTgmKcd());									// set [전문종별코드]
					savgKcdDetlRegCtntInq.setAssoBusiGb					(out.getTaxpfBzDcd());										// set [협회업무구분]
					savgKcdDetlRegCtntInq.setTrnsDtm							(out.getPrcsDtm());											// set [전문전송일시]
					savgKcdDetlRegCtntInq.setMgntTgmCd					(out.getTaxpfTgmNo().toString());				// set [전문관리번호]
					savgKcdDetlRegCtntInq.setSndInstCd						("L51");																	// set [전송기관코드]
					savgKcdDetlRegCtntInq.setRcvInstCd						("L00");																	// set [수신기관코드]
					savgKcdDetlRegCtntInq.setAssoRspCd					(out.getTaxpfRcd());											// set [협회응답코드]
					
					savgKcdDetlRegCtntInq.setRrnoDvsn						(out.getRdsnBznoDcd());									// set [주민(사업자)등록번호구분]
					savgKcdDetlRegCtntInq.setConm								(out.getConmNm());											// set [상호(기업체명)]
					savgKcdDetlRegCtntInq.setName								(out.getTaxpfTgtpNm());									// set [성명(대표자)]
					savgKcdDetlRegCtntInq.setInfoMnbdyDvsn			(out.getInfoMnbdyDcd());								// set [정보주체(구 장애인)구분]
					savgKcdDetlRegCtntInq.setIncmrDvsn						(out.getLrnkIncmrDcd());									// set [저소득자구분(농어가저축)]
					savgKcdDetlRegCtntInq.setInqReqSavgLmt			(out.getInqReqSavgKndLmtAmt());				// set [조회요청저축종류한도]
					savgKcdDetlRegCtntInq.setInqReqSavgEntAmt	(out.getInqReqSavgKndEntSamt());				// set [조회요청저축종류가입총액]
					savgKcdDetlRegCtntInq.setInqReqSavgLmtAmt	(out.getInqReqSavgKndLmtRmnAmt());		// set [조회요청저축종류한도잔여액]
					savgKcdDetlRegCtntInq.setInqReqSavgDupYn		(out.getInqReqSavgKndDupVl());					// set [조회요청저축종류중복여부]	
					
					outSub = cmt001dbio.selectOneTBCNETC035a(prcsDt, taxpfTgmNo);
					
					if (outSub !=null) {
						
						savgKcdDetlRegCtntInq.setTaxpfReptCnt		(outSub.size());					// set [세금우대회보건수]
						
						for(int j = 0; j < outSub.size(); j++){
							
							TaxpfReptMtrDO taxpfReptMtrDO = new TaxpfReptMtrDO();
							
							taxpfReptMtrDO.setRescsDcd					(outSub.get(j).getRescsDvsnVl()); 				// set [해지구분코드]
							taxpfReptMtrDO.setRegOffc						(outSub.get(j).getOpenOffcNm()); 				// set [등록점포]
							taxpfReptMtrDO.setActNo							(outSub.get(j).getActNo()); 							// set [계좌번호]
							taxpfReptMtrDO.setSavgKcd						(outSub.get(j).getSavgKndVl()); 					// set [저축종류]
							taxpfReptMtrDO.setSavgNewDt				(outSub.get(j).getSavgNewDt()); 					// set [저축신규일]
							taxpfReptMtrDO.setSavgLastChgDt			(outSub.get(j).getSavgLastChgDt()); 			// set [저축최종변경일]
							taxpfReptMtrDO.setTaxpfEntAmt				(outSub.get(j).getTaxpfEntAmt()); 				// set [세금우대가입금액]
							taxpfReptMtrDO.setExpiDt							(outSub.get(j).getExpiDt()); 							// set [만기일]
							taxpfReptMtrDO.setTaxpfRescsDt				(outSub.get(j).getTaxPfrRescsDt()); 				// set [세금우대해지일]
							taxpfReptMtrDO.setIntDividPayAmt			(outSub.get(j).getIntDivdPayAmt()); 			// set [이자배당지급액]
							taxpfReptMtrDO.setHeirYn							(outSub.get(j).getInhrtVl()); 							// set [상속여부]
							taxpfReptMtrDO.setHousPrpsDpstDcd	(outSub.get(j).getHousPrpsDpstDvsnVl());	// set [주택청약예부금구분]
							
							subResult.add(taxpfReptMtrDO);
							
						}	
						
						savgKcdDetlRegCtntInq.setTaxpfReptMtrDO(subResult);
					}
					
					output = savgKcdDetlRegCtntInq;
					
					// 결과코드가 들어오는 경우
					if( !StringUtils.isEmpty(out.getTaxpfRcd()) )	break;
					
				}
				
			}

			logger.debug("#######처리시간 체크 END=>{}", (double)(System.currentTimeMillis()-startTime)/1000 );
			
			logger.debug("output---->:{}",output);

		} catch (InterruptedException e )  {
			  throw new ApplicationException("APNBE0119", new Object[]{}, new Object[]{});
		}
		
		return output;
		
	}
	
	/**
	 * 저축종류별세부등록내용조회 수신(0210/211)
	 * 
	 * @param  COM_F_KLIOAKOTS00013In 저축종류별세부등록내용조회OMM
	 * @throws ApplicationException
	 */
	public void savgKcdDetlRegCtntInqRcv(COM_F_KLIOAKOTS00013In input
			) throws ApplicationException {
		
		List<COM_F_KLIOAKOTS00013Sub0> taxpfReptMtr = null;		// 세금우대회보사항
		
		TBCNETC026Io tbcnetc026io = new TBCNETC026Io();				// TBCNETC026       OMM
		String prcsDt	 						= DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);		//처리일자
		String prcsYn							= " ";														//처리여부
		String taxpfRcd						= " ";														//세금우대결과코드 - 응답코드
		String prcsDtm 						= "";														//처리일시
		String taxpfTgmNo 				= "";														//세금우대전문번호 - 채번(9번째자리부터 끝까지)
		String nrmCnclDcd					= "0";														//정상취소구분코드
		
		logger.debug("수신전문 [{}]", input);
		
		// ------------- 세금우대처리로그 UPDATE START ---------------- //
		prcsDtm            = input.getTrnsDtm();						//전문전송일시
		taxpfTgmNo		= input.getMgntTgmCd();				//세금우대전문번호
		prcsYn 				= "Y";														//처리여부
		taxpfRcd 			= input.getAssoRspCd(); 					//세금우대결과코드 - 응답코드
//		taxpfTgmKcd 		= input.getTgmKndCd();				//세금우대전문종류코드
//		taxpfBzDcd			= input.getAssoBusiGb();				//세금우대업무구분코드
//		taxpfTgmDataCtnt	= new String(FwUtil.toBytes(input));		//수신전문내용을 세금우대처리로그(TBCNETC026) UPDATE 하기 위한 작업
	
		//수신받은 전문에 응답코드가 없으면 error
		if (StringUtils.isEmpty(taxpfRcd)) {
			taxpfRcd = "888";
		}
		
		tbcnetc026io.setPrcsDt											(prcsDt);												//처리일자
		tbcnetc026io.setTaxpfTgmNo								(taxpfTgmNo);									//세금우대전문번호
		tbcnetc026io.setPrcsDtm											(prcsDtm);											//처리일시
		tbcnetc026io.setPrcsYn											(prcsYn);												//처리여부
		tbcnetc026io.setTaxpfRcd										(taxpfRcd);											//세금우대결과코드 - 응답코드
		tbcnetc026io.setNrmCnclDcd								(nrmCnclDcd);										//정상취소구분코드
		tbcnetc026io.setRdsnBznoDcd								(input.getRrnoDvsn());						//주민(사업자)등록번호구분
		tbcnetc026io.setConmNm										(input.getConm());							//상호명
		tbcnetc026io.setTaxpfTgtpNm								(input.getName());							//세금우대대상자명
		tbcnetc026io.setInfoMnbdyDcd							(input.getInfoMnbdyDvsn());			//정보주체구분코드
		tbcnetc026io.setLrnkIncmrDcd								(input.getIncmrDvsn());					//하위소득자구분코드
		tbcnetc026io.setInqReqSavgKndLmtAmt			(input.getInqReqSavgLmt());			//조회요청저축종류한도금액
		tbcnetc026io.setInqReqSavgKndEntSamt			(input.getInqReqSavgEntAmt());	//조회요청저축종류가입합계금액
		tbcnetc026io.setInqReqSavgKndLmtRmnAmt	(input.getInqReqSavgLmtAmt());	//조회요청저축종류한도잔여금액
		tbcnetc026io.setInqReqSavgKndDupVl				(input.getInqReqSavgDupYn());	//조회요청저축종류중복값
		
		logger.debug("로그update IO [{}]", new Object [] {tbcnetc026io});
		
		int iResult = 0;
		
		iResult = cmt001dbio.updateOneTBCNETC0262(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
		
		//세금우대회보사항
		taxpfReptMtr = input.getTaxpfReptMtr();
		
		iResult = 0;
		
		for(int i = 0; i < input.getTaxpfReptCnt(); i++ ){
			
			TBCNETC035Io tbcnetc035io = new TBCNETC035Io();				// TBCNETC035       OMM
			
			tbcnetc035io.setPrcsDt							(prcsDt); 																		// set [처리일자]
			tbcnetc035io.setTaxpfTgmNo				(Integer.parseInt(taxpfTgmNo)); 							// set [등록점포]
			tbcnetc035io.setRescsDvsnVl					(taxpfReptMtr.get(i).getRescsDcd()); 					// set [해지구분값]			
			tbcnetc035io.setOpenOffcNm				(taxpfReptMtr.get(i).getRegOffc());						// set [개설점포명]
			tbcnetc035io.setActNo							(SecuUtil.getEncValue(taxpfReptMtr.get(i).getActNo(), SecuUtil.EncType.actNo));	// set [계좌번호]
			tbcnetc035io.setSavgKndVl					(taxpfReptMtr.get(i).getSavgKcd());						// set [저축종류값]	
			tbcnetc035io.setSavgNewDt					(taxpfReptMtr.get(i).getSavgNewDt());				// set [저축신규일자]
			tbcnetc035io.setSavgLastChgDt			(taxpfReptMtr.get(i).getSavgLastChgDt());		// set [저축최종변경일자]
			tbcnetc035io.setTaxpfEntAmt				(taxpfReptMtr.get(i).getTaxpfEntAmt());			// set [세금우대가입금액]
			tbcnetc035io.setExpiDt							(taxpfReptMtr.get(i).getExpiDt());						// set [만기일자]
			tbcnetc035io.setTaxPfrRescsDt				(taxpfReptMtr.get(i).getTaxpfRescsDt());			// set [세금우대해지일자]
			tbcnetc035io.setIntDivdPayAmt			(taxpfReptMtr.get(i).getIntDividPayAmt());		// set [이자배당지급금액]
			tbcnetc035io.setInhrtVl							(taxpfReptMtr.get(i).getHeirYn());						// set [상속값]
			tbcnetc035io.setHousPrpsDpstDvsnVl	(taxpfReptMtr.get(i).getHousPrpsDpstDcd());	// set [주택청약예금구분값]
			
			tbcnetc035io.setLastChgrId					("KLI");																			// 최종변경자ID(LAST_CHGR_ID) 설정
			tbcnetc035io.setLastChgPgmId				("KLI");																			// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
			tbcnetc035io.setLastChgTrmNo			("KLI");																			// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
			
			iResult = cmt001dbio.insertOneTBCNETC0350(tbcnetc035io);
			
			if(iResult != 1){
				// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
				throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
			}
			
		}

	}
	
	/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW) 
	public void insertLog(TBCNETC026Io tbcnetc026io) throws ApplicationException {
		int iResult = 0;
		
		logger.debug("insertLogSTART");

		//암호화
		SecuUtil.doEncObject(tbcnetc026io);
		
		String taxpfTgmDataCtnt = tbcnetc026io.getTaxpfTgmDataCtnt();	//세금우대전문데이터내용
		if(taxpfTgmDataCtnt != null) {
			tbcnetc026io.setTaxpfTgmDataCtnt(SecuUtil.getEncValue(taxpfTgmDataCtnt, EncType.Etc));
		}
		
		iResult = cmt001dbio.insertOneTBCNETC0260(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}

		logger.debug("insertLogEND");

	}
	
	/*기존의 Transaction과 관계없이 새로운 Transaction을 생성한다. */
	@TransactionalOperation(propagation= Propagation.REQUIRES_NEW) 
	public void updateLog(TBCNETC026Io tbcnetc026io) throws ApplicationException {
		int iResult = 0;

		logger.debug("updateLogSTART");
		
		//암호화
		String taxpfTgmDataCtnt = tbcnetc026io.getTaxpfTgmDataCtnt();	//세금우대전문데이터내용
		if(taxpfTgmDataCtnt != null) {
			tbcnetc026io.setTaxpfTgmDataCtnt(SecuUtil.getEncValue(taxpfTgmDataCtnt, EncType.Etc));
		}

		iResult = cmt001dbio.updateOneTBCNETC0260(tbcnetc026io);
		
		if(iResult != 1){
			// SQL오류, '리얼타임이체원장입력 오류가 발생하였습니다. IT 담당자에게 문의하십시요.'
			throw new ApplicationException("APPAE0009", new Object[]{"세금우대처리로그 입력"});
		}
		
		logger.debug("updateLogEND");

	}
	
	// syncTime 설정(오픈 후에는 10000 으로 고정처리할 것)
	public int getSynctime()	{
		
		String mode = LApplicationContext.getSystemMode();
		
		// 운영계인 경우 syncTime 넉넉하게 받을 수 있도록 조치
		return("D".equals(mode)?100:100);
		
	}
	
	public String  getOldContNo(String argContNo) throws ApplicationException {
		
		String  oldContNo  = "";

		if (StringUtils.isEmpty(argContNo) || argContNo == null) {
			return 	oldContNo;
		}
		
		SelectOneTBCNETC0010Out  oldContInfo = null;
		oldContInfo = cmt001dbio.selectOneTBCNETC0010(argContNo);
		
		if (oldContInfo == null) {
			oldContNo = argContNo;
		}
		else {
			if (oldContInfo.getOldContNo().length() == 9) {
				oldContNo = oldContInfo.getOldContNo().substring(1, 9);
			}
			else {
				oldContNo = oldContInfo.getOldContNo();
			}
		}
		
		return  oldContNo;
	}		

}