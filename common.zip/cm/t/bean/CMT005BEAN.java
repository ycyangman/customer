package cigna.cm.t.bean;

import java.util.ArrayList;
import java.util.List;

import cigna.cm.t.dbio.CMT005DBIO;
import cigna.cm.t.domain.TaxpfSavgKndDvsnReqDO;
import cigna.cm.t.domain.TaxpfSavgKndDvsnResDO;
import cigna.cm.t.io.SelectOneTBCNETC025aOut;
import cigna.cm.t.io.SelectOneTBCNETC026aOut;
import cigna.cm.t.io.SelectOneTBCNETC026bOut;
import cigna.cm.t.io.TBCNETC025Io;
import cigna.cm.t.io.TBCNETC026Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;
import klaf.app.ApplicationException;
import klaf.common.util.CollectionUtils;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;
import klaf.inf.innorule.item.InnoRuleOmm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.t.bean.CMT005BEAN.java
 * @filetype     java source file
 * @brief
 * @author       김욱
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           홍선원			       2013. 7. 19.       신규 작성
 * 0.1           김욱			           2013. 8. 02.       
 *
 */
@KlafBean
public class CMT005BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
    @Autowired
    private CMT005DBIO cmt005dbio;
    	
    
	/**
	 * 세금우대 저축상품코드 셋팅
	 * @param  TaxpfSavgKndDvsnReqDO
	 * @return TaxpfSavgKndDvsnResDO
	 * @throws ApplicationException
	 */
    public List<TaxpfSavgKndDvsnResDO> setTaxpfSavgPrdcd(TaxpfSavgKndDvsnReqDO input) throws ApplicationException {
		
    	logger.debug("[로그]세금우대 저축상품코드 input:{}",input);
    	List<TaxpfSavgKndDvsnResDO> taxpfSavgKndDvsnResDOList = new ArrayList<TaxpfSavgKndDvsnResDO>();
    	TaxpfSavgKndDvsnResDO output = null;
    	
    	// 필수입력값 validation을 check
    	this.chkTaxpfSavgPrdcdIo(input);
    	
    	//계약구분 = "개인계약" AND 계약자개인여부 = "개인"(AS-IS주민번호로 CHECK)
    	if("10".equals(input.getContBzDcd()) && "Y".equals(input.getContrIndYn())) {
    		
    		// array(1) : "36" 연금저축 기준 (특정상품코드)
    		// if ("P02228,P02229,P02230,P02236,P02237".contains(input.getPrdcd())) {
    		// 2014.05.14 상품코드분류기준 변경(개인연금세제적격구분코드)
    		if(!StringUtils.isEmpty(input.getPrpenTaxsysQufcDcd()) 
    				&& "8".equals(input.getPrpenTaxsysQufcDcd())){
    			
    			output = new TaxpfSavgKndDvsnResDO();
        		
        		output.setSavgPrdcd("36");
        		taxpfSavgKndDvsnResDOList.add(output);
        		
    		} else {
    			
    			
				// 룰 호출(상품중분류코드, 전환옵션 조회)
				TaxpfSavgKndDvsnReqDO ruleInfo = this.chkProdRuleInfo(input);
				
				if(ruleInfo == null){
					
					throw new ApplicationException("APNBE0017",  new Object[]{"상품 rule정보"}, new Object[]{});
				}
				if(ruleInfo.getProdMclsCd() == null || StringUtils.isEmpty(ruleInfo.getProdMclsCd()) ){
					
					throw new ApplicationException("APNBE0017",  new Object[]{"상품중분류코드"}, new Object[]{});
				}
				//전환옵션선택유형코드는 없을수 있음
				if(ruleInfo.getSwtopSelTpcd() == null || StringUtils.isEmpty(ruleInfo.getSwtopSelTpcd()) ){

					ruleInfo.setSwtopSelTpcd("");
					//throw new ApplicationException("APNBE0017",  new Object[]{"전환옵션선택유형코드"}, new Object[]{});
				}
				
				
    			// array(1) : "56" ,"58" 월적립식저축보험, 비월납적립식저축보험 기준 보험기간 10년이상
    			if (input.getInsPrdYcnt() >= 10) {
    				
					//"56"  보험기간 10년이상 AND 월납 AND 납입기간 5년이상 AND 선납횟차 6회 이하
    				if ("01".equals(input.getPmCylCd()) && input.getPmPrd() >= 5 && input.getPpyNts() <= 6) {
    					output = new TaxpfSavgKndDvsnResDO();
    	        		
    	        		output.setSavgPrdcd("56");
    	        		taxpfSavgKndDvsnResDOList.add(output);
    	        		
    	        	//"58" 보험기간 10년 AND  "56" 이 아닌경우 AND 사망,종신 상품은 제외(상품중분류코드:40,50) 2013.08.23 추가
    				} else {
    					
    					if ( ! ("40".equals(ruleInfo.getProdMclsCd()) || "50".equals(ruleInfo.getProdMclsCd()))  ) {
    						
        					output = new TaxpfSavgKndDvsnResDO();
        	        		output.setSavgPrdcd("58");
        	        		taxpfSavgKndDvsnResDOList.add(output);
    					}

    				}    				
    			}
    			
    			// array(2) : "59" 종신형 연금 (계약자=주피보험자=만기시수익자)
    			if (input.getContrCustNo().equals(input.getPinsdCustNo()) && input.getContrCustNo().equals(input.getExpiBenfcCustNo())) {

    				// 전환옵션구분코드 맵핑 (asIs / toBe)
					// 연금전환특약      (06 / C04),
					// 건강설계전환특약(16 / C08),
					// 은퇴설계전환특약(17 / C06),
				    // 보장설계전환특약(18 / C09)
    				
    				// (상품중분류 = "01" AND 연금개시연령 >=55) OR
    				// (전환옵션구분 = "06" OR "16" OR "17" OR "18")
    				if( "10".equals(ruleInfo.getProdMclsCd()) && input.getAntyOpnAge() >= 55 ) {
    					//("C04,C06,C08,C09".contains(ruleInfo.getSwtopSelTpcd())) ){ //요건 변경으로 삭제 처리 2013.08.07 김욱
    					
    					output = new TaxpfSavgKndDvsnResDO();
    	        		
    	        		output.setSavgPrdcd("59");
    	        		taxpfSavgKndDvsnResDOList.add(output);	
    				}

    			}
    			
    		}
    		
    		logger.debug("taxpfSavgKndDvsnResDOList:{}",taxpfSavgKndDvsnResDOList);
    		
    	}
    	
    	return taxpfSavgKndDvsnResDOList;
		
	}
    
	/**
	 * 상품rule 정보 조회
	 * @param  TaxpfSavgKndDvsnReqDO
	 * @return TaxpfSavgKndDvsnReqDO(setProdMclsCd, setSwtopSelTpcd)
	 * @throws ApplicationException
	 */
    public TaxpfSavgKndDvsnReqDO chkProdRuleInfo(TaxpfSavgKndDvsnReqDO input) throws ApplicationException {
		
    	try {
			
			InnoRuleOmm request = new InnoRuleOmm();

			// rule 호출
			String ruleId		= "RBA001R";  					// NBA001R-상품보험관계조회_Main
			String applyDate	= DateUtils.getCurrentDate(2);	// 적용일자-계약일자
			request.set("BASE_DT" ,applyDate);					// BASE_DT-기준일자-계약일자
			request.set("CONT_DT" ,applyDate);					// CONT_DT-계약일자-계약일자
			request.set("PRDCD"   ,input.getPrdcd());	        // PRDCD-상품코드
			request.set("INSCD"   ,"");	                        // INSDCD-보험코드

			//요율사용방법
			request.set( "STND_ITEM_ALIAS", new String[]{"PROD_MCLS_CD","SWTOP_SEL_TPCD"});
			InnoRuleOmm response = InfUtil.callRule(ruleId, applyDate, request);

			logger.debug("response{}",response);

			String[] stndItemAlias	= (String[])response.get("STND_ITEM_ALIAS");	// 표준항목별칭
			String[] st1CharVl 		= (String[])response.get("ST1_CHAR_VL");		// 제1문자값

			
			for (int j = 0; j < stndItemAlias.length; j++) {
				
				if("PROD_MCLS_CD".equals(stndItemAlias[j])) {		// 상품중분류코드
					input.setProdMclsCd(st1CharVl[j]);
				}
				if("SWTOP_SEL_TPCD".equals(stndItemAlias[j])) { 	   // 전환옵션선택유형코드
					input.setSwtopSelTpcd(st1CharVl[j]);
				}
			}

			if(input.getProdMclsCd() == null || StringUtils.isEmpty(input.getProdMclsCd()) ){

				logger.debug("###	EisExecutionException		===> (PROD_MCLS_CD)Rule 값 없음."  );
				throw new ApplicationException("APNBE0017",  new Object[]{"(상품중분류코드 PROD_MCLS_CD)"+input.getPrdcd()+"Rule 값이"}, new Object[]{});
			}
			//전환옵션선택유형코드는 없을수 있음
//			if(input.getSwtopSelTpcd() == null || StringUtils.isEmpty(input.getSwtopSelTpcd()) ){
//
//				logger.debug("###	EisExecutionException		===> (SWTOP_SEL_TPCD)Rule 값 없음."  );
//				throw new ApplicationException("APNBE0017",  new Object[]{"(전환옵션선택유형코드 SWTOP_SEL_TPCD)"+input.getPrdcd()+"Rule 값이"}, new Object[]{});
//			}			
			
			logger.debug("in:{}", input);
			

		}catch (EisExecutionException e) {
			logger.debug("###	EisExecutionException");
			// 상품/규칙 정보 호출 오류가 발생하였습니다. | IT 담당자에게 문의하십시요. (오류내용 : {0})
			throw new ApplicationException("KIERE0018",  new Object[]{}, new Object[]{});
		} catch (NotSupportedEISException e) {
			logger.debug("###	NotSupportedEISException");
			// 상품/규칙 정보 호출 오류가 발생하였습니다. | IT 담당자에게 문의하십시요. (오류내용 : {0})
			throw new ApplicationException("KIERE0018",  new Object[]{}, new Object[]{});
		} catch (Exception e) {
			throw new ApplicationException("KIERE0018",  new Object[]{}, new Object[]{});
		}
				
    	return input;
		
	}
    
	/**
	 * 세금우대 단건 조회
	 * @param  String contNo
	 * @param  String savgPrdcd
	 * @return SelectOneTBCNETC025aOut
	 * @throws ApplicationException
	 */
    public SelectOneTBCNETC025aOut getTaxpfInfo(String contNo, String savgPrdcd) throws ApplicationException {
    	
    	SelectOneTBCNETC025aOut output = null;
		
    	if (StringUtils.isEmpty(contNo)) {
            logger.error("계약번호가 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "계약번호" });
        }
    	if (StringUtils.isEmpty(savgPrdcd)) {
            logger.error("저축상품코드가 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "저축상품코드" });
        }
    	
    	// dbio 호출
    	output = cmt005dbio.selectOneTBCNETC025a(contNo, savgPrdcd);

		if(output == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return output;
	}
    
	/**
	 * 세금우대 다건 조회(계약번호로 조회)
	 * @param  String contNo
	 * @return SelectOneTBCNETC025aOut
	 * @throws ApplicationException
	 */
    public List<SelectOneTBCNETC025aOut> getTaxpfList(String contNo) throws ApplicationException {
    	
    	List<SelectOneTBCNETC025aOut> list = null;
		
		
		if (StringUtils.isEmpty(contNo)) {
            logger.error("계약번호가 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "계약번호" });
        }
		

		// dbio 호출
		list = cmt005dbio.selectMultiTBCNETC025a(contNo);
		
		
		if (CollectionUtils.isEmpty(list)) {
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.O
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return list;
		
	}
    
	/**
	 * 세금우대 다건 조회(계약번호,상태코드로 조회)
	 * @param  String contNo
	 * @param  String taxpfPrcsStcd 
	 * @return SelectOneTBCNETC025aOut
	 * @throws ApplicationException
	 */
    public List<SelectOneTBCNETC025aOut> getTaxpfList(String contNo,String taxpfPrcsStcd ) throws ApplicationException {
    	
    	List<SelectOneTBCNETC025aOut> list = null;

		
		if (StringUtils.isEmpty(contNo)) {
            logger.error("계약번호가 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "계약번호" });
        }
		
		// dbio 호출
		list = cmt005dbio.selectMultiTBCNETC025b(contNo,taxpfPrcsStcd);
		
		//2013,01이후 데이터 부터 존재함

		return list;
		
	}  
    
	/**
	 * 세금우대 다건 조회
	 * @param  String contNo
	 * @param  String taxpfPrcsStcd 
	 * @return SelectOneTBCNETC025aOut
	 * @throws ApplicationException
	 */
    public List<SelectOneTBCNETC025aOut> getTaxpfList(String contNo,String taxpfPrcsStcd,String bzDcd) throws ApplicationException {
    	
    	List<SelectOneTBCNETC025aOut> list = null;
		
		
		if (StringUtils.isEmpty(contNo)) {
            logger.error("계약번호가 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "계약번호" });
        }
		

		// dbio 호출
		list = cmt005dbio.selectMultiTBCNETC025b(contNo,taxpfPrcsStcd);
		
		
		if (CollectionUtils.isEmpty(list)) {
			// KIOKI0004: 요청하신 자료가 존재하지 않습니다.O
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return list;
		
	}     

   
	/**
	 * 세금우대 insert(단건처리)
	 * @param  TBCNETC025Io
	 * @return int
	 * @throws ApplicationException
	 */
    public int insertTaxpf (TBCNETC025Io input) throws ApplicationException {
		
		int cnt = 0;
	
    	// 필수입력값 check
		this.chkInsertTaxpfIo(input);
		
		input.setDelYn("N");// set [삭제여부]
		input.setLastChgrId(FwUtil.getUserId());       // set [최종변경자ID]
		input.setLastChgPgmId(FwUtil.getPgmId()); // set [최종변경프로그램ID]
		input.setLastChgTrmNo(FwUtil.getTrmNo());// set [최종변경단말번호]
		
		cnt = cmt005dbio.mergeOneTBCNETC025a(input);
		
    	return cnt;
		
	}
    
	/**
	 * 세금우대 update(단건처리)
	 * @param  TBCNETC025Io
	 * @return int
	 * @throws ApplicationException
	 */
    public int updateTaxpf(TBCNETC025Io input) throws ApplicationException {
    	
    	int cnt = 0;

    	// 필수입력값 validation을 check
		this.chkUpdateTaxpfIo(input);
		
		
		input.setDelYn("N");// set [삭제여부]
		input.setLastChgrId(FwUtil.getUserId());       // set [최종변경자ID]
		input.setLastChgPgmId(FwUtil.getPgmId()); // set [최종변경프로그램ID]
		input.setLastChgTrmNo(FwUtil.getTrmNo());// set [최종변경단말번호]
		
		// dbio 호출
		cnt = cmt005dbio.updateOneTBCNETC025a(input);
    	
    	return cnt;
		
	}

    

    
    /**
	 * 세금우대로그 단건 조회
	 * @param  String prcsDtm, String taxpfTgmNo
	 * @return SelectOneTBCNETC025aOut
	 * @throws ApplicationException
	 */
    public SelectOneTBCNETC026aOut getTaxpfLog(String prcsDtm, String taxpfTgmNo) throws ApplicationException {
    	
    	SelectOneTBCNETC026aOut output = null;
		
    	if (StringUtils.isEmpty(prcsDtm)) {
            logger.error("처리일시 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "처리일시" });
        }
    	if (StringUtils.isEmpty(taxpfTgmNo)) {
            logger.error("세금우대전문번호 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "세금우대전문번호" });
        }
    	
    	// dbio 호출
    	output = cmt005dbio.selectOneTBCNETC026a(taxpfTgmNo, prcsDtm);
    	SecuUtil.doDecObject(output);

		if(output == null) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			throw new ApplicationException("KIOKI0004", null);
		}
		
		return output;
	}
    
    /**
	 * 세금우대로그 조회(특정업무 처리건 조회)
	 * @param  String contNo
	 * @param  String taxpfTgmKcd 전문종류코드
	 * @param  String taxpfBzDcd    업무구분코드
	 * @param  String taxpfBzPrcsDcd 업무처리구분코드
	 * @param  String taxpfPrcsStcd 세금우대처리상태코드
	 * @return SelectOneTBCNETC026bOut
	 * @throws ApplicationException
	 */
    public List<SelectOneTBCNETC026bOut> getTaxpfLog(String contNo,
    		                                                                          String taxpfTgmKcd,
    		                                                                          String taxpfBzDcd,
    		                                                                          String taxpfBzPrcsDcd,
    		                                                                          String taxpfPrcsStcd) throws ApplicationException {
    	

    	List<SelectOneTBCNETC026bOut> list = null;
		
    	if (StringUtils.isEmpty(contNo)) {
            logger.error("계악번호 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "계악번호" });
        }
    	if (StringUtils.isEmpty(taxpfTgmKcd)) {
            logger.error("전문종류코드 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "전문종류코드" });
        }
    	if (StringUtils.isEmpty(taxpfBzDcd)) {
            logger.error("업무구분코드 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "업무구분코드" });
        }
    	if (StringUtils.isEmpty(taxpfBzPrcsDcd)) {
            logger.error("세금우대전문번호 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "세금우대전문번호" });
        }  	
    	
    	// 신계약에서 처리한 해지건 조회시
    	// taxpfTgmKcd:0500 taxpfBzDcd:210 taxpfBzPrcsDcd:NB, taxpfPrcsStcd:02
    	
    	// dbio 호출
    	list = cmt005dbio.selectOneTBCNETC026b(contNo,taxpfTgmKcd,taxpfBzDcd,taxpfBzPrcsDcd,taxpfPrcsStcd);
    	//2013,01이후 데이터 부터 존재함

		return list;
	}    
    
	/**
	 * 세금우대로그 insert(단건처리)
	 * @param  TBCNETC026Io
	 * @return int
	 * @throws ApplicationException
	 */
    public int insertTaxpfLog (TBCNETC026Io input) throws ApplicationException {
    	
		int cnt = 0;
	
    	// 필수입력값 validation을 check
		this.chkInsertTaxpfLogIo(input);
		
		String taxpfTgmDataCtnt = input.getTaxpfTgmDataCtnt();
		if(taxpfTgmDataCtnt != null) {
			input.setTaxpfTgmDataCtnt(SecuUtil.getEncValue(taxpfTgmDataCtnt, EncType.Etc));
		}
				
		input.setDelYn("N");// set [삭제여부]
		input.setLastChgrId(FwUtil.getUserId());// set [최종변경자ID]
		input.setLastChgPgmId(FwUtil.getPgmId());// set [최종변경프로그램ID]
		input.setLastChgTrmNo(FwUtil.getTrmNo());// set [최종변경단말번호]
		
		// dbio 호출
		cnt = cmt005dbio.insertOneTBCNETC026a(input);
		
    	return cnt;
		
	}
    
    /**
	 * 세금우대로그 update(단건처리)
	 * @param  TBCNETC026Io
	 * @return int
	 * @throws ApplicationException
	 */
    public int updateTaxpfLog (TBCNETC026Io input) throws ApplicationException {
		
		int cnt = 0;
	
    	// 필수입력값 validation을 check
		this.chkUpdateTaxpfLogIo(input);
		
		String taxpfTgmDataCtnt = input.getTaxpfTgmDataCtnt();
		if(taxpfTgmDataCtnt != null) {
			input.setTaxpfTgmDataCtnt(SecuUtil.getEncValue(taxpfTgmDataCtnt, EncType.Etc));
		}
		
		input.setDelYn("N");// set [삭제여부]
		input.setLastChgrId(FwUtil.getUserId());// set [최종변경자ID]
		input.setLastChgPgmId(FwUtil.getPgmId());// set [최종변경프로그램ID]
		input.setLastChgTrmNo(FwUtil.getTrmNo());// set [최종변경단말번호]
		
		// dbio 호출
		cnt = cmt005dbio.updateOneTBCNETC026a(input);
		
    	return cnt;
		
	}
    
    
    
    /**
	 * <p> 세금우대 입력값  확인</p>
	 * @param 
	 * @throws ApplicationException
	 */
    
    private void chkInsertTaxpfIo ( TBCNETC025Io input) throws ApplicationException {

    	if(StringUtils.isEmpty(input.getContNo())) {

	        logger.debug("계약번호를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"계약번호"}, new Object[]{"계약번호"});
		}

		if(StringUtils.isEmpty(input.getSavgPrdcd())) {

	        logger.debug("저축상품코드를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"저축상품코드"}, new Object[]{"저축상품코드"});
		}

		if(StringUtils.isEmpty(input.getContrCustNo())) {

	        logger.debug("계약자고객번호를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"계약자고객번호"}, new Object[]{"계약자고객번호"});
		}

//		if(StringUtils.isEmpty(input.getContrBlntEntpNm())) {
//
//	        logger.debug("계약자소속기업명을  입력하지 않았습니다");
//	        throw new ApplicationException("APPRE0000", new Object[]{"계약자소속기업명"}, new Object[]{"계약자소속기업명"});
//		}

		if(StringUtils.isEmpty(input.getContrBlntReprNm())) {

	        logger.debug("계약자소속대표자명을  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"계약자소속대표자명"}, new Object[]{"계약자소속대표자명"});
		}
		
		if(StringUtils.isEmpty(input.getPrcsDt())) {

	        logger.debug("처리일자  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"처리일자"}, new Object[]{"처리일자"});
		}
		
		if(StringUtils.isEmpty(input.getExpiDt())) {

	        logger.debug("만기일자  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"만기일자"}, new Object[]{"만기일자"});
		}
		
//		if(StringUtils.isEmpty(input.getExpiExtnDt())) {
//
//	        logger.debug("만기연장일자  입력하지 않았습니다");
//	        throw new ApplicationException("APPRE0000", new Object[]{"만기연장일자"}, new Object[]{"만기연장일자"});
//		}
		
		if(StringUtils.isEmpty(input.getTaxpfIntDivdAmt().toString())) {

	        logger.debug("세금우대이자배당금액  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대이자배당금액"}, new Object[]{"세금우대이자배당금액"});
		}
		
		if(StringUtils.isEmpty(input.getTaxpfEntAmt().toString())) {

	        logger.debug("세금우대가입금액  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대가입금액"}, new Object[]{"세금우대가입금액"});
		}
		
		if(StringUtils.isEmpty(input.getTaxpfPrcsStcd().toString())) {

	        logger.debug("세금우대처리상태코드  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대처리상태코드"}, new Object[]{"세금우대처리상태코드"});
		}
		
	}
    
    /**
	 * <p> 세금우대 입력값  확인</p>
	 * @param 
	 * @throws ApplicationException
	 */
    
    private void chkUpdateTaxpfIo ( TBCNETC025Io input) throws ApplicationException {

    	if(StringUtils.isEmpty(input.getContNo())) {

	        logger.debug("계약번호를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"계약번호"}, new Object[]{"계약번호"});
		}

		if(StringUtils.isEmpty(input.getSavgPrdcd())) {

	        logger.debug("저축상품코드를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"저축상품코드"}, new Object[]{"저축상품코드"});
		}
	
	}    
    
    
    
    /**
	 * <p> 세금우대로그 입력값  확인</p>
	 * @param 
	 * @throws ApplicationException
	 */
    
    private void chkInsertTaxpfLogIo ( TBCNETC026Io input) throws ApplicationException {

    	
    	if(StringUtils.isEmpty(input.getPrcsDtm())) {

	        logger.debug("처리일시  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"처리일시"}, new Object[]{"처리일시"});
		}
    	
    	if(StringUtils.isEmpty(input.getTaxpfTgmNo())) {

	        logger.debug("세금우대전문번호  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대전문번호"}, new Object[]{"세금우대전문번호"});
		}
    	
    	if(StringUtils.isEmpty(input.getPrcsDt())) {

	        logger.debug("처리일자  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"처리일자"}, new Object[]{"처리일자"});
		}
    	
    	if(StringUtils.isEmpty(input.getDpsTxNo())) {

	        logger.debug("입금거래번호  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"입금거래번호"}, new Object[]{"입금거래번호"});
		}
    	
    	if(StringUtils.isEmpty(input.getPrcsDofOrgNo())) {

	        logger.debug("처리지점조직번호  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"처리지점조직번호"}, new Object[]{"처리지점조직번호"});
		}
    	
    	if(StringUtils.isEmpty(input.getPrcsFofOrgNo())) {

	        logger.debug("처리영업소조직번호  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"처리영업소조직번호"}, new Object[]{"처리영업소조직번호"});
		}
    	
    	if(StringUtils.isEmpty(input.getPrcsEno())) {

	        logger.debug("처리사원번호  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"처리사원번호"}, new Object[]{"처리사원번호"});
		}
    	
    	if(StringUtils.isEmpty(input.getContNo())) {

	        logger.debug("계약번호를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"계약번호"}, new Object[]{"계약번호"});
		}

		if(StringUtils.isEmpty(input.getSavgPrdcd())) {

	        logger.debug("저축상품코드를  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"저축상품코드"}, new Object[]{"저축상품코드"});
		}

		if(StringUtils.isEmpty(input.getPrcsYn())) {

	        logger.debug("처리여부  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"처리여부"}, new Object[]{"처리여부"});
		}
		
		if(StringUtils.isEmpty(input.getTaxpfRcd())) {

	        logger.debug("세금우대결과코드  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대결과코드"}, new Object[]{"세금우대결과코드"});
		}
		
		if(StringUtils.isEmpty(input.getTaxpfTgmKcd())) {

	        logger.debug("세금우대전문종류코드  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대전문종류코드"}, new Object[]{"세금우대전문종류코드"});
		}
		
		if(StringUtils.isEmpty(input.getTaxpfBzDcd())) {

	        logger.debug("세금우대업무구분코드  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대업무구분코드"}, new Object[]{"세금우대업무구분코드"});
		}
		
		if(StringUtils.isEmpty(input.getTaxpfBzPrcsDcd())) {

	        logger.debug("세금우대업무처리구분코드  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대업무처리구분코드"}, new Object[]{"세금우대업무처리구분코드"});
		}
		
		if(StringUtils.isEmpty(input.getNrmCnclDcd())) {

	        logger.debug("정상취소구분코드  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"정상취소구분코드"}, new Object[]{"정상취소구분코드"});
		}
		
		if(StringUtils.isEmpty(input.getTaxpfTgmDataCtnt())) {

	        logger.debug("세금우대전문데이터내용  입력하지 않았습니다");
	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대전문데이터내용"}, new Object[]{"세금우대전문데이터내용"});
		}		

		
	}
    
    /**
   	 * <p> 세금우대로그 입력값  확인</p>
   	 * @param 
   	 * @throws ApplicationException
   	 */
       
       private void chkUpdateTaxpfLogIo ( TBCNETC026Io input) throws ApplicationException {

       	
       	if(StringUtils.isEmpty(input.getPrcsDtm())) {

   	        logger.debug("처리일시  입력하지 않았습니다");
   	        throw new ApplicationException("APPRE0000", new Object[]{"처리일시"}, new Object[]{"처리일시"});
   		}
       	
       	if(StringUtils.isEmpty(input.getTaxpfTgmNo())) {

   	        logger.debug("세금우대전문번호  입력하지 않았습니다");
   	        throw new ApplicationException("APPRE0000", new Object[]{"세금우대전문번호"}, new Object[]{"세금우대전문번호"});
   		}
       		
   	}    
    
    
    /**
	 * <p> 세금우대저축상품코드셋팅 입력값  확인</p>
	 * @param 
	 * @throws ApplicationException
	 */
    private void chkTaxpfSavgPrdcdIo ( TaxpfSavgKndDvsnReqDO input) throws ApplicationException {
    	
    	if (StringUtils.isEmpty(input.getContBzDcd())) {
            logger.error("개인단체계약구분코드 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "개인단체계약구분코드" });
        }
    	if (StringUtils.isEmpty(input.getPmPrd().toString())) {
            logger.error("납입기간 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "납입기간" });
        }
    	if (StringUtils.isEmpty(input.getInsPrdYcnt().toString())) {
            logger.error("보험기간년수 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "보험기간년수" });
        }
    	if (StringUtils.isEmpty(input.getPmCylCd())) {
            logger.error("납입주기코드 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "납입주기코드" });
        }
    	if (StringUtils.isEmpty(input.getPpyNts().toString())) {
            logger.error("선납횟수 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "선납횟수" });
        }

    	if (StringUtils.isEmpty(input.getPrdcd())) {
            logger.error("상품코드 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "상품코드" });
        }
    	if (StringUtils.isEmpty(input.getContrCustNo())) {
            logger.error("계약자고객번호 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "계약자고객번호" });
        }
    	if (StringUtils.isEmpty(input.getPinsdCustNo())) {
            logger.error("주피보험자고객번호 없습니다.");
            throw new ApplicationException("APNBE0000", new String[] { "주피보험자고객번호" });
        }
//    	if (StringUtils.isEmpty(input.getExpiBenfcCustNo())) {
//            logger.error("만기수익자고객번호 없습니다.");
//            throw new ApplicationException("APNBE0000", new String[] { "만기수익자고객번호" });
//        }
    	
    }

}

