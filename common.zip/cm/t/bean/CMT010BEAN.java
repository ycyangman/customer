package cigna.cm.t.bean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA002BEAN;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.t.dbio.CMT010DBIO;
import cigna.cm.t.domain.BfFininRegCtntAddInqDO;
import cigna.cm.t.domain.BfFininRegCtntInqDO;
import cigna.cm.t.domain.SavgKcdDetlDtlcAddInqDO;
import cigna.cm.t.domain.SavgKcdDetlDtlcInqDO;
import cigna.cm.t.domain.SavgKcdDetlRegCtntInqDO;
import cigna.cm.t.domain.TaxpfCorrcDO;
import cigna.cm.t.domain.TaxpfSavgKndClLmtInqDO;
import cigna.cm.t.io.CMT010SVC01Out;
import cigna.cm.t.io.CMT010SVC01Sub0;
import cigna.zz.BizCommUtil;


/**
 * @file         cigna.cm.t.bean.CMT010BEAN.java
 * @filetype     java source file
 * @brief        세금우대간입한도조회
 * @author       권문
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           권문                   2013. 7. 23.       신규 작성
 *
 */
@KlafBean
public class CMT010BEAN {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
    @Autowired
    private CMT001BEAN cmt001bean;
    
    /**
     * 계약번호전환내역 조회 DBIO
     */
    @Autowired
    private CMT010DBIO cmt010dbio;

    @Autowired
    private CMA002BEAN cma002bean;

    
	/**
	 * 세금우대한도조회
	 * 
	 * @param  TaxPfrLmtInqDO 세금우대한도조회DO
	 * @return TaxPfrLmtInqDO 세금우대한도조회DO
	 * @throws ApplicationException
	 */
	public CMT010SVC01Out taxPfrLmtInq( String custNm, String custDscNo, String savgPrdcd, String isudTpcd, String mgntTgmCd) throws ApplicationException {
		
		
	     /****************************************************************       
	      *경문선 20130507 전산의뢰　언더라이팅팀20130304-323000-48322              
	      * NBX0027-TRT-GB  =  '1'  0200-205 세금우대저축종류별한도조회             
	      *                    '2'  0200-216 세금우대저축종류별세부내역  savgKcdDetlDtlcInq           
	      *                    '3'  0300-216 세금우대저축종류별세부추가  savgKcdDetlDtlcAddInq           
	      *                    '4'  0200-215 해당계좌등록내용조회　　　             
	      *                    '5'  0200-205 세금우대저축종류별한도조회             
	      *                                  세금우대금액계산안함　　               
	      *                    '6'  0200-210 세금우대전금융기관등록내역  bfFininRegCtntInq           
	      *                    '7'  0300-210 세금우대전금융기관등록추가  bfFininRegCtntAddInq           
	      *****************************************************************/
		CMT010SVC01Out output = new CMT010SVC01Out();
		CMT010SVC01Sub0 outputSub0 = new CMT010SVC01Sub0();
		List<CMT010SVC01Sub0> outputSub0List = new ArrayList<CMT010SVC01Sub0>();

		
		this.validData( custNm, custDscNo, savgPrdcd );
		
		String prgGb = "";
		if( "S".equals(isudTpcd) ){// 조회버튼
			
			prgGb = "2";
			
			// 전체 조회시
			if( "00".equals(savgPrdcd)){
				prgGb = "6";
			}
			
		}else{
			
			prgGb = "3";
			
			if( "00".equals(savgPrdcd)){
				prgGb = "7";
			}
			
		}
		
		CommEmplInfo emplInfo = cma002bean.getLoginEmplInfo();
		
		String    tempDpsTxNo        = ""                      ; // 입금거래번호
		String    tempPrcsDofOrgNo   = emplInfo.getDofOrgNo()  ; // 처리지점조직번호
		String    tempPrcsFofOrgNo   = emplInfo.getFofOrgNo()  ; // 처리영업소조직번호
		String    tempPrcsEno        = emplInfo.getEno()       ; // 처리사원번호
		String    tempContNo         = ""                      ; // 계약번호
		String    tempSavgPrdcd      = savgPrdcd               ; // 저축상품코드
		String    tempRrno           = custDscNo               ; // 주민등록번호
		String    tempRrnoDvsn       = "1"                     ; // 구분코드
		String    tempInqReqSavgKcd  = savgPrdcd               ; // 저축종류
		String    tempTaxpfBzPrcsDcd = "PR"                    ; // 세금우대업무처리구분코드
		String    tempMgntTgmCd      = mgntTgmCd               ; // 전문관리번호
		
		logger.debug("=========  prgGb  ===============" + prgGb);
		
		if( "2".equals(prgGb) ){
			
			SavgKcdDetlDtlcInqDO input = new SavgKcdDetlDtlcInqDO();
			
			input.setDpsTxNo        (  tempDpsTxNo         ); // 입금거래번호
			input.setPrcsDofOrgNo   (  tempPrcsDofOrgNo    ); // 처리지점조직번호
			input.setPrcsFofOrgNo   (  tempPrcsFofOrgNo    ); // 처리영업소조직번호
			input.setPrcsEno        (  tempPrcsEno         ); // 처리사원번호
			input.setContNo         (  tempContNo          ); // 계약번호
			input.setSavgPrdcd      (  tempSavgPrdcd       ); // 저축상품코드
			input.setRrno           (  tempRrno            ); // 주민등록번호
			input.setRrnoDvsn       (  tempRrnoDvsn        ); // 구분코드
			input.setInqReqSavgKcd  (  tempInqReqSavgKcd   ); // 저축종류
			input.setTaxpfBzPrcsDcd (  tempTaxpfBzPrcsDcd  ); // 세금우대업무처리구분코드(PR = 보전)
			
			logger.info("input 2:{} ",input);
			
			SavgKcdDetlDtlcInqDO tempOutput = cmt001bean.savgKcdDetlDtlcInq( input );
			
			logger.info("tempOutput 2 :{} ",tempOutput);
			
			
			// ------------- 응답 전문 MOVE START ------------------- //
			output.setTgmKndCd			     ( tempOutput.getTgmKndCd                         ( ) );  // set [전문종별코드]
			output.setAssoBusiGb		     ( tempOutput.getAssoBusiGb                       ( ) );  // set [협회업무구분]
			output.setTrnsDtm			     ( tempOutput.getTrnsDtm                          ( ) );  // set [전문전송일시]
			output.setMgntTgmCd			     ( tempOutput.getMgntTgmCd                        ( ) );  // set [전문관리번호]
			output.setSndInstCd			     ( tempOutput.getSndInstCd                        ( ) );  // set [전송기관코드]
			output.setRcvInstCd			     ( tempOutput.getRcvInstCd                        ( ) );  // set [수신기관코드]
			output.setAssoRspCd			     ( tempOutput.getAssoRspCd                        ( ) );  // set [협회응답코드]
			output.setRrnoDvsn               ( tempOutput.getRrnoDvsn                         ( ) );  // set [주민(사업자)등록번호구분]
			output.setConm                   ( tempOutput.getConm                             ( ) );  // set [상호(기업체명)]
			output.setName                   ( tempOutput.getName                             ( ) );  // set [성명(대표자)]
			output.setInfoMnbdyDvsn          ( tempOutput.getInfoMnbdyDvsn                    ( ) );  // set [정보주체(구 장애인)구분]
			output.setIncmrDvsn              ( tempOutput.getIncmrDvsn                        ( ) );  // set [저소득자구분(농어가저축)]
			output.setInqReqSavgLmt          ( tempOutput.getInqReqSavgLmt                    ( ) );  // set [조회요청저축종류한도]
			output.setInqReqSavgEntAmt       ( tempOutput.getInqReqSavgEntAmt                 ( ) );  // set [조회요청저축종류가입총액]
			output.setInqReqSavgLmtAmt       ( tempOutput.getInqReqSavgLmtAmt                 ( ) );  // set [조회요청저축종류한도잔여액]
			output.setInqReqSavgDupYn        ( tempOutput.getInqReqSavgDupYn                  ( ) );  // set [조회요청저축종류중복여부]
			output.setInqReqSavgReptCtntMore ( tempOutput.getInqReqSavgReptCtntMore           ( ) );  // set [조회요청저축회보내용MORE]
			output.setTaxpfReptCnt           ( tempOutput.getTaxpfReptCnt                     ( ) );  // set [세금우대회보건수]
			output.setInqReqSavgTtlCnt   (tempOutput.getInqReqSavgTtlCnt( ));  // set [조회요청저축종류총건수]

			
			//세금우대회보사항
			if(tempOutput.getTaxpfReptMtrDO() != null){
				for(int i = 0; i < tempOutput.getTaxpfReptMtrDO().size(); i++ ){
					
					outputSub0 = new CMT010SVC01Sub0();
					
					outputSub0.setRescsDcd		    (  tempOutput.getTaxpfReptMtrDO().get(i).getRescsDcd          ());  // set [해지구분코드]
					outputSub0.setRegOffc		    (  tempOutput.getTaxpfReptMtrDO().get(i).getRegOffc           ());  // set [등록점포]
					outputSub0.setActNo			    (  tempOutput.getTaxpfReptMtrDO().get(i).getActNo             ());  // set [계좌번호]
					outputSub0.setSavgKcd		    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgKcd           ());  // set [저축종류]
					outputSub0.setSavgNewDt		    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgNewDt         ());  // set [저축신규일]
					outputSub0.setSavgLastChgDt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgLastChgDt     ());  // set [저축최종변경일]
					outputSub0.setTaxpfEntAmt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getTaxpfEntAmt       ());  // set [세금우대가입금액]
					outputSub0.setExpiDt			(  tempOutput.getTaxpfReptMtrDO().get(i).getExpiDt            ());  // set [만기일]
					outputSub0.setTaxpfRescsDt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getTaxpfRescsDt      ());  // set [세금우대해지일]
					outputSub0.setIntDividPayAmt	(  tempOutput.getTaxpfReptMtrDO().get(i).getIntDividPayAmt    ());  // set [이자배당지급액]
					outputSub0.setHeirYn			(  tempOutput.getTaxpfReptMtrDO().get(i).getHeirYn            ());  // set [상속여부]
					outputSub0.setHousPrpsDpstDcd   (  tempOutput.getTaxpfReptMtrDO().get(i).getHousPrpsDpstDcd   ());  // set [주택청약예부금구분]
					
					if(!StringUtils.isEmpty(tempOutput.getTaxpfReptMtrDO().get(i).getActNo())){
						
						if(tempOutput.getTaxpfReptMtrDO().get(i).getActNo().length() == 8){
							//구계약번호로 신계약번호 조회 DBIO 호출
							String newContNo = cmt010dbio.selectOneTBCNETC001b(StringUtils.lpad(tempOutput.getTaxpfReptMtrDO().get(i).getActNo(), 9, "0"));
							
							if(!StringUtils.isEmpty(newContNo)){
								outputSub0.setContNo(newContNo);
							}
						}
					}
					
					if("00".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[00]활동계좌") ;
					}else if("10".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[10]만기해지") ;
					}else if("21".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[21]자동중도해지") ;
					}else if("22".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[22]강제해지") ;
					}else if("23".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[23]신청해지") ;
					}else if("24".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[24]특별중도해지") ;
					}else if("25".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[25]선택해지") ;
					}else if("30".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[30]자동만기해지") ;
					}
					
					logger.info("outputSub0 2 :{} ",outputSub0); 
					outputSub0List.add(outputSub0);
				}
			}

			output.setTaxDtlInfo(outputSub0List);
			output.setTaxDtlInfoCnt(outputSub0List.size());


			
		}else if( "3".equals(prgGb) ){
			
			SavgKcdDetlDtlcAddInqDO input = new SavgKcdDetlDtlcAddInqDO();
			
			input.setDpsTxNo        (  tempDpsTxNo         ); // 입금거래번호
			input.setPrcsDofOrgNo   (  tempPrcsDofOrgNo    ); // 처리지점조직번호
			input.setPrcsFofOrgNo   (  tempPrcsFofOrgNo    ); // 처리영업소조직번호
			input.setPrcsEno        (  tempPrcsEno         ); // 처리사원번호
			input.setContNo         (  tempContNo          ); // 계약번호
			input.setSavgPrdcd      (  tempSavgPrdcd       ); // 저축상품코드
			input.setRrno           (  tempRrno            ); // 주민등록번호
			input.setRrnoDvsn       (  tempRrnoDvsn        ); // 구분코드
			input.setInqReqSavgKcd  (  tempInqReqSavgKcd   ); // 저축종류
			input.setTaxpfBzPrcsDcd (  tempTaxpfBzPrcsDcd  ); // 세금우대업무처리구분코드(PR = 보전)
			input.setMgntTgmCd      (  tempMgntTgmCd       ); // 전문관리번호
			
			logger.info("input 3:{} ",input);
			
			SavgKcdDetlDtlcAddInqDO tempOutput = cmt001bean.savgKcdDetlDtlcAddInq( input );
			logger.info("tempOutput 3:{} ",tempOutput);					
			
			// ------------- 응답 전문 MOVE START ------------------- //
			output.setTgmKndCd			     ( tempOutput.getTgmKndCd                         ( ) );  // set [전문종별코드]
			output.setAssoBusiGb		     ( tempOutput.getAssoBusiGb                       ( ) );  // set [협회업무구분]
			output.setTrnsDtm			     ( tempOutput.getTrnsDtm                          ( ) );  // set [전문전송일시]
			output.setMgntTgmCd			     ( tempOutput.getMgntTgmCd                        ( ) );  // set [전문관리번호]
			output.setSndInstCd			     ( tempOutput.getSndInstCd                        ( ) );  // set [전송기관코드]
			output.setRcvInstCd			     ( tempOutput.getRcvInstCd                        ( ) );  // set [수신기관코드]
			output.setAssoRspCd			     ( tempOutput.getAssoRspCd                        ( ) );  // set [협회응답코드]
			output.setRrnoDvsn               ( tempOutput.getRrnoDvsn                         ( ) );  // set [주민(사업자)등록번호구분]
			output.setConm                   ( tempOutput.getConm                             ( ) );  // set [상호(기업체명)]
			output.setName                   ( tempOutput.getName                             ( ) );  // set [성명(대표자)]
			output.setInfoMnbdyDvsn          ( tempOutput.getInfoMnbdyDvsn         		      ( ) );  // set [정보주체(구 장애인)구분]
			output.setIncmrDvsn              ( tempOutput.getIncmrDvsn                        ( ) );  // set [저소득자구분(농어가저축)]
			output.setInqReqSavgLmt          ( tempOutput.getInqReqSavgLmt                    ( ) );  // set [조회요청저축종류한도]
			output.setInqReqSavgEntAmt       ( tempOutput.getInqReqSavgEntAmt                 ( ) );  // set [조회요청저축종류가입총액]
			output.setInqReqSavgLmtAmt       ( tempOutput.getInqReqSavgLmtAmt                 ( ) );  // set [조회요청저축종류한도잔여액]
			output.setInqReqSavgDupYn        ( tempOutput.getInqReqSavgDupYn                  ( ) );  // set [조회요청저축종류중복여부]
			output.setInqReqSavgReptCtntMore ( tempOutput.getInqReqSavgReptCtntMore           ( ) );  // set [조회요청저축회보내용MORE]
			output.setTaxpfReptCnt           ( tempOutput.getTaxpfReptCnt                     ( ) );  // set [세금우대회보건수]
			
			if(StringUtils.isEmpty(tempOutput.getInqReqSavgTtlCnt())){
				output.setInqReqSavgTtlCnt(0);  // set [저축종류총건수 값 세팅]			
			}else{
				output.setInqReqSavgTtlCnt   ( Integer.parseInt(tempOutput.getInqReqSavgTtlCnt( )));  // set [조회요청저축종류총건수]
				
				logger.info("tempOutput.getTaxpfTtlRegCnt 3:{} ",tempOutput.getInqReqSavgTtlCnt( ));
			}
			
			//세금우대회보사항	
			if(tempOutput.getTaxpfReptMtrDO() != null){
				for(int i = 0; i < tempOutput.getTaxpfReptMtrDO().size(); i++ ){
					
					outputSub0 = new CMT010SVC01Sub0();
					
					outputSub0.setRescsDcd		    (  tempOutput.getTaxpfReptMtrDO().get(i).getRescsDcd          ());  // set [해지구분코드]
					outputSub0.setRegOffc		    (  tempOutput.getTaxpfReptMtrDO().get(i).getRegOffc           ());  // set [등록점포]
					outputSub0.setActNo			    (  tempOutput.getTaxpfReptMtrDO().get(i).getActNo             ());  // set [계좌번호]
					outputSub0.setSavgKcd		    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgKcd           ());  // set [저축종류]
					outputSub0.setSavgNewDt		    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgNewDt         ());  // set [저축신규일]
					outputSub0.setSavgLastChgDt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgLastChgDt     ());  // set [저축최종변경일]
					outputSub0.setTaxpfEntAmt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getTaxpfEntAmt       ());  // set [세금우대가입금액]
					outputSub0.setExpiDt			(  tempOutput.getTaxpfReptMtrDO().get(i).getExpiDt            ());  // set [만기일]
					outputSub0.setTaxpfRescsDt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getTaxpfRescsDt      ());  // set [세금우대해지일]
					outputSub0.setIntDividPayAmt	(  tempOutput.getTaxpfReptMtrDO().get(i).getIntDividPayAmt    ());  // set [이자배당지급액]
					outputSub0.setHeirYn			(  tempOutput.getTaxpfReptMtrDO().get(i).getHeirYn            ());  // set [상속여부]
					outputSub0.setHousPrpsDpstDcd   (  tempOutput.getTaxpfReptMtrDO().get(i).getHousPrpsDpstDcd   ());  // set [주택청약예부금구분]
					
					if(!StringUtils.isEmpty(tempOutput.getTaxpfReptMtrDO().get(i).getActNo())){
						
						if(tempOutput.getTaxpfReptMtrDO().get(i).getActNo().length() == 8){
							//구계약번호로 신계약번호 조회 DBIO 호출
							String newContNo = cmt010dbio.selectOneTBCNETC001b(StringUtils.lpad(tempOutput.getTaxpfReptMtrDO().get(i).getActNo(), 9, "0"));
							
							if(!StringUtils.isEmpty(newContNo)){
								outputSub0.setContNo(newContNo);
							}
						}
					}
					
					if("00".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[00]활동계좌") ;
					}else if("10".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[10]만기해지") ;
					}else if("21".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[21]자동중도해지") ;
					}else if("22".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[22]강제해지") ;
					}else if("23".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[23]신청해지") ;
					}else if("24".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[24]특별중도해지") ;
					}else if("25".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[25]선택해지") ;
					}else if("30".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[30]자동만기해지") ;
					}
					
					logger.info("outputSub0 3 :{} ",outputSub0);
					outputSub0List.add(outputSub0);
				}
			}

			output.setTaxDtlInfo(outputSub0List);
			output.setTaxDtlInfoCnt(outputSub0List.size());
			
		}else if( "6".equals(prgGb) ){
			
			BfFininRegCtntInqDO input = new BfFininRegCtntInqDO();	
			
			input.setDpsTxNo        (  tempDpsTxNo         ); // 입금거래번호
			input.setPrcsDofOrgNo   (  tempPrcsDofOrgNo    ); // 처리지점조직번호
			input.setPrcsFofOrgNo   (  tempPrcsFofOrgNo    ); // 처리영업소조직번호
			input.setPrcsEno        (  tempPrcsEno         ); // 처리사원번호
			input.setContNo         (  tempContNo          ); // 계약번호
			input.setSavgPrdcd      (  tempSavgPrdcd       ); // 저축상품코드
			input.setRrno           (  tempRrno            ); // 주민등록번호
			input.setRrnoDvsn       (  tempRrnoDvsn        ); // 구분코드
			input.setTaxpfBzPrcsDcd (  tempTaxpfBzPrcsDcd  ); // 세금우대업무처리구분코드(PR = 보전)
//			input.setInqReqSavgKcd  (  tempInqReqSavgKcd   ); // 저축종류
			input.setMgntTgmCd      (  tempMgntTgmCd       ); // 전문관리번호
			
			logger.debug("input 6:{} ",input);

			BfFininRegCtntInqDO tempOutput = cmt001bean.bfFininRegCtntInq( input );	
			logger.info("tempOutput 6:{} ",tempOutput);

			// ------------- 응답 전문 MOVE START ------------------- //
			output.setTgmKndCd			     (  tempOutput.getTgmKndCd                       ( ) );  // set [전문종별코드]
			output.setAssoBusiGb		     (  tempOutput.getAssoBusiGb                     ( ) );  // set [협회업무구분]
			output.setTrnsDtm			     (  tempOutput.getTrnsDtm                        ( ) );  // set [전문전송일시]
			output.setMgntTgmCd			     (  tempOutput.getMgntTgmCd                      ( ) );  // set [전문관리번호]
			output.setSndInstCd			     (  tempOutput.getSndInstCd                      ( ) );  // set [전송기관코드]
			output.setRcvInstCd			     (  tempOutput.getRcvInstCd                      ( ) );  // set [수신기관코드]
			output.setAssoRspCd			     (  tempOutput.getAssoRspCd                      ( ) );  // set [협회응답코드]
			output.setRrnoDvsn               (  tempOutput.getRrnoDvsn                       ( ) );  // set [주민(사업자)등록번호구분]
			output.setConm                   (  tempOutput.getConm                           ( ) );  // set [상호(기업체명)]
			output.setName                   (  tempOutput.getName                           ( ) );  // set [성명(대표자)]
			output.setInfoMnbdyDvsn          (  tempOutput.getInfoMnbdyDvsn                  ( ) );  // set [정보주체(구 장애인)구분]
			output.setIncmrDvsn              (  tempOutput.getIncmrDvsn                      ( ) );  // set [저소득자구분(농어가저축)]
//			output.setInqReqSavgLmt          (  tempOutput.getInqReqSavgLmt                  ( ) );  // set [조회요청저축종류한도]
			output.setInqReqSavgEntAmt       (  tempOutput.getTaxpfEntAmt                    ( ) );  // set [조회요청저축종류가입총액]
			output.setInqReqSavgLmtAmt       (  tempOutput.getTaxpfLmtAmt                    ( ) );  // set [조회요청저축종류한도잔여액]
			output.setInqReqSavgDupYn        (  tempOutput.getTaxpfDupYn                     ( ) );  // set [조회요청저축종류중복여부]
			output.setInqReqSavgReptCtntMore (  tempOutput.getTaxpfRegCtntMore               ( ) );  // set [조회요청저축회보내용MORE]
			output.setTaxpfReptCnt           (  tempOutput.getTaxpfReptCnt                   ( ) );  // set [세금우대회보건수]
			
			if(StringUtils.isEmpty(tempOutput.getTaxpfTtlRegCnt())){
				output.setInqReqSavgTtlCnt(0);  // set [저축종류총건수 값 세팅]			
			}else{
				output.setInqReqSavgTtlCnt   ( Integer.parseInt(tempOutput.getTaxpfTtlRegCnt( )));  // set [조회요청저축종류총건수]
				
				logger.info("tempOutput.getTaxpfTtlRegCnt 6:{} ",tempOutput.getTaxpfTtlRegCnt( ));
			}
			
			//세금우대회보사항
			if(tempOutput.getTaxpfReptMtrDO() != null){
				for(int i = 0; i < tempOutput.getTaxpfReptMtrDO().size(); i++ ){
					
					outputSub0 = new CMT010SVC01Sub0();
					
					outputSub0.setRescsDcd		    (  tempOutput.getTaxpfReptMtrDO().get(i).getRescsDcd          ());  // set [해지구분코드]
					outputSub0.setRegOffc		    (  tempOutput.getTaxpfReptMtrDO().get(i).getRegOffc           ());  // set [등록점포]
					outputSub0.setActNo			    (  tempOutput.getTaxpfReptMtrDO().get(i).getActNo             ());  // set [계좌번호]
					outputSub0.setSavgKcd		    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgKcd           ());  // set [저축종류]
					outputSub0.setSavgNewDt		    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgNewDt         ());  // set [저축신규일]
					outputSub0.setSavgLastChgDt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgLastChgDt     ());  // set [저축최종변경일]
					outputSub0.setTaxpfEntAmt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getTaxpfEntAmt       ());  // set [세금우대가입금액]
					outputSub0.setExpiDt			(  tempOutput.getTaxpfReptMtrDO().get(i).getExpiDt            ());  // set [만기일]
					outputSub0.setTaxpfRescsDt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getTaxpfRescsDt      ());  // set [세금우대해지일]
					outputSub0.setIntDividPayAmt	(  tempOutput.getTaxpfReptMtrDO().get(i).getIntDividPayAmt    ());  // set [이자배당지급액]
					outputSub0.setHeirYn			(  tempOutput.getTaxpfReptMtrDO().get(i).getHeirYn            ());  // set [상속여부]
					outputSub0.setHousPrpsDpstDcd   (  tempOutput.getTaxpfReptMtrDO().get(i).getHousPrpsDpstDcd   ());  // set [주택청약예부금구분]
					
					if(!StringUtils.isEmpty(tempOutput.getTaxpfReptMtrDO().get(i).getActNo())){
						
						if(tempOutput.getTaxpfReptMtrDO().get(i).getActNo().length() == 8){
							//구계약번호로 신계약번호 조회 DBIO 호출
							String newContNo = cmt010dbio.selectOneTBCNETC001b(StringUtils.lpad(tempOutput.getTaxpfReptMtrDO().get(i).getActNo(), 9, "0"));
							
							if(!StringUtils.isEmpty(newContNo)){
								outputSub0.setContNo(newContNo);
							}
						}
					}
					
					if("00".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[00]활동계좌") ;
					}else if("10".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[10]만기해지") ;
					}else if("21".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[21]자동중도해지") ;
					}else if("22".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[22]강제해지") ;
					}else if("23".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[23]신청해지") ;
					}else if("24".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[24]특별중도해지") ;
					}else if("25".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[25]선택해지") ;
					}else if("30".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[30]자동만기해지") ;
					}
					
					logger.info("outputSub0 6 :{} ",outputSub0);
					outputSub0List.add(outputSub0);
				}
			}

			output.setTaxDtlInfo(outputSub0List);
			output.setTaxDtlInfoCnt(outputSub0List.size());
			
		}else{// 7
			
			BfFininRegCtntAddInqDO input = new BfFininRegCtntAddInqDO();
			
			input.setDpsTxNo        (  tempDpsTxNo         ); // 입금거래번호
			input.setPrcsDofOrgNo   (  tempPrcsDofOrgNo    ); // 처리지점조직번호
			input.setPrcsFofOrgNo   (  tempPrcsFofOrgNo    ); // 처리영업소조직번호
			input.setPrcsEno        (  tempPrcsEno         ); // 처리사원번호
			input.setContNo         (  tempContNo          ); // 계약번호
			input.setSavgPrdcd      (  tempSavgPrdcd       ); // 저축상품코드
			input.setRrno           (  tempRrno            ); // 주민등록번호
			input.setRrnoDvsn       (  tempRrnoDvsn        ); // 구분코드
			input.setTaxpfBzPrcsDcd (  tempTaxpfBzPrcsDcd  ); // 세금우대업무처리구분코드(PR = 보전)
//			input.setInqReqSavgKcd  (  tempInqReqSavgKcd   ); // 저축종류
			input.setMgntTgmCd      (  tempMgntTgmCd       ); // 전문관리번호
			
			logger.info("input 7:{} ",input);
			
			BfFininRegCtntAddInqDO tempOutput = cmt001bean.bfFininRegCtntAddInq( input );
			logger.info("tempOutput 7:{} ",tempOutput);
			
			// ------------- 응답 전문 MOVE START ------------------- //
			output.setTgmKndCd			     (  tempOutput.getTgmKndCd                       ( ) );	 // set [전문종별코드]
			output.setAssoBusiGb		     (  tempOutput.getAssoBusiGb                     ( ) );	 // set [협회업무구분]
			output.setTrnsDtm			     (  tempOutput.getTrnsDtm                        ( ) );	 // set [전문전송일시]
			output.setMgntTgmCd			     (  tempOutput.getMgntTgmCd                      ( ) );	 // set [전문관리번호]
			output.setSndInstCd			     (  tempOutput.getSndInstCd                      ( ) );  // set [전송기관코드]
			output.setRcvInstCd			     (  tempOutput.getRcvInstCd                      ( ) );  // set [수신기관코드]
			output.setAssoRspCd			     (  tempOutput.getAssoRspCd                      ( ) );	 // set [협회응답코드]
			output.setRrnoDvsn               (  tempOutput.getRrnoDvsn                       ( ) );  // set [주민(사업자)등록번호구분]
			output.setConm                   (  tempOutput.getConm                           ( ) );  // set [상호(기업체명)]
			output.setName                   (  tempOutput.getName                           ( ) );  // set [성명(대표자)]
			output.setInfoMnbdyDvsn          (  tempOutput.getInfoMnbdyDvsn                  ( ) );  // set [정보주체(구 장애인)구분]
			output.setIncmrDvsn              (  tempOutput.getIncmrDvsn                      ( ) );  // set [저소득자구분(농어가저축)]
//			output.setInqReqSavgLmt          (  tempOutput.getInqReqSavgLmt                  ( ) );  // set [조회요청저축종류한도]
			output.setInqReqSavgEntAmt       (  tempOutput.getTaxpfEntAmt                    ( ) );  // set [조회요청저축종류가입총액]
			output.setInqReqSavgLmtAmt       (  tempOutput.getTaxpfLmtAmt                    ( ) );  // set [조회요청저축종류한도잔여액]
			output.setInqReqSavgDupYn        (  tempOutput.getTaxpfDupYn                     ( ) );  // set [조회요청저축종류중복여부]
			output.setInqReqSavgReptCtntMore (  tempOutput.getTaxpfRegCtntMore               ( ) );  // set [조회요청저축회보내용MORE]
			output.setTaxpfReptCnt           (  tempOutput.getTaxpfReptCnt                   ( ) );  // set [세금우대회보건수]
			
			if(StringUtils.isEmpty(tempOutput.getTaxpfTtlRegCnt())){
				output.setInqReqSavgTtlCnt(0);  // set [저축종류총건수 값 세팅]			
			}else{
				output.setInqReqSavgTtlCnt   ( Integer.parseInt(tempOutput.getTaxpfTtlRegCnt( )));   // set [조회요청저축종류총건수]
				
				logger.info("tempOutput.getTaxpfTtlRegCnt 7:{} ",tempOutput.getTaxpfTtlRegCnt( ));
			}
			
			//세금우대회보사항	
			if(tempOutput.getTaxpfReptMtrDO() != null){
				for(int i = 0; i < tempOutput.getTaxpfReptMtrDO().size(); i++ ){
					
					outputSub0 = new CMT010SVC01Sub0();
					
					outputSub0.setRescsDcd		    (  tempOutput.getTaxpfReptMtrDO().get(i).getRescsDcd          ());  // set [해지구분코드]
					outputSub0.setRegOffc		    (  tempOutput.getTaxpfReptMtrDO().get(i).getRegOffc           ());  // set [등록점포]
					outputSub0.setActNo			    (  tempOutput.getTaxpfReptMtrDO().get(i).getActNo             ());  // set [계좌번호]
					outputSub0.setSavgKcd		    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgKcd           ());  // set [저축종류]
					outputSub0.setSavgNewDt		    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgNewDt         ());  // set [저축신규일]
					outputSub0.setSavgLastChgDt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getSavgLastChgDt     ());  // set [저축최종변경일]
					outputSub0.setTaxpfEntAmt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getTaxpfEntAmt       ());  // set [세금우대가입금액]
					outputSub0.setExpiDt			(  tempOutput.getTaxpfReptMtrDO().get(i).getExpiDt            ());  // set [만기일]
					outputSub0.setTaxpfRescsDt	    (  tempOutput.getTaxpfReptMtrDO().get(i).getTaxpfRescsDt      ());  // set [세금우대해지일]
					outputSub0.setIntDividPayAmt	(  tempOutput.getTaxpfReptMtrDO().get(i).getIntDividPayAmt    ());  // set [이자배당지급액]
					outputSub0.setHeirYn			(  tempOutput.getTaxpfReptMtrDO().get(i).getHeirYn            ());  // set [상속여부]
					outputSub0.setHousPrpsDpstDcd   (  tempOutput.getTaxpfReptMtrDO().get(i).getHousPrpsDpstDcd   ());  // set [주택청약예부금구분]
					
					if(!StringUtils.isEmpty(tempOutput.getTaxpfReptMtrDO().get(i).getActNo())){
						
						if(tempOutput.getTaxpfReptMtrDO().get(i).getActNo().length() == 8){
							//구계약번호로 신계약번호 조회 DBIO 호출
							String newContNo = cmt010dbio.selectOneTBCNETC001b(StringUtils.lpad(tempOutput.getTaxpfReptMtrDO().get(i).getActNo(), 9, "0"));
							
							if(!StringUtils.isEmpty(newContNo)){
								outputSub0.setContNo(newContNo);
							}
						}
					}
					
					if("00".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[00]활동계좌") ;
					}else if("10".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[10]만기해지") ;
					}else if("21".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[21]자동중도해지") ;
					}else if("22".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[22]강제해지") ;
					}else if("23".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[23]신청해지") ;
					}else if("24".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[24]특별중도해지") ;
					}else if("25".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[25]선택해지") ;
					}else if("30".equals(outputSub0.getRescsDcd())){
						outputSub0.setRescsDcd("[30]자동만기해지") ;
					}

					logger.info("outputSub0 7 :{} ",outputSub0);
					
					outputSub0List.add(outputSub0);
				}
			}

			output.setTaxDtlInfo(outputSub0List);
			output.setTaxDtlInfoCnt(outputSub0List.size());
			
		}
		
		
		return output;
		
		
	}
	
	
	/**
	 * 입력값의 업무상 체크가 필요한 항목값 체크
	 * @param in
	 * @return
	 * @throws Exception
	 */
	private void validData( String custNm, String custDscNo, String savgPrdcd ) throws ApplicationException {
		
		
		//필수입력값 체크 (고객명)
		if( StringUtils.isEmpty(custNm) ) {
			logger.error("고객명를  입력하지 않았습니다");
			throw new ApplicationException( "APPRE0000", new Object[]{"고객명"}, new Object[]{"고객명"} );
		}
		
		if( StringUtils.isEmpty(custDscNo) ) {
			logger.error("고객주민등록번호를  입력하지 않았습니다");
			throw new ApplicationException( "APPRE0000", new Object[]{"고객주민등록번호"}, new Object[]{"고객주민등록번호"} );
		}
		
		if( StringUtils.isEmpty(savgPrdcd) ) {
			logger.error("저축종류를  입력하지 않았습니다");
			throw new ApplicationException( "APPRE0000", new Object[]{"저축종류"}, new Object[]{"저축종류"} );
		}
		
		
	}
	
	
	/**
	 * 세금우대한도조회
	 * 
	 * @param  TaxPfrLmtInqDO 세금우대한도조회DO
	 * @return TaxPfrLmtInqDO 세금우대한도조회DO
	 * @throws ApplicationException
	 */
	public CMT010SVC01Out taxpfSavgKndClLmtInq( String custNm, String custDscNo, String savgPrdcd, String isudTpcd, String mgntTgmCd, String prgGb) throws ApplicationException {
		
		
	     /****************************************************************       
	      *경문선 20130507 전산의뢰　언더라이팅팀20130304-323000-48322              
	      * NBX0027-TRT-GB  =  '1'  0200-205 세금우대저축종류별한도조회             
	      *                    '2'  0200-216 세금우대저축종류별세부내역  savgKcdDetlDtlcInq           
	      *                    '3'  0300-216 세금우대저축종류별세부추가  savgKcdDetlDtlcAddInq           
	      *                    '4'  0200-215 해당계좌등록내용조회　　　             
	      *                    '5'  0200-205 세금우대저축종류별한도조회             
	      *                                  세금우대금액계산안함　　               
	      *                    '6'  0200-210 세금우대전금융기관등록내역  bfFininRegCtntInq           
	      *                    '7'  0300-210 세금우대전금융기관등록추가  bfFininRegCtntAddInq           
	      *****************************************************************/
		CMT010SVC01Out output = new CMT010SVC01Out();
		CMT010SVC01Sub0 outputSub0 = new CMT010SVC01Sub0();
		List<CMT010SVC01Sub0> outputSub0List = new ArrayList<CMT010SVC01Sub0>();

		
		this.validData( custNm, custDscNo, savgPrdcd );
		
		//String prgGb = "1";
		
		CommEmplInfo emplInfo = cma002bean.getLoginEmplInfo();
		
		String    tempDpsTxNo        = ""                      ; // 입금거래번호
		String    tempPrcsDofOrgNo   = emplInfo.getDofOrgNo()  ; // 처리지점조직번호
		String    tempPrcsFofOrgNo   = emplInfo.getFofOrgNo()  ; // 처리영업소조직번호
		String    tempPrcsEno        = emplInfo.getEno()       ; // 처리사원번호
		String    tempContNo         = ""                      ; // 계약번호
		String    tempSavgPrdcd      = savgPrdcd               ; // 저축상품코드
		String    tempRrno           = custDscNo               ; // 주민등록번호
		String    tempRrnoDvsn       = "1"                     ; // 구분코드
		String    tempInqReqSavgKcd  = savgPrdcd               ; // 저축종류
		String    tempTaxpfBzPrcsDcd = "PR"                    ; // 세금우대업무처리구분코드
		String    tempMgntTgmCd      = mgntTgmCd               ; // 전문관리번호
		
		logger.debug("=========  prgGb  ===============" + prgGb);
		
		if( "1".equals(prgGb) ){
			
			TaxpfSavgKndClLmtInqDO input = new TaxpfSavgKndClLmtInqDO();
			
			input.setDpsTxNo        (  tempDpsTxNo         ); // 입금거래번호
			input.setPrcsDofOrgNo   (  tempPrcsDofOrgNo    ); // 처리지점조직번호
			input.setPrcsFofOrgNo   (  tempPrcsFofOrgNo    ); // 처리영업소조직번호
			input.setPrcsEno        (  tempPrcsEno         ); // 처리사원번호
			input.setContNo         (  tempContNo          ); // 계약번호
			input.setSavgPrdcd      (  tempSavgPrdcd       ); // 저축상품코드
			input.setRrno           (  tempRrno            ); // 주민등록번호
			input.setRrnoDvsn       (  tempRrnoDvsn        ); // 구분코드
			input.setLmtInqSavgKnd  (  tempInqReqSavgKcd   ); // 저축종류
			input.setTaxpfBzPrcsDcd (  tempTaxpfBzPrcsDcd  ); // 세금우대업무처리구분코드(PR = 보전)
			input.setInfoMnbdyDvsn  (  "1"  ); // 장애구분처리구분코드(PR = 보전)
			input.setIncmrDvsn  (  "1"  ); // 농어촌
			
			logger.info("input 2:{} ",input);
			
			TaxpfSavgKndClLmtInqDO tempOutput = cmt001bean.taxpfSavgKndClLmtInq( input );
			
			logger.info("tempOutput 2 :{} ",tempOutput);
			
			
			// ------------- 응답 전문 MOVE START ------------------- //
			output.setTgmKndCd			     ( tempOutput.getTgmKndCd                         ( ) );  // set [전문종별코드]
			output.setAssoBusiGb		     ( tempOutput.getAssoBusiGb                       ( ) );  // set [협회업무구분]
			output.setTrnsDtm			     ( tempOutput.getTrnsDtm                          ( ) );  // set [전문전송일시]
			output.setMgntTgmCd			     ( tempOutput.getMgntTgmCd                        ( ) );  // set [전문관리번호]
			output.setSndInstCd			     ( tempOutput.getSndInstCd                        ( ) );  // set [전송기관코드]
			output.setRcvInstCd			     ( tempOutput.getRcvInstCd                        ( ) );  // set [수신기관코드]
			output.setAssoRspCd			     ( tempOutput.getAssoRspCd                        ( ) );  // set [협회응답코드]
			output.setRrnoDvsn               ( tempOutput.getRrnoDvsn                         ( ) );  // set [주민(사업자)등록번호구분]
			output.setConm                   ( tempOutput.getConm                             ( ) );  // set [상호(기업체명)]
			output.setName                   ( tempOutput.getName                             ( ) );  // set [성명(대표자)]
			output.setInfoMnbdyDvsn          ( tempOutput.getInfoMnbdyDvsn                    ( ) );  // set [정보주체(구 장애인)구분]
			output.setIncmrDvsn              ( tempOutput.getIncmrDvsn                        ( ) );  // set [저소득자구분(농어가저축)]
			
		}
		else if( "2".equals(prgGb) ){
			
			SavgKcdDetlDtlcInqDO input = new SavgKcdDetlDtlcInqDO();
			
			input.setDpsTxNo        (  tempDpsTxNo         ); // 입금거래번호
			input.setPrcsDofOrgNo   (  tempPrcsDofOrgNo    ); // 처리지점조직번호
			input.setPrcsFofOrgNo   (  tempPrcsFofOrgNo    ); // 처리영업소조직번호
			input.setPrcsEno        (  tempPrcsEno         ); // 처리사원번호
			input.setContNo         (  tempContNo          ); // 계약번호
			input.setInqReqSavgKcd   (  tempSavgPrdcd       ); // 저축상품코드
			input.setRrno           (  tempRrno            ); // 주민등록번호
			input.setRrnoDvsn       (  tempRrnoDvsn        ); // 구분코드
			input.setTaxpfBzPrcsDcd (  tempTaxpfBzPrcsDcd  ); // 세금우대업무처리구분코드(PR = 보전)
			
			logger.info("input 2:{} ",input);
			
			SavgKcdDetlRegCtntInqDO tempOutput = cmt001bean.savgKcdDetlRegCtntInq( input );
			
			logger.info("tempOutput 2 :{} ",tempOutput);
			
			
			// ------------- 응답 전문 MOVE START ------------------- //
			output.setTgmKndCd			     ( tempOutput.getTgmKndCd                         ( ) );  // set [전문종별코드]
			output.setAssoBusiGb		     ( tempOutput.getAssoBusiGb                       ( ) );  // set [협회업무구분]
			output.setTrnsDtm			     ( tempOutput.getTrnsDtm                          ( ) );  // set [전문전송일시]
			output.setMgntTgmCd			     ( tempOutput.getMgntTgmCd                        ( ) );  // set [전문관리번호]
			output.setSndInstCd			     ( tempOutput.getSndInstCd                        ( ) );  // set [전송기관코드]
			output.setRcvInstCd			     ( tempOutput.getRcvInstCd                        ( ) );  // set [수신기관코드]
			output.setAssoRspCd			     ( tempOutput.getAssoRspCd                        ( ) );  // set [협회응답코드]
			output.setRrnoDvsn               ( tempOutput.getRrnoDvsn                         ( ) );  // set [주민(사업자)등록번호구분]
			output.setConm                   ( tempOutput.getConm                             ( ) );  // set [상호(기업체명)]
			output.setName                   ( tempOutput.getName                             ( ) );  // set [성명(대표자)]
			output.setInfoMnbdyDvsn          ( tempOutput.getInfoMnbdyDvsn                    ( ) );  // set [정보주체(구 장애인)구분]
			output.setIncmrDvsn              ( tempOutput.getIncmrDvsn                        ( ) );  // set [저소득자구분(농어가저축)]
		} else if( "3".equals(prgGb) ){
			
			TaxpfCorrcDO input = new TaxpfCorrcDO();
			
			input.setPrcsDofOrgNo(emplInfo.getDofOrgNo());									//처리지점조직번호
			input.setPrcsFofOrgNo(emplInfo.getFofOrgNo());									//처리영업소조직번호
			input.setPrcsEno(emplInfo.getEno());										//처리사원번호
			input.setTaxpfBzPrcsDcd("PR");								//세금우대업무처리구분코드		

			input.setDpsTxNo("1234555666");										//입금거래번호
			input.setContNo("24410Z0306");										//계약번호
			input.setSavgPrdcd(savgPrdcd);										//저축상품코드
		
			input.setBfchRrno	       ("6007032463030");         // set [변경전주민등록번호				]
			input.setBfchRrnoDvsn      ("1");         // set [변경전주민등록번호구분			]	
			input.setBfchSavgKnd       (savgPrdcd);         // set [변경전저축종류					]			
			input.setBfchOpenOffcCd    ("2061005");         // set [변경전개설점포코드				]					
			input.setBfchActNo         ("24410Z0306");         // set [변경전계좌번호					]
			input.setAfchRrno	       ("6007032463031");         // set [변경후주민등록번호				]
			input.setAfchRrnoDvsn	   ("1");         // set [변경후주민등록번호구분			]
			input.setAfchName	       ("홍길동");         // set [변경후성명(대표자)				]
			input.setAfchInfoMnbdyDvsn ("0");         // set [변경후정보주체(구장애인)구분	]								
			input.setAfchIncmrDvsn     ("0");         // set [변경후저소득자구분(농어가저축)	]							
			input.setAfchSavgKnd       ( savgPrdcd );         // set [변경후저축종류					]				
			input.setAfchOpenOffcCd    ("2061005");         // set [변경후개설점포코드				]					
			input.setAfchActNo         ("24410Z0307");         // set [변경후계좌번호					]					
			input.setAfchActOpenDy	   ("20160728");         // set [변경후계좌개설일				]			
			input.setAfchTaxpfAmt  (BigDecimal.ZERO);         // set [변경후세금우대금액(단위:원)		]
			input.setAfchExpiDy    ("20301231");         // set [변경후만기일					]			
			input.setAfchFstExpiExtnDy ("20311231");         // set [변경후최초만기연장일			]
			input.setAfchRescsKnd	   ("23");         // set [변경후해지종류					]	
			input.setAfchInhrtYn       ("0");         // set [변경후상속여부					]				
			input.setAfchHousPrpsDvsn  ("0");         // set [변경후주택청약예부금구분		]
			input.setAfchIntDivdAmt	   ( BigDecimal.ZERO );         // set [변경후이자,배당지급액(단위:원) 0원으로세팅

			TaxpfCorrcDO tempOutput = cmt001bean.taxpfCorrc(input);
			
			// ------------- 응답 전문 MOVE START ------------------- //
			output.setTgmKndCd			     ( tempOutput.getTgmKndCd                         ( ) );  // set [전문종별코드]
			output.setAssoBusiGb		     ( tempOutput.getAssoBusiGb                       ( ) );  // set [협회업무구분]
			output.setTrnsDtm			     ( tempOutput.getTrnsDtm                          ( ) );  // set [전문전송일시]
			output.setMgntTgmCd			     ( tempOutput.getMgntTgmCd                        ( ) );  // set [전문관리번호]
			output.setSndInstCd			     ( tempOutput.getSndInstCd                        ( ) );  // set [전송기관코드]
			output.setRcvInstCd			     ( tempOutput.getRcvInstCd                        ( ) );  // set [수신기관코드]
			output.setAssoRspCd			     ( tempOutput.getAssoRspCd                        ( ) );  // set [협회응답코드]
			output.setRrnoDvsn               ( "1" );  // set [주민(사업자)등록번호구분]
			output.setConm                   ( "테트스" );  // set [상호(기업체명)]
			output.setName                   ( "테스트" );  // set [성명(대표자)]
			output.setInfoMnbdyDvsn          ( "1" );  // set [정보주체(구 장애인)구분]
			output.setIncmrDvsn              ( "1" );  // set [저소득자구분(농어가저축)]
				
		} else if( "4".equals(prgGb) ){
			
			BfFininRegCtntInqDO input = new BfFininRegCtntInqDO();
			
			input.setDpsTxNo        (  tempDpsTxNo         ); // 입금거래번호
			input.setPrcsDofOrgNo   (  tempPrcsDofOrgNo    ); // 처리지점조직번호
			input.setPrcsFofOrgNo   (  tempPrcsFofOrgNo    ); // 처리영업소조직번호
			input.setPrcsEno        (  tempPrcsEno         ); // 처리사원번호
			input.setContNo         (  tempContNo          ); // 계약번호
			input.setRrno           (  tempRrno            ); // 주민등록번호
			input.setRrnoDvsn       (  tempRrnoDvsn        ); // 구분코드
			input.setTaxpfBzPrcsDcd (  tempTaxpfBzPrcsDcd  ); // 세금우대업무처리구분코드(PR = 보전)
			
			logger.info("input 2:{} ",input);
			
			BfFininRegCtntInqDO tempOutput = cmt001bean.bfFininRegCtntInq( input );
			
			logger.info("tempOutput 2 :{} ",tempOutput);
			
			
			// ------------- 응답 전문 MOVE START ------------------- //
			output.setTgmKndCd			     ( tempOutput.getTgmKndCd                         ( ) );  // set [전문종별코드]
			output.setAssoBusiGb		     ( tempOutput.getAssoBusiGb                       ( ) );  // set [협회업무구분]
			output.setTrnsDtm			     ( tempOutput.getTrnsDtm                          ( ) );  // set [전문전송일시]
			output.setMgntTgmCd			     ( tempOutput.getMgntTgmCd                        ( ) );  // set [전문관리번호]
			output.setSndInstCd			     ( tempOutput.getSndInstCd                        ( ) );  // set [전송기관코드]
			output.setRcvInstCd			     ( tempOutput.getRcvInstCd                        ( ) );  // set [수신기관코드]
			output.setAssoRspCd			     ( tempOutput.getAssoRspCd                        ( ) );  // set [협회응답코드]
			output.setRrnoDvsn               ( tempOutput.getRrnoDvsn                         ( ) );  // set [주민(사업자)등록번호구분]
			output.setConm                   ( tempOutput.getConm                             ( ) );  // set [상호(기업체명)]
			output.setName                   ( tempOutput.getName                             ( ) );  // set [성명(대표자)]
			output.setInfoMnbdyDvsn          ( tempOutput.getInfoMnbdyDvsn                    ( ) );  // set [정보주체(구 장애인)구분]
			output.setIncmrDvsn              ( tempOutput.getIncmrDvsn                        ( ) );  // set [저소득자구분(농어가저축)]
				
		}
		
		return output;
		
	}
	
}

