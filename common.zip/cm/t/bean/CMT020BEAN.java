package cigna.cm.t.bean;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import cigna.cm.a.bean.CMA004BEAN;
import cigna.cm.t.dbio.CMT011DBIO;
import cigna.cm.t.io.CMT020SVC01In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00007In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00008In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00010In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00011In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00009In;
import cigna.cm.t.io.SelectMultiTBCNETC026aOut;
import cigna.cm.t.io.TBCNETC026Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.ApplicationContextTrace;
import klaf.container.annotation.KlafBean;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;
import klaf.omm.marshaller.IKLafMarshaller;
import klaf.omm.marshaller.factory.KLafMarshallerFactory;
import klaf.omm.marshaller.factory.KLafMarshallerFactory.Marshaller;
import klaf.omm.root.IOmmObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file         cigna.cm.t.bean.CMT020BEAN.java
 * @filetype     java source file
 * @brief        로그조회화면 bean
 * @author       문규식
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------
 * 0.1           문규식                  2013. 7. 18.           신규 작성
 *
 */
@KlafBean
public class CMT020BEAN {
    final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    CMT011DBIO cmt011dbio;	// 세금우대로그 조회 dbio

    @Autowired
    CMT005BEAN cmt005bean;	// 세금우대

    @Autowired
    private CMA004BEAN cma004bean;		// 채번관련 BEAN

    /**
     * 로그조회화면 조회
     *
     * @param CMT020SVC01In
     * @return CMT020SVC01Out
     */
    public List<SelectMultiTBCNETC026aOut> getlogScrInq(CMT020SVC01In ioBean) throws ApplicationException {

        List<SelectMultiTBCNETC026aOut> list = null;
        TBCNETC026Io tbcnetc026io = new TBCNETC026Io();

        tbcnetc026io.setPrcsDtm(StringUtils.nvl(ioBean.getPrcsDtm()));// set [처리일시]
        tbcnetc026io.setTaxpfTgmNo(StringUtils.nvl(ioBean.getTaxpfTgmNo()));// set [세금우대전문번호]
        tbcnetc026io.setPrcsDt(StringUtils.nvl(ioBean.getPrcsDt()));// set [처리일자]
        tbcnetc026io.setDpsTxNo(StringUtils.nvl(ioBean.getDpsTxNo()));// set [입금거래번호]
        tbcnetc026io.setPrcsDofOrgNo(StringUtils.nvl(ioBean.getPrcsDofOrgNo()));// set [처리지점조직번호]
        tbcnetc026io.setPrcsFofOrgNo(StringUtils.nvl(ioBean.getPrcsFofOrgNo()));// set [처리영업소조직번호]
        tbcnetc026io.setPrcsEno(StringUtils.nvl(ioBean.getPrcsEno()));// set [처리사원번호]
        tbcnetc026io.setContNo(StringUtils.nvl(ioBean.getContNo()));// set [계약번호]
        tbcnetc026io.setSavgPrdcd(StringUtils.nvl(ioBean.getSavgPrdcd()));// set [저축상품코드]
        tbcnetc026io.setPrcsYn(StringUtils.nvl(ioBean.getPrcsYn()));// set [처리여부]
        tbcnetc026io.setTaxpfRcd(StringUtils.nvl(ioBean.getTaxpfRcd()));// set [세금우대결과코드]
        tbcnetc026io.setTaxpfTgmKcd(StringUtils.nvl(ioBean.getTaxpfTgmKcd()));// set [세금우대전문종류코드]
        tbcnetc026io.setTaxpfBzDcd(StringUtils.nvl(ioBean.getTaxpfBzDcd()));// set [세금우대업무구분코드]
        tbcnetc026io.setTaxpfBzPrcsDcd(StringUtils.nvl(ioBean.getTaxpfBzPrcsDcd()));// set [세금우대업무처리구분코드]
        tbcnetc026io.setNrmCnclDcd(StringUtils.nvl(ioBean.getNrmCnclDcd()));// set [정상취소구분코드]

        if (!StringUtils.isEmpty(tbcnetc026io.getContNo())) {
        	tbcnetc026io.setPrcsDtm("");
        	tbcnetc026io.setTaxpfRcd("");// set [세금우대결과코드]
        }
        else {
            if (StringUtils.isEmpty(ioBean.getPrcsDtm())) {
	            // TODO : 문자열이 null이거나 값이 설정되지 않은 경우 로직 구현 및 필요시 오류 메시지 현행화
	            logger.error("처리일자가 없습니다.");
	            throw new ApplicationException("APNBE0000", new String[] { "처리일자" });
	        }
        }

        list = cmt011dbio.selectMultiTBCNETC026a(tbcnetc026io, ioBean.getPageNum(), ioBean.getPageCount());

        SecuUtil.doDecList(list);
        
        return list;
    }

    /**
     * 전송
     *
     * @param CMT020SVC01In
     * @return int
     */
    public int insertSend(CMT020SVC01In input) throws ApplicationException {

        List<SelectMultiTBCNETC026aOut> dsList = input.getDsList();

        int rtnCnt = 0;

        logger.debug("FwUtil.getUserId={}", FwUtil.getUserId());
        logger.debug("FwUtil.getPgmId={}", FwUtil.getPgmId());
        logger.debug("FwUtil.getTrmNo={}", FwUtil.getTrmNo());
        logger.debug("FwUtil.getTrmNo={}", FwUtil.getDeptCd());


        for (SelectMultiTBCNETC026aOut out : dsList) {
            if ("1".equals(out.getChkYn())) {

                if (!"0200".equals(out.getTaxpfTgmKcd()) && !"0300".equals(out.getTaxpfTgmKcd())) {

                    cigna.cm.t.io.TBCNETC026Io uTbcnetc026io = new cigna.cm.t.io.TBCNETC026Io();

                    uTbcnetc026io.setPrcsDtm(out.getPrcsDtm());// set [처리일시]
                    uTbcnetc026io.setTaxpfTgmNo(out.getTaxpfTgmNo());// set [세금우대전문번호]
                    uTbcnetc026io.setPrcsDt(out.getPrcsDt());// set [처리일자]
                    uTbcnetc026io.setDpsTxNo(out.getDpsTxNo());// set [입금거래번호]
                    uTbcnetc026io.setPrcsDofOrgNo(out.getPrcsDofOrgNo());// set [처리지점조직번호]
                    uTbcnetc026io.setPrcsFofOrgNo(out.getPrcsFofOrgNo());// set [처리영업소조직번호]
                    uTbcnetc026io.setPrcsEno(out.getPrcsEno());// set [처리사원번호]
                    uTbcnetc026io.setContNo(out.getContNo());// set [계약번호]
                    uTbcnetc026io.setSavgPrdcd(out.getSavgPrdcd());// set [저축상품코드]
                    uTbcnetc026io.setPrcsYn("Y");// set [처리여부]
                    uTbcnetc026io.setTaxpfRcd("999");// set [세금우대결과코드]
                    uTbcnetc026io.setTaxpfTgmKcd(out.getTaxpfTgmKcd());// set [세금우대전문종류코드]
                    uTbcnetc026io.setTaxpfBzDcd(out.getTaxpfBzDcd());// set [세금우대업무구분코드]
                    uTbcnetc026io.setTaxpfBzPrcsDcd(out.getTaxpfBzPrcsDcd());// set [세금우대업무처리구분코드]
                    uTbcnetc026io.setNrmCnclDcd(out.getNrmCnclDcd());// set [정상취소구분코드]
                    
                    uTbcnetc026io.setTaxpfTgmDataCtnt(out.getTaxpfTgmDataCtnt());// set [세금우대전문데이터내용]
                   
                    uTbcnetc026io.setDelYn(out.getDelYn());// set [삭제여부]

                    cmt005bean.updateTaxpfLog(uTbcnetc026io);

                    // 송신할 전문 공통부 재구성: 1)에서 할당한 전문의 공통부을 재구성함
                    //
                    // - 전문종별코드를 응답에서 송신으로 변경(종별코드3번째를 '0'으로 전환 : 4bytes EX) 0410 -> 0400)
                    // - 전문전송일시 현재정보로 변경
                    // - 전문번호 생성하는 bean의 해당method를 호출하여 송신할 전문번호 재생성(as_is의 EB#MTR03('TY', 처리일자 기준)
                    // - 응당코드 '000'으로 재설정
                    // - 송신기죈코드 'L51'
                    // - 수신기관코드 'L00'
                    // - 거래구분코드 SPAEC : 3bytes UPMU-GB

                    // : OSKLIALITB040021000000In.omm : 세금우대등록(0400/210, 0410/210)
                    // : OSKLIALITB050021000000In.omm : 세금우대해지(0500/210, 0510/210)
                    // : OSKLIALITB060021000000In.omm : 세금우대정정(0600/210, 0610/210)
                    // : OSKLIALITB060023000000In.omm : 세금우대삭제(0600/230, 0610/230)
                    // : OSKLIALITB060026000000In.omm : 세금우대해지취소(0600/260, 0610/260)
                    String taxpfTgmDataCtnt = "";	// 세금우대전문데이터내용
                    Calendar calendar = Calendar.getInstance();
                    //String prcsDtm = new SimpleDateFormat("yyyyMMddHHmmssSSSSSS", Locale.KOREA).format(calendar.getTime());  // 처리일시
                    String prcsDtm = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA).format(calendar.getTime());  // 처리일시

                    String taxpfTgmNo = cma004bean.getNewPayMkno("CMTP",
                            DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE), 15).substring(9);		// 세금우대전문번호 -
                    taxpfTgmNo = "0" + taxpfTgmNo;
                    String prcsYn = " ";											// 처리여부
                    String taxpfRcd = " "; 										// 세금우대결과코드 - 응답코드

                    // 채번(9번째자리부터
                    // 끝까지); // 세금우대전문번호

                    String dataCtnt = cmt011dbio.selectMultiTBCNETC026b(out.getPrcsDtm(), out.getTaxpfTgmNo());
                    
                    if(dataCtnt != null) {
                    	dataCtnt = SecuUtil.getDecValue(dataCtnt, EncType.Etc);
                    }

                    try {

                        if ("0400".equals(out.getTaxpfTgmKcd()) && "210".equals(out.getTaxpfBzDcd())) {
                            
                        	String interfaceId = "COM_F_KLIOSKOTS00007";						// EAI Interface ID
                            EISResponse<COM_F_KLIOSKOTS00007In> response = null;	// 세금우대한도조회 OMM
                            COM_F_KLIOSKOTS00007In responseData = null;				// 세금우대한도조회 OMM

                            COM_F_KLIOSKOTS00007In request = new COM_F_KLIOSKOTS00007In(); // 은행연합회 신용공여거래기업체
                                                                                                // 집중오류내역통보
                                                                                                // 수신(기등록오류) omm
                            logger.debug("dataCtnt [{}]", dataCtnt);
//                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request, "MS949"), "MS949");
//                            taxpfTgmDataCtnt = StringUtils.rpad(dataCtnt, taxpfTgmDataCtnt.length(), " ");
//                            logger.debug("taxpfTgmDataCtnt[{}]", taxpfTgmDataCtnt);
                            
                            //전송방법수정
                            taxpfTgmDataCtnt = dataCtnt;

                            request = this.toOMMFld(request.getClass(), taxpfTgmDataCtnt, null);
                            logger.debug("11 IO [{}]", new Object[] { request });

                            request.setTgmKndCd("0400");
                            request.setTrnsDtm(prcsDtm); 		// 전문전송일시

                            request.setMgntTgmCd(taxpfTgmNo);
//                            request.setAssoRspCd("000");
                            request.setSndInstCd("L51"); 										// 송신기관코드
                            request.setRcvInstCd("L00"); 										// 수신기관코드

                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026)
                            logger.debug(":{}",taxpfTgmDataCtnt);

                            logger.debug("송신전문request IO [{}]", new Object[] { request });
                            // ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //

                            //TODO:2016.07.05;대외계 호출 주석처리 추후 변경
                            //======================================
                            response = InfUtil.callFEP(request, interfaceId, COM_F_KLIOSKOTS00007In.class);
                            // 수신 결과
                            responseData = response.getResponseData();
                            taxpfRcd = responseData.getAssoRspCd(); 										// 세금우대결과코드 - 응답코드
                            //======================================
//                            taxpfRcd = "888"; 										// 세금우대결과코드 - 응답코드
                        } else if ("0500".equals(out.getTaxpfTgmKcd()) && "210".equals(out.getTaxpfBzDcd())) {

                            String interfaceId = "COM_F_KLIOSKOTS00008";						// EAI Interface ID
                            EISResponse<COM_F_KLIOSKOTS00008In> response = null;	// 세금우대한도조회 OMM
                            COM_F_KLIOSKOTS00008In responseData = null;				// 세금우대한도조회 OMM

                            COM_F_KLIOSKOTS00008In request = new COM_F_KLIOSKOTS00008In(); // 은행연합회 신용공여거래기업체
                                                                                                // 집중오류내역통보
                                                                                                // 수신(기등록오류) omm
                            logger.debug("dataCtnt [{}]", dataCtnt);
//                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request, "MS949"), "MS949");
//                            taxpfTgmDataCtnt = StringUtils.rpad(dataCtnt, taxpfTgmDataCtnt.length(), " ");
//                            logger.debug("taxpfTgmDataCtnt[{}]", taxpfTgmDataCtnt);
                            
                            //전송방법수정
                            taxpfTgmDataCtnt = dataCtnt;

                            request = this.toOMMFld(request.getClass(), taxpfTgmDataCtnt, null);
                            logger.debug("11 IO [{}]", new Object[] { request });

                            request.setTgmKndCd("0500");
                            request.setTrnsDtm(prcsDtm); 		// 전문전송일시

                            request.setMgntTgmCd(taxpfTgmNo);
//                            request.setAssoRspCd("000");
                            request.setSndInstCd("L51"); 										// 송신기관코드
                            request.setRcvInstCd("L00"); 										// 수신기관코드

                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026)
                            // INSERT
                            // 하기 위한 작업

                            logger.debug("송신전문request IO [{}]", new Object[] { request });
                            // ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
                            //TODO:2016.07.05;대외계 호출 주석처리 추후 변경
                            //======================================
                            response = InfUtil.callFEP(request, interfaceId, COM_F_KLIOSKOTS00008In.class);
//                            // 수신 결과
                            responseData = response.getResponseData();
                            taxpfRcd = responseData.getAssoRspCd(); 										// 세금우대결과코드 - 응답코드
                          //======================================
//                            taxpfRcd = "888";
                        } else if ("0600".equals(out.getTaxpfTgmKcd()) && "210".equals(out.getTaxpfBzDcd())) {
                            String interfaceId = "COM_F_KLIOSKOTS00010";						// EAI Interface ID
                            EISResponse<COM_F_KLIOSKOTS00010In> response = null;	// 세금우대한도조회 OMM
                            COM_F_KLIOSKOTS00010In responseData = null;				// 세금우대한도조회 OMM

                            COM_F_KLIOSKOTS00010In request = new COM_F_KLIOSKOTS00010In(); // 은행연합회 신용공여거래기업체
                                                                                                // 집중오류내역통보
                            logger.debug("dataCtnt [{}]", dataCtnt);

//                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request, "MS949"), "MS949");
//                            taxpfTgmDataCtnt = StringUtils.rpad(dataCtnt, taxpfTgmDataCtnt.length(), " ");
                            
                            //전송방법수정
                            taxpfTgmDataCtnt = dataCtnt;
                            
                            logger.debug("taxpfTgmDataCtnt[{}]", taxpfTgmDataCtnt);
                            // 수신(기등록오류) omm
                            request = this.toOMMFld(request.getClass(), taxpfTgmDataCtnt, null);
                                                        
                            logger.debug("11 IO [{}]", new Object[] { request });

                            request.setTgmKndCd("0600");
                            request.setTrnsDtm(prcsDtm); 		// 전문전송일시

                            request.setMgntTgmCd(taxpfTgmNo);
//                            request.setAssoRspCd("000");
                            request.setSndInstCd("L51"); 										// 송신기관코드
                            request.setRcvInstCd("L00"); 										// 수신기관코드

                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026)
                            // INSERT
                            // 하기 위한 작업

                            logger.debug("송신전문request IO [{}]", new Object[] { request });
                            // ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
                            //TODO:2016.07.05;대외계 호출 주석처리 추후 변경
                            //======================================
                            response = InfUtil.callFEP(request, interfaceId, COM_F_KLIOSKOTS00010In.class);
//                            // 수신 결과
                            responseData = response.getResponseData();
                            taxpfRcd = responseData.getAssoRspCd(); 										// 세금우대결과코드 - 응답코드
                          //======================================
//                            taxpfRcd = "888";
                        } else if ("0600".equals(out.getTaxpfTgmKcd()) && "230".equals(out.getTaxpfBzDcd())) {
                            String interfaceId = "COM_F_KLIOSKOTS00011";						// EAI Interface ID
                            EISResponse<COM_F_KLIOSKOTS00011In> response = null;	// 세금우대한도조회 OMM
                            COM_F_KLIOSKOTS00011In responseData = null;				// 세금우대한도조회 OMM

                            COM_F_KLIOSKOTS00011In request = new COM_F_KLIOSKOTS00011In(); // 은행연합회 신용공여거래기업체
                                                                                                // 집중오류내역통보
                                                                                                // 수신(기등록오류) omm

                            logger.debug("dataCtnt [{}]", dataCtnt);
//                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request, "MS949"), "MS949");
//                            taxpfTgmDataCtnt = StringUtils.rpad(dataCtnt, taxpfTgmDataCtnt.length(), " ");
//                            logger.debug("taxpfTgmDataCtnt[{}]", taxpfTgmDataCtnt);
                            
                            //전송방법수정
                            taxpfTgmDataCtnt = dataCtnt;

                            request = this.toOMMFld(request.getClass(), taxpfTgmDataCtnt, null);
                            logger.debug("11 IO [{}]", new Object[] { request });

                            request.setTgmKndCd("0600");
                            request.setTrnsDtm(prcsDtm); 		// 전문전송일시

                            request.setMgntTgmCd(taxpfTgmNo);
//                            request.setAssoRspCd("000");
                            request.setSndInstCd("L51"); 										// 송신기관코드
                            request.setRcvInstCd("L00"); 										// 수신기관코드

                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request));			// 요청전문내용을 세금우대처리로그(TBCNETC026)
                            // INSERT
                            // 하기 위한 작업

                            logger.debug("송신전문request IO [{}]", new Object[] { request });
                            // ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //
                            //TODO:2016.07.05;대외계 호출 주석처리 추후 변경
                            //======================================
                            response = InfUtil.callFEP(request, interfaceId, COM_F_KLIOSKOTS00011In.class);
//                            // 수신 결과
                            responseData = response.getResponseData();
                            taxpfRcd = responseData.getAssoRspCd(); 										// 세금우대결과코드 - 응답코드
                            //======================================
//                            taxpfRcd = "888";
                        } else if ("0600".equals(out.getTaxpfTgmKcd()) && "260".equals(out.getTaxpfBzDcd())) {
                            String interfaceId = "COM_F_KLIOSKOTS00009";						// EAI Interface ID
                            EISResponse<COM_F_KLIOSKOTS00009In> response = null;	// 세금우대한도조회 OMM
                            COM_F_KLIOSKOTS00009In responseData = null;				// 세금우대한도조회 OMM

                            COM_F_KLIOSKOTS00009In request = new COM_F_KLIOSKOTS00009In(); // 은행연합회 신용공여거래기업체
                                                                                                // 집중오류내역통보
                                                                                                // 수신(기등록오류) omm
                            logger.debug("dataCtnt [{}]", dataCtnt);
//                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request, "MS949"), "MS949");
//                            taxpfTgmDataCtnt = StringUtils.rpad(dataCtnt, taxpfTgmDataCtnt.length(), " ");
//                            logger.debug("taxpfTgmDataCtnt[{}]", taxpfTgmDataCtnt);
                            
                            //전송방법수정
                            taxpfTgmDataCtnt = dataCtnt;

                            request = this.toOMMFld(request.getClass(), taxpfTgmDataCtnt, null);
                            logger.debug("11 IO [{}]", new Object[] { request });

                            request.setTgmKndCd("0600");
                            request.setTrnsDtm(prcsDtm); 		// 전문전송일시

                            request.setMgntTgmCd(taxpfTgmNo);
//                            request.setAssoRspCd("000");
                            request.setSndInstCd("L51"); 										// 송신기관코드
                            request.setRcvInstCd("L00"); 										// 수신기관코드

                            taxpfTgmDataCtnt = new String(FwUtil.toBytes(request));
                            // 요청전문내용을 세금우대처리로그(TBCNETC026)INSERT 하기 위한 작업

                            logger.debug("송신전문request IO [{}]", new Object[] { request });
                            // ------------- 대외계 인터페이스 호출(SYNC 방식) START ------ //

                            response = InfUtil.callFEP(request, interfaceId, COM_F_KLIOSKOTS00009In.class);
                            // 수신 결과
                            responseData = response.getResponseData();
                            taxpfRcd = responseData.getAssoRspCd(); 										// 세금우대결과코드 - 응답코드

                            
                        }
                        logger.debug("rtnCnt:{}", rtnCnt);
                        prcsYn = "Y";											// 처리여부
                        rtnCnt++;

                    } catch (EisExecutionException e) {
                        // ------------- 세금우대처리로그 UPDATE START ---------------- //
                        logger.debug("EisExecutionException IO ");
                        logger.error(e.getMessage());
                        prcsYn = "N";											// 처리여부
                        taxpfRcd = "888"; 										// 세금우대결과코드 - 응답코드
                    } catch (NotSupportedEISException e) {
                        logger.debug("EisExecutionException IO ");
                        logger.error(e.getMessage());
                        // ------------- 세금우대처리로그 UPDATE START ---------------- //
                        prcsYn = "N";											// 처리여부
                        taxpfRcd = "888"; 										// 세금우대결과코드 - 응답코드
                    } 
//                    catch (UnsupportedEncodingException e1) {
//                        // TODO Auto-generated catch block
//                    }

                    cigna.cm.t.io.TBCNETC026Io iTbcnetc026io = new cigna.cm.t.io.TBCNETC026Io();
                    iTbcnetc026io.setPrcsDtm(prcsDtm);// set [처리일시]
                    iTbcnetc026io.setTaxpfTgmNo(taxpfTgmNo);// set [세금우대전문번호]
                    iTbcnetc026io.setPrcsDt(DateUtils.getCurrentDate(2));// set [처리일자]
                    iTbcnetc026io.setDpsTxNo(out.getDpsTxNo());// set [입금거래번호]
                    iTbcnetc026io.setPrcsDofOrgNo(out.getPrcsDofOrgNo());// set [처리지점조직번호]
                    iTbcnetc026io.setPrcsFofOrgNo(out.getPrcsFofOrgNo());// set [처리영업소조직번호]
                    iTbcnetc026io.setPrcsEno(out.getPrcsEno());// set [처리사원번호]
                    iTbcnetc026io.setContNo(out.getContNo());// set [계약번호]
                    iTbcnetc026io.setSavgPrdcd(out.getSavgPrdcd());// set [저축상품코드]
                    iTbcnetc026io.setPrcsYn(prcsYn);// set [처리여부]
                    iTbcnetc026io.setTaxpfRcd(taxpfRcd);// set [세금우대결과코드]
                    iTbcnetc026io.setTaxpfTgmKcd(out.getTaxpfTgmKcd());// set [세금우대전문종류코드]
                    iTbcnetc026io.setTaxpfBzDcd(out.getTaxpfBzDcd());// set [세금우대업무구분코드]
                    iTbcnetc026io.setTaxpfBzPrcsDcd(out.getTaxpfBzPrcsDcd());// set [세금우대업무처리구분코드]
                    iTbcnetc026io.setNrmCnclDcd(out.getNrmCnclDcd());// set [정상취소구분코드]
                    iTbcnetc026io.setTaxpfTgmDataCtnt(taxpfTgmDataCtnt); // set [세금우대전문데이터내용]

                    cmt005bean.insertTaxpfLog(iTbcnetc026io);

                    // 재전송
                }
            }
        }

        return rtnCnt;
    }

    /**
     * string 내용을 OMM 객체로 변환한다.
     *
     * <pre>
     * String data;
     * ...
     * MyOMM omm = this.toOMM(MyOMM.class, data);
     * ...
     * </pre>
     *
     * @param type OMM type의 Class class
     * @param csvData CSV형태의 데이터
     * @return OMM객체
     */
    public <T extends IOmmObject> T toOMMFld(Class<T> type, String inputData, String encoding) {
        byte[] data;

        try {
            if (inputData == null) {
                return null;
            }
            if (encoding == null)
                data = inputData.getBytes();
            else
                data = inputData.getBytes(encoding);

            IKLafMarshaller marshaller = null;
            if ((marshaller = ApplicationContextTrace.getCurrentApplication().getMarshaller(Marshaller.OMM_FLD)) == null) {
                marshaller = KLafMarshallerFactory.newInstance().getMarshaller(Marshaller.OMM_FLD);
                ApplicationContextTrace.getCurrentApplication().setMarshaller(Marshaller.OMM_FLD, marshaller);
            }

            if (encoding == null)
                return marshaller.unmarshal(type, data);
            else
                return marshaller.unmarshal(type, data, encoding);
        } catch (Exception e) {
            logger.error("error: {}", e);
            return null;
        }
    }
}
