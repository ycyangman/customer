package cigna.cm.t.bean;

import cigna.cm.t.dbio.CMT011DBIO;
import cigna.cm.t.io.CMT020SVC02Out;
import cigna.cm.t.io.OSKLIALITB000000000000In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00007In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00008In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00010In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00011In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00009In;
import cigna.zz.SecuUtil;
import cigna.zz.SecuUtil.EncType;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.t.bean.CMT021BEAN.java
 * @filetype     java source file
 * @brief		 로그상세조회화면 BEAN * 
 * @author       김위현
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김위현 			    2013. 7. 24.       신규 작성
 *
 */
@KlafBean
public class CMT021BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/******************************
	 * 세금우대로그조회 DBIO
	 ******************************/
	@Autowired
    CMT011DBIO cmt011dbio;
	
	
	/**
	 * 세금우대로그상세조회
	 * 
	 * @param  prcsDtm    처리일시
	 *  	   taxpfTgmNo 전문번호
	 *  	   dvsn       팝업화면구분
	 * @return CMT020SVC02Out 
	 * @throws ApplicationException
	 */
	public CMT020SVC02Out getLogDtls(String prcsDtm, String taxpfTgmNo, String dvsn) throws ApplicationException {
		
		CMT020SVC02Out output = new CMT020SVC02Out();
				
		String dataCtnt = null;


		if (StringUtils.isEmpty(prcsDtm)) {
			logger.error("처리일자가 없습니다.");
			throw new ApplicationException("APNBE0000", new String[] { "처리일자" });
		}

		if (StringUtils.isEmpty(taxpfTgmNo)) {
			logger.error("세금우대전문번호가 없습니다.");
			throw new ApplicationException("APNBE0000", new String[] { "세금우대전문번호" });
		}

		dataCtnt = cmt011dbio.selectMultiTBCNETC026b(prcsDtm, taxpfTgmNo);
		
		if(dataCtnt == null){
			
			output.setResultCnt(0);
			
		}
		else{

			/******************************
			 * 전문공통정보부 데이터 세팅
			 ******************************/
			
            if(dataCtnt != null) {
            	dataCtnt = SecuUtil.getDecValue(dataCtnt, EncType.Etc);
            }
			
			OSKLIALITB000000000000In taxpfCommonOut = new OSKLIALITB000000000000In();
			
			taxpfCommonOut.setTrCd       (dataCtnt.substring(0,  9));//transactioncode 
			taxpfCommonOut.setSysId	     (dataCtnt.substring(9, 11));//SYSTEM_ID		   
			taxpfCommonOut.setTgmKndCd	 (dataCtnt.substring(11,15));//전문종별코드    
			taxpfCommonOut.setAssoBusiGb (dataCtnt.substring(15,18));//협회업무구분    
			taxpfCommonOut.setTrnsDtm	 (dataCtnt.substring(18,32));//전문전송일시    
			taxpfCommonOut.setMgntTgmCd	 (dataCtnt.substring(32,39));//전문관리번호    
			taxpfCommonOut.setSndInstCd	 (dataCtnt.substring(39,42));//전송기관코드    
			taxpfCommonOut.setRcvInstCd	 (dataCtnt.substring(42,45));//수신기관코드    
			taxpfCommonOut.setAssoTrnsGb (dataCtnt.substring(45,51));//협회거래구분    
			taxpfCommonOut.setDataLen	 (dataCtnt.substring(51,55));//data 정보부	   
			taxpfCommonOut.setTerId	     (dataCtnt.substring(55,65));//단말기ID	       
			taxpfCommonOut.setTerOpId	 (dataCtnt.substring(65,75));//단말기조작자ID
			
			//단말기조작자성명 한글이름바이트수 조정
			int terNmByte = calKorByte(dataCtnt, 20, 75);
			taxpfCommonOut.setTerOwnNm	 (dataCtnt.substring(75,75+terNmByte));//단말기조작자성명			
			taxpfCommonOut.setAssoRspCd	 (dataCtnt.substring(75+terNmByte,75+terNmByte+3));//협회응답코드    
			taxpfCommonOut.setDataEtc	 (dataCtnt.substring(75+terNmByte+3,75+terNmByte+15));//예비필드       
			                                                                           
			                                                                           
			logger.debug("transactioncode {}",  dataCtnt.substring(0,  9));            
			logger.debug("SYSTEM_ID		  {}",  dataCtnt.substring(9, 11));            
			logger.debug("전문종별코드    {}",  dataCtnt.substring(11,15));            
			logger.debug("협회업무구분    {}",  dataCtnt.substring(15,18));            
			logger.debug("전문전송일시    {}",  dataCtnt.substring(18,32));            
			logger.debug("전문관리번호    {}",  dataCtnt.substring(32,39));            
			logger.debug("전송기관코드    {}",  dataCtnt.substring(39,42));            
			logger.debug("수신기관코드    {}",  dataCtnt.substring(42,45));            
			logger.debug("협회거래구분    {}",  dataCtnt.substring(45,51));            
			logger.debug("data 정보부	  {}",  dataCtnt.substring(51,55));            
			logger.debug("단말기ID	      {}",  dataCtnt.substring(55,65));            
			logger.debug("단말기조작자ID  {}",  dataCtnt.substring(65,75));            
			logger.debug("단말기조작자성명{}",  dataCtnt.substring(75,75+terNmByte));            
			logger.debug("협회응답코드    {}",  dataCtnt.substring(75+terNmByte,75+terNmByte+3));            
			logger.debug("예비필드       {}",  dataCtnt.substring(75+terNmByte+3,75+terNmByte+15));
			
			output.setTaxpfCommon(taxpfCommonOut);

			
			
			
			//데이터부분시작인덱스
			int scndIndex = 90+terNmByte;

			/*************************************
			 * 세금우대등록일경우 ( 0400 - 210 )
			 *************************************/			
			if("1".equals(dvsn)){
				
				COM_F_KLIOSKOTS00007In taxpfRegOut = new COM_F_KLIOSKOTS00007In();
				
				taxpfRegOut.setRrno	              (dataCtnt.substring(scndIndex,    scndIndex+13));//주민등록번호	13	0									
				taxpfRegOut.setRrnoDvsn	          (dataCtnt.substring(scndIndex+13, scndIndex+14));//주민등록번호구분	1	0
				
				//기업체명 한글이름바이트수 조정
				int corpNmByte = calKorByte(dataCtnt, 40, scndIndex+14);
				taxpfRegOut.setConm	              (dataCtnt.substring(scndIndex+14, scndIndex+14+corpNmByte));//상호(기업체명)	40	0
				//대표자명 한글이름바이트수 조정
				int nameByte = calKorByte(dataCtnt, 20, scndIndex+14+corpNmByte);
				taxpfRegOut.setName	              (dataCtnt.substring(scndIndex+14+corpNmByte,  scndIndex+14+corpNmByte+nameByte             ));                   //성명(대표자)	20	0	
				taxpfRegOut.setInfoMnbdyDvsn	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte    ,scndIndex+14+corpNmByte+nameByte+1));      //정보주체(구장애인)구분	1	0					
				taxpfRegOut.setIncmrDvsn	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+1  ,scndIndex+14+corpNmByte+nameByte+2));      //저소득자구분(농어가저축)	1	0				
				taxpfRegOut.setSavgKnd	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+2  ,scndIndex+14+corpNmByte+nameByte+4));      //저축종류	2	0									      
				taxpfRegOut.setOpenOffcCd	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+4  ,scndIndex+14+corpNmByte+nameByte+11));     //개설점포코드	7	0									  
				taxpfRegOut.setActNo	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+11 ,scndIndex+14+corpNmByte+nameByte+27));     //계좌번호	16	0									    
				taxpfRegOut.setActOpenDy	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+27 ,scndIndex+14+corpNmByte+nameByte+35));     //계좌개설일	8	0									    
				taxpfRegOut.setTaxpfAmt	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+35 ,scndIndex+14+corpNmByte+nameByte+45));     //세금우대금액(단위:원)	10	0				  
				taxpfRegOut.setExpiDy	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+45 ,scndIndex+14+corpNmByte+nameByte+53));     //만기일	8	0									        
				taxpfRegOut.setInhrtYn	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+53 ,scndIndex+14+corpNmByte+nameByte+54));     //상속여부	1	0									      
				taxpfRegOut.setHousPrpsDvsn       (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+54 ,scndIndex+14+corpNmByte+nameByte+55));     //주택청약예부금구분	1	0							
				taxpfRegOut.setRrnoErr	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+55 ,scndIndex+14+corpNmByte+nameByte+56));     //주민등록번호error	1	0							  
				taxpfRegOut.setRrnoDvsnErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+56 ,scndIndex+14+corpNmByte+nameByte+57));     //주민등록번호구분error	1	0					  
				taxpfRegOut.setConmErr	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+57 ,scndIndex+14+corpNmByte+nameByte+58));     //상호error	1	0									      
				taxpfRegOut.setNameErr	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+58 ,scndIndex+14+corpNmByte+nameByte+59));     //성명error	1	0									      
				taxpfRegOut.setInfoMnbdyDvsnErr   (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+59 ,scndIndex+14+corpNmByte+nameByte+60));     //정보주체(구장애인)구분error	1	0		  
				taxpfRegOut.setIncmrDvsnErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+60 ,scndIndex+14+corpNmByte+nameByte+61));     //저소득자구분error	1	0							  
				taxpfRegOut.setSavgKndErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+61 ,scndIndex+14+corpNmByte+nameByte+62));     //저축종류error	1	0									  
				taxpfRegOut.setOpenOffcCdErr	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+62 ,scndIndex+14+corpNmByte+nameByte+63));     //개설점포코드error	1	0							  
				taxpfRegOut.setActNoErr	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+63 ,scndIndex+14+corpNmByte+nameByte+64));     //계좌번호error	1	0									  
				taxpfRegOut.setActOpenDyErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+64 ,scndIndex+14+corpNmByte+nameByte+65));     //계좌개설일error	1	0								  
				taxpfRegOut.setTaxpfAmtErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+65 ,scndIndex+14+corpNmByte+nameByte+66));     //세금우대금액error	1	0							  
				taxpfRegOut.setExpiDyErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+66 ,scndIndex+14+corpNmByte+nameByte+67));     //만기일error	1	0									    
				taxpfRegOut.setInhrtYnErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+67 ,scndIndex+14+corpNmByte+nameByte+68));     //상속여부error	1	0									  
				taxpfRegOut.setHousPrpsDvsnErr	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+68 ,scndIndex+14+corpNmByte+nameByte+69));     //주택청약예부금구분error	1	0				  

				
				logger.debug("주민등록번호		         ({})",  dataCtnt.substring(scndIndex,    scndIndex+13                                              ));
				logger.debug("주민등록번호구분           ({})",	 dataCtnt.substring(scndIndex+13, scndIndex+14                                              ));
				logger.debug("상호(기업체명)             ({})",  dataCtnt.substring(scndIndex+14, scndIndex+14+corpNmByte                                   ));
				logger.debug("이름                       ({})",  dataCtnt.substring(scndIndex+14+corpNmByte,  scndIndex+14+corpNmByte+nameByte              ));
				logger.debug("정보주체(구장애인)구분	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte    ,scndIndex+14+corpNmByte+nameByte+1 ));
				logger.debug("저소득자구분(농어가저축)	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+1  ,scndIndex+14+corpNmByte+nameByte+2 ));
				logger.debug("저축종류	   				 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+2  ,scndIndex+14+corpNmByte+nameByte+4 ));
				logger.debug("개설점포코드	  			 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+4  ,scndIndex+14+corpNmByte+nameByte+11));
				logger.debug("계좌번호	    			 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+11 ,scndIndex+14+corpNmByte+nameByte+27));
				logger.debug("계좌개설일	  			 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+27 ,scndIndex+14+corpNmByte+nameByte+35));
				logger.debug("세금우대금액(단위:원)	  	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+35 ,scndIndex+14+corpNmByte+nameByte+45));
				logger.debug("만기일	8	0			 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+45 ,scndIndex+14+corpNmByte+nameByte+53));
				logger.debug("상속여부	1	0			 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+53 ,scndIndex+14+corpNmByte+nameByte+54));
				logger.debug("주택청약예부금구분	1	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+54 ,scndIndex+14+corpNmByte+nameByte+55));
				logger.debug("주민등록번호error	1	0	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+55 ,scndIndex+14+corpNmByte+nameByte+56));
				logger.debug("주민등록번호구분error	1	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+56 ,scndIndex+14+corpNmByte+nameByte+57));
				logger.debug("상호error	1	0			 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+57 ,scndIndex+14+corpNmByte+nameByte+58));
				logger.debug("성명error	1	0			 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+58 ,scndIndex+14+corpNmByte+nameByte+59));
				logger.debug("정보주체(구장애인)구분erro ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+59 ,scndIndex+14+corpNmByte+nameByte+60));
				logger.debug("저소득자구분error	1	0	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+60 ,scndIndex+14+corpNmByte+nameByte+61));
				logger.debug("저축종류error	1	0		 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+61 ,scndIndex+14+corpNmByte+nameByte+62));
				logger.debug("개설점포코드error	1	0	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+62 ,scndIndex+14+corpNmByte+nameByte+63));
				logger.debug("계좌번호error	1	0		 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+63 ,scndIndex+14+corpNmByte+nameByte+64));
				logger.debug("계좌개설일error	1	0	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+64 ,scndIndex+14+corpNmByte+nameByte+65));
				logger.debug("세금우대금액error	1	0	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+65 ,scndIndex+14+corpNmByte+nameByte+66));
				logger.debug("만기일error	1	0		 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+66 ,scndIndex+14+corpNmByte+nameByte+67));
				logger.debug("상속여부error	1	0		 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+67 ,scndIndex+14+corpNmByte+nameByte+68));
				logger.debug("주택청약예부금구분error	 ({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+68 ,scndIndex+14+corpNmByte+nameByte+69));


				output.setTaxpfReg(taxpfRegOut);


			}
			/*************************************
			 * 세금우대해지일경우 ( 0500 - 210 )
			 *************************************/
			else if("2".equals(dvsn)){
				
				COM_F_KLIOSKOTS00008In taxpfRescsOut = new COM_F_KLIOSKOTS00008In();
				
				taxpfRescsOut.setRrno	          (dataCtnt.substring(scndIndex,    scndIndex+13));//주민등록번호	13	0									                                                    
				taxpfRescsOut.setRrnoDvsn	      (dataCtnt.substring(scndIndex+13, scndIndex+14));//주민등록번호구분	1	0  
				//기업체명 한글이름바이트수 조정
				int corpNmByte = calKorByte(dataCtnt, 40, scndIndex+14);
				taxpfRescsOut.setConm	          (dataCtnt.substring(scndIndex+14, scndIndex+14+corpNmByte));//상호(기업체명)	40	0
				//대표자명 한글이름바이트수 조정
				int nameByte = calKorByte(dataCtnt, 20, scndIndex+14+corpNmByte);									
				taxpfRescsOut.setName	          (dataCtnt.substring(scndIndex+14+corpNmByte,  scndIndex+14+corpNmByte+nameByte              ));        //성명(대표자)	20	0
				
				logger.debug("scndIndex {}", scndIndex);
				logger.debug("namebyte {}, corpbyte {}", nameByte,corpNmByte);
				
				logger.debug("17자르기 {}", dataCtnt.substring(110+14+40, 110+14+40+17));
				logger.debug("20자르기 {}", dataCtnt.substring(110+14+40, 110+14+40+20));
				logger.debug("14자르기 {}", dataCtnt.substring(110+14+40, 110+14+40+14));
				
				logger.debug("주민등록번호	13	0			({})", 	dataCtnt.substring(scndIndex,    scndIndex+13)                                              );
				logger.debug("주민등록번호구분	1	0       ({})",  dataCtnt.substring(scndIndex+13, scndIndex+14)                                              );
				logger.debug("상호(기업체명)	40	0		({})",  dataCtnt.substring(scndIndex+14, scndIndex+14+corpNmByte)                                   );
				logger.debug("성명(대표자)	20	0			({})",  dataCtnt.substring(scndIndex+14+corpNmByte,  scndIndex+14+corpNmByte+nameByte)              );
				taxpfRescsOut.setRescsKnd	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte   , scndIndex+14+corpNmByte+nameByte+2 ));        //해지종류	2	0									  
				taxpfRescsOut.setSavgKnd	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+2 , scndIndex+14+corpNmByte+nameByte+4 ));        //저축종류	2	0									  
				taxpfRescsOut.setOpenOffcCd	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+4 , scndIndex+14+corpNmByte+nameByte+11));        //개설점포코드	7	0							  
				taxpfRescsOut.setActNo	          (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+11, scndIndex+14+corpNmByte+nameByte+27));        //계좌번호	16	0								  
				taxpfRescsOut.setActRescsDy	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+27, scndIndex+14+corpNmByte+nameByte+35));        //계좌해지일	8	0								  
				taxpfRescsOut.setTaxpfAmt	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+35, scndIndex+14+corpNmByte+nameByte+45));        //세금우대금액(단위:원)	10	0		
				taxpfRescsOut.setIntDivdAmt	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+45, scndIndex+14+corpNmByte+nameByte+55));        //이자배당지급액(단위:원)	10	0	
				taxpfRescsOut.setRrnoErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+55, scndIndex+14+corpNmByte+nameByte+56));        //주민등록번호error	1	0					
				taxpfRescsOut.setRrnoDvsnErr	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+56, scndIndex+14+corpNmByte+nameByte+57));        //주민등록번호구분error	1	0			
				taxpfRescsOut.setConmErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+57, scndIndex+14+corpNmByte+nameByte+58));        //상호error	1	0									
				taxpfRescsOut.setNameErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+58, scndIndex+14+corpNmByte+nameByte+59));        //성명error	1	0									
				taxpfRescsOut.setRescsKndErr	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+59, scndIndex+14+corpNmByte+nameByte+60));        //해지종류error	1	0							
				taxpfRescsOut.setSavgKndErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+60, scndIndex+14+corpNmByte+nameByte+61));        //저축종류error	1	0							
				taxpfRescsOut.setOpenOffcCdErr	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+61, scndIndex+14+corpNmByte+nameByte+62));        //개설점포코드error	1	0					
				taxpfRescsOut.setActNoErr	      (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+62, scndIndex+14+corpNmByte+nameByte+63));        //계좌번호error	1	0							
				taxpfRescsOut.setActRescsDyErr	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+63, scndIndex+14+corpNmByte+nameByte+64));        //계좌해지일error	1	0						
				taxpfRescsOut.setTaxpfAmtErr	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+64, scndIndex+14+corpNmByte+nameByte+65));        //세금우대금액error	1	0					
				taxpfRescsOut.setIntDivdAmtErr	  (dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+65, scndIndex+14+corpNmByte+nameByte+66));        //이자배당지급액error	1	0				


				
				logger.debug("해지종류	2	0				({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte   , scndIndex+14+corpNmByte+nameByte+2 ));
				logger.debug("저축종류	2	0				({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+2 , scndIndex+14+corpNmByte+nameByte+4 ));
				logger.debug("개설점포코드	7	0			({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+4 , scndIndex+14+corpNmByte+nameByte+11));
				logger.debug("계좌번호	16	0				({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+11, scndIndex+14+corpNmByte+nameByte+27));
				logger.debug("계좌해지일	8	0			({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+27, scndIndex+14+corpNmByte+nameByte+35));
				logger.debug("세금우대금액(단위:원)	10	0	({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+35, scndIndex+14+corpNmByte+nameByte+45));
				logger.debug("이자배당지급액(단위:원)	10	({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+45, scndIndex+14+corpNmByte+nameByte+55));
				logger.debug("주민등록번호error	1	0		({})",  dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+55, scndIndex+14+corpNmByte+nameByte+56));
				logger.debug("주민등록번호구분error	1	0	({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+56, scndIndex+14+corpNmByte+nameByte+57));
				logger.debug("상호error	1	0				({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+57, scndIndex+14+corpNmByte+nameByte+58));
				logger.debug("성명error	1	0				({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+58, scndIndex+14+corpNmByte+nameByte+59));
				logger.debug("해지종류error	1	0			({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+59, scndIndex+14+corpNmByte+nameByte+60));
				logger.debug("저축종류error	1	0			({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+60, scndIndex+14+corpNmByte+nameByte+61));
				logger.debug("개설점포코드error	1	0		({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+61, scndIndex+14+corpNmByte+nameByte+62));
				logger.debug("계좌번호error	1	0			({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+62, scndIndex+14+corpNmByte+nameByte+63));
				logger.debug("계좌해지일error	1	0		({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+63, scndIndex+14+corpNmByte+nameByte+64));
				logger.debug("세금우대금액error	1	0		({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+64, scndIndex+14+corpNmByte+nameByte+65));
				logger.debug("이자배당지급액error	1	0	({})", 	dataCtnt.substring(scndIndex+14+corpNmByte+nameByte+65, scndIndex+14+corpNmByte+nameByte+66));

				
				output.setTaxpfRescs(taxpfRescsOut);
				

			}
			/*************************************
			 * 세금우대정정일경우 ( 0600 - 210 )
			 *************************************/
			else if("3".equals(dvsn)){

				COM_F_KLIOSKOTS00010In taxpfCorrcOut = new COM_F_KLIOSKOTS00010In();
				
								
				
				taxpfCorrcOut.setAfchRrno	            (dataCtnt.substring(scndIndex,    scndIndex+13)); //변경후주민등록번호	13	0					                                                     						                                                            
				taxpfCorrcOut.setAfchRrnoDvsn	        (dataCtnt.substring(scndIndex+13, scndIndex+14)); //변경후주민등록번호구분	1	0				                                                                                                                     
				taxpfCorrcOut.setBfchRrno	            (dataCtnt.substring(scndIndex+14, scndIndex+27)); //변경전주민등록번호	13	0					
				taxpfCorrcOut.setBfchRrnoDvsn	        (dataCtnt.substring(scndIndex+27, scndIndex+28)); //변경전주민등록번호구분	1	0
				//기업체명 한글이름바이트수 조정
				int corpNmByte = calKorByte(dataCtnt, 40, scndIndex+28);
				taxpfCorrcOut.setAfchConm	            (dataCtnt.substring(scndIndex+28, scndIndex+28+corpNmByte));//상호(기업체명)	40	0
				//대표자명 한글이름바이트수 조정
				int nameByte = calKorByte(dataCtnt, 20, scndIndex+28+corpNmByte);									
				taxpfCorrcOut.setAfchName	            (dataCtnt.substring(scndIndex+28+corpNmByte,  scndIndex+28+corpNmByte+nameByte  ));        //성명(대표자)	20	0
				
				
				logger.debug("변경후주민등록번호	13	0					({})", 	dataCtnt.substring(scndIndex,    scndIndex+13));                                
				logger.debug("변경후주민등록번호구분	1	0		{})",  dataCtnt.substring(scndIndex+13, scndIndex+14));                                
				logger.debug("변경전주민등록번호	13	0			({})",  dataCtnt.substring(scndIndex+14, scndIndex+27));                                
				logger.debug("변경전주민등록번호구분	1	0		({})",  dataCtnt.substring(scndIndex+27, scndIndex+28));                                
				logger.debug("변경후상호(기업체명)	40	0		    ({})",  dataCtnt.substring(scndIndex+28, scndIndex+28+corpNmByte));                     
				logger.debug("변경후성명(대표자)	20	0			({})",  dataCtnt.substring(scndIndex+28+corpNmByte,  scndIndex+28+corpNmByte+nameByte)); 
		        logger.debug("변경후정보주체(구장애인)구분	1	0	({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte     , scndIndex+28+corpNmByte+nameByte+1  ));        
				logger.debug("변경후저소득자구분(농어가저축)	1	({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+1   , scndIndex+28+corpNmByte+nameByte+2  ));        
				logger.debug("변경전저축종류	2	0				        ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+2   , scndIndex+28+corpNmByte+nameByte+4  ));        
				logger.debug("변경전개설점포코드	7	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+4   , scndIndex+28+corpNmByte+nameByte+11 ));        
				logger.debug("변경전계좌번호	16	0				      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+11  , scndIndex+28+corpNmByte+nameByte+27 ));        
				logger.debug("변경후저축종류	2	0				        ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+27  , scndIndex+28+corpNmByte+nameByte+29 ));        
				logger.debug("변경후개설점포코드	7	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+29  , scndIndex+28+corpNmByte+nameByte+36 ));        
				logger.debug("변경후계좌번호	16	0				      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+36  , scndIndex+28+corpNmByte+nameByte+52 ));        
				logger.debug("변경후계좌개설일	8	0				      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+52  , scndIndex+28+corpNmByte+nameByte+60 ));        
				logger.debug("변경후세금우대금액(단위:원)	10	0	({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+60  , scndIndex+28+corpNmByte+nameByte+70 ));        
				logger.debug("변경후만기일	8	0					        ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+70  , scndIndex+28+corpNmByte+nameByte+78 ));        
				logger.debug("변경후최초만기연장일	8	0			    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+78  , scndIndex+28+corpNmByte+nameByte+86 ));        
				logger.debug("변경후이자,배당지급액(단위:원)	10({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+86  , scndIndex+28+corpNmByte+nameByte+96 ));        
				logger.debug("변경후해지종류	2	0				        ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+96  , scndIndex+28+corpNmByte+nameByte+98 ));        
				logger.debug("변경후상속여부	1	0				        ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+98  , scndIndex+28+corpNmByte+nameByte+99 ));        
				logger.debug("변경후주택청약예부금구분	1	0		  ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+99  , scndIndex+28+corpNmByte+nameByte+100));        
				logger.debug("변경후주민등록번호Error	1	0		    ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+100 , scndIndex+28+corpNmByte+nameByte+101));        
				logger.debug("변경후주민등록번호구분Error	1	0	  ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+101 , scndIndex+28+corpNmByte+nameByte+102));        
				logger.debug("변경전주민등록번호Error	1	0		    ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+102 , scndIndex+28+corpNmByte+nameByte+103));        
				logger.debug("변경전주민등록번호구분Error	1	0	  ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+103 , scndIndex+28+corpNmByte+nameByte+104));        
				logger.debug("변경후기업체명Error	1	0			      ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+104 , scndIndex+28+corpNmByte+nameByte+105));        
				logger.debug("변경후성명Error	1	0				        ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+105 , scndIndex+28+corpNmByte+nameByte+106));        
				logger.debug("변경후정보주체구분Error	1	0		    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+106 , scndIndex+28+corpNmByte+nameByte+107));        
				logger.debug("변경후저소득자구분Error	1	0		    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+107 , scndIndex+28+corpNmByte+nameByte+108));        
				logger.debug("변경전저축종류Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+108 , scndIndex+28+corpNmByte+nameByte+109));        
				logger.debug("변경전점포코드Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+109 , scndIndex+28+corpNmByte+nameByte+110));        
				logger.debug("변경전계좌번호Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+110 , scndIndex+28+corpNmByte+nameByte+111));        
				logger.debug("변경후저축종류Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+111 , scndIndex+28+corpNmByte+nameByte+112));        
				logger.debug("변경후점포코드Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+112 , scndIndex+28+corpNmByte+nameByte+113));        
				logger.debug("변경후계좌번호Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+113 , scndIndex+28+corpNmByte+nameByte+114));        
				logger.debug("변경후계좌개설일Error	1	0			    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+114 , scndIndex+28+corpNmByte+nameByte+115));        
				logger.debug("변경후세금우대금액Error	1	0		    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+115 , scndIndex+28+corpNmByte+nameByte+116));        
				logger.debug("변경후만기일Error	1	0				      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+116 , scndIndex+28+corpNmByte+nameByte+117));        
				logger.debug("변경후최초만기연장일Error	1	0		  ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+117 , scndIndex+28+corpNmByte+nameByte+118));        
				logger.debug("변경후이자,배당지급액Error	1	0	  ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+118 , scndIndex+28+corpNmByte+nameByte+119));        
				logger.debug("변경후해지종류Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+119 , scndIndex+28+corpNmByte+nameByte+120));        
				logger.debug("변경후상속여부Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+120 , scndIndex+28+corpNmByte+nameByte+121));
				
				taxpfCorrcOut.setAfchInfoMnbdyDvsn     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte     , scndIndex+28+corpNmByte+nameByte+1  ));          //변경후정보주체(구장애인)구분	1	0	  
				taxpfCorrcOut.setAfchIncmrDvsn	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+1   , scndIndex+28+corpNmByte+nameByte+2  ));          //변경후저소득자구분(농어가저축)	1	  
				taxpfCorrcOut.setBfchSavgKnd	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+2   , scndIndex+28+corpNmByte+nameByte+4  ));          //변경전저축종류	2	0								  
				taxpfCorrcOut.setBfchOpenOffcCd	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+4   , scndIndex+28+corpNmByte+nameByte+11 ));          //변경전개설점포코드	7	0						  
				taxpfCorrcOut.setBfchActNo	           (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+11  , scndIndex+28+corpNmByte+nameByte+27 ));          //변경전계좌번호	16	0							  
				taxpfCorrcOut.setAfchSavgKnd	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+27  , scndIndex+28+corpNmByte+nameByte+29 ));          //변경후저축종류	2	0								  
				taxpfCorrcOut.setAfchOpenOffcCd	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+29  , scndIndex+28+corpNmByte+nameByte+36 ));          //변경후개설점포코드	7	0						  
				taxpfCorrcOut.setAfchActNo	           (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+36  , scndIndex+28+corpNmByte+nameByte+52 ));          //변경후계좌번호	16	0							  
				taxpfCorrcOut.setAfchActOpenDy	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+52  , scndIndex+28+corpNmByte+nameByte+60 ));          //변경후계좌개설일	8	0							  
				taxpfCorrcOut.setAfchTaxpfAmt	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+60  , scndIndex+28+corpNmByte+nameByte+70 ));          //변경후세금우대금액(단위:원)	10	0	
				taxpfCorrcOut.setAfchExpiDy	           (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+70  , scndIndex+28+corpNmByte+nameByte+78 ));          //변경후만기일	8	0									  
				taxpfCorrcOut.setAfchFstExpiExtnDy     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+78  , scndIndex+28+corpNmByte+nameByte+86 ));          //변경후최초만기연장일	8	0					  
				taxpfCorrcOut.setAfchIntDivdAmt	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+86  , scndIndex+28+corpNmByte+nameByte+96 ));          //변경후이자,배당지급액(단위:원)	10  
				taxpfCorrcOut.setAfchRescsKnd	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+96  , scndIndex+28+corpNmByte+nameByte+98 ));          //변경후해지종류	2	0								  
				taxpfCorrcOut.setAfchInhrtYn	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+98  , scndIndex+28+corpNmByte+nameByte+99 ));          //변경후상속여부	1	0								  
				taxpfCorrcOut.setAfchHousPrpsDvsn	     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+99  , scndIndex+28+corpNmByte+nameByte+100));          //변경후주택청약예부금구분	1	0			  
				taxpfCorrcOut.setAfchRrnoErr	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+100 , scndIndex+28+corpNmByte+nameByte+101));          //변경후주민등록번호Error	1	0				
				taxpfCorrcOut.setAfchRrnoDvsnErr	     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+101 , scndIndex+28+corpNmByte+nameByte+102));          //변경후주민등록번호구분Error	1	0		
				taxpfCorrcOut.setBfchRrnoErr	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+102 , scndIndex+28+corpNmByte+nameByte+103));          //변경전주민등록번호Error	1	0				
				taxpfCorrcOut.setBfchRrnoDvsnErr	     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+103 , scndIndex+28+corpNmByte+nameByte+104));          //변경전주민등록번호구분Error	1	0		
				taxpfCorrcOut.setAfchConmErr	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+104 , scndIndex+28+corpNmByte+nameByte+105));          //변경후기업체명Error	1	0						
				taxpfCorrcOut.setAfchNameErr	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+105 , scndIndex+28+corpNmByte+nameByte+106));          //변경후성명Error	1	0								
				taxpfCorrcOut.setAfchInfoMnbdyDvsnErr  (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+106 , scndIndex+28+corpNmByte+nameByte+107));          //변경후정보주체구분Error	1	0				
				taxpfCorrcOut.setAfchIncmrDvsnErr	     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+107 , scndIndex+28+corpNmByte+nameByte+108));          //변경후저소득자구분Error	1	0				
				taxpfCorrcOut.setBfchSavgKndErr	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+108 , scndIndex+28+corpNmByte+nameByte+109));          //변경전저축종류Error	1	0						
				taxpfCorrcOut.setBfchOffcCdErr	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+109 , scndIndex+28+corpNmByte+nameByte+110));          //변경전점포코드Error	1	0						
				taxpfCorrcOut.setBfchActNoErr	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+110 , scndIndex+28+corpNmByte+nameByte+111));          //변경전계좌번호Error	1	0						
				taxpfCorrcOut.setAfchSavgKndErr  	     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+111 , scndIndex+28+corpNmByte+nameByte+112));          //변경후저축종류Error	1	0						
				taxpfCorrcOut.setAfchOffcCdErr	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+112 , scndIndex+28+corpNmByte+nameByte+113));          //변경후점포코드Error	1	0						
				taxpfCorrcOut.setAfchActNoErr	         (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+113 , scndIndex+28+corpNmByte+nameByte+114));          //변경후계좌번호Error	1	0						
				taxpfCorrcOut.setAfchActOpenDyErr	     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+114 , scndIndex+28+corpNmByte+nameByte+115));          //변경후계좌개설일Error	1	0					
				taxpfCorrcOut.setAfchTaxpfAmtErr	     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+115 , scndIndex+28+corpNmByte+nameByte+116));          //변경후세금우대금액Error	1	0				
				taxpfCorrcOut.setAfchExpiDyErr	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+116 , scndIndex+28+corpNmByte+nameByte+117));          //변경후만기일Error	1	0							
				taxpfCorrcOut.setAfchFstExpiExtnDyErr  (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+117 , scndIndex+28+corpNmByte+nameByte+118));          //변경후최초만기연장일Error	1	0			
				taxpfCorrcOut.setAfchIntDivdAmtErr	   (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+118 , scndIndex+28+corpNmByte+nameByte+119));          //변경후이자,배당지급액Error	1	0		  
				taxpfCorrcOut.setAfchRescsKndErr	     (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+119 , scndIndex+28+corpNmByte+nameByte+120));          //변경후해지종류Error	1	0						
				taxpfCorrcOut.setAfchInhrtYnErr	       (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+120 , scndIndex+28+corpNmByte+nameByte+121));          //변경후상속여부Error	1	0						
				taxpfCorrcOut.setAfchHousPrpsDvsnErr   (dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+121 , scndIndex+28+corpNmByte+nameByte+122));          //변경후주택청약예부금구분Error	1	0 

				
				
				logger.debug("변경후주민등록번호	13	0					({})", 	dataCtnt.substring(scndIndex,    scndIndex+13));                                
				logger.debug("변경후주민등록번호구분	1	0		{})",  dataCtnt.substring(scndIndex+13, scndIndex+14));                                
				logger.debug("변경전주민등록번호	13	0			({})",  dataCtnt.substring(scndIndex+14, scndIndex+27));                                
				logger.debug("변경전주민등록번호구분	1	0		({})",  dataCtnt.substring(scndIndex+27, scndIndex+28));                                
				logger.debug("변경후상호(기업체명)	40	0		    ({})",  dataCtnt.substring(scndIndex+28, scndIndex+28+corpNmByte));                     
				logger.debug("변경후성명(대표자)	20	0			({})",  dataCtnt.substring(scndIndex+28+corpNmByte,  scndIndex+28+corpNmByte+nameByte)); 
		        logger.debug("변경후정보주체(구장애인)구분	1	0	({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte     , scndIndex+28+corpNmByte+nameByte+1  ));        
				logger.debug("변경후저소득자구분(농어가저축)	1	({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+1   , scndIndex+28+corpNmByte+nameByte+2  ));        
				logger.debug("변경전저축종류	2	0				        ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+2   , scndIndex+28+corpNmByte+nameByte+4  ));        
				logger.debug("변경전개설점포코드	7	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+4   , scndIndex+28+corpNmByte+nameByte+11 ));        
				logger.debug("변경전계좌번호	16	0				      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+11  , scndIndex+28+corpNmByte+nameByte+27 ));        
				logger.debug("변경후저축종류	2	0				        ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+27  , scndIndex+28+corpNmByte+nameByte+29 ));        
				logger.debug("변경후개설점포코드	7	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+29  , scndIndex+28+corpNmByte+nameByte+36 ));        
				logger.debug("변경후계좌번호	16	0				      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+36  , scndIndex+28+corpNmByte+nameByte+52 ));        
				logger.debug("변경후계좌개설일	8	0				      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+52  , scndIndex+28+corpNmByte+nameByte+60 ));        
				logger.debug("변경후세금우대금액(단위:원)	10	0	({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+60  , scndIndex+28+corpNmByte+nameByte+70 ));        
				logger.debug("변경후만기일	8	0					        ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+70  , scndIndex+28+corpNmByte+nameByte+78 ));        
				logger.debug("변경후최초만기연장일	8	0			    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+78  , scndIndex+28+corpNmByte+nameByte+86 ));        
				logger.debug("변경후이자,배당지급액(단위:원)	10({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+86  , scndIndex+28+corpNmByte+nameByte+96 ));        
				logger.debug("변경후해지종류	2	0				        ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+96  , scndIndex+28+corpNmByte+nameByte+98 ));        
				logger.debug("변경후상속여부	1	0				        ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+98  , scndIndex+28+corpNmByte+nameByte+99 ));        
				logger.debug("변경후주택청약예부금구분	1	0		  ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+99  , scndIndex+28+corpNmByte+nameByte+100));        
				logger.debug("변경후주민등록번호Error	1	0		    ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+100 , scndIndex+28+corpNmByte+nameByte+101));        
				logger.debug("변경후주민등록번호구분Error	1	0	  ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+101 , scndIndex+28+corpNmByte+nameByte+102));        
				logger.debug("변경전주민등록번호Error	1	0		    ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+102 , scndIndex+28+corpNmByte+nameByte+103));        
				logger.debug("변경전주민등록번호구분Error	1	0	  ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+103 , scndIndex+28+corpNmByte+nameByte+104));        
				logger.debug("변경후기업체명Error	1	0			      ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+104 , scndIndex+28+corpNmByte+nameByte+105));        
				logger.debug("변경후성명Error	1	0				        ({})", 	dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+105 , scndIndex+28+corpNmByte+nameByte+106));        
				logger.debug("변경후정보주체구분Error	1	0		    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+106 , scndIndex+28+corpNmByte+nameByte+107));        
				logger.debug("변경후저소득자구분Error	1	0		    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+107 , scndIndex+28+corpNmByte+nameByte+108));        
				logger.debug("변경전저축종류Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+108 , scndIndex+28+corpNmByte+nameByte+109));        
				logger.debug("변경전점포코드Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+109 , scndIndex+28+corpNmByte+nameByte+110));        
				logger.debug("변경전계좌번호Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+110 , scndIndex+28+corpNmByte+nameByte+111));        
				logger.debug("변경후저축종류Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+111 , scndIndex+28+corpNmByte+nameByte+112));        
				logger.debug("변경후점포코드Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+112 , scndIndex+28+corpNmByte+nameByte+113));        
				logger.debug("변경후계좌번호Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+113 , scndIndex+28+corpNmByte+nameByte+114));        
				logger.debug("변경후계좌개설일Error	1	0			    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+114 , scndIndex+28+corpNmByte+nameByte+115));        
				logger.debug("변경후세금우대금액Error	1	0		    ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+115 , scndIndex+28+corpNmByte+nameByte+116));        
				logger.debug("변경후만기일Error	1	0				      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+116 , scndIndex+28+corpNmByte+nameByte+117));        
				logger.debug("변경후최초만기연장일Error	1	0		  ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+117 , scndIndex+28+corpNmByte+nameByte+118));        
				logger.debug("변경후이자,배당지급액Error	1	0	  ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+118 , scndIndex+28+corpNmByte+nameByte+119));        
				logger.debug("변경후해지종류Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+119 , scndIndex+28+corpNmByte+nameByte+120));        
				logger.debug("변경후상속여부Error	1	0			      ({})",  dataCtnt.substring(scndIndex+28+corpNmByte+nameByte+120 , scndIndex+28+corpNmByte+nameByte+121));        
						                                                    

				output.setTaxpfCorrc(taxpfCorrcOut);
				
				
			}
			/*************************************
			 * 세금우대삭제일경우 ( 0600 - 230 )
			 *************************************/
			else if("4".equals(dvsn)){

				COM_F_KLIOSKOTS00011In taxpfDelOut = new COM_F_KLIOSKOTS00011In();
				
				taxpfDelOut.setRrno	       (dataCtnt.substring(scndIndex   , scndIndex+13)); //주민등록번호	13	0				
				taxpfDelOut.setRrnoDvsn	   (dataCtnt.substring(scndIndex+13, scndIndex+14)); //주민등록번호구분	1	0			
				taxpfDelOut.setSavgKnd	   (dataCtnt.substring(scndIndex+14, scndIndex+16)); //저축종류	2	0							
				taxpfDelOut.setOffcCd	     (dataCtnt.substring(scndIndex+16, scndIndex+23)); //점포코드	7	0						  
				taxpfDelOut.setActNo	     (dataCtnt.substring(scndIndex+23, scndIndex+39)); //계좌번호	16	0					  
				taxpfDelOut.setRrnoErr	   (dataCtnt.substring(scndIndex+39, scndIndex+40)); //주민등록번호Error	1	0		
				taxpfDelOut.setRrnoDvsnErr (dataCtnt.substring(scndIndex+40, scndIndex+41)); //주민등록번호구분Error	1	
				taxpfDelOut.setSavgKndErr	 (dataCtnt.substring(scndIndex+41, scndIndex+42)); //저축종류Error	1	0				
				taxpfDelOut.setOffcCdErr	 (dataCtnt.substring(scndIndex+42, scndIndex+43)); //점포코드Error	1	0				
				taxpfDelOut.setActNoErr	   (dataCtnt.substring(scndIndex+43, scndIndex+44)); //계좌번호Error	1	0
				
				
				logger.debug("주민등록번호	13	0		({})", 	dataCtnt.substring(scndIndex   , scndIndex+13));      
				logger.debug("주민등록번호구분	1	0	({})",  dataCtnt.substring(scndIndex+13, scndIndex+14));      
				logger.debug("저축종류	2	0					({})",  dataCtnt.substring(scndIndex+14, scndIndex+16));      
				logger.debug("점포코드	7	0					({})",  dataCtnt.substring(scndIndex+16, scndIndex+23));      
				logger.debug("계좌번호	16	0				({})",  dataCtnt.substring(scndIndex+23, scndIndex+39));      
				logger.debug("주민등록번호Error	1	0	({})",  dataCtnt.substring(scndIndex+39, scndIndex+40));      
				logger.debug("주민등록번호구분Error	({})", 	dataCtnt.substring(scndIndex+40, scndIndex+41));      
				logger.debug("저축종류Error	1	0			({})",  dataCtnt.substring(scndIndex+41, scndIndex+42));      
				logger.debug("점포코드Error	1	0			({})",  dataCtnt.substring(scndIndex+42, scndIndex+43));      
				logger.debug("계좌번호Error	1	0			({})",  dataCtnt.substring(scndIndex+43, scndIndex+44));      

				
				output.setTaxpfDel(taxpfDelOut);
				

				
			}
			/*************************************
			 * 세금우대해지취소일경우 ( 0600 - 260 )
			 *************************************/
			else if("5".equals(dvsn)){

				COM_F_KLIOSKOTS00009In taxpfRescsCncl = new COM_F_KLIOSKOTS00009In();
				
				taxpfRescsCncl.setRrno	       (dataCtnt.substring(scndIndex   , scndIndex+13)); //주민등록번호	13	0				
				taxpfRescsCncl.setRrnoDvsn	   (dataCtnt.substring(scndIndex+13, scndIndex+14)); //주민등록번호구분	1	0			
				taxpfRescsCncl.setSavgKnd	   (dataCtnt.substring(scndIndex+14, scndIndex+16)); //저축종류	2	0							
				taxpfRescsCncl.setOpenOffcCd	     (dataCtnt.substring(scndIndex+16, scndIndex+23)); //점포코드	7	0						  
				taxpfRescsCncl.setActNo	     (dataCtnt.substring(scndIndex+23, scndIndex+39)); //계좌번호	16	0					  
				taxpfRescsCncl.setRrnoErr	   (dataCtnt.substring(scndIndex+39, scndIndex+40)); //주민등록번호Error	1	0		
				taxpfRescsCncl.setRrnoDvsnErr (dataCtnt.substring(scndIndex+40, scndIndex+41)); //주민등록번호구분Error	1	
				taxpfRescsCncl.setSavgKndErr	 (dataCtnt.substring(scndIndex+41, scndIndex+42)); //저축종류Error	1	0				
				taxpfRescsCncl.setOffcCdErr	 (dataCtnt.substring(scndIndex+42, scndIndex+43)); //점포코드Error	1	0				
				taxpfRescsCncl.setActNoErr	   (dataCtnt.substring(scndIndex+43, scndIndex+44)); //계좌번호Error	1	0
				
				
				logger.debug("주민등록번호	13	0		({})", 	dataCtnt.substring(scndIndex   , scndIndex+13));      
				logger.debug("주민등록번호구분	1	0	({})",  dataCtnt.substring(scndIndex+13, scndIndex+14));      
				logger.debug("저축종류	2	0					({})",  dataCtnt.substring(scndIndex+14, scndIndex+16));      
				logger.debug("개설점포코드	7	0					({})",  dataCtnt.substring(scndIndex+16, scndIndex+23));      
				logger.debug("계좌번호	16	0				({})",  dataCtnt.substring(scndIndex+23, scndIndex+39));      
				logger.debug("주민등록번호Error	1	0	({})",  dataCtnt.substring(scndIndex+39, scndIndex+40));      
				logger.debug("주민등록번호구분Error	({})", 	dataCtnt.substring(scndIndex+40, scndIndex+41));      
				logger.debug("저축종류Error	1	0			({})",  dataCtnt.substring(scndIndex+41, scndIndex+42));      
				logger.debug("점포코드Error	1	0			({})",  dataCtnt.substring(scndIndex+42, scndIndex+43));      
				logger.debug("계좌번호Error	1	0			({})",  dataCtnt.substring(scndIndex+43, scndIndex+44));      

				
				output.setTaxpfRescsCncl(taxpfRescsCncl);

				
				
			}
			
			output.setResultCnt(1);

		}
		
		
		return output;
		
	}
	
	
	/**
	 * 한글문자 포함데이터 바이트수 계산
	 * 
	 * @param  dataCtnt    데이터전문
	 *  	   dataByte    해당데이터의 바이트수
	 *  	   beginIndex  해당데이터의 문자열시작인덱스
	 * @return int 
	 * @throws ApplicationException
	 */	
	public int calKorByte(String dataCtnt, int dataByte, int beginIndex){
		
		int size = dataByte;
		int numSize = 0;
		int korSize = 0;
		int fSize = 0;
		
		for(int i = 0 ; i < size ; i++){
			
//			logger.debug("{}", FwUtil.substringKorean(dataCtnt.substring(beginIndex, beginIndex+dataByte), 20, "EUC-KR"));
//			
//			//한글일경우 2바이트 이므로, 문자열길이를 하나 뺀다.
//			
//			logger.debug("{}", Character.getType(dataCtnt.charAt(beginIndex+i)));
//			
//			if(Character.getType(dataCtnt.charAt(beginIndex+i)) == Character.OTHER_LETTER){
//				
//				logger.debug("데이터바이트--");
//				dataByte --;
//			}
			
			if(Character.getType(dataCtnt.charAt(beginIndex+i)) == 9){
			
				break;
				
			}
			else if((Character.getType(dataCtnt.charAt(beginIndex+i)) == Character.OTHER_LETTER)){
				korSize++;
			}
			else{
				numSize++;
			}
			
		}
		
		fSize = korSize + numSize;
		
		return fSize;
		
	}
}

