package cigna.cm.t.bean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA002BEAN;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.t.dbio.CMT010DBIO;
import cigna.cm.t.domain.BfFininRegCtntAddInqDO;
import cigna.cm.t.domain.BfFininRegCtntInqDO;
import cigna.cm.t.domain.RlvActNoRegCtntInqDO;
import cigna.cm.t.domain.SavgKcdDetlDtlcAddInqDO;
import cigna.cm.t.domain.SavgKcdDetlDtlcInqDO;
import cigna.cm.t.domain.TaxPfrLmtInqDO;
import cigna.cm.t.domain.TaxpfCorrcDO;
import cigna.cm.t.domain.TaxpfDelDO;
import cigna.cm.t.domain.TaxpfRegDO;
import cigna.cm.t.domain.TaxpfRescsCnclDO;
import cigna.cm.t.domain.TaxpfRescsDO;
import cigna.cm.t.domain.TaxpfSavgKndClLmtInqDO;
import cigna.cm.t.io.CMT010SVC01Out;
import cigna.cm.t.io.CMT010SVC01Sub0;


/**
 * @file         cigna.cm.t.bean.CMT010BEAN.java
 * @filetype     java source file
 * @brief        세금우대간입한도조회
 * @author       권문
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           권문                   2013. 7. 23.       신규 작성
 *
 */
@KlafBean
public class CMT999BEAN {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
    @Autowired
    private CMT001BEAN cmt001bean;
    
    /**
     * 계약번호전환내역 조회 DBIO
     */
    @Autowired
    private CMT010DBIO cmt010dbio;

    @Autowired
    private CMA002BEAN cma002bean;

    
	/**
	 * 세금우대한도조회
	 * 
	 * @param  TaxPfrLmtInqDO 세금우대한도조회DO
	 * @return TaxPfrLmtInqDO 세금우대한도조회DO
	 * @throws ApplicationException
	 */
	public CMT010SVC01Out taxpfSavgKndClLmtInq( String custNm, String custDscNo, String savgPrdcd, String isudTpcd, String mgntTgmCd, String prgGb) throws ApplicationException {
		
		CMT010SVC01Out output = new CMT010SVC01Out();
		
		CommEmplInfo emplInfo = cma002bean.getLoginEmplInfo();
		
		String    tempDpsTxNo        		= ""                      ;							// 입금거래번호
		String    tempPrcsDofOrgNo	= emplInfo.getDofOrgNo()  ;	// 처리지점조직번호
		String    tempPrcsFofOrgNo		= emplInfo.getFofOrgNo()  ;	// 처리영업소조직번호
		String    tempPrcsEno				= emplInfo.getEno()       ;			// 처리사원번호
		String    tempContNo				= ""                      ;							// 계약번호
		String    tempRrno						= custDscNo               ;					// 주민등록번호
		String    tempRrnoDvsn				= "1"                     ;							// 구분코드
		String    tempTaxpfBzPrcsDcd = "PR"                    ;						// 세금우대업무처리구분코드
		
		logger.debug("=========  prgGb  ===============" + prgGb);
		
		Object out = null;
		
		// 세금우대저축종류별한도조회(0200/205)
		if( "COM_F_KLIOAKOTS00001".equals(isudTpcd) ){
			
			TaxpfSavgKndClLmtInqDO input = new TaxpfSavgKndClLmtInqDO();
			
			out = new TaxpfSavgKndClLmtInqDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setLmtInqSavgKnd	("58");									// 저축종류
			input.setInfoMnbdyDvsn	("1");										// 장애구분처리구분코드
			input.setIncmrDvsn			("1");										// 농어촌구분코드
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.taxpfSavgKndClLmtInq(input);
			
		// 세금우대전금융기관등록내용조회(0200/210)
		} else if( "COM_F_KLIOAKOTS00002".equals(isudTpcd) ){
			
			BfFininRegCtntInqDO input = new BfFininRegCtntInqDO();
			
			out = new BfFininRegCtntInqDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.bfFininRegCtntInq(input);
			
			// 전문관리번호
			output.setMgntTgmCd(((BfFininRegCtntInqDO)out).getMgntTgmCd());
			
		// 세금우대전금융기관등록내용추가조회(0300/210)
		} else if( "COM_F_KLIOAKOTS00003".equals(isudTpcd) ){
			
			BfFininRegCtntAddInqDO input = new BfFininRegCtntAddInqDO();
			
			out = new BfFininRegCtntAddInqDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			if( !StringUtils.isEmpty(mgntTgmCd) )	{
				input.setMgntTgmCd		(StringUtils.lpad(mgntTgmCd, 7, "0"));					// 전문관리번호(7자리)
			}
			
			out = cmt001bean.bfFininRegCtntAddInq(input);
			
		// 저축종류별세부내역조회(0200/216)
		} else if( "COM_F_KLIOAKOTS00004".equals(isudTpcd) ){
			
			SavgKcdDetlDtlcInqDO input = new SavgKcdDetlDtlcInqDO();
			
			out = new SavgKcdDetlDtlcInqDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setInqReqSavgKcd	("58");									// 저축종류
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.savgKcdDetlDtlcInq(input);
			
			// 전문관리번호
			output.setMgntTgmCd(((SavgKcdDetlDtlcInqDO)out).getMgntTgmCd());
			
		// 저축종류별세부내역추가조회(0300/216)
		} else if( "COM_F_KLIOAKOTS00005".equals(isudTpcd) ){
			
			SavgKcdDetlDtlcAddInqDO input = new SavgKcdDetlDtlcAddInqDO();
			
			out = new SavgKcdDetlDtlcAddInqDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setInqReqSavgKcd	("58");									// 저축종류
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			if( !StringUtils.isEmpty(mgntTgmCd) )	{
				input.setMgntTgmCd		(StringUtils.lpad(mgntTgmCd, 7, "0"));					// 전문관리번호(7자리)
			}
			
			out = cmt001bean.savgKcdDetlDtlcAddInq(input);
			
		// 해당계좌번호 등록내용 조회(0200/215)
		} else if( "COM_F_KLIOAKOTS00006".equals(isudTpcd) ){
			
			RlvActNoRegCtntInqDO input = new RlvActNoRegCtntInqDO();
			
			out = new RlvActNoRegCtntInqDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setInqActNo				("1236500902");				// 조회계좌번호
			input.setRegOffcCd			("2061005");						// 등록점포코드
			input.setSavgKnd				("58");									// 저축종류
			
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.rlvActNoRegCtntInq(input);
			
		// 세금우대등록(0400/210)
		} else if( "COM_F_KLIOAKOTS00007".equals(isudTpcd) ){
			
			TaxpfRegDO input = new TaxpfRegDO();
			
			out = new TaxpfRegDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setConm					("홍길동");								// 상호
			input.setName					("테스트");								// 성명
			input.setInfoMnbdyDvsn	("1");										// 정보주체 구분
			input.setIncmrDvsn			("1");										// 저소득자 구분
			input.setSavgKnd				("58");									// 저축종류
			input.setOpenOffcCd		("2061005");						// 개설점포코드
			input.setActNo					("1236500902");				// 계좌번호
			input.setActOpenDy			("20160101");						// 계좌개설일
			input.setTaxpfAmt				(BigDecimal.valueOf(10000));	// 세금우대금액
			input.setExpiDy					("20171231");						// 만기일
			input.setInhrtYn					("1");										// 상속여부
			input.setHousPrpsDvsn		("0");										// 주택청약 예부금 코드
			
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.taxpfReg(input);
			
		// 세금우대해지(0500/210)
		} else if( "COM_F_KLIOAKOTS00008".equals(isudTpcd) ){
			
			TaxpfRescsDO input = new TaxpfRescsDO();
			
			out = new TaxpfRescsDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setConm					("홍길동");								// 상호
			input.setName					("테스트");								// 성명
			input.setRescsKnd				("21");									// 중도해지
			input.setSavgKnd				("58");									// 저축종류
			input.setOpenOffcCd		("2061005");						// 개설점포코드
			input.setActNo					("1236500902");				// 계좌번호
			input.setActRescsDy			("20160101");						// 계좌해지일
			input.setTaxpfAmt				(BigDecimal.valueOf(10000));	// 세금우대금액
			input.setIntDivdAmt			(BigDecimal.valueOf(100));	// 이자배당지급액
			
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.taxpfRescs(input);
			
		// 세금우대해지취소(0600/260)
		} else if( "COM_F_KLIOAKOTS00009".equals(isudTpcd) ){
			
			TaxpfRescsCnclDO input = new TaxpfRescsCnclDO();
			
			out = new TaxpfRescsCnclDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setSavgKnd				("58");									// 저축종류
			input.setOpenOffcCd		("2061005");						// 개설점포코드
			input.setActNo					("1236500902");				// 계좌번호
			
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.taxpfRescsCncl(input);
			
		// 세금우대정정(0600/210)
		} else if( "COM_F_KLIOAKOTS00010".equals(isudTpcd) ){
			
			TaxpfCorrcDO input = new TaxpfCorrcDO();
			
			out = new TaxpfCorrcDO();
			
			input.setBfchRrno						(tempRrno);   					// set [변경전주민등록번호]
			input.setBfchRrnoDvsn     		(tempRrnoDvsn);         	// set [변경전주민등록번호구분]	
			input.setBfchSavgKnd       		(savgPrdcd);         			// set [변경전저축종류]			
			input.setBfchOpenOffcCd		("2061005");         			// set [변경전개설점포코드]					
			input.setBfchActNo					("24410Z0306");        	// set [변경전계좌번호]
			
			input.setAfchRrno	      				("6007032463031");    // set [변경후주민등록번호]
			input.setAfchRrnoDvsn	  		("1");        							// set [변경후주민등록번호구분]
			input.setAfchConm	      			("테스트2");       				// set [변경후기업체명]
			input.setAfchName	      			("홍길동");        					// set [변경후성명(대표자)]
			input.setAfchInfoMnbdyDvsn	("0");        							// set [변경후정보주체(구장애인)구분	]								
			input.setAfchIncmrDvsn     		("0");         							// set [변경후저소득자구분(농어가저축)	]							
			input.setAfchSavgKnd       		( savgPrdcd );         			// set [변경후저축종류]				
			input.setAfchOpenOffcCd    	("2061005");         			// set [변경후개설점포코드]					
			input.setAfchActNo        			("24410Z0307");         	// set [변경후계좌번호]					
			input.setAfchActOpenDy	   		("20160728");         		// set [변경후계좌개설일]			
			input.setAfchTaxpfAmt  			(BigDecimal.ZERO);       // set [변경후세금우대금액(단위:원)]
			input.setAfchExpiDy    				("20301231");         		// set [변경후만기일]
			input.setAfchFstExpiExtnDy		("20311231");         		// set [변경후최초만기연장일]
			input.setAfchRescsKnd	   			("23");        						// set [변경후해지종류]	
			input.setAfchInhrtYn       			("0");         							// set [변경후상속여부]				
			input.setAfchHousPrpsDvsn  	("0");         							// set [변경후주택청약예부금구분]
			input.setAfchIntDivdAmt	   		( BigDecimal.ZERO );     // set [변경후이자,배당지급액(단위:원) 0원으로세팅
			
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)

			out = cmt001bean.taxpfCorrc(input);
			
		// 세금우대삭제(0600/230)
		} else if( "COM_F_KLIOAKOTS00011".equals(isudTpcd) ){
			
			TaxpfDelDO input = new TaxpfDelDO();
			
			out = new TaxpfDelDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setSavgKnd				("58");									// 저축종류
			input.setOffcCd					("2061005");						// 점포코드
			input.setActNo					("1236500902");				// 계좌번호
			
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.taxpfDel(input);
			
		// 세금우대한도조회(0200/200)
		} else if( "COM_F_KLIOAKOTS00012".equals(isudTpcd) ){
			
			TaxPfrLmtInqDO input = new TaxPfrLmtInqDO();
			
			out = new TaxPfrLmtInqDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.taxPfrLmtInq(input);
			
		// 저축종류별세부등록내용조회(0200/211)
		} else if( "COM_F_KLIOAKOTS00013".equals(isudTpcd) ){
			
			SavgKcdDetlDtlcInqDO input = new SavgKcdDetlDtlcInqDO();
			
			out = new SavgKcdDetlDtlcInqDO();
			
			input.setRrno						(tempRrno);							// 주민등록번호
			input.setRrnoDvsn				(tempRrnoDvsn);				// 주민등록번호구분
			input.setInqReqSavgKcd	("58");									// 저축종류
			
			input.setDpsTxNo        		(tempDpsTxNo);					// 입금거래번호
			input.setPrcsDofOrgNo	(tempPrcsDofOrgNo);		// 처리지점조직번호
			input.setPrcsFofOrgNo 	(tempPrcsFofOrgNo);		// 처리영업소조직번호
			input.setPrcsEno        			(tempPrcsEno);					// 처리사원번호
			input.setContNo         		(tempContNo);					// 계약번호
			input.setTaxpfBzPrcsDcd	(tempTaxpfBzPrcsDcd);	// 세금우대업무처리구분코드(PR = 보전)
			
			out = cmt001bean.savgKcdDetlRegCtntInq(input);
			
		}
		
		if ( null != isudTpcd && null != out)		{
			logger.debug("InterfaceID : "+isudTpcd +" output : " + out);
		}
		
		return output;
		
	}
	
}

