/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Sat Feb 14 16:36:54 KST 2015
 */
package cigna.cm.t.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/t/dbio/CMT000DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMT000DBIO
{

	java.util.HashMap selectMultiNONAME();
}