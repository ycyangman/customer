/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue May 03 18:00:19 KST 2016
 */
package cigna.cm.t.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/t/dbio/CMT005DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMT005DBIO
{

	/**
	 * 세금우대 조회
	 * @TestValues 	contNo=;	savgPrdcd=;
	 */
	cigna.cm.t.io.SelectOneTBCNETC025aOut selectOneTBCNETC025a(
			@Param("contNo")
			java.lang.String contNo, @Param("savgPrdcd")
			java.lang.String savgPrdcd);

	/**
	 * 세금우대로그 조회
	 * @TestValues 	taxpfTgmNo=;	prcsDtm=;
	 */
	cigna.cm.t.io.SelectOneTBCNETC026aOut selectOneTBCNETC026a(
			@Param("taxpfTgmNo")
			java.lang.String taxpfTgmNo, @Param("prcsDtm")
			java.lang.String prcsDtm);

	/**
	 * 세금우대 insert
	 * @TestValues 	contNo=;	savgPrdcd=;	contrCustNo=;	contrBlntEntpNm=;	contrBlntReprNm=;	prcsDt=;	expiDt=;	expiExtnDt=;	taxpfIntDivdAmt=;	taxpfEntAmt=;	taxpfPrcsStcd=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCNETC025a(cigna.cm.t.io.TBCNETC025Io tBCNETC025Io);

	/**
	 * 세금우대 update
	 * @TestValues 	contNo=1;	savgPrdcd=1;	contrCustNo=1;	contrBlntEntpNm=1;	contrBlntReprNm=1;	prcsDt=1;	expiDt=1;	expiExtnDt=1;	taxpfIntDivdAmt=1;	taxpfEntAmt=1;	taxpfPrcsStcd=1;	delYn=1;	lastChgDtm=;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int updateOneTBCNETC025a(cigna.cm.t.io.TBCNETC025Io tBCNETC025Io);

	/**
	 * 세금우대로그 insert
	 * @TestValues 	prcsDtm=;	taxpfTgmNo=;	prcsDt=;	dpsTxNo=;	prcsDofOrgNo=;	prcsFofOrgNo=;	prcsEno=;	contNo=;	savgPrdcd=;	prcsYn=;	taxpfRcd=;	taxpfTgmKcd=;	taxpfBzDcd=;	taxpfBzPrcsDcd=;	nrmCnclDcd=;	taxpfTgmDataCtnt=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCNETC026a(cigna.cm.t.io.TBCNETC026Io tBCNETC026Io);

	/**
	 * 세금우대멀티건조회
	 * @TestValues 	contNo=;
	 */
	java.util.List<cigna.cm.t.io.SelectOneTBCNETC025aOut> selectMultiTBCNETC025a(
			@Param("contNo")
			java.lang.String contNo);

	/**
	 * @TestValues 	prcsDtm=1;	taxpfTgmNo=1;	prcsDt=1;	dpsTxNo=1;	prcsDofOrgNo=1;	prcsFofOrgNo=1;	prcsEno=1;	contNo=1;	savgPrdcd=1;	prcsYn=1;	taxpfRcd=;	taxpfTgmKcd=1;	taxpfBzDcd=1;	taxpfBzPrcsDcd=;	nrmCnclDcd=;	taxpfTgmDataCtnt=;	delYn=;	lastChgDtm=;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int updateOneTBCNETC026a(cigna.cm.t.io.TBCNETC026Io tBCNETC026Io);

	/**
	 * 세금우대멀티건조회(상태값추가)
	 * @TestValues 	contNo=;	taxpfPrcsStcd=;
	 */
	java.util.List<cigna.cm.t.io.SelectOneTBCNETC025aOut> selectMultiTBCNETC025b(@Param("contNo")
			java.lang.String contNo, @Param("taxpfPrcsStcd")
			java.lang.String taxpfPrcsStcd);

	/**
	 * 세금우대로그조회(특정처리건조회)
	 * @TestValues 	contNo=;	taxpfTgmKcd=;	taxpfBzDcd=;	taxpfBzPrcsDcd=;	taxpfPrcsStcd=;
	 */
	java.util.List<cigna.cm.t.io.SelectOneTBCNETC026bOut> selectOneTBCNETC026b(@Param("contNo")
	java.lang.String contNo, @Param("taxpfTgmKcd")
	java.lang.String taxpfTgmKcd, @Param("taxpfBzDcd")
	java.lang.String taxpfBzDcd, @Param("taxpfBzPrcsDcd")
	java.lang.String taxpfBzPrcsDcd, @Param("taxpfPrcsStcd")
	java.lang.String taxpfPrcsStcd);

	/**
	 * 세금우대 merge
	 * @TestValues 	contNo=1;	savgPrdcd=1;	contrCustNo=1;	contrBlntEntpNm=1;	contrBlntReprNm=1;	prcsDt=1;	expiDt=1;	expiExtnDt=1;	taxpfIntDivdAmt=1;	taxpfEntAmt=1;	taxpfPrcsStcd=1;	delYn=;	lastChgDtm=;	lastChgrId=1;	lastChgPgmId=1;	lastChgTrmNo=1;
	 */
	int mergeOneTBCNETC025a(cigna.cm.t.io.TBCNETC025Io tBCNETC025Io);
}