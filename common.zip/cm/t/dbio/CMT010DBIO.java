/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Fri Nov 15 14:56:11 KST 2013
 */
package cigna.cm.t.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/t/dbio/CMT010DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMT010DBIO
{

	/**
	 * @TestValues 	contNo=;
	 */
	java.lang.String selectOneTBCNETC001a(
			@Param("contNo")
			java.lang.String contNo);

	/**
	 * @TestValues 	contNo=;
	 */
	java.lang.String selectOneTBCNETC001b(
			@Param("contNo") java.lang.String contNo);
}