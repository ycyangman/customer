/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Fri Feb 24 21:31:25 KST 2017
 */
package cigna.cm.t.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/t/dbio/CMT011DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMT011DBIO
{

	/**
	 * @TestValues 	data.prcsDtm=;	data.taxpfTgmNo=;	data.prcsDt=;	data.dpsTxNo=;	data.prcsDofOrgNo=;	data.prcsFofOrgNo=;	data.prcsEno=;	data.contNo=;	data.savgPrdcd=;	data.prcsYn=;	data.taxpfRcd=;	data.taxpfTgmKcd=;	data.taxpfBzDcd=;	data.taxpfBzPrcsDcd=;	data.nrmCnclDcd=;	data.taxpfTgmDataCtnt=;	data.rdsnBzno=;	data.rdsnBznoDcd=;	data.lmtInqSavgKndVl=;	data.infoMnbdyDcd=;	data.lrnkIncmrDcd=;	data.conmNm=;	data.taxpfTgtpNm=;	data.savgKndDupVl=;	data.savgCtgyEntAmt=;	data.savgCtgyUusdAmt=;	data.entInstOffcId=;	data.inqReqSavgKndLmtAmt=;	data.inqReqSavgKndEntSamt=;	data.inqReqSavgKndLmtRmnAmt=;	data.inqReqSavgKndDupVl=;	data.inqReqSavgKndTtlCnt=;	data.actNo=;	data.openOffcId=;	data.rescsDvsnVl=;	data.savgKndVl=;	data.savgNewDt=;	data.taxpfAmt=;	data.expiDt=;	data.rescsDt=;	data.intDivdPayAmt=;	data.inhrtVl=;	data.housPrpsDpstDvsnVl=;	data.actOpenDt=;	data.rescsKcd=;	data.actRescsDt=;	data.rdsnBznoErrVl=;	data.rdsnBznoDcdErrVl=;	data.conmErrVl=;	data.taxpfTgtpNmErrVl=;	data.infoMnbdyDcdErrVl=;	data.lrnkIncmrDcdErrVl=;	data.savgKndErrVl=;	data.openOffcIdErrVl=;	data.actNoErrVl=;	data.actOpenDtErrVl=;	data.taxpfAmtErrVl=;	data.expiDtErrVl=;	data.inhrtErrVl=;	data.housPrpsDpstDvsnVlErrVl=;	data.rescsKcdErrVl=;	data.actRescsDtErrVl=;	data.intDivdPayAmtErrVl=;	data.afchRdsnBzno=;	data.afchRdsnBznoDcd=;	data.bfchRdsnBzno=;	data.bfchRdsnBznoDcd=;	data.afchConmNm=;	data.afchTaxpfTgtpNm=;	data.afchInfoMnbdyDcd=;	data.afchLrnkIncmrDcd=;	data.bfchSavgKndVl=;	data.bfchOpenOffcId=;	data.bfchActNo=;	data.afchSavgKndVl=;	data.afchOpenOffcId=;	data.afchActNo=;	data.afchActOpenDt=;	data.afchTaxpfAmt=;	data.afchExpiDt=;	data.afchFstExpiExtnDt=;	data.afchIntDivdPayAmt=;	data.afchRescsKcd=;	data.afchInhrtVl=;	data.afchHousPrpsDpstDvsnVl=;	data.afchRdsnBznoErrVl=;	data.afchRdsnBznoDcdErrVl=;	data.bfchRdsnBznoErrVl=;	data.bfchRdsnBznoDcdErrVl=;	data.afchConmErrVl=;	data.afchTaxpfTgtpNmErrVl=;	data.afchInfoMnbdyDcdErrVl=;	data.afchLrnkIncmrDcdErrVl=;	data.bfchSavgKndErrVl=;	data.bfchOpenOffcIdErrVl=;	data.bfchActNoErrVl=;	data.afchSavgKndErrVl=;	data.afchOpenOffcIdErrVl=;	data.afchActNoErrVl=;	data.afchActOpenDtErrVl=;	data.afchTaxpfAmtErrVl=;	data.afchExpiDtErrVl=;	data.afchFstExpiExtnDtErrVl=;	data.afchIntDivdPayAmtErrVl=;	data.afchRescsKcdErrVl=;	data.afchInhrtYnErrVl=;	data.afchHousPrpsDpstErrVl=;	data.delYn=;	data.lastChgDtm=;	data.lastChgrId=;	data.lastChgPgmId=;	data.lastChgTrmNo=;	pageNum=0;	pageCount=500;
	 */
	java.util.List<cigna.cm.t.io.SelectMultiTBCNETC026aOut> selectMultiTBCNETC026a(@Param("data")
	cigna.cm.t.io.TBCNETC026Io data, @Param("pageNum")
	int pageNum, @Param("pageCount")
	int pageCount);

	/**
	 * @TestValues 	prcsDtm=20130705143919127603;	taxpfTgmNo=1459;
	 */
	java.lang.String selectMultiTBCNETC026b(
			@Param("prcsDtm")
			java.lang.String prcsDtm, @Param("taxpfTgmNo")
			java.lang.String taxpfTgmNo);
}