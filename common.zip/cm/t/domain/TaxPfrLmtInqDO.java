/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Thu Apr 11 14:24:39 KST 2013
 * 
 */
package cigna.cm.t.domain;

import java.io.Serializable;

/**
 * @DataObjectName TaxPfrLmtInqDO
 * @Description 
 */
public class TaxPfrLmtInqDO implements Serializable, Cloneable {

	private static final long serialVersionUID = 561594894L;
	/**
	 * @Type java.lang.String
	 * @Name rrno
	 * @Description 주민등록번호
	 * @Length 82
	 * @Decimal 0
	 */
	private java.lang.String rrno;
	/**
	 * @Type java.lang.String
	 * @Name rrnoDvsn
	 * @Description 주민(사업자)등록번호구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrnoDvsn;
	/**
	 * @Type java.lang.String
	 * @Name conm
	 * @Description 상호(기업체명)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String conm;
	/**
	 * @Type java.lang.String
	 * @Name name
	 * @Description 성명(대표자)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String name;
	/**
	 * @Type java.lang.String
	 * @Name infoMnbdyDvsn
	 * @Description 정보주체(구 장애인)구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String infoMnbdyDvsn;
	/**
	 * @Type java.lang.String
	 * @Name taxpfDupYn
	 * @Description 세금우대중복여부
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String taxpfDupYn;
	/**
	 * @Type java.math.BigDecimal
	 * @Name taxpfTtlLmtAmt
	 * @Description 세금우대총한도금액
	 * @Length 0
	 * @Decimal 0
	 */
	private java.math.BigDecimal taxpfTtlLmtAmt;
	/**
	 * @Type java.math.BigDecimal
	 * @Name taxpfUusdLmtAmt
	 * @Description 세금우대미사용한도금액
	 * @Length 0
	 * @Decimal 0
	 */
	private java.math.BigDecimal taxpfUusdLmtAmt;
	/**
	 * @Type java.lang.String
	 * @Name dpsTxNo
	 * @Description 입금거래번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String dpsTxNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsDofOrgNo
	 * @Description 처리지점조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsDofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsFofOrgNo
	 * @Description 처리지점소조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsFofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsEno
	 * @Description 처리사원번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsEno;
	
	/**
	 * @Type java.lang.String
	 * @Name contNo
	 * @Description 계약번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String contNo;
	
	/**
	 * @Type java.lang.String
	 * @Name savgPrdcd
	 * @Description 저축상품코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgPrdcd;
	
	/**
	 * @Type java.lang.String
	 * @Name tgmKndCd
	 * @Description 전문종별코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String tgmKndCd;
	/**
	 * @Type java.lang.String
	 * @Name assoBusiGb
	 * @Description 협회업무구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String assoBusiGb;
	/**
	 * @Type java.lang.String
	 * @Name trnsDtm
	 * @Description 전문전송일시
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String trnsDtm;
	/**
	 * @Type java.lang.String
	 * @Name mgntTgmCd
	 * @Description 전문관리번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String mgntTgmCd;
	/**
	 * @Type java.lang.String
	 * @Name sndInstCd
	 * @Description 전송기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String sndInstCd;
	/**
	 * @Type java.lang.String
	 * @Name rcvInstCd
	 * @Description 수신기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rcvInstCd;
	/**
	 * @Type java.lang.String
	 * @Name assoRspCd
	 * @Description 협회응답코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String assoRspCd;
	/**
	 * @Type java.lang.String
	 * @Name taxpfBzPrcsDcd
	 * @Description 세금우대업무처리구분코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String taxpfBzPrcsDcd;

	/**
	 * @return the taxpfBzPrcsDcd
	 */
	public java.lang.String getTaxpfBzPrcsDcd() {
		return taxpfBzPrcsDcd;
	}

	/**
	 * @param taxpfBzPrcsDcd the taxpfBzPrcsDcd to set
	 */
	public void setTaxpfBzPrcsDcd(java.lang.String taxpfBzPrcsDcd) {
		this.taxpfBzPrcsDcd = taxpfBzPrcsDcd;
	}

	/**
	 * @return the dpsTxNo
	 */
	public java.lang.String getDpsTxNo() {
		return dpsTxNo;
	}

	/**
	 * @param dpsTxNo the dpsTxNo to set
	 */
	public void setDpsTxNo(java.lang.String dpsTxNo) {
		this.dpsTxNo = dpsTxNo;
	}

	/**
	 * @return the prcsDofOrgNo
	 */
	public java.lang.String getPrcsDofOrgNo() {
		return prcsDofOrgNo;
	}

	/**
	 * @param prcsDofOrgNo the prcsDofOrgNo to set
	 */
	public void setPrcsDofOrgNo(java.lang.String prcsDofOrgNo) {
		this.prcsDofOrgNo = prcsDofOrgNo;
	}

	/**
	 * @return the prcsFofOrgNo
	 */
	public java.lang.String getPrcsFofOrgNo() {
		return prcsFofOrgNo;
	}

	/**
	 * @param prcsFofOrgNo the prcsFofOrgNo to set
	 */
	public void setPrcsFofOrgNo(java.lang.String prcsFofOrgNo) {
		this.prcsFofOrgNo = prcsFofOrgNo;
	}

	/**
	 * @return the prcsEno
	 */
	public java.lang.String getPrcsEno() {
		return prcsEno;
	}

	/**
	 * @param prcsEno the prcsEno to set
	 */
	public void setPrcsEno(java.lang.String prcsEno) {
		this.prcsEno = prcsEno;
	}

	/**
	 * @return the contNo
	 */
	public java.lang.String getContNo() {
		return contNo;
	}

	/**
	 * @param contNo the contNo to set
	 */
	public void setContNo(java.lang.String contNo) {
		this.contNo = contNo;
	}

	/**
	 * @return the savgPrdcd
	 */
	public java.lang.String getSavgPrdcd() {
		return savgPrdcd;
	}

	/**
	 * @param savgPrdcd the savgPrdcd to set
	 */
	public void setSavgPrdcd(java.lang.String savgPrdcd) {
		this.savgPrdcd = savgPrdcd;
	}

	/**
	 * GET 주민등록번호
	 */
	public java.lang.String getRrno() {
		return this.rrno;
	}

	/**
	 * SET 주민등록번호
	 */
	public void setRrno(java.lang.String rrno) {
		this.rrno = rrno;
	}

	/**
	 * GET 주민(사업자)등록번호구분
	 */
	public java.lang.String getRrnoDvsn() {
		return this.rrnoDvsn;
	}

	/**
	 * SET 주민(사업자)등록번호구분
	 */
	public void setRrnoDvsn(java.lang.String rrnoDvsn) {
		this.rrnoDvsn = rrnoDvsn;
	}

	/**
	 * GET 상호(기업체명)
	 */
	public java.lang.String getConm() {
		return this.conm;
	}

	/**
	 * SET 상호(기업체명)
	 */
	public void setConm(java.lang.String conm) {
		this.conm = conm;
	}

	/**
	 * GET 성명(대표자)
	 */
	public java.lang.String getName() {
		return this.name;
	}

	/**
	 * SET 성명(대표자)
	 */
	public void setName(java.lang.String name) {
		this.name = name;
	}

	/**
	 * GET 정보주체(구 장애인)구분
	 */
	public java.lang.String getInfoMnbdyDvsn() {
		return this.infoMnbdyDvsn;
	}

	/**
	 * SET 정보주체(구 장애인)구분
	 */
	public void setInfoMnbdyDvsn(java.lang.String infoMnbdyDvsn) {
		this.infoMnbdyDvsn = infoMnbdyDvsn;
	}

	/**
	 * GET 세금우대중복여부
	 */
	public java.lang.String getTaxpfDupYn() {
		return this.taxpfDupYn;
	}

	/**
	 * SET 세금우대중복여부
	 */
	public void setTaxpfDupYn(java.lang.String taxpfDupYn) {
		this.taxpfDupYn = taxpfDupYn;
	}

	/**
	 * GET 세금우대총한도금액
	 */
	public java.math.BigDecimal getTaxpfTtlLmtAmt() {
		return this.taxpfTtlLmtAmt;
	}

	/**
	 * SET 세금우대총한도금액
	 */
	public void setTaxpfTtlLmtAmt(java.math.BigDecimal taxpfTtlLmtAmt) {
		this.taxpfTtlLmtAmt = taxpfTtlLmtAmt;
	}

	/**
	 * GET 세금우대미사용한도금액
	 */
	public java.math.BigDecimal getTaxpfUusdLmtAmt() {
		return this.taxpfUusdLmtAmt;
	}

	/**
	 * SET 세금우대미사용한도금액
	 */
	public void setTaxpfUusdLmtAmt(java.math.BigDecimal taxpfUusdLmtAmt) {
		this.taxpfUusdLmtAmt = taxpfUusdLmtAmt;
	}

	/**
	 * @return the tgmKndCd
	 */
	public java.lang.String getTgmKndCd() {
		return tgmKndCd;
	}

	/**
	 * @param tgmKndCd the tgmKndCd to set
	 */
	public void setTgmKndCd(java.lang.String tgmKndCd) {
		this.tgmKndCd = tgmKndCd;
	}

	/**
	 * @return the assoBusiGb
	 */
	public java.lang.String getAssoBusiGb() {
		return assoBusiGb;
	}

	/**
	 * @param assoBusiGb the assoBusiGb to set
	 */
	public void setAssoBusiGb(java.lang.String assoBusiGb) {
		this.assoBusiGb = assoBusiGb;
	}

	/**
	 * @return the trnsDtm
	 */
	public java.lang.String getTrnsDtm() {
		return trnsDtm;
	}

	/**
	 * @param trnsDtm the trnsDtm to set
	 */
	public void setTrnsDtm(java.lang.String trnsDtm) {
		this.trnsDtm = trnsDtm;
	}

	/**
	 * @return the mgntTgmCd
	 */
	public java.lang.String getMgntTgmCd() {
		return mgntTgmCd;
	}

	/**
	 * @param mgntTgmCd the mgntTgmCd to set
	 */
	public void setMgntTgmCd(java.lang.String mgntTgmCd) {
		this.mgntTgmCd = mgntTgmCd;
	}

	/**
	 * @return the sndInstCd
	 */
	public java.lang.String getSndInstCd() {
		return sndInstCd;
	}

	/**
	 * @param sndInstCd the sndInstCd to set
	 */
	public void setSndInstCd(java.lang.String sndInstCd) {
		this.sndInstCd = sndInstCd;
	}

	/**
	 * @return the rcvInstCd
	 */
	public java.lang.String getRcvInstCd() {
		return rcvInstCd;
	}

	/**
	 * @param rcvInstCd the rcvInstCd to set
	 */
	public void setRcvInstCd(java.lang.String rcvInstCd) {
		this.rcvInstCd = rcvInstCd;
	}

	/**
	 * @return the assoRspCd
	 */
	public java.lang.String getAssoRspCd() {
		return assoRspCd;
	}

	/**
	 * @param assoRspCd the assoRspCd to set
	 */
	public void setAssoRspCd(java.lang.String assoRspCd) {
		this.assoRspCd = assoRspCd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((assoBusiGb == null) ? 0 : assoBusiGb.hashCode());
		result = prime * result
				+ ((assoRspCd == null) ? 0 : assoRspCd.hashCode());
		result = prime * result + ((conm == null) ? 0 : conm.hashCode());
		result = prime * result + ((contNo == null) ? 0 : contNo.hashCode());
		result = prime * result + ((dpsTxNo == null) ? 0 : dpsTxNo.hashCode());
		result = prime * result
				+ ((infoMnbdyDvsn == null) ? 0 : infoMnbdyDvsn.hashCode());
		result = prime * result
				+ ((mgntTgmCd == null) ? 0 : mgntTgmCd.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result
				+ ((prcsDofOrgNo == null) ? 0 : prcsDofOrgNo.hashCode());
		result = prime * result + ((prcsEno == null) ? 0 : prcsEno.hashCode());
		result = prime * result
				+ ((prcsFofOrgNo == null) ? 0 : prcsFofOrgNo.hashCode());
		result = prime * result
				+ ((rcvInstCd == null) ? 0 : rcvInstCd.hashCode());
		result = prime * result + ((rrno == null) ? 0 : rrno.hashCode());
		result = prime * result
				+ ((rrnoDvsn == null) ? 0 : rrnoDvsn.hashCode());
		result = prime * result
				+ ((savgPrdcd == null) ? 0 : savgPrdcd.hashCode());
		result = prime * result
				+ ((sndInstCd == null) ? 0 : sndInstCd.hashCode());
		result = prime * result
				+ ((taxpfBzPrcsDcd == null) ? 0 : taxpfBzPrcsDcd.hashCode());
		result = prime * result
				+ ((taxpfDupYn == null) ? 0 : taxpfDupYn.hashCode());
		result = prime * result
				+ ((taxpfTtlLmtAmt == null) ? 0 : taxpfTtlLmtAmt.hashCode());
		result = prime * result
				+ ((taxpfUusdLmtAmt == null) ? 0 : taxpfUusdLmtAmt.hashCode());
		result = prime * result
				+ ((tgmKndCd == null) ? 0 : tgmKndCd.hashCode());
		result = prime * result + ((trnsDtm == null) ? 0 : trnsDtm.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxPfrLmtInqDO other = (TaxPfrLmtInqDO) obj;
		if (assoBusiGb == null) {
			if (other.assoBusiGb != null)
				return false;
		} else if (!assoBusiGb.equals(other.assoBusiGb))
			return false;
		if (assoRspCd == null) {
			if (other.assoRspCd != null)
				return false;
		} else if (!assoRspCd.equals(other.assoRspCd))
			return false;
		if (conm == null) {
			if (other.conm != null)
				return false;
		} else if (!conm.equals(other.conm))
			return false;
		if (contNo == null) {
			if (other.contNo != null)
				return false;
		} else if (!contNo.equals(other.contNo))
			return false;
		if (dpsTxNo == null) {
			if (other.dpsTxNo != null)
				return false;
		} else if (!dpsTxNo.equals(other.dpsTxNo))
			return false;
		if (infoMnbdyDvsn == null) {
			if (other.infoMnbdyDvsn != null)
				return false;
		} else if (!infoMnbdyDvsn.equals(other.infoMnbdyDvsn))
			return false;
		if (mgntTgmCd == null) {
			if (other.mgntTgmCd != null)
				return false;
		} else if (!mgntTgmCd.equals(other.mgntTgmCd))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (prcsDofOrgNo == null) {
			if (other.prcsDofOrgNo != null)
				return false;
		} else if (!prcsDofOrgNo.equals(other.prcsDofOrgNo))
			return false;
		if (prcsEno == null) {
			if (other.prcsEno != null)
				return false;
		} else if (!prcsEno.equals(other.prcsEno))
			return false;
		if (prcsFofOrgNo == null) {
			if (other.prcsFofOrgNo != null)
				return false;
		} else if (!prcsFofOrgNo.equals(other.prcsFofOrgNo))
			return false;
		if (rcvInstCd == null) {
			if (other.rcvInstCd != null)
				return false;
		} else if (!rcvInstCd.equals(other.rcvInstCd))
			return false;
		if (rrno == null) {
			if (other.rrno != null)
				return false;
		} else if (!rrno.equals(other.rrno))
			return false;
		if (rrnoDvsn == null) {
			if (other.rrnoDvsn != null)
				return false;
		} else if (!rrnoDvsn.equals(other.rrnoDvsn))
			return false;
		if (savgPrdcd == null) {
			if (other.savgPrdcd != null)
				return false;
		} else if (!savgPrdcd.equals(other.savgPrdcd))
			return false;
		if (sndInstCd == null) {
			if (other.sndInstCd != null)
				return false;
		} else if (!sndInstCd.equals(other.sndInstCd))
			return false;
		if (taxpfBzPrcsDcd == null) {
			if (other.taxpfBzPrcsDcd != null)
				return false;
		} else if (!taxpfBzPrcsDcd.equals(other.taxpfBzPrcsDcd))
			return false;
		if (taxpfDupYn == null) {
			if (other.taxpfDupYn != null)
				return false;
		} else if (!taxpfDupYn.equals(other.taxpfDupYn))
			return false;
		if (taxpfTtlLmtAmt == null) {
			if (other.taxpfTtlLmtAmt != null)
				return false;
		} else if (!taxpfTtlLmtAmt.equals(other.taxpfTtlLmtAmt))
			return false;
		if (taxpfUusdLmtAmt == null) {
			if (other.taxpfUusdLmtAmt != null)
				return false;
		} else if (!taxpfUusdLmtAmt.equals(other.taxpfUusdLmtAmt))
			return false;
		if (tgmKndCd == null) {
			if (other.tgmKndCd != null)
				return false;
		} else if (!tgmKndCd.equals(other.tgmKndCd))
			return false;
		if (trnsDtm == null) {
			if (other.trnsDtm != null)
				return false;
		} else if (!trnsDtm.equals(other.trnsDtm))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TaxPfrLmtInqDO [rrno=" + rrno + ", rrnoDvsn=" + rrnoDvsn
				+ ", conm=" + conm + ", name=" + name + ", infoMnbdyDvsn="
				+ infoMnbdyDvsn + ", taxpfDupYn=" + taxpfDupYn
				+ ", taxpfTtlLmtAmt=" + taxpfTtlLmtAmt + ", taxpfUusdLmtAmt="
				+ taxpfUusdLmtAmt + ", dpsTxNo=" + dpsTxNo + ", prcsDofOrgNo="
				+ prcsDofOrgNo + ", prcsFofOrgNo=" + prcsFofOrgNo
				+ ", prcsEno=" + prcsEno + ", contNo=" + contNo
				+ ", savgPrdcd=" + savgPrdcd + ", tgmKndCd=" + tgmKndCd
				+ ", assoBusiGb=" + assoBusiGb + ", trnsDtm=" + trnsDtm
				+ ", mgntTgmCd=" + mgntTgmCd + ", sndInstCd=" + sndInstCd
				+ ", rcvInstCd=" + rcvInstCd + ", assoRspCd=" + assoRspCd
				+ ", taxpfBzPrcsDcd=" + taxpfBzPrcsDcd + "]";
	}

}
