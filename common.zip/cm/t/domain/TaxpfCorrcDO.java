/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Thu Apr 11 20:55:48 KST 2013
 * 
 */
package cigna.cm.t.domain;

import java.io.Serializable;

/**
 * @DataObjectName TaxpfCorrcDO
 * @Description 
 */
public class TaxpfCorrcDO implements Serializable, Cloneable {

	private static final long serialVersionUID = 213402746L;
	/**
	 * @Type java.lang.String
	 * @Name afchRrno
	 * @Description 변경후주민등록번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchRrno;
	/**
	 * @Type java.lang.String
	 * @Name afchRrnoDvsn
	 * @Description 변경후주민등록번호구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchRrnoDvsn;
	/**
	 * @Type java.lang.String
	 * @Name bfchRrno
	 * @Description 변경전주민등록번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchRrno;
	/**
	 * @Type java.lang.String
	 * @Name bfchRrnoDvsn
	 * @Description 변경전주민등록번호구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchRrnoDvsn;
	/**
	 * @Type java.lang.String
	 * @Name afchConm
	 * @Description 변경후상호(기업체명)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchConm;
	/**
	 * @Type java.lang.String
	 * @Name afchName
	 * @Description 변경후성명(대표자)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchName;
	/**
	 * @Type java.lang.String
	 * @Name afchInfoMnbdyDvsn
	 * @Description 변경후정보주체(구장애인)구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchInfoMnbdyDvsn;
	/**
	 * @Type java.lang.String
	 * @Name afchIncmrDvsn
	 * @Description 변경후저소득자구분(농어가저축)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchIncmrDvsn;
	/**
	 * @Type java.lang.String
	 * @Name bfchSavgKnd
	 * @Description 변경전저축종류
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchSavgKnd;
	/**
	 * @Type java.lang.String
	 * @Name bfchOpenOffcCd
	 * @Description 변경전개설점포코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchOpenOffcCd;
	/**
	 * @Type java.lang.String
	 * @Name bfchActNo
	 * @Description 변경전계좌번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchActNo;
	/**
	 * @Type java.lang.String
	 * @Name afchSavgKnd
	 * @Description 변경후저축종류
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchSavgKnd;
	/**
	 * @Type java.lang.String
	 * @Name afchOpenOffcCd
	 * @Description 변경후개설점포코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchOpenOffcCd;
	/**
	 * @Type java.lang.String
	 * @Name afchActNo
	 * @Description 변경후계좌번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchActNo;
	/**
	 * @Type java.lang.String
	 * @Name afchActOpenDy
	 * @Description 변경후계좌개설일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchActOpenDy;
	/**
	 * @Type java.math.BigDecimal
	 * @Name afchTaxpfAmt
	 * @Description 변경후세금우대금액
	 * @Length 0
	 * @Decimal 0
	 */
	private java.math.BigDecimal afchTaxpfAmt;
	/**
	 * @Type java.lang.String
	 * @Name afchExpiDy
	 * @Description 변경후만기일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchExpiDy;
	/**
	 * @Type java.lang.String
	 * @Name afchFstExpiExtnDy
	 * @Description 변경후최초만기연장일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchFstExpiExtnDy;
	/**
	 * @Type java.math.BigDecimal
	 * @Name afchIntDivdAmt
	 * @Description 변경후이자,배당지급액
	 * @Length 0
	 * @Decimal 0
	 */
	private java.math.BigDecimal afchIntDivdAmt;
	/**
	 * @Type java.lang.String
	 * @Name afchRescsKnd
	 * @Description 변경후해지종류
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchRescsKnd;
	/**
	 * @Type java.lang.String
	 * @Name afchInhrtYn
	 * @Description 변경후상속여부
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchInhrtYn;
	/**
	 * @Type java.lang.String
	 * @Name afchHousPrpsDvsn
	 * @Description 변경후주택청약예부금구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchHousPrpsDvsn;
	/**
	 * @Type java.lang.String
	 * @Name afchRrnoErr
	 * @Description 주민등록번호:변경후Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchRrnoErr;
	/**
	 * @Type java.lang.String
	 * @Name afchRrnoDvsnErr
	 * @Description 주민등록번호구분:변경후Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchRrnoDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name bfchRrnoErr
	 * @Description 변경전주민등록번호Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchRrnoErr;
	/**
	 * @Type java.lang.String
	 * @Name bfchRrnoDvsnErr
	 * @Description 변경전주민등록번호구분Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchRrnoDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name afchConmErr
	 * @Description 기업체명:변경후Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchConmErr;
	/**
	 * @Type java.lang.String
	 * @Name afchNameErr
	 * @Description 성명:변경후Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchNameErr;
	/**
	 * @Type java.lang.String
	 * @Name afchInfoMnbdyDvsnErr
	 * @Description 정보주체구분:변경후Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchInfoMnbdyDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name afchIncmrDvsnErr
	 * @Description 저소득자구분:변경후Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchIncmrDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name bfchSavgKndErr
	 * @Description 변경전저축종류Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchSavgKndErr;
	/**
	 * @Type java.lang.String
	 * @Name bfchOffcCdErr
	 * @Description 변경전점포코드Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchOffcCdErr;
	/**
	 * @Type java.lang.String
	 * @Name bfchActNoErr
	 * @Description 변경전계좌번호Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String bfchActNoErr;
	/**
	 * @Type java.lang.String
	 * @Name afchSavgKndErr
	 * @Description 변경후저축종류Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchSavgKndErr;
	/**
	 * @Type java.lang.String
	 * @Name afchOffcCdErr
	 * @Description 변경후점포코드Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchOffcCdErr;
	/**
	 * @Type java.lang.String
	 * @Name afchActNoErr
	 * @Description 변경후계좌번호Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchActNoErr;
	/**
	 * @Type java.lang.String
	 * @Name afchActOpenDyErr
	 * @Description 변경후계좌개설일Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchActOpenDyErr;
	/**
	 * @Type java.lang.String
	 * @Name afchTaxpfAmtErr
	 * @Description 변경후세금우대금액Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchTaxpfAmtErr;
	/**
	 * @Type java.lang.String
	 * @Name afchExpiDyErr
	 * @Description 변경후만기일Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchExpiDyErr;
	/**
	 * @Type java.lang.String
	 * @Name afchFstExpiExtnDyErr
	 * @Description 변경후최초만기연장일Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchFstExpiExtnDyErr;
	/**
	 * @Type java.lang.String
	 * @Name afchIntDivdAmtErr
	 * @Description 변경후이자,배당지급액Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchIntDivdAmtErr;
	/**
	 * @Type java.lang.String
	 * @Name afchRescsKndErr
	 * @Description 변경후해지종류Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchRescsKndErr;
	/**
	 * @Type java.lang.String
	 * @Name afchInhrtYnErr
	 * @Description 변경후상속여부Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchInhrtYnErr;
	/**
	 * @Type java.lang.String
	 * @Name afchHousPrpsDvsnErr
	 * @Description 변경후주택청약예부금구분Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String afchHousPrpsDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name dpsTxNo
	 * @Description 입금거래번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String dpsTxNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsDofOrgNo
	 * @Description 처리지점조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsDofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsFofOrgNo
	 * @Description 처리지점소조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsFofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsEno
	 * @Description 처리사원번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsEno;
	
	/**
	 * @Type java.lang.String
	 * @Name contNo
	 * @Description 계약번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String contNo;
	
	/**
	 * @Type java.lang.String
	 * @Name savgPrdcd
	 * @Description 저축상품코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgPrdcd;
	/**
	 * @Type java.lang.String
	 * @Name tgmKndCd
	 * @Description 전문종별코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String tgmKndCd;
	/**
	 * @Type java.lang.String
	 * @Name assoBusiGb
	 * @Description 협회업무구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String assoBusiGb;
	/**
	 * @Type java.lang.String
	 * @Name trnsDtm
	 * @Description 전문전송일시
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String trnsDtm;
	/**
	 * @Type java.lang.String
	 * @Name mgntTgmCd
	 * @Description 전문관리번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String mgntTgmCd;
	/**
	 * @Type java.lang.String
	 * @Name sndInstCd
	 * @Description 전송기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String sndInstCd;
	/**
	 * @Type java.lang.String
	 * @Name rcvInstCd
	 * @Description 수신기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rcvInstCd;
	/**
	 * @Type java.lang.String
	 * @Name assoRspCd
	 * @Description 협회응답코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String assoRspCd;

	/**
	 * @Type java.lang.String
	 * @Name taxpfBzPrcsDcd
	 * @Description 세금우대업무처리구분코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String taxpfBzPrcsDcd;

	/**
	 * @return the taxpfBzPrcsDcd
	 */
	public java.lang.String getTaxpfBzPrcsDcd() {
		return taxpfBzPrcsDcd;
	}

	/**
	 * @param taxpfBzPrcsDcd the taxpfBzPrcsDcd to set
	 */
	public void setTaxpfBzPrcsDcd(java.lang.String taxpfBzPrcsDcd) {
		this.taxpfBzPrcsDcd = taxpfBzPrcsDcd;
	}
	/**
	 * @return the tgmKndCd
	 */
	public java.lang.String getTgmKndCd() {
		return tgmKndCd;
	}

	/**
	 * @param tgmKndCd the tgmKndCd to set
	 */
	public void setTgmKndCd(java.lang.String tgmKndCd) {
		this.tgmKndCd = tgmKndCd;
	}

	/**
	 * @return the assoBusiGb
	 */
	public java.lang.String getAssoBusiGb() {
		return assoBusiGb;
	}

	/**
	 * @param assoBusiGb the assoBusiGb to set
	 */
	public void setAssoBusiGb(java.lang.String assoBusiGb) {
		this.assoBusiGb = assoBusiGb;
	}

	/**
	 * @return the trnsDtm
	 */
	public java.lang.String getTrnsDtm() {
		return trnsDtm;
	}

	/**
	 * @param trnsDtm the trnsDtm to set
	 */
	public void setTrnsDtm(java.lang.String trnsDtm) {
		this.trnsDtm = trnsDtm;
	}

	/**
	 * @return the mgntTgmCd
	 */
	public java.lang.String getMgntTgmCd() {
		return mgntTgmCd;
	}

	/**
	 * @param mgntTgmCd the mgntTgmCd to set
	 */
	public void setMgntTgmCd(java.lang.String mgntTgmCd) {
		this.mgntTgmCd = mgntTgmCd;
	}

	/**
	 * @return the sndInstCd
	 */
	public java.lang.String getSndInstCd() {
		return sndInstCd;
	}

	/**
	 * @param sndInstCd the sndInstCd to set
	 */
	public void setSndInstCd(java.lang.String sndInstCd) {
		this.sndInstCd = sndInstCd;
	}

	/**
	 * @return the rcvInstCd
	 */
	public java.lang.String getRcvInstCd() {
		return rcvInstCd;
	}

	/**
	 * @param rcvInstCd the rcvInstCd to set
	 */
	public void setRcvInstCd(java.lang.String rcvInstCd) {
		this.rcvInstCd = rcvInstCd;
	}

	/**
	 * @return the assoRspCd
	 */
	public java.lang.String getAssoRspCd() {
		return assoRspCd;
	}

	/**
	 * @param assoRspCd the assoRspCd to set
	 */
	public void setAssoRspCd(java.lang.String assoRspCd) {
		this.assoRspCd = assoRspCd;
	}

	/**
	 * GET 변경후주민등록번호
	 */
	public java.lang.String getAfchRrno() {
		return this.afchRrno;
	}

	/**
	 * SET 변경후주민등록번호
	 */
	public void setAfchRrno(java.lang.String afchRrno) {
		this.afchRrno = afchRrno;
	}

	/**
	 * GET 변경후주민등록번호구분
	 */
	public java.lang.String getAfchRrnoDvsn() {
		return this.afchRrnoDvsn;
	}

	/**
	 * SET 변경후주민등록번호구분
	 */
	public void setAfchRrnoDvsn(java.lang.String afchRrnoDvsn) {
		this.afchRrnoDvsn = afchRrnoDvsn;
	}

	/**
	 * GET 변경전주민등록번호
	 */
	public java.lang.String getBfchRrno() {
		return this.bfchRrno;
	}

	/**
	 * SET 변경전주민등록번호
	 */
	public void setBfchRrno(java.lang.String bfchRrno) {
		this.bfchRrno = bfchRrno;
	}

	/**
	 * GET 변경전주민등록번호구분
	 */
	public java.lang.String getBfchRrnoDvsn() {
		return this.bfchRrnoDvsn;
	}

	/**
	 * SET 변경전주민등록번호구분
	 */
	public void setBfchRrnoDvsn(java.lang.String bfchRrnoDvsn) {
		this.bfchRrnoDvsn = bfchRrnoDvsn;
	}

	/**
	 * GET 변경후상호(기업체명)
	 */
	public java.lang.String getAfchConm() {
		return this.afchConm;
	}

	/**
	 * SET 변경후상호(기업체명)
	 */
	public void setAfchConm(java.lang.String afchConm) {
		this.afchConm = afchConm;
	}

	/**
	 * GET 변경후성명(대표자)
	 */
	public java.lang.String getAfchName() {
		return this.afchName;
	}

	/**
	 * SET 변경후성명(대표자)
	 */
	public void setAfchName(java.lang.String afchName) {
		this.afchName = afchName;
	}

	/**
	 * GET 변경후정보주체(구장애인)구분
	 */
	public java.lang.String getAfchInfoMnbdyDvsn() {
		return this.afchInfoMnbdyDvsn;
	}

	/**
	 * SET 변경후정보주체(구장애인)구분
	 */
	public void setAfchInfoMnbdyDvsn(java.lang.String afchInfoMnbdyDvsn) {
		this.afchInfoMnbdyDvsn = afchInfoMnbdyDvsn;
	}

	/**
	 * GET 변경후저소득자구분(농어가저축)
	 */
	public java.lang.String getAfchIncmrDvsn() {
		return this.afchIncmrDvsn;
	}

	/**
	 * SET 변경후저소득자구분(농어가저축)
	 */
	public void setAfchIncmrDvsn(java.lang.String afchIncmrDvsn) {
		this.afchIncmrDvsn = afchIncmrDvsn;
	}

	/**
	 * GET 변경전저축종류
	 */
	public java.lang.String getBfchSavgKnd() {
		return this.bfchSavgKnd;
	}

	/**
	 * SET 변경전저축종류
	 */
	public void setBfchSavgKnd(java.lang.String bfchSavgKnd) {
		this.bfchSavgKnd = bfchSavgKnd;
	}

	/**
	 * GET 변경전개설점포코드
	 */
	public java.lang.String getBfchOpenOffcCd() {
		return this.bfchOpenOffcCd;
	}

	/**
	 * SET 변경전개설점포코드
	 */
	public void setBfchOpenOffcCd(java.lang.String bfchOpenOffcCd) {
		this.bfchOpenOffcCd = bfchOpenOffcCd;
	}

	/**
	 * GET 변경전계좌번호
	 */
	public java.lang.String getBfchActNo() {
		return this.bfchActNo;
	}

	/**
	 * SET 변경전계좌번호
	 */
	public void setBfchActNo(java.lang.String bfchActNo) {
		this.bfchActNo = bfchActNo;
	}

	/**
	 * GET 변경후저축종류
	 */
	public java.lang.String getAfchSavgKnd() {
		return this.afchSavgKnd;
	}

	/**
	 * SET 변경후저축종류
	 */
	public void setAfchSavgKnd(java.lang.String afchSavgKnd) {
		this.afchSavgKnd = afchSavgKnd;
	}

	/**
	 * GET 변경후개설점포코드
	 */
	public java.lang.String getAfchOpenOffcCd() {
		return this.afchOpenOffcCd;
	}

	/**
	 * SET 변경후개설점포코드
	 */
	public void setAfchOpenOffcCd(java.lang.String afchOpenOffcCd) {
		this.afchOpenOffcCd = afchOpenOffcCd;
	}

	/**
	 * GET 변경후계좌번호
	 */
	public java.lang.String getAfchActNo() {
		return this.afchActNo;
	}

	/**
	 * SET 변경후계좌번호
	 */
	public void setAfchActNo(java.lang.String afchActNo) {
		this.afchActNo = afchActNo;
	}

	/**
	 * GET 변경후계좌개설일
	 */
	public java.lang.String getAfchActOpenDy() {
		return this.afchActOpenDy;
	}

	/**
	 * SET 변경후계좌개설일
	 */
	public void setAfchActOpenDy(java.lang.String afchActOpenDy) {
		this.afchActOpenDy = afchActOpenDy;
	}

	/**
	 * GET 변경후세금우대금액
	 */
	public java.math.BigDecimal getAfchTaxpfAmt() {
		return this.afchTaxpfAmt;
	}

	/**
	 * SET 변경후세금우대금액
	 */
	public void setAfchTaxpfAmt(java.math.BigDecimal afchTaxpfAmt) {
		this.afchTaxpfAmt = afchTaxpfAmt;
	}

	/**
	 * GET 변경후만기일
	 */
	public java.lang.String getAfchExpiDy() {
		return this.afchExpiDy;
	}

	/**
	 * SET 변경후만기일
	 */
	public void setAfchExpiDy(java.lang.String afchExpiDy) {
		this.afchExpiDy = afchExpiDy;
	}

	/**
	 * GET 변경후최초만기연장일
	 */
	public java.lang.String getAfchFstExpiExtnDy() {
		return this.afchFstExpiExtnDy;
	}

	/**
	 * SET 변경후최초만기연장일
	 */
	public void setAfchFstExpiExtnDy(java.lang.String afchFstExpiExtnDy) {
		this.afchFstExpiExtnDy = afchFstExpiExtnDy;
	}

	/**
	 * GET 변경후이자,배당지급액
	 */
	public java.math.BigDecimal getAfchIntDivdAmt() {
		return this.afchIntDivdAmt;
	}

	/**
	 * SET 변경후이자,배당지급액
	 */
	public void setAfchIntDivdAmt(java.math.BigDecimal afchIntDivdAmt) {
		this.afchIntDivdAmt = afchIntDivdAmt;
	}

	/**
	 * GET 변경후해지종류
	 */
	public java.lang.String getAfchRescsKnd() {
		return this.afchRescsKnd;
	}

	/**
	 * SET 변경후해지종류
	 */
	public void setAfchRescsKnd(java.lang.String afchRescsKnd) {
		this.afchRescsKnd = afchRescsKnd;
	}

	/**
	 * GET 변경후상속여부
	 */
	public java.lang.String getAfchInhrtYn() {
		return this.afchInhrtYn;
	}

	/**
	 * SET 변경후상속여부
	 */
	public void setAfchInhrtYn(java.lang.String afchInhrtYn) {
		this.afchInhrtYn = afchInhrtYn;
	}

	/**
	 * GET 변경후주택청약예부금구분
	 */
	public java.lang.String getAfchHousPrpsDvsn() {
		return this.afchHousPrpsDvsn;
	}

	/**
	 * SET 변경후주택청약예부금구분
	 */
	public void setAfchHousPrpsDvsn(java.lang.String afchHousPrpsDvsn) {
		this.afchHousPrpsDvsn = afchHousPrpsDvsn;
	}

	/**
	 * GET 주민등록번호:변경후Error
	 */
	public java.lang.String getAfchRrnoErr() {
		return this.afchRrnoErr;
	}

	/**
	 * SET 주민등록번호:변경후Error
	 */
	public void setAfchRrnoErr(java.lang.String afchRrnoErr) {
		this.afchRrnoErr = afchRrnoErr;
	}

	/**
	 * GET 주민등록번호구분:변경후Error
	 */
	public java.lang.String getAfchRrnoDvsnErr() {
		return this.afchRrnoDvsnErr;
	}

	/**
	 * SET 주민등록번호구분:변경후Error
	 */
	public void setAfchRrnoDvsnErr(java.lang.String afchRrnoDvsnErr) {
		this.afchRrnoDvsnErr = afchRrnoDvsnErr;
	}

	/**
	 * GET 변경전주민등록번호Error
	 */
	public java.lang.String getBfchRrnoErr() {
		return this.bfchRrnoErr;
	}

	/**
	 * SET 변경전주민등록번호Error
	 */
	public void setBfchRrnoErr(java.lang.String bfchRrnoErr) {
		this.bfchRrnoErr = bfchRrnoErr;
	}

	/**
	 * GET 변경전주민등록번호구분Error
	 */
	public java.lang.String getBfchRrnoDvsnErr() {
		return this.bfchRrnoDvsnErr;
	}

	/**
	 * SET 변경전주민등록번호구분Error
	 */
	public void setBfchRrnoDvsnErr(java.lang.String bfchRrnoDvsnErr) {
		this.bfchRrnoDvsnErr = bfchRrnoDvsnErr;
	}

	/**
	 * GET 기업체명:변경후Error
	 */
	public java.lang.String getAfchConmErr() {
		return this.afchConmErr;
	}

	/**
	 * SET 기업체명:변경후Error
	 */
	public void setAfchConmErr(java.lang.String afchConmErr) {
		this.afchConmErr = afchConmErr;
	}

	/**
	 * GET 성명:변경후Error
	 */
	public java.lang.String getAfchNameErr() {
		return this.afchNameErr;
	}

	/**
	 * SET 성명:변경후Error
	 */
	public void setAfchNameErr(java.lang.String afchNameErr) {
		this.afchNameErr = afchNameErr;
	}

	/**
	 * GET 정보주체구분:변경후Error
	 */
	public java.lang.String getAfchInfoMnbdyDvsnErr() {
		return this.afchInfoMnbdyDvsnErr;
	}

	/**
	 * SET 정보주체구분:변경후Error
	 */
	public void setAfchInfoMnbdyDvsnErr(java.lang.String afchInfoMnbdyDvsnErr) {
		this.afchInfoMnbdyDvsnErr = afchInfoMnbdyDvsnErr;
	}

	/**
	 * GET 저소득자구분:변경후Error
	 */
	public java.lang.String getAfchIncmrDvsnErr() {
		return this.afchIncmrDvsnErr;
	}

	/**
	 * SET 저소득자구분:변경후Error
	 */
	public void setAfchIncmrDvsnErr(java.lang.String afchIncmrDvsnErr) {
		this.afchIncmrDvsnErr = afchIncmrDvsnErr;
	}

	/**
	 * GET 변경전저축종류Error
	 */
	public java.lang.String getBfchSavgKndErr() {
		return this.bfchSavgKndErr;
	}

	/**
	 * SET 변경전저축종류Error
	 */
	public void setBfchSavgKndErr(java.lang.String bfchSavgKndErr) {
		this.bfchSavgKndErr = bfchSavgKndErr;
	}

	/**
	 * GET 변경전점포코드Error
	 */
	public java.lang.String getBfchOffcCdErr() {
		return this.bfchOffcCdErr;
	}

	/**
	 * SET 변경전점포코드Error
	 */
	public void setBfchOffcCdErr(java.lang.String bfchOffcCdErr) {
		this.bfchOffcCdErr = bfchOffcCdErr;
	}

	/**
	 * GET 변경전계좌번호Error
	 */
	public java.lang.String getBfchActNoErr() {
		return this.bfchActNoErr;
	}

	/**
	 * SET 변경전계좌번호Error
	 */
	public void setBfchActNoErr(java.lang.String bfchActNoErr) {
		this.bfchActNoErr = bfchActNoErr;
	}

	/**
	 * GET 변경후저축종류Error
	 */
	public java.lang.String getAfchSavgKndErr() {
		return this.afchSavgKndErr;
	}

	/**
	 * SET 변경후저축종류Error
	 */
	public void setAfchSavgKndErr(java.lang.String afchSavgKndErr) {
		this.afchSavgKndErr = afchSavgKndErr;
	}

	/**
	 * GET 변경후점포코드Error
	 */
	public java.lang.String getAfchOffcCdErr() {
		return this.afchOffcCdErr;
	}

	/**
	 * SET 변경후점포코드Error
	 */
	public void setAfchOffcCdErr(java.lang.String afchOffcCdErr) {
		this.afchOffcCdErr = afchOffcCdErr;
	}

	/**
	 * GET 변경후계좌번호Error
	 */
	public java.lang.String getAfchActNoErr() {
		return this.afchActNoErr;
	}

	/**
	 * SET 변경후계좌번호Error
	 */
	public void setAfchActNoErr(java.lang.String afchActNoErr) {
		this.afchActNoErr = afchActNoErr;
	}

	/**
	 * GET 변경후계좌개설일Error
	 */
	public java.lang.String getAfchActOpenDyErr() {
		return this.afchActOpenDyErr;
	}

	/**
	 * SET 변경후계좌개설일Error
	 */
	public void setAfchActOpenDyErr(java.lang.String afchActOpenDyErr) {
		this.afchActOpenDyErr = afchActOpenDyErr;
	}

	/**
	 * GET 변경후세금우대금액Error
	 */
	public java.lang.String getAfchTaxpfAmtErr() {
		return this.afchTaxpfAmtErr;
	}

	/**
	 * SET 변경후세금우대금액Error
	 */
	public void setAfchTaxpfAmtErr(java.lang.String afchTaxpfAmtErr) {
		this.afchTaxpfAmtErr = afchTaxpfAmtErr;
	}

	/**
	 * GET 변경후만기일Error
	 */
	public java.lang.String getAfchExpiDyErr() {
		return this.afchExpiDyErr;
	}

	/**
	 * SET 변경후만기일Error
	 */
	public void setAfchExpiDyErr(java.lang.String afchExpiDyErr) {
		this.afchExpiDyErr = afchExpiDyErr;
	}

	/**
	 * GET 변경후최초만기연장일Error
	 */
	public java.lang.String getAfchFstExpiExtnDyErr() {
		return this.afchFstExpiExtnDyErr;
	}

	/**
	 * SET 변경후최초만기연장일Error
	 */
	public void setAfchFstExpiExtnDyErr(java.lang.String afchFstExpiExtnDyErr) {
		this.afchFstExpiExtnDyErr = afchFstExpiExtnDyErr;
	}

	/**
	 * GET 변경후이자,배당지급액Error
	 */
	public java.lang.String getAfchIntDivdAmtErr() {
		return this.afchIntDivdAmtErr;
	}

	/**
	 * SET 변경후이자,배당지급액Error
	 */
	public void setAfchIntDivdAmtErr(java.lang.String afchIntDivdAmtErr) {
		this.afchIntDivdAmtErr = afchIntDivdAmtErr;
	}

	/**
	 * GET 변경후해지종류Error
	 */
	public java.lang.String getAfchRescsKndErr() {
		return this.afchRescsKndErr;
	}

	/**
	 * SET 변경후해지종류Error
	 */
	public void setAfchRescsKndErr(java.lang.String afchRescsKndErr) {
		this.afchRescsKndErr = afchRescsKndErr;
	}

	/**
	 * GET 변경후상속여부Error
	 */
	public java.lang.String getAfchInhrtYnErr() {
		return this.afchInhrtYnErr;
	}

	/**
	 * SET 변경후상속여부Error
	 */
	public void setAfchInhrtYnErr(java.lang.String afchInhrtYnErr) {
		this.afchInhrtYnErr = afchInhrtYnErr;
	}

	/**
	 * GET 변경후주택청약예부금구분Error
	 */
	public java.lang.String getAfchHousPrpsDvsnErr() {
		return this.afchHousPrpsDvsnErr;
	}

	/**
	 * SET 변경후주택청약예부금구분Error
	 */
	public void setAfchHousPrpsDvsnErr(java.lang.String afchHousPrpsDvsnErr) {
		this.afchHousPrpsDvsnErr = afchHousPrpsDvsnErr;
	}

	/**
	 * @return the dpsTxNo
	 */
	public java.lang.String getDpsTxNo() {
		return dpsTxNo;
	}

	/**
	 * @param dpsTxNo the dpsTxNo to set
	 */
	public void setDpsTxNo(java.lang.String dpsTxNo) {
		this.dpsTxNo = dpsTxNo;
	}

	/**
	 * @return the prcsDofOrgNo
	 */
	public java.lang.String getPrcsDofOrgNo() {
		return prcsDofOrgNo;
	}

	/**
	 * @param prcsDofOrgNo the prcsDofOrgNo to set
	 */
	public void setPrcsDofOrgNo(java.lang.String prcsDofOrgNo) {
		this.prcsDofOrgNo = prcsDofOrgNo;
	}

	/**
	 * @return the prcsFofOrgNo
	 */
	public java.lang.String getPrcsFofOrgNo() {
		return prcsFofOrgNo;
	}

	/**
	 * @param prcsFofOrgNo the prcsFofOrgNo to set
	 */
	public void setPrcsFofOrgNo(java.lang.String prcsFofOrgNo) {
		this.prcsFofOrgNo = prcsFofOrgNo;
	}

	/**
	 * @return the prcsEno
	 */
	public java.lang.String getPrcsEno() {
		return prcsEno;
	}

	/**
	 * @param prcsEno the prcsEno to set
	 */
	public void setPrcsEno(java.lang.String prcsEno) {
		this.prcsEno = prcsEno;
	}

	/**
	 * @return the contNo
	 */
	public java.lang.String getContNo() {
		return contNo;
	}

	/**
	 * @param contNo the contNo to set
	 */
	public void setContNo(java.lang.String contNo) {
		this.contNo = contNo;
	}

	/**
	 * @return the savgPrdcd
	 */
	public java.lang.String getSavgPrdcd() {
		return savgPrdcd;
	}

	/**
	 * @param savgPrdcd the savgPrdcd to set
	 */
	public void setSavgPrdcd(java.lang.String savgPrdcd) {
		this.savgPrdcd = savgPrdcd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((afchActNo == null) ? 0 : afchActNo.hashCode());
		result = prime * result
				+ ((afchActNoErr == null) ? 0 : afchActNoErr.hashCode());
		result = prime * result
				+ ((afchActOpenDy == null) ? 0 : afchActOpenDy.hashCode());
		result = prime
				* result
				+ ((afchActOpenDyErr == null) ? 0 : afchActOpenDyErr.hashCode());
		result = prime * result
				+ ((afchConm == null) ? 0 : afchConm.hashCode());
		result = prime * result
				+ ((afchConmErr == null) ? 0 : afchConmErr.hashCode());
		result = prime * result
				+ ((afchExpiDy == null) ? 0 : afchExpiDy.hashCode());
		result = prime * result
				+ ((afchExpiDyErr == null) ? 0 : afchExpiDyErr.hashCode());
		result = prime
				* result
				+ ((afchFstExpiExtnDy == null) ? 0 : afchFstExpiExtnDy
						.hashCode());
		result = prime
				* result
				+ ((afchFstExpiExtnDyErr == null) ? 0 : afchFstExpiExtnDyErr
						.hashCode());
		result = prime
				* result
				+ ((afchHousPrpsDvsn == null) ? 0 : afchHousPrpsDvsn.hashCode());
		result = prime
				* result
				+ ((afchHousPrpsDvsnErr == null) ? 0 : afchHousPrpsDvsnErr
						.hashCode());
		result = prime * result
				+ ((afchIncmrDvsn == null) ? 0 : afchIncmrDvsn.hashCode());
		result = prime
				* result
				+ ((afchIncmrDvsnErr == null) ? 0 : afchIncmrDvsnErr.hashCode());
		result = prime
				* result
				+ ((afchInfoMnbdyDvsn == null) ? 0 : afchInfoMnbdyDvsn
						.hashCode());
		result = prime
				* result
				+ ((afchInfoMnbdyDvsnErr == null) ? 0 : afchInfoMnbdyDvsnErr
						.hashCode());
		result = prime * result
				+ ((afchInhrtYn == null) ? 0 : afchInhrtYn.hashCode());
		result = prime * result
				+ ((afchInhrtYnErr == null) ? 0 : afchInhrtYnErr.hashCode());
		result = prime * result
				+ ((afchIntDivdAmt == null) ? 0 : afchIntDivdAmt.hashCode());
		result = prime
				* result
				+ ((afchIntDivdAmtErr == null) ? 0 : afchIntDivdAmtErr
						.hashCode());
		result = prime * result
				+ ((afchName == null) ? 0 : afchName.hashCode());
		result = prime * result
				+ ((afchNameErr == null) ? 0 : afchNameErr.hashCode());
		result = prime * result
				+ ((afchOffcCdErr == null) ? 0 : afchOffcCdErr.hashCode());
		result = prime * result
				+ ((afchOpenOffcCd == null) ? 0 : afchOpenOffcCd.hashCode());
		result = prime * result
				+ ((afchRescsKnd == null) ? 0 : afchRescsKnd.hashCode());
		result = prime * result
				+ ((afchRescsKndErr == null) ? 0 : afchRescsKndErr.hashCode());
		result = prime * result
				+ ((afchRrno == null) ? 0 : afchRrno.hashCode());
		result = prime * result
				+ ((afchRrnoDvsn == null) ? 0 : afchRrnoDvsn.hashCode());
		result = prime * result
				+ ((afchRrnoDvsnErr == null) ? 0 : afchRrnoDvsnErr.hashCode());
		result = prime * result
				+ ((afchRrnoErr == null) ? 0 : afchRrnoErr.hashCode());
		result = prime * result
				+ ((afchSavgKnd == null) ? 0 : afchSavgKnd.hashCode());
		result = prime * result
				+ ((afchSavgKndErr == null) ? 0 : afchSavgKndErr.hashCode());
		result = prime * result
				+ ((afchTaxpfAmt == null) ? 0 : afchTaxpfAmt.hashCode());
		result = prime * result
				+ ((afchTaxpfAmtErr == null) ? 0 : afchTaxpfAmtErr.hashCode());
		result = prime * result
				+ ((assoBusiGb == null) ? 0 : assoBusiGb.hashCode());
		result = prime * result
				+ ((assoRspCd == null) ? 0 : assoRspCd.hashCode());
		result = prime * result
				+ ((bfchActNo == null) ? 0 : bfchActNo.hashCode());
		result = prime * result
				+ ((bfchActNoErr == null) ? 0 : bfchActNoErr.hashCode());
		result = prime * result
				+ ((bfchOffcCdErr == null) ? 0 : bfchOffcCdErr.hashCode());
		result = prime * result
				+ ((bfchOpenOffcCd == null) ? 0 : bfchOpenOffcCd.hashCode());
		result = prime * result
				+ ((bfchRrno == null) ? 0 : bfchRrno.hashCode());
		result = prime * result
				+ ((bfchRrnoDvsn == null) ? 0 : bfchRrnoDvsn.hashCode());
		result = prime * result
				+ ((bfchRrnoDvsnErr == null) ? 0 : bfchRrnoDvsnErr.hashCode());
		result = prime * result
				+ ((bfchRrnoErr == null) ? 0 : bfchRrnoErr.hashCode());
		result = prime * result
				+ ((bfchSavgKnd == null) ? 0 : bfchSavgKnd.hashCode());
		result = prime * result
				+ ((bfchSavgKndErr == null) ? 0 : bfchSavgKndErr.hashCode());
		result = prime * result + ((contNo == null) ? 0 : contNo.hashCode());
		result = prime * result + ((dpsTxNo == null) ? 0 : dpsTxNo.hashCode());
		result = prime * result
				+ ((mgntTgmCd == null) ? 0 : mgntTgmCd.hashCode());
		result = prime * result
				+ ((prcsDofOrgNo == null) ? 0 : prcsDofOrgNo.hashCode());
		result = prime * result + ((prcsEno == null) ? 0 : prcsEno.hashCode());
		result = prime * result
				+ ((prcsFofOrgNo == null) ? 0 : prcsFofOrgNo.hashCode());
		result = prime * result
				+ ((rcvInstCd == null) ? 0 : rcvInstCd.hashCode());
		result = prime * result
				+ ((savgPrdcd == null) ? 0 : savgPrdcd.hashCode());
		result = prime * result
				+ ((sndInstCd == null) ? 0 : sndInstCd.hashCode());
		result = prime * result
				+ ((taxpfBzPrcsDcd == null) ? 0 : taxpfBzPrcsDcd.hashCode());
		result = prime * result
				+ ((tgmKndCd == null) ? 0 : tgmKndCd.hashCode());
		result = prime * result + ((trnsDtm == null) ? 0 : trnsDtm.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxpfCorrcDO other = (TaxpfCorrcDO) obj;
		if (afchActNo == null) {
			if (other.afchActNo != null)
				return false;
		} else if (!afchActNo.equals(other.afchActNo))
			return false;
		if (afchActNoErr == null) {
			if (other.afchActNoErr != null)
				return false;
		} else if (!afchActNoErr.equals(other.afchActNoErr))
			return false;
		if (afchActOpenDy == null) {
			if (other.afchActOpenDy != null)
				return false;
		} else if (!afchActOpenDy.equals(other.afchActOpenDy))
			return false;
		if (afchActOpenDyErr == null) {
			if (other.afchActOpenDyErr != null)
				return false;
		} else if (!afchActOpenDyErr.equals(other.afchActOpenDyErr))
			return false;
		if (afchConm == null) {
			if (other.afchConm != null)
				return false;
		} else if (!afchConm.equals(other.afchConm))
			return false;
		if (afchConmErr == null) {
			if (other.afchConmErr != null)
				return false;
		} else if (!afchConmErr.equals(other.afchConmErr))
			return false;
		if (afchExpiDy == null) {
			if (other.afchExpiDy != null)
				return false;
		} else if (!afchExpiDy.equals(other.afchExpiDy))
			return false;
		if (afchExpiDyErr == null) {
			if (other.afchExpiDyErr != null)
				return false;
		} else if (!afchExpiDyErr.equals(other.afchExpiDyErr))
			return false;
		if (afchFstExpiExtnDy == null) {
			if (other.afchFstExpiExtnDy != null)
				return false;
		} else if (!afchFstExpiExtnDy.equals(other.afchFstExpiExtnDy))
			return false;
		if (afchFstExpiExtnDyErr == null) {
			if (other.afchFstExpiExtnDyErr != null)
				return false;
		} else if (!afchFstExpiExtnDyErr.equals(other.afchFstExpiExtnDyErr))
			return false;
		if (afchHousPrpsDvsn == null) {
			if (other.afchHousPrpsDvsn != null)
				return false;
		} else if (!afchHousPrpsDvsn.equals(other.afchHousPrpsDvsn))
			return false;
		if (afchHousPrpsDvsnErr == null) {
			if (other.afchHousPrpsDvsnErr != null)
				return false;
		} else if (!afchHousPrpsDvsnErr.equals(other.afchHousPrpsDvsnErr))
			return false;
		if (afchIncmrDvsn == null) {
			if (other.afchIncmrDvsn != null)
				return false;
		} else if (!afchIncmrDvsn.equals(other.afchIncmrDvsn))
			return false;
		if (afchIncmrDvsnErr == null) {
			if (other.afchIncmrDvsnErr != null)
				return false;
		} else if (!afchIncmrDvsnErr.equals(other.afchIncmrDvsnErr))
			return false;
		if (afchInfoMnbdyDvsn == null) {
			if (other.afchInfoMnbdyDvsn != null)
				return false;
		} else if (!afchInfoMnbdyDvsn.equals(other.afchInfoMnbdyDvsn))
			return false;
		if (afchInfoMnbdyDvsnErr == null) {
			if (other.afchInfoMnbdyDvsnErr != null)
				return false;
		} else if (!afchInfoMnbdyDvsnErr.equals(other.afchInfoMnbdyDvsnErr))
			return false;
		if (afchInhrtYn == null) {
			if (other.afchInhrtYn != null)
				return false;
		} else if (!afchInhrtYn.equals(other.afchInhrtYn))
			return false;
		if (afchInhrtYnErr == null) {
			if (other.afchInhrtYnErr != null)
				return false;
		} else if (!afchInhrtYnErr.equals(other.afchInhrtYnErr))
			return false;
		if (afchIntDivdAmt == null) {
			if (other.afchIntDivdAmt != null)
				return false;
		} else if (!afchIntDivdAmt.equals(other.afchIntDivdAmt))
			return false;
		if (afchIntDivdAmtErr == null) {
			if (other.afchIntDivdAmtErr != null)
				return false;
		} else if (!afchIntDivdAmtErr.equals(other.afchIntDivdAmtErr))
			return false;
		if (afchName == null) {
			if (other.afchName != null)
				return false;
		} else if (!afchName.equals(other.afchName))
			return false;
		if (afchNameErr == null) {
			if (other.afchNameErr != null)
				return false;
		} else if (!afchNameErr.equals(other.afchNameErr))
			return false;
		if (afchOffcCdErr == null) {
			if (other.afchOffcCdErr != null)
				return false;
		} else if (!afchOffcCdErr.equals(other.afchOffcCdErr))
			return false;
		if (afchOpenOffcCd == null) {
			if (other.afchOpenOffcCd != null)
				return false;
		} else if (!afchOpenOffcCd.equals(other.afchOpenOffcCd))
			return false;
		if (afchRescsKnd == null) {
			if (other.afchRescsKnd != null)
				return false;
		} else if (!afchRescsKnd.equals(other.afchRescsKnd))
			return false;
		if (afchRescsKndErr == null) {
			if (other.afchRescsKndErr != null)
				return false;
		} else if (!afchRescsKndErr.equals(other.afchRescsKndErr))
			return false;
		if (afchRrno == null) {
			if (other.afchRrno != null)
				return false;
		} else if (!afchRrno.equals(other.afchRrno))
			return false;
		if (afchRrnoDvsn == null) {
			if (other.afchRrnoDvsn != null)
				return false;
		} else if (!afchRrnoDvsn.equals(other.afchRrnoDvsn))
			return false;
		if (afchRrnoDvsnErr == null) {
			if (other.afchRrnoDvsnErr != null)
				return false;
		} else if (!afchRrnoDvsnErr.equals(other.afchRrnoDvsnErr))
			return false;
		if (afchRrnoErr == null) {
			if (other.afchRrnoErr != null)
				return false;
		} else if (!afchRrnoErr.equals(other.afchRrnoErr))
			return false;
		if (afchSavgKnd == null) {
			if (other.afchSavgKnd != null)
				return false;
		} else if (!afchSavgKnd.equals(other.afchSavgKnd))
			return false;
		if (afchSavgKndErr == null) {
			if (other.afchSavgKndErr != null)
				return false;
		} else if (!afchSavgKndErr.equals(other.afchSavgKndErr))
			return false;
		if (afchTaxpfAmt == null) {
			if (other.afchTaxpfAmt != null)
				return false;
		} else if (!afchTaxpfAmt.equals(other.afchTaxpfAmt))
			return false;
		if (afchTaxpfAmtErr == null) {
			if (other.afchTaxpfAmtErr != null)
				return false;
		} else if (!afchTaxpfAmtErr.equals(other.afchTaxpfAmtErr))
			return false;
		if (assoBusiGb == null) {
			if (other.assoBusiGb != null)
				return false;
		} else if (!assoBusiGb.equals(other.assoBusiGb))
			return false;
		if (assoRspCd == null) {
			if (other.assoRspCd != null)
				return false;
		} else if (!assoRspCd.equals(other.assoRspCd))
			return false;
		if (bfchActNo == null) {
			if (other.bfchActNo != null)
				return false;
		} else if (!bfchActNo.equals(other.bfchActNo))
			return false;
		if (bfchActNoErr == null) {
			if (other.bfchActNoErr != null)
				return false;
		} else if (!bfchActNoErr.equals(other.bfchActNoErr))
			return false;
		if (bfchOffcCdErr == null) {
			if (other.bfchOffcCdErr != null)
				return false;
		} else if (!bfchOffcCdErr.equals(other.bfchOffcCdErr))
			return false;
		if (bfchOpenOffcCd == null) {
			if (other.bfchOpenOffcCd != null)
				return false;
		} else if (!bfchOpenOffcCd.equals(other.bfchOpenOffcCd))
			return false;
		if (bfchRrno == null) {
			if (other.bfchRrno != null)
				return false;
		} else if (!bfchRrno.equals(other.bfchRrno))
			return false;
		if (bfchRrnoDvsn == null) {
			if (other.bfchRrnoDvsn != null)
				return false;
		} else if (!bfchRrnoDvsn.equals(other.bfchRrnoDvsn))
			return false;
		if (bfchRrnoDvsnErr == null) {
			if (other.bfchRrnoDvsnErr != null)
				return false;
		} else if (!bfchRrnoDvsnErr.equals(other.bfchRrnoDvsnErr))
			return false;
		if (bfchRrnoErr == null) {
			if (other.bfchRrnoErr != null)
				return false;
		} else if (!bfchRrnoErr.equals(other.bfchRrnoErr))
			return false;
		if (bfchSavgKnd == null) {
			if (other.bfchSavgKnd != null)
				return false;
		} else if (!bfchSavgKnd.equals(other.bfchSavgKnd))
			return false;
		if (bfchSavgKndErr == null) {
			if (other.bfchSavgKndErr != null)
				return false;
		} else if (!bfchSavgKndErr.equals(other.bfchSavgKndErr))
			return false;
		if (contNo == null) {
			if (other.contNo != null)
				return false;
		} else if (!contNo.equals(other.contNo))
			return false;
		if (dpsTxNo == null) {
			if (other.dpsTxNo != null)
				return false;
		} else if (!dpsTxNo.equals(other.dpsTxNo))
			return false;
		if (mgntTgmCd == null) {
			if (other.mgntTgmCd != null)
				return false;
		} else if (!mgntTgmCd.equals(other.mgntTgmCd))
			return false;
		if (prcsDofOrgNo == null) {
			if (other.prcsDofOrgNo != null)
				return false;
		} else if (!prcsDofOrgNo.equals(other.prcsDofOrgNo))
			return false;
		if (prcsEno == null) {
			if (other.prcsEno != null)
				return false;
		} else if (!prcsEno.equals(other.prcsEno))
			return false;
		if (prcsFofOrgNo == null) {
			if (other.prcsFofOrgNo != null)
				return false;
		} else if (!prcsFofOrgNo.equals(other.prcsFofOrgNo))
			return false;
		if (rcvInstCd == null) {
			if (other.rcvInstCd != null)
				return false;
		} else if (!rcvInstCd.equals(other.rcvInstCd))
			return false;
		if (savgPrdcd == null) {
			if (other.savgPrdcd != null)
				return false;
		} else if (!savgPrdcd.equals(other.savgPrdcd))
			return false;
		if (sndInstCd == null) {
			if (other.sndInstCd != null)
				return false;
		} else if (!sndInstCd.equals(other.sndInstCd))
			return false;
		if (taxpfBzPrcsDcd == null) {
			if (other.taxpfBzPrcsDcd != null)
				return false;
		} else if (!taxpfBzPrcsDcd.equals(other.taxpfBzPrcsDcd))
			return false;
		if (tgmKndCd == null) {
			if (other.tgmKndCd != null)
				return false;
		} else if (!tgmKndCd.equals(other.tgmKndCd))
			return false;
		if (trnsDtm == null) {
			if (other.trnsDtm != null)
				return false;
		} else if (!trnsDtm.equals(other.trnsDtm))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TaxpfCorrcDO [afchRrno=" + afchRrno + ", afchRrnoDvsn="
				+ afchRrnoDvsn + ", bfchRrno=" + bfchRrno + ", bfchRrnoDvsn="
				+ bfchRrnoDvsn + ", afchConm=" + afchConm + ", afchName="
				+ afchName + ", afchInfoMnbdyDvsn=" + afchInfoMnbdyDvsn
				+ ", afchIncmrDvsn=" + afchIncmrDvsn + ", bfchSavgKnd="
				+ bfchSavgKnd + ", bfchOpenOffcCd=" + bfchOpenOffcCd
				+ ", bfchActNo=" + bfchActNo + ", afchSavgKnd=" + afchSavgKnd
				+ ", afchOpenOffcCd=" + afchOpenOffcCd + ", afchActNo="
				+ afchActNo + ", afchActOpenDy=" + afchActOpenDy
				+ ", afchTaxpfAmt=" + afchTaxpfAmt + ", afchExpiDy="
				+ afchExpiDy + ", afchFstExpiExtnDy=" + afchFstExpiExtnDy
				+ ", afchIntDivdAmt=" + afchIntDivdAmt + ", afchRescsKnd="
				+ afchRescsKnd + ", afchInhrtYn=" + afchInhrtYn
				+ ", afchHousPrpsDvsn=" + afchHousPrpsDvsn + ", afchRrnoErr="
				+ afchRrnoErr + ", afchRrnoDvsnErr=" + afchRrnoDvsnErr
				+ ", bfchRrnoErr=" + bfchRrnoErr + ", bfchRrnoDvsnErr="
				+ bfchRrnoDvsnErr + ", afchConmErr=" + afchConmErr
				+ ", afchNameErr=" + afchNameErr + ", afchInfoMnbdyDvsnErr="
				+ afchInfoMnbdyDvsnErr + ", afchIncmrDvsnErr="
				+ afchIncmrDvsnErr + ", bfchSavgKndErr=" + bfchSavgKndErr
				+ ", bfchOffcCdErr=" + bfchOffcCdErr + ", bfchActNoErr="
				+ bfchActNoErr + ", afchSavgKndErr=" + afchSavgKndErr
				+ ", afchOffcCdErr=" + afchOffcCdErr + ", afchActNoErr="
				+ afchActNoErr + ", afchActOpenDyErr=" + afchActOpenDyErr
				+ ", afchTaxpfAmtErr=" + afchTaxpfAmtErr + ", afchExpiDyErr="
				+ afchExpiDyErr + ", afchFstExpiExtnDyErr="
				+ afchFstExpiExtnDyErr + ", afchIntDivdAmtErr="
				+ afchIntDivdAmtErr + ", afchRescsKndErr=" + afchRescsKndErr
				+ ", afchInhrtYnErr=" + afchInhrtYnErr
				+ ", afchHousPrpsDvsnErr=" + afchHousPrpsDvsnErr + ", dpsTxNo="
				+ dpsTxNo + ", prcsDofOrgNo=" + prcsDofOrgNo
				+ ", prcsFofOrgNo=" + prcsFofOrgNo + ", prcsEno=" + prcsEno
				+ ", contNo=" + contNo + ", savgPrdcd=" + savgPrdcd
				+ ", tgmKndCd=" + tgmKndCd + ", assoBusiGb=" + assoBusiGb
				+ ", trnsDtm=" + trnsDtm + ", mgntTgmCd=" + mgntTgmCd
				+ ", sndInstCd=" + sndInstCd + ", rcvInstCd=" + rcvInstCd
				+ ", assoRspCd=" + assoRspCd + ", taxpfBzPrcsDcd="
				+ taxpfBzPrcsDcd + "]";
	}

}
