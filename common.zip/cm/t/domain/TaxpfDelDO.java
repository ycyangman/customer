/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Thu Apr 11 21:38:39 KST 2013
 * 
 */
package cigna.cm.t.domain;

import java.io.Serializable;

/**
 * @DataObjectName TaxpfDelDO
 * @Description 
 */
public class TaxpfDelDO implements Serializable, Cloneable {

	private static final long serialVersionUID = -101952722L;
	/**
	 * @Type java.lang.String
	 * @Name rrno
	 * @Description 주민등록번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrno;
	/**
	 * @Type java.lang.String
	 * @Name rrnoDvsn
	 * @Description 주민등록번호구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrnoDvsn;
	/**
	 * @Type java.lang.String
	 * @Name savgKnd
	 * @Description 저축종류
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgKnd;
	/**
	 * @Type java.lang.String
	 * @Name offcCd
	 * @Description 점포코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String offcCd;
	/**
	 * @Type java.lang.String
	 * @Name actNo
	 * @Description 계좌번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String actNo;
	/**
	 * @Type java.lang.String
	 * @Name rrnoErr
	 * @Description 주민등록번호Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrnoErr;
	/**
	 * @Type java.lang.String
	 * @Name rrnoDvsnErr
	 * @Description 주민등록번호구분Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrnoDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name savgKndErr
	 * @Description 저축종류Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgKndErr;
	/**
	 * @Type java.lang.String
	 * @Name offcCdErr
	 * @Description 점포코드Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String offcCdErr;
	/**
	 * @Type java.lang.String
	 * @Name actNoErr
	 * @Description 계좌번호Error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String actNoErr;

	/**
	 * @Type java.lang.String
	 * @Name dpsTxNo
	 * @Description 입금거래번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String dpsTxNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsDofOrgNo
	 * @Description 처리지점조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsDofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsFofOrgNo
	 * @Description 처리지점소조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsFofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsEno
	 * @Description 처리사원번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsEno;
	
	/**
	 * @Type java.lang.String
	 * @Name contNo
	 * @Description 계약번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String contNo;
	
	/**
	 * @Type java.lang.String
	 * @Name savgPrdcd
	 * @Description 저축상품코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgPrdcd;
	/**
	 * @Type java.lang.String
	 * @Name tgmKndCd
	 * @Description 전문종별코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String tgmKndCd;
	/**
	 * @Type java.lang.String
	 * @Name assoBusiGb
	 * @Description 협회업무구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String assoBusiGb;
	/**
	 * @Type java.lang.String
	 * @Name trnsDtm
	 * @Description 전문전송일시
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String trnsDtm;
	/**
	 * @Type java.lang.String
	 * @Name mgntTgmCd
	 * @Description 전문관리번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String mgntTgmCd;
	/**
	 * @Type java.lang.String
	 * @Name sndInstCd
	 * @Description 전송기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String sndInstCd;
	/**
	 * @Type java.lang.String
	 * @Name rcvInstCd
	 * @Description 수신기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rcvInstCd;
	/**
	 * @Type java.lang.String
	 * @Name assoRspCd
	 * @Description 협회응답코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String assoRspCd;
	/**
	 * @Type java.lang.String
	 * @Name taxpfBzPrcsDcd
	 * @Description 세금우대업무처리구분코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String taxpfBzPrcsDcd;

	/**
	 * @return the taxpfBzPrcsDcd
	 */
	public java.lang.String getTaxpfBzPrcsDcd() {
		return taxpfBzPrcsDcd;
	}

	/**
	 * @param taxpfBzPrcsDcd the taxpfBzPrcsDcd to set
	 */
	public void setTaxpfBzPrcsDcd(java.lang.String taxpfBzPrcsDcd) {
		this.taxpfBzPrcsDcd = taxpfBzPrcsDcd;
	}
	/**
	 * @return the tgmKndCd
	 */
	public java.lang.String getTgmKndCd() {
		return tgmKndCd;
	}

	/**
	 * @param tgmKndCd the tgmKndCd to set
	 */
	public void setTgmKndCd(java.lang.String tgmKndCd) {
		this.tgmKndCd = tgmKndCd;
	}

	/**
	 * @return the assoBusiGb
	 */
	public java.lang.String getAssoBusiGb() {
		return assoBusiGb;
	}

	/**
	 * @param assoBusiGb the assoBusiGb to set
	 */
	public void setAssoBusiGb(java.lang.String assoBusiGb) {
		this.assoBusiGb = assoBusiGb;
	}

	/**
	 * @return the trnsDtm
	 */
	public java.lang.String getTrnsDtm() {
		return trnsDtm;
	}

	/**
	 * @param trnsDtm the trnsDtm to set
	 */
	public void setTrnsDtm(java.lang.String trnsDtm) {
		this.trnsDtm = trnsDtm;
	}

	/**
	 * @return the mgntTgmCd
	 */
	public java.lang.String getMgntTgmCd() {
		return mgntTgmCd;
	}

	/**
	 * @param mgntTgmCd the mgntTgmCd to set
	 */
	public void setMgntTgmCd(java.lang.String mgntTgmCd) {
		this.mgntTgmCd = mgntTgmCd;
	}

	/**
	 * @return the sndInstCd
	 */
	public java.lang.String getSndInstCd() {
		return sndInstCd;
	}

	/**
	 * @param sndInstCd the sndInstCd to set
	 */
	public void setSndInstCd(java.lang.String sndInstCd) {
		this.sndInstCd = sndInstCd;
	}

	/**
	 * @return the rcvInstCd
	 */
	public java.lang.String getRcvInstCd() {
		return rcvInstCd;
	}

	/**
	 * @param rcvInstCd the rcvInstCd to set
	 */
	public void setRcvInstCd(java.lang.String rcvInstCd) {
		this.rcvInstCd = rcvInstCd;
	}

	/**
	 * @return the assoRspCd
	 */
	public java.lang.String getAssoRspCd() {
		return assoRspCd;
	}

	/**
	 * @param assoRspCd the assoRspCd to set
	 */
	public void setAssoRspCd(java.lang.String assoRspCd) {
		this.assoRspCd = assoRspCd;
	}

	/**
	 * GET 주민등록번호
	 */
	public java.lang.String getRrno() {
		return this.rrno;
	}

	/**
	 * SET 주민등록번호
	 */
	public void setRrno(java.lang.String rrno) {
		this.rrno = rrno;
	}

	/**
	 * GET 주민등록번호구분
	 */
	public java.lang.String getRrnoDvsn() {
		return this.rrnoDvsn;
	}

	/**
	 * SET 주민등록번호구분
	 */
	public void setRrnoDvsn(java.lang.String rrnoDvsn) {
		this.rrnoDvsn = rrnoDvsn;
	}

	/**
	 * GET 저축종류
	 */
	public java.lang.String getSavgKnd() {
		return this.savgKnd;
	}

	/**
	 * SET 저축종류
	 */
	public void setSavgKnd(java.lang.String savgKnd) {
		this.savgKnd = savgKnd;
	}

	/**
	 * GET 점포코드
	 */
	public java.lang.String getOffcCd() {
		return this.offcCd;
	}

	/**
	 * SET 점포코드
	 */
	public void setOffcCd(java.lang.String offcCd) {
		this.offcCd = offcCd;
	}

	/**
	 * GET 계좌번호
	 */
	public java.lang.String getActNo() {
		return this.actNo;
	}

	/**
	 * SET 계좌번호
	 */
	public void setActNo(java.lang.String actNo) {
		this.actNo = actNo;
	}

	/**
	 * GET 주민등록번호Error
	 */
	public java.lang.String getRrnoErr() {
		return this.rrnoErr;
	}

	/**
	 * SET 주민등록번호Error
	 */
	public void setRrnoErr(java.lang.String rrnoErr) {
		this.rrnoErr = rrnoErr;
	}

	/**
	 * GET 주민등록번호구분Error
	 */
	public java.lang.String getRrnoDvsnErr() {
		return this.rrnoDvsnErr;
	}

	/**
	 * SET 주민등록번호구분Error
	 */
	public void setRrnoDvsnErr(java.lang.String rrnoDvsnErr) {
		this.rrnoDvsnErr = rrnoDvsnErr;
	}

	/**
	 * GET 저축종류Error
	 */
	public java.lang.String getSavgKndErr() {
		return this.savgKndErr;
	}

	/**
	 * SET 저축종류Error
	 */
	public void setSavgKndErr(java.lang.String savgKndErr) {
		this.savgKndErr = savgKndErr;
	}

	/**
	 * GET 점포코드Error
	 */
	public java.lang.String getOffcCdErr() {
		return this.offcCdErr;
	}

	/**
	 * SET 점포코드Error
	 */
	public void setOffcCdErr(java.lang.String offcCdErr) {
		this.offcCdErr = offcCdErr;
	}

	/**
	 * GET 계좌번호Error
	 */
	public java.lang.String getActNoErr() {
		return this.actNoErr;
	}

	/**
	 * SET 계좌번호Error
	 */
	public void setActNoErr(java.lang.String actNoErr) {
		this.actNoErr = actNoErr;
	}

	/**
	 * @return the dpsTxNo
	 */
	public java.lang.String getDpsTxNo() {
		return dpsTxNo;
	}

	/**
	 * @param dpsTxNo the dpsTxNo to set
	 */
	public void setDpsTxNo(java.lang.String dpsTxNo) {
		this.dpsTxNo = dpsTxNo;
	}

	/**
	 * @return the prcsDofOrgNo
	 */
	public java.lang.String getPrcsDofOrgNo() {
		return prcsDofOrgNo;
	}

	/**
	 * @param prcsDofOrgNo the prcsDofOrgNo to set
	 */
	public void setPrcsDofOrgNo(java.lang.String prcsDofOrgNo) {
		this.prcsDofOrgNo = prcsDofOrgNo;
	}

	/**
	 * @return the prcsFofOrgNo
	 */
	public java.lang.String getPrcsFofOrgNo() {
		return prcsFofOrgNo;
	}

	/**
	 * @param prcsFofOrgNo the prcsFofOrgNo to set
	 */
	public void setPrcsFofOrgNo(java.lang.String prcsFofOrgNo) {
		this.prcsFofOrgNo = prcsFofOrgNo;
	}

	/**
	 * @return the prcsEno
	 */
	public java.lang.String getPrcsEno() {
		return prcsEno;
	}

	/**
	 * @param prcsEno the prcsEno to set
	 */
	public void setPrcsEno(java.lang.String prcsEno) {
		this.prcsEno = prcsEno;
	}

	/**
	 * @return the contNo
	 */
	public java.lang.String getContNo() {
		return contNo;
	}

	/**
	 * @param contNo the contNo to set
	 */
	public void setContNo(java.lang.String contNo) {
		this.contNo = contNo;
	}

	/**
	 * @return the savgPrdcd
	 */
	public java.lang.String getSavgPrdcd() {
		return savgPrdcd;
	}

	/**
	 * @param savgPrdcd the savgPrdcd to set
	 */
	public void setSavgPrdcd(java.lang.String savgPrdcd) {
		this.savgPrdcd = savgPrdcd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actNo == null) ? 0 : actNo.hashCode());
		result = prime * result
				+ ((actNoErr == null) ? 0 : actNoErr.hashCode());
		result = prime * result
				+ ((assoBusiGb == null) ? 0 : assoBusiGb.hashCode());
		result = prime * result
				+ ((assoRspCd == null) ? 0 : assoRspCd.hashCode());
		result = prime * result + ((contNo == null) ? 0 : contNo.hashCode());
		result = prime * result + ((dpsTxNo == null) ? 0 : dpsTxNo.hashCode());
		result = prime * result
				+ ((mgntTgmCd == null) ? 0 : mgntTgmCd.hashCode());
		result = prime * result + ((offcCd == null) ? 0 : offcCd.hashCode());
		result = prime * result
				+ ((offcCdErr == null) ? 0 : offcCdErr.hashCode());
		result = prime * result
				+ ((prcsDofOrgNo == null) ? 0 : prcsDofOrgNo.hashCode());
		result = prime * result + ((prcsEno == null) ? 0 : prcsEno.hashCode());
		result = prime * result
				+ ((prcsFofOrgNo == null) ? 0 : prcsFofOrgNo.hashCode());
		result = prime * result
				+ ((rcvInstCd == null) ? 0 : rcvInstCd.hashCode());
		result = prime * result + ((rrno == null) ? 0 : rrno.hashCode());
		result = prime * result
				+ ((rrnoDvsn == null) ? 0 : rrnoDvsn.hashCode());
		result = prime * result
				+ ((rrnoDvsnErr == null) ? 0 : rrnoDvsnErr.hashCode());
		result = prime * result + ((rrnoErr == null) ? 0 : rrnoErr.hashCode());
		result = prime * result + ((savgKnd == null) ? 0 : savgKnd.hashCode());
		result = prime * result
				+ ((savgKndErr == null) ? 0 : savgKndErr.hashCode());
		result = prime * result
				+ ((savgPrdcd == null) ? 0 : savgPrdcd.hashCode());
		result = prime * result
				+ ((sndInstCd == null) ? 0 : sndInstCd.hashCode());
		result = prime * result
				+ ((taxpfBzPrcsDcd == null) ? 0 : taxpfBzPrcsDcd.hashCode());
		result = prime * result
				+ ((tgmKndCd == null) ? 0 : tgmKndCd.hashCode());
		result = prime * result + ((trnsDtm == null) ? 0 : trnsDtm.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxpfDelDO other = (TaxpfDelDO) obj;
		if (actNo == null) {
			if (other.actNo != null)
				return false;
		} else if (!actNo.equals(other.actNo))
			return false;
		if (actNoErr == null) {
			if (other.actNoErr != null)
				return false;
		} else if (!actNoErr.equals(other.actNoErr))
			return false;
		if (assoBusiGb == null) {
			if (other.assoBusiGb != null)
				return false;
		} else if (!assoBusiGb.equals(other.assoBusiGb))
			return false;
		if (assoRspCd == null) {
			if (other.assoRspCd != null)
				return false;
		} else if (!assoRspCd.equals(other.assoRspCd))
			return false;
		if (contNo == null) {
			if (other.contNo != null)
				return false;
		} else if (!contNo.equals(other.contNo))
			return false;
		if (dpsTxNo == null) {
			if (other.dpsTxNo != null)
				return false;
		} else if (!dpsTxNo.equals(other.dpsTxNo))
			return false;
		if (mgntTgmCd == null) {
			if (other.mgntTgmCd != null)
				return false;
		} else if (!mgntTgmCd.equals(other.mgntTgmCd))
			return false;
		if (offcCd == null) {
			if (other.offcCd != null)
				return false;
		} else if (!offcCd.equals(other.offcCd))
			return false;
		if (offcCdErr == null) {
			if (other.offcCdErr != null)
				return false;
		} else if (!offcCdErr.equals(other.offcCdErr))
			return false;
		if (prcsDofOrgNo == null) {
			if (other.prcsDofOrgNo != null)
				return false;
		} else if (!prcsDofOrgNo.equals(other.prcsDofOrgNo))
			return false;
		if (prcsEno == null) {
			if (other.prcsEno != null)
				return false;
		} else if (!prcsEno.equals(other.prcsEno))
			return false;
		if (prcsFofOrgNo == null) {
			if (other.prcsFofOrgNo != null)
				return false;
		} else if (!prcsFofOrgNo.equals(other.prcsFofOrgNo))
			return false;
		if (rcvInstCd == null) {
			if (other.rcvInstCd != null)
				return false;
		} else if (!rcvInstCd.equals(other.rcvInstCd))
			return false;
		if (rrno == null) {
			if (other.rrno != null)
				return false;
		} else if (!rrno.equals(other.rrno))
			return false;
		if (rrnoDvsn == null) {
			if (other.rrnoDvsn != null)
				return false;
		} else if (!rrnoDvsn.equals(other.rrnoDvsn))
			return false;
		if (rrnoDvsnErr == null) {
			if (other.rrnoDvsnErr != null)
				return false;
		} else if (!rrnoDvsnErr.equals(other.rrnoDvsnErr))
			return false;
		if (rrnoErr == null) {
			if (other.rrnoErr != null)
				return false;
		} else if (!rrnoErr.equals(other.rrnoErr))
			return false;
		if (savgKnd == null) {
			if (other.savgKnd != null)
				return false;
		} else if (!savgKnd.equals(other.savgKnd))
			return false;
		if (savgKndErr == null) {
			if (other.savgKndErr != null)
				return false;
		} else if (!savgKndErr.equals(other.savgKndErr))
			return false;
		if (savgPrdcd == null) {
			if (other.savgPrdcd != null)
				return false;
		} else if (!savgPrdcd.equals(other.savgPrdcd))
			return false;
		if (sndInstCd == null) {
			if (other.sndInstCd != null)
				return false;
		} else if (!sndInstCd.equals(other.sndInstCd))
			return false;
		if (taxpfBzPrcsDcd == null) {
			if (other.taxpfBzPrcsDcd != null)
				return false;
		} else if (!taxpfBzPrcsDcd.equals(other.taxpfBzPrcsDcd))
			return false;
		if (tgmKndCd == null) {
			if (other.tgmKndCd != null)
				return false;
		} else if (!tgmKndCd.equals(other.tgmKndCd))
			return false;
		if (trnsDtm == null) {
			if (other.trnsDtm != null)
				return false;
		} else if (!trnsDtm.equals(other.trnsDtm))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TaxpfDelDO [rrno=" + rrno + ", rrnoDvsn=" + rrnoDvsn
				+ ", savgKnd=" + savgKnd + ", offcCd=" + offcCd + ", actNo="
				+ actNo + ", rrnoErr=" + rrnoErr + ", rrnoDvsnErr="
				+ rrnoDvsnErr + ", savgKndErr=" + savgKndErr + ", offcCdErr="
				+ offcCdErr + ", actNoErr=" + actNoErr + ", dpsTxNo=" + dpsTxNo
				+ ", prcsDofOrgNo=" + prcsDofOrgNo + ", prcsFofOrgNo="
				+ prcsFofOrgNo + ", prcsEno=" + prcsEno + ", contNo=" + contNo
				+ ", savgPrdcd=" + savgPrdcd + ", tgmKndCd=" + tgmKndCd
				+ ", assoBusiGb=" + assoBusiGb + ", trnsDtm=" + trnsDtm
				+ ", mgntTgmCd=" + mgntTgmCd + ", sndInstCd=" + sndInstCd
				+ ", rcvInstCd=" + rcvInstCd + ", assoRspCd=" + assoRspCd
				+ ", taxpfBzPrcsDcd=" + taxpfBzPrcsDcd + "]";
	}

}
