/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Thu Apr 11 17:22:15 KST 2013
 * 
 */
package cigna.cm.t.domain;

import java.io.Serializable;

/**
 * @DataObjectName TaxpfRegDO
 * @Description 
 */
public class TaxpfRegDO implements Serializable, Cloneable {

	private static final long serialVersionUID = -89028233L;
	/**
	 * @Type java.lang.String
	 * @Name rrno
	 * @Description 주민등록번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrno;
	/**
	 * @Type java.lang.String
	 * @Name rrnoDvsn
	 * @Description 주민등록번호구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrnoDvsn;
	/**
	 * @Type java.lang.String
	 * @Name conm
	 * @Description 상호(기업체명)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String conm;
	/**
	 * @Type java.lang.String
	 * @Name name
	 * @Description 성명(대표자)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String name;
	/**
	 * @Type java.lang.String
	 * @Name infoMnbdyDvsn
	 * @Description 정보주체(구장애인)구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String infoMnbdyDvsn;
	/**
	 * @Type java.lang.String
	 * @Name incmrDvsn
	 * @Description 저소득자구분(농어가저축)
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String incmrDvsn;
	/**
	 * @Type java.lang.String
	 * @Name savgKnd
	 * @Description 저축종류
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgKnd;
	/**
	 * @Type java.lang.String
	 * @Name openOffcCd
	 * @Description 개설점포코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String openOffcCd;
	/**
	 * @Type java.lang.String
	 * @Name actNo
	 * @Description 계좌번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String actNo;
	/**
	 * @Type java.lang.String
	 * @Name actOpenDy
	 * @Description 계좌개설일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String actOpenDy;
	/**
	 * @Type java.math.BigDecimal
	 * @Name taxpfAmt
	 * @Description 세금우대금액
	 * @Length 0
	 * @Decimal 0
	 */
	private java.math.BigDecimal taxpfAmt;
	/**
	 * @Type java.lang.String
	 * @Name expiDy
	 * @Description 만기일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String expiDy;
	/**
	 * @Type java.lang.String
	 * @Name inhrtYn
	 * @Description 상속여부
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String inhrtYn;
	/**
	 * @Type java.lang.String
	 * @Name housPrpsDvsn
	 * @Description 주택청약예부금구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String housPrpsDvsn;
	/**
	 * @Type java.lang.String
	 * @Name rrnoErr
	 * @Description 주민등록번호error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrnoErr;
	/**
	 * @Type java.lang.String
	 * @Name rrnoDvsnErr
	 * @Description 주민등록번호구분error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rrnoDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name conmErr
	 * @Description 상호error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String conmErr;
	/**
	 * @Type java.lang.String
	 * @Name nameErr
	 * @Description 성명error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String nameErr;
	/**
	 * @Type java.lang.String
	 * @Name infoMnbdyDvsnErr
	 * @Description 정보주체(구장애인)구분error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String infoMnbdyDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name incmrDvsnErr
	 * @Description 저소득자구분error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String incmrDvsnErr;
	/**
	 * @Type java.lang.String
	 * @Name savgKndErr
	 * @Description 저축종류error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgKndErr;
	/**
	 * @Type java.lang.String
	 * @Name openOffcCdErr
	 * @Description 개설점포코드error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String openOffcCdErr;
	/**
	 * @Type java.lang.String
	 * @Name actNoErr
	 * @Description 계좌번호error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String actNoErr;
	/**
	 * @Type java.lang.String
	 * @Name actOpenDyErr
	 * @Description 계좌개설일error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String actOpenDyErr;
	/**
	 * @Type java.lang.String
	 * @Name taxpfAmtErr
	 * @Description 세금우대금액error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String taxpfAmtErr;
	/**
	 * @Type java.lang.String
	 * @Name expiDyErr
	 * @Description 만기일error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String expiDyErr;
	/**
	 * @Type java.lang.String
	 * @Name inhrtYnErr
	 * @Description 상속여부error
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String inhrtYnErr;
	/**
	 * @Type java.lang.String
	 * @Name housPrpsDvsnErr
	 * @Description 주택청약예부금구분error
	 * @Length 0
	 * @Decimal 0
	 */
	/**
	 * @Type java.lang.String
	 * @Name dpsTxNo
	 * @Description 입금거래번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String dpsTxNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsDofOrgNo
	 * @Description 처리지점조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsDofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsFofOrgNo
	 * @Description 처리지점소조직번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsFofOrgNo;
	
	/**
	 * @Type java.lang.String
	 * @Name prcsEno
	 * @Description 처리사원번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String prcsEno;
	
	/**
	 * @Type java.lang.String
	 * @Name contNo
	 * @Description 계약번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String contNo;
	/**
	 * @Type java.lang.String
	 * @Name tgmKndCd
	 * @Description 전문종별코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String tgmKndCd;
	/**
	 * @Type java.lang.String
	 * @Name assoBusiGb
	 * @Description 협회업무구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String assoBusiGb;
	/**
	 * @Type java.lang.String
	 * @Name trnsDtm
	 * @Description 전문전송일시
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String trnsDtm;
	/**
	 * @Type java.lang.String
	 * @Name mgntTgmCd
	 * @Description 전문관리번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String mgntTgmCd;
	/**
	 * @Type java.lang.String
	 * @Name sndInstCd
	 * @Description 전송기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String sndInstCd;
	/**
	 * @Type java.lang.String
	 * @Name rcvInstCd
	 * @Description 수신기관코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rcvInstCd;
	/**
	 * @Type java.lang.String
	 * @Name assoRspCd
	 * @Description 협회응답코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String assoRspCd;
	/**
	 * @Type java.lang.String
	 * @Name taxpfBzPrcsDcd
	 * @Description 세금우대업무처리구분코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String taxpfBzPrcsDcd;

	/**
	 * @return the taxpfBzPrcsDcd
	 */
	public java.lang.String getTaxpfBzPrcsDcd() {
		return taxpfBzPrcsDcd;
	}

	/**
	 * @param taxpfBzPrcsDcd the taxpfBzPrcsDcd to set
	 */
	public void setTaxpfBzPrcsDcd(java.lang.String taxpfBzPrcsDcd) {
		this.taxpfBzPrcsDcd = taxpfBzPrcsDcd;
	}
	
	/**
	 * @return the tgmKndCd
	 */
	public java.lang.String getTgmKndCd() {
		return tgmKndCd;
	}

	/**
	 * @param tgmKndCd the tgmKndCd to set
	 */
	public void setTgmKndCd(java.lang.String tgmKndCd) {
		this.tgmKndCd = tgmKndCd;
	}

	/**
	 * @return the assoBusiGb
	 */
	public java.lang.String getAssoBusiGb() {
		return assoBusiGb;
	}

	/**
	 * @param assoBusiGb the assoBusiGb to set
	 */
	public void setAssoBusiGb(java.lang.String assoBusiGb) {
		this.assoBusiGb = assoBusiGb;
	}

	/**
	 * @return the trnsDtm
	 */
	public java.lang.String getTrnsDtm() {
		return trnsDtm;
	}

	/**
	 * @param trnsDtm the trnsDtm to set
	 */
	public void setTrnsDtm(java.lang.String trnsDtm) {
		this.trnsDtm = trnsDtm;
	}

	/**
	 * @return the mgntTgmCd
	 */
	public java.lang.String getMgntTgmCd() {
		return mgntTgmCd;
	}

	/**
	 * @param mgntTgmCd the mgntTgmCd to set
	 */
	public void setMgntTgmCd(java.lang.String mgntTgmCd) {
		this.mgntTgmCd = mgntTgmCd;
	}

	/**
	 * @return the sndInstCd
	 */
	public java.lang.String getSndInstCd() {
		return sndInstCd;
	}

	/**
	 * @param sndInstCd the sndInstCd to set
	 */
	public void setSndInstCd(java.lang.String sndInstCd) {
		this.sndInstCd = sndInstCd;
	}

	/**
	 * @return the rcvInstCd
	 */
	public java.lang.String getRcvInstCd() {
		return rcvInstCd;
	}

	/**
	 * @param rcvInstCd the rcvInstCd to set
	 */
	public void setRcvInstCd(java.lang.String rcvInstCd) {
		this.rcvInstCd = rcvInstCd;
	}

	/**
	 * @return the assoRspCd
	 */
	public java.lang.String getAssoRspCd() {
		return assoRspCd;
	}

	/**
	 * @param assoRspCd the assoRspCd to set
	 */
	public void setAssoRspCd(java.lang.String assoRspCd) {
		this.assoRspCd = assoRspCd;
	}

	/**
	 * @return the dpsTxNo
	 */
	public java.lang.String getDpsTxNo() {
		return dpsTxNo;
	}

	/**
	 * @param dpsTxNo the dpsTxNo to set
	 */
	public void setDpsTxNo(java.lang.String dpsTxNo) {
		this.dpsTxNo = dpsTxNo;
	}

	/**
	 * @return the prcsDofOrgNo
	 */
	public java.lang.String getPrcsDofOrgNo() {
		return prcsDofOrgNo;
	}

	/**
	 * @param prcsDofOrgNo the prcsDofOrgNo to set
	 */
	public void setPrcsDofOrgNo(java.lang.String prcsDofOrgNo) {
		this.prcsDofOrgNo = prcsDofOrgNo;
	}

	/**
	 * @return the prcsFofOrgNo
	 */
	public java.lang.String getPrcsFofOrgNo() {
		return prcsFofOrgNo;
	}

	/**
	 * @param prcsFofOrgNo the prcsFofOrgNo to set
	 */
	public void setPrcsFofOrgNo(java.lang.String prcsFofOrgNo) {
		this.prcsFofOrgNo = prcsFofOrgNo;
	}

	/**
	 * @return the prcsEno
	 */
	public java.lang.String getPrcsEno() {
		return prcsEno;
	}

	/**
	 * @param prcsEno the prcsEno to set
	 */
	public void setPrcsEno(java.lang.String prcsEno) {
		this.prcsEno = prcsEno;
	}

	/**
	 * @return the contNo
	 */
	public java.lang.String getContNo() {
		return contNo;
	}

	/**
	 * @param contNo the contNo to set
	 */
	public void setContNo(java.lang.String contNo) {
		this.contNo = contNo;
	}

	/**
	 * @return the savgPrdcd
	 */
	public java.lang.String getSavgPrdcd() {
		return savgPrdcd;
	}

	/**
	 * @param savgPrdcd the savgPrdcd to set
	 */
	public void setSavgPrdcd(java.lang.String savgPrdcd) {
		this.savgPrdcd = savgPrdcd;
	}

	/**
	 * @Type java.lang.String
	 * @Name savgPrdcd
	 * @Description 저축상품코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgPrdcd;
	private java.lang.String housPrpsDvsnErr;

	/**
	 * GET 주민등록번호
	 */
	public java.lang.String getRrno() {
		return this.rrno;
	}

	/**
	 * SET 주민등록번호
	 */
	public void setRrno(java.lang.String rrno) {
		this.rrno = rrno;
	}

	/**
	 * GET 주민등록번호구분
	 */
	public java.lang.String getRrnoDvsn() {
		return this.rrnoDvsn;
	}

	/**
	 * SET 주민등록번호구분
	 */
	public void setRrnoDvsn(java.lang.String rrnoDvsn) {
		this.rrnoDvsn = rrnoDvsn;
	}

	/**
	 * GET 상호(기업체명)
	 */
	public java.lang.String getConm() {
		return this.conm;
	}

	/**
	 * SET 상호(기업체명)
	 */
	public void setConm(java.lang.String conm) {
		this.conm = conm;
	}

	/**
	 * GET 성명(대표자)
	 */
	public java.lang.String getName() {
		return this.name;
	}

	/**
	 * SET 성명(대표자)
	 */
	public void setName(java.lang.String name) {
		this.name = name;
	}

	/**
	 * GET 정보주체(구장애인)구분
	 */
	public java.lang.String getInfoMnbdyDvsn() {
		return this.infoMnbdyDvsn;
	}

	/**
	 * SET 정보주체(구장애인)구분
	 */
	public void setInfoMnbdyDvsn(java.lang.String infoMnbdyDvsn) {
		this.infoMnbdyDvsn = infoMnbdyDvsn;
	}

	/**
	 * GET 저소득자구분(농어가저축)
	 */
	public java.lang.String getIncmrDvsn() {
		return this.incmrDvsn;
	}

	/**
	 * SET 저소득자구분(농어가저축)
	 */
	public void setIncmrDvsn(java.lang.String incmrDvsn) {
		this.incmrDvsn = incmrDvsn;
	}

	/**
	 * GET 저축종류
	 */
	public java.lang.String getSavgKnd() {
		return this.savgKnd;
	}

	/**
	 * SET 저축종류
	 */
	public void setSavgKnd(java.lang.String savgKnd) {
		this.savgKnd = savgKnd;
	}

	/**
	 * GET 개설점포코드
	 */
	public java.lang.String getOpenOffcCd() {
		return this.openOffcCd;
	}

	/**
	 * SET 개설점포코드
	 */
	public void setOpenOffcCd(java.lang.String openOffcCd) {
		this.openOffcCd = openOffcCd;
	}

	/**
	 * GET 계좌번호
	 */
	public java.lang.String getActNo() {
		return this.actNo;
	}

	/**
	 * SET 계좌번호
	 */
	public void setActNo(java.lang.String actNo) {
		this.actNo = actNo;
	}

	/**
	 * GET 계좌개설일
	 */
	public java.lang.String getActOpenDy() {
		return this.actOpenDy;
	}

	/**
	 * SET 계좌개설일
	 */
	public void setActOpenDy(java.lang.String actOpenDy) {
		this.actOpenDy = actOpenDy;
	}

	/**
	 * GET 세금우대금액
	 */
	public java.math.BigDecimal getTaxpfAmt() {
		return this.taxpfAmt;
	}

	/**
	 * SET 세금우대금액
	 */
	public void setTaxpfAmt(java.math.BigDecimal taxpfAmt) {
		this.taxpfAmt = taxpfAmt;
	}

	/**
	 * GET 만기일
	 */
	public java.lang.String getExpiDy() {
		return this.expiDy;
	}

	/**
	 * SET 만기일
	 */
	public void setExpiDy(java.lang.String expiDy) {
		this.expiDy = expiDy;
	}

	/**
	 * GET 상속여부
	 */
	public java.lang.String getInhrtYn() {
		return this.inhrtYn;
	}

	/**
	 * SET 상속여부
	 */
	public void setInhrtYn(java.lang.String inhrtYn) {
		this.inhrtYn = inhrtYn;
	}

	/**
	 * GET 주택청약예부금구분
	 */
	public java.lang.String getHousPrpsDvsn() {
		return this.housPrpsDvsn;
	}

	/**
	 * SET 주택청약예부금구분
	 */
	public void setHousPrpsDvsn(java.lang.String housPrpsDvsn) {
		this.housPrpsDvsn = housPrpsDvsn;
	}

	/**
	 * GET 주민등록번호error
	 */
	public java.lang.String getRrnoErr() {
		return this.rrnoErr;
	}

	/**
	 * SET 주민등록번호error
	 */
	public void setRrnoErr(java.lang.String rrnoErr) {
		this.rrnoErr = rrnoErr;
	}

	/**
	 * GET 주민등록번호구분error
	 */
	public java.lang.String getRrnoDvsnErr() {
		return this.rrnoDvsnErr;
	}

	/**
	 * SET 주민등록번호구분error
	 */
	public void setRrnoDvsnErr(java.lang.String rrnoDvsnErr) {
		this.rrnoDvsnErr = rrnoDvsnErr;
	}

	/**
	 * GET 상호error
	 */
	public java.lang.String getConmErr() {
		return this.conmErr;
	}

	/**
	 * SET 상호error
	 */
	public void setConmErr(java.lang.String conmErr) {
		this.conmErr = conmErr;
	}

	/**
	 * GET 성명error
	 */
	public java.lang.String getNameErr() {
		return this.nameErr;
	}

	/**
	 * SET 성명error
	 */
	public void setNameErr(java.lang.String nameErr) {
		this.nameErr = nameErr;
	}

	/**
	 * GET 정보주체(구장애인)구분error
	 */
	public java.lang.String getInfoMnbdyDvsnErr() {
		return this.infoMnbdyDvsnErr;
	}

	/**
	 * SET 정보주체(구장애인)구분error
	 */
	public void setInfoMnbdyDvsnErr(java.lang.String infoMnbdyDvsnErr) {
		this.infoMnbdyDvsnErr = infoMnbdyDvsnErr;
	}

	/**
	 * GET 저소득자구분error
	 */
	public java.lang.String getIncmrDvsnErr() {
		return this.incmrDvsnErr;
	}

	/**
	 * SET 저소득자구분error
	 */
	public void setIncmrDvsnErr(java.lang.String incmrDvsnErr) {
		this.incmrDvsnErr = incmrDvsnErr;
	}

	/**
	 * GET 저축종류error
	 */
	public java.lang.String getSavgKndErr() {
		return this.savgKndErr;
	}

	/**
	 * SET 저축종류error
	 */
	public void setSavgKndErr(java.lang.String savgKndErr) {
		this.savgKndErr = savgKndErr;
	}

	/**
	 * GET 개설점포코드error
	 */
	public java.lang.String getOpenOffcCdErr() {
		return this.openOffcCdErr;
	}

	/**
	 * SET 개설점포코드error
	 */
	public void setOpenOffcCdErr(java.lang.String openOffcCdErr) {
		this.openOffcCdErr = openOffcCdErr;
	}

	/**
	 * GET 계좌번호error
	 */
	public java.lang.String getActNoErr() {
		return this.actNoErr;
	}

	/**
	 * SET 계좌번호error
	 */
	public void setActNoErr(java.lang.String actNoErr) {
		this.actNoErr = actNoErr;
	}

	/**
	 * GET 계좌개설일error
	 */
	public java.lang.String getActOpenDyErr() {
		return this.actOpenDyErr;
	}

	/**
	 * SET 계좌개설일error
	 */
	public void setActOpenDyErr(java.lang.String actOpenDyErr) {
		this.actOpenDyErr = actOpenDyErr;
	}

	/**
	 * GET 세금우대금액error
	 */
	public java.lang.String getTaxpfAmtErr() {
		return this.taxpfAmtErr;
	}

	/**
	 * SET 세금우대금액error
	 */
	public void setTaxpfAmtErr(java.lang.String taxpfAmtErr) {
		this.taxpfAmtErr = taxpfAmtErr;
	}

	/**
	 * GET 만기일error
	 */
	public java.lang.String getExpiDyErr() {
		return this.expiDyErr;
	}

	/**
	 * SET 만기일error
	 */
	public void setExpiDyErr(java.lang.String expiDyErr) {
		this.expiDyErr = expiDyErr;
	}

	/**
	 * GET 상속여부error
	 */
	public java.lang.String getInhrtYnErr() {
		return this.inhrtYnErr;
	}

	/**
	 * SET 상속여부error
	 */
	public void setInhrtYnErr(java.lang.String inhrtYnErr) {
		this.inhrtYnErr = inhrtYnErr;
	}

	/**
	 * GET 주택청약예부금구분error
	 */
	public java.lang.String getHousPrpsDvsnErr() {
		return this.housPrpsDvsnErr;
	}

	/**
	 * SET 주택청약예부금구분error
	 */
	public void setHousPrpsDvsnErr(java.lang.String housPrpsDvsnErr) {
		this.housPrpsDvsnErr = housPrpsDvsnErr;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actNo == null) ? 0 : actNo.hashCode());
		result = prime * result
				+ ((actNoErr == null) ? 0 : actNoErr.hashCode());
		result = prime * result
				+ ((actOpenDy == null) ? 0 : actOpenDy.hashCode());
		result = prime * result
				+ ((actOpenDyErr == null) ? 0 : actOpenDyErr.hashCode());
		result = prime * result
				+ ((assoBusiGb == null) ? 0 : assoBusiGb.hashCode());
		result = prime * result
				+ ((assoRspCd == null) ? 0 : assoRspCd.hashCode());
		result = prime * result + ((conm == null) ? 0 : conm.hashCode());
		result = prime * result + ((conmErr == null) ? 0 : conmErr.hashCode());
		result = prime * result + ((contNo == null) ? 0 : contNo.hashCode());
		result = prime * result + ((dpsTxNo == null) ? 0 : dpsTxNo.hashCode());
		result = prime * result + ((expiDy == null) ? 0 : expiDy.hashCode());
		result = prime * result
				+ ((expiDyErr == null) ? 0 : expiDyErr.hashCode());
		result = prime * result
				+ ((housPrpsDvsn == null) ? 0 : housPrpsDvsn.hashCode());
		result = prime * result
				+ ((housPrpsDvsnErr == null) ? 0 : housPrpsDvsnErr.hashCode());
		result = prime * result
				+ ((incmrDvsn == null) ? 0 : incmrDvsn.hashCode());
		result = prime * result
				+ ((incmrDvsnErr == null) ? 0 : incmrDvsnErr.hashCode());
		result = prime * result
				+ ((infoMnbdyDvsn == null) ? 0 : infoMnbdyDvsn.hashCode());
		result = prime
				* result
				+ ((infoMnbdyDvsnErr == null) ? 0 : infoMnbdyDvsnErr.hashCode());
		result = prime * result + ((inhrtYn == null) ? 0 : inhrtYn.hashCode());
		result = prime * result
				+ ((inhrtYnErr == null) ? 0 : inhrtYnErr.hashCode());
		result = prime * result
				+ ((mgntTgmCd == null) ? 0 : mgntTgmCd.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((nameErr == null) ? 0 : nameErr.hashCode());
		result = prime * result
				+ ((openOffcCd == null) ? 0 : openOffcCd.hashCode());
		result = prime * result
				+ ((openOffcCdErr == null) ? 0 : openOffcCdErr.hashCode());
		result = prime * result
				+ ((prcsDofOrgNo == null) ? 0 : prcsDofOrgNo.hashCode());
		result = prime * result + ((prcsEno == null) ? 0 : prcsEno.hashCode());
		result = prime * result
				+ ((prcsFofOrgNo == null) ? 0 : prcsFofOrgNo.hashCode());
		result = prime * result
				+ ((rcvInstCd == null) ? 0 : rcvInstCd.hashCode());
		result = prime * result + ((rrno == null) ? 0 : rrno.hashCode());
		result = prime * result
				+ ((rrnoDvsn == null) ? 0 : rrnoDvsn.hashCode());
		result = prime * result
				+ ((rrnoDvsnErr == null) ? 0 : rrnoDvsnErr.hashCode());
		result = prime * result + ((rrnoErr == null) ? 0 : rrnoErr.hashCode());
		result = prime * result + ((savgKnd == null) ? 0 : savgKnd.hashCode());
		result = prime * result
				+ ((savgKndErr == null) ? 0 : savgKndErr.hashCode());
		result = prime * result
				+ ((savgPrdcd == null) ? 0 : savgPrdcd.hashCode());
		result = prime * result
				+ ((sndInstCd == null) ? 0 : sndInstCd.hashCode());
		result = prime * result
				+ ((taxpfAmt == null) ? 0 : taxpfAmt.hashCode());
		result = prime * result
				+ ((taxpfAmtErr == null) ? 0 : taxpfAmtErr.hashCode());
		result = prime * result
				+ ((taxpfBzPrcsDcd == null) ? 0 : taxpfBzPrcsDcd.hashCode());
		result = prime * result
				+ ((tgmKndCd == null) ? 0 : tgmKndCd.hashCode());
		result = prime * result + ((trnsDtm == null) ? 0 : trnsDtm.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxpfRegDO other = (TaxpfRegDO) obj;
		if (actNo == null) {
			if (other.actNo != null)
				return false;
		} else if (!actNo.equals(other.actNo))
			return false;
		if (actNoErr == null) {
			if (other.actNoErr != null)
				return false;
		} else if (!actNoErr.equals(other.actNoErr))
			return false;
		if (actOpenDy == null) {
			if (other.actOpenDy != null)
				return false;
		} else if (!actOpenDy.equals(other.actOpenDy))
			return false;
		if (actOpenDyErr == null) {
			if (other.actOpenDyErr != null)
				return false;
		} else if (!actOpenDyErr.equals(other.actOpenDyErr))
			return false;
		if (assoBusiGb == null) {
			if (other.assoBusiGb != null)
				return false;
		} else if (!assoBusiGb.equals(other.assoBusiGb))
			return false;
		if (assoRspCd == null) {
			if (other.assoRspCd != null)
				return false;
		} else if (!assoRspCd.equals(other.assoRspCd))
			return false;
		if (conm == null) {
			if (other.conm != null)
				return false;
		} else if (!conm.equals(other.conm))
			return false;
		if (conmErr == null) {
			if (other.conmErr != null)
				return false;
		} else if (!conmErr.equals(other.conmErr))
			return false;
		if (contNo == null) {
			if (other.contNo != null)
				return false;
		} else if (!contNo.equals(other.contNo))
			return false;
		if (dpsTxNo == null) {
			if (other.dpsTxNo != null)
				return false;
		} else if (!dpsTxNo.equals(other.dpsTxNo))
			return false;
		if (expiDy == null) {
			if (other.expiDy != null)
				return false;
		} else if (!expiDy.equals(other.expiDy))
			return false;
		if (expiDyErr == null) {
			if (other.expiDyErr != null)
				return false;
		} else if (!expiDyErr.equals(other.expiDyErr))
			return false;
		if (housPrpsDvsn == null) {
			if (other.housPrpsDvsn != null)
				return false;
		} else if (!housPrpsDvsn.equals(other.housPrpsDvsn))
			return false;
		if (housPrpsDvsnErr == null) {
			if (other.housPrpsDvsnErr != null)
				return false;
		} else if (!housPrpsDvsnErr.equals(other.housPrpsDvsnErr))
			return false;
		if (incmrDvsn == null) {
			if (other.incmrDvsn != null)
				return false;
		} else if (!incmrDvsn.equals(other.incmrDvsn))
			return false;
		if (incmrDvsnErr == null) {
			if (other.incmrDvsnErr != null)
				return false;
		} else if (!incmrDvsnErr.equals(other.incmrDvsnErr))
			return false;
		if (infoMnbdyDvsn == null) {
			if (other.infoMnbdyDvsn != null)
				return false;
		} else if (!infoMnbdyDvsn.equals(other.infoMnbdyDvsn))
			return false;
		if (infoMnbdyDvsnErr == null) {
			if (other.infoMnbdyDvsnErr != null)
				return false;
		} else if (!infoMnbdyDvsnErr.equals(other.infoMnbdyDvsnErr))
			return false;
		if (inhrtYn == null) {
			if (other.inhrtYn != null)
				return false;
		} else if (!inhrtYn.equals(other.inhrtYn))
			return false;
		if (inhrtYnErr == null) {
			if (other.inhrtYnErr != null)
				return false;
		} else if (!inhrtYnErr.equals(other.inhrtYnErr))
			return false;
		if (mgntTgmCd == null) {
			if (other.mgntTgmCd != null)
				return false;
		} else if (!mgntTgmCd.equals(other.mgntTgmCd))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (nameErr == null) {
			if (other.nameErr != null)
				return false;
		} else if (!nameErr.equals(other.nameErr))
			return false;
		if (openOffcCd == null) {
			if (other.openOffcCd != null)
				return false;
		} else if (!openOffcCd.equals(other.openOffcCd))
			return false;
		if (openOffcCdErr == null) {
			if (other.openOffcCdErr != null)
				return false;
		} else if (!openOffcCdErr.equals(other.openOffcCdErr))
			return false;
		if (prcsDofOrgNo == null) {
			if (other.prcsDofOrgNo != null)
				return false;
		} else if (!prcsDofOrgNo.equals(other.prcsDofOrgNo))
			return false;
		if (prcsEno == null) {
			if (other.prcsEno != null)
				return false;
		} else if (!prcsEno.equals(other.prcsEno))
			return false;
		if (prcsFofOrgNo == null) {
			if (other.prcsFofOrgNo != null)
				return false;
		} else if (!prcsFofOrgNo.equals(other.prcsFofOrgNo))
			return false;
		if (rcvInstCd == null) {
			if (other.rcvInstCd != null)
				return false;
		} else if (!rcvInstCd.equals(other.rcvInstCd))
			return false;
		if (rrno == null) {
			if (other.rrno != null)
				return false;
		} else if (!rrno.equals(other.rrno))
			return false;
		if (rrnoDvsn == null) {
			if (other.rrnoDvsn != null)
				return false;
		} else if (!rrnoDvsn.equals(other.rrnoDvsn))
			return false;
		if (rrnoDvsnErr == null) {
			if (other.rrnoDvsnErr != null)
				return false;
		} else if (!rrnoDvsnErr.equals(other.rrnoDvsnErr))
			return false;
		if (rrnoErr == null) {
			if (other.rrnoErr != null)
				return false;
		} else if (!rrnoErr.equals(other.rrnoErr))
			return false;
		if (savgKnd == null) {
			if (other.savgKnd != null)
				return false;
		} else if (!savgKnd.equals(other.savgKnd))
			return false;
		if (savgKndErr == null) {
			if (other.savgKndErr != null)
				return false;
		} else if (!savgKndErr.equals(other.savgKndErr))
			return false;
		if (savgPrdcd == null) {
			if (other.savgPrdcd != null)
				return false;
		} else if (!savgPrdcd.equals(other.savgPrdcd))
			return false;
		if (sndInstCd == null) {
			if (other.sndInstCd != null)
				return false;
		} else if (!sndInstCd.equals(other.sndInstCd))
			return false;
		if (taxpfAmt == null) {
			if (other.taxpfAmt != null)
				return false;
		} else if (!taxpfAmt.equals(other.taxpfAmt))
			return false;
		if (taxpfAmtErr == null) {
			if (other.taxpfAmtErr != null)
				return false;
		} else if (!taxpfAmtErr.equals(other.taxpfAmtErr))
			return false;
		if (taxpfBzPrcsDcd == null) {
			if (other.taxpfBzPrcsDcd != null)
				return false;
		} else if (!taxpfBzPrcsDcd.equals(other.taxpfBzPrcsDcd))
			return false;
		if (tgmKndCd == null) {
			if (other.tgmKndCd != null)
				return false;
		} else if (!tgmKndCd.equals(other.tgmKndCd))
			return false;
		if (trnsDtm == null) {
			if (other.trnsDtm != null)
				return false;
		} else if (!trnsDtm.equals(other.trnsDtm))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TaxpfRegDO [rrno=" + rrno + ", rrnoDvsn=" + rrnoDvsn
				+ ", conm=" + conm + ", name=" + name + ", infoMnbdyDvsn="
				+ infoMnbdyDvsn + ", incmrDvsn=" + incmrDvsn + ", savgKnd="
				+ savgKnd + ", openOffcCd=" + openOffcCd + ", actNo=" + actNo
				+ ", actOpenDy=" + actOpenDy + ", taxpfAmt=" + taxpfAmt
				+ ", expiDy=" + expiDy + ", inhrtYn=" + inhrtYn
				+ ", housPrpsDvsn=" + housPrpsDvsn + ", rrnoErr=" + rrnoErr
				+ ", rrnoDvsnErr=" + rrnoDvsnErr + ", conmErr=" + conmErr
				+ ", nameErr=" + nameErr + ", infoMnbdyDvsnErr="
				+ infoMnbdyDvsnErr + ", incmrDvsnErr=" + incmrDvsnErr
				+ ", savgKndErr=" + savgKndErr + ", openOffcCdErr="
				+ openOffcCdErr + ", actNoErr=" + actNoErr + ", actOpenDyErr="
				+ actOpenDyErr + ", taxpfAmtErr=" + taxpfAmtErr
				+ ", expiDyErr=" + expiDyErr + ", inhrtYnErr=" + inhrtYnErr
				+ ", dpsTxNo=" + dpsTxNo + ", prcsDofOrgNo=" + prcsDofOrgNo
				+ ", prcsFofOrgNo=" + prcsFofOrgNo + ", prcsEno=" + prcsEno
				+ ", contNo=" + contNo + ", tgmKndCd=" + tgmKndCd
				+ ", assoBusiGb=" + assoBusiGb + ", trnsDtm=" + trnsDtm
				+ ", mgntTgmCd=" + mgntTgmCd + ", sndInstCd=" + sndInstCd
				+ ", rcvInstCd=" + rcvInstCd + ", assoRspCd=" + assoRspCd
				+ ", taxpfBzPrcsDcd=" + taxpfBzPrcsDcd + ", savgPrdcd="
				+ savgPrdcd + ", housPrpsDvsnErr=" + housPrpsDvsnErr + "]";
	}

}
