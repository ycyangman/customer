/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Tue Jul 16 00:29:53 VET 2013
 * 
 */
package cigna.cm.t.domain;

import java.io.Serializable;

/**
 * @DataObjectName TaxpfReptMtr
 * @Description 
 */
public class TaxpfReptMtrDO implements Serializable, Cloneable {

	private static final long serialVersionUID = -1306591813L;
	/**
	 * @Type java.lang.String
	 * @Name rescsDcd
	 * @Description 해지구분코드
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String rescsDcd;
	/**
	 * @Type java.lang.String
	 * @Name regOffc
	 * @Description 등록점포
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String regOffc;
	/**
	 * @Type java.lang.String
	 * @Name actNo
	 * @Description 계좌번호
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String actNo;
	/**
	 * @Type java.lang.String
	 * @Name savgKcd
	 * @Description 저축종류
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgKcd;
	/**
	 * @Type java.lang.String
	 * @Name savgNewDt
	 * @Description 저축신규일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgNewDt;
	/**
	 * @Type java.lang.String
	 * @Name savgLastChgDt
	 * @Description 저축최종변경일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String savgLastChgDt;
	/**
	 * @Type java.lang.String
	 * @Name taxpfEntAmt
	 * @Description 세금우대가입금액
	 * @Length 0
	 * @Decimal 0
	 */
	private java.math.BigDecimal taxpfEntAmt;
	/**
	 * @Type java.lang.String
	 * @Name expiDt
	 * @Description 만기일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String expiDt;
	/**
	 * @Type java.lang.String
	 * @Name taxpfRescsDt
	 * @Description 세금우대해지일
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String taxpfRescsDt;
	/**
	 * @Type java.lang.String
	 * @Name intDividPayAmt
	 * @Description 이자배당지급액
	 * @Length 0
	 * @Decimal 0
	 */
	private java.math.BigDecimal intDividPayAmt;
	/**
	 * @Type java.lang.String
	 * @Name heirYn
	 * @Description 상속여부
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String heirYn;
	/**
	 * @Type java.lang.String
	 * @Name housPrpsDpstDcd
	 * @Description 주택청약예부금구분
	 * @Length 0
	 * @Decimal 0
	 */
	private java.lang.String housPrpsDpstDcd;

	
	/**
	 * GET 해지구분코드
	 */
	public java.lang.String getRescsDcd() {
		return this.rescsDcd;
	}

	/**
	 * SET 해지구분코드
	 */
	public void setRescsDcd(java.lang.String rescsDcd) {
		this.rescsDcd = rescsDcd;
	}

	/**
	 * GET 등록점포
	 */
	public java.lang.String getRegOffc() {
		return this.regOffc;
	}

	/**
	 * SET 등록점포
	 */
	public void setRegOffc(java.lang.String regOffc) {
		this.regOffc = regOffc;
	}

	/**
	 * GET 계좌번호
	 */
	public java.lang.String getActNo() {
		return this.actNo;
	}

	/**
	 * SET 계좌번호
	 */
	public void setActNo(java.lang.String actNo) {
		this.actNo = actNo;
	}

	/**
	 * GET 저축종류
	 */
	public java.lang.String getSavgKcd() {
		return this.savgKcd;
	}

	/**
	 * SET 저축종류
	 */
	public void setSavgKcd(java.lang.String savgKcd) {
		this.savgKcd = savgKcd;
	}

	/**
	 * GET 저축신규일
	 */
	public java.lang.String getSavgNewDt() {
		return this.savgNewDt;
	}

	/**
	 * SET 저축신규일
	 */
	public void setSavgNewDt(java.lang.String savgNewDt) {
		this.savgNewDt = savgNewDt;
	}

	/**
	 * GET 저축최종변경일
	 */
	public java.lang.String getSavgLastChgDt() {
		return this.savgLastChgDt;
	}

	/**
	 * SET 저축최종변경일
	 */
	public void setSavgLastChgDt(java.lang.String savgLastChgDt) {
		this.savgLastChgDt = savgLastChgDt;
	}

	/**
	 * GET 세금우대가입금액
	 */
	public java.math.BigDecimal getTaxpfEntAmt() {
		return this.taxpfEntAmt;
	}

	/**
	 * SET 세금우대가입금액
	 */
	public void setTaxpfEntAmt(java.math.BigDecimal taxpfEntAmt) {
		this.taxpfEntAmt = taxpfEntAmt;
	}

	/**
	 * GET 만기일
	 */
	public java.lang.String getExpiDt() {
		return this.expiDt;
	}

	/**
	 * SET 만기일
	 */
	public void setExpiDt(java.lang.String expiDt) {
		this.expiDt = expiDt;
	}

	/**
	 * GET 세금우대해지일
	 */
	public java.lang.String getTaxpfRescsDt() {
		return this.taxpfRescsDt;
	}

	/**
	 * SET 세금우대해지일
	 */
	public void setTaxpfRescsDt(java.lang.String taxpfRescsDt) {
		this.taxpfRescsDt = taxpfRescsDt;
	}

	/**
	 * GET 이자배당지급액
	 */
	public java.math.BigDecimal getIntDividPayAmt() {
		return this.intDividPayAmt;
	}

	/**
	 * SET 이자배당지급액
	 */
	public void setIntDividPayAmt(java.math.BigDecimal intDividPayAmt) {
		this.intDividPayAmt = intDividPayAmt;
	}

	/**
	 * GET 상속여부
	 */
	public java.lang.String getHeirYn() {
		return this.heirYn;
	}

	/**
	 * SET 상속여부
	 */
	public void setHeirYn(java.lang.String heirYn) {
		this.heirYn = heirYn;
	}

	/**
	 * GET 주택청약예부금구분
	 */
	public java.lang.String getHousPrpsDpstDcd() {
		return this.housPrpsDpstDcd;
	}

	/**
	 * SET 주택청약예부금구분
	 */
	public void setHousPrpsDpstDcd(java.lang.String housPrpsDpstDcd) {
		this.housPrpsDpstDcd = housPrpsDpstDcd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actNo == null) ? 0 : actNo.hashCode());
		result = prime * result + ((expiDt == null) ? 0 : expiDt.hashCode());
		result = prime * result + ((heirYn == null) ? 0 : heirYn.hashCode());
		result = prime * result
				+ ((housPrpsDpstDcd == null) ? 0 : housPrpsDpstDcd.hashCode());
		result = prime * result
				+ ((intDividPayAmt == null) ? 0 : intDividPayAmt.hashCode());
		result = prime * result + ((regOffc == null) ? 0 : regOffc.hashCode());
		result = prime * result
				+ ((rescsDcd == null) ? 0 : rescsDcd.hashCode());
		result = prime * result + ((savgKcd == null) ? 0 : savgKcd.hashCode());
		result = prime * result
				+ ((savgLastChgDt == null) ? 0 : savgLastChgDt.hashCode());
		result = prime * result
				+ ((savgNewDt == null) ? 0 : savgNewDt.hashCode());
		result = prime * result
				+ ((taxpfEntAmt == null) ? 0 : taxpfEntAmt.hashCode());
		result = prime * result
				+ ((taxpfRescsDt == null) ? 0 : taxpfRescsDt.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxpfReptMtrDO other = (TaxpfReptMtrDO) obj;
		if (actNo == null) {
			if (other.actNo != null)
				return false;
		} else if (!actNo.equals(other.actNo))
			return false;
		if (expiDt == null) {
			if (other.expiDt != null)
				return false;
		} else if (!expiDt.equals(other.expiDt))
			return false;
		if (heirYn == null) {
			if (other.heirYn != null)
				return false;
		} else if (!heirYn.equals(other.heirYn))
			return false;
		if (housPrpsDpstDcd == null) {
			if (other.housPrpsDpstDcd != null)
				return false;
		} else if (!housPrpsDpstDcd.equals(other.housPrpsDpstDcd))
			return false;
		if (intDividPayAmt == null) {
			if (other.intDividPayAmt != null)
				return false;
		} else if (!intDividPayAmt.equals(other.intDividPayAmt))
			return false;
		if (regOffc == null) {
			if (other.regOffc != null)
				return false;
		} else if (!regOffc.equals(other.regOffc))
			return false;
		if (rescsDcd == null) {
			if (other.rescsDcd != null)
				return false;
		} else if (!rescsDcd.equals(other.rescsDcd))
			return false;
		if (savgKcd == null) {
			if (other.savgKcd != null)
				return false;
		} else if (!savgKcd.equals(other.savgKcd))
			return false;
		if (savgLastChgDt == null) {
			if (other.savgLastChgDt != null)
				return false;
		} else if (!savgLastChgDt.equals(other.savgLastChgDt))
			return false;
		if (savgNewDt == null) {
			if (other.savgNewDt != null)
				return false;
		} else if (!savgNewDt.equals(other.savgNewDt))
			return false;
		if (taxpfEntAmt == null) {
			if (other.taxpfEntAmt != null)
				return false;
		} else if (!taxpfEntAmt.equals(other.taxpfEntAmt))
			return false;
		if (taxpfRescsDt == null) {
			if (other.taxpfRescsDt != null)
				return false;
		} else if (!taxpfRescsDt.equals(other.taxpfRescsDt))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TaxpfReptMtrDO [rescsDcd=" + rescsDcd + ", regOffc=" + regOffc
				+ ", actNo=" + actNo + ", savgKcd=" + savgKcd + ", savgNewDt="
				+ savgNewDt + ", savgLastChgDt=" + savgLastChgDt
				+ ", taxpfEntAmt=" + taxpfEntAmt + ", expiDt=" + expiDt
				+ ", taxpfRescsDt=" + taxpfRescsDt + ", intDividPayAmt="
				+ intDividPayAmt + ", heirYn=" + heirYn + ", housPrpsDpstDcd="
				+ housPrpsDpstDcd + "]";
	}

}
