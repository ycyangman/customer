/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Fri Jul 19 04:00:43 VET 2013
 * 
 */
package cigna.cm.t.domain;

import java.io.Serializable;

/**
 * @DataObjectName TaxpfSavgKndDvsnReqDO
 * @Description 
 */
public class TaxpfSavgKndDvsnReqDO implements Serializable, Cloneable {

	private static final long serialVersionUID = 1573663443L;
	
	/**
	 * @Type java.lang.String
	 * @Name prpenTaxsysQufcDcd
	 * @Description 개인연금세제적격구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String prpenTaxsysQufcDcd;
	
	/**
	 * @Type java.lang.String
	 * @Name pogContDcd
	 * @Description 개인단체계약구분코드
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String contBzDcd;
	/**
	 * @Type java.lang.String
	 * @Name pogContDcd
	 * @Description 계약자개인여부
	 * @Length 1
	 * @Decimal 0
	 */
	private java.lang.String contrIndYn;
	/**
	 * @Type java.lang.Integer
	 * @Name pmPrd
	 * @Description 납입기간
	 * @Length 3
	 * @Decimal 0
	 */
	private java.lang.Integer pmPrd;
	/**
	 * @Type java.lang.Integer
	 * @Name insPrdYcnt
	 * @Description 보험기간년수
	 * @Length 3
	 * @Decimal 0
	 */
	private java.lang.Integer insPrdYcnt;
	/**
	 * @Type java.lang.String
	 * @Name pmCylCd
	 * @Description 납입주기코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String pmCylCd;
	/**
	 * @Type java.lang.Integer
	 * @Name ppyNts
	 * @Description 선납횟수
	 * @Length 3
	 * @Decimal 0
	 */
	private java.lang.Integer ppyNts;
	/**
	 * @Type java.lang.Integer
	 * @Name antyOpnAge
	 * @Description 연금개시연령
	 * @Length 3
	 * @Decimal 0
	 */
	private java.lang.Integer antyOpnAge;
	/**
	 * @Type java.lang.String
	 * @Name prdcd
	 * @Description 상품코드
	 * @Length 6
	 * @Decimal 0
	 */
	private java.lang.String prdcd;
	/**
	 * @Type java.lang.String
	 * @Name contrCustNo
	 * @Description 계약자고객번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String contrCustNo;
	/**
	 * @Type java.lang.String
	 * @Name pinsdCustNo
	 * @Description 주피보험자고객번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String pinsdCustNo;
	
	/**
	 * @Type java.lang.String
	 * @Name custRrno
	 * @Description 고객주민번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String custRrno;
	
	/**
	 * @Type java.lang.String
	 * @Name expiBenfcCustNo
	 * @Description 만기수익자고객번호
	 * @Length 9
	 * @Decimal 0
	 */
	private java.lang.String expiBenfcCustNo;
	/**
	 * @Type java.lang.String
	 * @Name expiBenfcCustNo
	 * @Description 상품중분류코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String prodMclsCd;
	/**
	 * @Type java.lang.String
	 * @Name expiBenfcCustNo
	 * @Description 전환옵션선택유형코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String swtopSelTpcd;
	
	private java.lang.String chnlDcd;

	public java.lang.String getPrpenTaxsysQufcDcd() {
		return prpenTaxsysQufcDcd;
	}

	public void setPrpenTaxsysQufcDcd(java.lang.String prpenTaxsysQufcDcd) {
		this.prpenTaxsysQufcDcd = prpenTaxsysQufcDcd;
	}

	public java.lang.String getContBzDcd() {
		return contBzDcd;
	}

	public void setContBzDcd(java.lang.String contBzDcd) {
		this.contBzDcd = contBzDcd;
	}

	public java.lang.String getContrIndYn() {
		return contrIndYn;
	}

	public void setContrIndYn(java.lang.String contrIndYn) {
		this.contrIndYn = contrIndYn;
	}

	public java.lang.Integer getPmPrd() {
		return pmPrd;
	}

	public void setPmPrd(java.lang.Integer pmPrd) {
		this.pmPrd = pmPrd;
	}

	public java.lang.Integer getInsPrdYcnt() {
		return insPrdYcnt;
	}

	public void setInsPrdYcnt(java.lang.Integer insPrdYcnt) {
		this.insPrdYcnt = insPrdYcnt;
	}

	public java.lang.String getPmCylCd() {
		return pmCylCd;
	}

	public void setPmCylCd(java.lang.String pmCylCd) {
		this.pmCylCd = pmCylCd;
	}

	public java.lang.Integer getPpyNts() {
		return ppyNts;
	}

	public void setPpyNts(java.lang.Integer ppyNts) {
		this.ppyNts = ppyNts;
	}

	public java.lang.Integer getAntyOpnAge() {
		return antyOpnAge;
	}

	public void setAntyOpnAge(java.lang.Integer antyOpnAge) {
		this.antyOpnAge = antyOpnAge;
	}

	public java.lang.String getPrdcd() {
		return prdcd;
	}

	public void setPrdcd(java.lang.String prdcd) {
		this.prdcd = prdcd;
	}

	public java.lang.String getContrCustNo() {
		return contrCustNo;
	}

	public void setContrCustNo(java.lang.String contrCustNo) {
		this.contrCustNo = contrCustNo;
	}

	public java.lang.String getPinsdCustNo() {
		return pinsdCustNo;
	}

	public void setPinsdCustNo(java.lang.String pinsdCustNo) {
		this.pinsdCustNo = pinsdCustNo;
	}

	public java.lang.String getCustRrno() {
		return custRrno;
	}

	public void setCustRrno(java.lang.String custRrno) {
		this.custRrno = custRrno;
	}

	public java.lang.String getExpiBenfcCustNo() {
		return expiBenfcCustNo;
	}

	public void setExpiBenfcCustNo(java.lang.String expiBenfcCustNo) {
		this.expiBenfcCustNo = expiBenfcCustNo;
	}

	public java.lang.String getProdMclsCd() {
		return prodMclsCd;
	}

	public void setProdMclsCd(java.lang.String prodMclsCd) {
		this.prodMclsCd = prodMclsCd;
	}

	public java.lang.String getSwtopSelTpcd() {
		return swtopSelTpcd;
	}

	public void setSwtopSelTpcd(java.lang.String swtopSelTpcd) {
		this.swtopSelTpcd = swtopSelTpcd;
	}

	public java.lang.String getChnlDcd() {
		return chnlDcd;
	}

	public void setChnlDcd(java.lang.String chnlDcd) {
		this.chnlDcd = chnlDcd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((antyOpnAge == null) ? 0 : antyOpnAge.hashCode());
		result = prime * result + ((chnlDcd == null) ? 0 : chnlDcd.hashCode());
		result = prime * result
				+ ((contBzDcd == null) ? 0 : contBzDcd.hashCode());
		result = prime * result
				+ ((contrCustNo == null) ? 0 : contrCustNo.hashCode());
		result = prime * result
				+ ((contrIndYn == null) ? 0 : contrIndYn.hashCode());
		result = prime * result
				+ ((custRrno == null) ? 0 : custRrno.hashCode());
		result = prime * result
				+ ((expiBenfcCustNo == null) ? 0 : expiBenfcCustNo.hashCode());
		result = prime * result
				+ ((insPrdYcnt == null) ? 0 : insPrdYcnt.hashCode());
		result = prime * result
				+ ((pinsdCustNo == null) ? 0 : pinsdCustNo.hashCode());
		result = prime * result + ((pmCylCd == null) ? 0 : pmCylCd.hashCode());
		result = prime * result + ((pmPrd == null) ? 0 : pmPrd.hashCode());
		result = prime * result + ((ppyNts == null) ? 0 : ppyNts.hashCode());
		result = prime * result + ((prdcd == null) ? 0 : prdcd.hashCode());
		result = prime * result
				+ ((prodMclsCd == null) ? 0 : prodMclsCd.hashCode());
		result = prime
				* result
				+ ((prpenTaxsysQufcDcd == null) ? 0 : prpenTaxsysQufcDcd
						.hashCode());
		result = prime * result
				+ ((swtopSelTpcd == null) ? 0 : swtopSelTpcd.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxpfSavgKndDvsnReqDO other = (TaxpfSavgKndDvsnReqDO) obj;
		if (antyOpnAge == null) {
			if (other.antyOpnAge != null)
				return false;
		} else if (!antyOpnAge.equals(other.antyOpnAge))
			return false;
		if (chnlDcd == null) {
			if (other.chnlDcd != null)
				return false;
		} else if (!chnlDcd.equals(other.chnlDcd))
			return false;
		if (contBzDcd == null) {
			if (other.contBzDcd != null)
				return false;
		} else if (!contBzDcd.equals(other.contBzDcd))
			return false;
		if (contrCustNo == null) {
			if (other.contrCustNo != null)
				return false;
		} else if (!contrCustNo.equals(other.contrCustNo))
			return false;
		if (contrIndYn == null) {
			if (other.contrIndYn != null)
				return false;
		} else if (!contrIndYn.equals(other.contrIndYn))
			return false;
		if (custRrno == null) {
			if (other.custRrno != null)
				return false;
		} else if (!custRrno.equals(other.custRrno))
			return false;
		if (expiBenfcCustNo == null) {
			if (other.expiBenfcCustNo != null)
				return false;
		} else if (!expiBenfcCustNo.equals(other.expiBenfcCustNo))
			return false;
		if (insPrdYcnt == null) {
			if (other.insPrdYcnt != null)
				return false;
		} else if (!insPrdYcnt.equals(other.insPrdYcnt))
			return false;
		if (pinsdCustNo == null) {
			if (other.pinsdCustNo != null)
				return false;
		} else if (!pinsdCustNo.equals(other.pinsdCustNo))
			return false;
		if (pmCylCd == null) {
			if (other.pmCylCd != null)
				return false;
		} else if (!pmCylCd.equals(other.pmCylCd))
			return false;
		if (pmPrd == null) {
			if (other.pmPrd != null)
				return false;
		} else if (!pmPrd.equals(other.pmPrd))
			return false;
		if (ppyNts == null) {
			if (other.ppyNts != null)
				return false;
		} else if (!ppyNts.equals(other.ppyNts))
			return false;
		if (prdcd == null) {
			if (other.prdcd != null)
				return false;
		} else if (!prdcd.equals(other.prdcd))
			return false;
		if (prodMclsCd == null) {
			if (other.prodMclsCd != null)
				return false;
		} else if (!prodMclsCd.equals(other.prodMclsCd))
			return false;
		if (prpenTaxsysQufcDcd == null) {
			if (other.prpenTaxsysQufcDcd != null)
				return false;
		} else if (!prpenTaxsysQufcDcd.equals(other.prpenTaxsysQufcDcd))
			return false;
		if (swtopSelTpcd == null) {
			if (other.swtopSelTpcd != null)
				return false;
		} else if (!swtopSelTpcd.equals(other.swtopSelTpcd))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TaxpfSavgKndDvsnReqDO [prpenTaxsysQufcDcd=");
		builder.append(prpenTaxsysQufcDcd);
		builder.append(", contBzDcd=");
		builder.append(contBzDcd);
		builder.append(", contrIndYn=");
		builder.append(contrIndYn);
		builder.append(", pmPrd=");
		builder.append(pmPrd);
		builder.append(", insPrdYcnt=");
		builder.append(insPrdYcnt);
		builder.append(", pmCylCd=");
		builder.append(pmCylCd);
		builder.append(", ppyNts=");
		builder.append(ppyNts);
		builder.append(", antyOpnAge=");
		builder.append(antyOpnAge);
		builder.append(", prdcd=");
		builder.append(prdcd);
		builder.append(", contrCustNo=");
		builder.append(contrCustNo);
		builder.append(", pinsdCustNo=");
		builder.append(pinsdCustNo);
		builder.append(", custRrno=");
		builder.append(custRrno);
		builder.append(", expiBenfcCustNo=");
		builder.append(expiBenfcCustNo);
		builder.append(", prodMclsCd=");
		builder.append(prodMclsCd);
		builder.append(", swtopSelTpcd=");
		builder.append(swtopSelTpcd);
		builder.append(", chnlDcd=");
		builder.append(chnlDcd);
		builder.append("]");
		return builder.toString();
	}

	

	
}
