/**
 * 이 클래스는 Data Object Wizard에서 생성 되었습니다.
 * 
 * @Generated Fri Jul 19 04:23:08 VET 2013
 * 
 */
package cigna.cm.t.domain;

import java.io.Serializable;

/**
 * @DataObjectName TaxpfSavgKndDvsnResDO
 * @Description 
 */
public class TaxpfSavgKndDvsnResDO implements Serializable, Cloneable {

	
	private static final long serialVersionUID = 1573665365L;
	/**
	 * @Type java.lang.String
	 * @Name savgPrdcd
	 * @Description 저축상품코드
	 * @Length 2
	 * @Decimal 0
	 */
	private java.lang.String savgPrdcd;

	/**
	 * GET 저축상품코드
	 */
	public java.lang.String getSavgPrdcd() {
		return this.savgPrdcd;
	}

	/**
	 * SET 저축상품코드
	 */
	public void setSavgPrdcd(java.lang.String savgPrdcd) {
		this.savgPrdcd = savgPrdcd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((savgPrdcd == null) ? 0 : savgPrdcd.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxpfSavgKndDvsnResDO other = (TaxpfSavgKndDvsnResDO) obj;
		if (savgPrdcd == null) {
			if (other.savgPrdcd != null)
				return false;
		} else if (!savgPrdcd.equals(other.savgPrdcd))
			return false;

		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("TaxpfSavgKndDvsnResDO[\n");
		sb.append("	savgPrdcd(저축상품코드) = " + savgPrdcd);
		sb.append("\n");
		sb.append("]");
		return sb.toString();
	}

}
