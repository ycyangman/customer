package cigna.cm.t.service;

import cigna.cm.t.dbio.CMT000DBIO;
import cigna.cm.t.io.CMT000SVC00In;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.cm.t.service.CMT000SVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2015. 2. 13.       신규 작성
 *
 */
@KlafService("CMT000SVC")
public class CMT000SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMT000DBIO cmt000dbio;
	
	@KlafServiceOperation("selectSingle0")
	public void selectSingle0(CMT000SVC00In input) throws ApplicationException {

		logger.debug("CMT000SVC-selectSingle0 start");
		
		cmt000dbio.selectMultiNONAME();
		
		String[] beanArray = LApplicationContext.getCurrentApplicationContext().getBeanDefinitionNames();
		
		logger.debug("beanArray:{}", beanArray);
		
		for(String beanName : beanArray) {
			logger.debug("생성된 빈 이름:{}", beanName);
		}
		
		logger.debug("CMT000SVC-selectSingle0 end");
		
	}
	
}