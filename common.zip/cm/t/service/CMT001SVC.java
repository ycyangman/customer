package cigna.cm.t.service;

import klaf.app.ApplicationException;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.t.bean.CMT001BEAN;
import cigna.cm.t.io.COM_F_KLIOAKOTS00001In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00004In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00006In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00007In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00008In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00010In;
import cigna.cm.t.io.COM_F_KLIOAKOTS00013In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00002In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00003In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00005In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00009In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00011In;
import cigna.cm.t.io.COM_F_KLIOSKOTS00012In;


/**
 * @file         cigna.cm.t.service.CMT000SVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2015. 2. 13.       신규 작성
 *
 */
@KlafService("CMT001SVC")
public class CMT001SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMT001BEAN cmt001bean;		// 세금우대
	
	/**
	 * 세금우대 저축종류별 한도조회 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate0")
	@TransactionalOperation
	public void changeUpdate0(COM_F_KLIOAKOTS00001In input) throws ApplicationException {
		
			
		if ("0210".equals(input.getTgmKndCd()) && "205".equals(input.getAssoBusiGb())) {
				
				cmt001bean.setTaxpfSavgKndClLmtInqRcv(input);
			
		}
		
	}
	
	/**
	 * 저축종류별세부등록내용조회 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate1")
	@TransactionalOperation
	public void changeUpdate1(COM_F_KLIOAKOTS00013In input) throws ApplicationException {
		
			
		if ("0210".equals(input.getTgmKndCd()) && "211".equals(input.getAssoBusiGb())) {
				
				cmt001bean.savgKcdDetlRegCtntInqRcv(input);
			
		}
		
	}
	
	/**
	 * 해당계좌번호 등록내용 조회 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate2")
	@TransactionalOperation
	public void changeUpdate2(COM_F_KLIOAKOTS00006In input) throws ApplicationException {
		
			
		if ("0210".equals(input.getTgmKndCd()) && "215".equals(input.getAssoBusiGb())) {
				
				cmt001bean.rlvActNoRegCtntInqRcv(input);
			
		}
		
	}
	
	/**
	 * 세금우대등록 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate3")
	@TransactionalOperation
	public void changeUpdate3(COM_F_KLIOAKOTS00007In input) throws ApplicationException {
		
			
		if ("0410".equals(input.getTgmKndCd()) && "210".equals(input.getAssoBusiGb())) {
				
				cmt001bean.taxpfRegRcv(input);
			
		}
		
	}
	
	/**
	 * 세금우대해지 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate4")
	@TransactionalOperation
	public void changeUpdate4(COM_F_KLIOAKOTS00008In input) throws ApplicationException {
		
			
		if ("0510".equals(input.getTgmKndCd()) && "210".equals(input.getAssoBusiGb())) {
				
				cmt001bean.taxpfRescsRcv(input);
			
		}
		
	}
	
	
	
	/**
	 * 세금우대정정 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate5")
	@TransactionalOperation
	public void changeUpdate5(COM_F_KLIOAKOTS00010In input) throws ApplicationException {
		
			
		if ("0610".equals(input.getTgmKndCd()) && "210".equals(input.getAssoBusiGb())) {
				
				cmt001bean.taxpfCorrcRcv(input);
			
		}
		
	}
	
	
	/**
	 * 저축종류별세부내역조회 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate6")
	@TransactionalOperation
	public void changeUpdate6(COM_F_KLIOAKOTS00004In input) throws ApplicationException {
			
		if ("0210".equals(input.getTgmKndCd()) && "216".equals(input.getAssoBusiGb())) {
				
				cmt001bean.savgKcdDetlCtntInqRcv(input);
			
		}
		
	}
	
	/**
	 * 세금우대 전 금융기관 등록내용 조회 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate7")
	@TransactionalOperation
	public void changeUpdate7(COM_F_KLIOSKOTS00002In input) throws ApplicationException {
			
		if ("0210".equals(input.getTgmKndCd()) && "210".equals(input.getAssoBusiGb())) {
				
				cmt001bean.bfFininRegCtntInqRcv(input);
			
		}
		
	}
	
	/**
	 * 세금우대 전 금융기관 등록내용추가 조회 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate8")
	@TransactionalOperation
	public void changeUpdate8(COM_F_KLIOSKOTS00003In input) throws ApplicationException {
			
		if ("0310".equals(input.getTgmKndCd()) && "210".equals(input.getAssoBusiGb())) {
				
				cmt001bean.bfFininRegCtntInqAddRcv(input);
			
		}
		
	}
	
	/**
	 * 세금우대해지취소 수신
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate9")
	@TransactionalOperation
	public void changeUpdate9(COM_F_KLIOSKOTS00009In input) throws ApplicationException {
			
		if ("0610".equals(input.getTgmKndCd()) && "260".equals(input.getAssoBusiGb())) {
				
				cmt001bean.taxpfRescsCnclRcv(input);
			
		}
		
	}
	
	/**
	 * 세금우대삭제
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate10")
	@TransactionalOperation
	public void changeUpdate10(COM_F_KLIOSKOTS00011In input) throws ApplicationException {
			
		if ("0610".equals(input.getTgmKndCd()) && "230".equals(input.getAssoBusiGb())) {
				
				cmt001bean.taxpfDelRcv(input);
			
		}
		
	}
	
	/**
	 * 세금우대 저축종류별세부내역추가조회
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate11")
	@TransactionalOperation
	public void changeUpdate11(COM_F_KLIOSKOTS00005In input) throws ApplicationException {
			
		if ("0310".equals(input.getTgmKndCd()) && "216".equals(input.getAssoBusiGb())) {
				
				cmt001bean.savgKcdDetlCtntInqAddRcv(input);
			
		}
		
	}
	
	/**
	 * 세금우대한도조회
	 * @param input OMM
	 * @return N/A
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate12")
	@TransactionalOperation
	public void changeUpdate12(COM_F_KLIOSKOTS00012In input) throws ApplicationException {
			
		if ("0210".equals(input.getTgmKndCd()) && "200".equals(input.getAssoBusiGb())) {
				
				cmt001bean.setTaxpfLmtInqRcv(input);
			
		}
		
	}
	
}