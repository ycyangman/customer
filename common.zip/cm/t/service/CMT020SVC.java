package cigna.cm.t.service;

import java.util.List;

import cigna.cm.t.bean.CMT020BEAN;
import cigna.cm.t.bean.CMT021BEAN;
import cigna.cm.t.io.CMT020SVC01In;
import cigna.cm.t.io.CMT020SVC01Out;
import cigna.cm.t.io.CMT020SVC02Out;
import cigna.cm.t.io.SelectMultiTBCNETC026aOut;
import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file         cigna.cm.t.service.CMT020SVC.java
 * @filetype     java source file
 * @brief        로그조회화면
 * @author       문규식
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------
 * 0.1           문규식                  2013. 7. 18.           신규 작성
 * 0.1           김위현                  2013. 7. 25.           상세조회 추가
 *
 */
@KlafService("CMT020SVC")
public class CMT020SVC {
    final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 로그화면조회 bean
     */
    @Autowired
    private CMT020BEAN cmt020bean;


    /**
     * 로그화면상세조회 bean
     */
    @Autowired
    private CMT021BEAN cmt021bean;

    /**
     * 로그화면조회
     *
     * @param CMT020SVC01In
     *
     */
    @KlafServiceOperation("selectList0")
    public CMT020SVC01Out selectList0(CMT020SVC01In input) throws ApplicationException {
        CMT020SVC01Out output = new CMT020SVC01Out();

        List<SelectMultiTBCNETC026aOut> list = null;

        // 로그화면 조회 bean 호출
        list = this.cmt020bean.getlogScrInq(input);

        output.setDsList(list);
        output.setDsListCnt(list.size()); // Output 데이타 건수 설정
        // 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다.
        if (DasUtils.existNextResult(list)) {
            output.setRecrdNxtYn("Y");
        } else {
            output.setRecrdNxtYn("N");
        }

        if (output.getDsListCnt() == 0)
            LApplicationContext.addMessage("KIOKI0004", null, null);
        else
            LApplicationContext.addMessage("KIOKI0002", new Object[] { output.getDsListCnt() }, null);

        return output;

    }


    /**
     * 로그상세화면조회
     *
     * @param CMT020SVC01In
     *
     */
    @KlafServiceOperation("selectList1")
    public CMT020SVC02Out selectList1(CMT020SVC01In input) throws ApplicationException {
        CMT020SVC02Out output = new CMT020SVC02Out();



        // 로그화면 조회 bean 호출
        output = this.cmt021bean.getLogDtls(input.getPrcsDtm(), input.getTaxpfTgmNo(), input.getDvsn());


        if (output.getResultCnt() == 0)
            LApplicationContext.addMessage("KIOKI0004", null, null);
        else
            LApplicationContext.addMessage("KIOKI0002", new Object[] { output.getResultCnt() }, null);

        return output;

    }

    /**
     * 전송처리
     *
     * @param CMT020SVC01In
     *
     */
    @KlafServiceOperation("changeInsert")
    @TransactionalOperation
    public CMT020SVC01Out changeInsert(CMT020SVC01In input) throws ApplicationException {
        CMT020SVC01Out output = new CMT020SVC01Out();
        int cnt  = cmt020bean.insertSend(input);

        /* 정상처리 결과 메시지: 입력하신 내용 {0}건이 저장 되었습니다. */
        LApplicationContext.addMessage("APDPI0043", new Object[]{ Integer.toString(cnt)},  null);
        output.setRstCnt(cnt);
        return output;

    }

}
