package cigna.cm.t.service;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.t.bean.CMT999BEAN;
import cigna.cm.t.io.CMT010SVC01In;
import cigna.cm.t.io.CMT010SVC01Out;


/**
 * @file         cigna.cm.t.service.CMT010SVC.java
 * @filetype     java source file
 * @brief        세금우대가입한도조회
 * @author       권문
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           권문                   2013. 7. 23.       신규 작성
 *
 */
@KlafService("CMT999SVC")
public class CMT999SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
    @Autowired
    private CMT999BEAN cmt999bean;
	
	/**
	 * 세금우대한도조회
	 * 
	 * @param input 계약번호가 세팅된 CMT010SVC01In OMM
	 * @return 주민등록번호로 세금우대한도정보 세팅된 CMT010SVC01Out OMM
	 * @throws ApplicationException
	 */
	@KlafServiceOperation( "selectList" )
	public CMT010SVC01Out selectList(CMT010SVC01In input) throws ApplicationException{
	
		logger.info("input SVC:{} ",input);
		
		CMT010SVC01Out output = new CMT010SVC01Out();
		
		//계약변경사항 조회		
		
		if ("COM_F_KLIOAKOTS00001".equals(input.getIsudTpcd())) {
			 output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "1" );
		} else if ("COM_F_KLIOAKOTS00002".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "2" );
		} else if ("COM_F_KLIOAKOTS00003".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "3" );
		} else if ("COM_F_KLIOAKOTS00004".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00005".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00006".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00007".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00008".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00009".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00010".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00011".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00012".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		} else if ("COM_F_KLIOAKOTS00013".equals(input.getIsudTpcd())) {
			output = cmt999bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd(), "4" );
		}
		
		logger.info("output SVC:{} ",output);
		
		if( output == null ){
			// 정상처리 결과 메시지: 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage("KIOKI0004",null, null);
		}
		else{
			// 정상처리 결과 메시지: 요청하신 내용이 조회 되었습니다. 
			LApplicationContext.addMessage("KIOKI0001",	null, null);
		}
		return output;
		
	}
}

