package cigna.cm.t.service;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.t.bean.CMT010BEAN;
import cigna.cm.t.io.CMT010SVC01Out;
import cigna.cm.t.io.COM_F_KLIOSKOTS00012In;


/**
 * @file         cigna.cm.t.service.CMTTest.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2016. 5. 19.       신규 작성
 *
 */
@KlafService("CMTTest")
public class CMTTest {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
    private CMT010BEAN cmt010bean;
	
	/**
	 * 세금우대 저축종류별 한도호죄 요청
	 * 
	 * @param input 계약번호가 세팅된 CMT010SVC01In OMM
	 * @return 주민등록번호로 세금우대한도정보 세팅된 CMT010SVC01Out OMM
	 * @throws ApplicationException
	 */
	@KlafServiceOperation( "selectList" )
	public CMT010SVC01Out selectList(COM_F_KLIOSKOTS00012In input) throws ApplicationException{
	
		logger.info("input SVC:{} ",input);
		
		
		CMT010SVC01Out output= null;
		
		//계약변경사항 조회		
		//CMT010SVC01Out output = cmt010bean.taxpfSavgKndClLmtInq( input.getCustNm(), input.getCustDscNo(), input.getSavgPrdcd(), input.getIsudTpcd() ,input.getMgntTgmCd() );
		
		logger.info("output SVC:{} ",output);
		
		if( output == null ){
			// 정상처리 결과 메시지: 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage("KIOKI0004",null, null);
		}
		else{
			// 정상처리 결과 메시지: 요청하신 내용이 조회 되었습니다. 
			LApplicationContext.addMessage("KIOKI0001",	null, null);
		}
		return output;
		
	}
}

