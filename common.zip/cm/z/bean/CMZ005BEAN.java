package cigna.cm.z.bean;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.dbio.CMZ005DBIO;
import cigna.cm.z.io.CMZ005SVC01In;
import cigna.cm.z.io.CMZ005SVC01Out;
import cigna.cm.z.io.CMZ005SVC02In;
import cigna.cm.z.io.TBSLEMP114Io;
import cigna.zz.FwUtil;


/**
 * @file         cigna.cm.z.bean.CMZ005BEAN.java
 * @filetype     java source file
 * @brief        TBSLEMP114[사원부가정보] 내근직원 내선번호, MacAdress 조회 및 저장 처리
 * @author       권슬기
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           권슬기          2016. 11. 7.       신규 작성
 *
 */
@KlafBean
public class CMZ005BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	

	/** 사원부가정보관리 DBIO */
	@Autowired
	CMZ005DBIO  cmz005dbio;
	
	/**
	 * 사원부가정보조회 ( 내근직원 내선번호, MacAdress )
	 * 
	 * @param  CMZ005SVC01In 
	 * @return CMZ005SVC01Out 
	 * @throws ApplicationException
	 */
	public CMZ005SVC01Out getEnoAdInfo(CMZ005SVC01In input) throws ApplicationException {

		logger.debug( "###### getEnoAdInfo Strat :[{}]", input);
		CMZ005SVC01Out output = new CMZ005SVC01Out();


		// 사원번호가 존재하지 않을경우
		if (StringUtils.isEmpty(input.getEno())) {

			// 오류메시지 : 필수항목 [{0}]을(를) 입력하여야 합니다.    
			throw new ApplicationException("APPDE0002", new Object[]{"사원번호", "사원번호"});	
		}
		// 사원번호로 부가정보 조회
		output = cmz005dbio.selectOneTBSLEMP114a( input.getEno() ); 
		
		logger.debug( "###### getEnoAdInfo End : [{}]", output);
		return output;
	}
	
	
	
	/**
	 * TBSLEMP114[사원부가정보] MERGE ( 내근직원 내선번호, MacAdress )
	 * 
	 * @param  CMZ005SVC02In 
	 * @return 	int 
	 * @throws ApplicationException
	 */
	public int mergeTBSLEMP114(CMZ005SVC02In input) throws ApplicationException {

		logger.debug( "###### mergeTBSLEMP114 Strat :[{}]", input);

		// 사원번호가 존재하지 않을경우
		if (StringUtils.isEmpty(input.getEno())) {
			// 오류메시지 : 필수항목 [{0}]을(를) 입력하여야 합니다.    
			throw new ApplicationException("APPDE0002", new Object[]{"사원번호", "사원번호"});	
		}

		TBSLEMP114Io tbslemp114Io = new TBSLEMP114Io();
		
		tbslemp114Io.setEno          ( input.getEno()     ); // 사원번호
		tbslemp114Io.setInlnNo       ( input.getInlnNo()  ); // 내선번호
		tbslemp114Io.setMacAddr      ( input.getMacAddr() ); // MAC주소
		tbslemp114Io.setLastChgrId   ( FwUtil.getUserId() ); // 최종변경자ID
		tbslemp114Io.setLastChgPgmId ( FwUtil.getPgmId()  ); // 최종변경프로그램ID
		tbslemp114Io.setLastChgTrmNo ( FwUtil.getTrmNo()  ); // 최종변경단말번호

		logger.debug( "###### mergeTBSLEMP114 수행값 : [{}]", tbslemp114Io);
		// TBSLEMP114[사원부가정보] insert
		int prcCnt = cmz005dbio.mergeOneTBSLEMP114( tbslemp114Io ); 
		
		logger.debug( "###### mergeTBSLEMP114 End : [{}]", prcCnt);
		return prcCnt;
	}
	
	
	
}

