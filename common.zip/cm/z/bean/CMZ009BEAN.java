package cigna.cm.z.bean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import cigna.cm.z.io.CMZ009SVC00Out;
import cigna.cm.z.io.CMZ009SVC00Sub;
import cigna.cm.z.io.CMZ009SVC01In;
import cigna.cm.z.io.CMZ009SVC01Out;
import cigna.zz.SrchAddrSAXParser;

/**
 * @file         cigna.cm.z.bean.CMZ009BEAN.java
 * @filetype     java source file
 * @brief        주소정재 BEAN
 * @author       박진성
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1    박진성                 2016. 3. 2.      신규작성
 *
 */
@KlafBean
public class CMZ009BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 지번 조회(우편번호 검색)
	 * 
	 * @param  CMZ009SVC00Sub 
	 * @return CMZ009SVC00Out 
	 * @throws ApplicationException
	 */
	public CMZ009SVC00Out getJibunAddress(CMZ009SVC00Sub input) throws ApplicationException {
		Map<String, Object> inputMap = new HashMap<String, Object>();
		inputMap.put("dong", input.getDong());
		//result = getResponse(JIBUN_NAME_SERVER_URL, inputMap);
		
		// 지번주소 API호출 및 파싱
		SrchAddrSAXParser srchAddrSAXParser = new SrchAddrSAXParser();
		srchAddrSAXParser.parse(SrchAddrSAXParser.JIBUN_NAME_SERVER_URL, inputMap);
		CMZ009SVC00Out srchAddrResult = srchAddrSAXParser.getSrchAddrResult();
		
		return srchAddrResult;
	}
	
	/**
	 * 도로명 조회(우편번호 검색)
	 * 
	 * @param  CMZ009SVC00Sub 
	 * @return CMZ009SVC00Out 
	 * @throws ApplicationException
	 */
	public CMZ009SVC00Out getRoadAddress(CMZ009SVC00Sub input) throws ApplicationException {
		Map<String, Object> inputMap = new HashMap<String, Object>();
		inputMap.put("sido", input.getSido());
		inputMap.put("gungu", input.getSigungu());
		inputMap.put("road", input.getRoad());
		inputMap.put("mainNo", input.getBldgMaiNo());
		inputMap.put("subNo", input.getBldgSbNo());
		inputMap.put("bldgNm", input.getBldgNm());
		//result = getResponse(ROAD_NAME_SERVER_URL, inputMap);
		
		// 도로명주소 API호출 및 파싱
		SrchAddrSAXParser srchAddrSAXParser = new SrchAddrSAXParser();
		srchAddrSAXParser.parse(SrchAddrSAXParser.ROAD_NAME_SERVER_URL, inputMap);
		CMZ009SVC00Out srchAddrResult = srchAddrSAXParser.getSrchAddrResult();
		
		return srchAddrResult;
	}
	
	/**
	 * 주소정재 조회
	 * 
	 * @param  CMZ009SVC00Sub 
	 * @return CMZ009SVC00Out 
	 * @throws ApplicationException
	 */
	public CMZ009SVC00Out getRefindAddress(CMZ009SVC00Sub input) throws ApplicationException {
		Map<String, Object> inputMap = new HashMap<String, Object>();
		inputMap.put("zipcode", input.getZipcode());
		inputMap.put("addr1", input.getAddr1());
		inputMap.put("addr2", input.getAddr2());
		inputMap.put("encoding", "UTF-8");
		inputMap.put("addrDiv", input.getAddrDiv());
		//result = getResponse(REFIND_ZIPCODE_SERVER_URL, inputMap);
		
		// 주소정재 API호출 및 파싱
		SrchAddrSAXParser srchAddrSAXParser = new SrchAddrSAXParser();
		srchAddrSAXParser.parse(SrchAddrSAXParser.REFIND_ZIPCODE_SERVER_URL, inputMap);
		CMZ009SVC00Out srchAddrResult = srchAddrSAXParser.getSrchAddrResult();
		
		return srchAddrResult;
	}
	
	/**
	 * 주소정재 조회
	 * 
	 * @param  CMZ009SVC00Sub 
	 * @return CMZ009SVC00Out 
	 * @throws ApplicationException
	 */
	public CMZ009SVC01Out getRefindAddress2(CMZ009SVC01In input) throws ApplicationException {
		Map<String, Object> inputMap = new HashMap<String, Object>();
		inputMap.put("zipcode", input.getZipcode());
		inputMap.put("addr1", input.getAddr1());
		inputMap.put("addr2", input.getAddr2());
		inputMap.put("encoding", "UTF-8");
		if ("1".equals(input.getNwoldAddrDcd())) { // 구주소
			inputMap.put("addrDiv", "J");
		} else { // 신주소
			inputMap.put("addrDiv", "N");
		}
		
		// 주소정재 API호출 및 파싱
		SrchAddrSAXParser srchAddrSAXParser = new SrchAddrSAXParser();
		srchAddrSAXParser.parse(SrchAddrSAXParser.REFIND_ZIPCODE_SERVER_URL, inputMap);
		CMZ009SVC00Out srchAddrResult = srchAddrSAXParser.getSrchAddrResult();
		
		List<CMZ009SVC00Sub> addrList = srchAddrResult.getAddrList();
		
		CMZ009SVC01Out output = new CMZ009SVC01Out();
		
		if (CollectionUtils.isEmpty(addrList)) {
			// 건수가 없다면 오류처리
			throw new ApplicationException("KIOKI0004", null);
		} else {
			CMZ009SVC00Sub addrInfo = addrList.get(0);
			
			if ("1".equals(input.getNwoldAddrDcd())) { // 입력이 구주소일경우 도로명주소를 반환한다
				if (StringUtils.isEmpty(addrInfo.getNewZipcode())
						|| "null".equals(addrInfo.getNewZipcode())) {
					// 건수가 없다면 오류처리
					throw new ApplicationException("KIOKI0004", null);
				}
				
				output.setZipcode(addrInfo.getNewZipcode());
				output.setAddr1(addrInfo.getNewAddr1());
				output.setAddr2(addrInfo.getNewAddr2() + " " + addrInfo.getNewAddrEtc1());
				output.setNwoldAddrDcd("2");
			} else { // 입력이 도로명주소일경우 지번주소를 반환한다
				if (StringUtils.isEmpty(addrInfo.getZipcode())
						|| "null".equals(addrInfo.getZipcode())) {
					// 건수가 없다면 오류처리
					throw new ApplicationException("KIOKI0004", null);
				}
				
				output.setZipcode(addrInfo.getZipcode());
				output.setAddr1(addrInfo.getAddr1());
				output.setAddr2(addrInfo.getAddr2());
				output.setNwoldAddrDcd("1");
			}
		}
		
		return output;
	}
	
}

