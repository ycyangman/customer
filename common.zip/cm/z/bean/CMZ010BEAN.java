package cigna.cm.z.bean;


import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import klaf.app.ApplicationException;
import klaf.common.util.CollectionUtils;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafBean;
import klaf.context.das.DasUtils;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA002BEAN;
import cigna.cm.a.bean.CMA010BEAN;
import cigna.cm.a.dbio.CMA201DBIO;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.a.domain.OrgInfo;
import cigna.cm.a.io.COM_E_DMIOS000000001In;
import cigna.cm.a.io.COM_E_DMIOS000000001Out;
import cigna.cm.a.io.TBCSPRF001Io;
import cigna.cm.z.dbio.CMZ010DBIO;
import cigna.cm.z.io.CMZ010SVC00In;
import cigna.cm.z.io.CMZ010SVC01In;
import cigna.cm.z.io.CMZ010SVC01Out;
import cigna.cm.z.io.CMZ010SVC03Sub;
import cigna.cm.z.io.COMEILSOS000000001In;
import cigna.cm.z.io.COMEILSOS000000001Out;
import cigna.cm.z.io.TBCMETC009Io;
import cigna.cm.z.io.TBCMETC010Io;
import cigna.cm.z.io.TBCMETC011Io;
import cigna.cm.z.io.TBCMETC012Io;
import cigna.zz.BizDateInfo;
import cigna.zz.BizUtil;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.SecuUtil;

/**
 * @file         cigna.cm.z.bean.CMZ010BEAN.java
 * @filetype     java source file
 * @brief        업무연락 BEAN
 * @author       박진성
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1    박진성                 2016. 3. 2.      신규작성
 *
 */
@KlafBean
public class CMZ010BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZ010DBIO cmz010dbio;
	
	@Autowired
	private CMA201DBIO cma201dbio;
	
	@Autowired
	private CMA002BEAN cma002bean;
	
	@Autowired
	private CMA010BEAN cma010bean;
	
	@Autowired
	private BizDateInfo bizdateinfo;

	/**
	 * 업무연락유형 목록 조회
	 * 
	 * @param  CMZ010SVC00In 업무연락유형
	 * @return List<TBCMETC009Io> 업무연락유형관리 테이블의 OMM
	 * @throws ApplicationException
	 */
	public List<TBCMETC009Io> getBzCntcTypeList(CMZ010SVC00In input) throws ApplicationException {
		String bzCntcTypId = StringUtils.nvl(input.getBzCntcTypId()); // 업무연락유형ID
		String bzCntcTypNm = StringUtils.nvl(input.getBzCntcTypNm());//업무연락유형명
		//String applOrgNo = StringUtils.nvl(input.getApplOrgNo()); // 신청조직번호
		String receOrgNo = StringUtils.nvl(input.getReceOrgNo()); // 수신조직번호
		String receChrgpEno = StringUtils.nvl(input.getReceChrgpEno());
		String useYn = StringUtils.nvl(input.getUseYn()); // 사용여부
		String delYn = StringUtils.nvl(input.getDelYn(), "N"); // 사용여부
		
		Integer pageCount = input.getPageCount(); // 조회할페이지번호
		Integer pageNum = input.getPageNum(); // 페이지 size
		
		List<TBCMETC009Io> selectMultiTBCMETC009a = cmz010dbio.selectMultiTBCMETC009a(bzCntcTypId, bzCntcTypNm, receOrgNo, receChrgpEno, useYn, delYn, pageNum, pageCount);

		return selectMultiTBCMETC009a;
	}
	
	/**
	 * 업무연락유형 목록 조회 이름순 정렬
	 * 
	 * @param  CMZ010SVC00In 업무연락유형
	 * @return List<TBCMETC009Io> 업무연락유형관리 테이블의 OMM
	 * @throws ApplicationException
	 */
	public List<TBCMETC009Io> getBzCntcTypeListSortByNm(CMZ010SVC00In input) throws ApplicationException {
		String bzCntcTypId = StringUtils.nvl(input.getBzCntcTypId()); // 업무연락유형ID
		String bzCntcTypNm = StringUtils.nvl(input.getBzCntcTypNm());//업무연락유형명
		//String applOrgNo = StringUtils.nvl(input.getApplOrgNo()); // 신청조직번호
		String receOrgNo = StringUtils.nvl(input.getReceOrgNo()); // 수신조직번호
		String receChrgpEno = StringUtils.nvl(input.getReceChrgpEno());
		String useYn = StringUtils.nvl(input.getUseYn()); // 사용여부
		String delYn = StringUtils.nvl(input.getDelYn(), "N"); // 사용여부
		
		Integer pageCount = input.getPageCount(); // 조회할페이지번호
		Integer pageNum = input.getPageNum(); // 페이지 size
		
		List<TBCMETC009Io> selectMultiTBCMETC009a = cmz010dbio.selectMultiTBCMETC009b(bzCntcTypId, bzCntcTypNm, receOrgNo, receChrgpEno, useYn, delYn, pageNum, pageCount);

		return selectMultiTBCMETC009a;
	}
	
	/**
	 * 업무연락유형 저장
	 * 
	 * @param  CMZ010SVC00In 업무연락유형
	 * @return int 저장된 개수
	 * @throws ApplicationException
	 */
	public int modifyBzCntcTypeList(CMZ010SVC00In input) throws ApplicationException {
		
		int successCnt = 0;
		List<TBCMETC009Io> bzCntcTypeList = input.getBzCntcTypeList();
		
		//저장 처리할 리스트 정보 체크
		if(bzCntcTypeList == null || bzCntcTypeList.size() < 1){
			throw new ApplicationException("APCME0009", new Object[]{"업무연락유형 리스트 화면정보는"}, new Object[]{});
		}
		
		for (TBCMETC009Io bzCntcTypeInfo : bzCntcTypeList) {
			// 필수입력 정보 체크
			
			if (StringUtils.isEmpty(bzCntcTypeInfo.getReceOrgNm())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"수신팀"}, new Object[]{});
			}
			
			if (StringUtils.isEmpty(bzCntcTypeInfo.getBzCntcTypId1())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"업무유형1"}, new Object[]{});
			}			
			if (StringUtils.isEmpty(bzCntcTypeInfo.getBzCntcTypNm1())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"업무유형명1"}, new Object[]{});
			}
			if (StringUtils.isEmpty(bzCntcTypeInfo.getBzCntcTypId2())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"업무유형2"}, new Object[]{});
			}			
			if (StringUtils.isEmpty(bzCntcTypeInfo.getBzCntcTypNm2())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"업무유형명2"}, new Object[]{});
			}
			
			if(!"S".equals(bzCntcTypeInfo.getFlgCd())) {
				TBCMETC009Io bzCntcTyp = cmz010dbio.selectOneTBCMETC009a(bzCntcTypeInfo.getBzCntcTypId1(),bzCntcTypeInfo.getBzCntcTypId2());
				
				if( bzCntcTyp != null) {
					throw new ApplicationException("APNBE0066", new String[] { "업무유형" });		
				}
			}
			
			bzCntcTypeInfo.setFstCrtrId(FwUtil.getUserId());
			bzCntcTypeInfo.setLastChgrId(FwUtil.getUserId());
			bzCntcTypeInfo.setLastChgPgmId(FwUtil.getPgmId());
			bzCntcTypeInfo.setLastChgTrmNo(FwUtil.getTrmNo());
			
			successCnt += cmz010dbio.mergeOneTBCMETC009(bzCntcTypeInfo);
		}
		
		return successCnt;
	}
	
	
	/**
	 * 업무연락 조회
	 * 
	 * @param  CMZ010SVC00In 업무연락
	 * @return TBCMETC010Io 공통업무연락 테이블의 OMM
	 * @throws ApplicationException
	 */
	public TBCMETC010Io getBzCntcInfo(CMZ010SVC01In input) throws ApplicationException {
		String bzCntcMgntNo = input.getBzCntcMgntNo();
		
		// 필수입력 정보 체크
		if (StringUtils.isEmpty(bzCntcMgntNo)) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"업무연락관리번호"}, new Object[]{});
		}
		
		TBCMETC010Io selectOneTBCMETC010a = cmz010dbio.selectOneTBCMETC010a(bzCntcMgntNo);
		if (selectOneTBCMETC010a != null) {
			SecuUtil.doDecObject(selectOneTBCMETC010a);
			
			String bzCntcReqCtnt = selectOneTBCMETC010a.getBzCntcReqCtnt();
			
			if( "MIG".equals(selectOneTBCMETC010a.getLastChgTrmNo()) && 
				!StringUtils.isEmpty(bzCntcReqCtnt) &&
				"R23".equals(selectOneTBCMETC010a.getBzCntcTypId1())) { //민원관련
				if( "S03".equals(selectOneTBCMETC010a.getBzCntcTypId2()) ||
					"S09".equals(selectOneTBCMETC010a.getBzCntcTypId2())) {
					
					String[] bzCntcReqCtntArr = bzCntcReqCtnt.split("@");
					
					StringBuffer sb = new StringBuffer();
					//소속팀 : 
					//민원인성명(연락처) : 
					//긴급통화요청여부:
					//계약자 동의여부 및 계약자관계
					//언급기관 :
					//모니터링결과:
					//민원내용:
					//요구사항:
					
					sb.append("소속팀 : ");
					if (bzCntcReqCtntArr.length > 0) { sb.append(bzCntcReqCtntArr[0]); }
					sb.append("\n");
					
					sb.append("민원인성명(연락처) : ");
					if (bzCntcReqCtntArr.length > 1) { sb.append(bzCntcReqCtntArr[1]); }
					sb.append("\n");
					
					sb.append("긴급통화요청여부 : ");
					if (bzCntcReqCtntArr.length > 2) { sb.append(bzCntcReqCtntArr[2]); }
					sb.append("\n");
					
					sb.append("계약자 동의여부 및 계약자관계 : ");
					if (bzCntcReqCtntArr.length > 3) { sb.append(bzCntcReqCtntArr[3]); }
					sb.append("\n");
					
					sb.append("언급기관 : ");
					if (bzCntcReqCtntArr.length > 4) {
						//cf_GetCommCode("ds_agency","B0154","4");
						//S0001	금감원
						//S0002	소비자원
						//S0003	언론기관
						//S0004	정부기관
						//S0005	인터넷
						//S0006	그외
						Map<String, String> dsAgency = new HashMap<String, String>();
						dsAgency.put("S0001", "금감원");
						dsAgency.put("S0002", "소비자원");
						dsAgency.put("S0003", "언론기관");
						dsAgency.put("S0004", "정부기관");
						dsAgency.put("S0005", "인터넷");
						dsAgency.put("S0006", "그외");
						
						sb.append(StringUtils.nvl(dsAgency.get(bzCntcReqCtntArr[4])));
					}
					sb.append("\n");
					
					sb.append("모니터링결과 : ");
					if (bzCntcReqCtntArr.length > 5) {
						//모니터링결과. -[2013.10.30] 이대근
						//cf_GetCommCode("ds_mon_result","B0155","4");
						//S0001	정상
						//S0002	요청사유불완전
						//S0003	기타불완전
						//S0004	진행중
						//S0005	미접수
						//S0006	녹취확인불가	
						Map<String, String> dsMonResult = new HashMap<String, String>();
						dsMonResult.put("S0001", "정상");
						dsMonResult.put("S0002", "요청사유불완전");
						dsMonResult.put("S0003", "기타불완전");
						dsMonResult.put("S0004", "진행중");
						dsMonResult.put("S0005", "미접수");
						dsMonResult.put("S0006", "녹취확인불가");
						sb.append(StringUtils.nvl(dsMonResult.get(bzCntcReqCtntArr[5])));
					}
					sb.append("\n");
					
					sb.append("민원내용 : ");
					if (bzCntcReqCtntArr.length > 6) { sb.append(bzCntcReqCtntArr[6]); }
					sb.append("\n");
					
					sb.append("요구사항 : ");
					if (bzCntcReqCtntArr.length > 7) { sb.append(bzCntcReqCtntArr[7]); }
					
					selectOneTBCMETC010a.setBzCntcReqCtnt(sb.toString());
				}
			}
			
			// 고객명조회
			String custDscNo = selectOneTBCMETC010a.getCustDscNo();
			logger.debug("selectOneTBCMETC010a.getCustDscNo() : " + custDscNo);
			if(!StringUtils.isEmpty(custDscNo) && custDscNo.trim().length() == 13){
				String encCustRrno = SecuUtil.getEncValue(custDscNo, SecuUtil.EncType.Jumin);
				
				TBCSPRF001Io tbcsprf001io = cma201dbio.selectOneTBCSPRF001d(encCustRrno);
				if(tbcsprf001io != null) {
					String custNm = tbcsprf001io.getCustNm();
					selectOneTBCMETC010a.setCustNm(custNm);
				}
			}
		}
		
		return selectOneTBCMETC010a;
	}
	
	/**
	 * 업무연락이력 조회
	 * 
	 * @param  CMZ010SVC00In 업무연락
	 * @return TBCMETC011Io 공통업무연락 테이블의 OMM
	 * @throws ApplicationException
	 */
	public TBCMETC011Io getBzCntcHistInfo(CMZ010SVC01In input) throws ApplicationException {
		String bzCntcMgntNo = input.getBzCntcMgntNo();
		
		// 필수입력 정보 체크
		if (StringUtils.isEmpty(bzCntcMgntNo)) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"업무연락관리번호"}, new Object[]{});
		}
		
		TBCMETC011Io selectOneTBCMETC011a = cmz010dbio.selectOneTBCMETC011a(bzCntcMgntNo);
		if(selectOneTBCMETC011a == null) {
			selectOneTBCMETC011a = new TBCMETC011Io();
		}
		
		// 이전 회신내용 조회
		StringBuffer bzCntcRplyCtntPrev = new StringBuffer();
		List<TBCMETC011Io> selectMultiTBCMETC011a = cmz010dbio.selectMultiTBCMETC011a(bzCntcMgntNo);
		for (TBCMETC011Io tbcmetc011io : selectMultiTBCMETC011a) {
			if ("Y".equals(tbcmetc011io.getPrcsYn())) {
				String rplyCtnt = "회신일시 :["+ StringUtils.nvl(tbcmetc011io.getPrcsDtm()) +"] ["+StringUtils.nvl(tbcmetc011io.getReceOrgNm())+"/"+StringUtils.nvl(tbcmetc011io.getPrcsrNm()) +"]";
				bzCntcRplyCtntPrev.append(rplyCtnt);
				bzCntcRplyCtntPrev.append("\r\n");
				bzCntcRplyCtntPrev.append(StringUtils.nvl(tbcmetc011io.getBzCntcRplyCtnt()));
				bzCntcRplyCtntPrev.append("\r\n====================================");
				bzCntcRplyCtntPrev.append("\r\n");
			}
		}
		
		if (bzCntcRplyCtntPrev.length() > 0) {
			selectOneTBCMETC011a.setBzCntcRplyCtntPrev(bzCntcRplyCtntPrev.toString());
		}
		
		return selectOneTBCMETC011a;
	}
	
	/**
	 * 저장된 계약사항 조회
	 * 
	 * @param  List<TBCMETC012Io> 저장된 계약사항
	 * @return selectMultiTBCMETC012a 업무연락 계약사항 테이블의 OMM
	 * @throws ApplicationException
	 */
	public List<TBCMETC012Io> getSavedContInfoInq(CMZ010SVC01In input) throws ApplicationException {
		String bzCntcMgntNo = input.getBzCntcMgntNo();
		
		// 필수입력 정보 체크
		if (StringUtils.isEmpty(bzCntcMgntNo)) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"업무연락관리번호"}, new Object[]{});
		}
		
		List<TBCMETC012Io> selectMultiTBCMETC012a = cmz010dbio.selectMultiTBCMETC012a(bzCntcMgntNo);
		
		SecuUtil.doDecList(selectMultiTBCMETC012a);
		
		return selectMultiTBCMETC012a;
	}
	
	/**
	 * 업무연락 입력
	 * 
	 * @param  CMZ010SVC00In 업무저장정보
	 * @return String 업무연락관리번호
	 * @throws ApplicationException
	 */
	public String insertBzCntcList(CMZ010SVC01In input) throws ApplicationException {
		logger.debug("CMZ010BEAN.insertBzCntcList(CMZ010SVC01In input)" + input);
		
		TBCMETC010Io bzCntcInfo = input.getBzCntcInfo(); // 업무유형
		TBCMETC011Io bzCntcHistInfo = input.getBzCntcHistInfo(); // 업무유형이력
		List<TBCMETC012Io> contInfoList = input.getContInfoList(); // 계약사항
		
		//저장 처리할 리스트 정보 체크
		if (bzCntcInfo == null || bzCntcHistInfo == null || contInfoList == null) {
			throw new ApplicationException("APCME0009", new Object[]{"업무연락정보는"}, new Object[]{});
		}
		
		/////////////////////////////////
		// 업무연락 저장
		/////////////////////////////////
		// 입력 정보 체크
		if (StringUtils.isEmpty(bzCntcInfo.getBzCntcProgStcd())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"진행상태"}, new Object[]{});
		}
		if (StringUtils.isEmpty(bzCntcInfo.getApplOrgNo())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"신청조직"}, new Object[]{});
		}
		if (StringUtils.isEmpty(bzCntcInfo.getApplEno())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"신청자"}, new Object[]{});
		}
		if (StringUtils.isEmpty(bzCntcInfo.getBzCntcTypId1())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"업무연락유형1"}, new Object[]{});
		}
		if (StringUtils.isEmpty(bzCntcInfo.getBzCntcTypId2())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"업무연락유형2"}, new Object[]{});
		}
		
		TBCMETC009Io bzCntcTyp = cmz010dbio.selectOneTBCMETC009a(bzCntcInfo.getBzCntcTypId1(),bzCntcInfo.getBzCntcTypId2());
		if( bzCntcTyp == null) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"존재하는 업무유형코드"}, new Object[]{});		
		}
		
		if (!CollectionUtils.isEmpty(contInfoList)
				&& "R29".equals(bzCntcInfo.getBzCntcTypId1())) { // R29.변액보험 처리요청
			
			String strtDt = "";
			strtDt = bizdateinfo.getNBfBizDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE), 2);
			
			for (TBCMETC012Io contInfo : contInfoList) {
				Integer cnt = cmz010dbio.selectOneTBCMETC012a(contInfo.getContNo(), strtDt);
				
				if (cnt > 0) {
					// {0} 입력이 불가능합니다.
					throw new ApplicationException("APNBE0020", new Object[]{"계약번호 " + contInfo.getContNo() + "은(는) 영업일 2일이내 등록된 업무연락으로"}, new Object[]{});
				}
			}
		}
		
		//-------------------- TM  담담자 조직 셋팅 --------------------------
		String medTypCd = FwUtil.getMedTyp(); //ILS : i-Lisa
		if(BizUtil.MED_TYP_CD_ILS.equals(medTypCd)) {
			
			String receOrgNo    = bzCntcTyp.getReceOrgNo();    //수신조직번호
			String receChrgpEno = bzCntcTyp.getReceChrgpEno(); //수신담당자사원번호
			
			if (!StringUtils.isEmpty(receChrgpEno)) {
				bzCntcInfo.setReceOrgUntCd("U"); //담당자
				bzCntcInfo.setFstReceChrgpEno(receChrgpEno);
				
				bzCntcHistInfo.setReceOrgUntCd("U"); 
				bzCntcHistInfo.setReceChrgpEno(receChrgpEno);
			}
			else {
				if (!StringUtils.isEmpty(receOrgNo)) {
					bzCntcInfo.setReceOrgUntCd("T"); //담당조직
					bzCntcInfo.setReceOrgNo(receOrgNo);
					
					bzCntcHistInfo.setReceOrgUntCd("T");
					bzCntcHistInfo.setReceOrgNo(receOrgNo);
				}
			}
		}
				
		
		if ("T".equals(bzCntcInfo.getReceOrgUntCd())) { // 팀일경우
			if (StringUtils.isEmpty(bzCntcInfo.getReceOrgNo())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"수신팀"}, new Object[]{});
			}
			
			// 본부, 지점세팅
			OrgInfo receOrgInfo = cma002bean.getOrgInfo(bzCntcInfo.getReceOrgNo());
			if (receOrgInfo != null) {
				bzCntcInfo.setReceHqOrgNo(receOrgInfo.getHqOrgNo());
				bzCntcInfo.setReceDofOrgNo(receOrgInfo.getDofOrgNo());
				bzCntcInfo.setReceOrgNo(receOrgInfo.getOrgNo());
			}
		}
		else if ("U".equals(bzCntcInfo.getReceOrgUntCd())) { // 담당자일경우
			if (StringUtils.isEmpty(bzCntcInfo.getFstReceChrgpEno())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"수신담당자"}, new Object[]{});
			}
			// 본부, 지점, 조직세팅
			CommEmplInfo receEmplInfo = cma002bean.getEmplInfo(bzCntcInfo.getFstReceChrgpEno());
			if (receEmplInfo != null ){
				bzCntcInfo.setReceHqOrgNo(receEmplInfo.getHqOrgNo());
				bzCntcInfo.setReceDofOrgNo(receEmplInfo.getDofOrgNo());
				bzCntcInfo.setReceOrgNo(receEmplInfo.getOrgNo());
				
				if(StringUtils.isEmpty(bzCntcHistInfo.getReceOrgNo())) {
					bzCntcHistInfo.setReceOrgNo(receEmplInfo.getOrgNo());
				}
			}
		}
		if (StringUtils.isEmpty(bzCntcInfo.getBzCntcReqCtnt())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"요청내용"}, new Object[]{});
		}
		if (getByteLength(bzCntcInfo.getBzCntcReqCtnt(), null) > 2000) {
			// {0} 입력 오류입니다.
			throw new ApplicationException("APCME0025", new Object[]{"입력한 요청내용이 길이가 너무 깁니다, 요청내용"}, new Object[]{});
		}
		
		// 요청내용 암호화
		bzCntcInfo.setBzCntcReqCtnt(SecuUtil.getEncValue(bzCntcInfo.getBzCntcReqCtnt(), SecuUtil.EncType.Etc));
		
		// 신규등록채번
		String bzCntcMgntNo = cmz010dbio.selectOneTBCMETC010b();
		logger.debug( "신규등록채번 bzCntcMgntNo : {} " , bzCntcMgntNo );
		
		// 등록지점세팅
		if(StringUtils.isEmpty(bzCntcInfo.getApplDofOrgNo())) {
			OrgInfo applOrgInfo = cma002bean.getOrgInfo(bzCntcInfo.getApplOrgNo());
			if (applOrgInfo != null) {
				bzCntcInfo.setApplDofOrgNo(applOrgInfo.getDofOrgNo());
			}
		}
		bzCntcInfo.setFstCrtrId(FwUtil.getUserId());
		bzCntcInfo.setLastChgrId(FwUtil.getUserId());
		bzCntcInfo.setLastChgPgmId(FwUtil.getPgmId());
		bzCntcInfo.setLastChgTrmNo(FwUtil.getTrmNo());
		bzCntcInfo.setBzCntcMgntNo(bzCntcMgntNo);
		
		// 요청일시
		bzCntcInfo.setRcDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));
		bzCntcInfo.setRcTi(DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE));
		
		// 고객주민번호
		if (!StringUtils.isEmpty(bzCntcInfo.getCustDscNo())) {
			bzCntcInfo.setCustDscNo(SecuUtil.getEncValue(bzCntcInfo.getCustDscNo(), SecuUtil.EncType.Jumin));
		}
		
		/*
		logger.debug("DateUtils.getCurrentTime()");
		logger.debug(DateUtils.getCurrentTime(DateUtils.FULL_TIME_TYPE));
		logger.debug(DateUtils.getCurrentTime(DateUtils.MIN_TIME_TYPE));
		logger.debug(DateUtils.getCurrentTime(DateUtils.HOUR_TIME_TYPE));
		logger.debug(DateUtils.getCurrentTime(DateUtils.AMPM_TIME_TYPE));
		logger.debug(DateUtils.getCurrentTime(DateUtils.AMPM_MIN_TIME_TYPE));
		logger.debug(DateUtils.getCurrentTime(DateUtils.AMPM_HOUR_TIME_TYPE));
		logger.debug(DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE));
		*/
		cmz010dbio.insertOneTBCMETC010(bzCntcInfo);
		
		/////////////////////////////////
		// 계약사항 저장
		/////////////////////////////////
		// 이전 계약사항 삭제 후 입력
		cmz010dbio.deleteMultiTBCMETC012(bzCntcMgntNo);
		for (TBCMETC012Io contInfo : contInfoList) {
			contInfo.setBzCntcMgntNo(bzCntcMgntNo);
			contInfo.setDelYn("N");
			contInfo.setLastChgrId(FwUtil.getUserId());
			contInfo.setLastChgPgmId(FwUtil.getPgmId());
			contInfo.setLastChgTrmNo(FwUtil.getTrmNo());
			cmz010dbio.insertOneTBCMETC012(contInfo);
		}
		
		/////////////////////////////////
		// 업무연락이력 저장
		/////////////////////////////////
		bzCntcHistInfo.setRcDt(bzCntcInfo.getRcDt());
		bzCntcHistInfo.setFstCrtrId(FwUtil.getUserId());
		bzCntcHistInfo.setLastChgrId(FwUtil.getUserId());
		bzCntcHistInfo.setLastChgPgmId(FwUtil.getPgmId());
		bzCntcHistInfo.setLastChgTrmNo(FwUtil.getTrmNo());
		bzCntcHistInfo.setBzCntcMgntNo(bzCntcMgntNo);
		bzCntcHistInfo.setReceDtm("00010101000001");
		bzCntcHistInfo.setPrcsYn("N");
		
		cmz010dbio.insertOneTBCMETC011(bzCntcHistInfo);
		
		// R26.청약철회숙려 TM인터페이스호출 -------------------------------
		if ("R26".equals(bzCntcInfo.getBzCntcTypId1()) ||
			"R27".equals(bzCntcInfo.getBzCntcTypId1()) ||
			"R28".equals(bzCntcInfo.getBzCntcTypId1())) {
			tranBzCntcCloff(input);
		}
		
		// 업무유형이 민원관련일 경우 SMS발송 //IVR 및 WSS 등록일 경우는 제외
		if ("R23".equals(bzCntcInfo.getBzCntcTypId1())
				&& "S11".equals(bzCntcInfo.getBzCntcTypId2())) {
			// 소비자보호부로 발송
			sendLmsTrms(bzCntcInfo.getBzCntcTypId1(), bzCntcInfo.getBzCntcTypId2(), bzCntcInfo.getFstReceChrgpEno());
		}
		
		return bzCntcMgntNo;
	}
	
	/**
	 * 업무연락 수정
	 * 
	 * @param  CMZ010SVC00In 업무저장정보
	 * @return String 업무연락관리번호
	 * @throws ApplicationException
	 */
	public String updateBzCntcList(CMZ010SVC01In input) throws ApplicationException {
		TBCMETC010Io bzCntcInfo = input.getBzCntcInfo(); // 업무연락정보
		TBCMETC011Io bzCntcHistInfo = input.getBzCntcHistInfo(); // 업무유형이력
		List<TBCMETC012Io> contInfoList = input.getContInfoList(); // 계약사항
		
		//저장 처리할 정보 체크
		if (bzCntcInfo == null || bzCntcHistInfo == null || contInfoList == null) {
			throw new ApplicationException("APCME0009", new Object[]{"업무연락정보는"}, new Object[]{});
		}
		
		// 입력 정보 체크
		if (StringUtils.isEmpty(bzCntcInfo.getBzCntcProgStcd())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"진행상태"}, new Object[]{});
		}
		if ("T".equals(bzCntcInfo.getReceOrgUntCd())) { // 팀일경우
			if (StringUtils.isEmpty(bzCntcInfo.getReceOrgNo())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"수신팀"}, new Object[]{});
			}
			// 본부, 지점세팅
			OrgInfo receOrgInfo = cma002bean.getOrgInfo(bzCntcInfo.getReceOrgNo());
			if (receOrgInfo != null) {
				bzCntcInfo.setReceHqOrgNo(receOrgInfo.getHqOrgNo());
				bzCntcInfo.setReceDofOrgNo(receOrgInfo.getDofOrgNo());
				bzCntcInfo.setReceOrgNo(receOrgInfo.getOrgNo());
			}
		} else if ("U".equals(bzCntcInfo.getReceOrgUntCd())) { // 담당자일경우
			if (StringUtils.isEmpty(bzCntcInfo.getFstReceChrgpEno())) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"수신담당자"}, new Object[]{});
			}
			// 본부, 지점, 조직세팅
			CommEmplInfo receEmplInfo = cma002bean.getEmplInfo(bzCntcInfo.getFstReceChrgpEno());
			if (receEmplInfo != null) {
				bzCntcInfo.setReceHqOrgNo(receEmplInfo.getHqOrgNo());
				bzCntcInfo.setReceDofOrgNo(receEmplInfo.getDofOrgNo());
				bzCntcInfo.setReceOrgNo(receEmplInfo.getOrgNo());
			}
		}
		/* TM에서는 입력안하는 경우 발생함
		if (StringUtils.isEmpty(bzCntcHistInfo.getBzCntcRplyCtnt())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"회신내용"}, new Object[]{});
		}
		*/
		if (bzCntcInfo.getBzCntcReqCtnt() != null &&  getByteLength(bzCntcInfo.getBzCntcReqCtnt(), null) > 2000) {
			// {0} 입력 오류입니다.
			throw new ApplicationException("APCME0025", new Object[]{"입력한 요청내용이 길이가 너무 깁니다, 회신내용"}, new Object[]{});
		}
		if (bzCntcHistInfo.getBzCntcRplyCtnt() != null &&  getByteLength(bzCntcHistInfo.getBzCntcRplyCtnt(), null) > 4000) {
			// {0} 입력 오류입니다.
			throw new ApplicationException("APCME0025", new Object[]{"입력한 회신내용이 길이가 너무 깁니다, 회신내용"}, new Object[]{});
		}
		
		// 요청내용 암호화
		bzCntcInfo.setBzCntcReqCtnt(SecuUtil.getEncValue(bzCntcInfo.getBzCntcReqCtnt(), SecuUtil.EncType.Etc));

		// 등록번호확인
		String bzCntcMgntNo = bzCntcInfo.getBzCntcMgntNo();
		logger.debug( "등록번호확인 bzCntcMgntNo : {} " , bzCntcMgntNo );
		
		/////////////////////////////////
		// 업무연락 저장
		/////////////////////////////////
		bzCntcInfo.setLastChgrId(FwUtil.getUserId());
		bzCntcInfo.setLastChgPgmId(FwUtil.getPgmId());
		bzCntcInfo.setLastChgTrmNo(FwUtil.getTrmNo());
		
		
		// R26.청약철회숙려  -------------------------------
		// 배치 : 업무유형이 청약 철회 숙려, Welcome 숙려, TMR 본인계약 숙려이면 
		//영업일 기준 다음날 23시 업무요청결과를 TMR반려시도중(202) -> TMR반려중(203)으로 업데이트한다.
		
		//1. 업무유형이 청약 철회 숙려, Welcome 숙려, TMR 본인계약 숙려이면 업무요청결과가 
		//   TMR미시도(201), TMR반려시도중(202)이고 요청일시 기준 1영업일이내인 경우 업무요청결과 선택이 가능하다.
		//2. 업무요청결과가 고객재접수(유지)_301이면 업무처리상태는 취소로 세팅된다.
		//3. 업무요청결과가 고객재접수(철회)_302이면 업무처리상태는 완료로 세팅된다.
		if ("R26".equals(bzCntcInfo.getBzCntcTypId1()) ||
			"R27".equals(bzCntcInfo.getBzCntcTypId1()) ||
			"R28".equals(bzCntcInfo.getBzCntcTypId1())) {
		
			if("301".equals(bzCntcInfo.getCloffReqRcd())) {
				bzCntcInfo.setBzCntcProgStcd("05");
			}
			if("302".equals(bzCntcInfo.getCloffReqRcd())) {
				bzCntcInfo.setBzCntcProgStcd("03");
			}

		}
		
		// 진행상태가 완료나 취소일때 완료일시 입력
		// 01.미처리,02:보류, 03.완료, 04.진행중, 05.취소, 06.미연결완료, 07:반려-재접수요엋ㅇ, 08:반려-처리불가, 09:결과요청
		
		if ("03".equals(bzCntcInfo.getBzCntcProgStcd()) || 
			"04".equals(bzCntcInfo.getBzCntcProgStcd()) ||
			"05".equals(bzCntcInfo.getBzCntcProgStcd()) ||
			"06".equals(bzCntcInfo.getBzCntcProgStcd()) ||
			"07".equals(bzCntcInfo.getBzCntcProgStcd()) ||
			"08".equals(bzCntcInfo.getBzCntcProgStcd()) ||
			"09".equals(bzCntcInfo.getBzCntcProgStcd()) ) { 
			// 완료일시			
			bzCntcInfo.setCmptDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));
			bzCntcInfo.setCmptTi(DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE));
		} else {
			bzCntcInfo.setCmptDt(null);
			bzCntcInfo.setCmptTi(null);
		}
		
		cmz010dbio.updateOneTBCMETC010(bzCntcInfo);
		
		/////////////////////////////////
		// 업무연락이력 저장
		/////////////////////////////////
		bzCntcHistInfo.setFstCrtrId(FwUtil.getUserId());
		bzCntcHistInfo.setLastChgrId(FwUtil.getUserId());
		bzCntcHistInfo.setLastChgPgmId(FwUtil.getPgmId());
		bzCntcHistInfo.setLastChgTrmNo(FwUtil.getTrmNo());
		bzCntcHistInfo.setBzCntcMgntNo(bzCntcMgntNo);
		
		String bzCntcRplyCtnt = bzCntcHistInfo.getBzCntcRplyCtnt(); // 입력된 회신내용
		
		//본인계약 처리상태조회
		TBCMETC011Io bzCntcPrcsInfo = cmz010dbio.selectOneTBCMETC011b(bzCntcMgntNo, FwUtil.getDeptCd(), FwUtil.getUserId(), null);
		
		String medTypCd = FwUtil.getMedTyp(); //ILS : i-Lisa
		
		String prcsYn = "N";
		if(bzCntcPrcsInfo != null) {
			
			//String maxSeq = bzCntcPrcsInfo.getMaxSeq();
			String curSeq = bzCntcPrcsInfo.getSeq();
			
	        String befReceOrgUntCd = StringUtils.nvl(bzCntcPrcsInfo.getReceOrgUntCd(),"");  // 수신조직단위코드  
	        String befReceOrgNo    = StringUtils.nvl(bzCntcPrcsInfo.getReceOrgNo(),"");     // 수신조직번호      
			String befReceChrgpEno = StringUtils.nvl(bzCntcPrcsInfo.getReceChrgpEno(),"");  // 수신담당자사원번호
			
			/*
			//다른 사람일경우 
			if(!curSeq.equals(maxSeq)) {
				throw new ApplicationException("KIERE0005", null, new String[]{"이미 처리된 건으로 이력 확인 대상"});
			}
			*/
			
			prcsYn = StringUtils.nvl(bzCntcPrcsInfo.getPrcsYn(), "N");
			
			// 답변 미처리건
			if("N".equals(prcsYn)) {
				
				bzCntcHistInfo.setBzCntcRplyCtnt(bzCntcRplyCtnt); 
				bzCntcHistInfo.setSeq(curSeq);
				bzCntcHistInfo.setPrcsYn("Y");
				bzCntcHistInfo.setDelYn("N"); // 삭제여부
				
				//---------------------------------------------------
				cmz010dbio.updateOneTBCMETC011(bzCntcHistInfo);
				//---------------------------------------------------
			}
			else {
				// 수신자 본인건 현재 입력건이  존재하므로 처리여부는 Y -추가이력 개념
				bzCntcHistInfo.setReceOrgUntCd(befReceOrgUntCd);
				bzCntcHistInfo.setReceOrgNo(befReceOrgNo);
				bzCntcHistInfo.setReceChrgpEno(befReceChrgpEno);					
				
				bzCntcHistInfo.setReceDtm(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE));
				bzCntcHistInfo.setPrcsYn("Y");
				bzCntcHistInfo.setRcDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));
				bzCntcHistInfo.setDelYn("N"); // 삭제여부
				//----------------------------------------------
				cmz010dbio.insertOneTBCMETC011(bzCntcHistInfo);
				//----------------------------------------------
			}
			
	        String aftReceOrgUntCd = StringUtils.nvl(bzCntcHistInfo.getReceOrgUntCd(),"");  // 수신조직단위코드  
	        String aftReceOrgNo    = StringUtils.nvl(bzCntcHistInfo.getReceOrgNo(),"");     // 수신조직번호      
			String aftReceChrgpEno = StringUtils.nvl(bzCntcHistInfo.getReceChrgpEno(),"");  // 수신담당자사원번호
			
			//수신담당자 정보 다른 경우_위임
			if( !befReceOrgUntCd.equals(aftReceOrgUntCd) ||
				!befReceOrgNo.equals(aftReceOrgNo) ||
				!befReceChrgpEno.equals(aftReceChrgpEno) ) {
				
				bzCntcHistInfo.setReceDtm("00010101000001");
				bzCntcHistInfo.setBzCntcRplyCtnt(null);
				bzCntcHistInfo.setPrcsYn("N");
				bzCntcHistInfo.setRcDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));
				bzCntcHistInfo.setDelYn("N"); // 삭제여부
				//-----------------------------------------------------
				cmz010dbio.insertOneTBCMETC011(bzCntcHistInfo);
				//-----------------------------------------------------
			}
			
		}

		else {
			
			// i-lisa   담당자
			if(BizUtil.MED_TYP_CD_ILS.equals(medTypCd)) {
				
				bzCntcHistInfo.setReceOrgUntCd("U");
				bzCntcHistInfo.setReceOrgNo(FwUtil.getDeptCd());
				bzCntcHistInfo.setReceChrgpEno(FwUtil.getUserId());					
				bzCntcHistInfo.setBzCntcRplyCtnt(bzCntcRplyCtnt); 
				bzCntcHistInfo.setReceDtm(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)+DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE));
				bzCntcHistInfo.setPrcsYn("Y");
				bzCntcHistInfo.setRcDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));
				bzCntcHistInfo.setDelYn("N"); // 삭제여부
				//----------------------------------------------
				cmz010dbio.insertOneTBCMETC011(bzCntcHistInfo);
				//----------------------------------------------
			}
			else {
			
				// 신청자- 취소,보류, 완료  업데이트
				if ("01,02,03,05".contains(bzCntcInfo.getBzCntcProgStcd())) { //미처리, 보류, 취소
					
					if ("05".equals(bzCntcInfo.getBzCntcProgStcd()) || //취소
						"02".equals(bzCntcInfo.getBzCntcProgStcd()) || //보류
						"03".equals(bzCntcInfo.getBzCntcProgStcd()) ) { //완료
		
						bzCntcHistInfo.setBzCntcRplyCtnt(bzCntcRplyCtnt); 
						bzCntcHistInfo.setSeq(bzCntcHistInfo.getSeq());
						bzCntcHistInfo.setPrcsYn("N");
						bzCntcHistInfo.setDelYn("N"); // 삭제여부
					
						//---------------------------------------------------
						cmz010dbio.updateOneTBCMETC011c(bzCntcHistInfo);
						//---------------------------------------------------
					}
					
				} //담당자 본인건이 아니므로 에러 발생 
				else {
					throw new ApplicationException("APCME0056", null); //업무 수신담당자 확인 바랍니다.
				}
			} //end if ILISA
		}
		
		return bzCntcMgntNo;
	}
	
	
	/**
	 * 접수현황조회 목록 조회
	 * 
	 * @param  CMZ010SVC02In 접수현황조회
	 * @return List<TBCMETC010Io> 공통업무연락 테이블의 OMM
	 * @throws ApplicationException
	 */
	public List<TBCMETC010Io> getBzCntcList(CMZ010SVC01In input) throws ApplicationException {
		
		String bzCntcMgntNo = StringUtils.nvl(input.getBzCntcMgntNo()); //업무연락관리번호
		String contNo = input.getContNo(); //계약번호
		String custRfDscNo = StringUtils.nvl(input.getRrno());
		String rrno = StringUtils.nvl(input.getRrno()); // 고객주민등록번호
		
		//업무연락관리번호 혹은 계약번호 있을시 
		if( !StringUtils.isEmpty(bzCntcMgntNo) || 
			!StringUtils.isEmpty(contNo) ||
			!StringUtils.isEmpty(custRfDscNo) ||
			!StringUtils.isEmpty(rrno)) {
			
			input.setRcDtFrom("00010101");
			input.setRcDtTo("99991231");			
		}
		
		// 입력 정보 체크
		if (StringUtils.isEmpty(input.getRcDtFrom())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"접수기간from"}, new Object[]{});
		}
		if (StringUtils.isEmpty(input.getRcDtTo())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"접수기간to"}, new Object[]{});
		}

		String bzCntcTypNm1 = StringUtils.nvl(input.getBzCntcTypNm1()); // 업무유형명
		String bzCntcTypNm2 = StringUtils.nvl(input.getBzCntcTypNm2()); // 업무유형명
		String receOrgNo = StringUtils.nvl(input.getReceOrgNo()); // 수신조직번호
		String applEno = StringUtils.nvl(input.getApplEno()); // 신청사원
		String rfEno = StringUtils.nvl(input.getRfEno()); // 참조사원
		String fstReceChrgpEno = StringUtils.nvl(input.getReceChrgpEno()); // 수신사원
		String bzCntcProgStcd = StringUtils.nvl(input.getBzCntcProgStcd()); // 진행상태코드
		String calDtFrom = input.getRcDtFrom(); // 접수기간from
		String calDtTo = input.getRcDtTo(); // 접수기간to

		String insdContrDcd = StringUtils.nvl(input.getInsdContrDcd(),"9"); //9:전체, 0:계약자, 1:피보험자
		String custNo=null;
		Integer pageNum = input.getPageNum();
		Integer pageCount = input.getPageCount();
		List<TBCMETC010Io> selectMultiTBCMETC010 = null;
		// 주민번호가 있다면 암호화
		if (!StringUtils.isEmpty(rrno)) {
			rrno = SecuUtil.getEncValue(rrno, SecuUtil.EncType.Jumin);
			custNo = cmz010dbio.selectOneTBCSPRF001(rrno);
			
			if (StringUtils.isEmpty(custNo)) {
				//{0} 입력 오류입니다.
				custNo = "999999999";
				//throw new ApplicationException("APCME0025", new Object[]{"주민등록번호"});
			}
			logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> custNo"+custNo);
		}
		
		if(!StringUtils.isEmpty(custNo) || !StringUtils.isEmpty(contNo)){
			logger.debug(">>>>>>>>> selectMultiTBCMETC010b");
			selectMultiTBCMETC010 = cmz010dbio.selectMultiTBCMETC010b(bzCntcMgntNo, bzCntcTypNm1,bzCntcTypNm2,receOrgNo,applEno,rfEno,fstReceChrgpEno,bzCntcProgStcd,contNo,insdContrDcd,custRfDscNo,custNo,rrno,calDtFrom,calDtTo,pageNum,pageCount);
		}
		else if(!StringUtils.isEmpty(receOrgNo) || !StringUtils.isEmpty(fstReceChrgpEno)){
			selectMultiTBCMETC010 = cmz010dbio.selectMultiTBCMETC010c(bzCntcMgntNo, bzCntcTypNm1,bzCntcTypNm2,receOrgNo,applEno,rfEno,fstReceChrgpEno,bzCntcProgStcd,contNo,custRfDscNo,custNo,calDtFrom,calDtTo,pageNum,pageCount);
		}
		else{
			logger.debug(">>>>>>>>> selectMultiTBCMETC010a");
			selectMultiTBCMETC010 = cmz010dbio.selectMultiTBCMETC010a(bzCntcMgntNo, bzCntcTypNm1,bzCntcTypNm2,receOrgNo,applEno,rfEno,fstReceChrgpEno,bzCntcProgStcd,contNo,custRfDscNo,custNo,calDtFrom,calDtTo,pageNum,pageCount);
		}
		
		SecuUtil.doDecList(selectMultiTBCMETC010);
		
		return selectMultiTBCMETC010;
		
	}
	
	
	/**
	 * 접수현황조회 목록 조회(팀기준)
	 * 
	 * @param  CMZ010SVC02In 접수현황조회
	 * @return List<TBCMETC010Io> 공통업무연락 테이블의 OMM
	 * @throws ApplicationException
	 */
	public List<TBCMETC010Io> getBzCntcListByTeam(CMZ010SVC01In input) throws ApplicationException {
		
		String bzCntcMgntNo = StringUtils.nvl(input.getBzCntcMgntNo()); //업무연락관리번호
		String contNo = input.getContNo(); //계약번호
		String custRfDscNo = StringUtils.nvl(input.getRrno());
		String rrno = StringUtils.nvl(input.getRrno()); // 고객주민등록번호
		
		//업무연락관리번호 혹은 계약번호 있을시 
		if( !StringUtils.isEmpty(bzCntcMgntNo) || 
			!StringUtils.isEmpty(contNo) ||
			!StringUtils.isEmpty(custRfDscNo) ||
			!StringUtils.isEmpty(rrno)) {
			
			input.setRcDtFrom("00010101");
			input.setRcDtTo("99991231");			
		}
		
		// 입력 정보 체크
		if (StringUtils.isEmpty(input.getRcDtFrom())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"접수기간from"}, new Object[]{});
		}
		if (StringUtils.isEmpty(input.getRcDtTo())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"접수기간to"}, new Object[]{});
		}

		String bzCntcTypNm1 = StringUtils.nvl(input.getBzCntcTypNm1()); // 업무유형명
		String bzCntcTypNm2 = StringUtils.nvl(input.getBzCntcTypNm2()); // 업무유형명
		String receOrgNo = StringUtils.nvl(input.getReceOrgNo()); // 수신조직번호
		String applEno = StringUtils.nvl(input.getApplEno()); // 신청사원
		String rfEno = StringUtils.nvl(input.getRfEno()); // 참조사원
		String fstReceChrgpEno = StringUtils.nvl(input.getReceChrgpEno()); // 수신사원
		String bzCntcProgStcd = StringUtils.nvl(input.getBzCntcProgStcd()); // 진행상태코드
		String calDtFrom = input.getRcDtFrom(); // 접수기간from
		String calDtTo = input.getRcDtTo(); // 접수기간to

		//String insdContrDcd = StringUtils.nvl(input.getInsdContrDcd(),"9"); //9:전체, 0:계약자, 1:피보험자
		String custNo=null;
		Integer pageNum = input.getPageNum();
		Integer pageCount = input.getPageCount();
		List<TBCMETC010Io> selectMultiTBCMETC010 = null;
		// 주민번호가 있다면 암호화
		if (!StringUtils.isEmpty(rrno)) {
			rrno = SecuUtil.getEncValue(rrno, SecuUtil.EncType.Jumin);
			custNo = cmz010dbio.selectOneTBCSPRF001(rrno);
			
			if (StringUtils.isEmpty(custNo)) {
				//{0} 입력 오류입니다.
				custNo = "999999999";
				//throw new ApplicationException("APCME0025", new Object[]{"주민등록번호"});
			}
			logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> custNo"+custNo);
		}
		
		selectMultiTBCMETC010 = cmz010dbio.selectMultiTBCMETC010d(bzCntcMgntNo, bzCntcTypNm1,bzCntcTypNm2,receOrgNo,applEno,rfEno,fstReceChrgpEno,bzCntcProgStcd,contNo,custRfDscNo,custNo,calDtFrom,calDtTo,pageNum,pageCount);
		
		SecuUtil.doDecList(selectMultiTBCMETC010);
		
		return selectMultiTBCMETC010;
		
	}
	
	/**
	 * 접수현황조회 목록 파일조회
	 * 
	 * @param  String fileMgntNo
	 * @return List<CMZ010SVC03Sub>
	 * @throws ApplicationException
	 */
	public List<CMZ010SVC03Sub> getFileMgntList(String fileMgntNo) throws ApplicationException {
		
		List<CMZ010SVC03Sub> dsFileMgntNo= cmz010dbio.selectMultiTBCMCCD017a(fileMgntNo);
		
		return dsFileMgntNo;
		
	}
	
	
	
	
	/**
	  * 계약사항조회(주민번호) : 홈페이지
	  * CMZ010BEAN.getContInfoInq2
	  * 
	  * @param rrno   	주민등록번호
	  * @param contrPinsdDcd   	계약자피보험자구분  
	  * @return out : List<NBZI50SVC02Sub0>
	  * @throws ApplicationException
	  */	
	public List<TBCMETC012Io> getContInfoInq( String rrno, String contrInsdDcd, String contNo )  throws ApplicationException {
		
		List<TBCMETC012Io> list = new ArrayList<TBCMETC012Io>();
		
		if (!StringUtils.isEmpty(contNo)) {
			String[] contNoArr = contNo.split(",");
			List<String> contNoList = new ArrayList<String>();
			for (String contNoStr : contNoArr) {
				contNoList.add(contNoStr);
			}
			
			list = cmz010dbio.selectMultiTBCNBAS001a(null, null, contNoList);
		} else {
			// 입력 정보 체크
			if (StringUtils.isEmpty(rrno)) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"고객식별번호"}, new Object[]{});
			}
			if (StringUtils.isEmpty(contrInsdDcd)) {
				// 필수항목 [{0}]을(를) 입력하여야 합니다.
				throw new ApplicationException("APCME0008", new Object[]{"계약자 피보험자 구분"}, new Object[]{});
			}
			
			String custNo = cmz010dbio.selectOneTBCSPRF001(SecuUtil.getEncValue(rrno, SecuUtil.EncType.Jumin));
			
			if (StringUtils.isEmpty(custNo)) {
				//미등록된 고객입니다.
				throw new ApplicationException("APNBE0015", null);
			} else {
				logger.debug("고객번호 = {}", custNo);
			}
			
			// 계약자 피보험자 구분이 0이면 계약자 1이면 피보험자 
			if ("0".equals(contrInsdDcd)) {
				list = cmz010dbio.selectMultiTBCNBAS001a(custNo, null, null);
			} else if ("1".equals(contrInsdDcd)) {
				list = cmz010dbio.selectMultiTBCNBAS001a(null, custNo, null);
			} else if ("9".equals(contrInsdDcd)) {
				list = cmz010dbio.selectMultiTBCNBAS001b(custNo);
			}
		}
		
		SecuUtil.doDecList(list);
		
		return list;
	}
	
	/**
	 * 고객번호로 접수현황조회 목록 조회
	 * 
	 * @param  custNo 접수현황조회
	 * @param  rcDtFrom 접수기간From
	 * @param  rcDtTo 접수기간To
	 * @return List<TBCMETC010Io> 공통업무연락 테이블의 OMM
	 * @throws ApplicationException
	 */
	public List<TBCMETC010Io> getBzCntcListByCustNo(String custNo, String rcDtFrom, String rcDtTo) throws ApplicationException {
		// 입력 정보 체크
		if (StringUtils.isEmpty(custNo)) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"고객번호"}, new Object[]{});
		}
		
		String insdContrDcd = "9"; //전체, 0:계약자, 1:피보험자
				
		List<TBCMETC010Io> selectMultiTBCMETC010a = cmz010dbio.selectMultiTBCMETC010b(null, null,null,null,null,null,null,null,null,insdContrDcd,null,custNo,null,rcDtFrom,rcDtTo, 1, 1000);
		
		SecuUtil.doDecList(selectMultiTBCMETC010a);
		
		return selectMultiTBCMETC010a;
	}
	
	/**
	 * 고객번호로 접수현황조회 목록 조회(paging)
	 * 
	 * @param  custNo 접수현황조회
	 * @param  rcDtFrom 접수기간From
	 * @param  rcDtTo 접수기간To
	 * @return List<TBCMETC010Io> 공통업무연락 테이블의 OMM
	 * @throws ApplicationException
	 */
	public CMZ010SVC01Out getBzCntcListByCustNo(String custNo, String rcDtFrom, String rcDtTo, Integer pageNum, Integer pageCount) throws ApplicationException {
		
		CMZ010SVC01Out output = new CMZ010SVC01Out();
		
		// 입력 정보 체크
		if (StringUtils.isEmpty(custNo)) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"고객번호"}, new Object[]{});
		}
		
		String insdContrDcd = "9"; //전체, 0:계약자, 1:피보험자
		
		List<TBCMETC010Io> selectMultiTBCMETC010a = cmz010dbio.selectMultiTBCMETC010b(null, null,null,null,null,null,null,null,null,insdContrDcd,null,custNo,null,rcDtFrom,rcDtTo, pageNum, pageCount);
		
		SecuUtil.doDecList(selectMultiTBCMETC010a);

		if (DasUtils.existNextResult(selectMultiTBCMETC010a)) {
				output.setRecrdNxtYn("Y");
		} else {
				output.setRecrdNxtYn("N");
		}

		if (selectMultiTBCMETC010a.size() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage("KIOKI0004", null, null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003",	new Object[] { selectMultiTBCMETC010a.size() }, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",new Object[] { selectMultiTBCMETC010a.size() }, null);
		}
		
		output.setBzCntcList(selectMultiTBCMETC010a);
		return output;
	}
	
	/**
	 * 업무연락진행상태 반영
	 * 
	 * @param  업무연락유형 목록 조회조건
	 * @throws ApplicationException
	 */
	public void setBzCntcProgSta(CMZ010SVC01In input) throws ApplicationException {
		
		logger.debug("CMZ010BEAN.setBzCntcProgSta - 업무연락진행상태 반영");
		
		String bzCntcMgntNo = input.getBzCntcMgntNo();
		
		// 신청자와 로그인사원이 같으면 진행상태를 반영하지 않는다
		TBCMETC010Io selectOneTBCMETC010a = cmz010dbio.selectOneTBCMETC010a(bzCntcMgntNo);
		if (selectOneTBCMETC010a != null) {
			String applEno = selectOneTBCMETC010a.getApplEno();
			if (FwUtil.getUserId().equals(applEno)) {
				return;
			}
		}
		
		TBCMETC011Io bzCntcHistInfo = cmz010dbio.selectOneTBCMETC011c(bzCntcMgntNo, FwUtil.getDeptCd(), FwUtil.getUserId());
		if(bzCntcHistInfo != null) {
			
			String bzCntcProgStcd = "04";  //업무연락진행상태코드 - 진행중
			
			String lastChgrId   = FwUtil.getUserId();
			String lastChgPgmId = FwUtil.getPgmId();
			String lastChgTrmNo = FwUtil.getTrmNo();
			
			String fstReceChrgpEno= "";
			
			//수신단위가 팀일때 담당자 셋팅
			if("T".equals(bzCntcHistInfo.getReceOrgUntCd())) {
				fstReceChrgpEno = FwUtil.getUserId();
			}
			
			cmz010dbio.updateOneTBCMETC010a(bzCntcMgntNo, bzCntcProgStcd, fstReceChrgpEno, lastChgrId, lastChgPgmId, lastChgTrmNo);
			
			// 로그인 직원이 수신자라면 알림해제
			
			TBCMETC011Io tbcmetc011tmp = new TBCMETC011Io();
			tbcmetc011tmp.setBzCntcMgntNo(bzCntcMgntNo);
			tbcmetc011tmp.setSeq(bzCntcHistInfo.getSeq());
			tbcmetc011tmp.setReceChrgpEno(fstReceChrgpEno);
			tbcmetc011tmp.setLastChgrId(lastChgrId);
			tbcmetc011tmp.setLastChgPgmId(lastChgPgmId);
			tbcmetc011tmp.setLastChgTrmNo(lastChgTrmNo);
			
			cmz010dbio.updateOneTBCMETC011b(tbcmetc011tmp);
			
		}
	}
		
	/**
	 * 청약철회숙려 알림데이터 전송
	 * 
	 * @param  CMZ010SVC00In 업무연락유형
	 * @return List<TBCMETC009aIo> 업무연락유형관리 테이블의 OMM
	 * @throws ApplicationException
	 */
	public void tranBzCntcCloff(CMZ010SVC01In input) throws ApplicationException {
		logger.debug("CMZ010BEAN.tranBzCntcCloff()");
		
		COMEILSOS000000001In callEAIInput = new COMEILSOS000000001In();
		
		TBCMETC010Io bzCntcInfo = input.getBzCntcInfo(); // 업무유형
		List<TBCMETC012Io> contInfoList = input.getContInfoList(); // 계약사항
		
		// 요청String contrCustNo = 일시
		String currentDtm = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) + DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		
		bzCntcInfo.setRcDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE));
		bzCntcInfo.setRcTi(DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE));
		
		callEAIInput.setNtfcSeq("ALM"+FwUtil.getUserId()+currentDtm); // 알림순번
		
		// To_Do 확인 필요=> R28_TMR 본인계약 숙려이면 팀장을 셋팅한다)
		callEAIInput.setCnslrId(bzCntcInfo.getFstReceChrgpEno()); // 상담원아이디
		callEAIInput.setNtfcDvsn("S0001"); // 알림구분
		callEAIInput.setNtfcDtm(currentDtm); // 알림시간
		callEAIInput.setNtfcPrcsYn("N"); // 알림처리여부
		if (contInfoList != null && contInfoList.size() > 0) {
			String custNo = contInfoList.get(0).getContrCustNo();
			String contrRrno = cmz010dbio.selectOneTBCSPRF001b(custNo);
			if (StringUtils.isEmpty(contrRrno)) {
				List<TBCMETC012Io> contInfoInq = getContInfoInq(null, null, contInfoList.get(0).getContNo());
				if (contInfoInq != null && contInfoInq.size() > 0) {
					contrRrno = SecuUtil.getEncValue(contInfoInq.get(0).getContrRrno(), SecuUtil.EncType.Jumin);
				}
			}
			
			//callEAIInput.setRrno(SecuUtil.getDecValue(contrRrno, SecuUtil.EncType.Jumin)); // 주민번호
			callEAIInput.setRrno(contrRrno); // 주민번호
		}
		callEAIInput.setRsvtSeq(""); // 예약순번
		callEAIInput.setRcSeq(""); // 접수순번
		callEAIInput.setWrkSeq("1"); // 타스크순번
		callEAIInput.setRegDt(currentDtm.substring(0, 8)); // 등록일자
		callEAIInput.setRegpNm(bzCntcInfo.getApplEno()); // 등록자
		callEAIInput.setLastModDt(currentDtm.substring(0, 8)); // 최종수정일자
		callEAIInput.setLastChgrNm(bzCntcInfo.getApplEno()); // 최종수정자
		callEAIInput.setTaskNo(bzCntcInfo.getBzCntcMgntNo()); // TASK_NO
		
		try{
			String interfaceId = "COM_E_ILSOS000000001"; //업무연락알림 
			EISResponse<COMEILSOS000000001Out> response = null;
			response = InfUtil.callEAI(callEAIInput, interfaceId, COMEILSOS000000001Out.class);
			
			logger.debug("response={}", response);
			COMEILSOS000000001Out responseData = response.getResponseData();
		    logger.debug("response data:{}", responseData);
		} catch (EisExecutionException e) {
			logger.error("EAI송수신에러_EisExecutionException :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		} catch (NotSupportedEISException e) {
			logger.error("EAI송수신에러_NotSupportedEISException :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		}
		
	}

	/**
	 * 업무유형이 민원관련일 경우 SMS발송 //IVR 및 WSS 등록일 경우는 제외
	 * @param bzCntcTypId1
	 * @param bzCntcTypId2
	 * @throws ApplicationException
	 */
	private void sendLmsTrms(String bzCntcTypId1, String bzCntcTypId2, String fstReceChrgpEno) throws ApplicationException {		
		
		// 업무유형이 민원관련일 경우 SMS발송 //IVR 및 WSS 등록일 경우는 제외
		if ("R23".equals(bzCntcTypId1)
				&& "S11".equals(bzCntcTypId2)) {
			CommEmplInfo receEmplInfo = cma002bean.getEmplInfo(FwUtil.getUserId());
			
			String sndUsrNm = receEmplInfo.getEmplNm();
			
			String msg="";
			if ("S10".equals(bzCntcTypId2)) {
				msg = "클레임 관련 긴급 민원이 " + sndUsrNm +" 상담원을 통해 접수되었습니다.";
			} else {
				msg = "고객센터 " + sndUsrNm +" 상담원으로부터 긴급 민원이 접수되었습니다.";
			}
			
			// 100981.소비자보호팀으로 전체 사원검색
			List<TBCSPRF001Io> emplInfoList = cma201dbio.selectMultiTBCSPRF001a("100981");
			
			for (TBCSPRF001Io emplInfo: emplInfoList) {
				if ("S10".equals(bzCntcTypId2)
						&& !emplInfo.getEno().equals(fstReceChrgpEno)) {
					// S10 클레임 관련 긴급 민원일경우 수신자가 아니면 SMS발송하지 않는다
					continue;
				}
				
				try{
					COM_E_DMIOS000000001In req = new COM_E_DMIOS000000001In();
					req.setDocCd("B00000001");
					req.setReqSysId	    ("COR");			 // 요청시스템ID			
					req.setFormtDcd	    ("");  			 // 서식구분코드			
					//req.setScdlId	        ("");  			     // 스케줄ID					
					//headerIo.setNotclId	        ("01_0141");  	     // 안내장ID					
					req.setNotclId	        ("");  	     // 안내장ID
					req.setVerNo      	    ("");  			     // 안내장버젼				
					req.setNotclNm	        ("청약철회 안내");     // 안내장명					
					//headerIo.setDocCd	        ("");  	 // 문서코드					
					req.setDocCd	        ("B00000001");  	 // 문서코드
					req.setDocId	        ("");                // 문서ID						
					req.setCtryCd	        ("KR");              // 국가코드					
					req.setExpDt	        ("");                // 예정일자					
					req.setExpTi	        ("");                // 예정시각					
					req.setInspYn	        ("0");               // 검사여부					
					req.setDocInqYn	        ("1");               // 문서조회여부			
					req.setDocStrgPrd	    ("0");               // 문서보관기간		
					
					//01:창구,02:EMAIL,03:FAX,04:일반우편,05:등기,06:방문전달,07:음성안내,08:SMS,09:LMS,10:콜센터,11:비정기,12:재발행
					req.setNotclSndMedcd    ("09");              // 안내장발송매체코드
					
					req.setReceMphonTeldno  ("");
					req.setReceMphonTelsno  ("");
					req.setReceMphonTelino  ("");
					req.setReceFaxdno       ("");
					req.setReceFaxsno       ("");
					req.setReceFaxino       ("");
					req.setReceEmailId      ("");  //이메일ID			
					
					req.setReceCustNo    (emplInfo.getCustNo());  //수신자-고객번호
					req.setReceCustNm    (emplInfo.getCustNm());  //수신자-고객명
					
					req.setReceMphonTeldno(emplInfo.getMpdno());
					req.setReceMphonTelsno(emplInfo.getMpsno());
					req.setReceMphonTelino(emplInfo.getMpino());
					req.setRespTeldno("");
					req.setRespTelsno("1588");
					req.setRespTelino("0058");
					String xml = "<root><msg>" +msg + "</msg></root>";
					req.setPrintData     (xml);  //출력정보
				   
					COM_E_DMIOS000000001Out sndNotclResult = cma010bean.callEAINotcl(req);
					
					logger.debug("*** MMJ smsmsginfo: {}", sndNotclResult);
				}catch(Exception e){
					logger.error(e.toString());
				}
			}
		}
	}
	
	/**
	 * 바이트 길이 체크
	 * @param str
	 * @param charset
	 * @return
	 */
	private int getByteLength(String str, Charset charset) {
		int length = 0;
		
		if (!StringUtils.isEmpty(str)) {
			if (charset != null) {
				byte[] bytes = str.getBytes(charset);
				if (bytes != null) {
					length = bytes.length;
				}
			} else {
				byte[] bytes = str.getBytes();
				if (bytes != null) {
					length = bytes.length;
				}
			}
		}
		
		logger.debug("getByteLength : " + length);
		
		return length;
	}
}

