package cigna.cm.z.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.dbio.CMZ010DBIO;
import cigna.cm.z.dbio.CMZ020DBIO;
import cigna.cm.z.io.CMZI10SVC02In;
import cigna.cm.z.io.CMZI10SVC02Sub1;
import cigna.cm.z.io.CMZI10SVC04In;
import cigna.cm.z.io.CMZI10SVC04Sub1;
import cigna.cm.z.io.TBCMETC010Io;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;


/**
 * @file         cigna.cm.z.bean.CMZ020BEAN.java
 * @filetype     java source file
 * @brief
 * @author       이보라
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           이보라       2016. 8. 30.       신규 작성
 *
 */
@KlafBean
public class CMZ020BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CMZ020DBIO cmz020dbio;
	
	@Autowired
	private CMZ010DBIO cmz010dbio;
	
	/**
	 * 업무연락유형 목록 조회(TM)
	 * 
	 * @param  CMZI10SVC02In 업무연락유형
	 * @return List<CMZI10SVC02Sub1>
	 * @throws ApplicationException
	 */
	public List<CMZI10SVC02Sub1> getBzCntcTypeList(CMZI10SVC02In input) throws ApplicationException {
		String bzCntcTypId1 = StringUtils.nvl(input.getBzCntcTypId1()); // 업무연락유형ID1
		String bzCntcTypId2 = StringUtils.nvl(input.getBzCntcTypId2()); // 업무연락유형ID2
		String useYn = StringUtils.nvl(input.getUseYn()); // 사용여부

		
		List<CMZI10SVC02Sub1> dsBzCntcTypList = cmz020dbio.selectMultiTBCMETC009a(bzCntcTypId1, bzCntcTypId2, useYn);

		return dsBzCntcTypList;
	}
	

	/**
	 * 접수현황조회 목록 조회
	 * 
	 * @param  CMZ010SVC02In 접수현황조회
	 * @return List<TBCMETC010Io> 공통업무연락 테이블의 OMM
	 * @throws ApplicationException
	 */
	public List<CMZI10SVC04Sub1> getBzCntcList(CMZI10SVC04In input) throws ApplicationException {
		// 입력 정보 체크
		if (StringUtils.isEmpty(input.getRcStrtDt())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"접수시작일자"}, new Object[]{});
		}
		if (StringUtils.isEmpty(input.getRcEndDt())) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"접수종료일자"}, new Object[]{});
		}
		
		String medTypCd = FwUtil.getMedTyp(); //ILS : i-Lisa		

		String bzCntcTypId1 = StringUtils.nvl(input.getBzCntcTypId1()); // 업무연락유형ID1
		String bzCntcTypId2 = StringUtils.nvl(input.getBzCntcTypId2()); // 업무연락유형ID2
		String applDofOrgNo = StringUtils.nvl(input.getApplDofOrgNo()); //신청지점조직번호
		String applOrgNo = StringUtils.nvl(input.getApplOrgNo()); // 신청조직번호
		
		if(!StringUtils.isEmpty(applOrgNo)) {
			applDofOrgNo = "";
		}
		
		String receDofOrgNo = StringUtils.nvl(input.getReceDofOrgNo()); // 수신지점조직번호
		//String receDofOrgNo = ""; // 20170119 마이그 대상아님
		String receOrgNo = StringUtils.nvl(input.getReceOrgNo()); // 수신조직번호
		
		if(!StringUtils.isEmpty(receOrgNo)) {
			receDofOrgNo = "";
		}
		
		String rrno = StringUtils.nvl(input.getRrno()); // 고객주민등록번호
		String bzCntcProgStcd = StringUtils.nvl(input.getBzCntcProgStcd()); // 진행상태코드
		String rcStrtDt = input.getRcStrtDt(); // 접수기간from
		String rcEndDt = input.getRcEndDt(); // 접수기간to
		String receStrtDt = input.getReceStrtDt(); //수신기간from
		String receEndDt = input.getReceStrtDt(); //수신기간to
		String cloffReqRcd    = input.getCloffReqRcd();    // 청약철회요청결과코드
		String bzCntcTeleRcd  = input.getBzCntcTeleRcd();  // 업무연락통화결과코드	

		String regpId = ""; /* AS-IS 로그인 사원번호 */
		
		String applEno = StringUtils.nvl(input.getApplEno()); // 신청사원
		if(!StringUtils.isEmpty(applEno)) {
			regpId = StringUtils.nvl(input.getRegpId(), applEno);
			applOrgNo = ""; // 사원번호가 있다면 조직은 조회할 필요없음
		}
		String fstReceChrgpEno = StringUtils.nvl(input.getReceChrgpEno()); // 수신사원
		if(!StringUtils.isEmpty(fstReceChrgpEno)) {
			regpId = StringUtils.nvl(input.getRegpId(), fstReceChrgpEno);
			receOrgNo = ""; // 사원번호가 있다면 조직은 조회할 필요없음
		}	

		String custNo=null;
		
		List<CMZI10SVC04Sub1> bzCntcList = null;
		// 주민번호가 있다면 암호화
		if (!StringUtils.isEmpty(rrno)) {
			rrno = SecuUtil.getEncValue(rrno, SecuUtil.EncType.Jumin);
			custNo = cmz010dbio.selectOneTBCSPRF001(rrno);
			logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> custNo"+custNo);
			
			if (StringUtils.isEmpty(custNo)) {
				//{0} 입력 오류입니다.
				custNo = "999999999";
				//throw new ApplicationException("APCME0025", new Object[]{"주민등록번호"});
			}
		}
		
		if(!StringUtils.isEmpty(custNo)){
			logger.debug(">>>>>>>>> selectMultiTBCMETC010b");
			bzCntcList = cmz020dbio.selectMultiTBCMETC010b(medTypCd, applDofOrgNo, bzCntcTypId1, bzCntcTypId2, applOrgNo, receDofOrgNo, receOrgNo, applEno, fstReceChrgpEno, bzCntcProgStcd, custNo, rcStrtDt, rcEndDt, receStrtDt, receEndDt, cloffReqRcd, bzCntcTeleRcd, regpId, rrno);
		}else{
			logger.debug(">>>>>>>>> selectMultiTBCMETC010a");
			bzCntcList = cmz020dbio.selectMultiTBCMETC010a(medTypCd, applDofOrgNo, bzCntcTypId1, bzCntcTypId2, applOrgNo, receDofOrgNo, receOrgNo, applEno, fstReceChrgpEno, bzCntcProgStcd, custNo, rcStrtDt, rcEndDt, receStrtDt, receEndDt, cloffReqRcd, bzCntcTeleRcd, regpId, rrno);
		}
		//SecuUtil.doDecList(bzCntcList); // 암호화하지 않는다
		
		return bzCntcList;
		
	}
	
	/**
	 * 업무연락진행정보  조회
	 * 
	 * @param  String contNo
	 * @return List<CMZI10SVC02Sub1>
	 * @throws ApplicationException
	 */
	public TBCMETC010Io getBzCntcInfo(String contNo) throws ApplicationException {
		
		TBCMETC010Io dsBzCntcTypInfo = cmz020dbio.selectOneTBCMETC010a(contNo, "");

		return dsBzCntcTypInfo;
	}

}

