package cigna.cm.z.bean;

import java.io.File;
import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.dbio.CMZ030DBIO;
import cigna.cm.z.io.CMZ030SVC00In;
import cigna.cm.z.io.CMZ030SVC01In;
import cigna.cm.z.io.CMZ030SVC02In;
import cigna.cm.z.io.CMZ030SVC04In;
import cigna.cm.z.io.CMZ030SVC04Sub;
import cigna.cm.z.io.TBCMCCD047Io;
import cigna.cm.z.io.TBCMCCD048Io;
import cigna.cm.z.io.TBCMCCD049Io;
import cigna.cm.z.io.TBCMCCD050Io;
import cigna.cm.z.io.TBCMCCD053Io;
import cigna.cm.z.io.TBCMCCD054Io;
import cigna.sys.util.SFTPClient;
import cigna.zz.BizDateInfo;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;


/**
 * @file         cigna.cm.z.bean.CMZ030BEAN.java
 * @filetype     java source file
 * @brief
 * @author       문효증
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           문효증       			2016. 11. 21.       신규 작성
 *
 */
@KlafBean
public class CMZ030BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZ030DBIO cmz030dbio;
	
	@Autowired
	private BizDateInfo bizdateinfo;
	
	/** 파일경로명 */
	private static final String FILE_UPLOAD_DIR_PATH = "/sdata/doc/cm/ec";
	//private static final String FILE_UPLOAD_DIR_PATH = "C:/NGSCore/workspace/tempFile";
	
	
	/** FOLDER SEPARATOR */
	private static final String FOLDER_SEPARATOR= "/";
	
	/** FILTER PATTERN */
	private static final String FILTER_PATTERN= "*";
	
	/** 다운로드유효일 */
	private static final int DWLD_VLD_DAY= 5;
	
	/** 파일최대크기 */
	private static final long FILE_MAX_SIZE_1 = 1 * 1024 * 1024 * 1024; //배치서버 위치정보 입력(GB)
	private static final long FILE_MAX_SIZE_2 = 1 * 1024 * 1024 * 1024; //타서버 전송 요청(GB)
	private static final long FILE_MAX_SIZE_3 = 1 * 1024 * 1024 * 1024; //기 산출파일 업로드(GB)
	
	/** 전체파일최대크기 */
	private static final long TOT_FILE_MAX_SIZE_1 = 1 * 1024 * 1024 * 1024;//배치서버 위치정보 입력(GB)
	private static final long TOT_FILE_MAX_SIZE_2 = 1 * 1024 * 1024 * 1024;//타서버 전송 요청(GB)
	private static final long TOT_FILE_MAX_SIZE_3 = 1 * 1024 * 1024 * 1024;//기 산출파일 업로드(GB)

	
	long totalFileSize = 0;
	int fileIdx = 0;

	
	/**
	 * Work Request 목록
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public List<TBCMCCD047Io> getWorkRequestList(CMZ030SVC00In input) throws ApplicationException {

		String userId = FwUtil.getUserId();
		
		int pageNum = input.getPageNum();
		int pageCount = input.getPageCount();
		
		// 필수입력값체크
		if( StringUtils.isEmpty(userId) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		String bzReqNo = input.getBzReqNo();
		String reqpId = input.getReqpId();
		
		String reqStrDt = input.getReqStrDt();
		String reqEndDt = input.getReqEndDt();
		
		// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
		// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
		boolean bValidFmYmd = DateUtils.isValidDate(reqStrDt, DateUtils.EMPTY_DATE_TYPE);
		if ( !bValidFmYmd ) {throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
		
		boolean bValidToYmd = DateUtils.isValidDate(reqEndDt, DateUtils.EMPTY_DATE_TYPE);
		if ( !bValidToYmd ) {throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

		if ( Integer.parseInt(reqStrDt) > Integer.parseInt(reqEndDt) ) {
			//  APCME0006 : 적용종료일자는 적용시작일자보다 크거나 같아야 합니다. 
			throw new ApplicationException("APCME0006", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), reqStrDt, reqEndDt } );
		}
		
		List<TBCMCCD047Io> wrList = cmz030dbio.selectMultiTBCMCCD047b(userId, bzReqNo, reqStrDt, reqEndDt, reqpId, pageNum, pageCount);
		
		return wrList;
	}
	
	/**
	 * Work Request 요청 상세
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public TBCMCCD053Io getWorkRequest(CMZ030SVC00In input) throws ApplicationException {
		
		String bzReqNo = input.getBzReqNo();
		String userId = FwUtil.getUserId();
		
		// 필수입력값체크
		if( StringUtils.isEmpty(bzReqNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "업무요청번호" });
		}
		if( StringUtils.isEmpty(userId) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		TBCMCCD053Io  wrInfo = cmz030dbio.selecOneTBCMCCD053(bzReqNo, userId);
		
		return wrInfo;
	}
	
	/**
	 * Work Request 요청 저장
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public int modifyWorkRequest(CMZ030SVC04In input) throws ApplicationException {
		
		String bzReqNo = input.getSrmId();
		String reqpId = input.getSrmReqEmpId();
		String reqDtm = input.getSrmReqDttm();
		String reqTitlCtnt = input.getSrmReqTitle();
		
		List<CMZ030SVC04Sub> prcsrIdList = input.getAssEmpIdGrid();
		
		String userId = FwUtil.getUserId();//최종변경자ID(LAST_CHGR_ID) 설정
		String pgmId = FwUtil.getPgmId();// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		String trmNo = FwUtil.getTrmNo();// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		// 필수입력값체크
		if( StringUtils.isEmpty(bzReqNo) ){
			throw new ApplicationException("APCME0025", new Object[]{"요청번호"});
		}
		if( StringUtils.isEmpty(reqDtm) ){
			throw new ApplicationException("APCME0025", new Object[]{"요청일시"});
		}
		if( StringUtils.isEmpty(reqTitlCtnt) ){
			throw new ApplicationException("APCME0025", new Object[]{"요청제목"});
		}
		if( StringUtils.isEmpty(userId) ){
			throw new ApplicationException("APCME0025", new Object[]{"사원번호"});
		}
		
		//처리자ID INSERT
		int prcsrCnt = 0;
		if(prcsrIdList != null){
			for(CMZ030SVC04Sub prcsrIdInfo : prcsrIdList){
				
				String prcsrId = prcsrIdInfo.getAssEmpId();
				
				TBCMCCD054Io prcsrInfo = new TBCMCCD054Io();
				
				prcsrInfo.setBzReqNo(bzReqNo);
				prcsrInfo.setPrcsrId(prcsrId);
				
				prcsrInfo.setLastChgrId(userId);
				prcsrInfo.setLastChgPgmId(pgmId);
				prcsrInfo.setLastChgTrmNo(trmNo);
				
				prcsrCnt += cmz030dbio.insertOneTBCMCCD054(prcsrInfo);
			}
		}
		
		if( prcsrCnt == 0 ){
			throw new ApplicationException("APCME0025", new Object[]{"처리자ID"});
		}
		
		//요청정보 INSERT
		int reqCnt = 0;
		TBCMCCD053Io reqInfo = new TBCMCCD053Io();
		reqInfo.setBzReqNo(bzReqNo);
		reqInfo.setReqpId(reqpId);
		reqInfo.setReqDtm(reqDtm);
		reqInfo.setReqTitlCtnt(reqTitlCtnt);
		
		reqInfo.setLastChgrId(userId);
		reqInfo.setLastChgPgmId(pgmId);
		reqInfo.setLastChgTrmNo(trmNo);
		
		reqCnt = cmz030dbio.insertOneTBCMCCD053(reqInfo);
		
		return reqCnt;
	}
	
	/**
	 * Work Request 처리 목록
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public List<TBCMCCD047Io> getWorkRequestList2(CMZ030SVC00In input) throws ApplicationException {

		String userId = FwUtil.getUserId();
		
		int pageNum = input.getPageNum();
		int pageCount = input.getPageCount();
		
		// 필수입력값체크
		if( StringUtils.isEmpty(userId) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		String bzReqNo = input.getBzReqNo();
		String prcsrId = input.getPrcsrId();
		
		String prcsStrDt = input.getPrcsStrDt();
		String prcsEndDt = input.getPrcsEndDt();
		
		// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
		// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
		boolean bValidFmYmd = DateUtils.isValidDate(prcsStrDt, DateUtils.EMPTY_DATE_TYPE);
		if ( !bValidFmYmd ) {throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
		
		boolean bValidToYmd = DateUtils.isValidDate(prcsEndDt, DateUtils.EMPTY_DATE_TYPE);
		if ( !bValidToYmd ) {throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

		if ( Integer.parseInt(prcsStrDt) > Integer.parseInt(prcsEndDt) ) {
			//  APCME0006 : 적용종료일자는 적용시작일자보다 크거나 같아야 합니다. 
			throw new ApplicationException("APCME0006", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), prcsStrDt, prcsEndDt } );
		}
		
		List<TBCMCCD047Io> wrList = cmz030dbio.selectMultiTBCMCCD047(userId, bzReqNo, prcsStrDt, prcsEndDt, prcsrId, pageNum, pageCount);
		
		return wrList;
	}
	
	/**
	 * Work Request 처리 상세
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public TBCMCCD047Io getWorkRequestInfo(CMZ030SVC01In input) throws ApplicationException {
		
		String bzReqNo = input.getBzReqNo();
		String userId = FwUtil.getUserId();
		
		// 필수입력값체크
		if( StringUtils.isEmpty(bzReqNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "업무요청번호" });
		}
		if( StringUtils.isEmpty(userId) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "사원번호" });
		}
		
		TBCMCCD047Io  wrInfo = cmz030dbio.selectOneTBCMCCD047(bzReqNo, userId);
		
		if(wrInfo != null){
			List<TBCMCCD048Io> wrFileList = cmz030dbio.selectMultiTBCMCCD048(bzReqNo);
			
			int fileListCnt = 0;
			if(wrFileList != null){
				fileListCnt = wrFileList.size();
				wrInfo.setFileListCnt(fileListCnt);
				wrInfo.setFileList(wrFileList);
			}
		}

		return wrInfo;
	}
	
	/**
	 * 파일 다운로드 히스토리 목록
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public List<TBCMCCD049Io> getFileDwldHisList(CMZ030SVC01In input) throws ApplicationException {
		
		String bzReqNo = input.getBzReqNo();
		String fileSeq = input.getFileSeq();
		
		// 필수입력값체크
		if( StringUtils.isEmpty(bzReqNo) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "업무요청번호" });
		}
		
		// 필수입력값체크
		if( StringUtils.isEmpty(fileSeq) ){
			throw new ApplicationException( "APCME0005", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "파일순번" });
		}

		List<TBCMCCD049Io> fileDwldHisList = cmz030dbio.selectMultiTBCMCCD049(bzReqNo, fileSeq);
		
		return fileDwldHisList;
	}
	
	/**
	 * SFTP계정 목록
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public List<TBCMCCD050Io> getHostNmList() throws ApplicationException {

		List<TBCMCCD050Io> hostNmList = cmz030dbio.selectMultiTBCMCCD050();
		
		return hostNmList;
	}
	
	/**
	 * 다운로드파일정보 저장
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public int insertDownloadFileInfo(TBCMCCD049Io input) throws ApplicationException{
		
		String userId = FwUtil.getUserId();//최종변경자ID(LAST_CHGR_ID) 설정
		String pgmId = FwUtil.getPgmId();// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		String trmNo = FwUtil.getTrmNo();// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		input.setLastChgrId(userId);
		input.setLastChgPgmId(pgmId);
		input.setLastChgTrmNo(trmNo);
		
		int inCnt = cmz030dbio.insertOneTBCMCCD049(input);
		
		return inCnt;
	}
	
	/**
	 * Work Request 처리
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	public int setFileInfo(CMZ030SVC02In input) throws ApplicationException {
		
		String prcsDcd = input.getPrcsDcd();
		int resultCnt = 0;
		totalFileSize = 0;
		fileIdx = 0;

		int fileListCnt = input.getFileListCnt();
		
		List<TBCMCCD048Io> wrFileList = input.getFileList();
		
		String failMsg = null;
		
		try{
			if(fileListCnt > 0){
				if("1".equals(prcsDcd)){ //배치서버 위치정보 입력
					failMsg = downloadFileList(wrFileList);
					if(totalFileSize> TOT_FILE_MAX_SIZE_1) failMsg = "전체파일용량초과";
				}else if("2".equals(prcsDcd)){ //타서버 전송 요청
					failMsg = moveFileList(wrFileList);
					if(totalFileSize> TOT_FILE_MAX_SIZE_2) failMsg = "전체파일용량초과";
				}else if("3".equals(prcsDcd)){ //기 산출파일 업로드
					failMsg = checkFileSize(wrFileList);
					if(totalFileSize> TOT_FILE_MAX_SIZE_3) failMsg = "전체파일용량초과";
				}
				
				 
				
				if(failMsg == null){//파일처리성공
					
					//실패시 MSG
					failMsg = "DB저장실패";
					
					String userId = FwUtil.getUserId();//최종변경자ID(LAST_CHGR_ID) 설정
					String pgmId = FwUtil.getPgmId();// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
					String trmNo = FwUtil.getTrmNo();// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
					
					//다운로드유효일자 = 처리일+DWLD_VLD_DAY일(영업일 기준)
					String dwldVldDt = bizdateinfo.getNNxtBizDt(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE), DWLD_VLD_DAY);
					
					TBCMCCD047Io input47Io = new TBCMCCD047Io();
					
					input47Io.setBzReqNo(input.getBzReqNo());
					input47Io.setPrcsDcd(prcsDcd);
					input47Io.setPrcsrId(userId);
					input47Io.setReqpId(input.getReqpId());
					input47Io.setNote(input.getNote());
					input47Io.setLastChgrId(userId);
					input47Io.setLastChgPgmId(pgmId);
					input47Io.setLastChgTrmNo(trmNo);
					
					int inCnt = cmz030dbio.insertOneTBCMCCD047(input47Io);
					
					if(inCnt != 1) throw new Exception(failMsg);
						
					for(TBCMCCD048Io fileInfo : wrFileList){
						
						if("3".equals(prcsDcd)) fileInfo.setReceFilePathNm(FILE_UPLOAD_DIR_PATH);
						
						fileInfo.setDwldVldDt(dwldVldDt);
						fileInfo.setLastChgrId(userId);
						fileInfo.setLastChgPgmId(pgmId);
						fileInfo.setLastChgTrmNo(trmNo);
						resultCnt += cmz030dbio.insertOneTBCMCCD048(fileInfo);
					}
				}else{
					throw new Exception(failMsg);
				}
			}
			
		}catch (Exception e) {
			int iDelCnt = 0;
			
			if("1".equals(prcsDcd)){ //배치서버 위치정보 입력
				iDelCnt = deleteFileList(wrFileList);
			}else if("2".equals(prcsDcd)){ //배치서버 위치정보 입력
				iDelCnt = deleteReceFileList(wrFileList);
			}else if("3".equals(prcsDcd)){ //기 산출파일 업로드
				iDelCnt = deleteFileList(wrFileList);
			}
			
			logger.debug( "wrFileList : {}, 생성 실패 후 파일삭제건수 : {} " , fileListCnt, iDelCnt );
			
			throw new ApplicationException("KIERE0005", null, new Object[]{failMsg});
		}
		
		logger.debug( "wrFileList : {}, 파일처리건수 : {} " , fileListCnt, resultCnt );

		return resultCnt;
	}

	/**
	 * 파일리스트 이동(SEND HOST >>>> RECE HOST)
	 * @param wrFileList
	 * @return
	 */
	private String moveFileList(List<TBCMCCD048Io> wrFileList){
		
		for(TBCMCCD048Io fileInfo : wrFileList){
			String failMsg = moveFile(fileInfo);
			if(failMsg != null){
				return failMsg;
			} 
		}
		
		return null;
	}
	
	/**
	 * 파일 이동(SEND HOST >>>> RECE HOST)
	 * @param fileInfo
	 * @return
	 */
	private String moveFile(TBCMCCD048Io fileInfo){
		
		SFTPClient dClient = null;
		SFTPClient uClient = null;
		File file = null;
		
		//SEND HOST
		String sndmHostNm = fileInfo.getSndmHostNm();
		String sndmFilePathNm = fileInfo.getSndmFilePathNm();
		
		//RECE HOST
		String receHostNm = fileInfo.getReceHostNm();
		String receFilePathNm = fileInfo.getReceFilePathNm();
		
		String atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();
		String atchSavFileNm = fileInfo.getAtchSavFileNm();
		
		try{
			
			TBCMCCD050Io sendSFTPInfo = getSFTPInfo(sndmHostNm);
			TBCMCCD050Io receSFTPInfo = getSFTPInfo(receHostNm);
			
			if(sendSFTPInfo == null){
				return "잘못된 송신호스트정보(호스트정보 NULL)";
			}
			
			if(receSFTPInfo == null){
				return "잘못된 수신호스트정보(호스트정보 NULL)";
			}
			
			if(sndmFilePathNm == null || (!sndmFilePathNm.startsWith("/sdata") && !sndmFilePathNm.startsWith("/logs"))) return "잘못된 송신파일경로("+sndmFilePathNm+")";

			dClient = new SFTPClient(sendSFTPInfo.getSftpIpAddr(), sendSFTPInfo.getSftpAccntNm(), sendSFTPInfo.getSftpPswd());
			
			Long fileSize = (Long)dClient.getFileAttribute(sndmFilePathNm, atchOrgcpFileNm, SFTPClient.ATTRIBUTE_SIZE_LONG);
			totalFileSize += fileSize.longValue();
			if(fileSize.longValue() > FILE_MAX_SIZE_2) return "파일용량초과("+fileSize.longValue()+" Byte)";
			
			
			file = dClient.download(sndmFilePathNm, FILE_UPLOAD_DIR_PATH, atchOrgcpFileNm, atchSavFileNm);
			
			//totalFileSize += file.length();
			//if(file.length() > FILE_MAX_SIZE_2) return "파일용량초과";
			
			uClient = new SFTPClient(receSFTPInfo.getSftpIpAddr(), receSFTPInfo.getSftpAccntNm(), receSFTPInfo.getSftpPswd());
			
			//파일 중복체크
			List<String> remoteFileList = uClient.getFileList(receFilePathNm, FILTER_PATTERN);
			if(remoteFileList != null){
				for(String fileNm: remoteFileList){
					if(fileNm != null && fileNm.equals(atchSavFileNm)){
						return "수신파일중복";
					}
				}
			}

			uClient.upload(receFilePathNm, file);

		}catch (Exception e) {
			logger.error("Exception : " + e.getMessage());
			return "타서버전송실패";
		}finally {
			if(dClient!=null) try{dClient.close();}catch(Exception ce){logger.error("Exception : " + ce.getMessage());}
			if(uClient!=null) try{uClient.close();}catch(Exception ce){logger.error("Exception : " + ce.getMessage());}
			if(file!=null) try{file.delete();}catch(Exception ce){logger.error("Exception : " + ce.getMessage());}
		}
		
		return null;
	}
	
	/**
	 * 파일리스트 다운로드(SEND HOST >>>> LOCAL)
	 * @param wrFileList
	 * @return
	 */
	private String downloadFileList(List<TBCMCCD048Io> wrFileList){
		for(TBCMCCD048Io fileInfo : wrFileList){
			String failMsg = downloadFile(fileInfo);
			if(failMsg != null){
				return failMsg;
			} 
		}
		return null;
	}
	
	/**
	 * 파일 다운로드(SEND HOST >>>> LOCAL)
	 * @param fileInfo
	 * @param idx
	 * @return
	 */
	private String downloadFile(TBCMCCD048Io fileInfo){
		
		SFTPClient dClient = null;
		//File file = null;
		
		//SEND HOST
		String sndmHostNm = fileInfo.getSndmHostNm();
		String sndmFilePathNm = fileInfo.getSndmFilePathNm();

		String atchOrgcpFileNm = fileInfo.getAtchOrgcpFileNm();
		String atchSavFileNm = 	DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)
							+ DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE)
							+ StringUtils.lpad(String.valueOf(fileIdx++), 6, "0");
		
		try{
			
			TBCMCCD050Io sendSFTPInfo = getSFTPInfo(sndmHostNm);
			
			if(sendSFTPInfo == null){
				return "잘못된 송신호스트정보(호스트정보 NULL)";
			}
			
			if(sndmFilePathNm == null || (!sndmFilePathNm.startsWith("/sdata") && !sndmFilePathNm.startsWith("/logs")) ) return "잘못된 송신파일경로("+sndmFilePathNm+")";
			
			dClient = new SFTPClient(sendSFTPInfo.getSftpIpAddr(), sendSFTPInfo.getSftpAccntNm(), sendSFTPInfo.getSftpPswd());
			
			Long fileSize = (Long)dClient.getFileAttribute(sndmFilePathNm, atchOrgcpFileNm, SFTPClient.ATTRIBUTE_SIZE_LONG);
			totalFileSize += fileSize.longValue();
			if(fileSize.longValue() > FILE_MAX_SIZE_1) return "파일용량초과("+fileSize.longValue()+" Byte)";
			
			dClient.download(sndmFilePathNm, FILE_UPLOAD_DIR_PATH, atchOrgcpFileNm, atchSavFileNm);
			//file = dClient.download(sndmFilePathNm, FILE_UPLOAD_DIR_PATH, atchOrgcpFileNm, atchSavFileNm);

			fileInfo.setAtchSavFileNm(atchSavFileNm);
			fileInfo.setReceFilePathNm(FILE_UPLOAD_DIR_PATH);
			
			//totalFileSize += file.length();
			//if(file.length() > FILE_MAX_SIZE_1) return "파일용량초과";
		}catch (Exception e) {
			logger.error("Exception : " + e.getMessage());
			return "배치서버전송실패";
		}finally {
			if(dClient!=null) try{dClient.close();}catch(Exception ce){logger.error("Exception : " + ce.getMessage());}
		}
		
		return null;
	}
	
	/**
	 * 파일리스트 삭제(LOCAL)
	 * @param wrFileList
	 * @return
	 */
	private int deleteFileList(List<TBCMCCD048Io> wrFileList) {
		int iResult = 0;
		
		File file = null;
		
		String deleteFilePath = "";
        try{
        	for(TBCMCCD048Io fileInfo : wrFileList){
        		String savFileNm = fileInfo.getAtchSavFileNm();
        		boolean bResult = false;
        		if(!StringUtils.isEmpty(savFileNm)){
        			deleteFilePath = FILE_UPLOAD_DIR_PATH + FOLDER_SEPARATOR + savFileNm;
            		file = new File(deleteFilePath);
            		bResult = file.delete();
            		if (bResult) iResult++;
        		}
        		
            }
        }catch (Exception e) {
        	logger.error("Exception : " + e.getMessage());
        	return iResult;
		}
        	
		return iResult;
	}
	
	
	/**
	 * 파일리스트 삭제(RECE HOST)
	 * @param wrFileList
	 * @return
	 */
	private int deleteReceFileList(List<TBCMCCD048Io> wrFileList) {
		int iResult = 0;
		try{
			for(TBCMCCD048Io fileInfo : wrFileList){
				boolean bResult = deleteReceFile(fileInfo);
				if (bResult) iResult++;
			}
		}catch (Exception e) {
			logger.error("Exception : " + e.getMessage());
        	return iResult;
		}
		return iResult;
	}
	
	/**
	 * 파일 삭제(RECE HOST)
	 * @param fileInfo
	 * @return
	 */
	private boolean deleteReceFile(TBCMCCD048Io fileInfo) {
		
		boolean bResult = false;
		SFTPClient dClient = null;
		
		String receHostNm = fileInfo.getReceHostNm();
		String receFilePathNm = fileInfo.getReceFilePathNm();

		String atchSavFileNm = fileInfo.getAtchSavFileNm();

		
		try{
			
			TBCMCCD050Io receSFTPInfo = getSFTPInfo(receHostNm);
			
			if(receSFTPInfo == null){
				return false;
			}
			
			dClient = new SFTPClient(receSFTPInfo.getSftpIpAddr(), receSFTPInfo.getSftpAccntNm(), receSFTPInfo.getSftpPswd());
			bResult = dClient.delete(receFilePathNm, atchSavFileNm);
			
		}catch (Exception e) {
			logger.error("Exception : " + e.getMessage());
			return false;
		}finally {
			if(dClient!=null) try{dClient.close();}catch(Exception ce){logger.error("Exception : " + ce.getMessage());}
		}
		
		return bResult;
	}
	
	/**
	 * SFTP계정 정보
	 * @param hostNm
	 * @return
	 */
	private TBCMCCD050Io getSFTPInfo(String hostNm){
		
		TBCMCCD050Io out = new TBCMCCD050Io();
		
		out = cmz030dbio.selectOneTBCMCCD050(hostNm);
		
		String decSftpPswd = null;
		
		if(out != null){
			String sftpPswd = out.getSftpPswd();
	
			if(sftpPswd != null){
				try{
					decSftpPswd = SecuUtil.getDecValue(sftpPswd, SecuUtil.EncType.Etc);
				}catch (Exception e) {
					decSftpPswd = out.getSftpPswd();
				}
			}
			
			out.setSftpPswd(decSftpPswd);
		}
		
		return out;
	}
	
	
	private String checkFileSize(List<TBCMCCD048Io> wrFileList){
		String filePath = "";
		File file = null;

    	for(TBCMCCD048Io fileInfo : wrFileList){
    		String savFileNm = fileInfo.getAtchSavFileNm();
    		if(!StringUtils.isEmpty(savFileNm)){
    			filePath = FILE_UPLOAD_DIR_PATH + FOLDER_SEPARATOR + savFileNm;
        		file = new File(filePath);
        		totalFileSize += file.length();
    			if(file.length() > FILE_MAX_SIZE_3) return "파일용량초과("+file.length()+" Byte)";
    		}
        }
    	
    	return null;
    	
	}

}

