package cigna.cm.z.bean;

import java.util.ArrayList;
import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.CollectionUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.dbio.CMA002DBIO;
import cigna.cm.a.domain.CommEmplInfo;
import cigna.cm.z.dbio.CMZ010DBIO;
import cigna.cm.z.dbio.CMZ020DBIO;
import cigna.cm.z.io.CMZ010SVC01In;
import cigna.cm.z.io.CMZ010SVC03In;
import cigna.cm.z.io.CMZI10SVC03In;
import cigna.cm.z.io.CMZI10SVC03Sub1;
import cigna.cm.z.io.CMZI10SVC04Sub1;
import cigna.cm.z.io.CMZI10SVC05In;
import cigna.cm.z.io.CMZI10SVC05Out;
import cigna.cm.z.io.CMZI10SVC05Sub1;
import cigna.cm.z.io.CMZI10SVC05Sub2;
import cigna.cm.z.io.CMZI10SVC05Sub3;
import cigna.cm.z.io.COMECOTOS000000001In;
import cigna.cm.z.io.COMECOTOS000000001Out;
import cigna.cm.z.io.TBCMETC010Io;
import cigna.cm.z.io.TBCMETC011Io;
import cigna.cm.z.io.TBCMETC012Io;
import cigna.zz.FwUtil;
import cigna.zz.InfUtil;
import cigna.zz.ReflUtil;
import cigna.zz.SecuUtil;

/**
 * @file         cigna.cm.z.bean.CMZI10BEAN.java
 * @filetype     java source file
 * @brief        TM 업무연락 BEAN
 * @author       박진성
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1    박진성                 2016. 8. 31.      신규작성
 *
 */
@KlafBean
public class CMZI10BEAN {
	
final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZ010BEAN cmz010bean;
	
	@Autowired
	private CMZ010DBIO cmz010dbio;
	
	@Autowired
	private CMZ020DBIO cmz020dbio;
	
	@Autowired
	private CMA002DBIO cma002dbio; 	
	
	/**
	 * 업무연락 알림목록조회
	 * 
	 * @param  String 사원번호
	 * @return List<CMZI10SVC04Sub1> 업무연락정보
	 * @throws ApplicationException
	 */
	public List<CMZI10SVC04Sub1> getBzCntcNtfcList(String eno) throws ApplicationException {
		if (StringUtils.isEmpty(eno)) {
			eno = FwUtil.getUserId();
		}
		
		CommEmplInfo emplInfo = null;
		
		if (!StringUtils.isEmpty(eno)) {
			emplInfo = cma002dbio.selectOneTBSLEMP001(eno);
		}
		
		String orgNo = FwUtil.getDeptCd();
		if(StringUtils.isEmpty(orgNo) && emplInfo != null) {
			orgNo = emplInfo.getOrgNo();
		}
		
		List<CMZI10SVC04Sub1> selectMultiTBCMETC010c = new ArrayList<CMZI10SVC04Sub1>();
		
		if (!StringUtils.isEmpty(eno)) {
			selectMultiTBCMETC010c = cmz020dbio.selectMultiTBCMETC010c(eno, orgNo, "00010101000001");
		}
		
		return selectMultiTBCMETC010c;
	}
	
	
	/**
	 * 업무연락알림 대상조회
	 * 
	 * @param   String 사원번호
	 * @return List<TBCMETC010Io> 업무연락정보
	 * @throws ApplicationException
	 */
	public List<TBCMETC010Io> getBzCntcNtfcTgtList(String eno) throws ApplicationException {
		if (StringUtils.isEmpty(eno)) {
			eno = FwUtil.getUserId();
		}
		
		CommEmplInfo emplInfo = null;
		if (!StringUtils.isEmpty(eno)) { 
			emplInfo = cma002dbio.selectOneTBSLEMP001(eno);
		}
		
		String orgNo = FwUtil.getDeptCd();
		if(StringUtils.isEmpty(orgNo) && emplInfo != null) {
			orgNo = emplInfo.getOrgNo();
		}
		
		List<TBCMETC010Io> selectMultiTBCMETC011a = new ArrayList<TBCMETC010Io>();
		
		if (!StringUtils.isEmpty(eno)) {
			selectMultiTBCMETC011a = cmz020dbio.selectMultiTBCMETC011a(eno);
			
			SecuUtil.doDecList(selectMultiTBCMETC011a);
		}
		
		return selectMultiTBCMETC011a;
	}
	
	
	/**
	 * 업무연락 상세조회
	 * 
	 * @param  CMZI10SVC05In 업무저장정보
	 * @return CMZI10SVC05Out 업무연락정보
	 * @throws ApplicationException
	 */
	public CMZI10SVC05Out getBzCntcInfo(CMZI10SVC05In input) throws ApplicationException {
		
		CMZI10SVC05Out output = new CMZI10SVC05Out();
		
		// 업무연락 input
		CMZ010SVC01In cmz010svc01in = new CMZ010SVC01In();
		cmz010svc01in.setBzCntcMgntNo(input.getBzCntcMgntNo());
		
		// 업무연락정보 조회
		TBCMETC010Io bzCntcInfoSource = cmz010bean.getBzCntcInfo(cmz010svc01in);
		if(bzCntcInfoSource == null ) {
			//조회된 {0}이(가) 없습니다.
			throw new ApplicationException("APAIE0041", null, new String[]{cmz010svc01in.getBzCntcMgntNo()});
		}
			
		// 업무연락이력정보 조회
		TBCMETC011Io bzCntcHistInfoSource = cmz010bean.getBzCntcHistInfo(cmz010svc01in);
		// 저장된 업무연락계약 조회
		List<TBCMETC012Io> contInfoListSource = cmz010bean.getSavedContInfoInq(cmz010svc01in);
		
		output.setBzCntcMgntNo(input.getBzCntcMgntNo());
		
		// 업무연락정보 조회
		CMZI10SVC05Sub1 bzCntcInfoTarget = new CMZI10SVC05Sub1();
		bzCntcInfoTarget.setBzCntcMgntNo(bzCntcInfoSource.getBzCntcMgntNo());// set [업무연락관리번호]
		bzCntcInfoTarget.setBzCntcTypId1(bzCntcInfoSource.getBzCntcTypId1());// set [업무연락유형ID]
		bzCntcInfoTarget.setBzCntcTypNm1(bzCntcInfoSource.getBzCntcTypNm1());// set [업무연락유형명]
		bzCntcInfoTarget.setBzCntcTypId2(bzCntcInfoSource.getBzCntcTypId2());// set [업무연락유형ID2]
		bzCntcInfoTarget.setBzCntcTypNm2(bzCntcInfoSource.getBzCntcTypNm2());// set [업무연락유형명2]
		bzCntcInfoTarget.setEmerDcd(bzCntcInfoSource.getEmerDcd());// set [긴급구분코드]
		bzCntcInfoTarget.setEmerDcdNm(bzCntcInfoSource.getEmerDcdNm());// set [긴급구분코드명]
		bzCntcInfoTarget.setRcDtm(bzCntcInfoSource.getRcDtm());// set [접수일시]
		bzCntcInfoTarget.setApplOrgNo(bzCntcInfoSource.getApplOrgNo());// set [신청조직번호]
		bzCntcInfoTarget.setApplOrgNm(bzCntcInfoSource.getApplOrgNm());// set [신청조직명]
		bzCntcInfoTarget.setApplEno(bzCntcInfoSource.getApplEno());// set [신청사원번호]
		bzCntcInfoTarget.setApplNm(bzCntcInfoSource.getApplNm());// set [신청사원명]
		bzCntcInfoTarget.setReceOrgNo(bzCntcInfoSource.getReceOrgNo());// set [수신조직번호]
		bzCntcInfoTarget.setReceOrgNm(bzCntcInfoSource.getReceOrgNm());// set [수신조직명]
		bzCntcInfoTarget.setFstReceChrgpEno(bzCntcInfoSource.getFstReceChrgpEno());// set [최초수신담당자사원번호]
		bzCntcInfoTarget.setFstReceChrgpNm(bzCntcInfoSource.getFstReceChrgpNm());// set [최초수신담당자사원명]
		bzCntcInfoTarget.setCmptDtm(bzCntcInfoSource.getCmptDtm());// set [완료일시(회신일시)]
		bzCntcInfoTarget.setBzCntcProgStcd(bzCntcInfoSource.getBzCntcProgStcd());// set [업무연락진행상태코드]
		bzCntcInfoTarget.setBzCntcProgStNm(bzCntcInfoSource.getBzCntcProgStNm());// set [업무연락진행상태명]
		bzCntcInfoTarget.setBzCntcReqCtnt(bzCntcInfoSource.getBzCntcReqCtnt());// set [업무연락요청내용]
		bzCntcInfoTarget.setCloffReqRcd(bzCntcInfoSource.getCloffReqRcd());// set [청약철회요청결과코드]
		bzCntcInfoTarget.setCloffReqRcdNm(bzCntcInfoSource.getCloffReqRcdNm());// set [청약철회요청결과코드명]
		bzCntcInfoTarget.setBzCntcTeleRcd(bzCntcInfoSource.getBzCntcTeleRcd());// set [업무연락통화결과코드]
		bzCntcInfoTarget.setBzCntcTeleRcdNm(bzCntcInfoSource.getBzCntcTeleRcdNm());// set [업무연락통화결과코드명]
		bzCntcInfoTarget.setReceOrgUntCd(bzCntcInfoSource.getReceOrgUntCd());// set [수신조직단위코드]
		bzCntcInfoTarget.setThdyCloffRcYn(bzCntcInfoSource.getThdyCloffRcYn());// set [당일청약철회접수건여부]
		bzCntcInfoTarget.setContrRrno(bzCntcInfoSource.getContrRrno());// set [계약자고객주민번호]
		bzCntcInfoTarget.setContrNm(bzCntcInfoSource.getContrNm());// set [계약자명]
		SecuUtil.doEncObject(bzCntcInfoTarget); // 인터페이스는 암호화한다
		output.setBzCntcInfo(bzCntcInfoTarget);

		// 업무연락이력정보 조회
		CMZI10SVC05Sub2 bzCntcHistInfoTarget = new CMZI10SVC05Sub2();
		bzCntcHistInfoTarget.setBzCntcMgntNo(bzCntcHistInfoSource.getBzCntcMgntNo());// set [업무연락관리번호]
		bzCntcHistInfoTarget.setReceOrgUntCd(bzCntcHistInfoSource.getReceOrgUntCd());// set [수신조직단위코드]
		bzCntcHistInfoTarget.setReceOrgNo(bzCntcHistInfoSource.getReceOrgNo());// set [수신조직번호]
		bzCntcHistInfoTarget.setReceOrgNm(bzCntcHistInfoSource.getReceOrgNm());// set [수신조직명]
		bzCntcHistInfoTarget.setReceChrgpEno(bzCntcHistInfoSource.getReceChrgpEno());// set [수신담당자사원번호]
		bzCntcHistInfoTarget.setReceChrgpNm(bzCntcHistInfoSource.getReceChrgpNm());// set [수신담당자사원명]
		bzCntcHistInfoTarget.setBzCntcRplyCtnt(bzCntcHistInfoSource.getBzCntcRplyCtnt());// set [업무연락회신내용]
		bzCntcHistInfoTarget.setBzCntcRplyCtntPrev(bzCntcHistInfoSource.getBzCntcRplyCtntPrev());// set [이전업무연락회신내용]
		SecuUtil.doEncObject(bzCntcHistInfoTarget); // 인터페이스는 암호화한다
		output.setBzCntcHistInfo(bzCntcHistInfoTarget);
		
		// 저장된 업무연락계약 조회
		List<CMZI10SVC05Sub3> contInfoListTarget = new ArrayList<CMZI10SVC05Sub3>();
		if (contInfoListSource != null && contInfoListSource.size() > 0) {
			for (TBCMETC012Io contInfoSource : contInfoListSource) {
				// 계약번호가 없는 계약이 있다면 업무연락정보에 계약자 정보 세팅
				if (StringUtils.isEmpty(contInfoSource.getContNo())) {
					bzCntcInfoTarget.setContrRrno(contInfoSource.getContrRrno());// set [계약자주민번호]
					bzCntcInfoTarget.setContrNm(contInfoSource.getContrNm());// set [계약자명]
				} else {
					CMZI10SVC05Sub3 contInfoTarget = new CMZI10SVC05Sub3();
					contInfoTarget.setBzCntcMgntNo(contInfoSource.getBzCntcMgntNo());// set [업무연락관리번호]
					contInfoTarget.setSeq(contInfoSource.getSeq());// set [순번]
					contInfoTarget.setContNo(contInfoSource.getContNo());// set [계약번호]
					contInfoTarget.setPrdcd(contInfoSource.getPrdcd());// set [상품코드]
					contInfoTarget.setPrdnm(contInfoSource.getPrdnm());// set [상품명]
					contInfoTarget.setContrRrno(contInfoSource.getContrRrno());// set [계약자주민번호]
					contInfoTarget.setContrNm(contInfoSource.getContrNm());// set [계약자명]
					contInfoTarget.setInsdRrno(contInfoSource.getInsdRrno());// set [피보험자주민번호]
					contInfoTarget.setInsdNm(contInfoSource.getInsdNm());// set [피보험자명]
					contInfoTarget.setContDt(contInfoSource.getContDt());// set [계약일자]
					contInfoTarget.setContStcd(contInfoSource.getContStcd());// set [계약상태코드]
					contInfoTarget.setContStcdNm(contInfoSource.getContStcdNm());// set [계약상태코드명]
					contInfoListTarget.add(contInfoTarget);
				}
			}
		}
		SecuUtil.doEncList(contInfoListTarget); // 인터페이스는 암호화한다
		
		// 대표고객명조회
		if (!CollectionUtils.isEmpty(contInfoListTarget)) {
			CMZI10SVC05Sub3 cmzi10svc05Sub3 = contInfoListTarget.get(0);
			bzCntcInfoTarget.setContrRrno(cmzi10svc05Sub3.getContrRrno());// set [계약자고객주민번호]
			bzCntcInfoTarget.setContrNm(cmzi10svc05Sub3.getContrNm());// set [계약자명]
		}
		
		output.setContInfoList(contInfoListTarget);
		
		return output;
	}
	
	/**
	 * 업무연락 입력
	 * 
	 * @param  CMZ010SVC00In 업무저장정보
	 * @return String 업무연락관리번호
	 * @throws ApplicationException
	 */
	public String modifyBzCntc(CMZI10SVC03In input) throws ApplicationException {
		
		String bzCntcMgntNo = null;
		CMZ010SVC01In cmz010svc01in = new CMZ010SVC01In();
		
		// 업무유형
		TBCMETC010Io bzCntcInfo = new TBCMETC010Io(); // 업무유형
		bzCntcInfo.setBzCntcMgntNo(input.getBzCntcMgntNo()); // 업무연락관리번호
		bzCntcInfo.setBzCntcTypId1(input.getBzCntcTypId1()); // 업무연락유형ID1
		bzCntcInfo.setBzCntcTypId2(input.getBzCntcTypId2()); // 업무연락유형ID2
		bzCntcInfo.setEmerDcd(input.getEmerDcd()); // 긴급구분코드
		bzCntcInfo.setRcDt(input.getRcDt()); // 접수일자
		bzCntcInfo.setRcTi(input.getRcTi()); // 접수시각
		bzCntcInfo.setReceOrgUntCd(input.getReceOrgUntCd()); // 수신조직단위코드
		bzCntcInfo.setApplDofOrgNo(input.getApplDofOrgNo()); // 신청지점조직번호
		bzCntcInfo.setApplOrgNo(input.getApplOrgNo()); // 신청조직번호
		bzCntcInfo.setApplEno(input.getApplEno()); // 신청사원번호
		bzCntcInfo.setReceHqOrgNo(input.getReceHqOrgNo()); // 수신본부조직번호
		bzCntcInfo.setReceDofOrgNo(input.getReceDofOrgNo()); // 수신지점조직번호
		bzCntcInfo.setReceOrgNo(input.getReceOrgNo()); // 수신조직번호
		bzCntcInfo.setFstReceChrgpEno(input.getFstReceChrgpEno()); // 최초수신담당자사원번호
		bzCntcInfo.setBzCntcReqCtnt(input.getBzCntcReqCtnt()); // 업무연락요청내용
		bzCntcInfo.setBzCntcProgStcd(input.getBzCntcProgStcd()); // 업무연락진행상태코드
		bzCntcInfo.setCloffReqRcd(input.getCloffReqRcd()); // 청약철회요청결과코드
		bzCntcInfo.setBzCntcTeleRcd(input.getBzCntcTeleRcd()); // 청약철회요청결과코드
		bzCntcInfo.setRplyNeedYn("N"); // 회신필요여부
		bzCntcInfo.setDelYn("N"); // 삭제여부
		String custDscNo = StringUtils.nvl(input.getContrRrno(), input.getInsdRrno());
		if (!StringUtils.isEmpty(custDscNo)) {
			custDscNo = SecuUtil.getEncValue(custDscNo, SecuUtil.EncType.Jumin);
		}
		bzCntcInfo.setCustDscNo(custDscNo);
		cmz010svc01in.setBzCntcInfo(bzCntcInfo);
		
		// 업무유형이력
		TBCMETC011Io bzCntcHistInfo = new TBCMETC011Io(); // 업무유형이력
		
		bzCntcHistInfo.setBzCntcMgntNo(input.getBzCntcMgntNo()); // 업무연락관리번호
		bzCntcHistInfo.setReceOrgUntCd(input.getReceOrgUntCd()); // 수신조직단위코드
		bzCntcHistInfo.setReceOrgNo(input.getReceOrgNo()); // 수신조직번호
		bzCntcHistInfo.setReceChrgpEno(input.getFstReceChrgpEno()); // 신담당자사원번호
		bzCntcHistInfo.setBzCntcRplyCtnt(input.getBzCntcRplyCtnt()); // 업무연락회신내용
		bzCntcHistInfo.setDelYn("N"); // 삭제여부
		cmz010svc01in.setBzCntcHistInfo(bzCntcHistInfo);
		
		// 계약사항
		if (!CollectionUtils.isEmpty(input.getContNoList())) {
			// contNo 다수건 조합
			StringBuffer contNoSB = new StringBuffer();
			for (CMZI10SVC03Sub1 contNoInfo : input.getContNoList()) {
				if (contNoSB.length() > 0) {
					contNoSB.append(",");
				}
				contNoSB.append(contNoInfo.getContNo());
			}
			
			if (contNoSB.length() > 0) {
				// 계약번호가 있다면 계약조회
				List<TBCMETC012Io> contInfoInq = cmz010bean.getContInfoInq(null, null, contNoSB.toString());
				if (contInfoInq != null && contInfoInq.size() > 0) {
					for (TBCMETC012Io contInfo : contInfoInq) {
						contInfo.setDelYn("N"); // 삭제여부
						contInfo.setBzCntcMgntNo(input.getBzCntcMgntNo()); // 업무연락관리번호
						
						if (!StringUtils.isEmpty(input.getContrRrno())) {
							String custNo = cmz010dbio.selectOneTBCSPRF001(SecuUtil.getEncValue(input.getContrRrno(), SecuUtil.EncType.Jumin));
							contInfo.setContrCustNo(custNo);
						}
						if (!StringUtils.isEmpty(input.getInsdRrno())) {
							String custNo = cmz010dbio.selectOneTBCSPRF001(SecuUtil.getEncValue(input.getInsdRrno(), SecuUtil.EncType.Jumin));
							contInfo.setInsdCustNo(custNo);
						}
					}
					cmz010svc01in.setContInfoList(contInfoInq);
				}
			}
		}
		
		/* 계약번호가 없다면 입력안함.양윤철 2017.01.25
		else {
			// 계약자 또는 피보험자 주민번호가 있다면 해당 고객번호만 입력 
			List<TBCMETC012Io> contInfoList = new ArrayList<TBCMETC012Io>(); // 계약사항
			TBCMETC012Io contInfo = new TBCMETC012Io();
			contInfo.setBzCntcMgntNo(input.getBzCntcMgntNo()); // 업무연락관리번호
			if (!StringUtils.isEmpty(input.getContrRrno())) {
				String custNo = cmz010dbio.selectOneTBCSPRF001(SecuUtil.getEncValue(input.getContrRrno(), SecuUtil.EncType.Jumin));
				contInfo.setContrCustNo(custNo);
			}
			if (!StringUtils.isEmpty(input.getInsdRrno())) {
				String custNo = cmz010dbio.selectOneTBCSPRF001(SecuUtil.getEncValue(input.getInsdRrno(), SecuUtil.EncType.Jumin));
				contInfo.setInsdCustNo(custNo);
			}
			
			if (!StringUtils.isEmpty(contInfo.getContrCustNo())) {
				contInfo.setDelYn("N"); // 삭제여부
				contInfoList.add(contInfo);
				cmz010svc01in.setContInfoList(contInfoList);
			}
		}
		*/
		if ("I".equals(input.getBzPrcsDvsn())) {
			// I.인서트
			bzCntcMgntNo = cmz010bean.insertBzCntcList(cmz010svc01in);
		} else if ("U".equals(input.getBzPrcsDvsn())) {
			// U.업데이트
			bzCntcMgntNo = cmz010bean.updateBzCntcList(cmz010svc01in);
		}
		
		return bzCntcMgntNo;
	}
	
	/**
	 * 예약콜 전송
	 * 
	 * @param  CMZ010SVC03In 예약콜 전송정보
	 * @throws ApplicationException
	 */
	public void rsvtCallTrms(CMZ010SVC03In input) throws ApplicationException {	
		
		COMECOTOS000000001In callEAIInput = new COMECOTOS000000001In();
		
		ReflUtil.setObjData(input, callEAIInput);
		callEAIInput.setRrno     (SecuUtil.getEncValue(callEAIInput.getRrno(),      SecuUtil.EncType.Jumin));
		callEAIInput.setRsvtTelno(SecuUtil.getEncValue(callEAIInput.getRsvtTelno(), SecuUtil.EncType.Contact));
		
		//logger.debug("rsvtCallTrms {}", callEAIInput);
		
		try{
			String interfaceId = "COM_E_COTOS000000001"; //업무연락알림 
			//EISResponse<COMECOTOS000000001Out> response = null;
			
			InfUtil.callEAI(callEAIInput, interfaceId, "CC", "CCD103SVC", "changeInsert0", FwUtil.getDeptCd(), FwUtil.getUserId(), COMECOTOS000000001Out.class);
			
		} catch (EisExecutionException e) {
			logger.error("EAI송수신에러_EisExecutionException :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
			
		} catch (NotSupportedEISException e) {
			logger.error("EAI송수신에러_NotSupportedEISException :: ",e);
			throw new ApplicationException("APSLE9022", new String[]{"EAI송수신에러"});
		}
		
	}
	
}
