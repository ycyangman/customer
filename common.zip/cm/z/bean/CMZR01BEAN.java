package cigna.cm.z.bean;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.dbio.CMZR01DBIO;
import cigna.cm.z.io.CMZR01SVC00In;
import cigna.cm.z.io.CMZR01SVC01In;
import cigna.cm.z.io.CMZR01SVC02In;
import cigna.cm.z.io.TBCMCCD045Io;
import cigna.cm.z.io.TBCMCCD046Io;
import cigna.zz.FwUtil;


/**
 * @file         cigna.cm.z.bean.CMZR01BEAN.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2016. 11. 14.       신규 작성
 *
 */
@KlafBean
public class CMZR01BEAN {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZR01DBIO cmzr01dbio;
	
	public List<TBCMCCD046Io> getBtnInfoList(CMZR01SVC00In input) throws ApplicationException {
		
		List<TBCMCCD046Io> btnInfoList = null;
		
		String userId = FwUtil.getUserId();
		String scrnId = input.getScrnId();
		String itRoleCd = input.getItRoleCd();
		
		if(StringUtils.isEmpty(userId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "사용자ID" } );
		}
		
		if(StringUtils.isEmpty(scrnId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "화면ID" } );
		}
		
		if(StringUtils.isEmpty(itRoleCd)) {
			return btnInfoList;
		}

		btnInfoList = cmzr01dbio.selectMultiTBCMCCD046a(userId, scrnId, itRoleCd);
		
		return btnInfoList;
	}
	
	public List<TBCMCCD046Io> getItRoleList(CMZR01SVC01In input) throws ApplicationException {
		
		List<TBCMCCD046Io> itRoleList = null;

		String userId = FwUtil.getUserId();
		String scrnId = input.getScrnId();
		
		if(StringUtils.isEmpty(userId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "사용자ID" } );
		}
		
		if(StringUtils.isEmpty(scrnId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "화면ID" } );
		}

		itRoleList = cmzr01dbio.selectMultiTBCMCCD046b(userId, scrnId);
		
		//ALL
		if(itRoleList == null || itRoleList.size() == 0){
			TBCMCCD046Io tempRoleInfo = new TBCMCCD046Io();
			tempRoleInfo.setItRoleCd("ALL");
			tempRoleInfo.setItRoleNm("ALL");
			itRoleList.add(tempRoleInfo);
		}
		
		return itRoleList;
	}
	
	public TBCMCCD045Io getAuthInfo(CMZR01SVC01In input) throws ApplicationException {

		TBCMCCD045Io authInfo = null;

		String userId = FwUtil.getUserId();
		String scrnId = input.getScrnId();
		
		if(StringUtils.isEmpty(userId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "사용자ID" } );
		}
		
		if(StringUtils.isEmpty(scrnId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "화면ID" } );
		}

		authInfo = cmzr01dbio.selectOneTBCMCCD045(userId, scrnId);
		
		return authInfo;
	}
	
	
	
	public int modifyAuthInfo(CMZR01SVC02In input) throws ApplicationException {
		
		String userId = FwUtil.getUserId();//최종변경자ID(LAST_CHGR_ID) 설정
		String pgmId = FwUtil.getPgmId();// 최종변경프로그램ID(LAST_CHG_PGM_ID) 설정
		String trmNo = FwUtil.getTrmNo();// 최종변경단말번호(LAST_CHG_TRM_NO) 설정
		
		if(StringUtils.isEmpty(userId)) {
			throw new ApplicationException( "APCME0005", new Object[]{ "사용자ID" } );
		}
		
		int inCnt = 0;
		TBCMCCD045Io authIfo = input.getAuthIfo();
		
		authIfo.setLastChgrId(userId);
		authIfo.setLastChgPgmId(pgmId);
		authIfo.setLastChgTrmNo(trmNo);
		
		inCnt = cmzr01dbio.mergeOneTBCMCCD045(authIfo);
		if(inCnt > 0){
			cmzr01dbio.deleteMultiTBCMCCD046(authIfo);
			
			List<TBCMCCD046Io> putBtnList = input.getPutBtnList();
			
			if(putBtnList != null){
				for(TBCMCCD046Io btnInfo:putBtnList){
					
					btnInfo.setLastChgrId(userId);
					btnInfo.setLastChgPgmId(pgmId);
					btnInfo.setLastChgTrmNo(trmNo);
					
					cmzr01dbio.insertOneTBCMCCD046(btnInfo);
					
					//변경적용여부=Y 경우 EAM데이터 직접 수정
					if(!"ALL".equals(authIfo.getItRoleCd()) && "Y".equals(authIfo.getChgYn())){

						String scrnSubId = StringUtils.nvl(btnInfo.getScrnSubId(), "");
						String butnId = StringUtils.nvl(btnInfo.getButnId(), "");
						String authYn = StringUtils.nvl(btnInfo.getAuthYn(), "");
						
						if(!scrnSubId.equals(butnId) && !authYn.equals(btnInfo.getChangeAuthYn())){
							
							if("Y".equals(btnInfo.getChangeAuthYn())){
								cmzr01dbio.mergeOneEI_ROLE_SCR_BUTN_RL(btnInfo);
							}else{
								cmzr01dbio.updateOneEI_ROLE_SCR_BUTN_RL(btnInfo);
							}
						}
					}
					
				}	
			}
		}
		return inCnt;
	}
}

