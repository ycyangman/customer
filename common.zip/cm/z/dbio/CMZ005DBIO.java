/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue Nov 22 18:23:11 KST 2016
 */
package cigna.cm.z.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/z/dbio/CMZ005DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMZ005DBIO
{

	/**
	 * @TestValues 	eno=;
	 */
	cigna.cm.z.io.CMZ005SVC01Out selectOneTBSLEMP114a(@Param("eno")
	java.lang.String eno);

	/**
	 * @TestValues 	eno=;	inlnNo=;	macAddr=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBSLEMP114(cigna.cm.z.io.TBSLEMP114Io tBSLEMP114Io);

	/**
	 * @TestValues 	eno=;	inlnNo=;	macAddr=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBSLEMP114(cigna.cm.z.io.TBSLEMP114Io tBSLEMP114Io);

	/**
	 * 사원부가정보 저장
	 * @TestValues 	eno=1500528000;	inlnNo=1234;	macAddr=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int mergeOneTBSLEMP114(cigna.cm.z.io.TBSLEMP114Io tBSLEMP114Io);
}