/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Fri May 19 10:25:05 KST 2017
 */
package cigna.cm.z.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/z/dbio/CMZ010DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMZ010DBIO
{

	/**
	 * 업무연락유형조회
	 * @TestValues 	bzCntcTypId=;	bzCntcTypNm=정정;	receOrgNo=;	receChrgpEno=;	userYn=;	delYn=;	pageNum=1;	pageCount=9999;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC009Io> selectMultiTBCMETC009a(
			@Param("bzCntcTypId")
			java.lang.String bzCntcTypId, @Param("bzCntcTypNm")
			java.lang.String bzCntcTypNm, @Param("receOrgNo")
			java.lang.String receOrgNo, @Param("receChrgpEno")
			java.lang.String receChrgpEno, @Param("userYn")
			java.lang.String userYn, @Param("delYn")
			java.lang.String delYn, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);

	/**
	 * @TestValues 	bzCntcType.bzCntcTypId1=1;	bzCntcType.bzCntcTypId2=1;	bzCntcType.seq=1;	bzCntcType.bzCntcTypNm1=1;	bzCntcType.bzCntcTypNm2=1;	bzCntcType.dtlCtnt=1;	bzCntcType.applOrgNo=1;	bzCntcType.applOrgNm=;	bzCntcType.bzprtCd=1;	bzCntcType.receHqOrgNo=1;	bzCntcType.receDofOrgNo=1;	bzCntcType.receOrgNo=1;	bzCntcType.receOrgNm=;	bzCntcType.receChrgpEno=1;	bzCntcType.receChrgpNm=;	bzCntcType.useYn=1;	bzCntcType.fstCrtDtm=;	bzCntcType.fstCrtDtmStr=;	bzCntcType.fstCrtrId=1;	bzCntcType.delYn=1;	bzCntcType.lastChgDtm=;	bzCntcType.lastChgrId=1;	bzCntcType.lastChgPgmId=1;	bzCntcType.lastChgTrmNo=1;	bzCntcType.bzCntcMgntNo=;	bzCntcType.chkYn=;	bzCntcType.flgCd=;
	 */
	int mergeOneTBCMETC009(@Param("bzCntcType")
	cigna.cm.z.io.TBCMETC009Io bzCntcType);

	/**
	 * 업무유형중복조회
	 * @TestValues 	bzCntcTypId1=R01;	bzCntcTypId2=S01;
	 */
	cigna.cm.z.io.TBCMETC009Io selectOneTBCMETC009a(@Param("bzCntcTypId1")
	java.lang.String bzCntcTypId1, @Param("bzCntcTypId2")
	java.lang.String bzCntcTypId2);

	/**
	 * @TestValues 	bzCntcMgntNo=1;	bzCntcTypId1=11;	bzCntcTypNm1=;	bzCntcTypId2=22;	bzCntcTypNm2=;	emerDcd=01;	emerDcdNm=;	rcDt=2;	rcTi=3;	rcDtm=;	receOrgUntCd=1;	receOrgUntNm=;	applDofOrgNo=;	applOrgNo=4;	applOrgNm=;	applEno=5;	applNm=;	bzprtCd=6;	receHqOrgNo=7;	receDofOrgNo=8;	receOrgNo=9;	receOrgNm=;	fstReceChrgpEno=1;	fstReceChrgpNm=;	contNo=;	contrCustNo=;	contrRrno=;	contrNm=;	insdCustNo=;	insdRrno=;	insdNm=;	bzCntcHopeDt=4;	rplyNeedYn=5;	cmptDt=6;	cmptTi=7;	cmptDtm=;	tat=;	bzCntcProgStcd=8;	bzCntcProgStNm=;	bzCntcReqCtnt=9;	cloffReqRcd=;	cloffReqRcdNm=;	bzCntcTeleRcd=;	bzCntcTeleRcdNm=;	rfEno=;	rfNm=;	fileMgntNo=;	custDcd=;	custDscNo=;	custNm=;	custRfDscNo=;	custRfNm=;	slctPlnrEno=;	thdyCloffRcYn=;	fstCrtDtm=;	fstCrtrId=1;	delYn=1;	lastChgDtm=;	lastChgrId=2;	lastChgPgmId=3;	lastChgTrmNo=4;
	 */
	int insertOneTBCMETC010(cigna.cm.z.io.TBCMETC010Io tBCMETC010Io);

	/**
	 * @TestValues 	bzCntcMgntNo=1;	bzCntcTypId1=11;	bzCntcTypNm1=;	bzCntcTypId2=22;	bzCntcTypNm2=;	emerDcd=01;	emerDcdNm=;	rcDt=3;	rcTi=4;	rcDtm=;	receOrgUntCd=;	receOrgUntNm=;	applDofOrgNo=;	applOrgNo=5;	applOrgNm=;	applEno=6;	applNm=;	bzprtCd=7;	receHqOrgNo=8;	receDofOrgNo=9;	receOrgNo=1;	receOrgNm=;	fstReceChrgpEno=1;	fstReceChrgpNm=;	contNo=;	contrCustNo=;	contrRrno=;	contrNm=;	insdCustNo=;	insdRrno=;	insdNm=;	bzCntcHopeDt=5;	rplyNeedYn=6;	cmptDt=7;	cmptTi=8;	cmptDtm=;	tat=;	bzCntcProgStcd=9;	bzCntcProgStNm=;	bzCntcReqCtnt=1;	cloffReqRcd=;	cloffReqRcdNm=;	bzCntcTeleRcd=;	bzCntcTeleRcdNm=;	rfEno=;	rfNm=;	fileMgntNo=;	custDcd=;	custDscNo=;	custNm=;	custRfDscNo=;	custRfNm=;	slctPlnrEno=;	thdyCloffRcYn=;	fstCrtDtm=;	fstCrtrId=;	delYn=1;	lastChgDtm=;	lastChgrId=2;	lastChgPgmId=3;	lastChgTrmNo=4;
	 */
	int updateOneTBCMETC010(cigna.cm.z.io.TBCMETC010Io tBCMETC010Io);

	java.lang.String selectOneTBCMETC010b();

	/**
	 * @TestValues 	bzCntcMgntNo=1;	seq=;	maxSeq=;	receOrgUntCd=;	receOrgNo=2;	receOrgNm=;	receChrgpEno=3;	receChrgpNm=;	bzCntcRplyCtnt=4;	bzCntcRplyCtntPrev=;	receDtm=;	prcsYn=;	prcsDtm=;	prcsrNm=;	rcDt=;	fstCrtDtm=;	fstCrtrId=5;	delYn=6;	lastChgDtm=;	lastChgrId=7;	lastChgPgmId=8;	lastChgTrmNo=9;
	 */
	int insertOneTBCMETC011(cigna.cm.z.io.TBCMETC011Io tBCMETC011Io);

	/**
	 * @TestValues 	bzCntcMgntNo=1;	seq=2;	maxSeq=;	receOrgUntCd=;	receOrgNo=;	receOrgNm=;	receChrgpEno=;	receChrgpNm=;	bzCntcRplyCtnt=;	bzCntcRplyCtntPrev=;	receDtm=;	prcsYn=;	prcsDtm=;	prcsrNm=;	rcDt=;	fstCrtDtm=;	fstCrtrId=;	delYn=6;	lastChgDtm=;	lastChgrId=7;	lastChgPgmId=8;	lastChgTrmNo=9;
	 */
	int updateOneTBCMETC011(cigna.cm.z.io.TBCMETC011Io tBCMETC011Io);

	/**
	 * @TestValues 	bzCntcMgntNo=TSWE161009720170331113528;
	 */
	cigna.cm.z.io.TBCMETC010Io selectOneTBCMETC010a(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo);

	/**
	 * @TestValues 	bzCntcMgntNo=000000000000001;
	 */
	cigna.cm.z.io.TBCMETC011Io selectOneTBCMETC011a(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo);

	/**
	 * @TestValues 	bzCntcMgntNo=000000000000042;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC011Io> selectMultiTBCMETC011a(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo);

	/**
	 * 업무연락현황조회
	 * @TestValues 	bzCntcMgntNo=;	bzCntcTypNm1=;	bzCntcTypNm2=;	receOrgNo=;	applEno=;	rfEno=;	fstReceChrgpEno=;	bzCntcProgStcd=;	contNo=1111;	custRfDscNo=;	custNo=;	calDtFrom=20170101;	calDtTo=20170123;	pageNum=1;	pageCount=20;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC010Io> selectMultiTBCMETC010a(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo, @Param("bzCntcTypNm1")
			java.lang.String bzCntcTypNm1, @Param("bzCntcTypNm2")
			java.lang.String bzCntcTypNm2, @Param("receOrgNo")
			java.lang.String receOrgNo, @Param("applEno")
			java.lang.String applEno, @Param("rfEno")
			java.lang.String rfEno, @Param("fstReceChrgpEno")
			java.lang.String fstReceChrgpEno, @Param("bzCntcProgStcd")
			java.lang.String bzCntcProgStcd, @Param("contNo")
			java.lang.String contNo, @Param("custRfDscNo")
			java.lang.String custRfDscNo, @Param("custNo")
			java.lang.String custNo, @Param("calDtFrom")
			java.lang.String calDtFrom, @Param("calDtTo")
			java.lang.String calDtTo, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);

	/**
	 * @TestValues 	contrCustNo=;	pinsdCustNo=;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC012Io> selectMultiTBCNBAS001a(
			@Param("contrCustNo")
			java.lang.String contrCustNo, @Param("pinsdCustNo")
			java.lang.String pinsdCustNo, @Param("contNoList")
			java.util.List contNoList);

	/**
	 * @TestValues 	strCustDscNo=;
	 */
	java.lang.String selectOneTBCSPRF001(
			@Param("strCustDscNo")
			java.lang.String strCustDscNo);

	/**
	 * @TestValues 	chkYn=;	bzCntcMgntNo=1;	seq=;	delYn=1;	prpsNo=;	contNo=1;	prdcd=;	prdnm=;	contrCustNo=1;	contrRrno=;	contrNm=;	insdCustNo=1;	insdRrno=;	insdNm=;	pmpsCustNo=;	pmpsNm=;	contDt=;	contStcd=;	contStcdNm=;	cstaDtlCd=;	sprm=;	clmnPlnrEno=;	emplNm=;	plnrEno=;	lastPmMnth=;	lastChgDtm=;	lastChgrId=2;	lastChgPgmId=2;	lastChgTrmNo=2;
	 */
	int insertOneTBCMETC012(cigna.cm.z.io.TBCMETC012Io tBCMETC012Io);

	/**
	 * @TestValues 	bzCntcMgntNo=1;
	 */
	int deleteMultiTBCMETC012(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo);

	/**
	 * @TestValues 	bzCntcMgntNo=PMQ13320161230184058;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC012Io> selectMultiTBCMETC012a(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo);

	/**
	 * 업무연락현황조회
	 * @TestValues 	bzCntcMgntNo=;	bzCntcTypNm1=;	bzCntcTypNm2=;	receOrgNo=;	applEno=;	rfEno=;	fstReceChrgpEno=;	bzCntcProgStcd=;	contNo=6279860879;	insdContrDcd=;	custRfDscNo=1;	custNo=011254975;	custRrno=8404301234567;	calDtFrom=20160901;	calDtTo=20161231;	pageNum=1;	pageCount=20;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC010Io> selectMultiTBCMETC010b(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo, @Param("bzCntcTypNm1")
			java.lang.String bzCntcTypNm1, @Param("bzCntcTypNm2")
			java.lang.String bzCntcTypNm2, @Param("receOrgNo")
			java.lang.String receOrgNo, @Param("applEno")
			java.lang.String applEno, @Param("rfEno")
			java.lang.String rfEno, @Param("fstReceChrgpEno")
			java.lang.String fstReceChrgpEno, @Param("bzCntcProgStcd")
			java.lang.String bzCntcProgStcd, @Param("contNo")
			java.lang.String contNo, @Param("insdContrDcd")
			java.lang.String insdContrDcd, @Param("custRfDscNo")
			java.lang.String custRfDscNo, @Param("custNo")
			java.lang.String custNo, @Param("custRrno")
			java.lang.String custRrno, @Param("calDtFrom")
			java.lang.String calDtFrom, @Param("calDtTo")
			java.lang.String calDtTo, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);

	java.lang.String selectOneTBCMETC009b();

	/**
	 * @TestValues 	custNo=;
	 */
	java.lang.String selectOneTBCSPRF001b(@Param("custNo")
	java.lang.String custNo);

	/**
	 * @TestValues 	bzCntcMgntNo=;	seq=;	maxSeq=;	receOrgUntCd=;	receOrgNo=;	receOrgNm=;	receChrgpEno=;	receChrgpNm=;	bzCntcRplyCtnt=;	bzCntcRplyCtntPrev=;	receDtm=;	prcsYn=;	prcsDtm=;	prcsrNm=;	rcDt=;	fstCrtDtm=;	fstCrtrId=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMETC011b(cigna.cm.z.io.TBCMETC011Io tBCMETC011Io);

	/**
	 * 업무연락현황조회(수신자정보)
	 * @TestValues 	bzCntcMgntNo=;	bzCntcTypNm1=;	bzCntcTypNm2=;	receOrgNo=;	applEno=;	rfEno=;	fstReceChrgpEno=D110625;	bzCntcProgStcd=;	contNo=;	custRfDscNo=;	custNo=;	calDtFrom=20170401;	calDtTo=20170424;	pageNum=1;	pageCount=50;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC010Io> selectMultiTBCMETC010c(@Param("bzCntcMgntNo")
	java.lang.String bzCntcMgntNo, @Param("bzCntcTypNm1")
	java.lang.String bzCntcTypNm1, @Param("bzCntcTypNm2")
	java.lang.String bzCntcTypNm2, @Param("receOrgNo")
	java.lang.String receOrgNo, @Param("applEno")
	java.lang.String applEno, @Param("rfEno")
	java.lang.String rfEno, @Param("fstReceChrgpEno")
	java.lang.String fstReceChrgpEno, @Param("bzCntcProgStcd")
	java.lang.String bzCntcProgStcd, @Param("contNo")
	java.lang.String contNo, @Param("custRfDscNo")
	java.lang.String custRfDscNo, @Param("custNo")
	java.lang.String custNo, @Param("calDtFrom")
	java.lang.String calDtFrom, @Param("calDtTo")
	java.lang.String calDtTo, @Param("pageNum")
	java.lang.Integer pageNum, @Param("pageCount")
	java.lang.Integer pageCount);

	/**
	 * @TestValues 	bzCntcMgntNo=000000000000014;	receOrgNo=;	receChrgpEno=T00000020N;	receDtm=;
	 */
	cigna.cm.z.io.TBCMETC011Io selectOneTBCMETC011b(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo, @Param("receOrgNo")
			java.lang.String receOrgNo, @Param("receChrgpEno")
			java.lang.String receChrgpEno, @Param("receDtm")
			java.lang.String receDtm);

	/**
	 * @TestValues 	bzCntcMgntNo=;	bzCntcProgStcd=;	fstReceChrgpEno=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneTBCMETC010a(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo, @Param("bzCntcProgStcd")
			java.lang.String bzCntcProgStcd, @Param("fstReceChrgpEno")
			java.lang.String fstReceChrgpEno, @Param("lastChgrId")
			java.lang.String lastChgrId, @Param("lastChgPgmId")
			java.lang.String lastChgPgmId, @Param("lastChgTrmNo")
			java.lang.String lastChgTrmNo);

	/**
	 * @TestValues 	contNo=;	strtDt=;
	 */
	java.lang.Integer selectOneTBCMETC012a(
			@Param("contNo")
			java.lang.String contNo, @Param("strtDt")
			java.lang.String strtDt);

	/**
	 * @TestValues 	custNo=001961477;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC012Io> selectMultiTBCNBAS001b(@Param("custNo")
	java.lang.String custNo);

	/**
	 * @TestValues 	fileMgntNo=;
	 */
	java.util.List<cigna.cm.z.io.CMZ010SVC03Sub> selectMultiTBCMCCD017a(
			@Param("fileMgntNo")
			java.lang.String fileMgntNo);

	/**
	 * @TestValues 	bzCntcMgntNo=1;	seq=2;	maxSeq=;	receOrgUntCd=;	receOrgNo=;	receOrgNm=;	receChrgpEno=;	receChrgpNm=;	bzCntcRplyCtnt=;	bzCntcRplyCtntPrev=;	receDtm=;	prcsYn=;	prcsDtm=;	prcsrNm=;	rcDt=;	fstCrtDtm=;	fstCrtrId=;	delYn=6;	lastChgDtm=;	lastChgrId=7;	lastChgPgmId=8;	lastChgTrmNo=9;
	 */
	int updateOneTBCMETC011c(cigna.cm.z.io.TBCMETC011Io tBCMETC011Io);

	/**
	 * @TestValues 	bzCntcMgntNo=;	bzCntcTypNm1=;	bzCntcTypNm2=;	receOrgNo=810300;	applEno=;	rfEno=;	fstReceChrgpEno=;	bzCntcProgStcd=;	contNo=;	custRfDscNo=;	custNo=;	calDtFrom=20160201;	calDtTo=20160222;	pageNum=1;	pageCount=100;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC010Io> selectMultiTBCMETC010d(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo, @Param("bzCntcTypNm1")
			java.lang.String bzCntcTypNm1, @Param("bzCntcTypNm2")
			java.lang.String bzCntcTypNm2, @Param("receOrgNo")
			java.lang.String receOrgNo, @Param("applEno")
			java.lang.String applEno, @Param("rfEno")
			java.lang.String rfEno, @Param("fstReceChrgpEno")
			java.lang.String fstReceChrgpEno, @Param("bzCntcProgStcd")
			java.lang.String bzCntcProgStcd, @Param("contNo")
			java.lang.String contNo, @Param("custRfDscNo")
			java.lang.String custRfDscNo, @Param("custNo")
			java.lang.String custNo, @Param("calDtFrom")
			java.lang.String calDtFrom, @Param("calDtTo")
			java.lang.String calDtTo, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);

	/**
	 * @TestValues 	bzCntcMgntNo=20170222000000000003;	receOrgNo=190031;	receChrgpEno=1500364000;
	 */
	cigna.cm.z.io.TBCMETC011Io selectOneTBCMETC011c(
			@Param("bzCntcMgntNo")
			java.lang.String bzCntcMgntNo, @Param("receOrgNo")
			java.lang.String receOrgNo, @Param("receChrgpEno")
			java.lang.String receChrgpEno);

	/**
	 * 업무연락유형조회 이름순 정렬
	 * @TestValues 	bzCntcTypId=;	bzCntcTypNm=정정;	receOrgNo=;	receChrgpEno=;	userYn=;	delYn=;	pageNum=1;	pageCount=99;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC009Io> selectMultiTBCMETC009b(
			@Param("bzCntcTypId")
			java.lang.String bzCntcTypId, @Param("bzCntcTypNm")
			java.lang.String bzCntcTypNm, @Param("receOrgNo")
			java.lang.String receOrgNo, @Param("receChrgpEno")
			java.lang.String receChrgpEno, @Param("userYn")
			java.lang.String userYn, @Param("delYn")
			java.lang.String delYn, @Param("pageNum")
			java.lang.Integer pageNum, @Param("pageCount")
			java.lang.Integer pageCount);
}