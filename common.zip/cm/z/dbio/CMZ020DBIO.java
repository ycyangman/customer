/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Wed May 24 16:56:42 KST 2017
 */
package cigna.cm.z.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/z/dbio/CMZ020DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMZ020DBIO
{

	/**
	 * 업무연락유형조회(TM)
	 * @TestValues 	bzCntcTypId1=;	bzCntcTypId2=;	userYn=Y;
	 */
	java.util.List<cigna.cm.z.io.CMZI10SVC02Sub1> selectMultiTBCMETC009a(
			@Param("bzCntcTypId1")
			java.lang.String bzCntcTypId1, @Param("bzCntcTypId2")
			java.lang.String bzCntcTypId2, @Param("userYn")
			java.lang.String userYn);

	/**
	 * 업무연락현황조회
	 * @TestValues 	medTypCd=;	applDofOrgNo=;	bzCntcTypId1=;	bzCntcTypId2=;	applOrgNo=;	receDofOrgNo=;	receOrgNo=;	applEno=;	fstReceChrgpEno=T0000002PD;	bzCntcProgStcd=;	custNo=;	rcStrtDt=20170401;	rcEndDt=20170517;	receStrtDt=;	receEndDt=;	cloffReqRcd=;	bzCntcTeleRcd=;	regpId=T0000002PD;	custRrno=;
	 */
	java.util.List<cigna.cm.z.io.CMZI10SVC04Sub1> selectMultiTBCMETC010a(
			@Param("medTypCd")
			java.lang.String medTypCd, @Param("applDofOrgNo")
			java.lang.String applDofOrgNo, @Param("bzCntcTypId1")
			java.lang.String bzCntcTypId1, @Param("bzCntcTypId2")
			java.lang.String bzCntcTypId2, @Param("applOrgNo")
			java.lang.String applOrgNo, @Param("receDofOrgNo")
			java.lang.String receDofOrgNo, @Param("receOrgNo")
			java.lang.String receOrgNo, @Param("applEno")
			java.lang.String applEno, @Param("fstReceChrgpEno")
			java.lang.String fstReceChrgpEno, @Param("bzCntcProgStcd")
			java.lang.String bzCntcProgStcd, @Param("custNo")
			java.lang.String custNo, @Param("rcStrtDt")
			java.lang.String rcStrtDt, @Param("rcEndDt")
			java.lang.String rcEndDt, @Param("receStrtDt")
			java.lang.String receStrtDt, @Param("receEndDt")
			java.lang.String receEndDt, @Param("cloffReqRcd")
			java.lang.String cloffReqRcd, @Param("bzCntcTeleRcd")
			java.lang.String bzCntcTeleRcd, @Param("regpId")
			java.lang.String regpId, @Param("custRrno")
			java.lang.String custRrno);

	/**
	 * 업무연락현황조회
	 * @TestValues 	medTypCd=;	applDofOrgNo=;	bzCntcTypId1=;	bzCntcTypId2=;	applOrgNo=;	receDofOrgNo=;	receOrgNo=;	applEno=;	fstReceChrgpEno=;	bzCntcProgStcd=;	custNo=99999999;	rcStrtDt=20160801;	rcEndDt=20160831;	receStrtDt=20160801;	receEndDt=20160831;	cloffReqRcd=;	bzCntcTeleRcd=;	regpId=;	custRrno=;
	 */
	java.util.List<cigna.cm.z.io.CMZI10SVC04Sub1> selectMultiTBCMETC010b(@Param("medTypCd")
	java.lang.String medTypCd, @Param("applDofOrgNo")
	java.lang.String applDofOrgNo, @Param("bzCntcTypId1")
	java.lang.String bzCntcTypId1, @Param("bzCntcTypId2")
	java.lang.String bzCntcTypId2, @Param("applOrgNo")
	java.lang.String applOrgNo, @Param("receDofOrgNo")
	java.lang.String receDofOrgNo, @Param("receOrgNo")
	java.lang.String receOrgNo, @Param("applEno")
	java.lang.String applEno, @Param("fstReceChrgpEno")
	java.lang.String fstReceChrgpEno, @Param("bzCntcProgStcd")
	java.lang.String bzCntcProgStcd, @Param("custNo")
	java.lang.String custNo, @Param("rcStrtDt")
	java.lang.String rcStrtDt, @Param("rcEndDt")
	java.lang.String rcEndDt, @Param("receStrtDt")
	java.lang.String receStrtDt, @Param("receEndDt")
	java.lang.String receEndDt, @Param("cloffReqRcd")
	java.lang.String cloffReqRcd, @Param("bzCntcTeleRcd")
	java.lang.String bzCntcTeleRcd, @Param("regpId")
	java.lang.String regpId, @Param("custRrno")
	java.lang.String custRrno);

	/**
	 * 업무현황알림
	 * @TestValues 	receChrgpEno=1009900089;	receOrgNo=;	rece_dtm=00010101000001;
	 */
	java.util.List<cigna.cm.z.io.CMZI10SVC04Sub1> selectMultiTBCMETC010c(@Param("receChrgpEno")
	java.lang.String receChrgpEno, @Param("receOrgNo")
	java.lang.String receOrgNo, @Param("rece_dtm")
	java.lang.String rece_dtm);

	/**
	 * 업무연락알람조회
	 * @TestValues 	receChrgpEno=1600073000;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC010Io> selectMultiTBCMETC011a(@Param("receChrgpEno")
	java.lang.String receChrgpEno);

	/**
	 * 업무연락조회_청약철회숙려 계약번호로 조회
	 * @TestValues 	contNo=34917E0058;	contrCustNo=005904931;
	 */
	cigna.cm.z.io.TBCMETC010Io selectOneTBCMETC010a(@Param("contNo")
	java.lang.String contNo, @Param("contrCustNo")
	java.lang.String contrCustNo);

	/**
	 * @TestValues 	contNo=3521411328;	contrCustNo=004184697;
	 */
	cigna.cm.z.io.TBCMETC010Io selectOneTBCMETC010b(@Param("contNo")
			java.lang.String contNo, @Param("contrCustNo")
			java.lang.String contrCustNo);

	/**
	 * @TestValues 	contNo=3521411328;	contrCustNo=004184697;
	 */
	java.util.List<cigna.cm.z.io.TBCMETC010Io> selectMultiTBCMETC012a(
			@Param("contNo")
			java.lang.String contNo, @Param("contrCustNo")
			java.lang.String contrCustNo);
}