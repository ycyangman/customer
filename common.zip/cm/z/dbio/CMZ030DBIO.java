/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Tue Mar 07 16:51:39 KST 2017
 */
package cigna.cm.z.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/z/dbio/CMZ030DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMZ030DBIO
{

	/**
	 * Work Request 처리 목록
	 * @TestValues 	usrId=1600151000;	bzReqNo=;	prcsStrDt=20160101;	prcsEndDt=20161231;	prcsrId=;	pageNum=1;	pageCount=10;
	 */
	java.util.List<cigna.cm.z.io.TBCMCCD047Io> selectMultiTBCMCCD047(@Param("usrId")
	java.lang.String usrId, @Param("bzReqNo")
	java.lang.String bzReqNo, @Param("prcsStrDt")
	java.lang.String prcsStrDt, @Param("prcsEndDt")
	java.lang.String prcsEndDt, @Param("prcsrId")
	java.lang.String prcsrId, @Param("pageNum")
	int pageNum, @Param("pageCount")
	int pageCount);

	/**
	 * Work Request 처리 파일 목록
	 * @TestValues 	bzReqNo=00000000000000000001;
	 */
	java.util.List<cigna.cm.z.io.TBCMCCD048Io> selectMultiTBCMCCD048(@Param("bzReqNo")
	java.lang.String bzReqNo);

	/**
	 * Work Request 처리 정보
	 * @TestValues 	bzReqNo=00000000000000000004;	usrId=;
	 */
	cigna.cm.z.io.TBCMCCD047Io selectOneTBCMCCD047(@Param("bzReqNo")
	java.lang.String bzReqNo, @Param("usrId")
	java.lang.String usrId);

	/**
	 * SFTP 계정 정보
	 * @TestValues 	hostNm=TEST_HOST1;
	 */
	cigna.cm.z.io.TBCMCCD050Io selectOneTBCMCCD050(@Param("hostNm")
	java.lang.String hostNm);

	/**
	 * 파일다운로드히스토리목록
	 * @TestValues 	bzReqNo=00000000000000000006;	fileSeq=1;
	 */
	java.util.List<cigna.cm.z.io.TBCMCCD049Io> selectMultiTBCMCCD049(
			@Param("bzReqNo")
			java.lang.String bzReqNo, @Param("fileSeq")
			java.lang.String fileSeq);

	/**
	 * SFTP 계정 목록
	 */
	java.util.List<cigna.cm.z.io.TBCMCCD050Io> selectMultiTBCMCCD050();

	/**
	 * Work Request 요청목록(임시)
	 * @TestValues 	usrId=;	bzReqNo=;	reqStrDt=;	reqEndDt=;	reqpId=;	pageNum=0;	pageCount=0;
	 */
	java.util.List<cigna.cm.z.io.TBCMCCD047Io> selectMultiTBCMCCD047b(
			@Param("usrId")
			java.lang.String usrId, @Param("bzReqNo")
			java.lang.String bzReqNo, @Param("reqStrDt")
			java.lang.String reqStrDt, @Param("reqEndDt")
			java.lang.String reqEndDt, @Param("reqpId")
			java.lang.String reqpId, @Param("pageNum")
			int pageNum, @Param("pageCount")
			int pageCount);

	/**
	 * Work Request 처리 저장
	 * @TestValues 	bzReqNo=;	reqTitlCtnt=;	reqpId=;	reqpNm=;	reqDtm=;	prcsrId=;	prcsrNm=;	prcsSt=;	prcsDcd=;	prcsDtm=;	note=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;	fileListCnt=;
	 */
	int insertOneTBCMCCD047(cigna.cm.z.io.TBCMCCD047Io tBCMCCD047Io);

	/**
	 * Work Request 처리 파일정보 저장
	 * @TestValues 	bzReqNo=;	fileSeq=;	sndmHostNm=;	sndmFilePathNm=;	receHostNm=;	receFilePathNm=;	atchOrgcpFileNm=;	atchSavFileNm=;	dwldVldDt=;	dwldVldYn=;	delYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;	prcsDcd=;
	 */
	int insertOneTBCMCCD048(cigna.cm.z.io.TBCMCCD048Io tBCMCCD048Io);

	/**
	 * Work Request 처리 파일 다운로드정보 저장
	 * @TestValues 	bzReqNo=;	fileSeq=;	dwldFileSeq=;	dwldDtm=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD049(cigna.cm.z.io.TBCMCCD049Io tBCMCCD049Io);

	/**
	 * Work Request 요청 정보
	 * @TestValues 	bzReqNo=;	usrId=;
	 */
	cigna.cm.z.io.TBCMCCD053Io selecOneTBCMCCD053(@Param("bzReqNo")
	java.lang.String bzReqNo, @Param("usrId")
	java.lang.String usrId);

	/**
	 * Work Request 요청 저장
	 * @TestValues 	bzReqNo=;	prcsrId=;	prcsrNm=;	reqpId=;	reqpNm=;	reqDtm=;	reqTitlCtnt=;	prcsYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD053(cigna.cm.z.io.TBCMCCD053Io tBCMCCD053Io);

	/**
	 * Work Request 처리자 저장
	 * @TestValues 	bzReqNo=;	prcsrId=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD054(cigna.cm.z.io.TBCMCCD054Io tBCMCCD054Io);
}