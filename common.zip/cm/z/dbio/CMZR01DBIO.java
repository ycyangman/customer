/**
 * DBIO 에디터에서 생성된 파일입니다. 인터페이스 파일을 직접 수정하지 마십시오.
 * @Generated Wed Apr 12 20:10:00 KST 2017
 */
package cigna.cm.z.dbio;

import klaf.container.annotation.KlafDataAccess;
import org.apache.ibatis.annotations.Param;

@KlafDataAccess(mapper = "cigna/cm/z/dbio/CMZR01DBIO.dbio", datasource = "bizBIZDDBDS")
public interface CMZR01DBIO
{

	/**
	 * 권한버튼목록
	 * @TestValues 	userId=A16051066;	scrnId=SLEA02M1;	itRoleCd=SL_286;
	 */
	java.util.List<cigna.cm.z.io.TBCMCCD046Io> selectMultiTBCMCCD046a(
			@Param("userId")
			java.lang.String userId, @Param("scrnId")
			java.lang.String scrnId, @Param("itRoleCd")
			java.lang.String itRoleCd);

	/**
	 * IT역할목록
	 * @TestValues 	userId=1600135000;	scrnId=ATBP03M0;
	 */
	java.util.List<cigna.cm.z.io.TBCMCCD046Io> selectMultiTBCMCCD046b(
			@Param("userId")
			java.lang.String userId, @Param("scrnId")
			java.lang.String scrnId);

	/**
	 * 권한검증내용
	 * @TestValues 	userId=1600135000;	scrnId=ATBP03M0;
	 */
	cigna.cm.z.io.TBCMCCD045Io selectOneTBCMCCD045(
			@Param("userId")
			java.lang.String userId, @Param("scrnId")
			java.lang.String scrnId);

	/**
	 * 권한검증등록
	 * @TestValues 	usrId=;	usrNm=;	sysId=;	scrnId=;	scrnNm=;	note=;	cnfYn=;	errYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;	itRoleCd=;	chgYn=;
	 */
	int mergeOneTBCMCCD045(
			cigna.cm.z.io.TBCMCCD045Io tBCMCCD045Io);

	/**
	 * 화면버튼권한 요청 삭제
	 * @TestValues 	usrId=;	usrNm=;	sysId=;	scrnId=;	scrnNm=;	note=;	cnfYn=;	errYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;	itRoleCd=;	chgYn=;
	 */
	int deleteMultiTBCMCCD046(cigna.cm.z.io.TBCMCCD045Io tBCMCCD045Io);

	/**
	 * 화면버튼권한 요청 저장
	 * @TestValues 	usrId=;	sysId=;	scrnId=;	scrnNm=;	itRoleCd=;	itRoleNm=;	scrnSubId=;	scrnSubNm=;	scrnButnConnId=;	butnId=;	butnNm=;	note=;	authYn=;	changeAuthYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int insertOneTBCMCCD046(cigna.cm.z.io.TBCMCCD046Io tBCMCCD046Io);

	/**
	 * @TestValues 	usrId=;	sysId=;	scrnId=;	scrnNm=;	itRoleCd=;	itRoleNm=;	scrnSubId=;	scrnSubNm=;	scrnButnConnId=;	butnId=;	butnNm=;	note=;	authYn=;	changeAuthYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int updateOneEI_ROLE_SCR_BUTN_RL(cigna.cm.z.io.TBCMCCD046Io tBCMCCD046Io);

	/**
	 * @TestValues 	usrId=;	sysId=;	scrnId=;	scrnNm=;	itRoleCd=;	itRoleNm=;	scrnSubId=;	scrnSubNm=;	scrnButnConnId=;	butnId=;	butnNm=;	note=;	authYn=;	changeAuthYn=;	lastChgDtm=;	lastChgrId=;	lastChgPgmId=;	lastChgTrmNo=;
	 */
	int mergeOneEI_ROLE_SCR_BUTN_RL(cigna.cm.z.io.TBCMCCD046Io tBCMCCD046Io);
}