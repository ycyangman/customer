package cigna.cm.z.service;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.bean.CMZ005BEAN;
import cigna.cm.z.io.CMZ005SVC01In;
import cigna.cm.z.io.CMZ005SVC01Out;
import cigna.cm.z.io.CMZ005SVC02In;
import cigna.cm.z.io.CMZ005SVC02Out;


/**
 * @file         cigna.cm.z.service.CMZ005SVC.java
 * @filetype     java source file
 * @brief        TBSLEMP114[사원부가정보] 내근직원 내선번호, MacAdress 조회 및 저장 처리
 * @author       권슬기
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           권슬기            2016. 11. 7.       신규 작성
 *
 */
@KlafService("CMZ005SVC")
public class CMZ005SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CMZ005BEAN cmz005bean;


	
	/**
	 * 사원부가정보조회 (내근직원 내선번호, MacAdress )
	 * 
	 * @param  input 사원번호조건 
	 * @return CMZ005SVC01Out 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMZ005SVC01Out selectList0(CMZ005SVC01In input) throws ApplicationException {
		logger.debug("CMZ005SVC-selectList0 start");

		// 사원번호가 존재하지 않을경우
		if (StringUtils.isEmpty(input.getEno())) {
			// 오류메시지 : 필수항목 [{0}]을(를) 입력하여야 합니다.    
			throw new ApplicationException("APPDE0002", new Object[]{"사원번호", "사원번호"});	
		}

		CMZ005SVC01Out output = cmz005bean.getEnoAdInfo( input );

		logger.debug("CMZ005SVC-selectList0 end");
		return output;
	}

	
	
	/**
	 * 사원부가정보조회 (내근직원 내선번호, MacAdress )
	 * 
	 * @param  input 사원번호조건 
	 * @return CMZ005SVC01Out 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify0")
	public CMZ005SVC02Out changeModify0(CMZ005SVC02In input) throws ApplicationException {

		logger.debug("CMZ005SVC-changeModify0 start");

		// 사원번호가 존재하지 않을경우
		if (StringUtils.isEmpty(input.getEno())) {
			// 오류메시지 : 필수항목 [{0}]을(를) 입력하여야 합니다.    
			throw new ApplicationException("APPDE0002", new Object[]{"사원번호", "사원번호"});	
		}
		CMZ005SVC02Out output = new CMZ005SVC02Out();
		
		// TBSLEMP114[사원부가정보] MERGE ( 내근직원 내선번호, MacAdress )
		int prcCnt = cmz005bean.mergeTBSLEMP114( input );

		if( prcCnt > 0 ){
			/* 정상처리 결과 메시지: 입력하신 내용 저장 되었습니다. */
			LApplicationContext.addMessage("KIOKI0009", null , null);
		}
		output.setPrcCnt(prcCnt);
		logger.debug("CMZ005SVC-changeModify0 end");
		return output;
	}
	


}

