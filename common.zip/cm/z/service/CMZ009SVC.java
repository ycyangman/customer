package cigna.cm.z.service;

import klaf.app.ApplicationException;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.bean.CMZ009BEAN;
import cigna.cm.z.io.CMZ009SVC00In;
import cigna.cm.z.io.CMZ009SVC00Out;
import cigna.cm.z.io.CMZ009SVC01In;
import cigna.cm.z.io.CMZ009SVC01Out;


/**
 * @file         cigna.cm.a.bean.CMZ009SVC.java
 * @filetype     java source file
 * @brief        주소정재
 * @author       박진성
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1    박진성                 2016. 3. 2.      신규작성
 *
 */
@KlafService("CMZ009SVC")
public class CMZ009SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZ009BEAN cmz009bean;
	
	/**
	 * 지번 조회(우편번호 검색)
	 * 
	 * @param  input 주소조회조건 
	 * @return CMZ009SVC00Out 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMZ009SVC00Out selectList0(CMZ009SVC00In input) throws ApplicationException {

		logger.debug("CMZ009SVC-selectList0 start");
		
		CMZ009SVC00Out jibunAddress = cmz009bean.getJibunAddress(input.getAddrInfo());
		
		return jibunAddress;
	}
	
	/**
	 * 도로명 조회(우편번호 검색)
	 * 
	 * @param  input 주소조회조건 
	 * @return CMZ009SVC00Out 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMZ009SVC00Out selectList1(CMZ009SVC00In input) throws ApplicationException {

		logger.debug("CMZ009SVC-selectList1 start");
		
		CMZ009SVC00Out roadAddress = cmz009bean.getRoadAddress(input.getAddrInfo());
		
		return roadAddress;
	}
	
	/**
	 * 주소정재
	 * 
	 * @param  input 주소조회조건 
	 * @return CMZ009SVC00Out 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMZ009SVC00Out selectList2(CMZ009SVC00In input) throws ApplicationException {

		logger.debug("CMZ009SVC-selectList2 start");
		
		CMZ009SVC00Out refindAddress = cmz009bean.getRefindAddress(input.getAddrInfo());
		
		return refindAddress;
	}
	
	/**
	 * 주소정재2
	 * 
	 * @param  input 주소조회조건 
	 * @return CMZ009SVC00Out 
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle0")
	public CMZ009SVC01Out selectSingle0(CMZ009SVC01In input) throws ApplicationException {

		logger.debug("CMZ009SVC-selectSingle0 start");
		
		CMZ009SVC01Out refindAddress2 = cmz009bean.getRefindAddress2(input);
		
		return refindAddress2;
	}
	
}