package cigna.cm.z.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.dbio.CMA201DBIO;
import cigna.cm.a.io.TBCSPRF001Io;
import cigna.cm.z.bean.CMZ010BEAN;
import cigna.cm.z.bean.CMZI10BEAN;
import cigna.cm.z.io.CMZ010SVC00In;
import cigna.cm.z.io.CMZ010SVC00Out;
import cigna.cm.z.io.CMZ010SVC01In;
import cigna.cm.z.io.CMZ010SVC01Out;
import cigna.cm.z.io.CMZ010SVC03In;
import cigna.cm.z.io.CMZ010SVC03Sub;
import cigna.cm.z.io.TBCMETC009Io;
import cigna.cm.z.io.TBCMETC010Io;
import cigna.cm.z.io.TBCMETC011Io;
import cigna.cm.z.io.TBCMETC012Io;
import cigna.zz.ExcelUtil;
import cigna.zz.ReflUtil;
import cigna.zz.SecuUtil;


/**
 * @file         cigna.cm.a.bean.CMZ010SVC.java
 * @filetype     java source file
 * @brief        업무연락
 * @author       박진성
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1    박진성                 2016. 3. 2.      신규작성
 *
 */
@KlafService("CMZ010SVC")
public class CMZ010SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZ010BEAN cmz010bean;
	
	@Autowired
	private CMZI10BEAN cmzi10bean;
	
	@Autowired
	private CMA201DBIO cma201dbio;
	
	/**
	 * 업무연락유형 목록 조회
	 * @param input 업무연락유형 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMZ010SVC00Out selectList0(CMZ010SVC00In input) throws ApplicationException {

		logger.debug("CMZ010SVC-selectList0 start");
		
		CMZ010SVC00Out output = new CMZ010SVC00Out();
		
		List<TBCMETC009Io> bzCntcList = cmz010bean.getBzCntcTypeList(input);
		output.setBzCntcTypeList(bzCntcList);
		
		if ( output.getBzCntcTypeCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			int totalCount = ((input.getPageNum()-1)*input.getPageCount()) + output.getBzCntcTypeCnt();
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{totalCount}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{totalCount}, null);
			}
		}
		
		return output;
	}
	
	/**
	 * 업무연락 목록 조회
	 * @param input 업무연락 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMZ010SVC01Out selectList1(CMZ010SVC01In input) throws ApplicationException {

		logger.debug("CMZ010SVC-selectList1 start");
		
		CMZ010SVC01Out output = new CMZ010SVC01Out();
		
		List<TBCMETC010Io> bzCntcList = null;
		
		String bzAlrmInqYn = input.getBzAlrmInqYn(); // 업무알람조회여부
		String receTeamInqYn = input.getReceTeamInqYn(); // 수신팀조회여부
		
		if ("Y".equals(bzAlrmInqYn)) {
			bzCntcList = cmzi10bean.getBzCntcNtfcTgtList(input.getReceChrgpEno());
		}
		else if("Y".equals(receTeamInqYn)) {
			bzCntcList = cmz010bean.getBzCntcListByTeam(input);
		}		
		else {
			bzCntcList = cmz010bean.getBzCntcList(input);
		}
		
		output.setBzCntcList(bzCntcList);
		
		if (DasUtils.existNextResult(bzCntcList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}

		if (bzCntcList.size() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage("KIOKI0004", null, null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003",	new Object[] { bzCntcList.size() }, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",	new Object[] { bzCntcList.size() }, null);
		}
		
		return output;
	}
	
	/**
	 * 업무연락정보 진행상태업데이트 및 상세조회
	 * @param input 업무연락유형 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMZ010SVC01Out selectList2(CMZ010SVC01In input) throws ApplicationException {

		logger.debug("CMZ010SVC-selectList2 start");
		
		CMZ010SVC01Out output = new CMZ010SVC01Out();
		
		//업문연락진행상태 Update
		cmz010bean.setBzCntcProgSta(input);
		
		// 업무연락정보 조회
		TBCMETC010Io bzCntcInfo = cmz010bean.getBzCntcInfo(input);
		output.setBzCntcInfo(bzCntcInfo);
		
		// 업무연락이력정보 조회
		TBCMETC011Io bzCntcHistInfo = cmz010bean.getBzCntcHistInfo(input);
		output.setBzCntcHistInfo(bzCntcHistInfo);
		
		// 저장된 업무연락 조회
		List<TBCMETC012Io> savedContInfoInq = cmz010bean.getSavedContInfoInq(input);
		output.setContInfoList(savedContInfoInq);
		
		//logger.debug(">>>>equals(bzCntcInfo) : "+!StringUtils.isEmpty(bzCntcInfo.getFileMgntNo()));
		if(bzCntcInfo != null){
			if(!StringUtils.isEmpty(bzCntcInfo.getFileMgntNo())){
				//저장된 파일첨부
				List<CMZ010SVC03Sub> fileMgntList = cmz010bean.getFileMgntList(bzCntcInfo.getFileMgntNo());
				output.setDsFileMgntList(fileMgntList);
			}else{
				output.setDsFileMgntList(null);
			}
		}
		return output;
	}
	
	
	/**
	 * 엑셀다운 테스트
	 * @param input 업무연락유형 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMZ010SVC00Out selectList3(CMZ010SVC00In input) throws ApplicationException {
	
		logger.debug("CMZ010SVC-selectList3 start");
		
		CMZ010SVC00Out output = new CMZ010SVC00Out();
		
		List<TBCMETC009Io> bzCntcList = cmz010bean.getBzCntcTypeList(input);
		
		// DRM엑셀 생성 메소드		
		String drmExcelFileName = ExcelUtil.createDrmExcel(input.getGridInfoJson(), bzCntcList);
		output.setDrmExcelFileName(drmExcelFileName);
		
		return output;
	}

	/**
	 * 계약사항조회										
	 * @param input 계약사항 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList4")
	public CMZ010SVC01Out selectList4(CMZ010SVC01In input) throws ApplicationException {
	
		logger.debug("CMZ010SVC-selectList4 start");
		
		CMZ010SVC01Out output = new CMZ010SVC01Out();
		
		List<TBCMETC012Io> contInfoInq = cmz010bean.getContInfoInq(input.getRrno(), input.getContrInsdDcd(), input.getContNo());
		output.setContInfoList(contInfoInq);
		
		if ( output.getContInfoCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getContInfoList().size()}, null);
		}
		
		return output;
	}
	
	/**
	 * 업무현황 엑셀다운로드
	 * @param input 업무연락유형 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList5")
	public CMZ010SVC01Out selectList5(CMZ010SVC01In input) throws ApplicationException {
	
		logger.debug("CMZ010SVC-selectList5 start");
		
		CMZ010SVC01Out output = new CMZ010SVC01Out();
		
		List<TBCMETC010Io> bzCntcList = null;
		
		input.setPageNum(1);
		input.setPageCount(50000);
		
		String bzAlrmInqYn   = input.getBzAlrmInqYn();   // 업무알람조회여부
		String receTeamInqYn = input.getReceTeamInqYn(); // 수신팀조회여부
		
		if ("Y".equals(bzAlrmInqYn)) {
			bzCntcList = cmzi10bean.getBzCntcNtfcTgtList(input.getReceChrgpEno());
		}
		else if("Y".equals(receTeamInqYn)) {
			bzCntcList = cmz010bean.getBzCntcListByTeam(input);
		}
		else {
			bzCntcList = cmz010bean.getBzCntcList(input);
		}

		if (bzCntcList.size() == 0) {
			// KIOKI0004 : 요청하신 자료가 존재하지 않습니다.
			LApplicationContext.addMessage("KIOKI0004", null, null);
		} else if ("Y".equals(output.getRecrdNxtYn())) {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
			LApplicationContext.addMessage("KIOKI0003",	new Object[] { bzCntcList.size() }, null);
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002",	new Object[] { bzCntcList.size() }, null);
		}
		
		// DRM엑셀 생성 메소드		
		String drmExcelFileName = ExcelUtil.createDrmExcel(input.getGridInfoJson(), bzCntcList);
		output.setDrmExcelFileName(drmExcelFileName);
		
		return output;
	}
	
	/**
	 * 업무연락유형 목록 조회 이름순 정렬
	 * @param input 업무연락유형 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList6")
	public CMZ010SVC00Out selectList6(CMZ010SVC00In input) throws ApplicationException {

		logger.debug("CMZ010SVC-selectList6 start");
		
		CMZ010SVC00Out output = new CMZ010SVC00Out();
		
		List<TBCMETC009Io> bzCntcList = cmz010bean.getBzCntcTypeListSortByNm(input);
		output.setBzCntcTypeList(bzCntcList);
		
		// 업무연락상세조회에서 고객정보 파라미터전달시 사용
		if(!StringUtils.isEmpty(input.getCustDscNo())) {
			
			String encCustRrno = SecuUtil.getEncValue(input.getCustDscNo(), SecuUtil.EncType.Jumin);
			TBCSPRF001Io  custInfo = cma201dbio.selectOneTBCSPRF001d(encCustRrno);
			
			if(custInfo != null) {
				output.setCustInfo(custInfo);
				SecuUtil.doDecOmm(custInfo);
			}
		}
		
		
		if ( output.getBzCntcTypeCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			int totalCount = ((input.getPageNum()-1)*input.getPageCount()) + output.getBzCntcTypeCnt();
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{totalCount}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{totalCount}, null);
			}
		}
		
		return output;
	}

	/**
	 * 레포트 테스트
	 * @param input 업무연락유형 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList9")
	public CMZ010SVC00Out selectList9(CMZ010SVC00In input) throws ApplicationException {
	
		logger.debug("CMZ010SVC-selectList9 start");
		
		CMZ010SVC00Out output = new CMZ010SVC00Out();
		

		List<TBCMETC009Io> bzCntcList = cmz010bean.getBzCntcTypeList(input);
		
		TBCMETC009Io setObj = new TBCMETC009Io();
		
		ReflUtil.setObjData(bzCntcList.get(0), setObj);
		
		logger.info("getObj :"+ setObj);
		
		//RptUtil.toRptXml(new String[]{"customerList", "bzCntcList"}, new Object[]{customerList, bzCntcList.get(0)});
		
		// 레포트 생성 메소드	
		//String drmExcelFileName = RptUtil.createDrmReport(input.getReportReqInfo(), new List[]{customerList, bzCntcList});
		//output.setReportFileName(drmExcelFileName);
		
		return output;
	}

	/**
	 * 업무연락유형 입력
	 * @param input 업무연락 저장정보
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public CMZ010SVC01Out changeInsert1(CMZ010SVC01In input) throws ApplicationException {

		logger.debug("CMZ010SVC-changeInsert1 start");
		
		CMZ010SVC01Out output = new CMZ010SVC01Out();
		
		// 업무연락정보 입력
		String bzCntcMgntNo = cmz010bean.insertBzCntcList(input);
		
		TBCMETC010Io bzCntcInfo = new TBCMETC010Io();
		bzCntcInfo.setBzCntcMgntNo(bzCntcMgntNo);
		output.setBzCntcInfo(bzCntcInfo);
		
		LApplicationContext.addMessage("KIOKI0010", new Object[]{1}, null);
		
		return output;
	}
	
	
	/**
	 * 예약콜 전송
	 * @param input 예약콜 전송
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert2")
	@TransactionalOperation
	public void changeInsert2(CMZ010SVC03In input) throws ApplicationException {

		logger.debug("CMZ010SVC-changeInsert1 start");
		
		// 업무연락정보 입력
		cmzi10bean.rsvtCallTrms(input);
		
		LApplicationContext.addMessage("KIOKI0010", new Object[]{1}, null);

	}
		
	/**
	 * 업무연락유형 입력
	 * @param input 업무연락 저장정보
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeUpdate1")
	@TransactionalOperation
	public CMZ010SVC01Out changeUpdate1(CMZ010SVC01In input) throws ApplicationException {

		logger.debug("CMZ010SVC-changeInsert1 start");
		
		CMZ010SVC01Out output = new CMZ010SVC01Out();
		
		// 업무연락정보 수정
		String bzCntcMgntNo = cmz010bean.updateBzCntcList(input);
		
		TBCMETC010Io bzCntcInfo = new TBCMETC010Io();
		bzCntcInfo.setBzCntcMgntNo(bzCntcMgntNo);
		output.setBzCntcInfo(bzCntcInfo);
		
		LApplicationContext.addMessage("KIOKI0010", new Object[]{1}, null);
		
		return output;
	}
	
	/**
	 * 업무연락유형 저장
	 * @param input 업무연락유형 저장목록
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify0")
	@TransactionalOperation
	public void changeModify0(CMZ010SVC00In input) throws ApplicationException {
	
		logger.debug("CMZ010SVC-changeModify0 start");
		
		int iCnt = cmz010bean.modifyBzCntcTypeList(input);
		
	
		if(iCnt > 0)
			LApplicationContext.addMessage("KIOKI0009", null, null);
		else
			throw new ApplicationException("KIERE0005", null, new Object[]{"데이터 베이스 연결을 실패했거나, 데이터의 중복, 필수 입력값이 누락"});
		
		
		LApplicationContext.addMessage("KIOKI0010", new Object[]{iCnt}, null);
	}
}