package cigna.cm.z.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.context.das.DasUtils;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.bean.CMZ030BEAN;
import cigna.cm.z.io.CMZ030SVC00In;
import cigna.cm.z.io.CMZ030SVC00Out;
import cigna.cm.z.io.CMZ030SVC01In;
import cigna.cm.z.io.CMZ030SVC01Out;
import cigna.cm.z.io.CMZ030SVC02In;
import cigna.cm.z.io.CMZ030SVC02Out;
import cigna.cm.z.io.CMZ030SVC03In;
import cigna.cm.z.io.CMZ030SVC03Out;
import cigna.cm.z.io.CMZ030SVC04In;
import cigna.cm.z.io.TBCMCCD047Io;
import cigna.cm.z.io.TBCMCCD049Io;
import cigna.cm.z.io.TBCMCCD050Io;
import cigna.cm.z.io.TBCMCCD053Io;


/**
 * @file         cigna.cm.z.service.CMZ030SVC.java
 * @filetype     java source file
 * @brief
 * @author       문효증
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           문효증		       2016. 11. 21.       신규 작성
 *
 */
@KlafService("CMZ030SVC")
public class CMZ030SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZ030BEAN cmz030bean;
	
	/**
	 * Work Request 요청 상세
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle1")
	public TBCMCCD053Io selectSingle1(CMZ030SVC00In input) throws ApplicationException {

		TBCMCCD053Io output = cmz030bean.getWorkRequest(input);
		
		if(output == null){
			throw new ApplicationException("APAIE0092", new Object[]{"요청"}, new Object[]{});
		}
		
		return output;
	}
	
	/**
	 * Work Request 요청 저장
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify1")
	@TransactionalOperation
	public CMZ030SVC02Out changeModify1(CMZ030SVC04In input) throws ApplicationException {
		
		CMZ030SVC02Out output = new CMZ030SVC02Out();
		
		int wrListCnt = cmz030bean.modifyWorkRequest(input);
		
		output.setResultCnt(wrListCnt);
		
		return output;
	}
	
	/**
	 * Work Request 처리 상세
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectSingle0")
	public TBCMCCD047Io selectSingle0(CMZ030SVC01In input) throws ApplicationException {

		TBCMCCD047Io output = cmz030bean.getWorkRequestInfo(input);
		
		if(output == null){
			throw new ApplicationException("APAIE0092", new Object[]{"처리"}, new Object[]{});
		}
		
		return output;
	}
	
	/**
	 * 파일 다운로드 히스토리 목록
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMZ030SVC01Out selectList2(CMZ030SVC01In input) throws ApplicationException {
		
		CMZ030SVC01Out output = new CMZ030SVC01Out();

		List<TBCMCCD049Io> fileDwldHisList = cmz030bean.getFileDwldHisList(input);

		output.setFileDwldHisList(fileDwldHisList);
		
		return output;
	}
	
	/**
	 * SFTP계정 목록
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMZ030SVC03Out selectList3(CMZ030SVC03In input) throws ApplicationException {
		
		CMZ030SVC03Out output = new CMZ030SVC03Out();

		List<TBCMCCD050Io> hostNmList = cmz030bean.getHostNmList();

		output.setHostNmList(hostNmList);
		
		return output;
	}
	
	
	/**
	 * Work Request 처리
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify0")
	@TransactionalOperation
	public CMZ030SVC02Out changeModify0(CMZ030SVC02In input) throws ApplicationException {
		
		CMZ030SVC02Out output = new CMZ030SVC02Out();
		
		int wrListCnt = cmz030bean.setFileInfo(input);
		
		if( wrListCnt > 0 ){
			// 입력하신내용 {0}건이 저장 되었습니다. 
			LApplicationContext.addMessage("KIOKI0010", new Object[]{ Integer.toString(wrListCnt)}, null);
		}
		
		output.setResultCnt(wrListCnt);
		
		return output;
	}
	
	/**
	 * 다운로드파일정보 저장
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public CMZ030SVC02Out changeInsert1(TBCMCCD049Io input) throws ApplicationException {
		
		CMZ030SVC02Out output = new CMZ030SVC02Out();
		
		int resultCnt = cmz030bean.insertDownloadFileInfo(input);
		
		output.setResultCnt(resultCnt);
		
		return output;
	}
	
	/**
	 * Work Request 목록 (임시)
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMZ030SVC00Out selectList0(CMZ030SVC00In input) throws ApplicationException {
		
		CMZ030SVC00Out output = new CMZ030SVC00Out();
		
		List<TBCMCCD047Io> wrList = cmz030bean.getWorkRequestList(input);

		output.setWrList(wrList);

		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(wrList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		if ( output.getWrListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			int totalCount = ((input.getPageNum()-1)*input.getPageCount()) + output.getWrListCnt();
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{totalCount}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{totalCount}, null);
			}
		}
		
		return output;
	}
	
	/**
	 * Work Request 처리 목록(임시)
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMZ030SVC00Out selectList1(CMZ030SVC00In input) throws ApplicationException {
		
		CMZ030SVC00Out output = new CMZ030SVC00Out();

		List<TBCMCCD047Io> wrList = cmz030bean.getWorkRequestList2(input);
		
		output.setWrList(wrList);
		
		/* 다음페이지가 존재하는 지 여부를 판단하여 recrdNxtYn 변수에 Y/N을 설정한다. */
		if (DasUtils.existNextResult(wrList)) {
			output.setRecrdNxtYn("Y");
		} else {
			output.setRecrdNxtYn("N");
		}
		
		if ( output.getWrListCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			int totalCount = ((input.getPageNum()-1)*input.getPageCount()) + output.getWrListCnt();
			if ("Y".equals(output.getRecrdNxtYn())) {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. - 자료를 계속하여 조회할 수 있습니다. */
				LApplicationContext.addMessage("KIOKI0003", new Object[]{totalCount}, null);
			} else {
				/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
				LApplicationContext.addMessage("KIOKI0002", new Object[]{totalCount}, null);
			}
		}

		return output;
	}
	
}

