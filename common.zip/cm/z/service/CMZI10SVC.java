package cigna.cm.z.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.bean.CMZ010BEAN;
import cigna.cm.z.bean.CMZ020BEAN;
import cigna.cm.z.bean.CMZI10BEAN;
import cigna.cm.z.io.CMZ010SVC01In;
import cigna.cm.z.io.CMZI10SVC01In;
import cigna.cm.z.io.CMZI10SVC01Out;
import cigna.cm.z.io.CMZI10SVC02In;
import cigna.cm.z.io.CMZI10SVC02Out;
import cigna.cm.z.io.CMZI10SVC02Sub1;
import cigna.cm.z.io.CMZI10SVC03In;
import cigna.cm.z.io.CMZI10SVC03Out;
import cigna.cm.z.io.CMZI10SVC04In;
import cigna.cm.z.io.CMZI10SVC04Out;
import cigna.cm.z.io.CMZI10SVC04Sub1;
import cigna.cm.z.io.CMZI10SVC05In;
import cigna.cm.z.io.CMZI10SVC05Out;
import cigna.cm.z.io.CMZI10SVC06In;
import cigna.cm.z.io.CMZI10SVC06Out;
import cigna.cm.z.io.TBCMETC010Io;
import cigna.zz.BizUtil;
import cigna.zz.FwUtil;
import cigna.zz.SecuUtil;


/**
 * @file         cigna.cm.a.bean.CMZ010SVC.java
 * @filetype     java source file
 * @brief        업무연락인터페이스
 * @author       박진성
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1    박진성                 2016. 3. 2.      신규작성
 *
 */
@KlafService("CMZI10SVC")
public class CMZI10SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZ010BEAN cmz010bean;
	
	@Autowired
	private CMZ020BEAN cmz020bean;
	
	@Autowired
	private CMZI10BEAN cmzi10bean;
	
	/**
	 * 업무연락유형 조회(TM)
	 * I/F : ILS_E_COMOS000000002
	 * @param input 업무연락 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList0")
	public CMZI10SVC02Out selectList0(CMZI10SVC02In input) throws ApplicationException {

		logger.debug("CMZ010SVC-selectList0 start");
		
		
		CMZI10SVC02Out output = new CMZI10SVC02Out();
		
		List<CMZI10SVC02Sub1> dsBzCntcTypList = cmz020bean.getBzCntcTypeList(input);
		output.setDsBzCntcTypList(dsBzCntcTypList);
		
		if ( output.getBzCntcTypCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getBzCntcTypCnt()}, null);
		}
		
		return output;
	}
	
	
	
	/**
	 * 업무연락 목록 조회(C/S)
	 * @param input 업무연락 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMZI10SVC01Out selectList1(CMZI10SVC01In input) throws ApplicationException {

		logger.debug("CMZ010SVC-selectList1 start");
		
		CMZ010SVC01In cmz010svc01in = new CMZ010SVC01In();
		cmz010svc01in.setBzCntcTypNm1(input.getBzCntcTypNm1()); // 업무유형명
		cmz010svc01in.setBzCntcTypNm2(input.getBzCntcTypNm2()); // 업무유형명
		cmz010svc01in.setApplOrgNo(input.getApplOrgNo()); // 신청조직번호
		cmz010svc01in.setReceOrgNo(input.getReceOrgNo()); // 수신조직번호
		cmz010svc01in.setApplEno(input.getApplEno()); // 신청사원
		cmz010svc01in.setReceChrgpEno(input.getReceChrgpEno()); // 수신사원
		cmz010svc01in.setRrno(input.getRrno()); // 고객주민등록번호
		cmz010svc01in.setBzCntcProgStcd(input.getBzCntcProgStcd()); // 진행상태코드
		cmz010svc01in.setRcDtFrom(input.getRcDtFrom()); // 접수기간from
		cmz010svc01in.setRcDtTo(input.getRcDtTo()); // 접수기간to
		
		CMZI10SVC01Out output = new CMZI10SVC01Out();
		
		List<TBCMETC010Io> bzCntcList = cmz010bean.getBzCntcList(cmz010svc01in);
		SecuUtil.doEncList(bzCntcList); // 주민번호 암호화
		
		output.setBzCntcList(bzCntcList);
		
		if ( output.getBzCntcCnt() == 0 ) {
			LApplicationContext.addMessage( "KIOKI0004", null, null) ;  
		} else {
			/* 정상처리 결과 메시지: 요청하신 내용이 {0}건 조회 되었습니다. */
			LApplicationContext.addMessage("KIOKI0002", new Object[]{output.getBzCntcCnt()}, null);
		}
		
		return output;
	}
	
	/**
	 * 업무연락 목록 조회(TM)
	 * @param input 업무연락 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMZI10SVC04Out selectList2(CMZI10SVC04In input) throws ApplicationException {

		logger.debug("CMZ010SVC-selectList1 start");
		
		CMZI10SVC04Out output = new CMZI10SVC04Out();
		
		List<CMZI10SVC04Sub1> bzCntcList = cmz020bean.getBzCntcList(input);
		output.setBzCntcList(bzCntcList);
		
		return output;
	}	
	
	
	/**
	 * 업무연락 상세 조회(TM)
	 * @param input 업무연락 목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList3")
	public CMZI10SVC05Out selectList3(CMZI10SVC05In input) throws ApplicationException {

		CMZI10SVC05Out output = cmzi10bean.getBzCntcInfo(input);
		
		return output;
	}	
	
	/**
	 * 업무연락등록처리
	 * @param input 업무연락 저장정보
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert1")
	@TransactionalOperation
	public CMZI10SVC03Out changeInsert1(CMZI10SVC03In input) throws ApplicationException {

		logger.debug("CMZ010SVC-changeInsert1 start");
		
		CMZI10SVC03Out output = new CMZI10SVC03Out();
		
		// 업무연락정보 입력
		String bzCntcMgntNo = cmzi10bean.modifyBzCntc(input);
		
		output.setBzCntcMgntNo(bzCntcMgntNo);
		
		LApplicationContext.addMessage("KIOKI0010", new Object[]{1}, null);
		
		return output;
	}
	
	/**
	 * 업무연락 알림조회
	 * @param input 업무연락 알림목록 조회조건
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList4")
	public CMZI10SVC06Out selectList4(CMZI10SVC06In input) throws ApplicationException {

		logger.debug("CMZI10SVC-selectList4 start");
		
		CMZI10SVC06Out output = new CMZI10SVC06Out();
		
		output.setBzCntcYn("N");
		
		if (BizUtil.MED_TYP_CD_COR.equals(FwUtil.getMedTyp())) {
			List<CMZI10SVC04Sub1> bzCntcList = cmzi10bean.getBzCntcNtfcList(input.getReceChrgpEno());
			if(bzCntcList !=null && bzCntcList.size()>0) {
				output.setBzCntcYn("Y");
			}
		}
		
		return output;
	}
		
	
}