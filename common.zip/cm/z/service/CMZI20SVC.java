package cigna.cm.z.service;

import java.util.HashMap;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;

import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.a.bean.CMA010BEAN;
import cigna.cm.a.dbio.CMA201DBIO;
import cigna.cm.a.io.COM_E_DMIOS000000001In;
import cigna.cm.a.io.COM_E_DMIOS000000001Out;
import cigna.cm.a.io.TBCSPRF001Io;
import cigna.cm.z.io.CMZI20SVC01In;
import cigna.cm.z.io.CMZI20SVC01Out;
import cigna.zz.RptUtil;
import cigna.zz.SecuUtil;

/**
 * @file         cigna.cm.a.bean.CMZ010SVC.java
 * @filetype     java source file
 * @brief        ARS SMS 발송
 * @author       양윤철
 * @version      0.1
 * @history
 *
 * 버전               성명                   일자                       변경내용
 * -----  --------  -----------   -----------------	
 * 0.1     박진성               2016. 12. 2.  신규작성
 *
 */
@KlafService("CMZI20SVC")
public class CMZI20SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMA010BEAN cma010bean;
	
	@Autowired
	private CMA201DBIO cma201dbio;
	
	/**
	 * ARS SMS 발송
	 * ARS_E_COMOS000000001
	 * @param input SMS 발송정보
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeInsert0")
	public CMZI20SVC01Out changeInsert0(CMZI20SVC01In input) throws ApplicationException {

		logger.debug("CMZ020SVC-changeInsert0 start");		
		
		CMZI20SVC01Out output = new CMZI20SVC01Out();

		String bzDvsn = input.getBzDvsn();
		
		// 입력 정보 체크
		if (StringUtils.isEmpty(bzDvsn)) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"업무구분"}, new Object[]{});
		}
		
		StringBuffer sb = new StringBuffer();
		
		if("01".equals(bzDvsn)) {
			sb.append("ARS 라이나주소안내 SMS \n");
			sb.append("주소:서울특별시 종로구 삼봉로 48, 18층 (청진동, 시그나타워) 라이나생명 보험금심사팀 앞 (110-130) \n");
			sb.append("라이나생명 \n");
			sb.append("15880058 \n");
		}
		else if("02".equals(bzDvsn)) {
			sb.append("ARS 콜백접수 안내 \n");
			sb.append("상담예약 접수가 완료되었습니다. 감사합니다.[라이나생명] \n");
			sb.append("라이나생명 \n");
			sb.append("15882215 \n");
		}
		else if("03".equals(bzDvsn)) {
			sb.append("ARS 콜백접수 안내 \n");
			sb.append("상담예약 접수가 완료되었습니다. 감사합니다.[라이나생명] \n");
			sb.append("라이나생명 \n");
			sb.append("63250200 \n");
		}
		else if("04".equals(bzDvsn)) {
			sb.append("ARS 콜백기록 안내 \n");
			sb.append("상담예약 접수가 완료되었습니다. 감사합니다.[라이나생명] \n");
			sb.append("라이나생명 \n");
			sb.append("15880058 \n");
		}		
		
		String custRrno  = input.getCustRrno();
		String custTelno = input.getCustTelno();
		
		// 입력 정보 체크
		if (StringUtils.isEmpty(custTelno)) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"고객 전화번호"}, new Object[]{});
		}
		
		String custNo = "";
		String custNm = "";
		String encCustRrno =  custRrno;
		if(!StringUtils.isEmpty(custRrno) && custRrno.trim().length() == 13){
			encCustRrno = SecuUtil.getEncValue(custRrno, SecuUtil.EncType.Jumin);
			
			TBCSPRF001Io tbcsprf001io = cma201dbio.selectOneTBCSPRF001d(encCustRrno);
			if(tbcsprf001io != null) {
				custNo = tbcsprf001io.getCustNo();
				custNm = tbcsprf001io.getCustNm();
			}
		}
		
		String mpdno = ""; //핸드폰식별번호
		String mpsno = ""; //핸드폰국번호
		String mpino = ""; //핸드폰개별번호
		
		if(!StringUtils.isEmpty(custTelno)) {			
			mpdno = custTelno.substring(0, 3); //핸드폰식별번호
			mpsno = custTelno.substring(3, 7); //핸드폰국번호
			mpino = custTelno.substring(7); //핸드폰개별번호
		}
	
		
		/* LMS전송 */
		/* 자유형식문자메시지(B00000001) */
		HashMap<String, String> msgInfo = new HashMap<String, String>();
		msgInfo.put("msg",   sb.toString());     // 메세지내용
		
		String rptXml = RptUtil. getRootMapXmlString(msgInfo);
		
		COM_E_DMIOS000000001In req = new COM_E_DMIOS000000001In();
		
		req.setDocCd			("B00000001");	// 문서코드(B00000001:자유형식문자메시지)
		req.setNotclSndMedcd 	("09");			// 안내장발송매체코드(09:LMS)
		req.setExpDt			("");			// 발송예정일자(즉시 발송인 경우 생략 가능)
		req.setExpTi			("");			// 발송예정시각(즉시 발송인 경우 생략 가능)
		req.setReceCustNo		(custNo);		// 고객번호
		req.setReceCustNm		(custNm);		// 고객명
		req.setPrintData     	(rptXml);		// 출력정보
		req.setReceMphonTeldno	(mpdno);		// 휴대전화전화식별번호
		req.setReceMphonTelsno	(mpsno);		// 휴대전화전화국번호
		req.setReceMphonTelino	(mpino);		// 휴대전화전화개별번호
		
		logger.debug("eaiRequest data:{}", req);
		
		COM_E_DMIOS000000001Out res = cma010bean.callEAINotcl(req);
		
		logger.debug("eaiResponse data:{}", res);
		
		output.setErrDcd("N");// set [오류구분]
		output.setRstMsgCtnt("");// set [결과메시지내용]
		
		return output;
	}
	
	
}