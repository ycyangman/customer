package cigna.cm.z.service;

import java.util.List;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;
import klaf.container.annotation.KlafService;
import klaf.container.annotation.KlafServiceOperation;
import klaf.transaction.annotation.TransactionalOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import cigna.cm.z.bean.CMZR01BEAN;
import cigna.cm.z.io.CMZR01SVC00In;
import cigna.cm.z.io.CMZR01SVC00Out;
import cigna.cm.z.io.CMZR01SVC01In;
import cigna.cm.z.io.CMZR01SVC01Out;
import cigna.cm.z.io.CMZR01SVC02In;
import cigna.cm.z.io.CMZR01SVC02Out;
import cigna.cm.z.io.TBCMCCD045Io;
import cigna.cm.z.io.TBCMCCD046Io;


/**
 * @file         cigna.cm.z.service.CMZR01SVC.java
 * @filetype     java source file
 * @brief
 * @author       개발자(한글이름)
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           개발자(한글이름)       2016. 11. 15.       신규 작성
 *
 */
@KlafService("CMZR01SVC")
public class CMZR01SVC {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CMZR01BEAN cmzr01bean;
	
	/**
	 * 권한버튼목록
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList1")
	public CMZR01SVC00Out selectList1(CMZR01SVC00In input) throws ApplicationException {
		
		CMZR01SVC00Out output = new CMZR01SVC00Out();

		List<TBCMCCD046Io> btnInfoList = cmzr01bean.getBtnInfoList(input);

		int btnInfoListCnt = 0;
		if(btnInfoList != null) btnInfoListCnt = btnInfoList.size();
		
		output.setBtnInfoList(btnInfoList);
		output.setBtnInfoListCnt(btnInfoListCnt);
		
		return output ;
	}
	
	/**
	 * IT역할목록
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("selectList2")
	public CMZR01SVC01Out selectList2(CMZR01SVC01In input) throws ApplicationException {
		
		CMZR01SVC01Out output = new CMZR01SVC01Out();
		
		//IT역할목록
		List<TBCMCCD046Io> itRoleList = cmzr01bean.getItRoleList(input);
		
		int itRoleListCnt = 0;
		if(itRoleList != null) itRoleListCnt = itRoleList.size();

		//권한검증내용
		TBCMCCD045Io authInfo = cmzr01bean.getAuthInfo(input);
		
		output.setAuthInfo(authInfo);
		output.setItRoleList(itRoleList);
		output.setItRoleListCnt(itRoleListCnt);
		
		return output ;
	}
	
	/**
	 * RBAC검증 저장
	 * @param input
	 * @return
	 * @throws ApplicationException
	 */
	@KlafServiceOperation("changeModify1")
	public CMZR01SVC02Out changeModify1(CMZR01SVC02In input) throws ApplicationException {
		
		int putBtnListCnt = cmzr01bean.modifyAuthInfo(input);
		
		if( putBtnListCnt > 0 ){
			/* 정상처리 결과 메시지: 입력하신 내용 저장 되었습니다. */
			LApplicationContext.addMessage("KIOKI0009", null , null);
		}
		
		CMZR01SVC02Out output = new CMZR01SVC02Out();
		output.setPutBtnListCnt(putBtnListCnt);

		return output ;
	}
}

