package cigna.zz;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;


/**
 * @file            cigna.zz.BizCommUtil.java
 * @filetype        java source file
 * @brief           업무공통으로 연령계산 및 체크 프로그램 입니다.
 * @author          박경화
 * @version         1.0
 * @history
 * convertHangul()의 '만', '억', '조', '경' 단위의 add는 1이상일때 동작
 * 지점에서 사용하고 있는 착신 과금 서비스 전화번호를 나타내는 080이 isValidTelno() 메서드에서 true 가 나오도록 수정
 * 1666-XXXX 형태의 번호도 식별이 되어 추가
 * isValidRrno()와 isValidFrgnrRrno()에서 주민번호 앞 6자리가 미래의 날짜가 입력이 되면 올바르지 않은 주민번호로 판단하도록 수정
 *
 * Version         성명                    일자                          변경내용
 * -----------    ---------  -----------    ----------------- 
 * 1.0             양윤철                 2016. 01.29.  신규작성
 */

public class BizCommUtil {

	
    /** 외국인등록번호 연속문자열 포맷 */
    public static final String FRGNRRRNO_PATTERN = "[0-9]{2}[01]{1}[0-9]{1}[0123]{1}[0-9]{1}[5678]{1}[0-9]{1}[02468]{1}[0-9]{4}";
    // 2012.06.01 변경된 외국인등록번호 체크로직 적용을 위해 포맷변경함. 2013.10.15 적용
    // 기존 [0-9]{2}[01]{1}[0-9]{1}[0123]{1}[0-9]{1}[5678]{1}[0-9]{1}[02468]{1}[0-9]{2}[6789]{1}[0-9]{1}
    
    /** 사업자등록번호 문자열 포맷 */
    public static final String ERNO_PATTERN = "[0-9]{3}[0-9]{2}[0-9]{5}";

    /** 전화번호 문자열 포맷 */
    public static final String TELNO_PATTERN = "[0](([2])|([0-9]{2}))[1-9][0-9]{2,3}[0-9]{4}";
    
    /**
     * 공통서비스 전화번호(2014-07-07)<br>
     * 020, ..., 090 같이 셋째 자리가 0인 번호는 통신망과 상관 없이 공통적으로 사용할 수 있는 서비스를 위해서 사용된다.
     */
    public static final String COMN_TELNO_PATTERN = "[0](7|8)[0][0-9]{3,4}[0-9]{4}";
    
    /** 휴대전화번호 문자열 포맷 */
    public static final String MPNO_PATTERN = "01[0136789][0-9]{1}[0-9]{2,3}[0-9]{4}";
    
    /** 
     * 전화번호 문자열 포맷
     * 2014.08.19 패턴 18XX 추가
     */
    public static final String TELNO_PATTERN2 = "(15|16|18)[0-9]{2}[0-9]{4}";
    
    /** 메시지구분코드 SMS */
    public static final String MSG_DCD_SMS = "S";
    
    /** 메시지구분코드 LMS */
    public static final String MSG_DCD_LMS = "L";
    
    /** 메시지구분코드 EMAIL */
    public static final String MSG_DCD_EMAIL = "E";
    
    /** 보안이메일구분값 비보안 */
    public static final String SECU_EMAIL_DVSN_VL_NONSECURITY = "1";
    
    /** 보안이메일구분값 보안 */
    public static final String SECU_EMAIL_DVSN_VL_SECURITY = "2";
    
    /** 메시지 처리구분코드 실시간 */
    public static final String MSG_PRCS_OBJ_DCD_REAL_TIME = "R";
    
    /** 메시지 처리구분코드 대량배치 */
    public static final String MSG_PRCS_OBJ_DCD_BATCH = "B";
    
    

	/** 초성 */
    private static final char[] CHO = 
			/*ㄱ ㄲ ㄴ ㄷ ㄸ ㄹ ㅁ ㅂ ㅃ ㅅ ㅆ ㅇ ㅈ ㅉ ㅊ ㅋ ㅌ ㅍ ㅎ */
		{0x3131, 0x3132, 0x3134, 0x3137, 0x3138, 0x3139, 0x3141, 0x3142, 0x3143, 0x3145,
			0x3146, 0x3147, 0x3148, 0x3149, 0x314a, 0x314b, 0x314c, 0x314d, 0x314e};
	/** 중성 */
    private static final char[] JUN = 
			/*ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ*/
		{0x314f, 0x3150, 0x3151, 0x3152, 0x3153, 0x3154, 0x3155, 0x3156, 0x3157, 0x3158,
			0x3159, 0x315a, 0x315b, 0x315c, 0x315d, 0x315e, 0x315f, 0x3160,	0x3161,	0x3162,
			0x3163};
			/*X ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ*/
    /** 종성 */
//	private static final char[] JON = 
//		{0x0000, 0x3131, 0x3132, 0x3133, 0x3134, 0x3135, 0x3136, 0x3137, 0x3139, 0x313a,
//			0x313b, 0x313c, 0x313d, 0x313e, 0x313f, 0x3140, 0x3141, 0x3142, 0x3144, 0x3145,
//			0x3146, 0x3147, 0x3148, 0x314a, 0x314b, 0x314c, 0x314d, 0x314e};
    
    
    private static final String[] bnkCdArray = new String[]{
    	"002"	//산업은행
    	,"020"	//우리은행
    };
    
    /**
     * 입금 전용 모계좌
     */
    public static final int DPS_MO_ACT = 0;
    
    /**
     * 지급 전용 모계좌
     */
    public static final int PAY_MO_ACT = 1;
    
	/**
	 * <pre>
	 * 보험연령 계산(1988년 이전)
	 * </pre>
	 * @param String	argFmYmd (YYYYMMDD)
	 * @param String	argToYmd (YYYYMMDD)
	 * @return int
	 * @throws ApplicationException
	 */
	private static int getCaclInsAgeBefore1988(String argFmYmd, String argToYmd)
	{
		String	strFmYmdYy	= argFmYmd.substring(0, 4);	// 시작일자(년)
		String	strFmYmdMm	= argFmYmd.substring(4, 6);	// 시작일자(월)
		String	strToYmdYy	= argToYmd.substring(0, 4);	// 종료일자(년)
		String	strToYmdMm	= argToYmd.substring(4, 6);	// 종료일자(월)
		int		intValue	= 0;
		
		// 총개월수 계산.
		// ( 종료일자(년) * 12 + 종료일자(월) ) - ( 시작일자(년) * 12 + 시작일자(월) )
		intValue	= ( Integer.parseInt(strToYmdYy) * 12 + Integer.parseInt(strToYmdMm) )
						- ( Integer.parseInt(strFmYmdYy) * 12 + Integer.parseInt(strFmYmdMm) );
		// 보험연령 계산.
		int		intCaclMain	= 0;
		int		intCaclSub	= 0;
		int		intInsAge		= 0;
		intCaclMain	= intValue / 12;
		intCaclSub	= intValue % 12;
		
		// 나머지 값이 5 보다 큰 경우에는 몫 + 1 을, 5 보다 작다면 몫을 보험연령으로 한다. 
		if ( intCaclSub > 5 ) { intCaclMain++; }
		//
		intInsAge	= intCaclMain;

        return intInsAge;
	}

	/**
	 * <pre>
	 * 보험연령 계산(1988년 이후)
	 * </pre>
	 * @param String	argFmYmd (YYYYMMDD)
	 * @param String	argToYmd (YYYYMMDD)
	 * @return int
	 * @throws ApplicationException
	 */
	private static int getCaclInsAgeAfter1988(String argFmYmd, String argToYmd)
	{
		String	strFmYmdYy	= argFmYmd.substring(0, 4);	// 시작일자(년)
		String	strFmYmdMm	= argFmYmd.substring(4, 6);	// 시작일자(월)
		String	strToYmdYy	= argToYmd.substring(0, 4);	// 종료일자(년)
		String	strToYmdMm	= argToYmd.substring(4, 6);	// 종료일자(월)
		int		intFmYmdTot	= 0;
		int		intToYmdTot	= 0;
		int		intCaclMain	= 0;
		int		intInsAge	= 0;
		
		// 시작일자(년) * 12 + 시작일자(월)
		intFmYmdTot	= Integer.parseInt(strFmYmdYy) * 12 + Integer.parseInt(strFmYmdMm);
		// 종료일자(년) * 12 + 종료일자(월)
		intToYmdTot	= Integer.parseInt(strToYmdYy) * 12 + Integer.parseInt(strToYmdMm);
		
		if ( Integer.parseInt(argFmYmd) > Integer.parseInt(argToYmd) ) {
			intToYmdTot += 1200;
		}
		
		intCaclMain = intToYmdTot - intFmYmdTot;
		intInsAge = ( (intCaclMain + 6) / 12 );

		return	intInsAge;
	}

	/**
	 * <pre>
	 * 연령계산 : FM_DATE와 TO_DATE로 연령을 계산한다
	 * </pre>
	 * @param	String		argFmYmd 시작일자 (YYYYMMDD)
	 * @param	String		argToYmd 종료일자 (YYYYMMDD)
	 * @return	int[]		intWkInsAge[0]	보험연령
	 *         			    intWkInsAge[1]	법연령
	 *                      intWkInsAge[2]	학년연령
	 * @throws ApplicationException
	 */
	public static int[]  getCaclAge(	String argFmYmd, String argToYmd)
			throws ApplicationException
	{

		boolean	boolFmDate;
		boolean	boolToDate;

		String	strFmYmdYy	= "";	// 시작일자(년)
		String	strFmYmdMm	= "";	// 시작일자(월)
		String	strFmYmdDd	= "";	// 시작일자(일)
		String	strToYmdYy	= "";	// 종료일자(년)
		String	strToYmdMm	= "";	// 종료일자(월)
		String	strToYmdDd	= "";	// 종료일자(일)
		int intFmLast		= 0;
		int	intToLast		= 0;

		int	intWkLastDay	= 0;	// 입력받은 날짜의 마지막 일수
		int intDay      	= 0;	// 말일자
		int	intWkLast    	= 0;

		// 리턴용.
		int intInsAge		= 0;		// 보험연령(insr_age)
		int intLawAge		= 0;		// 법률연령(law_age)
		int intSchAge		= 0;		// 학년연령(sch_age)
		int intWkAge[]		= new int[3];

		try {

		    // 1. TO_DATE 날짜 체크
			intWkLastDay	= 0;
			intDay				= 0;
			// 일자의 날자형식 유효성체크.( 날짜 형식이 유효할 경우 TRUE )
			boolToDate = DateUtils.isValidDate(argToYmd, DateUtils.EMPTY_DATE_TYPE);
			// APCME0001 : 디폴트  날짜 포맷은 "YYYYMMDD" 입니다.
			if (!boolToDate) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			//
			intWkLastDay	= Integer.parseInt(argToYmd.substring(6));
			// 말일자 산출
			intDay = DateUtils.getDaysOfTheMonth(argToYmd);
			
			if ( intWkLastDay == intDay ) { intWkLast = 1; } 
			else { intWkLast = 0; }
			
			intToLast	= intWkLast;
		        
		    /* FM_DATE 날짜 체크*/
			intWkLastDay	= 0;
			intDay				= 0;
			// 1. 일자의 날자형식 유효성체크.( 날짜 형식이 유효할 경우 TRUE )
			boolFmDate = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE); 
			// APCME0001 : 디폴트  날짜 포맷은 "YYYYMMDD" 입니다.
			if (!boolFmDate) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			//
			intWkLastDay	= Integer.parseInt(argFmYmd.substring(6));
			// 말일자 산출
			intDay = DateUtils.getDaysOfTheMonth(argFmYmd);
			
			if ( intWkLastDay == intDay ) { intWkLast = 1; }
			else { intWkLast = 0; }
			
			intFmLast	= intWkLast;

			// 1-3. 시작일자와 종료일자의 날짜형식 유효성체크가 끝나면
			//        계산을 위한 년월일 분리작업을 수행한다.
			strFmYmdYy	= argFmYmd.substring(0, 4);
			strFmYmdMm	= argFmYmd.substring(4, 6);
			strFmYmdDd	= argFmYmd.substring(6);
			strToYmdYy	= argToYmd.substring(0, 4);
			strToYmdMm	= argToYmd.substring(4, 6);
			strToYmdDd	= argToYmd.substring(6);

			// 2. 보험연령 계산
			int		intWkInsFmYmdDd		= 0;	// 시작일자(일)
			int		intWkInsToYmdYear	= 0;	// 종료일자(년)
			int		intWkInsToYmdMon	= 0;	// 종료일자(월)
			int		intWkInsToYmdDd		= 0;	// 종료일자(일)
			intWkInsFmYmdDd	    = Integer.parseInt(strFmYmdDd);
			intWkInsToYmdYear	= Integer.parseInt(strToYmdYy);
			intWkInsToYmdMon	= Integer.parseInt(strToYmdMm);
			intWkInsToYmdDd		= Integer.parseInt(strToYmdDd);
			//
			if ( Integer.parseInt(argToYmd) < 19880100 ) {
				intInsAge = getCaclInsAgeBefore1988(argFmYmd, argToYmd);
			} else {
				if ( ( (intFmLast == 1) && (intToLast == 1) ) || (intToLast == 1) ) {
					intInsAge = getCaclInsAgeAfter1988(argFmYmd, argToYmd);
				} else {
					//
					
					if ( intWkInsFmYmdDd > intWkInsToYmdDd ) {
						intWkInsToYmdMon--;
					}
					String	strWkToDate = "";
					strWkToDate = StringUtils.lpad(String.valueOf(intWkInsToYmdYear), 4, "0");
					strWkToDate = strWkToDate + StringUtils.lpad(String.valueOf(intWkInsToYmdMon), 2, "0");
					strWkToDate = strWkToDate + StringUtils.lpad(String.valueOf(intWkInsToYmdDd), 2, "0");
					intInsAge = getCaclInsAgeAfter1988(argFmYmd, strWkToDate);
					
					// 시작일자가 종료일자 보다 한달이전일때에는 보험연령이 100 으로 되는 현상이 발생함
					if (Integer.parseInt(argFmYmd) >= Integer.parseInt(strWkToDate)) {
						if (argFmYmd.length()==8 && strWkToDate.length()==8) {
							intInsAge = 0;
						}
					}
				}
			}

			// 3. 법연령 계산
			int	intWkLawFmYmdYy	= 0;	// 시작일자
			int	intWkLawFmYmdMm	= 0;
			int	intWkLawFmYmdDd	= 0;
			int	intWkLawToYmdYy	= 0;	// 종료일자
			int	intWkLawToYmdMm	= 0;
			int	intWkLawToYmdDd	= 0;
			int	intWkLawFmYmdTotMmCnt	= 0;	// 시작일자 개월수 환산
			int	intWkLawToYmdTotMmCnt	= 0;	// 종료일자 개월수 환산
			int	intWkLawValue				= 0;
			
			// 시작일자
			intWkLawFmYmdYy	= Integer.parseInt(strFmYmdYy);
			intWkLawFmYmdMm	= Integer.parseInt(strFmYmdMm);
			intWkLawFmYmdDd	= Integer.parseInt(strFmYmdDd);
			// 종료일자
			intWkLawToYmdYy	= Integer.parseInt(strToYmdYy);
			intWkLawToYmdMm	= Integer.parseInt(strToYmdMm);
			intWkLawToYmdDd	= Integer.parseInt(strToYmdDd);
			//
			if ( intWkLawFmYmdDd > intWkLawToYmdDd ) {
				intWkLawToYmdMm--;
			}

			intWkLawFmYmdTotMmCnt	= intWkLawFmYmdYy * 12 + intWkLawFmYmdMm;	// 시작일자 개월수환산
			intWkLawToYmdTotMmCnt	= intWkLawToYmdYy * 12 + intWkLawToYmdMm;	// 종료일자 개월수환산
			if ( Integer.parseInt(argFmYmd) > Integer.parseInt(argToYmd) ) {
				intWkLawToYmdTotMmCnt += 1200;
			}

			intWkLawValue	= intWkLawToYmdTotMmCnt - intWkLawFmYmdTotMmCnt;

			intLawAge	= intWkLawValue / 12;

			// 4. 학년연령 계산
			int	intWkAgebabyFmYmdYy	= 0;	// 시작일자
			int	intWkAgebabyFmYmdMm	= 0;
			int	intWkAgebabyToYmdYy	= 0;	// 종료일자
			int	intWkAgebabyToYmdMm	= 0;
			//
			int	intWkAgebabyValue			= 0;
			// 시작일자
			intWkAgebabyFmYmdYy	= Integer.parseInt(strFmYmdYy);
			intWkAgebabyFmYmdMm	= Integer.parseInt(strFmYmdMm);
			// 종료일자
			intWkAgebabyToYmdYy	= Integer.parseInt(strToYmdYy);
			intWkAgebabyToYmdMm	= Integer.parseInt(strToYmdMm);
			//
			if ( intWkAgebabyFmYmdMm == 1 || intWkAgebabyFmYmdMm == 2 ) {
				if ( intWkAgebabyToYmdMm == 1 || intWkAgebabyToYmdMm == 2 ) {
					intWkAgebabyValue = intWkAgebabyToYmdYy - intWkAgebabyFmYmdYy - 1;
				} else {
					intWkAgebabyValue = intWkAgebabyToYmdYy - intWkAgebabyFmYmdYy;
				}
			} else {
				if ( intWkAgebabyToYmdMm == 1 || intWkAgebabyToYmdMm == 2 ) {
					intWkAgebabyValue = intWkAgebabyToYmdYy - intWkAgebabyFmYmdYy - 2;
				} else {
					intWkAgebabyValue = intWkAgebabyToYmdYy - intWkAgebabyFmYmdYy - 1;
				}
			}
			if ( intWkAgebabyValue < 0 ) {
				intSchAge = 0;
			} else {
				intSchAge = intWkAgebabyValue;
			}

			// int 배열로 넘길 변수 세팅.
			intWkAge[0]	= intInsAge;
			intWkAge[1]	= intLawAge;
			intWkAge[2]	= intSchAge;

		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}

		return intWkAge;

	}
	
	
	/**
	 * <pre>
	 * 보험연령계산 : 입력된 주민번호와 계약일자로 보험연령,법률연령,학년연령 산출
	 * </pre>
	 * @param	String		argRrno (주민등록번호 13 자리 )
	 * @param	String		argToYmd (To 일자 : YYYYMMDD)
	 * @return	int[]		intWkInsAge[0]	보험연령
	 *         			    intWkInsAge[1]	법연령
	 *                      intWkInsAge[2]	학년연령
	 * @throws ApplicationException
	 */

	public static int[]  getCaclInsrAge(String argRrno, String argToYmd)
			throws ApplicationException
	{

		boolean	bValidToYmd;					// TO_DATE 유효성 체크.
		String		strNfpRrno			= "";		// 입력받은 주민등록번호 앞 6자리.
		String		strGndrCd			= "";		// 성별구분코드. (1 자리)
		String		strBrdtY2Digit		= "";		// 생년 앞두자리. (2 자리)
		String		strSsnBrdtYMD		= "";		// 세기 + 주민번호 생년월일 (8 자리)
		String		strBrdtY			= "";		// 생년월일의 생년. (4 자리)
		String		strBrdtM			= "";		// 생년월일의 생월. (2 자리)
		String		strBrdtD			= "";		// 생년월일의 생일. (2 자리)
		int			intBrdtY			= 0;		// 생년월일의 생년. (4 자리)
		int			intBrdtM			= 0;		// 생년월일의 생월. (2 자리)
		int			intBrdtD			= 0;		// 생년월일의 생일. (2 자리)
		String		strToYY				= "";		// TO_DATE의 년. (4 자리)
		String		strToDD				= "";		// TO_DATE의 일. (2 자리)
		int			intToYY				= 0;		// TO_DATE의 년. (4 자리)
		int			intToDD				= 0;		// TO_DATE의 일. (2 자리)
		int			intLastDate			= 0;		// 계약일자의 말일자. (2 자리)
		// 작업용.
		int			intTmpCtrdtM1		= 0;		// TO_DATE의 월. (2 자리)
		int			intTmpCtrdtM2		= 0;		// TO_DATE의 월. (2 자리)
		int			intTmpCtrdtM3		= 0;		// TO_DATE의 월. (2 자리)
		// 리턴용.
		int			intInsAge			= 0;		// 보험연령(insr_age)
		int			intLawAge			= 0;		// 법률연령(law_age)
		int			intSchAge			= 0;		// 학년연령(sch_age)
		int			intWkInsAge[]		= new int[3];

		try {
			// 1-1. TO_DATE의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidToYmd = DateUtils.isValidDate(argToYmd, DateUtils.EMPTY_DATE_TYPE);
			// APCME0001 : 디폴트 년월 포맷은 "YYYYMM" 입니다.
			if (!bValidToYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 주민번호 생년월일 앞의 세기 자리를 성별로 판단하여 채우기
			strNfpRrno	= argRrno.substring(0, 6);	// 주민번호 생년월일.
			strGndrCd	= argRrno.substring(6, 7);	// 성별구분코드.
			switch(Integer.parseInt(strGndrCd)) {
				case 0:
					strBrdtY2Digit	= "18"; break;
				case 9:
					strBrdtY2Digit	= "18"; break;
				case 1:
					strBrdtY2Digit	= "19"; break;
				case 2:
					strBrdtY2Digit	= "19"; break;
				case 3:
					strBrdtY2Digit	= "20"; break;
				case 4:
					strBrdtY2Digit	= "20"; break;
				case 5:
					strBrdtY2Digit	= "19"; break;	// 외국인
				case 6:
					strBrdtY2Digit	= "19"; break;	// 외국인
				case 7:
					strBrdtY2Digit	= "20"; break;	// 외국인
				case 8:
					strBrdtY2Digit	= "20"; break;	// 외국인
				default:
					// APCME0002 : 입력값 오류 ! 확인요망.
					throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "주민등록번호" , "주민등록번호 유효"});
			}
			strSsnBrdtYMD	= strBrdtY2Digit + strNfpRrno;	// 세기 + 주민번호 생년월일 (8 자리)

			strBrdtY	= strSsnBrdtYMD.substring(0, 4);	// 생년월일의 생년.
			strBrdtM	= strSsnBrdtYMD.substring(4, 6);	// 생년월일의 생월.
			strBrdtD	= strSsnBrdtYMD.substring(6);		// 생년월일의 생일.
			//
			intBrdtY	= Integer.parseInt(strBrdtY);
			intBrdtM	= Integer.parseInt(strBrdtM);
			intBrdtD	= Integer.parseInt(strBrdtD);

			strToYY			= argToYmd.substring(0, 4);									// TO_DATE의 년.
			intTmpCtrdtM1	= Integer.parseInt(argToYmd.substring(4, 6));
			intTmpCtrdtM2	= Integer.parseInt(argToYmd.substring(4, 6));
			intTmpCtrdtM3	= Integer.parseInt(argToYmd.substring(4, 6));
			strToDD			= argToYmd.substring(6);									// TO_DATE의 일.
			//
			intToYY			= Integer.parseInt(strToYY);
			intToDD			= Integer.parseInt(strToDD);

			// 보험연령계산
			int		intWkMm	= 0;	// 계산용 월.
			int		intWkMm2 = 0;	// 계산용 월.
			//
			// OLD-AGE-CALC-RTN ( 19871231  까지 )
			if ( Integer.parseInt(argToYmd) < 19880100 ) {
				// 월수 계산.
				intWkMm		= ( intToYY * 12 + intTmpCtrdtM1 ) - ( intBrdtY * 12 + intBrdtM );
				intInsAge	= intWkMm / 12;								// 보험연령.
				if ( (intWkMm % 12) > 5 ) { intInsAge++; }
			}
			// NEW-AGE-CALC-RTN  ( 19880101  까지 )
			else if ( Integer.parseInt(argToYmd) > 19871231 && Integer.parseInt(argToYmd) < 20080414 ) {
				intLastDate = DateUtils.getDaysOfTheMonth(argToYmd);	// 말일자구하기.
				
				if ( intToDD < intLastDate ) {
					if ( intBrdtD > intToDD ) {intTmpCtrdtM1--; }
				}
				// 월수 계산.
				intWkMm		= ( intToYY * 12 + intTmpCtrdtM1 ) - ( intBrdtY * 12 + intBrdtM );
				intInsAge	= ( intWkMm + 6 ) / 12;		// 보험연령.
			}
			// NEW 1 -AGE-CALC-RTN  ( 20080414  까지 )
			else {
				intWkMm2 = intTmpCtrdtM1 - intBrdtM;
				
				if ( intWkMm2 > 6) {
					intInsAge = intToYY - intBrdtY + 1;
				} else if ( intWkMm2 == 6) {
					if( intToDD < intBrdtD ){
						intInsAge = intToYY - intBrdtY;
					}else{
						intInsAge = intToYY - intBrdtY + 1;
					}
				} else if ( intWkMm2 == -6) {
					if( intToDD < intBrdtD ){
						intInsAge = intToYY - intBrdtY - 1;
					}else{
						intInsAge = intToYY - intBrdtY;
					}
				} else if( intWkMm2 < -6 ) {
					intInsAge = intToYY - intBrdtY - 1;					
				} else {
					intInsAge = intToYY - intBrdtY;
				}
			}

			// LAW-AGE-CALC-RTN
			// 법률연령 계산(intLawAge) : (law_age)
			if ( intBrdtD > intToDD ) { intTmpCtrdtM2--; }
			intWkMm		= ( intToYY * 12 + intTmpCtrdtM2 ) - ( intBrdtY * 12 + intBrdtM );
			intLawAge	= intWkMm / 12;

			// BABY-AGE-CALC-RTN
			// 학년연령 계산(intSchAge) : (sch_age)
			intSchAge = intToYY - intBrdtY;
			if ( intBrdtM < 3 ) {
				if ( intTmpCtrdtM3 < 3 )	{ intSchAge--; }
			} else {
				if ( intTmpCtrdtM3 < 3 )	{ intSchAge -= 2; }
				else					{ intSchAge--; }
			}
			
			// 학년연령이 음수이면 0 으로 세팅한다.
			if ( intSchAge < 0 ) { intSchAge = 0; }

			// int 배열로 넘길 변수 세팅.
			intWkInsAge[0]	= intInsAge;
			intWkInsAge[1]	= intLawAge;
			intWkInsAge[2]	= intSchAge;

			return intWkInsAge;

		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}

	}
	
	/**
	 * <pre>
	 * 두음법칙.
	 * </pre>
	 * @param	String	argInName ( 성명 )
	 * @return	String	strOutName ( 성명 )
	 * @throws ApplicationException
	 */
	public static String setDuem(String argInName) throws ApplicationException
	{

		String	strRtnDuem = "";

		try
		{
			// 입력값이 한글인지 체크한다.
			// APCME0002 : 입력값이 오류입니다.
//			if ( StringUtils.isHangul(argInName, true) == false ) { 
//				throw new ApplicationException( "APCME0003", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "이름" });
//			}

			List<Map<String, Integer>> list = new ArrayList<Map<String, Integer>>();

			for(int i = 0 ; i < argInName.length();i++)
			{
				Map<String, Integer> map = new HashMap<String, Integer>();
				char test = argInName.charAt(i);
							
				if(test >= 0xAC00)
				{
					char uniVal = (char) (test - 0xAC00);
					
					char cho = (char) (((uniVal - (uniVal % 28))/28)/21);
					char jun = (char) (((uniVal - (uniVal % 28))/28)%21);
					char jon = (char) (uniVal %28);
					
					//'ㄹ' → 'ㅇ': '랴, 려, 료, 류, 례, 리' → '야, 여, 요, 유, 예, 이'로 바뀜.
					
					if ( CHO[cho] == 'ㄹ'&& 
									(JUN[jun] == 'ㅑ' || JUN[jun] == 'ㅕ' || JUN[jun] == 'ㅛ' || 
									JUN[jun] == 'ㅠ' || JUN[jun] == 'ㅖ' || JUN[jun] == 'ㅣ') )  cho = 0xb ;
					
					// 'ㄴ' -> 'ㅇ' : '니, 냐, 녀, 뇨, 뉴' → '이,야,여,요,유'로 바뀜.
					if ( CHO[cho] == 'ㄴ'&& 
							(JUN[jun] == 'ㅣ' || JUN[jun] == 'ㅑ' || JUN[jun] == 'ㅕ' || 
							JUN[jun] == 'ㅛ' || JUN[jun] == 'ㅠ' ) )  cho =  0xb ;
					
					//'ㄹ' → 'ㄴ': '라, 로, 루, 르, 래, 뢰' → '나, 노, 누, 느, 내, 뇌'로 바뀜.
					if ( CHO[cho] == 'ㄹ'&& 
							(JUN[jun] == 'ㅏ' || JUN[jun] == 'ㅗ' || JUN[jun] == 'ㅜ' || 
							JUN[jun] == 'ㅡ' || JUN[jun] == 'ㅐ' || JUN[jun] == 'ㅚ') )  cho = 0x2 ;
					
					map.put("cho", (int) cho);
					map.put("jun", (int) jun);
					map.put("jon", (int) jon);
				} else {
					map.put("mum", (int) test);
				}
				
				list.add(map);
			}
			
			for(int i = 0; i < list.size() ; i++)
			{
				// 한글
				if ((list.get(i)).get("cho") != null) {
					
					int a = (int)(list.get(i)).get("cho");
					int b = (int)(list.get(i)).get("jun");
					int c = (int)(list.get(i)).get("jon");
					
					char temp = (char)(0xAC00 + 28 * 21 *(a) + 28 * (b) + (c) );
					
					strRtnDuem = strRtnDuem.concat(String.valueOf(temp));
				}
				
				// 한글외 문자
				if ((list.get(i)).get("mum") != null) {
				
					int mum = (int)(list.get(i)).get("mum");
					
					char temp2 = (char) mum;
					
					strRtnDuem = strRtnDuem.concat(String.valueOf(temp2));
				}				
				
			}
			
			return strRtnDuem;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 아리비아숫자 한글로 컨버젼.
	 * </pre>
	 * @param  String argAmt
	 * @return String 한글금액
	 * @throws ApplicationException
	 */
	public static String convertHangul(String argAmt)  throws ApplicationException {
		
		String[] han1 = {"","일","이","삼","사","오","육","칠","팔","구"};
		String[] han2 = {"","십","백","천"};
		String[] han3 = {"","만","억","조","경"};
		
		StringBuffer result = new StringBuffer();
		
		try {
		
			// 입력값이 숫자인지 체크한다.
			// APCME0002 : 입력값이 오류입니다.
			if (!StringUtils.isDigit(argAmt)) { 
				throw new ApplicationException( "APCME0002", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "금액" });
			}
			
			int len = argAmt.length();
			for(int i=len-1; i>=0; i--){
				
				//문자열 1개를 잘라서 add
				result.append(han1[Integer.parseInt(argAmt.substring(len-i-1, len-i))]);
				
				//해당 문자열이 0보다 크면 '십', '백', '천' 단위를 붙임
				if(Integer.parseInt(argAmt.substring(len-i-1, len-i)) > 0)
					result.append(han2[i%4]);
				
				//자리수가 4로 나누어 떨어지는 위치에서 4자리의 숫자를 잘라서 0보다 크면 '만', '억', '조', '경' 단위를 붙임
				if(i%4 == 0){
					int strtIdx = (len-i)-4 < 0 ? 0 : (len-i)-4;
					if(Integer.parseInt(argAmt.substring(strtIdx, (len-i))) > 0)
						result.append(han3[i/4]);
				}
			}           
			
			return result.toString(); 
			
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
		
	} 
	
	/**
	 * <pre>
	 * 주민등록번호 체크
	 * </pre>
	 * @param argRrno 주민등록번호
	 * @return boolean 주민등록번호 유효여부
	 * @throws ApplicationException
	 */
	public static boolean  isValidRrno(String argRrno)
	{

		boolean bRtnHldyYn	= false;
		
		String		strNfpRrno			= "";		// 입력받은 주민등록번호 앞 6자리.
		String		strGndrCd			= "";		// 성별구분코드. (1 자리)
		String		strBrdtY2Digit		= "";		// 생년 앞두자리. (2 자리)
		String		strSsnBrdtYMD		= "";		// 세기 + 주민번호 생년월일 (8 자리)

		// 입력값이 숫자인지 체크한다.
		if (!StringUtils.isDigit(argRrno)) return false;

		// 주민등록번호 패턴이 검사 패턴 검사
		bRtnHldyYn = StringUtils.isFormattedString(argRrno, StringUtils.SSSNO_PATTERN);
		
		if (bRtnHldyYn) {
			strNfpRrno	= argRrno.substring(0, 6);	// 주민번호 생년월일.
			strGndrCd	= argRrno.substring(6, 7);	// 성별구분코드.
			switch(Integer.parseInt(strGndrCd)) {
				case 0:
					strBrdtY2Digit	= "18"; break;
				case 9:
					strBrdtY2Digit	= "18"; break;
				case 1:
					strBrdtY2Digit	= "19"; break;
				case 2:
					strBrdtY2Digit	= "19"; break;
				case 3:
					strBrdtY2Digit	= "20"; break;
				case 4:
					strBrdtY2Digit	= "20"; break;
				default:
					return false;	
			}
			strSsnBrdtYMD	= strBrdtY2Digit + strNfpRrno;	// 세기 + 주민번호 생년월일 (8 자리)
		
			if (!DateUtils.isValidDate(strSsnBrdtYMD, DateUtils.EMPTY_DATE_TYPE)) return false;

			//'세기 + 주민번호' 와 오늘날짜를 비교하여 미래일자이면 유효하지 않은것으로 판단(2015-03-25 김정국)
			if(strSsnBrdtYMD.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0)
				return false;
	        
	        int intSum = 0;
	        
	        int[] intNum = {2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5};
	 
	        int intLast = Integer.parseInt(argRrno.substring(12));
	        
	        for(int i = 0; i < 12; i++) {
	 
	            intSum += Integer.parseInt(argRrno.substring(i, i+1)) * intNum[i];
	 
	        }
	        
	        if ((11 - intSum % 11) % 10 == intLast) bRtnHldyYn = true ;
	        else bRtnHldyYn = false;

		}

		return bRtnHldyYn;
	}

	/**
	 * <pre>
	 * 외국인등록번호 체크
	 * </pre>
	 * @param argFrgnrRrno  외국인등록번호
	 * @return boolean 외국인등록번호 유효여부
	 * @throws ApplicationException
	 */
	public static boolean  isValidFrgnrRrno(String argFrgnrRrno) 
	{

		boolean bRtnHldyYn = false;
		
		String		strNfpRrno			= "";		// 입력받은 주민등록번호 앞 6자리.
		String		strGndrCd			= "";		// 성별구분코드. (1 자리)
		String		strBrdtY2Digit		= "";		// 생년 앞두자리. (2 자리)
		String		strSsnBrdtYMD		= "";		// 세기 + 주민번호 생년월일 (8 자리)

		// 입력값이 숫자인지 체크한다.
		if (!StringUtils.isDigit(argFrgnrRrno))  return false;

		// 외국인등록번호 패턴이 검사 패턴 검사
		bRtnHldyYn = StringUtils.isFormattedString(argFrgnrRrno, FRGNRRRNO_PATTERN);
		
		if (bRtnHldyYn) {
			
			strNfpRrno	= argFrgnrRrno.substring(0, 6);	// 주민번호 생년월일.
			strGndrCd	= argFrgnrRrno.substring(6, 7);	// 성별구분코드.
			switch(Integer.parseInt(strGndrCd)) {
				case 5:
					strBrdtY2Digit	= "19"; break;	// 외국인
				case 6:
					strBrdtY2Digit	= "19"; break;	// 외국인
				case 7:
					strBrdtY2Digit	= "20"; break;	// 외국인
				case 8:
					strBrdtY2Digit	= "20"; break;	// 외국인
				default:
					return false;	
			}
			strSsnBrdtYMD	= strBrdtY2Digit + strNfpRrno;	// 세기 + 주민번호 생년월일 (8 자리)
		
			if (!DateUtils.isValidDate(strSsnBrdtYMD, DateUtils.EMPTY_DATE_TYPE)) return false;
			
			//'세기 + 주민번호' 와 오늘날짜를 비교하여 미래일자이면 유효하지 않은것으로 판단(2015-03-25 김정국)
			if(strSsnBrdtYMD.compareTo(DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE)) > 0)
				return false;

	        if((Integer.parseInt(argFrgnrRrno.substring(7, 8)) * 10 + Integer.parseInt(argFrgnrRrno.substring(8, 9))) % 2 != 0) {
	 
	            return false;
	 
	        }
	 
	        int intSum = 0;
	 
	        int[] intNum = {2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5};
	 
	        int intLast = Integer.parseInt(argFrgnrRrno.substring(12));
	 
	        for(int i = 0; i < 12; i++) {
	 
	            intSum += Integer.parseInt(argFrgnrRrno.substring(i, i+1)) * intNum[i];
	 
	        }
	        
	        intSum = ((11 - intSum % 11) % 10) + 2;
	        if(intSum >= 10) intSum -= 10;

	        if (intSum == intLast) bRtnHldyYn = true ;
	        else bRtnHldyYn = false;
		}

		return bRtnHldyYn;
	}	

	
	/**
	 * <pre>
	 * 사업자등록번호 체크
	 * </pre>
	 * @param argBzno 사업자등록번호
	 * @return boolean 사업자등록번호 유효여부
	 * @throws ApplicationException
	 */
	public static boolean  isValidBzno(String argBzno) 
	{

		boolean bRtnHldyYn = false;

		// 입력값이 숫자인지 체크한다.
		if (!StringUtils.isDigit(argBzno))  return false;

		// 사업자등록번호 패턴이 검사 패턴 검사
		bRtnHldyYn = StringUtils.isFormattedString(argBzno, ERNO_PATTERN);

		if (bRtnHldyYn) {
			int intSum =  Integer.parseInt(argBzno.substring(0, 1));
			 
	        int[] intNum = {0, 3, 7, 1, 3, 7, 1, 3};
	 
	        for(int i = 1; i < 8; i++) intSum += (Integer.parseInt(argBzno.substring(i, i+1)) * intNum[i]) % 10;
	 
	        intSum += Math.floor((int)(Integer.parseInt(argBzno.substring(8, 9)) * 5 / 10));
	 
	        intSum += (Integer.parseInt(argBzno.substring(8, 9)) * 5) % 10 + Integer.parseInt(argBzno.substring(9, 10));
	 
	        if (intSum % 10 == 0)  bRtnHldyYn = true ;
	        else bRtnHldyYn = false;
		}

		return bRtnHldyYn;
	}
	
	/**
	 * <pre>
	 * 전화번호 체크
	 * </pre>
	 * @param argTelno 전화번호
	 * @return boolean 전화번호 유효여부
	 * @throws ApplicationException
	 */
	public static boolean  isValidTelno(String argTelno) 
	{

		boolean bRtnHldyYn = false;

		// 입력값이 숫자인지 체크한다.
		if (!StringUtils.isDigit(argTelno))  return false;

		// 일반 전화번호 패턴이 검사 패턴 검사
		bRtnHldyYn = StringUtils.isFormattedString(argTelno, TELNO_PATTERN);
		
		// 결과가 거짓이면 고객센터용 전화번호인지 체크
		if (!bRtnHldyYn) bRtnHldyYn = StringUtils.isFormattedString(argTelno, TELNO_PATTERN2);
		
		// 결과가 거짓이면 공통서비스용 전화번호인지 체크
		if (!bRtnHldyYn) bRtnHldyYn = StringUtils.isFormattedString(argTelno, COMN_TELNO_PATTERN);

		return bRtnHldyYn;
	}
	
	/**
	 * <pre>
	 * 휴대전화번호 체크
	 * </pre>
	 * @param argMpno 휴대전화번호
	 * @return boolean 휴대전화번호 유효여부
	 * @throws ApplicationException
	 */ 
	public static boolean  isValidMpno(String argMpno) 
	{

		boolean bRtnHldyYn = false;
		
		// 입력값이 숫자인지 체크한다.
		if (!StringUtils.isDigit(argMpno))  return false;

		// 휴대전화번호 패턴이 검사 패턴 검사
		bRtnHldyYn = StringUtils.isFormattedString(argMpno,MPNO_PATTERN);

		return bRtnHldyYn;

	}
	
	/**
	 * GIRO 출력용 format으로 데이터를 변환함.
	 * <pre>
	 * ex).
	 *    +000000020
	 *    -000000100
	 * </pre>
	 * @param data 출력하려는 원본 데이터
	 * @param width 부호를 포함한 출력자리수
	 * @return GIRO 출력용 데이터 format
	 */
    public static String toGIRO(BigDecimal data, int width) {
        long lvalue  = data.longValue();
        
        return toGIRO(lvalue, width);
    }

	/**
	 * GIRO 출력용 format으로 데이터를 변환함.
	 * <pre>
	 * ex).
	 *     +20
	 *    -100
	 * </pre>
	 * @param data 출력하려는 원본 데이터
	 * @param width 부호를 포함한 출력자리수
	 * @return GIRO 출력용 데이터 format
	 */
    public static String toGIRO(long data, int width) {
        boolean         sign = true;
        String          str  = null;
        StringBuffer    buf  = new StringBuffer(32);
        int				len;
        
        if(width < 0) {
            throw new IllegalArgumentException("데이터 폭이 잘못 설정되었습니다. 데이터 폭은 0이상이어야 합니다.");
        }
        if(width == 0) {
            return "";
        }

        if(data < 0) {
            data *= -1;
            sign  = false;
        }
        str = String.valueOf(data);
        len = str.length() + 1;
        
        for(int idx = 0; idx < width - len; idx++) {
        	buf.append(' ');
        }
        if(sign) {
            buf.append('+');
        } else {
            buf.append('-');
        }
        buf.append(str);
        if(buf.length() > width) {
            buf.delete(1, 1 + buf.length() - width);
        }
        return buf.toString();
    }

    /**
	 * Number 데이터를 + 또는 - 부호를 가진 format으로 데이터를 변환함.
	 * <pre>
	 * ex).
	 *    +000000020
	 *    -000000100
	 * </pre>
	 * @param data 출력하려는 원본 데이터
	 * @param width 부호를 포함한 출력자리수
	 * @return + 또는 - 부호가 붙은 출력용 데이터 format
	 */
    public static String toSignedNumber(long data, int width) {
        boolean         sign = true;
        String          str  = null;
        StringBuffer    buf  = new StringBuffer(32);
        int				len;
        
        if(width < 0) {
            throw new IllegalArgumentException("데이터 폭이 잘못 설정되었습니다. 데이터 폭은 0이상이어야 합니다.");
        }
        if(width == 0) {
            return "";
        }

        if(data < 0) {
            data *= -1;
            sign  = false;
        }
        if(sign) {
            buf.append('+');
        } else {
            buf.append('-');
        }
        str = String.valueOf(data);
        len = str.length() + 1;
        if(len > width) {
        	throw new IllegalArgumentException("데이터 폭이 잘못 설정되었습니다. 지정한 데이터 폭은 숫자의 자리수보다 짧습니다.");
        }
        
        for(int idx = 0; idx < width - len; idx++) {
        	buf.append('0');
        }
        buf.append(str);
        if(buf.length() > width) {
            buf.delete(1, 1 + buf.length() - width);
        }
        return buf.toString();
    }
        
    /**
     * item이 items에 포함된 문자열인지를 검사한다.
     * 
     * @param item 검사하려는 문자열
     * @param items 검사할 대상 목록
     * @return items에 item 문자열과 일치하는 문자열이 있으면 true, 그렇지 않으면 false
     */
    public static boolean contains(String item, String[] items) {
    	if ( item == null ) return false;
    	
    	for(int idx = 0; idx < items.length; idx++) {
    		if(item.equals(items[idx])) {
    			return true;
    		}
    	}
    	return false;
    }
    
    /**
     * item이 itemList에 포함된 문자열인지를 검사한다.
     * 
     * @param item 검사하려는 문자열
     * @param itemList 검사할 대상 목록
     * @return itemList에 item 문자열과 일치하는 문자열이 있으면 true, 그렇지 않으면 false
     */
    public static boolean contains(String item, List<String> itemList) {
    	if ( item == null ) return false;
    	
    	for(String item2 : itemList) {
    		if(item.equals(item2)) {
    			return true;
    		}
    	}
    	return false;
    }
    
	/**
	 * 문자열과, 캐릭터셋을 받아 문자열수 계산
	 * @param input   문자열
	 * @param charset 캐릭터셋
	 * @return
	 */
    public static int getStringToByteLen(String input, String charset) {
		try {

			if (StringUtils.isEmpty(input))
				return 0;

			byte[] inputB = input.getBytes(charset);

			return inputB.length;

		} catch (UnsupportedEncodingException e) {
			return 0;
		}
	}
    
	/**
	 * 문자열을 trim 후 리턴
	 * @param  String input   문자열
	 * @return String 문자열
	 */
    public static String nullTrim(String input) {

		if (StringUtils.isEmpty(input))
			return "";
			
		return input.trim();

	}
        
	/**
	 * 문자열을 숫자형으로 변환
	 * @param input   문자열
	 * @return int
	 */
    public static int getInt(String input) {
		try {

			if (StringUtils.isEmpty(nullTrim(input)))
				return 0;

			return Integer.parseInt(input.trim());

		} catch (Exception e) {
			return 0;
		}
	}
    
	/**
	 * 문자열을 숫자형으로 변환
	 * @param input   문자열
	 * @return int
	 */
    public static BigDecimal getBigDecimal(String input) {
		try {

			if (StringUtils.isEmpty(nullTrim(input)))
				return BigDecimal.ZERO;

			return new BigDecimal(input.trim());

		} catch (Exception e) {
			return BigDecimal.ZERO;
		}
	}
    
    /**
     * 모계좌 은행코드를 <font color="red"><b>입금전용</b></font>, <b>지급전용</b> 구분에 따라서 리턴
     * <pre>
     * 사용예)
     * 
     * String dpsMoActBnkCd = BizCommUtil.getMoActBnkCd(BizCommUtil.DPS_MO_ACT);//입금 전용 모계좌 은행코드 획득<font color="red">(처리시 반드시 담당자 확인요망)</font>
     * String payMoActBnkCd = BizCommUtil.getMoActBnkCd(BizCommUtil.PAY_MO_ACT);//지급 전용 모계좌 은행코드 획득
     * 
     * </pre>
     * @param kind 입금전용, 지급전용을 나타내는 <code>int</code> 타입의 구분
     * @return {@link String} 형태의 모계좌 은행코드, 구분값 <b>kind</b>가 올바르지 않으면 공백문자열 <b>""</b>를 리턴
     */
    public static String getMoActBnkCd(final int kind) {
    	if(kind < 0 || kind > bnkCdArray.length - 1)
    		return "";
    	return bnkCdArray[kind];
    }
    
	/**
	 * 주민번호로 성별가져오기
	 * @param regNo : 주민번호
	 * @return 성별(gender) 
	 * @throws ApplicationException
	 */
	public static String getGender(String regNo) throws ApplicationException {
		
		if (StringUtils.isEmpty(regNo) || regNo.length() < 7){
			throw new ApplicationException("APBSE0009", new Object[] { "주민번호" }, new Object[] { "주민번호" });			
		}
		
		String strGndrCd	= regNo.substring(6, 7);	// 성별구분코드.
		
		String gender;
		
		switch(Integer.parseInt(strGndrCd)) {
			case 0:
				gender	= "1"; break;
			case 9:
				gender	= "2"; break;
			case 1:
				gender	= "1"; break;
			case 2:
				gender	= "2"; break;
			case 3:
				gender	= "1"; break;
			case 4:
				gender	= "2"; break;
			case 5:
				gender	= "1"; break;	// 외국인
			case 6:
				gender	= "2"; break;	// 외국인
			case 7:
				gender	= "1"; break;	// 외국인
			case 8:
				gender	= "2"; break;	// 외국인
			default:
				// APCME0002 : 입력값 오류 ! 확인요망.
				throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "주민등록번호" , "주민등록번호 유효"});
		}

		return gender;
	}    
    
}