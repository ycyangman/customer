/**
 * 
 */
package cigna.zz;

import java.util.List;

import cigna.cm.a.dbio.CMA003DBIO;
import cigna.cm.a.io.TBCMCCD005Io;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @file             cigna.zz.BizDateInfo.java
 * @filetype        java source file
 * @brief           영업일캘린더 정보를 조회한다.
 * @author          박경화
 * @version         1.0
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               박경화                 2012. 7.06.       신규 작성
 * 0.6               박경화                 2012. 7.10.       개발 완료
 * 0.9               박경화                 2012. 7.21.       Class 테스트
 * 1.0               박경화                 2012. 7.21.       단위 테스트     
 * 1.1               박경화                 2012. 8.07.       첫영업일계산,마지막영업일계산 추가
 */
/**
 * 
 *  영업일캘린더 정보를 조회하기 위한 KlafBean class
 *
 */
@KlafBean
public class BizDateInfo {
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 영업일정보 조회, 수정하는 DBIO
	 */	
	@Autowired
	private CMA003DBIO cma003dbio; 
	
	/** 계산기준 00:시작일자 제외, 종료일자 제외 */
	public static final String CALCULATION_BASIS_00 = "00";
	/** 계산기준 01:시작일자 제외, 종료일자 포함 */
	public static final String CALCULATION_BASIS_01 = "01";
	/** 계산기준 10:시작일자 포함, 종료일자 제외 */
	public static final String CALCULATION_BASIS_10 = "10";
	/** 계산기준 11:시작일자 포함, 종료일자 포함 */
	public static final String CALCULATION_BASIS_11 = "11";
	
	/** 휴일종류코드  : 평일 */
	public static final String HLDY_KCD_00 = "00";
	/** 휴일종류코드  : 임시공휴일 */
	public static final String HLDY_KCD_99 = "99";
	
	/** 휴일평일구분코드  : 평일 */
	public static final String HLDY_WKDAY_DCD_0 = "0";
	/** 휴일평일구분코드  : 휴일 */
	public static final String HLDY_WKDAY_DCD_1 = "1";

	/**
	 * <pre>
	 * 휴일여부체크
	 * </pre>
	 * @param argYmd 입력일자 (YYYYMMDD)
	 * @return boolean 휴일 여부
	 * @throws ApplicationException
	 */
	public boolean chkHldyYnBoolean(String argYmd) throws ApplicationException
	{

		boolean bRtnHldyYn;

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			boolean bValidYmd = DateUtils.isValidDate(argYmd, DateUtils.EMPTY_DATE_TYPE);
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			if (!bValidYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 2. 영업일테이블의 정보를 조회후 휴일여부를 가져온다.
			List<TBCMCCD005Io> bizDateList= this.cma003dbio.selectMultiTBCMCCD005(argYmd,argYmd,"");
			
			if ( bizDateList.size() == 1) {
				
				TBCMCCD005Io bizDateInfo = bizDateList.get(0);
				
				if (HLDY_KCD_00.equals(bizDateInfo.getHldyKcd()) ) bRtnHldyYn = false;
				else bRtnHldyYn = true;

			} else {
				
				// 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException( "KIOKI0004", null );
				 
			}
			
			return bRtnHldyYn;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 입력일자간 영업일수계산
	 * <pre>
	 * @param	String	argFmYmd( 적용시작일자 : YYYYMMDD)
	 * @param	String	argToYmd( 적용종료일자 : YYYYMMDD)
	 * @param	String	argCaclBs( 계산기준 )
	 *                             00	:	시작일자 제외, 종료일자 제외
	 *                             01	:	시작일자 제외, 종료일자 포함
	 *                             10	:	시작일자 포함, 종료일자 제외
	 *                             11	:	시작일자 포함, 종료일자 포함
	 * @return	int  일수
	 * @throws ApplicationException
	 */
	public int  getCntBizDtFromBoth(String argFmYmd, String argToYmd, String argCaclBs)
			throws ApplicationException
	{
		boolean	bValidFmYmd;
		boolean	bValidToYmd;
		String	strFrYmd		= "";
		String	strToYmd		= "";
		int		intCountBizDt	= 0;

		try
		{
			strFrYmd	= argFmYmd.trim();
			strToYmd	= argToYmd.trim();
			
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(strFrYmd, DateUtils.EMPTY_DATE_TYPE);
			if (!bValidFmYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			bValidToYmd = DateUtils.isValidDate(strToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if (!bValidToYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			if ( Integer.parseInt(strFrYmd) > Integer.parseInt(strToYmd) ) {
				//  APCME0006 : 적용종료일자는 적용시작일자보다 크거나 같아야 합니다. 
				throw new ApplicationException("APCME0006", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), strToYmd, strFrYmd } );
			}
			
			// 2. 구분값에 따라 시작일자 종료일자 셋팅
			if ( CALCULATION_BASIS_00.equals(argCaclBs) ) {					// 00	:	시작일자 제외, 종료일자 제외
				strFrYmd = DateUtils.getDateDaysAfter(1, strFrYmd);			// N 후일
				strToYmd = DateUtils.getDateDaysBefore(1, strToYmd);		// N 전일
			} else if ( CALCULATION_BASIS_01.equals(argCaclBs) ) {			// 01	:	시작일자 제외, 종료일자 포함
				strFrYmd = DateUtils.getDateDaysAfter(1, strFrYmd);			// N 후일
			} else if ( CALCULATION_BASIS_10.equals(argCaclBs) ) {			// 10	:	시작일자 포함, 종료일자 제외
				strToYmd = DateUtils.getDateDaysBefore(1, strToYmd);		// N 전일
			//} else if ( CALCULATION_BASIS_11.equals(argCaclBs) ) {			// 11	:	시작일자 포함, 종료일자 포함
				// 처리없음
			} else  if ( !CALCULATION_BASIS_11.equals(argCaclBs) ) {
				// APCME0007 : 입력조건 범위 오류
				throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계산기준", "00,01,10,11" });
			}

			// 3. 시작일자와 종료일자 사이의 영엽일정보를 영업일테이블에서 가져온다.
			List<TBCMCCD005Io> bizDateList= this.cma003dbio.selectMultiTBCMCCD005(strFrYmd,strToYmd,HLDY_KCD_00);
			
			if ( bizDateList == null || bizDateList.size() <= 0) {
				// 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException( "KIOKI0004", null );
			}

		    intCountBizDt = bizDateList.size();


			return intCountBizDt;
			
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 입력일의익영업일계산
	 * </pre>
	 * @param	String	argYmd 입력일자 (YYYYMMDD) 
	 * @return	String  영업일자 (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public String  getNxtBizDtOfInpdt(String argYmd) throws ApplicationException
	{

		boolean	bValidYmd;
		String	strSolrDt		= "";

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd = DateUtils.isValidDate(argYmd, DateUtils.EMPTY_DATE_TYPE);
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			if (!bValidYmd)  { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 2. 입력일자의 익영업일 정보를 영업일테이블에서 조회한다.
			strSolrDt = this.cma003dbio.selectOneTBCMCCD005a(argYmd,1);
			
			if (StringUtils.isEmpty(strSolrDt)) {
				// 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException( "KIOKI0004", null );
			} 

			return strSolrDt;

		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}

		}
	}
	
	/**
	 * <pre>
	 * N전영업일계산
	 * </pre>
	 * @param	String	argYmd (YYYYMMDD)
	 * @param	int		argNth
	 * @return	String  N전영업일자 (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public String  getNBfBizDt(String argYmd, int argNth) throws ApplicationException
	{

		boolean	bValidYmd;
		String	strSolrDt		= "";

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd = DateUtils.isValidDate(argYmd, DateUtils.EMPTY_DATE_TYPE);
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			if (!bValidYmd)  { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			if ( argNth < 0 ) { throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계산일수", "양의 정수" }); }

			// 2. 입력일자와 입력값 조건에 맞게 영업일테이블에서 조회후 영엽일정보를 가져온다.
			strSolrDt = this.cma003dbio.selectOneTBCMCCD005b(argYmd,argNth);
			
			if (StringUtils.isEmpty(strSolrDt)) {
				// 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException( "KIOKI0004", null );
			} 
			
			return strSolrDt;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}

	}
	
	/**
	 * <pre>
	 * N익영업일계산
	 * </pre>
	 * @param	String	argYmd (YYYYMMDD)
	 * @param	int		argNth
	 * @return	String  N익영업일자 (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public String  getNNxtBizDt(String argYmd, int argNth) throws ApplicationException
	{

		boolean	bValidYmd;
		String	strSolrDt		= "";

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd = DateUtils.isValidDate(argYmd, DateUtils.EMPTY_DATE_TYPE);
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			if (!bValidYmd)  { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			if ( argNth < 0 ) { throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계산일수", "양의 정수" }); }

			// 2. 입력일자와 입력값 조건에 맞게 영업일테이블에서 조회후 영엽일정보를 가져온다.
			strSolrDt = this.cma003dbio.selectOneTBCMCCD005a(argYmd,argNth);
			
			if (StringUtils.isEmpty(strSolrDt)) {
				// 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException( "KIOKI0004", null );
			} 

			return strSolrDt;
		} catch (Exception e) {
			
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 입력년월의 첫영업일계산
	 * </pre>
	 * @param	String	argYm 입력년월(YYYYMM)
	 * @return	String  영업일첫날 (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public String  getFirstBizDt(String argYm) throws ApplicationException
	{

		boolean	bValidYmd;
		String	strSolrDt		= "";

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd = DateUtils.isValidDate(argYm+"01", DateUtils.EMPTY_DATE_TYPE);
			// APCME0004 : 디폴트 날짜 포맷은 "YYYYMM" 입니다.
			if (!bValidYmd)  { throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "입력년월" , "YYYYMM 날짜포맷"}); }
			
			// 2. 입력일자와 입력값 조건에 맞게 영업일테이블에서 조회후 영엽일정보를 가져온다.
			strSolrDt = this.cma003dbio.selectOneTBCMCCD005c(argYm,0);
			
			if (StringUtils.isEmpty(strSolrDt)) {
				// 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException( "KIOKI0004", null );
			} 

			return strSolrDt;
		} catch (Exception e) {
			
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 영업첫날 N익영업일계산
	 * </pre>
	 * @param	String	argYm 입력년월(YYYYMM)
	 * @return	String  영업첫날 N익영업일자 (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public String  getNNxtFirstBizDt(String argYm, int argNth) throws ApplicationException
	{

		boolean	bValidYmd;
		String	strSolrDt		= "";

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd = DateUtils.isValidDate(argYm+"01", DateUtils.EMPTY_DATE_TYPE);
			// APCME0004 : 디폴트 날짜 포맷은 "YYYYMM" 입니다.
			if (!bValidYmd)  { throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "입력년월" , "YYYYMM 날짜포맷"}); }
			
			if ( argNth < 0 ) { throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "계산일수", "양의 정수" }); }
			
			// 2. 입력일자와 입력값 조건에 맞게 영업일테이블에서 조회후 영엽일정보를 가져온다.
			strSolrDt = this.cma003dbio.selectOneTBCMCCD005c(argYm,argNth);
			
			if (StringUtils.isEmpty(strSolrDt)) {
				// 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException( "KIOKI0004", null );
			} 

			return strSolrDt;
		} catch (Exception e) {
			
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 입력년월의 마지막 영업일계산
	 * </pre>
	 * @param	String	argYm 입력년월(YYYYMM)
	 * @return	String  영업말일자 (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public String  getLastBizDt(String argYm) throws ApplicationException
	{

		boolean	bValidYmd;
		String	strSolrDt		= "";

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd = DateUtils.isValidDate(argYm+"01", DateUtils.EMPTY_DATE_TYPE);
			// APCME0004 : 디폴트 날짜 포맷은 "YYYYMM" 입니다.
			if (!bValidYmd)  { throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "입력년월" , "YYYYMM 날짜포맷"}); }
			
			// 2. 입력일자와 입력값 조건에 맞게 영업일테이블에서 조회후 영엽일정보를 가져온다.
			strSolrDt = this.cma003dbio.selectOneTBCMCCD005d(argYm);
			
			if (StringUtils.isEmpty(strSolrDt)) {
				// 요청하신 자료가 존재하지 않습니다.
				throw new ApplicationException( "KIOKI0004", null );
			} 

			return strSolrDt;
		} catch (Exception e) {
			
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
}

