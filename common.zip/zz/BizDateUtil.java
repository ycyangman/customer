package cigna.zz;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;

/**
 * @file             cigna.zz.BizDateUtil.java
 * @filetype        java source file
 * @brief           업무공통으로 날짜 계산, 변환 및 체크 프로그램 입니다.
 * @author          박경화
 * @version         1.0
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               박경화                 2012. 7.06.       신규 작성
 * 0.6               박경화                 2012. 7.10.       개발 완료
 * 0.9               박경화                 2012. 7.21.       Class 테스트
 * 1.0               박경화                 2012. 7.21.       단위 테스트     
 * 1.1               박경화                 2013. 1.25.       getYmMonthsAfter, getYmMonthsBefore 추가 
 * 
 */
/**
 * 
 * 업무공통으로 날짜 계산, 변환 및 체크하기 위한 utility class 
 *
 */
public class BizDateUtil {
	
	final static Logger LOGGER = LoggerFactory.getLogger(BizDateUtil.class);
	
    /** MAX DATE : 9999년 12월 31일 */
    public final static String MAX_DT = "99991231";

    /** MIN DATE: 1년 1월 1일 */
    public final static String MIN_DT = "00010101";

    /** MAX TIMESTAMP : 9999년 12월 31일 23시 59분 59.999999초 */
    public final static String MAX_TIMESTAMP = "99991231235959999999";

    /** MAX TIMESTAMP : 1년 1월 1일 0시 0분 0초 */
    public final static String MIN_TIMESTAMP = "00010101000000000000";
	
	/** 토요일을 평일처리 */
	public static final String SATURDAY_WEEKDAYS = "0";
	
	/** 토요일을 휴일처리 */
	public static final String SATURDAY_HOLIDAY = "1";
	
	
    /**
     * <pre>
     * 두 날짜간의 개월수를 반환(윤년을 감안함).
     * </pre>
     * @param startDate 시작 날짜
     * @param endDate 종료날짜
     * @return 날수
     */
	private static int getMonthsDiff(String startDate, String endDate) {

        int difer = ( Integer.parseInt(endDate.substring(0, 4)) * 12 + Integer.parseInt(endDate.substring(4, 6)) )
			       - ( Integer.parseInt(startDate.substring(0, 4)) * 12 + Integer.parseInt(startDate.substring(4, 6)) );
        return difer;

    }
	
	/**
	 * <pre>
	 * 입력일자의 경과일수 환산
	 * 기능 : sDate에 입력된 일자를 0년 3월 1일 부터의 경과 일수로 변환하여 tDays에 반환
	 * </pre>
	 * @param	String	argYmd
	 * @return	int			intRtnDate
	 * @throws ApplicationException
	 */
	private static int setJulianToSdn(String argYmd) throws ApplicationException
	{
	    int     cYear   ;
	    int     cMont   ;
	    int     cDay    ;
	    int	intRtnDays = 0;

	    try {
			cYear	= Integer.parseInt(argYmd.substring(0, 4));
			cMont	= Integer.parseInt(argYmd.substring(4, 6));
			cDay	= Integer.parseInt(argYmd.substring(6));

		    if (cMont > 2) {
		        cMont -= 3;
		    } else {
		        cMont += 9;
		        cYear--;
		    }
		    intRtnDays = ((cYear * 1461) >> 2) + (cMont * 153 + 2) / 5 + cDay;
		    return  intRtnDays;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}

	/**
	 * <pre>
	 * 경과일수의  입력일자 환산
	 * 기능 : sdn에 입력된 일수를 일자형식으로 변환’YYYYMMDD’ 하여 tDate에 move
	 * </pre>
	 * @param	int			argIntSdn
	 * @return	String	strRtnDate
	 * @throws ApplicationException
	 */
	private static String setSdnToJulian(int argIntSdn) throws ApplicationException
	{
		int		cYear			= 0;
		int		cMont			= 0;
		int		cDay			= 0;
		//
		int		temp				= 0;
		int		days				= 0;
		String	strRtnDate	= "";

		try
		{
			// APCME0007 : 입력값이 범위를 벗어납니다.
			if ( argIntSdn < 1 ) { throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "일수", "양의 정수" }); }
			temp		= (argIntSdn << 2) - 1;
			cYear	= temp / 1461;
			days		= ((temp % 1461) >> 2) + 1;

			temp		= days * 5 - 3;
			cMont	= temp / 153;
			cDay	= (temp % 153) / 5 + 1;

			if ( cMont < 10 ) {
				cMont += 3;
			} else {
				cYear += 1;
				cMont -= 9;
			}
			// strRtnDate = "" + cYear + cMont + cDay;
			strRtnDate = StringUtils.lpad( String.valueOf(cYear),4, "0")
							+ StringUtils.lpad( String.valueOf(cMont),2, "0")
							+ StringUtils.lpad( String.valueOf(cDay),2, "0");
			return strRtnDate;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}

	
	/**
	 * <pre>
	 * integer_of_date
	 * 기능 : sDate에 입력된 일자를 0년 3월 1일부터의 일수로 변환하여 tDays에 반환.
	 * </pre>
	 * @param	String	argDate
	 * @return	int			intRtnSdn
	 * @throws ApplicationException
	 */
	private static int setIntegerOfDate(String argDate) throws ApplicationException
	{
		try
		{
			int intRtnSdn = setJulianToSdn(argDate);
		    return intRtnSdn;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}


	/**
	 * <pre>
	 * date_of_integer
	 * 기능 : sdn에 입력된 일수를 일자로 변환하여 tDate에 move.
	 * </pre>
	 * @param	int			argIntSdn
	 * @return	String	argDate
	 * @throws ApplicationException
	 */
	private static String setDateOfInteger(int argIntSdn) throws ApplicationException
	{
	    try
	    {
	    	String strTDate = setSdnToJulian(argIntSdn);
	    	return	strTDate;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * 일수계산(한편)
	 * 기능 : sDate 에서 eDate 까지의 일수를 계산하여 tDays 에 move 한다.
	 * 예) 20091101~20091103 -> 이면 2를 리턴
	 * @param argFmDate 시작일자 (YYYYMMDD)
	 * @param argToDate 종료일자 (YYYYMMDD)
	 * @return int 일수
	 * @throws ApplicationException
	 */
	public static int getDayCountComBySingle(String argFmDate, String argToDate) throws ApplicationException
	{
		boolean bValidToYmd;
		boolean bValidFmYmd;
		int	intTempDays	= 0;
		int	intRtnDays	= 0;

		try {
			
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmDate, DateUtils.EMPTY_DATE_TYPE);
			if (!bValidFmYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 2.기준일의 날짜 형식이 유효한지 체크한다.
			bValidToYmd = DateUtils.isValidDate(argToDate,  DateUtils.EMPTY_DATE_TYPE);
			if (!bValidToYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			intTempDays	= setJulianToSdn(argFmDate);
			intRtnDays		= setJulianToSdn(argToDate);
			intRtnDays -= intTempDays;
			
			return  intRtnDays;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * 일수계산(양편)
	 * 기능 : sDate 에서 eDate 까지의 일수를 계산하여 tDays 에 move 한다.
	 * 예) 20091101~20091103 -> 3 을 리턴
	 * @param argFmDate 시작일자 (YYYYMMDD)
	 * @param argToDate 종료일자 (YYYYMMDD)
	 * @return int 일수
	 * @throws ApplicationException
	 */
	public static int getDayCountComByBoth(String argFmDate, String argToDate) throws ApplicationException
	{
		boolean bValidToYmd;
		boolean bValidFmYmd;
		int	intTempDays	= 0;
		int	intRtnDays	= 0;

		try {
			
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmDate, DateUtils.EMPTY_DATE_TYPE);
			if (!bValidFmYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 2.기준일의 날짜 형식이 유효한지 체크한다.
			bValidToYmd = DateUtils.isValidDate(argToDate,  DateUtils.EMPTY_DATE_TYPE);
			if (!bValidToYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			intTempDays	= setJulianToSdn(argFmDate);
			intRtnDays		= setJulianToSdn(argToDate);
			intRtnDays -= intTempDays;
			
			if (intRtnDays<0) {
				intRtnDays--;
			} else {
				intRtnDays++;
			}
			return  intRtnDays;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	
	/**
	 * <pre>
	 * TO일자계산 (일) : 입력받은 날짜(FM_DATE)에 일수를 더한 TO_DATE를 구한다
	 * </pre>
	 * @param	String	argFmYmd	From일자 (YYYYMMDD)
	 * @param	int		argIntDays	입력받은일수
	 * @return	String	strRtnDate  (YYYYMMDD)
	 * @throws ProFrameApplicationException
	 */
	public static String  getCaclToDtByDate(String argFmYmd, int argIntDays) throws ApplicationException
	{
		String	strRtnDate	= "";	// 호출한 BIZ로 반환하기 최종결과값.
		boolean bValidYmd;
		String	strWkFrYmd  = "";
		String	strWkToYmd = "";
		int		intDate          = 0;

		try {

			strWkFrYmd = argFmYmd;
			// 입력받은 일수가 90000 보다 크면 to_date에 '99999999'로 설정을 하고 프로그램 종료처리
			if ( argIntDays > 90000 ) {
				strRtnDate = "99999999";
				return strRtnDate;
			}
			// 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if (!bValidYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 입력 일자를 일수로 변환한다.
			intDate = setIntegerOfDate(strWkFrYmd);
			// 넘어온 일수를 더한다.
			intDate += argIntDays;
		    // 계산된 일수에 일자를 구한다  형식 = YYYYMMDD
			strWkToYmd = setDateOfInteger(intDate);

			strRtnDate	= strWkToYmd;
			return strRtnDate;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 토,일 제외한 후일자 체크
	 * </pre>
	 * @param	String	argYmd (YYYYMMDD)
	 * @return	String	strRtnDate (YYYYMMDD)
	 * @throws ProFrameApplicationException
	 */
	public static String  getChkNotHldyNxtDt(String argYmdInput) throws ApplicationException
	{
		String argYmd = argYmdInput;

		String		strRtnDate	= ""; 
		int			iDayOfWeek	= 0;	// 다음일자 들의 요일 숫자값.
		int			iChkVal		= 0;	// while 문을 수행하기 위한 체크변수.
		boolean		bValidYmd;

		try	{
			// 1. 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd =  DateUtils.isValidDate(argYmd, DateUtils.EMPTY_DATE_TYPE);
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			if (!bValidYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 4. 평일이 될 때까지 2. ~ 3. 을 반복한다.
			while (iChkVal == 0)
			{
				strRtnDate = DateUtils.getDateDaysAfter(1, argYmd);	// 2. 입력일에 하루 씩을 더한다.
				iDayOfWeek = DateUtils.getDayOfTheWeek(strRtnDate);
				// 3. 휴일인지 CHECK 한다.
				if ( iDayOfWeek >= 2 && iDayOfWeek <= 6  ) {
				    iChkVal = 1;
				} else {
					argYmd = strRtnDate;
				}
			}
			
			return strRtnDate;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}	

	/**
	 * <pre>
	 * 일요일이 아닌 전일자 구하기 
	 * (구분값으로 토요일 휴일여부 셋팅)
	 * </pre>
	 * @param	String	argYmd (YYYYMMDD)
	 * @param	String	argGbn (SATURDAY_HOLIDAY,SATURDAY_WEEKDAYS)
	 * @return	String  strRtnDate (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public static String  getNotHldyBfDt(String argYmdInput, String argGbn) throws ApplicationException
	{
		String argYmd = argYmdInput;
		
		String	strRtnDate	= "";	// 호출한 BIZ로 반환하기 최종결과값. 
		int		iDayOfWeek	= 0;	// 다음일자 들의 요일 숫자값.
		int		iChkVal		= 0;	// while 문을 수행하기 위한 체크변수.
		boolean	bValidYmd;

		try {
			// 1. 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd =  DateUtils.isValidDate(argYmd, DateUtils.EMPTY_DATE_TYPE);
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			if (!bValidYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			/*
			 * 2. 구분값( argGbn ) 에 따른 처리
			 * 0 : 토요일평일처리
			 * 1 : 토요일휴일처리
			 */
			if (SATURDAY_HOLIDAY.equals(argGbn)) {
				while (iChkVal == 0) {
					strRtnDate = DateUtils.getDateDaysBefore(1, argYmd);	// 전일
					iDayOfWeek = DateUtils.getDayOfTheWeek(strRtnDate);
					if ( iDayOfWeek >= 2 && iDayOfWeek <= 6  )	{ iChkVal = 1; }
					else { argYmd = strRtnDate; }
				}
			} else if (SATURDAY_WEEKDAYS.equals(argGbn)) {
				while (iChkVal == 0) {
					strRtnDate = DateUtils.getDateDaysBefore(1, argYmd);	// 전일
					iDayOfWeek = DateUtils.getDayOfTheWeek(strRtnDate);
					if ( iDayOfWeek >= 2 && iDayOfWeek <= 7  )	{ iChkVal = 1; }
					else { argYmd = strRtnDate; }
				}
			} else {
				// APCME0007 : 입력조건 범위 오류
				throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "구분값", "0,1" });
			}

			return strRtnDate;
			//
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 일요일이 아닌 후일자 구하기 
	 * (구분값으로 토요일 휴일여부 셋팅)
	 * </pre>
	 * @param	String	argYmd (YYYYMMDD)
	 * @param	String	argGbn (SATURDAY_HOLIDAY,SATURDAY_WEEKDAYS)
	 * @return	String  strRtnDate (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public static String  getNotHldyNxtDt(String argYmdInput, String argGbn) throws ApplicationException
	{
		String argYmd = argYmdInput;
		
		String		strRtnDate	= "";	// 호출한 BIZ로 반환하기 최종결과값. 
		int			iDayOfWeek	= 0;	// 다음일자 들의 요일 숫자값.
		int			iChkVal		= 0;	// while 문을 수행하기 위한 체크변수.
		boolean	bValidYmd;

		try {
			// 1. 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			bValidYmd =  DateUtils.isValidDate(argYmd, DateUtils.EMPTY_DATE_TYPE);	
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			if (!bValidYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			/*
			 * 2. 구분값( argGbn ) 에 따른 처리
			 * 0 : 토요일평일처리
			 * 1 : 토요일휴일처리
			 */
			if (SATURDAY_HOLIDAY.equals(argGbn)) {
				while (iChkVal == 0) {
					strRtnDate = DateUtils.getDateDaysAfter(1, argYmd);	// 전일
					iDayOfWeek = DateUtils.getDayOfTheWeek(strRtnDate);
					if ( iDayOfWeek >= 2 && iDayOfWeek <= 6  )	{ iChkVal = 1; }
					else { argYmd = strRtnDate; }
				}
			} else if (SATURDAY_WEEKDAYS.equals(argGbn)) {
				while (iChkVal == 0) {
					strRtnDate = DateUtils.getDateDaysAfter(1, argYmd);	// 전일
					iDayOfWeek = DateUtils.getDayOfTheWeek(strRtnDate);
					if ( iDayOfWeek >= 2 && iDayOfWeek <= 7  )	{ iChkVal = 1; }
					else { argYmd = strRtnDate; }
				}
			} else {
				// APCME0007 : 입력조건 범위 오류
				throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "구분값", "0,1" });
			}

			return strRtnDate;
			//
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}

	/**
	 * <pre>
	 * 경과일수구하기
	 * </pre>
	 * @param	String	argFmYmd( 기간시작일자 :YYYYMMDD )
	 * @param	String	argToYmd( 기간종료일자 :YYYYMMDD )
	 * @return	long	longVal( 경과일수 )
	 * @throws ApplicationException
	 */
	public static long  getErnDtCnt(String argFmYmd, String argToYmd) throws ApplicationException
	{
		boolean bValidToYmd;
		boolean bValidFmYmd;
		long	longVal		= 0L;

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if (!bValidFmYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 2.기준일의 날짜 형식이 유효한지 체크한다.
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if (!bValidToYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 3.입력일과 기준일의 비교
			// 일자간의 일수 차이를 구한다.
			// 3-1.입력일과 기준일보다 이전인 경우.(에러발생)
			// 3-2.입력일이 기준일이 동일한 경우.(0 을 리턴)
			// 3-3.입력일이 기준일보다 이후인 경우.(일반적인 경우)
			longVal = DateUtils.getPeriodBetween(argFmYmd, argToYmd);

		    //  APCME0006 : 적용종료일자는 적용시작일자보다 크거나 같아야 합니다. 
			if ( longVal < 0L ) { throw new ApplicationException("APCME0006", null, new Object[]{  new Throwable().getStackTrace()[0].getMethodName(), argToYmd, argFmYmd }); }
			
			return longVal;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}	
	
	/**
	 * <pre>
	 * 경과일수구하기
	 * </pre>
	 * @param	String	argFmYmd( 기간시작일자 :YYYYMMDD )
	 * @param	String	argToYmd( 기간종료일자 :YYYYMMDD )
	 * @return	int	intVal( 경과일수 )
	 * @throws ApplicationException
	 */
	public static int  getErnDtCntInt(String argFmYmd, String argToYmd) throws ApplicationException
	{
		boolean bValidToYmd;
		boolean bValidFmYmd;
		int	intVal		= 0;

		try {
			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if (!bValidFmYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 2.기준일의 날짜 형식이 유효한지 체크한다.
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if (!bValidToYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 3.입력일과 기준일의 비교
			// 일자간의 일수 차이를 구한다.
			// 3-1.입력일과 기준일보다 이전인 경우.(에러발생)
			// 3-2.입력일이 기준일이 동일한 경우.(0 을 리턴)
			// 3-3.입력일이 기준일보다 이후인 경우.(일반적인 경우)
			intVal = DateUtils.getPeriodBetween(argFmYmd, argToYmd);

		    //  APCME0006 : 적용종료일자는 적용시작일자보다 크거나 같아야 합니다. 
			if ( intVal < 0 ) { throw new ApplicationException("APCME0006", null, new Object[]{  new Throwable().getStackTrace()[0].getMethodName(), argToYmd, argFmYmd }); }
			
			return intVal;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 경과월수구하기
	 * 개요 : 계약일자로부터 기준일자까지의 경과월수를 구한다.
	 * </pre>
	 * @param	String	argFmYmd( 계약일자 : YYYYMMDD )
	 * @param	String	argToYmd( 기준일자 : YYYYMMDD )
	 * @return	int	    intErnMmCnt( 경과월수 )
	 * @throws ApplicationException
	 */
	public static int  getErnMmCnt(String argFmYmd, String argToYmd) throws ApplicationException
	{

		int	intWkLastDd			= 0;	// 기준일자의 말일자.
		int	intWkDayCnt			= 0;	// wk_day_cnt
		int	intWkMonCnt			= 0;	// wk_mon_cnt
		int	intInpWkContYy		= 0;	// 계약일자의 년.
		int	intInpWkContMm	= 0;	// 계약일자의 월.
		int	intInpWkContDd	= 0;	// 계약일자의 일자.
		int	intInpWkStdYy		= 0;	// 기준일자의 년.
		int	intInpWkStdMm		= 0;	// 기준일자의 월.
		int	intInpWkStdDd		= 0;	// 기준일자의 일자.

		boolean bValidFmYmd;
		boolean bValidToYmd;
		int	intErnMmCnt	= 0;	// 리턴값.

		try {
			
			// 1-1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if (!bValidFmYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 1-2.기준일의 날짜 형식이 유효한지 체크한다.
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if (!bValidToYmd) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
						

			// 계약일자의 일자부분을 별도로 추출한다.
			intInpWkContDd	= Integer.parseInt(argFmYmd.substring(6));
			//
			intInpWkContYy	= Integer.parseInt(argFmYmd.substring(0, 4));
			intInpWkContMm	= Integer.parseInt(argFmYmd.substring(4, 6));
			intInpWkStdYy	= Integer.parseInt(argToYmd.substring(0, 4));
			intInpWkStdMm	= Integer.parseInt(argToYmd.substring(4, 6));
			intInpWkStdDd	= Integer.parseInt(argToYmd.substring(6));	// 기준일자의 일자.
			
			// 2. 기준일자의 말일자를 가져온다.
			intWkLastDd	= DateUtils.getDaysOfTheMonth(argToYmd);		// 기준일자의 말일자.
			// 2-1. 기준일자의 말일자와 기준일의 일자를 비교한다.
			if ( intWkLastDd == intInpWkStdDd ) {
				// 입력받은 계약일의 일자와 기준일자의 일자와 비교한다.
				if ( intInpWkContDd > intInpWkStdDd ) {
				    intInpWkStdDd	= intInpWkContDd;
				}
			}

			intWkDayCnt	= intInpWkStdDd - intInpWkContDd;
			intWkMonCnt	= ( intInpWkStdYy - intInpWkContYy ) * 12 + ( intInpWkStdMm - intInpWkContMm );

			if ( intWkDayCnt >= 0 )	{ 
				intErnMmCnt	= intWkMonCnt + 1;
			} else { 
				intErnMmCnt	= intWkMonCnt;
			}

			return intErnMmCnt;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}

	/**
	 * <pre>
	 * 경과월수구하기
	 * 개요 : 계약일자로부터 기준일자까지의 경과월수를 구한다.(단편넣기)
	 * </pre>
	 * @param	String	argFmYmd( 계약일자 : YYYYMMDD )
	 * @param	String	argToYmd( 기준일자 : YYYYMMDD )
	 * @return	int	    intErnMmCnt( 경과월수 )
	 * @throws ApplicationException
	 */
	public static int  getErnMmCntSingle(String argFmYmd, String argToYmd) throws ApplicationException
	{

		int	intWkLastDd			= 0;	// 기준일자의 말일자.
		int	intWkDayCnt			= 0;	// wk_day_cnt
		int	intWkMonCnt			= 0;	// wk_mon_cnt
		int	intInpWkContYy		= 0;	// 계약일자의 년.
		int	intInpWkContMm	= 0;	// 계약일자의 월.
		int	intInpWkContDd	= 0;	// 계약일자의 일자.
		int	intInpWkStdYy		= 0;	// 기준일자의 년.
		int	intInpWkStdMm		= 0;	// 기준일자의 월.
		int	intInpWkStdDd		= 0;	// 기준일자의 일자.

		boolean bValidFmYmd;
		boolean bValidToYmd;
		int	intErnMmCnt	= 0;	// 리턴값.

		try {
			
			// 1-1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidFmYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 1-2.기준일의 날짜 형식이 유효한지 체크한다.
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidToYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
						

			// 계약일자의 일자부분을 별도로 추출한다.
			intInpWkContDd	= Integer.parseInt(argFmYmd.substring(6));
			//
			intInpWkContYy	= Integer.parseInt(argFmYmd.substring(0, 4));
			intInpWkContMm	= Integer.parseInt(argFmYmd.substring(4, 6));
			intInpWkStdYy	= Integer.parseInt(argToYmd.substring(0, 4));
			intInpWkStdMm	= Integer.parseInt(argToYmd.substring(4, 6));
			intInpWkStdDd	= Integer.parseInt(argToYmd.substring(6));	// 기준일자의 일자.
			
			// 2. 기준일자의 말일자를 가져온다.
			intWkLastDd	= DateUtils.getDaysOfTheMonth(argToYmd);		// 기준일자의 말일자.
			// 2-1. 기준일자의 말일자와 기준일의 일자를 비교한다.
			if ( intWkLastDd == intInpWkStdDd ) {
				// 입력받은 계약일의 일자와 기준일자의 일자와 비교한다.
				if ( intInpWkContDd > intInpWkStdDd ) {
				    intInpWkStdDd	= intInpWkContDd;
				}
			}

			intWkDayCnt	= intInpWkStdDd - intInpWkContDd;
			intWkMonCnt	= ( intInpWkStdYy - intInpWkContYy ) * 12 + ( intInpWkStdMm - intInpWkContMm );

			if ( intWkDayCnt >= 0 )	{ 
				intErnMmCnt	= intWkMonCnt;
			} else { 
				intErnMmCnt	= intWkMonCnt - 1;
			}

			return intErnMmCnt;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	/**
	 * <pre>
	 * 경과년수구하기
	 * </pre>
	 * @param	String	argFmYmd( 기간시작일자 :YYYYMMDD )
	 * @param	String	argToYmd( 기간종료일자 :YYYYMMDD )
	 * @return	int		intDueYearCnt( 경과년수 )
	 * @throws ApplicationException
	 */
	public static int  getErnYnCnt(String argFmYmd, String argToYmd) throws ApplicationException
	{
		
		LOGGER.debug("argFmYmd:" + argFmYmd + ", argToYmd:" + argToYmd);
		
		/*
		 * 업무로직
		 * 1) 기준일의 년수로부터 계산 기준일의 년수를 뺀다
		 * 2) 기준일의 월도가 계산기준일의 월도보다 작으면 년수 -1
		 * 3) 기중일의 월도와 계산기준일의 월도가 같으면 일자을 비교하여 기준일이 작으면 -1
		 */
		boolean bValidFmYmd;
		boolean bValidToYmd;
		// 시작일
		String strFmYy			= "";	// 시작일(년)
		String strFmMm			= "";	// 시작일(월)
		String strFmDd			= "";	// 시작일(일)
		// 종료일
		String strToYy			= "";	// 종료일(년)
		String strToMm			= "";	// 종료일(월)
		String strToDd			= "";	// 종료일(일)
		int	intCmpVal			= 0;	// 시작일과 종료일의 비교에 사용
		int	intLastDateOfDtTo	= 0;	// 종료일의 말일자
		int	intWorkMonCnt		= 0;	// 계산된 월수.
		int	intDueYearCnt		= 0;	// 경과년수.

		try {

			// 1.입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			LOGGER.debug("bValidFmYmd:"+bValidFmYmd);
			if ( !bValidFmYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 2.기준일의 날짜 형식이 유효한지 체크한다.
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			LOGGER.debug("bValidToYmd:"+bValidToYmd);
			if ( !bValidToYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 3.입력일과 기준일의 비교
			// 일자간의 일수 차이를 구한다.
			// 3-1.입력일과 기준일보다 이전인 경우.(에러발생)
			intCmpVal = DateUtils.getPeriodBetween(argFmYmd, argToYmd);
		    //  APCME0006 : 적용종료일자는 적용시작일자보다 크거나 같아야 합니다. 
			if ( intCmpVal < 0 ) { throw new ApplicationException("APCME0006", null, new Object[]{new Throwable().getStackTrace()[0].getMethodName(), argToYmd, argFmYmd }); }

			// 입력일 ( i_cont_dd )
			strFmYy		= argFmYmd.substring(0, 4);
			strFmMm		= argFmYmd.substring(4, 6);
			strFmDd		= argFmYmd.substring(6);
			// 기준일 ( i_std_dd )
			strToYy		= argToYmd.substring(0, 4);
			strToMm		= argToYmd.substring(4, 6);
			strToDd		= argToYmd.substring(6);

			// 4. 종료일의 말일자를 구한다.
			intLastDateOfDtTo = DateUtils.getDaysOfTheMonth(argToYmd);

			// 5. 일자를 비교한다.
			if ( Integer.parseInt(strToDd) == intLastDateOfDtTo ) {
				if ( Integer.parseInt(strFmDd) > intLastDateOfDtTo ) {
					intLastDateOfDtTo = Integer.parseInt(strFmDd);
					strToDd = "" + intLastDateOfDtTo;
				}
			}

			// 6. 월수를 구한다.
			intWorkMonCnt = ( Integer.parseInt(strToYy) * 12 + Integer.parseInt(strToMm) )
			                        - ( Integer.parseInt(strFmYy) * 12 + Integer.parseInt(strFmMm) );

			// 7. 경과년수를 구한다.
			intDueYearCnt = intWorkMonCnt / 12;
			if ( Integer.parseInt(strToMm) == Integer.parseInt(strFmMm) &&
					Integer.parseInt(strFmDd) > Integer.parseInt(strToDd) ) {
				intDueYearCnt--;
			}

			return intDueYearCnt;

		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}	
	
	/**
	 * <pre>
	 * 입력일의 전(익)월 응당일
	 * </pre>
	 * @param	String	argInYmd (YYYYMMDD)
	 * @param	String	argInDueDd (DD)
	 * @param	int		argPrdMms
	 * @return	String	strDueYmd (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public static String  getInpdtRldt(String argInYmdInput, String argInDueDdInput, int argPrdMmsInput) throws ApplicationException
	{
		String argInYmd = argInYmdInput;
		String argInDueDd = argInDueDdInput;
		int argPrdMms = argPrdMmsInput;
		
		/*
		 * ----------------------------------------------------------------------
		 * ◇사용예
		 *    ① IN-YMD = '20020331'   DUE-DD = '31'
		 *       PRD-MMS = 1 
		 *       -> DUE-YMD = '20020430'
		 *   ② IN-YMD = '20020331'   DUE-DD = '31'
		 *       PRD-MMS = -1 
		 *       -> DUE-YMD = '20020228'
		 *    ③ IN-YMD = '20020301'   DUE-DD = '20'
		 *       PRD-MMS = 1 
		 *       -> DUE-YMD = '20020420'
		 *  ---------------------------------------------------------------------- 
		 */
		
		boolean bValidInYmd;
		boolean bValidDueDd;
		String strRtnYmd	= "";
		String strRtnYy		= "";
		String strRtnMm		= "";
		String strRtnDd		= "";
		int intLastDate		= 0;
		String strTmpYmd	= "";		// 말일자 추출용.

		try {

			// 1. 입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidInYmd = DateUtils.isValidDate(argInYmd, DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidInYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 2. 입력값 숫자로만 구성되어 있는지 체크한다.
			bValidDueDd = StringUtils.isDigit(argInDueDd);
			// APCME0002 : 입력값이 오류입니다.
			if ( !bValidDueDd ) { throw new ApplicationException( "APCME0002", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "응당일" }); }
			//
			// 2-1. 입력값 '응당일'이 범위내의 값인지 체크한다.
			if ( Integer.parseInt(argInDueDd) < 1 && Integer.parseInt(argInDueDd) > 31 ) {
				// APCME0007 : 입력값이 범위를 벗어납니다.
				throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "응당일", "1~30 사이의 정수" });
			}

			// 3. 입력값 '기간월'이 0 이면, 1로 세팅한다.
			if ( argPrdMms == 0 )	{ argPrdMms = 1; }

			// 3-1. 입력값 '기간월'이 범위내의 값인지 체크한다.
			// APCME0007 : 입력값이 범위를 벗어납니다.
			if ( argPrdMms != 1 && argPrdMms != -1 ) { throw new ApplicationException( "APCME0007", null, new Object[]{new Throwable().getStackTrace()[0].getMethodName(),  "기간월", "1,-1" }); }

			// 5. 전(익)월의 응당일을 구한다.
			// 5-1. 익월을 구하는 경우.
			if ( argPrdMms == 1 ) {
				if ( Integer.parseInt(argInYmd.substring(4, 6)) == 12 ) {
					// 월도를 다음해의 1월로 세팅.
					strRtnMm	= "01";
					// 년도를 1 추가한다.
					strRtnYy	= String.valueOf(Integer.parseInt(argInYmd.substring(0, 4)) + 1 );
				} else
				{
					// 월도를 1 추가한다.
					strRtnMm	= StringUtils.lpad( String.valueOf(Integer.parseInt(argInYmd.substring(4, 6) )+ 1),2, "0");
					// 년도를 입력년으로 세팅한다.
					strRtnYy	= argInYmd.substring(0, 4);
				}
			}

			// 5-2. 전월을 구하는 경우.
			if ( argPrdMms == -1 ) {
				if ( Integer.parseInt(argInYmd.substring(4, 6)) == 1 ) {
					// 월도를 전년도의 12월로 세팅.
					strRtnMm	= "12";
					// 년도를 1 감산한다.
					strRtnYy	= String.valueOf(Integer.parseInt(argInYmd.substring(0, 4)) - 1);
				} else
				{
					// 월도를 1 감산한다.
					strRtnMm	= StringUtils.lpad(String.valueOf(Integer.parseInt(argInYmd.substring(4, 6)) - 1),2, "0");
					// 년도를 입력년으로 세팅한다.
					strRtnYy	= argInYmd.substring(0, 4);
				}
			}

			// 자릿수를 체크하여 앞에 '0' 을 붙인다. ( 연/월/일/시/분/초 에만 사용 )
			strRtnMm	= StringUtils.lpad(String.valueOf(Integer.parseInt(strRtnMm)), 2, "0");
			// 5-3-1. 말일자구하기.
			strTmpYmd = strRtnYy + strRtnMm + "01";
			intLastDate = DateUtils.getDaysOfTheMonth(strTmpYmd);
			
			// 5-3-2. 응당일에 대한 계산.
			if ( Integer.parseInt(argInDueDd) > intLastDate )				{ strRtnDd = "" + intLastDate; }
			else if ( Integer.parseInt(argInDueDd) <= intLastDate )		{ strRtnDd = argInDueDd; }

			// 자릿수를 체크하여 앞에 '0' 을 붙인다. ( 연/월/일/시/분/초 에만 사용 )
			//strRtnYy = StringUtils.lpad(strRtnYy, 4, "0");
			strRtnMm= StringUtils.lpad(strRtnMm, 2, "0");
			strRtnDd	= StringUtils.lpad(strRtnDd, 2, "0");
			// 6. 리턴할 응당일을 조합한다.
			strRtnYmd = strRtnYy + strRtnMm + strRtnDd;

			return strRtnYmd;

		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}	
	
	
	/**
	 * <pre>
	 * X월경과응당일
	 * </pre>
	 * @param	String	argInYmd (YYYYMMDD)
	 * @param	String	argInDueDd (DD)
	 * @param	int		argIntPrdMms
	 * @return	String	strRtnDueYmd (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public static String  getXMmErnRldt(String argInYmd, String argInDueDd, int argIntPrdMms)
			throws ApplicationException
	{
		/*
		 * ----------------------------------------------------------------------
		 * ◇사용예
		 *    ① IN-YMD = '20120331'   DUE-DD = '31'     PRD-MMS = 1
		 *       -> DUE-YMD = '20120430'
 		 *   ② IN-YMD = '20020331'   DUE-DD = '31'      PRD-MMS =  -1
		 *       -> DUE-YMD = '20120229'
		 *    ③ IN-YMD = '20020301'   DUE-DD = '20'     PRD-MMS =  1
		 *       -> DUE-YMD = '20120420'
		 *  ----------------------------------------------------------------------
		 */
		
		boolean bValidInYmd;
		boolean bValidDueDd;
		String strRtnDD		= "";
		int	   intLastDate		= 0;
		String strTestYmd	= "";		// 말일자 추출용.

		String strBfAfYmd	= "";
		String strRtnDueYmd	= "";

		try {
			// 1. 입력일의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효할 경우 TRUE )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidInYmd = DateUtils.isValidDate(argInYmd, DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidInYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 2. 입력값 숫자로만 구성되어 있는지 체크한다.
			bValidDueDd = StringUtils.isDigit(argInDueDd);
			// APCME0002 : 입력값이 오류입니다.
			if ( !bValidDueDd ) { throw new ApplicationException( "APCME0002", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "응당일" }); }
			//
			// 2-1. 입력값 '응당일'이 범위내의 값인지 체크한다.
			if ( Integer.parseInt(argInDueDd) < 1 && Integer.parseInt(argInDueDd) > 31 ) {
				// APCME0007 : 입력값이 범위를 벗어납니다.
				throw new ApplicationException( "APCME0007", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(),  "응당일", "1~30 사이의 정수" });
			}

			// 3. 입력값 '기간월'이 0 이면, 1로 세팅한다.
			//if ( argIntPrdMms == 0 ) { argIntPrdMms = 1; }

			// 4.
			// 4-1. 입력년도를 추출한다.
			// 4-1. 입력월을 추출한다.

			// 5.입력일의 X월경과응당일을 구한다.
			// 5.1 입력일의  X월경과응당일을 구한다.
			if ( argIntPrdMms > 0 ) {
				strBfAfYmd	= DateUtils.getDateMonthsAfter(argIntPrdMms,argInYmd);
			} else if ( argIntPrdMms < 0 ) {
				strBfAfYmd	= DateUtils.getDateMonthsBefore(-argIntPrdMms, argInYmd);
			} else {
				strBfAfYmd	= argInYmd;
			}
			// 5.2 입력일의  X월경과응당일의 말일자를 구한다.
			strTestYmd = strBfAfYmd.substring(0, 6) + "01";
			intLastDate = DateUtils.getDaysOfTheMonth(strTestYmd);
			if ( Integer.parseInt(argInDueDd) > intLastDate ) {
				strRtnDD = "" + intLastDate;
			} else if ( Integer.parseInt(argInDueDd) <= intLastDate ) {
				strRtnDD = argInDueDd;
			}
			// 6. 리턴할 응당일을 조합한다.
			strRtnDueYmd = strBfAfYmd.substring(0, 6) + strRtnDD;

			return strRtnDueYmd;

		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}
	
	
	/**
	 * <pre>
	 * 일자의 JULIAN DATE.
	 * 개요 : 입력일자를 JULIAN DATE형식으로 변환한다(YYYYMMDD -> YYYYDDD).
	 * </pre>
	 * @param	String	argYmd( 입력일자 : YYYYMMDD)
	 * @return	String	strRtnYmd( Julian date : YYYYDDD)
	 * @throws ApplicationException
	 */
	public static String  getJulianDate(String argYmd) throws ApplicationException
	{
		String		strRtnYmd	= "";
		boolean	    bValidYmd;
		String		strTmpYear	= "";
		long		longJDD 	= 0L;
		String		beginDate	= "";

		try {
			// 1. 입력일자의 날짜 형식이 유효한지 체크한다.
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidYmd = DateUtils.isValidDate(argYmd, DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 2-1. 입력년도를 추출한다.(입력일자에서 왼쪽 4자리를 가져온다.)
			strTmpYear	= argYmd.substring(0, 4);
			
			// 일자간의 일수차이를 구한다.
			beginDate = strTmpYear+"01"+"01";
			
			longJDD = DateUtils.getPeriodBetween(beginDate, argYmd);
			longJDD += 1;
			
			if ( longJDD < 10 )	{ 
				strRtnYmd = strTmpYear + "00" + longJDD; 
			} else if ( longJDD >= 10 && longJDD < 100 ) { 
				strRtnYmd = strTmpYear + "0" + longJDD; 
			} else { 
				strRtnYmd = strTmpYear + longJDD; 
			}
			
			return strRtnYmd;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
		
	}	

	
	/**
	 * <pre>
	 * 입력월의 마지막일자
	 * </pre>
	 * @param   String argYmd (YYYYMMDD)
	 * @return	String 마지막일자 (YYYYMMDD)
	 * @throws ApplicationException
	 */
	public static java.lang.String  getLastDtOfMonthString(String argYmd) throws ApplicationException
	{
		String		strRtnDate	= ""; 
		String		strExamYm	= "";
		String		strExamYmd	= "";
		int			iRtnDate	= 0;

		try {
			strExamYm	= argYmd.substring(0, 6);
			strExamYmd	= strExamYm + "01";
			// 1.날짜 형식이 유효할 경우 TRUE
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다. 
			if ( !DateUtils.isValidDate(strExamYmd, DateUtils.EMPTY_DATE_TYPE) ) { 
				throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); 
			}
			// 2.입력 일자의 말일자를 구한다.
			iRtnDate = DateUtils.getDaysOfTheMonth(strExamYmd);

			strRtnDate = strExamYm + iRtnDate;
			
			return strRtnDate;
		} catch ( Exception e ) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
		
	}	

	/**
	 * <pre>
	 * 제2보험기간시작일계산
	 * 개요 : 계약일자와 제2보험기간 개시년도로부터 제2보험기간 개시일자와 제1보험기간을 계산한다
	 * </pre>
	 * @param	int		argContYmdCy( 계약일자_년 )
	 * @param	int		argContYmdMm( 계약일자_월 )
	 * @param	int		argContYmdDd( 계약일자_일 )
	 * @param	int		argInprdStrYy2R( 제2보험기간 개시년도 )
	 * @return	int[]	intRtnDate[0]( 제2보험기간 개시일자_년 )
	 * @return	int[]	intRtnDate[1]( 제2보험기간 개시일자_월 )
	 * @return	int[]	intRtnDate[2]( 제2보험기간 개시일자_일 )
	 * @return	int[]	intRtnDate[3]( 제1보험기간 )
	 * @throws ApplicationException
	 */
	public static int[] getInsr2tSdd(int argContYmdCy, int argContYmdMm, int argContYmdDd, int argInprdStrYy2R)
			throws ApplicationException
	{
		/*
		 * 2-1) 제2보험기간 개시일자 계산
		 * - 제2보험기간 개시년도 * 10000 + 계약월일
		 * - 제2보험기간 개시일자가 2월이면서 일자가 28 보다 큰 경우는 윤달 체크
		 * : 윤달이면 일을 29, 아니면 28 로 SETTING
		 * 2-2) 제1보험기간 계산
		 * : 제2보험기간 개시년도 - 계약년도
		 */
		boolean bValidYmd;
		String	strWkYear		= "";	// 작업일자(년).
		String	strWkMon		= "";	// 작업일자(월).
		String	strWkDd			= "";	// 작업일자(일).
		String	strWkYmd		= "";	// 작업년월일.
	    int		intRtnDate[]	= new int[4];

		try {
			// 제２보험기간　개시년도가　있을경우 만 계산 처리.
			if ( argInprdStrYy2R > 0 ) {
				
				// 자릿수를 체크하여 앞에 '0' 을 붙인다. ( 연/월/일/시/분/초 에만 사용 )
				strWkYear	= String.valueOf(argContYmdCy);
				strWkMon	= StringUtils.lpad(String.valueOf(argContYmdMm), 2, "0");
				strWkDd	= StringUtils.lpad(String.valueOf(argContYmdDd), 2, "0");
				strWkYmd = strWkYear + strWkMon + strWkDd;
				
				// 1) 입력일자의 날짜 형식이 유효한지 체크한다.
				bValidYmd = DateUtils.isValidDate(strWkYmd, DateUtils.EMPTY_DATE_TYPE);
				// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
				if ( !bValidYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
				
				// 제 2보험 개시년월을 구한다.
/*				
				// 계약월이 2월이고 일자가 28일 보다 큰 경우 계약월의 마지막 일자를 구해서 넣는다.
				// 말일자구하기.
				if ( argContYmdMm == 2 && argContYmdDd > 28 ) {
					// 말일자구하기.
					intRtnDate[2] = DateUtils.getDaysOfTheMonth(strWkYmd);
				} else {
					intRtnDate[2] = argContYmdDd;
				}
*/
				intRtnDate[0] = argInprdStrYy2R;
				
				// 2012.07.26 상품팀 신동호 대리 수정요청 
				// 제２보험기간개시년도로 말일자구하기.
				intRtnDate[2] = DateUtils.getDaysOfTheMonth(argInprdStrYy2R,argContYmdMm);
				
				intRtnDate[1] = argContYmdMm;
				
				// 제1보험기간을 계산한다 : 제2보험기간 개시년도 - 계약년도
				intRtnDate[3] = argInprdStrYy2R - argContYmdCy;

				return intRtnDate;
			} else {
				throw new ApplicationException( "APCME0004", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), "제2보험기간 개시년도" , "yyyy 날짜"});
			}
		} catch ( Exception e ) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}	
	
	/**
	 * <pre>
	 * 기간계산 (양편넣기)  : 입력된 FROM DATE에서 TO DATE까지의 일수 계산(양편넣기)
	 * </pre>
	 * @param	String	argFmYmd( 기간시작일자 : YYYYMMDD )
	 * @param	String	argToYmd( 기간종료일자 : YYYYMMDD)
	 * @return	long	longRtnDays 일수
	 * @throws ApplicationException
	 */
	public static long  getPridCaclByBoth(String argFmYmd, String argToYmd)
			throws ApplicationException
	{
		long		longRtnDays	= 0L;	// 호출한 BIZ로 반환하기 최종결과값.
		boolean		bValidFmYmd;
		boolean		bValidToYmd;

		try {
			// 1-1.1-1. 입력일(FROM DATE)의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidFmYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 1-2.1-2. 입력일(FROM DATE)의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidToYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 2. 두 일자간의 일수를 구한다.
			longRtnDays = DateUtils.getPeriodBetween(argFmYmd, argToYmd);
			
			// 3. 결과 일수에 +1 (양편넣기)
			longRtnDays++;
			
			return longRtnDays;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}

	/**
	 * <pre>
	 * 기간계산 (단편넣기)
	 * 개요 : 입력된 FROM DATE에서 TO DATE까지의 일수 계산(단편넣기)
	 * </pre>
	 * @param	String		argFmYmd( 기간시작일자 : YYYYMMDD )
	 * @param	String		argToYmd( 기간종료일자 : YYYYMMDD )
	 * @return	long		longRtnDays 일수
	 * @throws ApplicationException
	 */
	public static long  getPridCaclBySingle(String argFmYmd, String argToYmd) throws ApplicationException
	{
		long		longRtnDays = 0;	// 호출한 BIZ로 반환하기 최종결과값.
		boolean		bValidFmYmd;
		boolean		bValidToYmd;

		try {
			// 1-1.1-1. 입력일(FROM DATE)의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidFmYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 1-2.1-2. 입력일(FROM DATE)의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidToYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 2. 두 일자간의 일수를 구한다.
			longRtnDays = DateUtils.getPeriodBetween(argFmYmd, argToYmd);
			
			return longRtnDays;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}

	/**
	 * <pre>
	 * 기간개월수 (양편넣기)
	 * 개요 : 주어진 FROM DATE에서 TO DATE까지의 기간 개월수를 구한다(양편넣기)
	 * </pre>
	 * @param	String	argFmYmd( 기간시작일자 : YYYYMMDD )
	 * @param	String	argToYmd( 기간종료일자 : YYYYMMDD)
	 * @return	int		intRtnMons 월수
	 * @throws ApplicationException
	 */
	public static int  getPridMmcntByBoth(String argFmYmd, String argToYmd) throws ApplicationException
	{
		int intRtnMons = 0;	// 호출한 BIZ로 반환하기 최종결과값.
		boolean bValidFmYmd;
		boolean bValidToYmd;

		try {
			// 1-1.1-1. 입력일(FROM DATE)의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidFmYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 1-2.1-2. 입력일(FROM DATE)의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidToYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 3. 두 일자간의 기간 개월수를 구한다.
			intRtnMons = getMonthsDiff(argFmYmd, argToYmd);
			
			// 4. 나온 결과 개월수에 +1 을 한다(양편넣기 적용)
			intRtnMons++;
			
			return intRtnMons;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}

	/**
	 * <pre>
	 * 기간개월수 (단편넣기)
	 * 개요 : FROM DATE 에서 TO DATE까지의 기간을 개월수로 계산
	 * </pre>
	 * @param	String	argFmYmd( 기간시작일자 : YYYYMMDD )
	 * @param	String	argToYmd( 기간종료일자 : YYYYMMDD )
	 * @return	int		intRtnMons 월수
	 * @throws ApplicationException
	 */
	public static int  getPridMmcntBySingle(String argFmYmd, String argToYmd) throws ApplicationException
	{
		int intRtnMons = 0;	// 호출한 BIZ로 반환하기 최종결과값.
		boolean bValidFmYmd;
		boolean bValidToYmd;

		try {
			// 1-1.1-1. 입력일(FROM DATE)의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다.
			bValidFmYmd = DateUtils.isValidDate(argFmYmd, DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidFmYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }
			
			// 1-2.1-2. 입력일(FROM DATE)의 날짜 형식이 유효한지 체크. ( 날짜 형식이 유효하면 true. )
			bValidToYmd = DateUtils.isValidDate(argToYmd,  DateUtils.EMPTY_DATE_TYPE);
			if ( !bValidToYmd ) { throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); }

			// 두 일자간의 기간 개월수를 구한다.
			intRtnMons = getMonthsDiff(argFmYmd, argToYmd);
			
			return intRtnMons;
		} catch (Exception e) {
			if (e  instanceof ApplicationException) {
				throw (ApplicationException) e;
			} else {
				//APCME0000 : 처리중 오류가 발생했습니다.
				throw new ApplicationException( "APCME0000", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName(), e.getMessage() }, e );
			}
		}
	}

    /**
     * 지정된 월수로부터 주어진 월수 만큼 후의 날짜를 구한다.
     * @param after 몇월 후의 날짜를 구할 것인지, int 값 (양의정수)
     * @param argYm 기준년월, 6자리 String (예 : "201212")
     * @return 기준 월수로부터 after만큼 후의 년월을 6자리 String으로 돌려줌
     */
    public static String getYmMonthsAfter( int after, String argYm) throws ApplicationException
    {
		// 1.날짜 형식이 유효할 경우 TRUE
		// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다. 
		if ( !DateUtils.isValidDate(argYm + "01", DateUtils.EMPTY_DATE_TYPE) ) { 
			throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); 
		}
		
		// 1-2. 입력값 '계산월'이 범위내의 값인지 체크한다.
		// APCME0007 : 입력값이 범위를 벗어납니다.
		if ( after < 0 ) { 
			throw new ApplicationException( "APCME0007", null, new Object[]{new Throwable().getStackTrace()[0].getMethodName(),  "개산월", "양의정수" }); 
		}
		
    	int year = Integer.parseInt( argYm.substring(0, 4) );
    	int month = Integer.parseInt( argYm.substring(4, 6) );
    	
    	month += after;
    	
        if ( month>= 13)
        {
            year += month / 12;
            month = month % 12;
            if ( month % 12 == 0 )
            {
                --year;
                month = 12;
            }
        }
        
		return year + StringUtils.lpad(String.valueOf(month), 2, "0");

    }
    
    /**
     * 지정된 월수로부터 주어진 월수 만큼 전의 날짜를 구한다.
     * @param before 몇월 전의 날짜를 구할 것인지, int 값 (양의정수)
     * @param argYm 기준년월, 6자리 String (예 : "201212")
     * @return 기준 월수로부터 before만큼 전의 년월을 6자리 String으로 돌려줌
     */
    public static String getYmMonthsBefore( int before, String argYm ) throws ApplicationException
    {
		// 1-1.날짜 형식이 유효할 경우 TRUE
		// APCME0001 : 디폴트 날짜 포맷은 "YYYYMMDD" 입니다. 
		if ( !DateUtils.isValidDate(argYm + "01", DateUtils.EMPTY_DATE_TYPE) ) { 
			throw new ApplicationException( "APCME0001", null, new Object[]{ new Throwable().getStackTrace()[0].getMethodName() } ); 
		}
		
		// 1-2. 입력값 '계산월'이 범위내의 값인지 체크한다.
		// APCME0007 : 입력값이 범위를 벗어납니다.
		if ( before < 0 ) { 
			throw new ApplicationException( "APCME0007", null, new Object[]{new Throwable().getStackTrace()[0].getMethodName(),  "개산월", "양의정수" }); 
		}

		
    	int year = Integer.parseInt( argYm.substring(0, 4) );
    	int month = Integer.parseInt( argYm.substring(4, 6) );
    	
        month -= before;
        
        while ( month <= 0 )
        {
            month = 12 + month;
            year--;
        }
        
		return year + StringUtils.lpad(String.valueOf(month), 2, "0");
    }
}
