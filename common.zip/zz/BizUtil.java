package cigna.zz;

import klaf.app.ApplicationException;


/**
 * @file            cigna.zz.BizUtil.java
 * @filetype        java source file
 * @brief           업무공통 프로그램
 * @author          양윤철
 * @version         1.0
 * @history
 * Version         성명                    일자                          변경내용
 * -----------    ---------  -----------    ----------------- 
 * 1.0             양윤철                 2016. 01.29.  신규작성
 */

public class BizUtil {

	/** 매체타입코드_ILISA  */          
	public final static String MED_TYP_CD_ILS = "ILS";	
	/** 매체타입코드_기간계  */          
	public final static String MED_TYP_CD_COR = "COR";   
	/** 매체타입코드_컨택센터  */          
	public final static String MED_TYP_CD_COT = "COT";
	/** 매체타입코드_통합접수  */          
	public final static String MED_TYP_CD_CIR = "CIR";
	/** 매체타입코드_홈페이지  */          
	public final static String MED_TYP_CD_HOM = "HOM";
	/** 매체타입코드_모바일  */          
	public final static String MED_TYP_CD_MBH = "MBH";
	/** 매체타입코드_VOC  */          
	public final static String MED_TYP_CD_VOC = "VOC";
	/** 매체타입코드_GA  */          
	public final static String MED_TYP_CD_GAP = "GAP";
	/** 매체타입코드_TM  */          
	public final static String MED_TYP_CD_TMR = "TMR";
	/** 매체타입코드_ARS  */          
	public final static String MED_TYP_CD_ARS = "ARS";	
	/** 매체타입코드_DTC Web  */          
	public final static String MED_TYP_CD_DTW = "DTW";	

	 /**
	  * 영업제한대상 확인
	  * @param 
	  * @return boolean (true : 영업제한, false : 영업제한대상아님) 
	  * @throws ApplicationException
	  */
	 public static boolean isSalesRestr() throws ApplicationException { 
	  boolean result = false;
	  
	  String medTypCd = FwUtil.getMedTyp();
	  //String headerInfo = FwUtil.getHeaderInfo("interfaceId");
	  
	  if (MED_TYP_CD_ILS.equals(medTypCd)) {
	   result = true;
	  } else if (MED_TYP_CD_GAP.equals(medTypCd)) {
	   result = true;
	  } else if (MED_TYP_CD_COT.equals(medTypCd)) {
	   result = false;
	  }
	  
	  return result;
	 }
    
	 /**
	  * 전각문자를 반각문자로 변현
	  * @param String
	  * @return String
	  * @throws ApplicationException
	  */
	public static String toHalfChar(String src) {
		// 입력된 스트링이 null 이면 null 을 리턴
		if (src == null) {
		    return null;
		}
		
		// 변환된 문자들을 쌓아놓을 StringBuffer 를 마련한다
		StringBuffer strBuf = new StringBuffer();
		
		char c = 0;
		int nSrcLength = src.length();
		
		for (int i=0; i<nSrcLength; i++) {
			c = src.charAt(i);
			
			// 영문이거나  특수문자일경우
			if (c >= 0x21+0xfee0 && c <= 0x7e+0xfee0) {
				c -= 0xfee0;
			} else if (c == '　') {
				c = 0x20;
			}
			
			// 문자열 버퍼에 변환된 문자를 쌓는다
			strBuf.append(c);
		}
		return strBuf.toString();
	}
	
	/**
	 * 반각문자를 전각문자로 변현
	 * @param String
	 * @return String
	 * @throws ApplicationException
	 */
	public static String toFullChar(String src) {
		// 입력된 스트링이 null 이면 null 을 리턴
		if (src == null) {
			return null;
		}

		// 변환된 문자들을 쌓아놓을 StringBuffer 를 마련한다
		StringBuffer strBuf = new StringBuffer();

		char c = 0;
		int nSrcLength = src.length();
		for (int i = 0; i < nSrcLength; i++) {
			c = src.charAt(i);
			// 영문이거나 특수 문자 일경우.
			if (c >= 0x21 && c <= 0x7e) {
				c += 0xfee0;
			}
			// 공백일경우
			else if (c == 0x20) {
				c = 0x3000;
			}
			// 문자열 버퍼에 변환된 문자를 쌓는다
			strBuf.append(c);
		}
		return strBuf.toString();
	}
}