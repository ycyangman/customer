package cigna.zz;

/**
 * @file            cigna.zz.CommonConstant.java
 * @filetype        java source file
 * @brief           전사공통 상수 정의
 * @author          양윤철
 * @version         1.0
 * @history
 * Version         성명                    일자                          변경내용
 * -----------    ---------  -----------    ----------------- 
 * 1.0             양윤철                 2016. 01.29.  신규작성
 */
public class CommonCons {
	/**
	 * TA에서 정의한 파일 생성 디렉토리
	 */
	public	static	final String	AP_FILE_PRE_PATH;
	public	static	final String	CUTOVER_DATE;
	public	static	final String	TMP_DATE;
	static {
		AP_FILE_PRE_PATH	=	"/sdata/biz";
		/** CUTOVER 일자(for 대외계 헤더정보) */
		CUTOVER_DATE = "20170414";
		/** 해당일자(for 한신정 업권구분코드 분개) */
		TMP_DATE = "20170425";
	}
	
}
