package cigna.zz;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import klaf.container.ApplicationContextTrace;

/**
 * @file             cigna.zz.DbUtil.java
 * @filetype         java source file
 * @brief            DB처리와 관련된 공통기능 제공
 * @author           정창수
 * @version          1.0
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               정창수                 2012. 7. 1.       신규 작성
 * 0.6               정창수                 2012. 7.10.       개발 완료
 * 0.9               정창수                 2012. 7.21.       Class 테스트
 * 1.0               정창수                 2012. 7.21.       단위 테스트    
 *
 */

/**
 * 
 * DB처리와 관련된 공통기능 제공하기 위한 utility class 
 * 
 */
public class DbUtil {

	/**
	 * log 생성용..
	 **/
	private final static Logger LOGGER = LoggerFactory.getLogger(DbUtil.class);
	
	/**
	 * DBMS 접속을 위한 Data Source Name
	 * */
	private final static String DATA_SOURCE_NAME = "bizBIZDDBDS";
	private final static String DATA_SOURCE_BCV = "bcvBIZDDBDS";

	/**
	 * 승인된 Table에 대해 Truncation을 수행한다.
	 *  
	 * TRUNCATE는 권한이 있어야 하며 Table에 대한 TRUNCATE권한은 DBA에 요청하여 TRUNCATE관리 대상 Table에 등록되어 있어야 함.
	 * 승인된 Table에 대한 Truncation을 수행하며 승인되지 않은 Table에 대해서는 Truncation시 SQLException이 발생한다.
	 * @param tableName truncation하려는 table name 
	 * @throws SQLException Truncate권한이 없거나 truncate 대상 Table이 아닌 경우 발생하는 예외
	 */
	
	public static void truncate(String tableName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_NAME).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_TRUNC(?)}");
			cs.setString(1, tableName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}

	/**
	 * 승인된 Table의 특정 partition에 대한 truncation을 수행한다.
	 * 
	 * TRUNCATE는 권한이 있어야 하며 Table에 대한 TRUNCATE권한은 DBA에 요청하여 TRUNCATE관리 대상 Table에 등록되어 있어야 함.
	 * 승인된 Table의 특정 partition에 대한 Truncation을 수행하며 승인되지 않은 Table에 대해서는 Truncation시 SQLException이 발생한다.
	 * 
	 * @param tableName 		truncation하려는 table name
	 * @param partitionName	truncation하려는 partition name
	 * @throws SQLException Truncate권한이 없거나 truncate 대상 Table이 아닌 경우 발생하는 예외
	 */
	public static void truncate(String tableName, String partitionName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_NAME).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_TRUNC(?, ?)}");
			cs.setString(1, tableName);
			cs.setString(2, partitionName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}


	/**
	 * Table의 통계정보를 생성하는 API
	 * 
	 * @param tableName 통계정보를 생성할 TableName
	 * @throws SQLException
	 */
	public static void stats(String tableName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_NAME).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_GATHER_STATS(?)}");
			cs.setString(1, tableName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}
	
	/**
	 * Table 및 Index에 대한 No Logging option을 설정한다.
	 * 
	 * Table에서 대량의 데이터처리를 해야하는 경우에 TABLE 및 INDEX No logging option으로 실행할 수 있도록 설정한다.
	 * Table/Index에 대한 NO LOGGING 권한요청은 DBA 담당자에게 요청해야 되며 DBA에서 관리하는 Table에 등록되어 있어야 한다. 
	 * 
	 * @param tableName NO LOGGING을 시작할 Table Name 
	 * @throws SQLException 처리시 오류 내용 
	 */
	public static void beginNoLogging(String tableName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_NAME).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_NOLOGGING(?)}");
			cs.setString(1, tableName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}

	/**
	 * Table 및 Index에 대한 No Logging option을 Loggin option으로 변경함.
	 * 
	 * Table에서 대량의 데이터처리를 해야하는 경우에 TABLE 및 INDEX logging option으로 실행할 수 있도록 설정한다.
	 * Table/Index에 대한 NO LOGGING 권한요청은 DBA 담당자에게 요청해야 되며 DBA에서 관리하는 Table에 등록되어 있어야 한다. 
	 * @param tableName
	 * @throws SQLException
	 */
	public static void endNoLogging(String tableName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_NAME).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_LOGGING(?)}");
			cs.setString(1, tableName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}	
	
	/**
	 * KLaF에서 사용하는 데이터 Source Name을 얻는다.
	 * @return datasource name
	 */
	public static String getDataSourceName()
	{
		return DATA_SOURCE_NAME;
	}

	/**
	 * 승인된 Table에 대해 Truncation을 수행한다.
	 *  
	 * TRUNCATE는 권한이 있어야 하며 Table에 대한 TRUNCATE권한은 DBA에 요청하여 TRUNCATE관리 대상 Table에 등록되어 있어야 함.
	 * 승인된 Table에 대한 Truncation을 수행하며 승인되지 않은 Table에 대해서는 Truncation시 SQLException이 발생한다.
	 * @param tableName truncation하려는 table name 
	 * @throws SQLException Truncate권한이 없거나 truncate 대상 Table이 아닌 경우 발생하는 예외
	 */
	
	public static void truncateBCV(String tableName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_BCV).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_TRUNC(?)}");
			LOGGER.info("##### tbName = [{}] #####", tableName);
			cs.setString(1, tableName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}

	/**
	 * 승인된 Table의 특정 partition에 대한 truncation을 수행한다.
	 * 
	 * TRUNCATE는 권한이 있어야 하며 Table에 대한 TRUNCATE권한은 DBA에 요청하여 TRUNCATE관리 대상 Table에 등록되어 있어야 함.
	 * 승인된 Table의 특정 partition에 대한 Truncation을 수행하며 승인되지 않은 Table에 대해서는 Truncation시 SQLException이 발생한다.
	 * 
	 * @param tableName 		truncation하려는 table name
	 * @param partitionName	truncation하려는 partition name
	 * @throws SQLException Truncate권한이 없거나 truncate 대상 Table이 아닌 경우 발생하는 예외
	 */
	public static void truncateBCV(String tableName, String partitionName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_BCV).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_TRUNC(?, ?)}");
			LOGGER.info("##### tableName = [{}] #####", tableName);
			LOGGER.info("##### partitionName = [{}] #####", partitionName);

			cs.setString(1, tableName);
			cs.setString(2, partitionName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}


	/**
	 * Table의 통계정보를 생성하는 API
	 * 
	 * @param tableName 통계정보를 생성할 TableName
	 * @throws SQLException
	 */
	public static void statsBCV(String tableName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_BCV).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_GATHER_STATS(?)}");
			cs.setString(1, tableName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}
	
	/**
	 * Table 및 Index에 대한 No Logging option을 설정한다.
	 * 
	 * Table에서 대량의 데이터처리를 해야하는 경우에 TABLE 및 INDEX No logging option으로 실행할 수 있도록 설정한다.
	 * Table/Index에 대한 NO LOGGING 권한요청은 DBA 담당자에게 요청해야 되며 DBA에서 관리하는 Table에 등록되어 있어야 한다. 
	 * 
	 * @param tableName NO LOGGING을 시작할 Table Name 
	 * @throws SQLException 처리시 오류 내용 
	 */
	public static void beginNoLoggingBCV(String tableName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_BCV).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_NOLOGGING(?)}");
			cs.setString(1, tableName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}

	/**
	 * Table 및 Index에 대한 No Logging option을 Loggin option으로 변경함.
	 * 
	 * Table에서 대량의 데이터처리를 해야하는 경우에 TABLE 및 INDEX logging option으로 실행할 수 있도록 설정한다.
	 * Table/Index에 대한 NO LOGGING 권한요청은 DBA 담당자에게 요청해야 되며 DBA에서 관리하는 Table에 등록되어 있어야 한다. 
	 * @param tableName
	 * @throws SQLException
	 */
	public static void endNoLoggingBCV(String tableName) throws SQLException
	{
		DataSource 			ds  	= ApplicationContextTrace.getCurrentApplication().getDataSource(DATA_SOURCE_BCV).getDatasource();
		Connection 			con 	= null;
		CallableStatement 	cs		= null;

		try {
			con 	= ds.getConnection();
			cs		= con.prepareCall("{call SP_LOGGING(?)}");
			cs.setString(1, tableName);
			cs.execute();
		} finally {
			if(cs != null) {
				try {
					cs.close();
				} catch (Exception e) {
					LOGGER.error("Statement Close Exception: {}", e);
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (Exception e) {
					LOGGER.error("Connection Close Exception: {}", e);
				}
			}			
		}
	}	
	
	/**
	 * KLaF에서 사용하는 데이터 Source Name을 얻는다.
	 * @return datasource name
	 */
	public static String getDataSourceNameBCV()
	{
		return DATA_SOURCE_BCV;
	}

}
