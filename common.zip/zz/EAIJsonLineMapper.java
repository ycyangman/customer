package cigna.zz;

import org.json.JSONObject;
import org.springframework.batch.item.file.LineMapper;




/**
 * @file         cigna.zz.EAIJsonLineMapper.java
 * @filetype     java source file
 * @brief        EAIJsonLineMapper
 * @author       양윤철
 * @version      1.0
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박진성                 2016. 6. 1.      신규 작성
 *
 */
public class EAIJsonLineMapper implements LineMapper<String> {
	
	public String mapLine(String line, int lineNumber) throws Exception {
		JSONObject jsonObject = new JSONObject(line);
		
		return jsonObject.toString();
	}

}