package cigna.zz;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.xml.bind.annotation.XmlType;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.omm.annotation.KlafOmm_Field;
import klaf.omm.root.IOmmObject;

import org.apache.poi.ss.usermodel.BuiltinFormats;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import SCSL.SLDsFile;


/**
 * @file         cigna.zz.ExcelUtil.java
 * @filetype     java source file
 * @brief        엑셀관련 처리를 위한 Utility class
 * @author       박진성
 * @version      1.0
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박진성                 2016. 3. 28.      신규 작성
 *
 */
public class ExcelUtil {
	final static Logger LOGGER = LoggerFactory.getLogger(ExcelUtil.class);

    private static final String FONT_NAME = "돋움체";
	
	/**  엑셀(파일) 대량 업로드 파일경로 */
	private static final String UI_ONLINE_FILE_PATH = "/sdata/biz/ui/online/";
	
	/**
	 * DRM 엑셀파일을 만든다
	 * 
	 * @param gridInfoList 그리드정보리스트
	 * @param sourceDataList 출력될 데이터리스트
	 * @throws ApplicationException
	 */
	public static String createDrmExcel(String gridInfoJson, List<? extends Object> sourceDataList) throws ApplicationException {
		

		// 실제 Excel파일생성
		String fileName = createSXSSExcel(gridInfoJson, sourceDataList);
		
		// DRM으로 암호화된 파일생성
		String drmFileName = fileName.replace(".xlsx", "_drm.xlsx");

		SLDsFile sFile = new SLDsFile();
		sFile.SettingPathForProperty("/app/softcamp/02_Module/02_ServiceLinker/softcamp.properties"); 
		
		sFile.SLDsInitGrade();
		int dSSLDocuGradeEncAddCreator = sFile.DSSLDocuGradeEncAddCreator ( "/app/softcamp/04_KeyFile/keyGrade_SVR0.sc", 
		"System",  "none", "0000003", //Grade ID
		"SECURITYDOMAIN", "SECURITYDOMAIN;", "none", fileName, drmFileName, "SECURITYDOMAIN", "SECURITYDOMAIN;", 	"/app/softcamp/04_KeyFile/keyDAC_SVR0.sc", 0, 0 );
		LOGGER.debug( "DSSLDocuGradeEncAddCreator [" + dSSLDocuGradeEncAddCreator  + "]");
		
		// 암호화 이전 원본파일은 삭제한다
		File file = new File(fileName);
		if(file.exists() && !file.isDirectory()) { 
			try {
				file.delete();
			} catch (Exception e) {
				LOGGER.error("{} 파일삭제오류: {}", new Object[] {fileName, e});
				throw new ApplicationException("APCME0032", new Object[] {fileName});
			}
		} else {
			LOGGER.error("{} 파일삭제오류: 파일존재하지 않음", new Object[] {fileName});
		}
		
		return drmFileName;
	}
	
	/**
	 * 엑셀파일을 만든다
	 * 
	 * @param gridInfoJson 그리드정보
	 * @param sourceDataList 출력될 데이터리스트
	 * @throws ApplicationException
	 */
	public static String createExcel(String gridInfoJson, List<? extends Object> sourceDataList) throws ApplicationException {
		String fileName = null;
		
		XSSFWorkbook wb = new XSSFWorkbook(); // workbook 생성
		XSSFSheet sheet = wb.createSheet();
		
		List<HashMap<String, String>> jsonToHashMapList = jsonToHashMapList(gridInfoJson);
		
		// 헤더 생성
		int nextRowIndex = processHeader(wb, sheet, jsonToHashMapList);
		
		// 바디 생성
		nextRowIndex = processBody(wb, sheet, jsonToHashMapList, sourceDataList, nextRowIndex);
		
		FileOutputStream fileOut = null;
		try {
			// 파일명은 yyyyMMddHHmmss001.xls 형태로 생성된다
			String date = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			String time = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			
			fileName = UI_ONLINE_FILE_PATH + date + time + "001.xlsx";
			
			fileOut = new FileOutputStream(fileName);

			wb.write(fileOut);
			
		} catch (FileNotFoundException e) {
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[FileNotFoundException] 파일생성 중 에러발생" }, e );
		} catch (IOException e) {
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[IOException] 파일생성 중 에러발생" }, e );
		} finally {
			// 오픈된 Stream을 닫아준다
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOGGER.debug("Fileout Close Fails");
			}
		}
		
		return fileName;
	}
	
	
	/**
	 * 엑셀파일을 만든다
	 * 만건단위 flush 
	 * @param gridInfoJson 그리드정보
	 * @param sourceDataList 출력될 데이터리스트
	 * @throws ApplicationException
	 */
	public static String createSXSSExcel(String gridInfoJson, List<? extends Object> sourceDataList) throws ApplicationException {
		
		LOGGER.debug("Called By createSXSSExcel");
		
		String fileName = null;
		
		SXSSFWorkbook wb = new SXSSFWorkbook();
		wb.setCompressTempFiles(true);
		
		SXSSFSheet sheet = (SXSSFSheet)wb.createSheet();		
		sheet.setRandomAccessWindowSize(10000);
		
		List<HashMap<String, String>> jsonToHashMapList = jsonToHashMapList(gridInfoJson);
		
		// 헤더 생성
		int nextRowIndex = processHeader(wb, sheet, jsonToHashMapList);
		
		// 바디 생성
		nextRowIndex = processBody(wb, sheet, jsonToHashMapList, sourceDataList, nextRowIndex);
		
		FileOutputStream fileOut = null;
		try {
			// 파일명은 yyyyMMddHHmmss001.xls 형태로 생성된다
			String date = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
			String time = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
			
			fileName = UI_ONLINE_FILE_PATH + date + time + "001.xlsx";
			
			fileOut = new FileOutputStream(fileName);

			wb.write(fileOut);
			
		} catch (FileNotFoundException e) {
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[FileNotFoundException] 파일생성 중 에러발생" }, e );
		} catch (IOException e) {
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[IOException] 파일생성 중 에러발생" }, e );
		} finally {
			// 오픈된 Stream을 닫아준다
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOGGER.debug("Fileout Close Fails");
			}
		}
		
		return fileName;
	}
	
	/**
	 * 입력된 grid 헤더정보값을 List<HashMap> 형태로 만든다
	 * 
	 * @param jasonString 그리드정보
	 * @return List<HashMap<String,String>>
	 * @throws ApplicationException
	 */
	private static List<HashMap<String,String>> jsonToHashMapList(String jasonString) throws ApplicationException {
		List<HashMap<String,String>> jsonHashMapList = new ArrayList<HashMap<String,String>>();
		
		if (StringUtils.isEmpty(jasonString)) {
			// 필수항목 [{0}]을(를) 입력하여야 합니다.
			throw new ApplicationException("APCME0008", new Object[]{"Grid 정보"}, new Object[]{});
		}
		
		// String 형태로 온 Header 정보를 파싱하여  HashMap의 ArrayList로 만든다
		LOGGER.debug("jasonString : " + jasonString);
		String[] gridInfoListArray = jasonString.split("\\$"); // 행단위 splite
		for (String gridInfoString : gridInfoListArray) {
			String[] gridInfoArray = gridInfoString.split("\\|"); // 열단위 splite
			
			HashMap<String,String> gridInfoHashMap = new HashMap<String,String>();
			
			for (String gridInfo : gridInfoArray) {
				gridInfo = gridInfo.replaceAll("\"", "");
				String[] gridInfoSplit = gridInfo.split("\\:"); // key:value 형태의 splite
				if (gridInfoSplit.length > 1) {
					gridInfoHashMap.put(gridInfoSplit[0], gridInfoSplit[1]);
				} else {
					gridInfoHashMap.put(gridInfoSplit[0], "");
				}
			}
			
			jsonHashMapList.add(gridInfoHashMap);
		}
		
		return jsonHashMapList;
	}
	
	/**
	 * 엑셀 헤더생성
	 * 
	 * @param workbook 엑셀 워크북
	 * @param sheet 엑셀 시트
	 * @param jsonToHashMapList 그리드정보리스트
	 * @return int nextRowIndex 다음행 index
	 * @throws ApplicationException
	 */
    private static int processHeader(Workbook workbook, Sheet sheet,List<HashMap<String, String>> jsonToHashMapList) {
        Row row = null;
        
        // 헤더의 셀 스타일을 지정한다
        CellStyle cellstyle = basicCellStyle(workbook, true);
        int colIndex = 0;
        
		for (HashMap<String, String> jsonToHashMap : jsonToHashMapList) {
            String headerTitle = jsonToHashMap.get("headerTitle");
            
            // 헤더 1행
            if (headerTitle != null) {
            	headerTitle = headerTitle.replaceAll("&amp;", "&").replaceAll("<br>", " ");
	            row = sheet.getRow(0);
	            if(row == null)
	                row = sheet.createRow(0);
	            
	            createCell(row, headerTitle, colIndex, cellstyle);
            }
            
            // 헤더 2행
            String headerTitle2 = jsonToHashMap.get("headerTitle2");
            
            if (headerTitle2 != null) {
            	headerTitle2 = headerTitle2.replaceAll("&amp;", "&").replaceAll("<br>", " ");
	            row = sheet.getRow(1);
	            if(row == null)
	                row = sheet.createRow(1);
	            
	            createCell(row, headerTitle2, colIndex, cellstyle);
            }
            
            // 헤더 3행
            String headerTitle3 = jsonToHashMap.get("headerTitle3");
            
            if (headerTitle3 != null) {
            	headerTitle3 = headerTitle3.replaceAll("&amp;", "&").replaceAll("<br>", " ");
	            row = sheet.getRow(2);
	            if(row == null)
	                row = sheet.createRow(2);
	            
	            createCell(row, headerTitle3, colIndex, cellstyle);
            }
            
            colIndex++;
		}
		
		// 헤더의 같은 열 이름을 merge한다
		for (int baseCellIndex=0; baseCellIndex<jsonToHashMapList.size(); baseCellIndex++) {
			// 첫째 행 merge
			String headerTitle = jsonToHashMapList.get(baseCellIndex).get("headerTitle");
			
			if (headerTitle == null) {
				continue;
			}
			
			// 이전행 조회해서 같은 이름이 있다면 셀병합한다
			int mergeCellIndex = baseCellIndex;
			for (int j=baseCellIndex+1; j<jsonToHashMapList.size(); j++) {
				String prevHeaderTitle = jsonToHashMapList.get(j).get("headerTitle");
				
				if (prevHeaderTitle != null && prevHeaderTitle.equals(headerTitle)) {
					mergeCellIndex = j;
				} else {
					break;
				}
			}
			
			int baseRowIndex = 0;
			int mergeRowIndex = 0;
			String headerTitle2 = jsonToHashMapList.get(baseCellIndex).get("headerTitle2");
			if (headerTitle.equals(headerTitle2)) {
				mergeRowIndex = 1;
			}
			
			if (mergeCellIndex != baseCellIndex || mergeRowIndex != baseRowIndex) {
				sheet.addMergedRegion(new CellRangeAddress(baseRowIndex, mergeRowIndex, baseCellIndex, mergeCellIndex));
			}
			
			baseCellIndex = mergeCellIndex;
		}
		
		// 헤더의 같은 열 이름을 merge한다
		for (int baseCellIndex=0; baseCellIndex<jsonToHashMapList.size(); baseCellIndex++) {
			// 두번째 행 merge
			String headerTitle2 = jsonToHashMapList.get(baseCellIndex).get("headerTitle2");
			
			if (StringUtils.isEmpty(headerTitle2)) {
				continue;
			}
			
			// 이전행 조회해서 같은 이름이 있다면 셀병합한다
			int mergeCellIndex = baseCellIndex;
			for (int j=baseCellIndex+1; j<jsonToHashMapList.size(); j++) {
				String prevHeaderTitle2 = jsonToHashMapList.get(j).get("headerTitle2");
				
				if (prevHeaderTitle2 != null && prevHeaderTitle2.equals(headerTitle2)) {
					mergeCellIndex = j;
				} else {
					break;
				}
			}
			
			int baseRowIndex = 1;
			int mergeRowIndex = 1;
			String headerTitle3 = jsonToHashMapList.get(baseCellIndex).get("headerTitle3");
			if (headerTitle2.equals(headerTitle3)) {
				mergeRowIndex = 1;
			}
			
			if (mergeCellIndex != baseCellIndex || mergeRowIndex != baseRowIndex) {
				sheet.addMergedRegion(new CellRangeAddress(mergeRowIndex, mergeRowIndex, baseCellIndex, mergeCellIndex));
			}
			
			baseCellIndex = mergeCellIndex;
		}

		if (sheet.getRow(2) != null) {
			return 3;
		} if (sheet.getRow(1) != null) {
			return 2;
		} else {
			return 1;
		}
    }
	
    /**
	 * 엑셀 바디생성
	 * 
	 * @param workbook 엑셀 워크북
	 * @param sheet 엑셀 시트
	 * @param jsonToHashMapList 그리드정보리스트
	 * @param sourceDataList 실제 행데이터 리스트
	 * @return int nextRowIndex 다음행 index
	 * @throws ApplicationException
	 */
    private static int processBody(Workbook workbook, Sheet sheet,List<HashMap<String, String>> jsonToHashMapList, List<? extends Object> sourceDataList, int rowIndex)  throws ApplicationException {
    	// 바디의 셀 스타일 목록
    	List<CellStyle> cellstyleList = new ArrayList<CellStyle>();
    	
    	int nextRowIndex = rowIndex; // 행번호
    	
    	LOGGER.debug("nextRowIndex : " + nextRowIndex);
    	
    	for (Object sourceData : sourceDataList) {
			Row row = sheet.getRow(nextRowIndex);
			if(row == null) {
				row = sheet.createRow(nextRowIndex);
			}
			
			// 다음 행 인덱스 생성
			nextRowIndex = nextRowIndex + 1;
			
			// 폰트정보
	        Font font = workbook.createFont();
	        font.setFontName(FONT_NAME);
	        font.setFontHeightInPoints((short)10);
	        font.setColor(IndexedColors.BLACK.getIndex());
			
			// 헤더정보만큼 열을 만든다
			int i = 0; // cell index
			for (HashMap<String, String> jsonToHashMap : jsonToHashMapList) {
				CellStyle cellstyle = null;
				if (cellstyleList.size() > i) {
					cellstyle = cellstyleList.get(i);
				}
				
				// 데이터포멧
				String type = jsonToHashMap.get("type");
				String mask = jsonToHashMap.get("mask");
				
				if (cellstyle == null) {
					// 헤더의 셀 스타일을 지정한다
					cellstyle = workbook.createCellStyle();
			        cellstyle.setVerticalAlignment((short)1);
			        cellstyle.setFont(font);
			        cellstyle.setBorderRight((short)1);
			        cellstyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			        cellstyle.setBorderLeft((short)1);
			        cellstyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			        cellstyle.setBorderTop((short)1);
			        cellstyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
			        cellstyle.setBorderBottom((short)1);
			        cellstyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			        
			        String hAlign = jsonToHashMap.get("hAlign"); // 정렬값
			        String hAlignLowerCase = hAlign.toLowerCase(Locale.ENGLISH);
			        if (!StringUtils.isEmpty(hAlign) && "left".equals(hAlignLowerCase)) {
			        	cellstyle.setAlignment((short)1);
			        } else if (!StringUtils.isEmpty(hAlign) && "right".equals(hAlignLowerCase)) {
			        	cellstyle.setAlignment((short)3);
			        } else {
			        	cellstyle.setAlignment((short)2);
			        }
			        
					// 열넓이
					String width = jsonToHashMap.get("width");
			        if (!StringUtils.isEmpty(width) && StringUtils.isDigit(width)) {
			        	int widthInt = Integer.parseInt(width);
			        	if (widthInt > 0) {
			        		//sheet.setColumnWidth(i, widthInt * 1000);
			        		//int maxColumnWidth = 255 * 256
			        		int maxColumnWidth = 8000;
			        		sheet.setColumnWidth(i, (widthInt*1000<maxColumnWidth)?(widthInt*1000):maxColumnWidth);
			        	}
			        }
			        
					HashMap<String, String> inputTypeMap = new HashMap<String, String>();
					//inputTypeMap.put("num", "#,###"); // num 숫자형(#,###)
					inputTypeMap.put("ssn", "######-#######"); // ssn 주민등록번호 (######-#######)
					inputTypeMap.put("lrn", "######-#######"); // lrn 법인등록번호 (######-#######)
					inputTypeMap.put("brn", "###-##-#####"); // brn 사업자등록번호 (###-##-#####)
					inputTypeMap.put("foreign", "######-#######"); // foreign 외국인등록번호 (######-#######)
					inputTypeMap.put("post", "###-###"); // post 우편번호 (###-###)
					inputTypeMap.put("card", "####-####-####-####"); // card 신용카드번호 (####-####-####-####)
					inputTypeMap.put("mobile", "###-####-####"); // mobile 휴대폰번호 (###-####-####)
					inputTypeMap.put("date", "yyyy-MM-dd"); // date 날짜 (yyyy-MM-dd)
					inputTypeMap.put("time", "hh:mm:ss"); // time 시간 (hh:mm:ss)
					inputTypeMap.put("datetime", "yyyy-MM-dd hh:mm:ss"); // time 시간 (hh:mm:ss)
					
					// mask가 있는경우 포멧으로 지정, 타입에 해당하는 데이터 타입에 맞는 해당포멧 지정, 이외 text포멧
					if (!StringUtils.isEmpty(mask)) {
						mask = mask.replaceAll("#\\.", "0.");
						cellstyle.setDataFormat(workbook.createDataFormat().getFormat(mask));
					} else if (!StringUtils.isEmpty(type) && !StringUtils.isEmpty(inputTypeMap.get(type.toLowerCase(Locale.ENGLISH))) ) {
						cellstyle.setDataFormat(workbook.createDataFormat().getFormat(inputTypeMap.get(type.toLowerCase(Locale.ENGLISH))));
					} else {
						cellstyle.setDataFormat((short)BuiltinFormats.getBuiltinFormat("text"));
					}
					
					cellstyleList.add(i, cellstyle);
				}
				
				// 실제데이터 필드명
				String fieldName = jsonToHashMap.get("textValue");
				String returnString = "";
				if (!StringUtils.isEmpty(fieldName)) {
					// 화면마다 grid정보가 다를수 있으므로 헤더에서 받은 필드명으로 invoke 시킨다
					Object obj = ReflUtil.doGetterMethod(sourceData, fieldName);
					if (obj != null) {
						if (obj.getClass().isAssignableFrom(Integer.class)) {
							returnString = String.valueOf((Integer)obj);
						} else if (obj.getClass().isAssignableFrom(Double.class)) {
							returnString = String.valueOf((Double)obj);
						} else if (obj.getClass().isAssignableFrom(BigDecimal.class)) {
							BigDecimal tempBigDecimal = (BigDecimal)obj;
							returnString = tempBigDecimal.toString();
						} else {
							// 자료형이 문자열이고 날짜포멧일때 처리
							if (StringUtils.isEmpty(mask)) {
								if (obj.getClass().isAssignableFrom(String.class)) {
									if ("date".equals(type.toLowerCase(Locale.ENGLISH))) {
										cellstyle.setDataFormat(workbook.createDataFormat().getFormat("####-##-##"));
									} else if ("time".equals(type.toLowerCase(Locale.ENGLISH))) {
										cellstyle.setDataFormat(workbook.createDataFormat().getFormat("##\":\"##\":\"##"));
									} else if ("datetime".equals(type.toLowerCase(Locale.ENGLISH))) {
										cellstyle.setDataFormat(workbook.createDataFormat().getFormat("####-##-## ##\":\"##\":\"##"));
									}
								}
							}
							
							returnString = StringUtils.nvl((String)obj);
						}
					}
					
					// Properties확인하여 마스킹처리
					if (!StringUtils.isEmpty(returnString)) {
						returnString = MaskUtil.getMaskingValue(fieldName, returnString);
					}
				}
				
				// 셀 입력
				i = createCell(row, returnString, i, cellstyle);
			
			}
    	}
    	
    	return nextRowIndex;
    }

	/**
	 * 셀스타일 생성
	 * 
	 * @param workbook 엑셀 워크북
	 * @param sheet 엑셀 시트
	 * @return CellStyle
	 * @throws ApplicationException
	 */
	private static CellStyle basicCellStyle(Workbook workbook, boolean headerFlag) {
		CellStyle cellstyle = workbook.createCellStyle();
		if (headerFlag) {
			// 헤더의 셀 스타일을 지정한다
			Font font = workbook.createFont();
			font.setFontName(FONT_NAME);
			font.setFontHeightInPoints((short) 10);
			font.setColor(IndexedColors.WHITE.getIndex());
			font.setBoldweight((short) 700);

			cellstyle.setAlignment((short) 2);
			cellstyle.setVerticalAlignment((short) 1);
			cellstyle.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
			cellstyle.setFillPattern((short) 1);
			cellstyle.setFont(font);
			cellstyle.setBorderRight((short) 1);
			cellstyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellstyle.setBorderLeft((short) 1);
			cellstyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			cellstyle.setBorderTop((short) 1);
			cellstyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
			cellstyle.setBorderBottom((short) 1);
			cellstyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			cellstyle.setDataFormat((short)BuiltinFormats.getBuiltinFormat("text"));

		} else {
			// 바디의 셀 스타일을 지정한다
			Font font = workbook.createFont();
			font.setFontName(FONT_NAME);
			font.setFontHeightInPoints((short) 10);
			font.setColor(IndexedColors.BLACK.getIndex());

			cellstyle.setVerticalAlignment((short) 1);
			cellstyle.setFont(font);
			cellstyle.setBorderRight((short) 1);
			cellstyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
			cellstyle.setBorderLeft((short) 1);
			cellstyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			cellstyle.setBorderTop((short) 1);
			cellstyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
			cellstyle.setBorderBottom((short) 1);
			cellstyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			cellstyle.setDataFormat((short)BuiltinFormats.getBuiltinFormat("text"));
		}

		return cellstyle;
	}
    
    /**
	 * 셀 생성
	 * 
	 * @param workbook 엑셀 워크북
	 * @param sheet 엑셀 시트
	 * @param row 입력될 생성된
	 * @param stringValue 입력된 값
	 * @param i 입력될 열 인덱스
	 * @param cellstyle 입력될 셀의 스타일
	 * @return int j 다음열의 index
	 */
    private static int createCell(Row row, String stringValue, int i, CellStyle cellstyle)
    {
        //Cell cell = row.getCell(i);
        int j = i;
        
        for (int k=0; k<100; k++) {
        	Cell cell = row.getCell(i+k);
        	
        	// 셀이 있다면 다음열을 생성하고 없다면 해당열에 생성한다 
        	if (cell == null) {
        		Cell cell1 = row.createCell(i+k);
                /*
                if(stringValue.contains("\n"))
                {
                    CellStyle cellstyle1 = workbook.createCellStyle();
                    cellstyle1.cloneStyleFrom(cellstyle);
                    cellstyle = cellstyle1;
                    cellstyle.setWrapText(true);
                }
                */

                cell1.setCellStyle(cellstyle);
                setCellValue(cell1, stringValue);
                j = i + k + 1;
                
                break;
        	}
        }

        /*
        if(cell != null)
        {
        	// 셀이 있다면 다음 열에 생성
            j = createCell(workbook, sheet, row, stringValue, i + 1, cellstyle);
        } else
        {
            Cell cell1 = row.createCell(i);

            cell1.setCellStyle(cellstyle);
            setCellValue(cell1, stringValue);
            j = i + 1;
        }
        */
        
        return j;
    }

    /**
	 * 셀 생성
	 * 
	 * @param cell 입력될 셀
	 * @param stringValue 입력된 값
	 */
    private static void setCellValue(Cell cell, String stringValue)
    {
        if(DateUtil.isCellDateFormatted(cell))
        	// 날짜 형태라면 날짜 포멧으로 만든후 보내야 엑셀에서 자릿수 오류가 없다
            try
            {
            	if (!StringUtils.isEmpty(stringValue)) {
	                String formatString = cell.getCellStyle().getDataFormatString();
	                SimpleDateFormat simpledateformat = new SimpleDateFormat(formatString, Locale.KOREA);
	                if(formatString.length() > stringValue.length())
	                    cell.setCellValue(simpledateformat.format(toDate(stringValue, formatString)));
	                else
	                    cell.setCellValue(stringValue);
            	} else {
            		cell.setCellValue("");
            	}
            }
            catch(ParseException parseexception)
            {
                cell.setCellValue(stringValue);
            }
        else
        if(!cell.getCellStyle().getDataFormatString().equals("@") && isDigit(stringValue))
        	// 숫자형태의 셀 타입
        	if (!StringUtils.isEmpty(stringValue)) {
        		cell.setCellValue(Double.parseDouble(stringValue));
        	} else {
        		cell.setCellValue(0.0d);
        	}
        else
        	// 텍스트 셀타입
            cell.setCellValue(stringValue);
    }
    
    private static boolean isDigit(String stringValue) {

    	if (StringUtils.isEmpty(stringValue)) {
    		return false;
    	}
    	
    	for (int i=0; i<stringValue.length(); i ++) {
    		if (!"0123456789.-+".contains(stringValue.substring(i,i+1))) {
    			return false;
    		}
    	}
    	return true;

    }
    
    /**
	 * 문자열 값을 해당 mask에 맞게 날짜형으로 변환한다
	 * 
	 * @param stringValue 입력된 값
	 * @param formatString 데이터포멧
	 */
    private static Date toDate(String stringValue, String formatString)
        throws ParseException
    {
    	StringBuilder formatStringBuffer = new StringBuilder("");
        int i = 0;
        for(int j = formatString.length(); i < j; i++)
        {
        	// date 형태로 만들기위해 format의 특수기호값 제거 후 입력한다
            char tmpChar = formatString.charAt(i);
            if(tmpChar == 'y' || tmpChar == 'M' || tmpChar == 'd')
            	formatStringBuffer.append(tmpChar);
        }

        SimpleDateFormat simpledateformat = new SimpleDateFormat(formatStringBuffer.toString(), Locale.KOREA);
        
        return simpledateformat.parse(stringValue);
    }
    
    /**
	 * IOmm을 상속받은 IO의 리스트를 Excel로 저장한다
	 * 
	 * @param filePath 파일경로
	 * @param sourceDataList 실제데이터
	 */
	public static void createExcelByIOmmObject(String filePath, List<? extends IOmmObject> sourceDataList) throws ApplicationException {
		int rowIndex=0;
		
		XSSFWorkbook workbook = new XSSFWorkbook(); // workbook 생성
		XSSFSheet sheet = workbook.createSheet();
		
		// 헤더의 셀 스타일을 지정한다
		CellStyle headerCellStyle = basicCellStyle(workbook, true);
		
		// 바디의 셀 스타일을 지정한다
		CellStyle bodyCellStyle = basicCellStyle(workbook, false);

		// 헤더생성
		for (IOmmObject sourceData : sourceDataList) {
			Row row = sheet.getRow(rowIndex);
			if(row == null) {
				row = sheet.createRow(rowIndex);
			}
			
			Class<? extends IOmmObject> sourceDataClass = sourceData.getClass();
			
			// 어노테이션xmlType에서 field명을 조회한다
			XmlType xmlType = sourceDataClass.getAnnotation(XmlType.class);
			String[] propOrderArray = xmlType.propOrder();
			
			int colIndex = 0;
			for (String propOrder : propOrderArray) {
				LOGGER.info("propOrder : " + propOrder);
				
				String headerTitle = null;
				try {
					Field declaredField = sourceDataClass.getDeclaredField(propOrder);
					
					// 어노테이션klafOmmField에서 설명을 조회하여 헤더로 사용한다
					KlafOmm_Field klafOmmField = declaredField.getAnnotation(KlafOmm_Field.class);
					headerTitle = klafOmmField.description();
					if (StringUtils.isEmpty(headerTitle)) {
						headerTitle = propOrder;
					}
				} catch (NoSuchFieldException e) {
					LOGGER.debug("[NoSuchFieldException] header생성중 에러 : " + propOrder);
					headerTitle = propOrder;
				} catch (SecurityException e) {
					LOGGER.debug("[NoSuchFieldException] header생성중 에러 : " + propOrder);
					headerTitle = propOrder;
				}
			
				createCell(row, headerTitle, colIndex, headerCellStyle);
			
				colIndex++;
			}
			rowIndex++;
			break;
		}
		
		// 바디생성
		for (IOmmObject sourceData : sourceDataList) {
			Row row = sheet.getRow(rowIndex);
			if(row == null) {
				row = sheet.createRow(rowIndex);
			}
			
			Class<? extends IOmmObject> sourceDataClass = sourceData.getClass();
			
			// 어노테이션xmlType에서 field명을 조회한다
			XmlType xmlType = sourceDataClass.getAnnotation(XmlType.class);
			String[] propOrderArray = xmlType.propOrder();
			
			int colIndex = 0;
			for (String propOrder : propOrderArray) {
				
				// 바디생성
				String returnString = "";
				if (!StringUtils.isEmpty(propOrder)) {
					// 화면마다 grid정보가 다를수 있으므로 헤더에서 받은 필드명으로 invoke 시킨다
					Object obj = ReflUtil.doGetterMethod(sourceData, propOrder);
					if (obj != null) {
						if (obj.getClass().isAssignableFrom(Integer.class)) {
							returnString = String.valueOf((Integer)obj);
						} else if (obj.getClass().isAssignableFrom(Double.class)) {
							returnString = String.valueOf((Double)obj);
						} else if (obj.getClass().isAssignableFrom(BigDecimal.class)) {
							BigDecimal tempBigDecimal = (BigDecimal)obj;
							
							DecimalFormat df = new DecimalFormat("#,##0.########");
							returnString = df.format(tempBigDecimal);
						} else {
							returnString = StringUtils.nvl((String)obj);
						}
					}
				}
				
				// Properties확인하여 마스킹처리
				//returnString = MaskUtil.getMaskingValue(propOrder, returnString);
				
				// 셀 입력
				createCell(row, returnString, colIndex, bodyCellStyle);
				
				colIndex++;
			}
			
			rowIndex++;
		}
		
		FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(filePath);

			workbook.write(fileOut);
		} catch (FileNotFoundException e) {
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[FileNotFoundException] 파일생성 중 에러발생" }, e );
		} catch (IOException e) {
			throw new ApplicationException( "KIERE0005", null, new Object[]{ "[IOException] 파일생성 중 에러발생" }, e );
		} finally {
			// 오픈된 Stream을 닫아준다
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOGGER.debug("Fileout Close Fails");
			}
		}
	}
	
}