package cigna.zz;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.media.jai.codec.JPEGEncodeParam;


/**
 * @file         cigna.zz.FileUtil.java
 * @filetype     java source file
 * @brief        파일관련 처리를 위한 Utility class
 * @author       정창수
 * @version      1.0
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           정창수                 2013. 7. 18.      신규 작성
 * 1.0           정창수                 2013. 7. 19.      테스트 완료.
 * 5.1           김정국                 2014. 9. 24.      tiffTojpg() 메서드를 제공하여 TIFF 포맷 파일을 JPG 파일로 변환
 *
 */
public class FileUtil {
	final static Logger LOGGER = LoggerFactory.getLogger(FileUtil.class);
	
	/**
	 * FILE 목록 조회시 오름차순으로 Sorting한다.
	 */
	public final static int FILE_SORT_ASC  = 0;
	
	/**
	 * FILE 목록 조회시 내림차순으로 Sorting한다. 
	 */
	public final static int FILE_SORT_DESC = 1;
	
	/**
	 * tiff를 jpg로 변환시 원본 유지율 100%
	 */
	public final static int G_100 = 0;
	/**
	 * tiff를 jpg로 변환시 원본 유지율 75%
	 */
	public final static int G_75 = 1;
	/**
	 * tiff를 jpg로 변환시 원본 유지율 50%
	 */
	public final static int G_50 = 2;
	/**
	 * tiff를 jpg로 변환시 원본 유지율 25%
	 */
	public final static int G_25 = 3;
	private final static float[] qualityArray = new float[]{1.0F, 0.75F, 0.5F, 0.25F};
	
	/**
	 * 파일을 복사한다.
	 * 
	 * @param srcFile 복사할 파일명
	 * @param destFile 새로만들 파일명
	 * @throws ApplicationException
	 */
	public static void copy(String srcFile, String destFile) throws ApplicationException {
		String targetFile = destFile;
		File   sFile      = null;
		
		if(StringUtils.isEmpty(srcFile)) {
			throw new ApplicationException("APCME0025", new Object[] {"Source File"}, new Object[] {"Source File"});
		}
		if(StringUtils.isEmpty(destFile)) {
			throw new ApplicationException("APCME0025", new Object[] {"Target File"}, new Object[] {"Target File"});
		}
		sFile = new File(srcFile);
		if(!sFile.exists()) {
			throw new ApplicationException("APCME0029", new Object[] {srcFile});
		}
		
		/*
		 * destFile이 디렉토리이면 srcFile의 파일명으로 저장함.
		 */
		File dFile = new File(destFile);
		if(dFile.exists() && dFile.isDirectory()) { 
			targetFile = destFile + "/" + sFile.getName();
			dFile = new File(targetFile);
		}

		if(sFile.getAbsolutePath().equals(dFile.getAbsolutePath())) {
			// srcFile과 destFile이 같은 파일이면 아무작업을 하지 않고 정상 종료시킨다.
			return;
		}		
		
		FileInputStream  srcStream = null;
		FileOutputStream dstStream = null;
		
		try {
			try {
				srcStream = new FileInputStream(srcFile);
			} catch (Exception e) {
				LOGGER.error("Error : ", e);
				throw new ApplicationException("APCME0030", new Object[] {srcFile}, new Object[]{e.toString()}, e);
			}
			try {
				dstStream = new FileOutputStream(targetFile);
			} catch (Exception e) {
				LOGGER.error("Error : ", e);
				throw new ApplicationException("APCME0031", new Object[] {destFile}, new Object[]{e.toString()}, e);
			}
			byte data[] = new byte[8192];
			int  readSize;

			try {
				while((readSize = srcStream.read(data)) > 0) {
					dstStream.write(data, 0, readSize);
				}
			} catch (Exception e) {
				LOGGER.error("Error : ", e);
				throw new ApplicationException("APCME0031", new Object[] {destFile}, new Object[]{e.toString()}, e);
			}
		} finally {
			try {
				if(srcStream != null) {
					srcStream.close();
				}
			}catch(Exception e) {
				LOGGER.error("Error : ", e);
			}
			try {
				if(dstStream != null) {
					dstStream.close();
				}
			}catch(Exception e) {
				LOGGER.error("Error : ", e);
			}
		}
		dFile.setLastModified(sFile.lastModified());
	}

	/**
	 * File을 삭제한다.
	 * 
	 * @param filename 삭제할 파일명
	 * @throws ApplicationException
	 */
	public static void delete(String filename) throws ApplicationException {
		if(StringUtils.isEmpty(filename)) {
			throw new ApplicationException("APCME0025", new Object[] {"삭제할 파일명"}, new Object[] {"삭제할 파일명"});
		}
		
		File file = new File(filename);
		if(!file.exists()) {
			return;
		}
		/*
		 * 디렉토리는 삭제하지 않음.
		 */
		if(file.isDirectory()) {
			return;
		}
		try {
			file.delete();
		} catch (Exception e) {
			LOGGER.error("{} 파일삭제오류: {}", new Object[] {filename, e});
			throw new ApplicationException("APCME0032", new Object[] {filename});
		}
	}
	
	/**
	 * 여러 File을 삭제한다.
	 * 
	 * @param filePath 삭제할 파일경로
	 * @throws ApplicationException
	 */
	public static void deleteFiles(String filePath) throws ApplicationException {
		if(StringUtils.isEmpty(filePath)) {
			throw new ApplicationException("APCME0025", new Object[] {"삭제할 디렉토리명"}, new Object[] {"삭제할 디렉토리명"});
		}
		
		File fileDir = new File(filePath);
		
		if(!fileDir.isDirectory()) {
			throw new ApplicationException("APCME0033", new Object[] {fileDir, "디렉토리"}, new Object[] {fileDir + "가 디렉토리인지"});
		}
		
		File[] files = fileDir.listFiles();
		String fileName = "";
		try {
			for(int i=0; i<files.length; i++) {
				fileName = files[i].toString();
				
				if(files[i].isDirectory()) {
					continue;
				}
				else if(files[i].isFile()) {
					files[i].delete();
				}
			
			}
		} catch (Exception e) {
			LOGGER.error("{} 파일삭제오류: {}", new Object[] {fileName, e});
			throw new ApplicationException("APCME0032", new Object[] {fileName});
		}
	}	
	
	/**
	 * File을 이동시킨다.
	 * 
	 * @param srcFile 이동시킬 원본파일
	 * @param destFile 이동될 위치에 대한 Path 또는 이동되면서 저장할 filename
	 * @throws ApplicationException
	 */
	public static void move(String srcFile, String destFile) throws ApplicationException {
		copy(srcFile, destFile);
		delete(srcFile);
	}
	
	/**
	 * 특정 디렉토리에 있는 파일 중 이름이 Matching되는 파일명 목록을 얻는다.
	 *  
	 * @param dir   파일을 찾을 directory
	 * @param prefix 파일명의 prefix
	 * @param sortType 오름차순(FILE_SORT_ASC) 또는 내림차순(FILE_SORT_DESC)를 설정한다.
	 * @param suffix   확장자 또는 파일명의 matching시킬 끝 부분<br>
	 *                 null이면 파일의 끝을 체크하지 않음.
	 * @return
	 */
	public static List<String> files(String dirName, String prefixInput, int sortType, String suffixInput) throws ApplicationException {
		String prefix = prefixInput;
		String suffix = suffixInput;
		
		ArrayList<String> list = new ArrayList<String>();
		
		if(StringUtils.isEmpty(dirName)) {
			throw new ApplicationException("APCME0025", new Object[] {"파일을 찾을 디렉토리"}, new Object[] {"디렉토리"});
		}
		
		if(StringUtils.isEmpty(suffix) && StringUtils.isEmpty(prefix)) {
			throw new ApplicationException("APCME0025", new Object[] {"파일의 suffix 또는 prefix"}, new Object[] {"파일의 suffix 또는 prefix"});
		}
		
		if(StringUtils.isEmpty(suffix)) {
			suffix = "";
		}
		if(StringUtils.isEmpty(prefix)) {
			prefix = "";
		}
		
		File dir = new File(dirName);
		if(!dir.isDirectory()) {
			throw new ApplicationException("APCME0033", new Object[] {dirName, "디렉토리"}, new Object[] {dirName + "가 디렉토리인지"});
		}
		
		File files[] = dir.listFiles();
		for(File f : files) {
			if(!f.isFile()) {
				continue;
			}
			String fname = f.getName();
			if(!fname.startsWith(prefix)) {
				continue;
			}
			if(!fname.endsWith(suffix)) {
				continue;
			}

			addList(list, fname, sortType);
		}
		return list;
	}

	/**
	 * data를 sorting하여 list에 추가한다.
	 * 
	 * @param lst 추가할 위치
	 * @param filename 추가할 파일
	 * @param sortType sorting방법
	 */
	private static void addList(List<String> lst, String filename, int sortType) {
		if(lst.size() == 0) {
			lst.add(filename);
			return;
		}
		if(sortType == FILE_SORT_DESC) {
			for(int idx = 0; idx < lst.size(); idx++) {
				String name = lst.get(idx);
				if(filename.compareTo(name) > 0) {
					lst.add(idx, filename);
					return;
				}
			}
			lst.add(filename);
		} else {
			for(int idx = 0; idx < lst.size(); idx++) {
				String name = lst.get(idx);
				if(filename.compareTo(name) < 0) {
					lst.add(idx, filename);
					return;
				}
			}
			lst.add(filename);
		}
	}
	
	/**
	 * filename1의 내용과 filename2의 내용을 읽어서 mergeFilename에 합친다.
	 * 
	 * @param filename1 merge시 앞쪽에 위치할 파일명
	 * @param filename2 merge시 뒤쪽에 위치할 파일명
	 * @param mergeFilename merge될 파일의 명
	 */
	public static void merge(String filename1, String filename2, String mergeFilename) throws ApplicationException {
		int  size;
		byte data[] = null;
		File file1  = null;
		File file2  = null;
		
		FileOutputStream output = null;
		FileInputStream  input1 = null;
		FileInputStream  input2 = null;

		if(StringUtils.isEmpty(filename1)) {
			throw new ApplicationException("APCME0025", new Object[] {"Merge할 첫번째 파일명"}, new Object[] {"Merge할 첫번째 파일명"});
		}
		if(StringUtils.isEmpty(filename2)) {
			throw new ApplicationException("APCME0025", new Object[] {"Merge할 두번째 파일명"}, new Object[] {"Merge할 두번째 파일명"});
		}
		
		file1 = new File(filename1);
		file2 = new File(filename2);

		if(!file1.exists() || !file1.isFile()) {
			throw new ApplicationException("APCME0029", new Object[] {filename1});
		}
		if(!file2.exists() || !file2.isFile()) {
			throw new ApplicationException("APCME0029", new Object[] {filename2});
		}
		
		try {
			input1 = new FileInputStream(file1);
			data   = new byte[4096];

			output = new FileOutputStream(mergeFilename);
			while((size = input1.read(data)) > 0) {
				output.write(data, 0, size);
			}

			input2 = new FileInputStream(file2);
			while((size = input2.read(data)) > 0) {
				output.write(data, 0, size);
			}
			
			output.close();
			input1.close();
			input2.close();
		} catch (FileNotFoundException e) {
			LOGGER.error("Error : {}", e.getMessage());
		} catch (IOException e) {
			LOGGER.error("Error : {}", e.getMessage());
		} finally {
			try {
				if(output != null) {
					output.close();
				}
			} catch (Exception e) {
				LOGGER.error("Error : {}", e.getMessage());
			}
			try {
				if(input1 != null) {
					input1.close();
				}
			} catch (Exception e) {
			LOGGER.error("Error : {}", e.getMessage());
			}
			try {
				if(input2 != null) {
					input2.close();
				}
			} catch (Exception e) {
				LOGGER.error("Error : {}", e.getMessage());
			}
		}
	}
	
	/**
	 * dest에 src의 내용을 append한다.<br>
	 * dest파일이 존재하지 않으면 src 파일을 copy한다.
	 *  
	 * @param src dest 파일의 뒤에 추가될 파일명
	 * @param dest src 파일을 추가할 파일명
	 * @throws ApplicationException
	 */
	public static void append(String src, String dest) throws ApplicationException {
		byte  data[] = null;
		int	  size;
		File destFile = null;
		File srcFile  = null;
		
		if(StringUtils.isEmpty(src)) {
			throw new ApplicationException("APCME0025", new Object[] {"Append할 파일명"}, new Object[] {"Append할 파일명"});
		}
		if(StringUtils.isEmpty(dest)) {
			throw new ApplicationException("APCME0025", new Object[] {"Append될 파일명"}, new Object[] {"Append될 파일명"});
		}
		
		destFile = new File(dest);
		srcFile  = new File(src);
		
		if(!srcFile.exists() || !srcFile.isFile()) {
			throw new ApplicationException("APCME0029", new Object[] {src});
		}
		if(!destFile.exists() || !destFile.isFile()) {
			copy(src, dest);
			return;
		}

		RandomAccessFile output = null;
		FileInputStream	 input	= null;
		try {
			data = new byte[8192];

			input  = new FileInputStream(srcFile);
			
			output = new RandomAccessFile(destFile, "rw");
			output.seek(output.length());
			
			while((size = input.read(data)) > 0) {
				output.write(data, 0, size);
			}
			
			output.close();
			input.close();
		} catch (IOException e) {
			LOGGER.error("Error : {}", e.getMessage());
		} finally {
			try {
				if(output != null) {
					output.close();
				}
			} catch (Exception e) {
				LOGGER.error("Error : {}", e.getMessage());
			}
			try {
				if(input != null) {
					input.close();
				}
			} catch (Exception e) {
				LOGGER.error("Error : {}", e.getMessage());
			}
		}
		
	}
	
  	/**
  	 * TIFF 파일 포맷을 JPG 파일 포맷으로 변환
  	 * @param input 변환하고자 하는 경로를 포함한 TIFF 파일(절대경로)
  	 * @param output 변환후 결과물이 되는 경로를 포함한 JPG 파일(절대경로)
  	 * @param quality 원본을 압축시 유지하고자 하는 유지율(25%, 50%, 75%, 100%)이고 셋팅하지 않으면 원본을 유지함
  	 * @return 처리결과가 성공이면 true, <code>input</code>, <code>output</code>이 <code>empty</code>이거나 <code>input</code>이 파일시스템상에 존재하지 않거나 혹은 읽을수 없는 상태 또는 변환결과 파일이 존재하지 않으면 false
  	 * @throws FileNotFoundException <code>output</code>을 {@link FileOutputStream} 객체로 생성시 파일을 생성할수 없는 경우
  	 */
  	public static boolean tiffTojpg(final String input, final String output, Integer quality) {
  		if(StringUtils.isEmpty(input) || StringUtils.isEmpty(output))
  			return false;
  		File source = new File(input);
  		if(!source.exists() || !source.canRead())
  			return false;
  		RenderedOp img = JAI.create("FileLoad", input);
  		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(output);
	  		JPEGEncodeParam encParam = new JPEGEncodeParam();
	  		if(quality == null || quality < 0 || quality > 3)
	  			encParam.setQuality(FileUtil.qualityArray[FileUtil.G_100]);
	  		else
	  			encParam.setQuality(FileUtil.qualityArray[quality]);
	  		JAI.create("encode", img, fos, "JPEG", encParam);
	  		
	  		fos.close();
		} catch (FileNotFoundException e) {
			LOGGER.error("Error : {}", e.getMessage());
 		} catch (IOException e) {
 			LOGGER.error("Error : {}", e.getMessage());
		} finally {
			try { 
				if(fos != null) fos.close();
			} catch(IOException e) {
				LOGGER.error("Error : {}", e.getMessage());
			}
		}
		
  		return new File(output).exists();
  	}

}