package cigna.zz;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;

import klaf.batch.BatchApplicationContext;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.common.util.SystemUtils;
import klaf.container.ApplicationContextTrace;
import klaf.container.LApplicationContext;
import klaf.instance.message.MessageResolver;
import klaf.omm.marshaller.IKLafMarshaller;
import klaf.omm.marshaller.factory.KLafMarshallerFactory;
import klaf.omm.marshaller.factory.KLafMarshallerFactory.Marshaller;
import klaf.omm.root.IOmmObject;
import klaf.request.ExtendedCignaSystemHeader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobParameters;

import cigna.sys.util.ISendMail;
import cigna.sys.util.mail.EAIMailSender;

import com.kimids.service.EAIMessage;

/**
 * @file             cigna.zz.FwUtil.java
 * @filetype         java source file
 * @brief            Framework관련 기능 편리성 제공
 * @author           정창수
 * @version          1.6
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               정창수                 2012. 7. 1.       신규 작성
 * 0.6               정창수                 2012. 7.10.       개발 완료
 * 0.9               정창수                 2012. 7.21.       Class 테스트
 * 1.0               정창수                 2012. 7.21.       단위 테스트
 * 1.1               정창수                 2012. 8. 2.       getDeptCd() Method 추가       
 * 1.2               정창수                 2012.10.11.       toCSV()함수 추가
 * 1.3               정창수                 2012.11.05.       toOMM()함수 추가 
 * 1.4               정창수                 2013. 3. 6.       substringKorean() 추가
 * 1.5				  정창수					2013. 6.25. 	  rpadKorean() / lpadKorean() 추가.
 * 1.6				  정창수					2013. 7.19.		  getGlobalId() 추가
 * 14.0              김정국                 2014. 3.14.       writeHeader(String fileName, IOmmObject header, String encoding) 추가 및 기존에 사용하던 메서드의 코드양을 줄임
 * 15.1              김정국                 2015. 1. 20.      융자 파트에서 getBatchDeptCd()를 사용시 '385000' 조직코드로 값이 리턴하도록 수정
 *                                                                당사 직제개편사항으로 인한 수정 => 변경전:기업금융팀(353000) 변경후:개인금융팀(신설-385000)
 * 16.0				   최석			2015.12. 23. 	     헤더를 Cigna 헤더로 변경  
 */

/**
 * 
 * Framework관련 기능 편리성 제공하기 위한 utility class
 *
 */
public class FwUtil {
	final static Logger LOGGER = LoggerFactory.getLogger(FwUtil.class);
	
	/**
	 * 개발서버 - 개발서버에서 실행되는 프로그램에서 getSystemType() return하는 값.
	 */
	public final static int SYSTEM_DEVELOPMENT = 100;

	/**
	 * 테스트 서버 - 테스트 서버에서 실행되는 프로그램에서 getSystemType() return하는 값.
	 */
	public final static int SYSTEM_TEST        = 200;

	/**
	 * 운영 서버 - 운영 서버에서 실행되는 프로그램에서 getSystemType() return하는 값.
	 */
	public final static int SYSTEM_REAL        = 300;
	 
	/**
	 * 등록되지 않은 서버 유형 - 미등록된 서버에서 실행되는 프로그램에서 getSystemType() return하는 값.
	 */
	public final static int SYSTEM_UNKOWN      = -1;

	private final static Hashtable<String, String> DEPT_LIST = new Hashtable<String, String>();
	private final static Hashtable<String, String> USER_LIST = new Hashtable<String, String>();

	static {
		DEPT_LIST.put("CS", "999999"); // 라이나가상
		DEPT_LIST.put("VI", "190011"); // 고객서비스팀
		DEPT_LIST.put("PA", "100977");
//		DEPT_LIST.put("DP", "100980"); // 청구입금 윤연상 2016.07.27 신규등록
		DEPT_LIST.put("DP", "101115"); // 청구입금 최영록 2016.12.19 요청
		DEPT_LIST.put("PR", "100977"); // 고객서비스팀 라이나 부서로 변경함. // 차후 다른 부서들도 
		DEPT_LIST.put("LN", "385000"); // 개인금융팀  // 라이나에 없다고 함. 융자업무 쪽.
		//====================================================================
		USER_LIST.put("CS", "EMPB100977"); // 고객배치
//		USER_LIST.put("DP", "1A13110859");  // 청구입금 윤연상 2016.07.27 수정함
		USER_LIST.put("DP", "6900000110");  // 청구입금 최영록 2017.01.09 요청
		USER_LIST.put("PA", "6900000210"); // 1090905710 -> 100C150307 2016-08-18 윤석을 부장님 요청으로 변경.
		USER_LIST.put("PR", "6900000310");
		USER_LIST.put("LN", "1000999997");
	}

	/**
	 * UI 서비스 호출인지, EAI I/F 호출인지 확인용.
	 * @return true : I/F 호출, false : UI서비스 호출
	 */
	public static boolean isInterfaceHeader() {
		try {
			String headerInfo = FwUtil.getHeaderInfo("interfaceId");
			if(headerInfo==null) {
				return false;
			}
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	/**
	 * 현재 실행되고 있는 시스템의 구분값(개발/테스트/운영)을 얻는다.
	 * 
	 * 현재 실행되고 있는 시스템이 <br>
	 *    개발 서버이면 SYSTEM_DEVELOPMENT<br>
	 * 	  테스트 서버이면 SYSTEM_TEST<br>
	 *    운영 서버이면 SYSTEM_REAL<br>
	 *    미등록된 서버이면 SYSTEM_UNKOWN<br>
	 *    을 얻는다.
	 *    
	 * @return System구분 값.
	 */
	public static int getSystemType()
	{
		String mode = null;
		
		if(BatchApplicationContext.isBatchContext()) {
			mode = BatchApplicationContext.getSystemMode();
		} else {
			mode = LApplicationContext.getSystemMode();
		}
		if(mode == null) {
			return SYSTEM_UNKOWN; 
		} else if("R".equals(mode)) {
			return SYSTEM_REAL;
		} else if("D".equals(mode)) {
			return SYSTEM_DEVELOPMENT;
		} else if("T".equals(mode)) {
			return SYSTEM_TEST;
		} else {
			return SYSTEM_UNKOWN;
		}
	}
	
	/*
	 * Global ID를 얻는다.
	 */
	public static String getGlobalId()
	{
		ExtendedCignaSystemHeader header = FwUtil.getContextHeader();
		/*
		 * Batch 프로그램은 Global ID가 설정되어 있지 않다.
		 */
		if(header.getGlobalUid() == null) {
			header.setGlobalUid(generateGlobaId());
		}
		return header.getGlobalUid();
	}
	
	/**
	 * 새로운 Global ID를 생성한다. SystemHeader에 GlobalId를 새로운 것으로 설정하지는 않는다.
	 */
	public static String generateGlobaId()
	{
		return SystemUtils.generateGUID().replace("-", "");		
	}
	
	/**
	 * Batch용 팀별 실 조직코드
	 * 
	 * @return 배치관할 조직코드
	 */
	private static String getBatchDeptCd() {
		String job = null;
		String deptCd = null;
		String deptCd2 = null;
		
		/* ondemand batch의 경우에는 onlineDeptCd Batch Parameter에서 얻어온다. */
		deptCd = getBatchParameter("onlineDeptCd");
		if(!StringUtils.isEmpty(deptCd)) {
			return deptCd;
		}

		ExtendedCignaSystemHeader header = getContextHeader();
		job = header.getUserId();  // Batch의 UserID는 Job ID이므로

		if(job != null && job.length() >= 3){
			deptCd = job.substring(1, 3);
			deptCd2 = DEPT_LIST.get(deptCd);
			if(deptCd2 == null) {
				deptCd2 = header.getChrgpDeptCd();
				if(deptCd2 == null) {
					deptCd2 = deptCd;
				}
			}
		}
		return deptCd2;		
	}

	/**
	 * user의 조직코드 
	 * Online Service를 실행하는 user의 소속 조직코드 조회 
	 * 2012.08.02일 기능 추가
	 * 
	 * @return 사용자의 소속조직
	 */
	public  static String getDeptCd() {

		/* Batch의 경우 */
		if(BatchApplicationContext.isBatchContext()) {
			String deptCd = getBatchDeptCd();
			if(deptCd != null) {
				return deptCd;
			}
		}

		/* Online의 경우 */
		ExtendedCignaSystemHeader header = getContextHeader();
		String deptCd = null;
		
		if(header != null) {
			deptCd = header.getChrgpDeptCd();
		}

		return deptCd;
	}

	/**
	 * 배치 실행 User ID<br>
	 * Ondemand Batch의 경우 화면에서 호출한 UserId<br>
	 * USER_LIST에 등록된 Team은 등록된 User ID<br>
	 * USER_LIST에 등록되지 않은 팀은 Batch Job ID로 설정됨.
	 * @return 사용자 ID
	 */
	private static String getBatchUserId() {
		String userId = null;
		String jobId  = null;
		String team   = null;
		
		/* ondemand batch의 경우에는 onlineDeptCd Batch Parameter에서 얻어온다. */
		userId = getBatchParameter("onlineUserId");
		if(!StringUtils.isEmpty(userId)) {
			return userId;
		}

		ExtendedCignaSystemHeader header = getContextHeader();
		jobId = header.getUserId();  // Batch의 UserID는 Job ID이므로

		if(jobId != null && jobId.length() >= 3){
			team = jobId.substring(1, 3);
			userId = USER_LIST.get(team);
			if(!StringUtils.isEmpty(userId)) {
				return userId;
			}
		}
		return jobId;
	}
	
	/**
	 * 실행중인 Online 및 Batch의 실행 User Id를 얻는다.
	 * 
	 * 실행중인 Online은 UI를 통해서 실행 요청된 경우 접속 사용자ID<br>
	 * 실행중인 Batch 프로그램은 경우는<br> 
	 *  - ondemand batch의 경우는 화면에서 실행한 User Id를 얻는다.<br>
	 *  - 일반 배치의 경우에는 Job ID를 return한다.<br>
	 *  
	 * @return user id 또는 Job Id
	 */
	public static String getUserId() 	{
		String userId = null;
		
		if(BatchApplicationContext.isBatchContext()) {			
			userId = getBatchUserId();
			if(!StringUtils.isEmpty(userId)) {
				return userId;
			}
		}

		ExtendedCignaSystemHeader header = getContextHeader();
		if(header == null) {
			return null;
		} else {
			return header.getUserId();
		}
	}

	/**
	 * Online 또는 Batch에서 실행시에 DB의 AUDIT COLUMN인 LAST_CHG_PGM_ID의 값을 return한다.
	 * 
	 * @return Program ID
	 */
	public static String getPgmId() {
		return getPgmId(null);
	}
	
	/**
	 * Online 또는 Batch에서 실행시에 DB의 AUDIT COLUMN인 LAST_CHG_PGM_ID의 값을 return한다.
	 * 
	 * @param obj 현재 실행중인 객체 this를 설정. 
	 * @return Program ID
	 */
	public static String getPgmId(Object obj) {
		String programId;
		if(obj != null) {
			int idx = 0;
			programId = obj.getClass().getName();
			if((idx = programId.lastIndexOf('.')) > 0) {
				programId = programId.substring(idx + 1);
			}
			if(programId.length() > 15) {
				programId = programId.substring(0, 15);
			}
			return programId;
		}
		ExtendedCignaSystemHeader header = getContextHeader();
		if(header == null) {
			return null;
		} else {
			return header.getService();
		}
	}
	
	/**
	 * Online 또는 Batch에서 실행시에 DB의 AUDIT COLUMN인 LAST_CHG_TRM_NO의 값을 return한다.
	 * 
	 * @return Terminal No
	 */
	public static String getTrmNo() {
		String ipAddr = null;
		ExtendedCignaSystemHeader header = getContextHeader();
		if(header == null) {
			return null;
		} else {
			ipAddr = header.getRemoteAddr();
			if(ipAddr != null && ipAddr.length() > 0) {
				return ipAddr;
			}
			if(BatchApplicationContext.isBatchContext()) {
				return "BATCH";
			}
			// Interface등에서 IP Address가 설정되지 않은 경우 Interface ID
			return header.getInterfaceId();
		}
	}
	
	/**
	 * Header에 지정된 시스템명을 리턴한다.
	 * 
	 * @return Media Type
	 */
	public static String getHeaderMedTyp() {
		ExtendedCignaSystemHeader header = getContextHeader();
		if(header == null) {
			return null;
		} else {
			return header.getMedTyp();
		}
	}
	
	/**
	 * Ondemand Batch에서 수행시 발생하는 로그 파일명을 얻는다.
	 * 
	 * @return 로그 파일명.
	 */
	public static String getBatchLoggingFileName() {
		String fileName= BatchApplicationContext.getOndemandLoggingFileName();
		  
		if( fileName==null) {
			fileName= System.getProperty( "logfile");
		}
		
		return fileName;
	 }
	/**
	 * 현재실행되는 환경이 ondemand batch 또는 일반 배치이면 true 그렇지 않으면 false를 얻는다.
	 * @return
	 */
	public static boolean isBatch() {
		if(BatchApplicationContext.isBatchContext()) {
			return true;
		} else {
			return false;
		}
	}
	
//	/**
//	 * 배치 수행시 AP1, AP2에서 돌리는지 확인을 할 필요가 있기에 AP1을 확인하는 함수 입니다.
//	 * isAP1(), isAP2() 함수를 이용하여 총 3대의 AP를 확인할 수 있습니다.
//	 * BATAP는  isAP1()==isAP2() 일 경우이며 AP3, AP4 ... 의 경우도 이와 같습니다.
//	 * 라이나는 AP1, AP2 만 존재함을 기준으로 합니다.
//	 * @return 
//	 */
//	public static boolean isAP1() {
//		String hostName = "";
//		try {
//			hostName = InetAddress.getLocalHost().getHostName();
//		} catch (UnknownHostException e1) {
//			// TODO Auto-generated catch block
//			return false;
//		}
//		if(hostName.contains("BATAP")) {
//			return false;
//		} else if (hostName.contains("AP1")) {
//			return true;
//		} else {
//			return false;
//		}
//	}

//	/**
//	 * 배치 수행시 AP1, AP2에서 돌리는지 확인을 할 필요가 있기에 AP2을 확인하는 함수 입니다.
//	 * isAP1(), isAP2() 함수를 이용하여 총 3대의 AP를 확인할 수 있습니다.
//	 * BATAP는  isAP1()==isAP2() 일 경우이며 AP3, AP4 ... 의 경우도 이와 같습니다.
//	 * 라이나는 AP1, AP2 만 존재함을 기준으로 합니다.
//	 * @return 
//	 */
//	public static boolean isAP2() {
//		String hostName = "";
//		try {
//			hostName = InetAddress.getLocalHost().getHostName();
//		} catch (UnknownHostException e1) {
//			// TODO Auto-generated catch block
//			return false;
//		}
//		if(hostName.contains("BATAP")) {
//			return false;
//		} else if (hostName.contains("AP2")) {
//			return true;
//		} else {
//			return false;
//		}
//	}
	/**
	 * 서비스를 호출한 화면ID를 얻는다.
	 * 
	 * @return 화면ID
	 */
	public static String getScreenId() 	{
		String screenId = null;
		ExtendedCignaSystemHeader header = getContextHeader();
		
		if(header == null) {
			return null;
		}

		screenId = header.getScrnNo();
		if(screenId != null && screenId.length() > 0) {
			return screenId;
		}
		if(BatchApplicationContext.isBatchContext()) {
			return getBatchParameter("screenId");
		}
		
		return null;
	}
	/**
	 * ExtendedCignaSystemHeader의 Key 값을 가져온다.
	 * chrqpDeptCd, chrqpMpNo, curLocale, dataContainer 값은 아직 가져오지 못한다.
	 * @param key : ExtendedCignaSystemHeader의 Key 값.
	 * @return : Key의 Value... String.
	 */
	public static String getHeaderInfo(String key) {
		try {
			String rtValue = null;
			ExtendedCignaSystemHeader header = getContextHeader();
			
			if(header == null) {
				return null;
			}
	
			rtValue = header.get(key).toString();
			if(rtValue != null && rtValue.length() > 0) {
				return rtValue;
			}
			if(BatchApplicationContext.isBatchContext()) {
				return getBatchParameter(key);
			}
			return null;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @deprecated
	 * Framework에서 사용중인 ContextHeader 정보를 얻는다.
	 * 
	 * @return ContextHeader
	 */
	public static ExtendedCignaSystemHeader getContextHeader() {
		return (ExtendedCignaSystemHeader)LApplicationContext.getCurrentApplicationHeader();
	}
	
	/**
	 * Batch 프로그램 실행시 Parameter로 넘어온 값을 얻는다.
	 * Batch를 실행할 때에 runJob.sh의 parameter로 넘겨진 값을 얻는다.
	 * 
	 * <pre>
	 * ex)
	 * runJob.sh ZZ BZZA000B inputFile=BZZ0000000000.dat outputFile=BZZ0000000001.dat
	 * 로 실행하였을 때 inputFile, outputFile과 같이 key=value 형식으로 넘겨진 parameter값을 얻는다.
	 * 
	 * String inputFile  = FwUtil.getBatchParameter("inputFile");
	 * String outputFile = FwUtil.getBatchParameter("outputFile");
	 * </pre>
	 * 
	 * @param paramName  얻으려는 parameter의 name
	 * @return parameter의 값
	 */
	public static String getBatchParameter(String paramName) 	{
		JobParameters jobParams = BatchApplicationContext.getJobParameters();
		if(jobParams==null) return null;
		return jobParams.getString(paramName);
	}
	
	/**
	 * 예외관련 정보를 문자열로 변환함
	 * 
	 * @param e  예외 정보
	 * @param trace line trace 정보
	 * @return line trace정보와 예외 message 정보
	 */
	private static String getTraceInfo(Throwable e, StackTraceElement trace) {
		StringBuffer buf = new StringBuffer(256);
        buf.append(trace.toString());
        buf.append(":");
        buf.append(e.getMessage());
        
        return buf.toString();
	}

	/**
	 * 예외가 발생한 위치 정보와 Message 정보를 return한다.
	 * 
	 * Exception이 발생한 곳의 위치중에서 KDB생명보험 프로젝트의 개발팀에서 개발한 Source의 범위에서 
	 * 오류발생의 원천의 정보와 예외 message정보를 얻는다. 
	 * 
	 * @param exception 예외
	 * @return
	 */
	public static String getTraceInfo(Throwable exception) {
	    StackTraceElement[] trace = exception.getStackTrace();
	    
        for(int idx = 0; idx < trace.length; idx++) {
        	if(!trace[idx].getClassName().startsWith("cigna.")) {
        		continue;
        	}
        	return getTraceInfo(exception, trace[idx]);
        }
		return getTraceInfo(exception, trace[trace.length - 1]);
	}
	
	/**
	 * 기본 Message를 생성하는 API
	 *  
	 * 사용법은 LApplicationContext.addMessage();와 같은 방법으로 사용한다.
	 * 
	 * @param messageId
	 * @param basic_message
	 * @param add_message
	 * @return 조합된 기본 메시지 
	 */
	public static String getBasicMessage(String messageId, Object[] basic_message, Object[] add_message) {
		return MessageResolver.resolveMessage(messageId, basic_message, add_message).getBasicMessage();
	}

	/**
	 * 부가 Message를 생성하는 API
	 * 
	 * 사용법은 LApplicationContext.addMessage();와 같은 방법으로 사용한다.
	 * 
	 * @param messageId
	 * @param basic_message
	 * @param add_message
	 * @return 조합된 부가 메시지
	 */
	public static String getAddedMessage(String messageId, Object[] basic_message, Object[] add_message) {
		return MessageResolver.resolveMessage(messageId, basic_message, add_message).getDetailMessage();
	}

	/**
	 * OMM을 CSV(Comma Separated Value) 형태로 변환함.
	 * @param omm 변환할 OMM 객체
	 * @return CSV형태의 문자열
	 */
	public static String toCSV(IOmmObject omm) {
		if(omm == null) {
			LOGGER.error("omm is null.");
			return null;
		}
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
				
		try {
			IKLafMarshaller marshaller = null;
			if( ( marshaller = ApplicationContextTrace.getCurrentApplication().getMarshaller( Marshaller.OMM_DELIMITER))== null) {
				marshaller = KLafMarshallerFactory.newInstance().getMarshaller( Marshaller.OMM_DELIMITER);
				ApplicationContextTrace.getCurrentApplication().setMarshaller( Marshaller.OMM_DELIMITER, marshaller);
			}
		
			marshaller.marshal(omm, bout);

			return new String(bout.toByteArray());
		} catch (Exception e) {
			LOGGER.error("error: {}", e);
			return null;
		} finally {
			try {
				bout.close();
			} catch (Exception e) {
				LOGGER.error("error: {}", e);
			}
		}
		
	}
	
	/**
	 * OMM을 FLD(Fixed Length Data) Bytes Array형태로 변환함.
	 * @param omm 변환할 OMM 객체
	 * @return bytes array
	 */
	public static byte[] toBytes(IOmmObject omm) {
		return toBytes(omm, null);
	}
	
	/**
	 * OMM을 FLD(Fixed Length Data) Bytes Array형태로 변환함.
	 * @param omm 변환할 OMM 객체, Encoding
	 * @return bytes array
	 */
	public static byte[] toBytes(IOmmObject omm, String encoding) {
		if(omm == null) {
			LOGGER.error("omm is null.");
			return null;
		}
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
				
		try {
			IKLafMarshaller marshaller = null;
			if( ( marshaller = ApplicationContextTrace.getCurrentApplication().getMarshaller( Marshaller.OMM_FLD))== null) {
				marshaller = KLafMarshallerFactory.newInstance().getMarshaller( Marshaller.OMM_FLD);
				ApplicationContextTrace.getCurrentApplication().setMarshaller( Marshaller.OMM_FLD, marshaller);
			}
		
			if( encoding == null) marshaller.marshal(omm, bout);
			else marshaller.marshal(omm, bout, encoding);
			
			return bout.toByteArray();
		} catch (Exception e) {
			LOGGER.error("error: {}", e);
			return null;
		} finally {
			try {
				bout.close();
			} catch (Exception e) {
				LOGGER.error("error: {}", e);
			}
		}
	}
	
	/**
	 * Data 파일의 Header부의 정보를 변경한다.
	 * 
	 * Header가 있는 파일에 Header부에 파일내용의 Summary 정보가 들어가는 경우 
	 * 미리 Header부의 공간을 만들어두고 파일 생성이 끝난 후에 Header부를 overwrite한다.  
	 * @param fileName 작업할 파일명
	 * @param header Write할 header정보
	 * @throws IOException
	 */
	public static void writeHeader(String fileName, IOmmObject header) throws IOException {
		writeHeader(fileName, header, null);
	}
	
	/**
	 * Data 파일의 Header부의 정보를 변경한다.
	 * 
	 * Header가 있는 파일에 Header부에 파일내용의 Summary 정보가 들어가는 경우 
	 * 미리 Header부의 공간을 만들어두고 파일 생성이 끝난 후에 Header부를 overwrite한다.
	 * @param fileName 작업할 파일명
	 * @param header Write할 header정보
	 * @param encoding header를 바이트 배열로 전환시 사용할 인코딩
	 * @throws IOException
	 */
	public static void writeHeader(String fileName, IOmmObject header, String encoding) throws IOException {
		byte[] bytes = toBytes(header, encoding);
		if(bytes == null) {
			return;
		}

		RandomAccessFile out = null;
		try {
			out = new RandomAccessFile(fileName, "rw");
			out.seek(0);
			out.write(bytes);
		} finally {
			if(out != null) {
				out.close();
			}
		}
	}
	
	/**
	 * CSV 내용을 OMM 객체로 변환한다.
	 * 
	 * <pre>
	 * String data;
	 * ...
	 * MyOMM omm = FwUtil.toOMM(MyOMM.class, data);
	 * ...
	 * </pre>
	 * 
	 * @param type OMM type의 Class class
	 * @param csvData CSV형태의 데이터
	 * @return OMM객체
	 */
	public static <T extends IOmmObject> T toOMM(Class<T> type, String csvData) {
		byte[] data;
		
		try {
			if(csvData == null) {
				return null;
			}
			data = csvData.getBytes();
			IKLafMarshaller marshaller = null;
			if( ( marshaller = ApplicationContextTrace.getCurrentApplication().getMarshaller( Marshaller.OMM_DELIMITER)) == null) {
				marshaller = KLafMarshallerFactory.newInstance().getMarshaller( Marshaller.OMM_DELIMITER);
				ApplicationContextTrace.getCurrentApplication().setMarshaller( Marshaller.OMM_DELIMITER, marshaller);
			}
			T px = marshaller.unmarshal(type, data);
			return px;
		}catch (Exception e) {
			LOGGER.error("error: {}", e);
			return null;
		}
	}
	
	/**
	 * FLD(Fixed Length Data) 데이터를 OMM형태로 변환함.
	 * 
	 * <pre>
	 * String data;
	 * ...
	 * MyOMM omm = FwUtil.toOMMFld(MyOMM.class, data);
	 * ...
	 * </pre>
	 * @param type OMM type의 Class class
	 * @param inputData FLD형태의 데이터
	 * @return OMM객체
	 */
	public static <T extends IOmmObject> T toOMMFld(Class<T> type, String inputData) {
		return toOMMFld(type, inputData, null);
	}
	
	/**
	 * FLD(Fixed Length Data) 데이터를 OMM형태로 변환함.
	 * 
	 * <pre>
	 * String data;
	 * ...
	 * MyOMM omm = FwUtil.toOMMFld(MyOMM.class, data, encoding);
	 * ...
	 * </pre>
	 * @param type OMM type의 Class class
	 * @param inputData FLD형태의 데이터
	 * @param encoding CharsetName
	 * @return OMM객체
	 */
	public static <T extends IOmmObject> T toOMMFld(Class<T> type, String inputData, String encoding) {
		byte[] data;
		
		try {
			if(inputData == null) {
				return null;
			}
			
			if( encoding == null) data = inputData.getBytes();
			else data = inputData.getBytes(encoding);
			
			IKLafMarshaller marshaller = null;
			if( ( marshaller = ApplicationContextTrace.getCurrentApplication().getMarshaller( Marshaller.OMM_FLD)) == null) {
				marshaller = KLafMarshallerFactory.newInstance().getMarshaller( Marshaller.OMM_FLD);
				ApplicationContextTrace.getCurrentApplication().setMarshaller( Marshaller.OMM_FLD, marshaller);
			}
			
			if( encoding == null) return marshaller.unmarshal(type, data);
			else return marshaller.unmarshal(type, data, encoding);
		}catch (Exception e) {
			LOGGER.error("error: {}", e);
			return null;
		}
	}
	
	/**
	 * 한글이 포함된 문자열에 대해서 substring을 실행한다. 
	 * 문자를 substring할 때에 한글이 중간에 잘리는 것을 막아준다.
	 * 
	 * @param inString 검사할 문자열
	 * @param length 리턴할 문자열 길이
	 * @param encoding UTF-8, EUC-KR
	 * @return <code>inString</code>으로 전달된 문자를 인코딩에 따라 <code>length</code>만큼 잘라서 리턴
	 */
	public static String substringKorean(String inString, int length, String encoding) // by Shin Changyoung 2013.03.06
	{ 
		if(StringUtils.isEmpty(inString)) {
			return inString;
		}
		
		String charset = encoding.toUpperCase( Locale.ENGLISH );
		String outString = null;
		
		try {
			byte[] rawBytes = inString.getBytes(charset);
			int rawLength 	= rawBytes.length;

			int index = 0;
			int minus_byte_num = 0;
			int offset = 0;

			int hangul_byte_num = "UTF-8".equals(charset) ? 3 : 2;

			if(rawLength > length){
				minus_byte_num = 0;
				offset = length;
				if(index + offset > rawBytes.length){
					offset = rawBytes.length - index;
				}
				for(int j=0; j<offset; j++){      
					if(((int)rawBytes[index + j] & 0x80) != 0){
						minus_byte_num ++;
					}
				}     
				if(minus_byte_num % hangul_byte_num != 0){
					offset -= minus_byte_num % hangul_byte_num;
				}
				outString = new String(rawBytes, index, offset, charset);
			} else {
				outString = inString;
			}    
		} catch(Exception e) {
			LOGGER.error("error: {}", e);
		}
		return outString;
	}

	/**
	 * 한글이 포함된 문자열에 대해서 space를 RAPD후 데이터를 return한다. 
	 * 
	 * @param inString rpad할 문자열
	 * @param length SPACE로 채운 후의 문자열 길이
	 * @param encoding UTF-8, EUC-KR
	 * @return <code>inString</code>으로 전달된 문자를 인코딩에 따라 <code>length</code>만큼 잘라서 리턴
	 */
	public static String rpadKorean(String inStringInput, int length, String encoding)
	{ 
		String inString = inStringInput;
		
		if( inString == null) inString= "";
		
		StringBuffer buf = null;
		String charset = encoding.toUpperCase();
		
		try {
			byte[] rawBytes = inString.getBytes(charset);
			int rawLength 	= rawBytes.length;

			if(rawLength >= length) {
				return inString;
			}
			buf = new StringBuffer(256);
			buf.append(inString);
			for(int idx = rawLength; idx < length; idx++) {
				buf.append(' ');
			}
			return buf.toString();
		} catch(Exception e) {
			LOGGER.error("error: {}", e);
		}
		return inString;
	}


	/**
	 * 한글이 포함된 문자열에 대해서 space를 RAPD후 데이터를 return한다. 
	 * 
	 * @param inString rpad할 문자열
	 * @param length SPACE로 채운 후의 문자열 길이
	 * @param encoding UTF-8, EUC-KR
	 * @return <code>inString</code>으로 전달된 문자를 인코딩에 따라 <code>length</code>만큼 잘라서 리턴
	 */
	public static String lpadKorean(String inString, int length, String encoding)
	{ 
		if(StringUtils.isEmpty(inString)) {
			return inString;
		}
		StringBuffer buf = null;
		String charset = encoding.toUpperCase();
		
		try {
			byte[] rawBytes = inString.getBytes(charset);
			int rawLength 	= rawBytes.length;

			if(rawLength >= length) {
				return inString;
			}
			buf = new StringBuffer(256);
			for(int idx = rawLength; idx < length; idx++) {
				buf.append(' ');
			}
			buf.append(inString);
			return buf.toString();
		} catch(Exception e) {
			LOGGER.error("error: {}", e);
		}
		return inString;
	}
	
	/**
	 * Local Cache에서 저장된 data를 읽어온다.
	 * 
	 * @param dataName Cache 이름
	 * @return dataName 이름으로 저장된 Cache 데이터
	 */
	public static Object getCacheData(String dataName) {
		if(LApplicationContext.isOnlineContext()) {
			return LApplicationContext.getDataContainer().get(dataName);
		} else {
			return LApplicationContext.getDataContainer().get(dataName + "#" + Thread.currentThread().getId());
		}
	}
	
	public static Object getCacheDataGlobal(String dataName) {
		return LApplicationContext.getDataContainer().get(dataName);
	}
	
	/**
	 * Local Cache에 데이터를 저장한다.
	 * 
	 * @param dataName 저장하려는 데이터 이름
	 * @param data 저장하려는 데이터
	 */
	public static void putCacheData(String dataName, Object data) {
		if(LApplicationContext.isOnlineContext()) {
			LApplicationContext.getDataContainer().put(dataName, data);
		} else {
			LApplicationContext.getDataContainer().put(dataName + "#" + Thread.currentThread().getId(), data);
		}
	}
	
	public static void putCacheDataGlobal(String dataName, Object data) {
		if( getCacheDataGlobal(dataName) != null ){
			removeCacheDataGlobal(dataName);
		}
		LApplicationContext.getDataContainer().put(dataName, data);
	}
	
	/**
	 * Local Cache에 저장된 데이터 삭제한다.
	 * 
	 * @param dataName 삭제하려는 Cache이름.
	 */
	public static void removeCacheData(String dataName) {
		if(LApplicationContext.isOnlineContext()) {
			LApplicationContext.getDataContainer().remove(dataName);
		} else {
			LApplicationContext.getDataContainer().remove(dataName + "#" + Thread.currentThread().getId());
		}
	}
	
	public static void removeCacheDataGlobal(String dataName) {
		LApplicationContext.getDataContainer().remove(dataName);
	}
	
	/**
	 * SMTP Mail send with EAI I/F
	 * @param from
	 * @param to
	 * @param cc
	 * @param subject
	 * @param bodyHtmlText
	 * @return
	 */
	public static String sendMailSmtp(String from, String to, String cc, String subject, String bodyHtmlText) {
		ISendMail smtpMail = new EAIMailSender();
		ExtendedCignaSystemHeader headerInfo = (ExtendedCignaSystemHeader)LApplicationContext.getCurrentApplicationHeader();
		
		bodyHtmlText = removeXssStr(bodyHtmlText, "<script", ".$cript");
		bodyHtmlText = removeXssStr(bodyHtmlText, "<object", ".0bject");
		EAIMessage msg = (EAIMessage)smtpMail.send(headerInfo, from, to, subject, bodyHtmlText, cc, null);
		
		return msg.getCode();
	}
	
	/**
	 * Remove XSS String
	 * @param strArg
	 * @return
	 */
	private static String removeXssStr(String strArg, String targetStr, String replaceStr) {
		String removedStr = strArg.toLowerCase();
		StringBuilder sb = new StringBuilder(strArg);
		
		int rIdx = -1;
		do {
			rIdx = removedStr.indexOf(targetStr.toLowerCase(), rIdx+1);
			if(rIdx>=0) {
				sb.replace(rIdx, rIdx+targetStr.length(), replaceStr);
			}
		}while(rIdx>=0);
		return sb.toString();
	}
	
	/**
	 * Get Extension Header Info 
	 * @param key
	 * @return
	 */
	private static Object getSysHeaderExtensionInfo(String key) {
		ExtendedCignaSystemHeader sysHeaderInfo = (ExtendedCignaSystemHeader)LApplicationContext.getCurrentApplicationHeader();
		if(sysHeaderInfo==null) return null;
		Map<String, Object> extProp = sysHeaderInfo.getExtensionProp();
		if(extProp==null) return null;
		return extProp.get(key);
	}
	
	/**
	 * Original Media Type
	 * @return
	 */
	public static String getMedTyp() {
		String orgMedTyp = (String)getSysHeaderExtensionInfo("orgMedTyp");
		if(orgMedTyp==null) orgMedTyp = getHeaderMedTyp();
		return orgMedTyp;
	}
	
	/**
	 * Interface Call 여부
	 * @return
	 */
	public static boolean isInterface() {
		boolean isIf = false;
		String orgInterfaceId = (String)getSysHeaderExtensionInfo("orgInterfaceId");
		if(orgInterfaceId!=null) {
			String interfaceId = orgInterfaceId.trim();
			if(interfaceId.length()>0) isIf = true;
		}else {
			isIf = isInterfaceHeader();
		}
		return isIf;
	}
	
	private static Map<String, Object> getHeaderExtensionProperiesMap() {
		ExtendedCignaSystemHeader sysHeaderInfo = (ExtendedCignaSystemHeader)LApplicationContext.getCurrentApplicationHeader();
		if(sysHeaderInfo==null) return null;
		Map<String, Object> extProp = sysHeaderInfo.getExtensionProp();
		
		return extProp;
	}
	
	/**
	 * 녹취 Key (gvRecordID)를 Header Ext정보에 저장. 성공시 입력된 key return
	 * @param gvRecordID
	 * @return
	 */
	public static String setGvRecordId(String gvRecordID) {
		Map<String, Object> extProp = getHeaderExtensionProperiesMap();
		if(extProp==null) return null;
		
		extProp.put("gvRecordID", gvRecordID);
		return gvRecordID;
	}
	
	/**
	 * Header에 저장된 녹취 Key (gvRecordID) 를 리턴
	 * @return
	 */
	public static String getGvRecordId() {
		Map<String, Object> extProp = getHeaderExtensionProperiesMap();
		if(extProp==null) return null;
		
		String gvRecordID = (String)extProp.get("gvRecordID");
		return gvRecordID;
	}
	
    /**
     * 현재날짜 Date Object 반환
     * @return
     */
    public static Date getSystemDate() {
    	String currDateStr = DateUtils.getCurrentDate( DateUtils.EMPTY_DATE_TYPE );
    	Calendar cal = Calendar.getInstance();
    	cal.set(Calendar.YEAR, Integer.parseInt(currDateStr.substring(0, 4)) );
    	cal.set(Calendar.MONTH, Integer.parseInt(currDateStr.substring(4, 6))-1 );
    	cal.set(Calendar.DAY_OF_MONTH , Integer.parseInt(currDateStr.substring(6, 8)) );
    	Date curStObj = new Date(cal.getTime().getTime());
    	return curStObj;
    }
    
    public static String getBizStacktrace(Throwable th) {
    	StringBuilder trace = new StringBuilder();
    	try{
    		StackTraceElement[] traceElements = th.getStackTrace();
    		if(traceElements==null) {
    			return "StackTraceElement is null";
    		}
    		String clazzName= "";
    		String fileName = "";
    		String methodName = "";
    		String lineNum = "";
    		// cigna.xxx package 만 return 한다
    		for(StackTraceElement element:traceElements) {
    			
    			clazzName = element.getClassName();
    			fileName = element.getFileName();
    			methodName = element.getMethodName();
    			
    			if(element.getLineNumber()>0) {
    				lineNum = Integer.toString(element.getLineNumber());
    			}else {
    				lineNum = "unknown";
    			}
    			
    			LOGGER.debug(clazzName+"."+methodName+"("+fileName+") "+lineNum );
    			
    			if(clazzName!=null && clazzName.startsWith("cigna.")) {
    				trace.append("<< "+clazzName+"."+methodName+"("+lineNum+")" );
    			}
    		}
    		
    	}catch(Exception ex) {
    		trace.append("Could not getStacktrace Cause:").append(ex.toString());
    	}
    	return trace.toString();
    }
}
