package cigna.zz;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import klaf.app.ApplicationException;
import klaf.batch.BatchApplicationContext;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.common.util.concurrent.ResourceTimedOutException;
import klaf.container.LApplicationContext;
import klaf.container.OnDemandCommandOption;
import klaf.container.OnDemandStatus;
import klaf.container.RemoteContainerServiceExecutor;
import klaf.inf.EISExecutor;
import klaf.inf.EISExecutorFactory;
import klaf.inf.EISRequest;
import klaf.inf.EISResponse;
import klaf.inf.EisExecutionException;
import klaf.inf.ExternalInteraction.EIS_TYPES;
import klaf.inf.NotSupportedEISException;
import klaf.inf.innorule.item.InnoRuleOmm;
import klaf.omm.annotation.KlafOmm_Field;
import klaf.omm.root.IOmmObject;
import klaf.request.ExtendedCignaSystemHeader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cigna.cm.a.bean.CMA007BEAN;
import cigna.cm.a.bean.CMA009BEAN;
import cigna.cm.a.io.TBCMCCD029Io;
import cigna.cm.a.io.TBCMCCD030Io;

import com.kimids.service.EAIMessage;
import com.kimids.service.EaiFile;
import com.kimids.service.FEP;
import com.kimids.service.FEPMessage;


/**
 * @file             cigna.zz.InfUtil.java
 * @filetype         java source file
 * @brief            Interface(Rule/EAI/FEP 등)와 관련된 기능제공 
 * @author           정창수
 * @version          1.4
 * @history
 * Version           성명                   일자              변경내용
 * -----------       ----------------       -----------       ----------------- 
 * 0.1               정창수                 2012. 7. 1.       신규 작성
 * 0.6               정창수                 2012. 7.10.       개발 완료
 * 0.9               정창수                 2012. 7.21.       Class 테스트
 * 1.0               정창수                 2012. 7.21.       단위 테스트
 * 1.1               정창수                 2012. 9. 4.       EAI 및 통합 file 전송 method 추가-transFile()
 * 1.2               정창수                 2012.10. 8.       startBatch() 추가 : ondemand batch 실행 method. 
 * 1.3               정창수                 2012.11. 6.       FEP(AnyLink)호출 method 추가 - callFEP()
 * 1.4               정창수                 2012.11.19.       EAI, FEP관련 method에 대해 Return에 System Header 포함하도록 변경
 */

/**
 * 
 * Interface(Rule/EAI/FEP 등)와 관련된 기능제공하기 위한 utility class
 * 
 */
public class InfUtil { 
	
	/**
	 * Log 생성 객체.
	 */
	private final static Logger logger = LoggerFactory.getLogger(InfUtil.class);

	public final static String PUSH_TYPE_MSG 				= "MSG";
	public final static String PUSH_TYPE_FILE				= "FIL";


	/** 
	 * transFile() method에서 EAI Sync로 전송	 
	 */
	public final static int TRANS_FILE_EAI_SYNC     	=	11;
	
	/** 
	 * transFile() method에서 EAI Async로 전송	 
	 */
	public final static int TRANS_FILE_EAI_ASYNC		= 	12;
	
	/** 
	 * transFile() method에서 FEP Sync로 전송	 
	 */
	public final static int TRANS_FILE_FEP_SYNC    		=	21;

	/**
	 * transFile() method에서 FEP Sync로 전송	 
	 * @deprecated TRANS_FILE_FEP_SYNC 변경
	 */
	public final static int TRANS_FILE_ANYLINK_SYNC    	=	TRANS_FILE_FEP_SYNC;
	
	/** 
	 * transFile() method에서 FEP Async로 전송	 
	 */
	public final static int TRANS_FILE_FEP_ASYNC    	=	22;
	

	/** 
	 * transFile() method에서 FEP Async로 파이릉 수신받는다.	 
	 */
	public final static int RECEIVE_FILE_FEP_ASYNC    	=	25;
	
	/**
	 * transFile() method에서 FEP Async로 전송	 
	 * @deprecated TRANS_FILE_FEP_ASYNC 변경
	 */
	public final static int TRANS_FILE_ANYLINK_ASYNC	= 	TRANS_FILE_FEP_ASYNC;

	
	/** 
	 * EAI를 통해서 FEP 파일 전송 서버까지 파일을 전송을 위한 INTERFACE ID 
	 */
	private final static String FEP_FILE_TRANS_IF_ID     = "COM_E_FEPBA000000001";

	/**
	 * FEP INTERFACE용 TX CODE 및 MAPPER정보를 관리하는 Properties.
	 * 환경변수 fep.file에 fep.properties file의 위치가 저장되어 있음.
	 */
	private static Properties fepProperties = null;

	/**
	 * FEP interface 정보를 저장하는 파일명 변수.
	 */
	private final static String FEP_PROPERTIES_FILE_KEY = "fep.interfaceFile";
	
	/* 파일 전송 */
	private final static String FEP_FILE_TRANS_TYPE   = "S";
	
	/* 파일 수신 */
	private final static String FEP_FILE_RECEIVE_TYPE = "R";
	
	/* ANSYNC FEP 서비스의 경우 GUID를 ContainerData에 설정하여 넘긴다. */
	private final static String GUID_CACHE_NAME = "FW/GUID";
	
	/* 임시 Rule 성능 측정을 위한 변수이며 테스트 후 삭제 예정 2013.04.22 */
	private static long batchRuleTime = 0;
	private static long batchRuleCallCount = 0;
	private static CMA007BEAN cma007bean = null;
	private static CMA009BEAN cma009bean = null;
	
	///////////////////////////////////////////////////////////////// RULE 관련 API //////////////////////////////////////////////////////////////////
	/**
	 * InnoRule을 호출하여 Rule정보를 얻는다.
	 * 
	 * @param ruleId   		조회할 Rule ID
	 * @param applyDate  	신청일자
	 * @param request		Rule 요청 정보
	 * @return	요철 결과 정보
	 * 
	 * @throws EisExecutionException  
	 * @throws NotSupportedEISException
	 */
	public static InnoRuleOmm callRule(String ruleId, String applyDate, InnoRuleOmm request) throws EisExecutionException, NotSupportedEISException {
		String applDate = applyDate;
		long   milliseconds = 0;  // rule성능 측정용
		
		if(DateUtils.isValidDate(applDate, DateUtils.EMPTY_DATE_TYPE)) {
			applDate = DateUtils.getDate(applyDate, DateUtils.DASH_DATE_TYPE);			
		}
		try {
			if(logger.isDebugEnabled()) {
				Throwable throwInfo = new Throwable();
				logger.debug( getCallerInfo(throwInfo) );
			}
			/* Rule 성능 측정용 ====================== */
			if(BatchApplicationContext.isBatchContext()) {
				milliseconds = System.currentTimeMillis();
				batchRuleCallCount++;
			}
			EISExecutor executor = EISExecutorFactory.getEisExecutor( EIS_TYPES.EIS_BRMS);
			
			return  executor.execute( request, InnoRuleOmm.class, new String[] { ruleId, applDate});
		} finally {
			/* Rule 성능 측정용 ====================== */
			if(BatchApplicationContext.isBatchContext()) {
				batchRuleTime += System.currentTimeMillis() - milliseconds;
			}
		}
	}
	
	/**
	 * Method호출 정보 logging 처리 (성능 튜닝 디버그 용)
	 * @param throwInfo
	 * @return
	 */
	private static String getCallerInfo(Throwable throwInfo) {
		String infoStr = "";
		StackTraceElement[] stackElements = throwInfo.getStackTrace();
		if(stackElements!=null && stackElements.length>1) {
			String calledMethod = stackElements[0].getMethodName();
			String calledClazz  = stackElements[0].getClassName();
			String callerClazz = stackElements[1].getClassName();
			String callerMethod = stackElements[1].getMethodName();
			int lineNumber = stackElements[1].getLineNumber();
			infoStr=calledClazz+"."+calledMethod+" called at "+callerClazz+"."+callerMethod+" line "+lineNumber;
		}
		return infoStr;
	}
	
	/* Rule 성능테스트용 API - BEGIN */
	public static long getCallRuleTime()
	{
		return batchRuleTime;
	}
	
	public static long getRuleCallCount()
	{
		return batchRuleCallCount;
	}
	/* Rule 성능테스트용 API - END */

	
	
	///////////////////////////////////////////////////////////////// EAI 관련 API //////////////////////////////////////////////////////////////////

	/**
	 * EAI를 통한 Interface(SYNC)를 수행한다.
	 * 
	 * @param request				EAI Interface request data(OMM)
	 * @param interfaceId			EAI Interface ID
	 * @param timeoutMiliseconds	Timeout (단위는 밀리초)
	 * @param application			Application Name
	 * @param serviceId				Service ID
	 * @param operationId			Operation ID
	 * @param deptCd				DEPT CODE
	 * @param userId				USER ID
	 * @param returnType			응답을 받을 데이터 type (OMM)
	 * @return	EAI 결과 데이터
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <R extends IOmmObject, S extends IOmmObject> EISResponse<S> callEAI(R request, String interfaceId, 
					int timeoutMiliseconds, String application, String serviceId, String operationId, String deptCd, String userId, Class<S> returnType) throws EisExecutionException, NotSupportedEISException {
		EISResponse<S>			response = new EISResponse<S>(null, null, LApplicationContext.getCurrentApplicationHeader(), null);
//		EISResponse<S> 				response 	= null;
		EISRequest<R, S> 			req 		= new EISRequest(request, returnType);
		ExtendedCignaSystemHeader 	header 		= null;
		
		if(logger.isDebugEnabled()) {
			logger.debug("INTERFACE ID:{}", interfaceId);
			logger.debug("TIMEOUT     :{}ms", timeoutMiliseconds);
			logger.debug("APPLICATION :{}", application);
			logger.debug("SERVICE ID  :{}", serviceId);
			logger.debug("OPERATION ID:{}", operationId);
			logger.debug("DEPT CODE   :{}", deptCd);
			logger.debug("USER ID     :{}", userId);
		}

		if(StringUtils.isEmpty(interfaceId)) {
			throw new EisExecutionException("EINPUT", "Interface id is empty.");
		}

		/*
		try {
			String guid = (String)LApplicationContext.getDataContainer().get(GUID_CACHE_NAME);
			if(guid == null) {
				guid = FwUtil.generateGlobaId();
				LApplicationContext.getDataContainer().put(GUID_CACHE_NAME, guid);
			}
			// GLOBAL ID 변환 
			LOGGER.info("ORG-GUID: {} <--> NEW-GUID: {}", new Object[] {FwUtil.getGlobalId(), guid});
	
			try {
				if(cma009bean == null) {
					cma009bean = (cigna.cm.a.bean.CMA009BEAN)LApplicationContext.getBean("cigna.cm.a.bean.CMA009BEAN");
					LOGGER.info("cigna.cm.a.bean.CMA009BEAN getBean Ended.");
				}
				TBCMCCD030Io fepGlblIdMappInfo = new TBCMCCD030Io();
				fepGlblIdMappInfo.setGlblId(FwUtil.getGlobalId());
				fepGlblIdMappInfo.setTrmsGlblId(guid);
				cma009bean.insertFepGlblIdMappInfo(fepGlblIdMappInfo);
			} catch (Exception e) {
				LOGGER.error("callEAI() GUID MAPPING INSERT ERROR: ", e);
			}		
			
			EISExecutor executor 	= EISExecutorFactory.getEisExecutor(EIS_TYPES.EIS_EAI, "EAI");
			if(application != null) {
				response = executor.execute(req,  EISResponse.class, new String[] {interfaceId, String.valueOf(timeoutMiliseconds), application, serviceId, operationId, deptCd, userId});
			} else {
				response = executor.execute(req,  EISResponse.class, new String[] {interfaceId, String.valueOf(timeoutMiliseconds)});
			}
		
		} finally {
			LApplicationContext.getDataContainer().remove(GUID_CACHE_NAME);
		}
		*/
		
		EISExecutor executor 	= EISExecutorFactory.getEisExecutor(EIS_TYPES.EIS_EAI, "EAI");
		if(application != null) {
			response = executor.execute(req,  EISResponse.class, new String[] {interfaceId, String.valueOf(timeoutMiliseconds), application, serviceId, operationId, deptCd, userId});
		} else {
			response = executor.execute(req,  EISResponse.class, new String[] {interfaceId, String.valueOf(timeoutMiliseconds)});
		}
														

		header = (ExtendedCignaSystemHeader)response.getHeader();
		if(!"0".equals(header.getRstTyp())) {
			throw new EisExecutionException(header.getMsgCd() + ":" + header.getBascMsg() + "-" + header.getAdMsg() + ":" + header.getSysMsg());
		}
		return response;
	}


	
	/**
	 * EAI를 통한 Interface(SYNC)를 수행한다.
	 * 
	 * @param request				EAI Interface request data(OMM)
	 * @param interfaceId			EAI Interface ID
	 * @param timeoutMiliseconds	Timeout (단위는 밀리초)
	 * @param returnType			응답을 받을 데이터 type (OMM)
	 * @return	EAI 결과 데이터
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */	
	public static <R extends IOmmObject, S extends IOmmObject> EISResponse<S> callEAI(R request, String interfaceId, 
					int timeoutMiliseconds, Class<S> returnType) throws EisExecutionException, NotSupportedEISException {
		return callEAI(request, interfaceId, timeoutMiliseconds, null, null, null, null, null, returnType);
	}
	
	/**
	 * EAI를 통한 Interface(SYNC)를 수행한다. 수행시 timeout은 EAI 환경 설정값으로 default로 설정된다.
	 * 
	 * @param request			EAI Interface request data(OMM)
	 * @param interfaceId		EAI Interface ID
	 * @param returnType		응답을 받을 데이터 type (OMM)
	 * @return	EAI 결과 데이터
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */	
	public static <R extends IOmmObject, S extends IOmmObject> EISResponse<S> callEAI(R request, String interfaceId, Class<S> returnType) 
			throws EisExecutionException, NotSupportedEISException 
	{
		return callEAI(request, interfaceId, -1, null, null, null, null, null, returnType);
	}
	
	/**
	 * EAI를 통한 Interface(SYNC)를 수행한다.
	 * 
	 * @param request				EAI Interface request data(OMM)
	 * @param interfaceId			EAI Interface ID
	 * @param application			Application Name
	 * @param serviceId				Service ID
	 * @param operationId			Operation ID
	 * @param deptCd				DEPT CODE
	 * @param userId				USER ID
	 * @param returnType			응답을 받을 데이터 type (OMM)
	 * @return	EAI 결과 데이터
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */
	public static <R extends IOmmObject, S extends IOmmObject> EISResponse<S> callEAI(R request, String interfaceId, 
                String application, String serviceId, String operationId, String deptCd, String userId, Class<S> returnType) throws EisExecutionException, NotSupportedEISException 
	{
		return callEAI(request, interfaceId, -1, application, serviceId, operationId, deptCd, userId, returnType);
	}
	
	/**
	 * EAI를 통한 Interface(callAsyncEAI)를 수행한다.
	 * 
	 * @param request				EAI Interface request data(OMM)
	 * @param interfaceId			EAI Interface ID
	 * @param timeoutMiliseconds	Timeout (단위는 밀리초)
	 * @param application			Application Name
	 * @param serviceId				Service ID
	 * @param operationId			Operation ID
	 * @param deptCd				DEPT CODE
	 * @param userId				USER ID
	 * @param returnType			응답을 받을 데이터 type (OMM)
	 * @return	EAI 결과 데이터
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <R extends IOmmObject, S extends IOmmObject> void callAsyncEAI(R request, String interfaceId, 
					int timeoutMiliseconds, String application, String serviceId, String operationId, String deptCd, String userId, Class<S> returnType) 
							throws EisExecutionException, NotSupportedEISException 
	{
		EISRequest<R, S> 			req 		= new EISRequest(request, returnType);
		
		if(logger.isDebugEnabled()) {
			logger.debug("INTERFACE ID:{}", interfaceId);
			logger.debug("TIMEOUT     :{}ms", timeoutMiliseconds);
			logger.debug("APPLICATION :{}", application);
			logger.debug("SERVICE ID  :{}", serviceId);
			logger.debug("OPERATION ID:{}", operationId);
			logger.debug("DEPT CODE   :{}", deptCd);
			logger.debug("USER ID     :{}", userId);
		}

		if(StringUtils.isEmpty(interfaceId)) {
			throw new EisExecutionException("EINPUT", "Interface id is empty.");
		}
		
		EISExecutor executor 	= null;
		try{
			executor 	= EISExecutorFactory.getEisExecutor(EIS_TYPES.EIS_EAI, "EAI");
			
			if(application != null) {
				executor.executeAsync(req, -1, new String[] {interfaceId, String.valueOf(timeoutMiliseconds), application, serviceId, operationId, deptCd, userId});
			} else {
				executor.executeAsync(req, -1, new String[] {interfaceId, String.valueOf(timeoutMiliseconds)});
			}
		} catch (ResourceTimedOutException e) {
			throw new EisExecutionException("Timeout error.", e);
		} 
	}


	
	/**
	 * EAI를 통한 Interface(callAsyncEAI)를 수행한다.
	 * 
	 * @param request				EAI Interface request data(OMM)
	 * @param interfaceId			EAI Interface ID
	 * @param timeoutMiliseconds	Timeout (단위는 밀리초)
	 * @param returnType			응답을 받을 데이터 type (OMM)
	 * @return	EAI 결과 데이터
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */	
	public static <R extends IOmmObject, S extends IOmmObject> void callAsyncEAI(R request, String interfaceId, 
					int timeoutMiliseconds, Class<S> returnType) throws EisExecutionException, NotSupportedEISException {
		callAsyncEAI(request, interfaceId, timeoutMiliseconds, null, null, null, null, null, returnType);
	}
	
	/**
	 * EAI를 통한 Interface(callAsyncEAI)를 수행한다. 수행시 timeout은 EAI 환경 설정값으로 default로 설정된다.
	 * 
	 * @param request			EAI Interface request data(OMM)
	 * @param interfaceId		EAI Interface ID
	 * @param returnType		응답을 받을 데이터 type (OMM)
	 * @return	EAI 결과 데이터
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */	
	public static <R extends IOmmObject, S extends IOmmObject> void callAsyncEAI(R request, String interfaceId, Class<S> returnType) 
			throws EisExecutionException, NotSupportedEISException 
	{
		callAsyncEAI(request, interfaceId, -1, null, null, null, null, null, returnType);
	}
	
	/**
	 * EAI를 통한 Interface(callAsyncEAI)를 수행한다.
	 * 
	 * @param request				EAI Interface request data(OMM)
	 * @param interfaceId			EAI Interface ID
	 * @param application			Application Name
	 * @param serviceId				Service ID
	 * @param operationId			Operation ID
	 * @param deptCd				DEPT CODE
	 * @param userId				USER ID
	 * @param returnType			응답을 받을 데이터 type (OMM)
	 * @return	EAI 결과 데이터
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */
	public static <R extends IOmmObject, S extends IOmmObject> void callAsyncEAI(R request, String interfaceId, 
                String application, String serviceId, String operationId, String deptCd, String userId, Class<S> returnType) throws EisExecutionException, NotSupportedEISException 
	{
		callAsyncEAI(request, interfaceId, -1, application, serviceId, operationId, deptCd, userId, returnType);
	}
	///////////////////////////////////////////////////////////////// FEP 관련 API //////////////////////////////////////////////////////////////////

	private static void loadFepProperties(boolean reload) throws EisExecutionException
	{
		FileInputStream input = null;
		
		if(reload || fepProperties == null) {
			fepProperties = new Properties();
			try {
				input = new FileInputStream(System.getProperty(FEP_PROPERTIES_FILE_KEY));
				fepProperties.load(input);
			} catch (IOException e) {
				logger.error("error: {}", e);
				throw new EisExecutionException("fep.properties file error: {}", e);
			} finally {
				if(input != null) {
					try {
						input.close();
					} catch (Exception e) {
						logger.error("error: {}", e);
					}
				}
			}
		}
	}
	/**
	 * 대외 시스템으로 데이터를 송수신한다.
	 * 
	 * @param request 		요청내용 (OMM)
	 * @param interfaceId 	interface id
	 * @param returnType 	응답받을 데이터 type (OMM)
	 * @return	수신 결과 데이터
	 * @throws EisExecutionException 
	 * @throws NotSupportedEISException
	 */	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <R extends IOmmObject, S extends IOmmObject> EISResponse<S> callFEP(R request, String interfaceId, Class<S> returnType) 
			throws EisExecutionException, NotSupportedEISException 
	{
		/*String instCode = null;
		String applCode = null;
		String kindCode = null;
		String txCode   = null;*/
		
		if(StringUtils.isEmpty(interfaceId) || interfaceId.length() != 20) {
			throw new EisExecutionException("EINPUT : interface id error: interface id is null or interface id length is not 20 bytes.");
		}
		
		/*instCode = interfaceId.substring(2, 6);
		applCode = interfaceId.substring(6, 10);
		kindCode = interfaceId.substring(10, 14);
		txCode   = getInterfaceTxCode(interfaceId);
		
		return callFEP(request, interfaceId, instCode, applCode, kindCode, txCode, returnType);*/
		EISResponse<S> 				response 	= null;
		EISRequest<R, S> 			req 		= new EISRequest(request, returnType);
		ExtendedCignaSystemHeader 	header 		= null;
		
		if(logger.isDebugEnabled()) {
			logger.debug("INTERFACE ID:{}", interfaceId);
		}

		//if(StringUtils.isEmpty(interfaceId)) {
		//	throw new EisExecutionException("EINPUT", "Interface id is empty.");
		//}

		/*
		try {
			String guid = (String)LApplicationContext.getDataContainer().get(GUID_CACHE_NAME);
			if(guid == null) {
				guid = FwUtil.generateGlobaId();
				LApplicationContext.getDataContainer().put(GUID_CACHE_NAME, guid);
			}
			// GLOBAL ID 변환 
			LOGGER.info("ORG-GUID: {} <--> NEW-GUID: {}", new Object[] {FwUtil.getGlobalId(), guid});
	
			EISExecutor executor 	= EISExecutorFactory.getEisExecutor(EIS_TYPES.EIS_EAI, "FEP");
			response = executor.execute(req,  EISResponse.class, new String[] {interfaceId, getInterfaceEncode(interfaceId)});
		} finally {
			LApplicationContext.getDataContainer().remove(GUID_CACHE_NAME);
		}
		*/
		
		EISExecutor executor 	= EISExecutorFactory.getEisExecutor(EIS_TYPES.EIS_EAI, "FEP");
		response = executor.execute(req,  EISResponse.class, new String[] {interfaceId, getInterfaceEncode(interfaceId)});
														
		header = (ExtendedCignaSystemHeader)response.getHeader();
		//if("0".equals(header.getRstTyp()) == false) {
		if(!"0".equals(header.getRstTyp())) {
			throw new EisExecutionException(header.getMsgCd() + ":" + header.getBascMsg() + "-" + header.getAdMsg() + ":" + header.getSysMsg());
		}
		return response;
	}

	/**
	 * FEP의 TxCode(거래코드)를 얻는다.
	 * 
	 * @param interfaceId TxCode를 얻으려는 InterfaceID
	 * @return TxCode (거래코드)
	 */
/*	private static String getInterfaceTxCode(String interfaceId) throws EisExecutionException {
		String txCode = null;

		loadFepProperties(false);
		
		txCode = fepProperties.getProperty(interfaceId + "_tx");
		if(txCode == null) {
			throw new EisExecutionException("TxCode Error: " + interfaceId + " is not registered in fep.properties file.");
		}
		
		return txCode;
	}*/
	
	/**
	 * FEP 인터페이스에 대한 기관별 encoding 정보 가져오기
	 * 
	 * @param interfaceId Encoding 정보를 얻으려는 InterfaceID
	 * @return Encode (Encoding 정보)
	 */
	private static String getInterfaceEncode(String interfaceId) throws EisExecutionException {
		String enCode = "KSC5601";

		loadFepProperties(false);
		
		if(interfaceId.equals("COR_F_ODBOSODBB00001") || interfaceId.equals("COR_F_ODBOSODBB00002")){
			enCode = fepProperties.getProperty(interfaceId);
		}else{
			enCode = fepProperties.getProperty(interfaceId.substring(6, 9)+"_"+interfaceId.substring(11, 15));
		}
		
		if(enCode == null || enCode.isEmpty()) {
			enCode = "KSC5601";
		}
		
		if(logger.isDebugEnabled()) {
			logger.debug("enCode:{}", enCode);
		}
		
		return enCode;
	}
	
	
	/**
	 * 대외계 시스템으로 Sync 전문을 전송한다.
	 * 
	 * @param request	요청 전문
	 * @param interfaceId	Interface ID
	 * @param instCode		기관코드
	 * @param applCode		Application Code
	 * @param kindCode		구분코드
	 * @param txCode		거래코드
	 * @param returnType	응답전문 type
	 * @return		응답전문
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */
	/*
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static <R extends IOmmObject, S extends IOmmObject> EISResponse<S> callFEP(R request, 
			String interfaceId, String instCode, String applCode, String kindCode, String txCode, Class<S> returnType) 
			throws EisExecutionException, NotSupportedEISException 
	{
		EISResponse<S> response = null;
		EISRequest<R, S> req 	= new EISRequest(request, returnType);
		String mapperType 		= null;

		LOGGER.debug("INTERFACE ID:{}", interfaceId);

		if(StringUtils.isEmpty(interfaceId)) {
			throw new EisExecutionException("EINPUT : interface id error.");
		}
		try {
			String guid = (String)LApplicationContext.getDataContainer().get(GUID_CACHE_NAME);
			if(guid == null) {
				guid = FwUtil.generateGlobaId();
				LApplicationContext.getDataContainer().put(GUID_CACHE_NAME, guid);
			}
			
			 GLOBAL ID 변환 
			LOGGER.info("ORG-GUID: {} <--> NEW-GUID: {}", new Object[] {FwUtil.getGlobalId(), guid});

			try {
				if(cma009bean == null) {
					cma009bean = (cigna.cm.a.bean.CMA009BEAN)LApplicationContext.getBean("cigna.cm.a.bean.CMA009BEAN");
					LOGGER.info("cigna.cm.a.bean.CMA009BEAN getBean Ended.");
				}
				TBCMCCD030Io fepGlblIdMappInfo = new TBCMCCD030Io();
				fepGlblIdMappInfo.setGlblId(FwUtil.getGlobalId());
				fepGlblIdMappInfo.setTrmsGlblId(guid);
				cma009bean.insertFepGlblIdMappInfo(fepGlblIdMappInfo);
			} catch (Exception e) {
				LOGGER.error("syncFEP() GUID MAPPING INSERT ERROR: ", e);
			}

			mapperType = getAnyLinkMapper(interfaceId);
			EISExecutor executor 	= EISExecutorFactory.getEisExecutor(EIS_TYPES.EIS_LINK, mapperType);
			response 				= executor.execute(req,  EISResponse.class, new String[] {interfaceId, instCode, applCode, kindCode, txCode});
		} finally {
			LApplicationContext.getDataContainer().remove(GUID_CACHE_NAME);
		}
		
		return response;
	}*/
	
	/**
	 * 대외 시스템으로 Async로 데이터를 송신한다.
	 * 
	 * @param request 		요청내용 (OMM)
	 * @param interfaceId 	interface id
	 * 
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */
	public static <R extends IOmmObject> void callAsyncFEP(R request, String interfaceId) 
			throws EisExecutionException, NotSupportedEISException 
	{
		/*String instCode = null;
		String applCode = null;
		String kindCode = null;
		String txCode   = null;
		
		instCode = interfaceId.substring(2, 6);
		applCode = interfaceId.substring(6, 10);
		kindCode = interfaceId.substring(10, 14);
		txCode   = getInterfaceTxCode(interfaceId);
		
		callAsyncFEP(request, interfaceId, instCode, applCode, kindCode, txCode);*/
		
		executeAsyncFEP(request, interfaceId);
	}

	/**
	 * 대외 시스템으로 Async로 데이터를 송신한다.
	 * 
	 * @param request	요청 전문
	 * @param interfaceId	Interface ID
	 * @throws EisExecutionException
	 * @throws NotSupportedEISException
	 */
	private static <R extends IOmmObject> void executeAsyncFEP(R request,  String interfaceId) throws EisExecutionException, NotSupportedEISException 
	{
		
		if(logger.isDebugEnabled()){
			logger.debug("INTERFACE ID:{}", interfaceId);
		}
		
		if(StringUtils.isEmpty(interfaceId) || interfaceId.length() != 20) {
			throw new EisExecutionException("EINPUT : interface id error: interface id is null or interface id length is not 20 bytes.");
		}
		
		EISExecutor executor = EISExecutorFactory.getEisExecutor(EIS_TYPES.EIS_EAI, "FEP");

		try {

			executor.executeAsync(request,  -1, new String[] {interfaceId, getInterfaceEncode(interfaceId)});
			
		} catch (ResourceTimedOutException e) {
			throw new EisExecutionException("Timeout error.", e);
		} 
		
	}

	///////////////////////////////////////////////////////////////// File 전송 관련 API //////////////////////////////////////////////////////////////////

	/**
	 * FEP Interface를 통하여 file을 전송한다.
	 * 
	 * @param transType 		TRANS_FILE_FEP_SYNC 또는 TRANS_FILE_FEP_ASYNC 또는 RECEIVE_FILE_FEP_ASYNC 값 
	 * @param interfaceId 		Interface ID
	 * @param localFileName    	전송할 Full File Path
	 * @param remoteFileName	전송될 곳의 File Path <br>
	 *                          TRANS_FILE_FEP_ASYNC는 디렉토리 정보없이 파일명만<br>
	 *                          RECEIVE_FILE_FEP_ASYNC는 파일명 설정할 필요 없음
	 * @param shellFullPath		전송후 실행할 상대 시스템의 shell 명령어
	 * @param shellParam		전송후 실행할 상대 시스템의 shell의 parameter
	 * @param hdbTxnDate		기준일자
	 * @param fileSeq			파일순번
	 * @throws EisExecutionException 실행오류 발생시.
	 */	
	private static void transFileFEP(int transType, String interfaceId, 
			String localFileName, String remoteFileName, String shellFullPath, String shellParam, String hdbTxnDateInput, int fileSeq) 
			throws EisExecutionException, NotSupportedEISException 
	{
		String hdbTxnDate = hdbTxnDateInput;
		
		FepFileTransOmm omm = new FepFileTransOmm(); 
		String			eaiFile;
		
		if(fileSeq<1) fileSeq=1;  // Set default 1 Fix 2016.10.12
		
		omm.setIfid(interfaceId);
		omm.setFileFullPath(remoteFileName);
		omm.setTranDate(hdbTxnDateInput);
		omm.setFileNum(fileSeq);

		TBCMCCD029Io fepFileLogInfo = new TBCMCCD029Io();

		if(transType == TRANS_FILE_FEP_ASYNC || transType == TRANS_FILE_FEP_SYNC) { /* 수신은 파일전송을 하지 않기 때문에 */
			/* FEP의 File 전송 서버까지는 EAI를 통해서 파일을 전송함. */
			//eaiFile = "B" + omm.getInstCode() + "/SEND/" + remoteFileName;
			
			eaiFile = remoteFileName;
			omm.setReqType(FEP_FILE_TRANS_TYPE);  // Fix FEP_FILE_TRANS_TYPE --> S  2016.10.12
			
			//--------------------------------------------------------------------------------------------------------
			transFileEAI(TRANS_FILE_EAI_SYNC, FEP_FILE_TRANS_IF_ID, localFileName, eaiFile, shellFullPath, shellParam);
			//--------------------------------------------------------------------------------------------------------
			
			fepFileLogInfo.setIfTrrvDcd("S");
			
		} 
		else if(transType == RECEIVE_FILE_FEP_ASYNC) {
			omm.setReqType(FEP_FILE_RECEIVE_TYPE);  // Fix FEP_FILE_RECEIVE_TYPE --> R  2016.10.12
		
			fepFileLogInfo.setIfTrrvDcd("R");
		} 
		else {
			throw new NotSupportedEISException("TransType is not supported. You should set the TransType as TRANS_FILE_FEP_ASYNC or RECEIVE_FILE_FEP_ASYNC.");
		}
		
		if(cma009bean == null) {
			cma009bean = (cigna.cm.a.bean.CMA009BEAN)LApplicationContext.getBean("cigna.cm.a.bean.CMA009BEAN");
			
			if(logger.isInfoEnabled()){
				logger.info("cigna.cm.a.bean.CMA009BEAN getBean Ended.");
			}
		}
		
		if (StringUtils.isEmpty(hdbTxnDate)) {
			hdbTxnDate = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		} 
		
		fepFileLogInfo.setIfTrmsKcd(String.valueOf(transType));
		fepFileLogInfo.setIfId(interfaceId);
		fepFileLogInfo.setLoclFileNm(localFileName);
		fepFileLogInfo.setRmotFileNm(remoteFileName);
		fepFileLogInfo.setBaseDt(hdbTxnDate);
		fepFileLogInfo.setFileTms(fileSeq);
		String guid = null;

// 		[[ Yasimhan 2016-05-26 - FEP 요청으로 인해 로그만 남기고 FEP 호출 부분은 주석처리함.
//		try {
			guid = FwUtil.generateGlobaId();
			fepFileLogInfo.setGlblId(guid);
//			LApplicationContext.getDataContainer().put(GUID_CACHE_NAME, guid);
			
			try {
				fepFileLogInfo.setFepFileTrmsStcd("10");
				if(StringUtils.isEmpty(fepFileLogInfo.getLoclFileNm())) {
					fepFileLogInfo.setLoclFileNm("#");
				}
				if(StringUtils.isEmpty(fepFileLogInfo.getRmotFileNm())) {
					fepFileLogInfo.setRmotFileNm("#");
				}
			
				//대외계 파일송수신 로그 적재
				cma009bean.insertFepFileLogInfo(fepFileLogInfo);
			
			} catch (Exception e) {
				logger.error("File전송 로그 생성 에러: ", e);
			}
			
			//EAI 파일 전송 API를 이용하여 파일 전송이 성공적으로 완료 된 후에 FEP에 파일전송이 완료 되었다는 Signal
			executeAsyncFEP(omm, interfaceId);

			
//		} catch (EisExecutionException ee) {
//			try {
//				fepFileLogInfo.setFepFileTrmsStcd("30");
//				cma009bean.updateFepFileLogInfo(fepFileLogInfo);
//			} catch (Exception e) {
//				logger.error("INSERT TBCMCCD029 ERROR: ", e);
//			}
//			throw ee;
//		} catch (NotSupportedEISException ne) {
//			try {
//				fepFileLogInfo.setFepFileTrmsStcd("30");
//				cma009bean.updateFepFileLogInfo(fepFileLogInfo);
//			} catch (Exception e) {
//				logger.error("INSERT TBCMCCD029 ERROR: ", e);
//			}
//			throw ne;
//		} finally {
//			// 파일전송 오류 메시지 처리
//			LApplicationContext.getDataContainer().remove(GUID_CACHE_NAME);
//		}
// 		2016-05-26 Yasimhan ]]
	
	}

	/**
	 * EAI Interface를 통하여 file을 전송한다.
	 * 
	 * @param transType TRANS_FILE_EAI_SYNC 또는 TRANS_FILE_EAI_ASYNC 값 
	 * @param interfaceId Interface ID
	 * @param localFileName   전송할 File명
	 * @param remoteFileName	전송될 곳의 File Path
	 * @param shellFullPath		전송후 실행할 상대 시스템의 shell 명령어
	 * @param shellParam		전송후 실행할 상대 시스템의 shell의 parameter
	 * @throws EisExecutionException 실행오류 발생시.
	 */
	private static void transFileEAI(int transType, String interfaceId, String localFileName, 
			String remoteFileName, String shellFullPath, String shellParam) throws EisExecutionException {
		String 		code;
		EAIMessage 	rslt = null;
		EaiFile		eai  = new EaiFile();

		if(transType == TRANS_FILE_EAI_ASYNC) {
			if(shellFullPath == null || shellFullPath.length() == 0) {
				rslt = eai.fileAsync(interfaceId, localFileName, remoteFileName);
			} else {
				rslt = eai.fileAsync(interfaceId, localFileName, remoteFileName, shellFullPath, shellParam);
			}
		} else {
			if(shellFullPath == null || shellFullPath.length() == 0) {
				rslt = eai.fileSync(interfaceId, localFileName, remoteFileName);
			} else {
				rslt = eai.fileSync(interfaceId, localFileName, remoteFileName, shellFullPath, shellParam);
			}
		}

		code = rslt.getCode();
		//if("SYSEA0000".equals(code)) {
		if("ISEAI0001".equals(code)){
			// [[ Yasimhan 2016-06-16 FEP 파일 전송 후 Signal 보내기 우해 수정.

			/* 
			// FEP Async SIGNAL 전송
			String ngs = NGS Header(1185byte);  // 표준전문 1185 byte 참조
			String str = “송/수신구분(S/R)(1byte)” + “FEP인터페이스ID(20byte)” + “Remote 파일경로 및 파일이름(80byte)” + 전송일자(8byte, YYYYMMDD) +“Space(51byte)” ;
			// Remote 파일경로 및 파일이름 : Remote 파일경로 → FEP 파일경로(IIMS IO 참조),  파일이름 : 기관으로 보낼 파일명       
			String signal = ngs + str;
			FEP fep = new FEP();
			FEPMessage msg = fep.async(signal.getBytes());      
			 */
			// 2016-06-16 ]]
			return;
		} else {
			StringBuffer buf = new StringBuffer(128);
			buf.append(rslt.getCode());
			buf.append(":");
			buf.append(rslt.getMsgStr());
			throw new EisExecutionException(buf.toString());
		}
	}
	
	/**
	 * EAI 또는 FEP Interface를 통하여 File을 전송한다. 
	 * 
	 * @param transType  		TRANS_FILE_EAI_SYNC, TRANS_FILE_EAI_ASYNC<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC, RECEIVE_FILE_FEP_ASYNC 등의 option<br>
	 * @param interfaceId 		Interface ID
	 * @param localFileName   	전송할 File의 Full name 또는 상대 Path name<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param remoteFileName	전송될 곳의 File의 full name 또는 상대 Path Name<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC의 경우 Filename만 설정한다.<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param shellFullPath		전송후 실행할 상대 시스템의 shell 명령어
	 * @param shellParam		전송후 실행할 상대 시스템의 shell의 parameter
	 * @param hdbTxDate			기준일자
	 * @throws EisExecutionException 실행오류 발생시.
	 * @throws NotSupportedEISException 실행 Option이 잘못된 경우 등 예외 발생
	 */
	public static void transFile(int transType, String interfaceId, String localFileName, 
			String remoteFileName, String shellFullPath, String shellParam, String hdbTxnDate, int fileSeq) throws  EisExecutionException, NotSupportedEISException {
		if(logger.isDebugEnabled()) {
			logger.debug("Trans Type: {}", transType);
			logger.debug("INTERFACE    ID: {}", interfaceId);
			logger.debug("LOCAL  FILENAME: {}", localFileName);
			logger.debug("REMOTE FILENAME: {}", remoteFileName);
			logger.debug("shellFullPath: {}", shellFullPath);
			logger.debug("shellParam: {}", shellParam);
			logger.debug("hdbTxnDate: {}", hdbTxnDate);
			logger.debug("fileSeq: {}", fileSeq);
		}

		if(StringUtils.isEmpty(interfaceId)) {
			throw new EisExecutionException("EINPUT : interface id error.");
		}
		if(transType != RECEIVE_FILE_FEP_ASYNC && StringUtils.isEmpty(localFileName)) {
			throw new EisExecutionException("EINPUT : local file name error.");
		}
		if(transType != RECEIVE_FILE_FEP_ASYNC && StringUtils.isEmpty(remoteFileName)) {
			throw new EisExecutionException("EINPUT : remote file name error.");
		}
		
		if(transType == TRANS_FILE_EAI_SYNC || transType == TRANS_FILE_EAI_ASYNC) {
			transFileEAI(transType, interfaceId, localFileName, remoteFileName, shellFullPath, shellParam);
		} else if(transType == TRANS_FILE_FEP_SYNC || transType == TRANS_FILE_FEP_ASYNC || transType == RECEIVE_FILE_FEP_ASYNC) {
			transFileFEP(transType, interfaceId, localFileName, remoteFileName, shellFullPath, shellParam, hdbTxnDate, fileSeq);
		} else {
			logger.error("Trans Type Error.");
			throw new NotSupportedEISException("TransType Error.");
		}
	}
	/**
	 * EAI 또는 FEP Interface를 통하여 File을 전송한다. 
	 * 
	 * @param transType  		TRANS_FILE_EAI_SYNC, TRANS_FILE_EAI_ASYNC<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC, RECEIVE_FILE_FEP_ASYNC 등의 option<br>
	 * @param interfaceId 		Interface ID
	 * @param localFileName   	전송할 File의 Full name 또는 상대 Path name<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param remoteFileName	전송될 곳의 File의 full name 또는 상대 Path Name<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC의 경우 Filename만 설정한다.<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param shellFullPath		전송후 실행할 상대 시스템의 shell 명령어
	 * @param shellParam		전송후 실행할 상대 시스템의 shell의 parameter
	 * @throws EisExecutionException 실행오류 발생시.
	 * @throws NotSupportedEISException 실행 Option이 잘못된 경우 등 예외 발생
	 */
	public static void transFile(int transType, String interfaceId, String localFileName, String remoteFileName, 
			String shellFullPath, String shellParam) throws  EisExecutionException, NotSupportedEISException {
		transFile(transType, interfaceId, localFileName, remoteFileName, shellFullPath, shellParam, null, 0); 
	}
	
	/**
	 * EAI 또는 FEP Interface를 통하여 File을 전송한다. 
	 * 
	 * @param transType  		TRANS_FILE_EAI_SYNC, TRANS_FILE_EAI_ASYNC<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC, RECEIVE_FILE_FEP_ASYNC 등의 option<br>
	 * @param interfaceId 		Interface ID
	 * @param localFileName   	전송할 File의 Full name 또는 상대 Path name<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param remoteFileName	전송될 곳의 File의 full name 또는 상대 Path Name<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC의 경우 Filename만 설정한다.<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @throws EisExecutionException 실행오류 발생시.
	 * @throws NotSupportedEISException 실행 Option이 잘못된 경우 등 예외 발생
	 */
	public static void transFile(int transType, String interfaceId, String localFileName, String remoteFileName) throws EisExecutionException, NotSupportedEISException {
		transFile(transType, interfaceId, localFileName, remoteFileName, null, null, null, 0);
	}


	/**
	 * EAI 또는 FEP Interface를 통하여 File을 전송한다. 
	 * 
	 * @param transType  		TRANS_FILE_EAI_SYNC, TRANS_FILE_EAI_ASYNC<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC, RECEIVE_FILE_FEP_ASYNC 등의 option<br>
	 * @param interfaceId 		Interface ID
	 * @param localFileName   	전송할 File의 Full name 또는 상대 Path name<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param remoteFileName	전송될 곳의 File의 full name 또는 상대 Path Name<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC의 경우 Filename만 설정한다.<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param hdbTxnDate		기준일자
	 * @throws EisExecutionException 실행오류 발생시.
	 * @throws NotSupportedEISException 실행 Option이 잘못된 경우 등 예외 발생
	 */
	public static void transFile(int transType, String interfaceId, String localFileName, String remoteFileName, String hdbTxnDate) throws EisExecutionException, NotSupportedEISException {
		transFile(transType, interfaceId, localFileName, remoteFileName, null, null, hdbTxnDate, 0);
	}

	/**
	 * EAI 또는 FEP Interface를 통하여 File을 전송한다. 
	 * 
	 * @param transType  		TRANS_FILE_EAI_SYNC, TRANS_FILE_EAI_ASYNC<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC, RECEIVE_FILE_FEP_ASYNC 등의 option<br>
	 * @param interfaceId 		Interface ID
	 * @param localFileName   	전송할 File의 Full name 또는 상대 Path name<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param remoteFileName	전송될 곳의 File의 full name 또는 상대 Path Name<br>
	 * 							TRANS_FILE_FEP_SYNC, TRANS_FILE_FEP_ASYNC의 경우 Filename만 설정한다.<br>
	 * 							RECEIVE_FILE_FEP_ASYNC는 파일명을 설정하지 않는다.
	 * @param hdbTxnDate		기준일자
	 * @param fileSeq			파일순번
	 * @throws EisExecutionException 실행오류 발생시.
	 * @throws NotSupportedEISException 실행 Option이 잘못된 경우 등 예외 발생
	 */
	public static void transFile(int transType, String interfaceId, String localFileName, String remoteFileName, String hdbTxnDate, int fileSeq) throws EisExecutionException, NotSupportedEISException {
		transFile(transType, interfaceId, localFileName, remoteFileName, null, null, hdbTxnDate, fileSeq);
	}	
	/**
	 * 대외계 시스템을 통하여 파일 수신요청을 한다. 
	 * 
	 * @param interfaceId 		Interface ID
	 * @param hdbTxnDate		기준일자
	 * @throws EisExecutionException 실행오류 발생시.
	 * @throws NotSupportedEISException 실행 Option이 잘못된 경우 등 예외 발생
	 */
	public static void receiveFile(String interfaceId, String hdbTxnDate) throws EisExecutionException, NotSupportedEISException {
		transFile(RECEIVE_FILE_FEP_ASYNC, interfaceId, null, null, null, null, hdbTxnDate, 0);
	}
	
	/**
	 * 대외계 시스템을 통하여 파일 수신요청을 한다. 
	 * 
	 * @param interfaceId 		Interface ID
	 * @throws EisExecutionException 실행오류 발생시.
	 * @throws NotSupportedEISException 실행 Option이 잘못된 경우 등 예외 발생
	 */
	public static void receiveFile(String interfaceId) throws EisExecutionException, NotSupportedEISException {
		transFile(RECEIVE_FILE_FEP_ASYNC, interfaceId, null, null, null, null, null, 0);
	}

	///////////////////////////////////////////////////////////////// Push Server API ///////////////////////////////////////////////////////////////////////////
	/**
	 * Ondemand Batch에서 Push Message를 UI로 발송한다.
	 * 
	 * @param sendType 전송 Message의 Type (MSG) - C(4)
	 * @param eno Push Message를 받을 사원번호 C(10)
	 * @param scrnNo 화면번호 C(10) 
	 * @param title  Message의 제목  C(256)
	 * @param content Message의 내용  C(4000)
	 * @param atchFilePathNm 첨부파일경로명 C(500)
	 * @param atchSavFileNm 첨부저장파일명 C(100)
	 */
	private static void sendPushMessage(String sendType, String eno, String scrnNo, String title, String content, String atchFilePathNm, String atchSavFileNm, String trmsSuccYn) {
		if(logger.isInfoEnabled()){
			logger.info("start sendPushMessage()");
		}
		if(cma007bean == null) {
			cma007bean = (cigna.cm.a.bean.CMA007BEAN)LApplicationContext.getBean("cigna.cm.a.bean.CMA007BEAN");
			if(logger.isInfoEnabled()){
				logger.info("cigna.cm.a.bean.CMA007BEAN getBean Ended.");
			}
		}
		if(cma007bean == null) {
			logger.error("CMA007BEAN 객체 생성 오류입니다.: PushMessage를 발송할 수 없습니다.");
			return;
		}
		
		if(logger.isInfoEnabled()){
			logger.info("Print Data cma007bean= [{}], sendType= [{}], eno= [{}], scrnNo= [{}], title= [{}], content= [{}], atchFilePathNm= [{}], atchSavFileNm= [{}], trmsSuccYn= [{}]"
				, new Object[]{cma007bean, sendType, eno, scrnNo, title, content, atchFilePathNm, atchSavFileNm, trmsSuccYn});
		}
		//----------------------------------------------------------------------------------------------------
		cma007bean.setPushServiceInfoTCP(sendType, eno, scrnNo, title, content, atchFilePathNm, atchSavFileNm, trmsSuccYn);
		//----------------------------------------------------------------------------------------------------
		if(logger.isDebugEnabled()){
			logger.debug("Print Data cma007bean= [{}], sendType= [{}], eno= [{}], scrnNo= [{}], title= [{}], content= [{}], atchFilePathNm= [{}], atchSavFileNm= [{}], trmsSuccYn= [{}]"
				, new Object[]{cma007bean, sendType, eno, scrnNo, title, content, atchFilePathNm, atchSavFileNm, trmsSuccYn});
		}
	}
	
	/**
	 * Ondemand Batch에서 Push Message를 UI로 발송한다.
	 * 
	 * @param eno Push Message를 받을 사원번호 C(10)
	 * @param scrnNo 화면번호 C(10)
	 * @param title  Message의 제목 C(256)
	 * @param content Message의 내용 C(4000)
	 */
	public static void sendPushMessage(String eno, String scrnNo, String title, String content) {
		sendPushMessage(PUSH_TYPE_MSG, eno, scrnNo, title, content, null, null, null);
	}
	
	/**
	 * Ondemand Batch에서 Push Message를 UI로 발송한다.
	 * 
	 * @param eno Push Message를 받을 사원번호 C(10)
	 * @param scrnNo 화면번호 C(10) 
	 * @param title  Message의 제목  C(256)
	 * @param content Message의 내용  C(4000)
	 * @param atchFilePathNm 첨부파일경로명 C(500)
	 * @param atchSavFileNm 첨부저장파일명 C(100)
	 */
	public static void sendPushMessage(String eno, String scrnNo, String title, String content, String atchFilePathNm, String atchSavFileNm) {
		sendPushMessage(PUSH_TYPE_FILE, eno, scrnNo, title, content, atchFilePathNm, atchSavFileNm, null);
	}
	
	/**
	 * Ondemand Batch에서 결과처리한다.
	 * 
	 * @param eno Push Message를 받을 사원번호 C(10)
	 * @param scrnNo 화면번호 C(10) 
	 * @param title  Message의 제목  C(256)
	 * @param content Message의 내용  C(4000)
	 * @param atchFilePathNm 첨부파일경로명 C(500)
	 * @param atchSavFileNm 첨부저장파일명 C(100)
	 * @param trmsSuccYn 전송성공여부 C(1)
	 */
	public static void sendPushMessage(String eno, String scrnNo, String title, String content, String atchFilePathNm, String atchSavFileNm, String trmsSuccYn) {
		sendPushMessage(PUSH_TYPE_FILE, eno, scrnNo, title, content, atchFilePathNm, atchSavFileNm, trmsSuccYn);
	}
	///////////////////////////////////////////////////////////////// On Demand Batch 관련 API //////////////////////////////////////////////////////////////////
	
	/**
	 * Online Program에서 Batch(Ondemand Batch)를 실행한다.
	 * 
	 * <pre>
	 * Sample Program.
	 * 
	 *  
	 * try {
	 *     InfUtil.startBatch("BFWXXX1B", new String[] {"startDt=20120101", "endDt=20121231"});
	 * } catch (EisExecutionException e) {
	 *     throw new ApplicationException(...);
	 * }
	 * 
	 * </pre>
	 * 
	 * @param jobName  실행할 Job Name
	 * @param parameters  Batch 실행에 필요한 key=value의 쌍에 대한 문자열 배열
	 * @return OnDemand Batch 실행 상태코드
	 * @throws ApplicationException
	 */
	public static void startBatch(String jobName, String[] parameters) throws EisExecutionException {
		startBatch(jobName, parameters, FwUtil.getGlobalId());
	}

	/**
	 * Ondemand Batch를 실행를 실행한다.
	 * Ondemand batch 실행후 배치의 진행상태를 확인하기 위해서는 global id를 parameter로 넘겨 설정하거나
	 * guid를 null로 설정하여 return된 guid로 실행상태를 모니터링한다.
	 * 
	 * <pre>
	 * try {
	 *     String guid = InfUtil.startBatch("BFWXXX1B", new String[] {"startDt=20120101", "endDt=20121231"}, null);
	 *     ...
	 * } catch (EisExecutionException e) {
	 *     throw new ApplicationException(...);
	 * }
	 * </pre>
	 * 
	 * @param jobName 실행 배치 job id
	 * @param parameters 실행할 parameters
	 * @param guid ondemand batch를 Unique하게 구별할 수 있는 GUID, null을 설정하면 guid를 내부에서 생성함
	 * @return guid를 return한다.
	 * @throws EisExecutionException
	 */
	public static String startBatch(String jobName, String[] parameters, String guidInput) throws EisExecutionException {
		String guid = guidInput;
		
		URL url = null;
		String urlName = null;
		Set<OnDemandCommandOption> options = null;
		String params[] = null;

		try {
			if(jobName.charAt(jobName.length() -1 ) != 'O'){
				throw new ApplicationException("APFWE0001", new Object[]{"OnDemand"});
			}
			
			urlName = System.getProperty("ondemandBatch.url");
			if(StringUtils.isEmpty(urlName)) {
				throw new EisExecutionException("The ondemand Batch Url is not set.");
			}
			url = new URL(urlName);
			
			options = new HashSet<OnDemandCommandOption>();
			options.add(OnDemandCommandOption.START);

			//////////////////////////////////////////////////////////////////////////////////////////
			// Push Server호출을 위한 Ondemand Batch 실행시 user 정보에 대한 parameter 추가   
			if(parameters == null) {
				params = new String[5];
			} else {
				params = new String[parameters.length + 5];
				/*for(int idx = 0; idx < parameters.length; idx++) {
					params[idx] = parameters[idx];
				}*/
				System.arraycopy(parameters, 0, params, 0, parameters.length);
			}
			if(StringUtils.isEmpty(guid)) {
				guid = FwUtil.generateGlobaId();
			}
			params[params.length - 5] = "onlineIpAddr=" + FwUtil.getTrmNo();
			params[params.length - 4] = "onlineGUID="   + guid;
			params[params.length - 3] = "onlineUserId=" + FwUtil.getUserId();
			params[params.length - 2] = "onlineDeptCd=" + FwUtil.getDeptCd();
			params[params.length - 1] = "screenId="     + FwUtil.getScreenId();
			//////////////////////////////////////////////////////////////////////////////////////////
			
			OnDemandStatus status = RemoteContainerServiceExecutor.startBatch( url, jobName, params, options);
			if(OnDemandStatus.EXECUTING.getCode().equals(status.getCode())) {
				return guid;
			} else {
				throw new EisExecutionException(status.toString());
			}
		} catch (MalformedURLException e) {
			throw new EisExecutionException("Invalide Ondemand Batch Url: ", e);
		} catch (EisExecutionException e) {
			logger.error("StartBatch Error: ", e);
			throw e;
		} catch (ApplicationException e){
			logger.error("StartBatch Error: ", e);
			throw new EisExecutionException("Application Exception: ", e);
		} catch (Exception e) {
			logger.error("StartBatch Error: ", e);
			throw new EisExecutionException("Unknowned Exception: ", e);
		}	
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	/* 대외시스템을 통해서 file 전송을 위한 OMM class file */
	/* 아래의 Source는 Source Generation된 것입니다. */
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	@XmlType(propOrder={"reqType", "ifid", "fileFullPath", "tranDate", "fileNum", "filler"}, name="FepFileTransOmm")

	@XmlRootElement(name="FepFileTransOmm")
	private static class FepFileTransOmm  implements IOmmObject  {
		
		private static final long serialVersionUID = 1923446889L;
		
		@XmlTransient
		public static final String OMM_DESCRIPTION = "대외계 파일전송용 전문";
		
		/*******************************************************************************************************************************
		* Property set << reqType >> [[ */
		
		@XmlTransient
		private boolean isSet_reqType = false;
		
		protected boolean isSet_reqType()
		{
			return this.isSet_reqType;
		}
		
		protected void setIsSet_reqType(boolean value)
		{
			this.isSet_reqType = value;
		}
		
		
		@KlafOmm_Field(referenceType="reference", description="송수신flag", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
		private java.lang.String reqType  = null;
		public java.lang.String getReqType(){
			return reqType; 
		}
		
		public void setReqType( java.lang.String reqType ) {
			isSet_reqType = true;
			this.reqType = reqType;
		}
		
		/** Property set << reqType >> ]]
		*******************************************************************************************************************************/
		/*******************************************************************************************************************************
		* Property set << ifid >> [[ */
		
		@XmlTransient
		private boolean isSet_ifid = false;
		
		protected boolean isSet_ifid()
		{
			return this.isSet_ifid;
		}
		
		protected void setIsSet_ifid(boolean value)
		{
			this.isSet_ifid = value;
		}
		
		
		@KlafOmm_Field(referenceType="reference", description="인터페이스ID", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
		private java.lang.String ifid  = null;
		public java.lang.String getIfid(){
			return ifid; 
		}
		
		public void setIfid( java.lang.String ifid ) {
			isSet_ifid = true;
			this.ifid = ifid;
		}
		
		/** Property set << ifid >> ]]
		*******************************************************************************************************************************/
		/*******************************************************************************************************************************
		* Property set << fileFullPath >> [[ */
		
		@XmlTransient
		private boolean isSet_fileFullPath = false;
		
		protected boolean isSet_fileFullPath()
		{
			return this.isSet_fileFullPath;
		}
		
		protected void setIsSet_fileFullPath(boolean value)
		{
			this.isSet_fileFullPath = value;
		}
		
		
		@KlafOmm_Field(referenceType="reference", description="파일경로 및 명", formatType="", format="", align="left", length=80, decimal=0, arrayReference="", fill="")
		private java.lang.String fileFullPath  = null;
		public java.lang.String getFileFullPath(){
			return fileFullPath; 
		}
		
		public void setFileFullPath( java.lang.String fileFullPath ) {
			isSet_fileFullPath = true;
			this.fileFullPath = fileFullPath;
		}
		
		/** Property set << fileFullPath >> ]]
		*******************************************************************************************************************************/
		/*******************************************************************************************************************************
		* Property set << tranDate >> [[ */
		
		@XmlTransient
		private boolean isSet_tranDate = false;
		
		protected boolean isSet_tranDate()
		{
			return this.isSet_tranDate;
		}
		
		protected void setIsSet_tranDate(boolean value)
		{
			this.isSet_tranDate = value;
		}
		
		
		@KlafOmm_Field(referenceType="reference", description="송수신날자", formatType="date", format="yyyyMMdd", align="left", length=8, decimal=0, arrayReference="", fill="")
		private java.lang.String tranDate  = null;
		public java.lang.String getTranDate(){
			return tranDate; 
		}
		
		public void setTranDate( java.lang.String tranDate ) {
			isSet_tranDate = true;
			this.tranDate = tranDate;
		}
		
		/** Property set << tranDate >> ]]
		*******************************************************************************************************************************/
		/*******************************************************************************************************************************
		* Property set << fileNum >> [[ */
		
		@XmlTransient
		private boolean isSet_fileNum = false;
		
		protected boolean isSet_fileNum()
		{
			return this.isSet_fileNum;
		}
		
		protected void setIsSet_fileNum(boolean value)
		{
			this.isSet_fileNum = value;
		}
		
		
		@KlafOmm_Field(referenceType="reference", description="파일보낸횟수", formatType="", format="", align="right", length=2, decimal=0, arrayReference="", fill="")
		private java.lang.Integer fileNum  = 0;
		public java.lang.Integer getFileNum(){
			return fileNum;
		}
		
		public void setFileNum( java.lang.Integer fileNum ) {
			isSet_fileNum = true;
			this.fileNum = fileNum;
		}
		
		/** Property set << fileNum >> ]]
		*******************************************************************************************************************************/
		/*******************************************************************************************************************************
		* Property set << filler >> [[ */
		
		@XmlTransient
		private boolean isSet_filler = false;
		
		protected boolean isSet_filler()
		{
			return this.isSet_filler;
		}
		
		protected void setIsSet_filler(boolean value)
		{
			this.isSet_filler = value;
		}
		
		
		@KlafOmm_Field(referenceType="reference", description="예비필드", formatType="", format="", align="left", length=49, decimal=0, arrayReference="", fill="")
		private java.lang.String filler  = null;
		public java.lang.String getFiller(){
			return filler; 
		}
		
		public void setFiller( java.lang.String filler ) {
			isSet_filler = true;
			this.filler = filler;
		}
		
		/** Property set << filler >> ]]
		*******************************************************************************************************************************/

		@XmlTransient
		private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
		
		public Object get(String key) throws IllegalArgumentException{
			switch( key.hashCode() ){
				case -1274499728 : 
						return getFiller();
				case 1094728952 : 
						return getReqType();
				case 1279478137 : 
						return getTranDate();
				case 3229432 : 
						return getIfid();
				case 62863600 : 
						return getFileFullPath();
				case -855016342 : 
						return getFileNum();
				default : {
					if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
					else throw new IllegalArgumentException("Not found element : " + key);
				}
			}
		}
		public void set(String key, Object value){
			switch( key.hashCode() ){
				case -1274499728 : 
					setFiller( (java.lang.String) value);
					return;
				case 1094728952 : 
					setReqType( (java.lang.String) value);
					return;
				case 1279478137 : 
					setTranDate( (java.lang.String) value);
					return;
				case 3229432 : 
					setIfid( (java.lang.String) value);
					return;
				case 62863600 : 
					setFileFullPath( (java.lang.String) value);
					return;
				case -855016342 : 
					setFileNum( (java.lang.Integer) value);
					return;
				default : htDynamicVariable.put(key, value);
			}
		}

		@Override
		public Object clone() throws CloneNotSupportedException {
			
			
			return super.clone();
		}

		
		@Override
		public int hashCode(){ 
			final int prime=31;
			int result = 1;
			result = prime * result + ((reqType==null)?0:reqType.hashCode());
			result = prime * result + ((ifid==null)?0:ifid.hashCode());
			result = prime * result + ((fileFullPath==null)?0:fileFullPath.hashCode());
			result = prime * result + ((tranDate==null)?0:tranDate.hashCode());
			result = prime * result + ((fileNum==null)?0:fileNum.hashCode());
			result = prime * result + ((filler==null)?0:filler.hashCode());
			return result;
		}
		
		@Override
		public boolean equals(Object obj) {
			if ( this == obj ) return true;
			if ( obj == null ) return false;
			if ( getClass() != obj.getClass() ) return false;
			final FepFileTransOmm other = (FepFileTransOmm)obj;
			if ( reqType == null ){
				if ( other.reqType != null ) return false;
			}
			else if ( !reqType.equals(other.reqType) )
				return false;
			if ( ifid == null ){
				if ( other.ifid != null ) return false;
			}
			else if ( !ifid.equals(other.ifid) )
				return false;
			if ( fileFullPath == null ){
				if ( other.fileFullPath != null ) return false;
			}
			else if ( !fileFullPath.equals(other.fileFullPath) )
				return false;
			if ( tranDate == null ){
				if ( other.tranDate != null ) return false;
			}
			else if ( !tranDate.equals(other.tranDate) )
				return false;
			if ( fileNum == null ){
				if ( other.fileNum != null ) return false;
			}
			else if ( !fileNum.equals(other.fileNum) )
				return false;
			if ( filler == null ){
				if ( other.filler != null ) return false;
			}
			else if ( !filler.equals(other.filler) )
				return false;
			return true;
		}
		
		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			
			sb.append( "\n[cigna.zz.FepFileTransOmm:\n");
			sb.append("\treqType: ");
			sb.append(reqType==null?"null":getReqType() );
			sb.append("\n");
			sb.append("\tifid: ");
			sb.append(ifid==null?"null":getIfid() );
			sb.append("\n");
			sb.append("\tfileFullPath: ");
			sb.append(fileFullPath==null?"null":getFileFullPath() );
			sb.append("\n");
			sb.append("\ttranDate: ");
			sb.append(tranDate==null?"null":getTranDate() );
			sb.append("\n");
			sb.append("\tfileNum: ");
			sb.append(fileNum==null?"null":getFileNum() );
			sb.append("\n");
			sb.append("\tfiller: ");
			sb.append(filler==null?"null":getFiller() );
			sb.append("\n");
			sb.append("]\n");
			
			return sb.toString();
		}
	}
}