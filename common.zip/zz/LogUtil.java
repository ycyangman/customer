package cigna.zz;

import java.io.UnsupportedEncodingException;

import cigna.cm.a.dbio.CMA903DBIO;
import cigna.cm.a.io.TBCMETC006Io;
import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.omm.root.IOmmObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * @file         cigna.zz.LogUtil.java
 * @filetype     java source file
 * @brief        금감원 감독규정에 의거한 전산원장 변경전후 내용 기록을 위하여 신기간계 공통 업무 테이블에 데이터 액세스를 수행하는 공통 API 클래스<br>
 * <pre>
 * 본 클래스를 사용하기 위해서는 다음에 나오는 내용을 준수
 * 1. LogUtil 클래스는 @Autowired 해야 사용가능
 * 2. 원장변경 대상데이터는 자동으로 조회해주지 않음(각자 개발한 DBIO를 사용하여 조회하여 조회결과 OMM을 파라미터로 넘겨야함)
 * 3. 제공되는 API는 변경전 또는 변경후 1개의 ROW를 저장하거나, 변경 전/후 데이터를 같이 저장하는 형태를 제공
 * </pre>
 * @author       김정국
 * @version      0.1
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           김정국                 2015. 3. 23.       신규 작성
 *
 */
@KlafBean
public class LogUtil {
	
	final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 원장변경 처리가 INSERT 일때 LogUtil.INSERT 형태로 사용
	 */
	public static final int INSERT = 0;
	
	/**
	 * 원장변경 처리가 UPDATE 일때 LogUtil.UPDATE 형태로 사용
	 */
	public static final int UPDATE = 1;
	
	/**
	 * 원장변경 처리가 DELETE 일때 LogUtil.DELETE 형태로 사용
	 */
	public static final int DELETE = 2;
	
	/**
	 * 원장변경 처리가 변경전 일때 LogUtil.BEFORE 형태로 사용
	 */
	public static final int BEFORE = 0;
	
	/**
	 * 원장변경 처리가 변경후 일때 LogUtil.AFTER 형태로 사용
	 */
	public static final int AFTER = 1;
	
	/**
	 * 신기간계 DB 캐릭터셋
	 */
	private static final String DB_CHARSET = "MS949";
	
	/**
	 * 변경작업 구분코드와 맵핑할 코드 테이블
	 */
	private static final String[] WORK_DCD_LIST = new String[]{"I", "U", "D"};
	
	/**
	 * 변경전후 구분코드와 맵핑할 코드 테이블
	 */
	private static final String[] BEFORE_AFTER_LIST = new String[]{"B", "A"};
	
	@Autowired
	private CMA903DBIO cma903dbio;
	
	/**
	 * 원장변경 처리전 또는 처리후에 호출하여 테이블 ROW의 데이터를 기록
	 * @param itsmId ITSM ID
	 * @param tableName 변경할 테이블명
	 * @param colNames 변경컬럼 이름(컬럼이 2개이상이면 '|' 로 연결)
	 * @param chgWrkDcd 변경작업구분코드(I:INSERT, U:UPDATE, D:DELETE)
	 * @param chgBfafDcd 변경전후구분코드(B:변경전, A:변경후)
	 * @param changeRowSeq 변경대상의 순번
	 * @param omm PK로 조회된 1개의 ROW 데이터가 할당된 OMM
	 * @param lastChgrId 최종변경자ID(IT 담당자의 사번)
	 * @param lastChgPgmId 최종변경프로그램ID(배치잡ID)
	 * @param lastChgTrmNo 최종변경단말번호
	 * @throws ApplicationException 입력 파라미터가 올바르지 않거나 처리가 실패한 경우
	 */
	public void saveChangedLog(
			final String itsmId
			, final String tableName
			, final String colNames
			, final int chgWrkDcd
			, final int chgBfafDcd
			, final int changeRowSeq
			, IOmmObject omm
			, final String lastChgrId
			, final String lastChgPgmId
			, final String lastChgTrmNo) throws ApplicationException {
		
		logger.debug("원장변경 이력생성 시작(ITSM ID:[{}] / 변경순번:[{}] / 작업구분:[{}] / 변경전후구분:[{}])"
				, new Object[]{itsmId, changeRowSeq, WORK_DCD_LIST[chgWrkDcd], BEFORE_AFTER_LIST[chgBfafDcd]});
		
		if(!FwUtil.isBatch())
			throw new ApplicationException("APCME0045", null);
		
		if(StringUtils.isEmpty(itsmId))
			throw new ApplicationException("APCME0044", null, new String[]{"ITSM ID 가 필요합니다."});
		
		if(StringUtils.isEmpty(tableName))
			throw new ApplicationException("APCME0044", null, new String[]{"테이블 영문명이 필요합니다."});
		
		if(StringUtils.isEmpty(colNames))
			throw new ApplicationException("APCME0044", null, new String[]{"원장변경 칼럼영문명이 필요합니다."});
		
		if(chgWrkDcd < 0 || chgWrkDcd > 2)
			throw new ApplicationException("APCME0044", null, new String[]{"작업구분코드는 0 ~ 2 중 택일해야 합니다."});
		
		if(chgBfafDcd < 0 || chgBfafDcd > 1)
			throw new ApplicationException("APCME0044", null, new String[]{"변경전후구분코드는 0 ~ 1 중 택일해야 합니다."});
		
		if(changeRowSeq <= 0)
			throw new ApplicationException("APCME0044", null, new String[]{"변경대상순번은 1 이상이어야 합니다."});
		
		if(omm == null)
			throw new ApplicationException("APCME0044", null, new String[]{"저장할 OMM 데이터가 필요합니다."});
		
		if(StringUtils.isEmpty(lastChgrId))
			throw new ApplicationException("APCME0044", null, new String[]{"최종변경자 ID가 필요합니다."});
		
		if(StringUtils.isEmpty(lastChgPgmId))
			throw new ApplicationException("APCME0044", null, new String[]{"최종변경프로그램 ID가 필요합니다."});
		
		if(StringUtils.isEmpty(lastChgTrmNo))
			throw new ApplicationException("APCME0044", null, new String[]{"최종변경단말번호가 필요합니다."});
		
		//OMM을 CSV 형식의 문자열로 변환
		String csvContent = FwUtil.toCSV(omm);
		
		logger.debug("OMM >> CSV 변환한 데이터:[{}]", csvContent);
		
		//저장 데이터의 전체길이
		try {
			int contLength = csvContent.getBytes(LogUtil.DB_CHARSET).length;
			logger.debug("OMM >> CSV 변환한 데이터 길이:[{}]", contLength);
		}
		catch(UnsupportedEncodingException e) {
			logger.error("OMM >> CSV 변환한 데이터의 byte[]로 변환 실패", e);
			logger.error("OMM >> CSV:[{}]", csvContent);
			//원장변경 전/후 데이터를 CSV 형식으로 변환에 실패했습니다.
			throw new ApplicationException("APCME0043", null, null, e);
		}
		
		int loggedCnt = 0;
		
		//저장 데이터의 순번
		int detailSeq = 1;
		
		//무한반복 방어 변수
		int exitCnt = 100;
		
		//CSV 변환한 문자열 길이
		while(StringUtils.hasLength(csvContent)) {
			
			//무한루프 방어로직 수행
			if(exitCnt-- <= 0) {
				logger.warn("이력생성 데이터(ITSM ID:[{}] / 변경순번:[{}])의 데이터가 무한루프 방어로직에 감지되었습니다.", new Object[]{itsmId, changeRowSeq});
				break;
			}
			
			String cuttedContent = FwUtil.substringKorean(csvContent, 4000, LogUtil.DB_CHARSET);
			
			//원장데이터 logging
			loggedCnt += this.doLogging(itsmId, tableName, chgWrkDcd, chgBfafDcd, changeRowSeq, detailSeq++, cuttedContent
					, colNames, lastChgrId, lastChgPgmId, lastChgTrmNo);
			
			logger.debug("원장변경내용 상세순번:[{}] 처리함", detailSeq);
			
			//남은 문자열을 다시 재할당
			csvContent = csvContent.substring(cuttedContent.length());
			
			logger.debug("추가 저장 데이터 존재여부:[{}]", StringUtils.hasLength(csvContent));
		}
		
		logger.debug("원장변경 이력생성 저장건수:[{}]", loggedCnt);
		
		/*
		 * 원장변경에 대한 전/후 데이터를 저장하지 못했습니다.
		 * 원장변경 대상에서 {0}번째 데이터
		 */
		if(loggedCnt < 1)
			throw new ApplicationException("APCME0042", null, new Object[]{changeRowSeq});
		
		logger.debug("원장변경 이력생성 종료(ITSM ID:[{}] / 변경순번:[{}])", itsmId, changeRowSeq);
	}
	
	/**
	 * 원장변경 처리후에 호출하여 테이블 ROW의 전/후 데이터를 기록
	 * @param itsmId ITSM ID
	 * @param tableName 변경할 테이블명
	 * @param colNames 변경컬럼 이름(컬럼이 2개이상이면 '|' 로 연결)
	 * @param chgWrkDcd 작업구분코드(I:INSERT, U:UPDATE, D:DELETE)
	 * @param changeRowSeq 변경대상의 순번
	 * @param beforeOmm PK로 조회된 1개의 ROW 데이터가 할당된 OMM(변경전)
	 * @param afterOmm PK로 조회된 1개의 ROW 데이터가 할당된 OMM(변경후)
	 * @param lastChgrId 원장변경을 처리하는 IT 개발담당자
	 * @param lastChgPgmId 원장변경 처리를 수행하는 배치잡
	 * @param lastChgTrmNo 원장변경을 처리하는 IT 개발담당자 IP
	 * @throws ApplicationException 입력 파라미터가 올바르지 않거나 처리가 실패한 경우
	 */
	public void saveChangedLog(
			final String itsmId
			, final String tableName
			, final String colNames
			, final int chgWrkDcd
			, final int changeRowSeq
			, IOmmObject beforeOmm
			, IOmmObject afterOmm
			, final String lastChgrId
			, final String lastChgPgmId
			, final String lastChgTrmNo) throws ApplicationException {
		
		logger.debug("원장변경 이력생성 시작(ITSM ID:[{}] / 변경순번:[{}] / 작업구분:[{}])"
				, new Object[]{itsmId, changeRowSeq, WORK_DCD_LIST[chgWrkDcd]});
		
		if(chgWrkDcd == LogUtil.INSERT && afterOmm == null)
			throw new ApplicationException("APCME0044", null, new String[]{"작업구분코드가 INSERT(코드:0)이면 변경후 데이터가 있어야 합니다."});
		
		if(chgWrkDcd == LogUtil.UPDATE && (beforeOmm == null || afterOmm == null))
			throw new ApplicationException("APCME0044", null, new String[]{"작업구분코드가 UPDATE(코드:1)이면 변경전/후 데이터가 모두 있어야 합니다."});
		
		if(chgWrkDcd == LogUtil.DELETE && beforeOmm == null)
			throw new ApplicationException("APCME0044", null, new String[]{"작업구분코드가 DELETE(코드:2)이면 변경전 데이터가 있어야 합니다."});
		
		//UPDATE, DELETE 경우 변경전 데이터를 저장
		/*
		if(chgWrkDcd == LogUtil.UPDATE || chgWrkDcd == LogUtil.DELETE) {
			//변경전 데이터 로깅
			saveChangedLog(itsmId, tableName, colNames, chgWrkDcd, LogUtil.BEFORE, changeRowSeq, beforeOmm, lastChgrId, lastChgPgmId, lastChgTrmNo);
		}
		
		//INSERT, UPDATE 경우 변경후 데이터를 저장
		if(chgWrkDcd == LogUtil.INSERT || chgWrkDcd == LogUtil.UPDATE) {
			//변경후 데이터 로깅
			saveChangedLog(itsmId, tableName, colNames, chgWrkDcd, LogUtil.AFTER, changeRowSeq, afterOmm, lastChgrId, lastChgPgmId, lastChgTrmNo);
		}
		*/

	}
	
	/**
	 * 원장변경전후내역 테이블에 데이터를 로깅
	 * @param itsmId ITSM ID
	 * @param tableName 변경할 대상 테이블명
	 * @param chgWrkDcd 작업구분코드(I:INSERT, U:UPDATE, D:DELETE)
	 * @param chgBfafDcd 변경전후구분코드(B:변경전, A:변경후)
	 * @param changeRowSeq 변경대상의 순번
	 * @param detailSeq 변경데이터 순번
	 * @param content 테이블내용(CSV 형식)
	 * @param changeColumns 변경대상 컬럼명
	 * @param lastChgrId 변경자ID
	 * @param lastChgPgmId 변경프로그램ID
	 * @param lastChgTrmNo 변경처리IP
	 * @return 처리건수
	 */
	private int doLogging(
			final String itsmId
			, final String tableName
			, final int chgWrkDcd
			, final int chgBfafDcd
			, final int changeRowSeq
			, final int detailSeq
			, final String content
			, final String changeColumns
			, final String lastChgrId
			, final String lastChgPgmId
			, final String lastChgTrmNo) {
		
		int loggedCnt = 0;
		
		TBCMETC006Io bLedgerInfo = new TBCMETC006Io();
		bLedgerInfo.setLdgrChgReqItsmRegId(itsmId);
		bLedgerInfo.setLdgrChgCtntInputDtm(DateUtils.getString(System.currentTimeMillis(), "yyyyMMddHHmmssSSSSSS"));
		bLedgerInfo.setLdgrTbEngNm(tableName);
		bLedgerInfo.setChgWrkDcd(this.getWorkCode(chgWrkDcd));
		bLedgerInfo.setChgBfafDcd(this.getBeforeAfterCode(chgBfafDcd));
		bLedgerInfo.setLdgrChgCtntSeq(changeRowSeq);
		bLedgerInfo.setLdgrChgCtntDtlSeq(detailSeq);
		bLedgerInfo.setLdgrChgCtnt(content);
		bLedgerInfo.setLdgrChgColEngNm(changeColumns);
		bLedgerInfo.setDelYn("N");
		bLedgerInfo.setLastChgrId(lastChgrId);
		bLedgerInfo.setLastChgPgmId(lastChgPgmId);
		bLedgerInfo.setLastChgTrmNo(lastChgTrmNo);
		
		loggedCnt = cma903dbio.insertOneTBCMETC006(bLedgerInfo);
		
		return loggedCnt;
	}
	
	/**
	 * 변경작업구분코드를 리턴
	 * @param wrkDcd 변경작업구분코드에 정수값(0 : LedgerLogUtil.INSERT / 1 : LedgerLogUtil.UPDATE / 2 : LedgerLogUtil.DELETE)
	 * @return 변경작업구분코드
	 */
	private String getWorkCode(final int wrkDcd) {
		if(WORK_DCD_LIST.length - 1 >= wrkDcd)
			return WORK_DCD_LIST[wrkDcd];
		return null;
	}
	
	/**
	 * 변경전후구분코드를 리턴
	 * @param bfAfCode 변경전후구분코드에 대한 정수값(0 : LedgerLogUtil.BEFORE / 1 : LedgerLogUtil.AFTER)
	 * @return 변경전후구분코드
	 */
	private String getBeforeAfterCode(final int bfAfCode) {
		if(BEFORE_AFTER_LIST.length - 1 >= bfAfCode)
			return BEFORE_AFTER_LIST[bfAfCode];
		return null;
	}
	
}