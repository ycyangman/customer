package cigna.zz;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import klaf.common.util.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @file         cigna.zz.MaskUtil.java
 * @filetype     java source file
 * @brief        마스크처리관련 Utility class
 * @author       박진성
 * @version      1.0
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박진성                 2016. 3. 28.      신규 작성
 *
 */
public class MaskUtil {
	final static Logger LOGGER = LoggerFactory.getLogger(MaskUtil.class);
	
	/**  마스크 대상건 프로퍼티 파일경로 */
	private static final String MASKING_PROPERTIES_FILE_PATH = "/app/fwk/home/properties/masking.properties";
	
	/** 마스킹 대상건 */
	private static Properties metaMaskingProp = null;
	
	public static void getMaskingProp() {
		
		// 마스크될 대상정보를 조회한다
		FileInputStream fis = null;
		
		if(metaMaskingProp == null) {
			LOGGER.info("마스크정보 프로퍼티 정보 생성 MaskUtil.getMaskingProp");
			
			metaMaskingProp = new Properties();
			
			try {
				fis = new FileInputStream(MASKING_PROPERTIES_FILE_PATH);
				metaMaskingProp.load(fis);
			} catch (FileNotFoundException e) {
				LOGGER.error("FileNotFoundException meta.masking.file error: {}", e);
			} catch (IOException e) {
				LOGGER.error("IOException meta.masking.file error: {}", e);
			} finally {
				if(fis != null)
					try {
						fis.close();
					} catch (IOException e) {
						LOGGER.error("IOException meta.masking.file close error: {}", e);
					}
			}
		}
	}
	
	
	public static String getMaskingValue(String fieldName, String inputString) {
		// 마스크 대상정보 조회
		getMaskingProp();
		
		String returnString = inputString;
		
		if (metaMaskingProp != null) {
			// 필드명으로 Properties에서 조회한다
			String maskTypeCd = (String)metaMaskingProp.get(fieldName);
			
			// Properties에 맞는 항목으로 마스크 타입 설정
			SecuUtil.MaskType maskType = null;
			if (!StringUtils.isEmpty(maskTypeCd)) {
				if ("01".equals(maskTypeCd)) {
					maskType = SecuUtil.MaskType.RRNo;
				} else if ("02".equals(maskTypeCd)) {
					maskType = SecuUtil.MaskType.ActNo;
				} else if ("03".equals(maskTypeCd)) {
					maskType = SecuUtil.MaskType.CardNo;
				} else if ("04".equals(maskTypeCd)) {
					maskType = SecuUtil.MaskType.TelNo;
				} else if ("05".equals(maskTypeCd)) {
					maskType = SecuUtil.MaskType.Address;
				} else if ("06".equals(maskTypeCd)) {
					maskType = SecuUtil.MaskType.EMail;
				} else if ("07".equals(maskTypeCd)) {
					maskType = SecuUtil.MaskType.Name;
				} else if ("08".equals(maskTypeCd)) {
					maskType = SecuUtil.MaskType.TelNo1;
				}
				
				// 마스킹호출
				if (maskType != null) {
					returnString = SecuUtil.getMasking(inputString, maskType);
				}
			}
		}
		
		return returnString;
	}
	
}
