package cigna.zz;


import klaf.inf.EisExecutionException;
import klaf.inf.NotSupportedEISException;
import klaf.inf.innorule.item.InnoRuleOmm;
import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @file         cigna.zz.PfUtil.java
 * @filetype     java source file
 * @brief        PF 처리를 위한 Utility class
 * @author       양윤철
 * @version      1.0
 * @history
 *
 * 버전                성명                   일자                            변경내용
 * ------  ------    ---------       ----------------------------	
 * 1.0       양윤철             2016.03.31.    신규 작성
 *
 */
public class PfUtil {
	
	final static Logger LOGGER = LoggerFactory.getLogger(PfUtil.class);
	

	
	public static final String RULEID_ITEM_ATTR	= "RBA001R";	// RBA001R-표준항목속성서비스
	
	public static final String ALIAS_PRDNM		= "PRDNM";		// 상품명
	
	
	/**
     * <pre>
     * 상품명 조회
     * PfUtil.getPrdnm
     * </pre>
	 * @param prdnm 
     * @param in  : contDt(계약일자), prdcd(상품코드) 
     * @return out : prdnm(상품명) 
     * @throws ApplicationException
     */
	public static String getPrdnm(String contDt, String prdcd) throws ApplicationException {
		LOGGER.debug("###	NBZZ10BEAN	getPrdnm	시작	###");
		
		
		LOGGER.debug("###	contDt	===> {}", contDt);
		LOGGER.debug("###	prdcd	===> {}", prdcd);
		

		/*
		 * 상품명칭
		 */
		String prdnm = null;
		
		
		/*
		 * 입력값 체크
		 */
		if (StringUtils.isEmpty(contDt)) {
	        LOGGER.error("계약일자  입력오류입니다.");
	        throw new ApplicationException("APPRE0000",
											new Object[]{"계약일자"},
											new Object[]{"계약일자"});
		}
		if (StringUtils.isEmpty(prdcd)) {
	        LOGGER.error("상품코드 입력오류입니다."); 
	        throw new ApplicationException("APPRE0000",
											new Object[]{"상품코드"},
											new Object[]{"상품코드"});
		}

		
		/*
		 * 상품명 조회
		 */
		try {
		
			InnoRuleOmm request = new InnoRuleOmm();
			
			String ruleId		= RULEID_ITEM_ATTR;	// 표준항목속성서비스
			String applyDate	= contDt;
	
			
			/*
			 * 조회할 상품코드 Move
			 */
		    request.set("BASE_DT",			applyDate);				// 기준일자
		    request.set("STND_ITEM_ALIAS",	ALIAS_PRDNM); // 상품명
		    request.set("PRDCD",			prdcd);					// 상품코드
		    request.set("INSCD",			"");					// 보험코드		    
		    
		    
		    /*
			 * 룰 호출
			 */
			InnoRuleOmm response = InfUtil.callRule(ruleId,	applyDate, request);
			
			LOGGER.debug("###	NBZZ10BEAN.getPrdnm		{}	호출 E	###", ruleId);
			
			/*
			 * 룰 호출 결과
			 */

			String[] stndItemAlias		= (String[])response.get("STND_ITEM_ALIAS");		// 표준항목별칭
			String[] st1CharVl			= (String[])response.get("ST1_CHAR_VL");			// 제1문자값
			
			/*
			 * 룰 호출 결과 체크
			 */
			if (stndItemAlias == null) {
				return null;
			}
			if (stndItemAlias.length <= 0) {
				return null;
			}
			
			/*
			 * 상품명칭 세팅
			 */
			if (ALIAS_PRDNM.equals(stndItemAlias[0])) {
				prdnm = st1CharVl[0];
			}
			
		} catch (EisExecutionException e) {
			LOGGER.debug("###	EisExecutionException");
			/* KIERE0018  : 상품/규칙 정보 호출 오류가 발생하였습니다. IT 담당자에게 문의하십시요. (오류내용 : {0}) */
			throw new ApplicationException("KIERE0018",
											new Object[]{},
											new Object[]{});
		} catch (NotSupportedEISException e) {
			LOGGER.debug("###	NotSupportedEISException");
			/* KIERE0018  : 상품/규칙 정보 호출 오류가 발생하였습니다. IT 담당자에게 문의하십시요. (오류내용 : {0}) */
			throw new ApplicationException("KIERE0018",
											new Object[]{},
											new Object[]{});
		}		
		
		return prdnm;
	}

}