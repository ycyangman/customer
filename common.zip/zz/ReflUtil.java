package cigna.zz;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;



/**
 * @file         cigna.zz.ReflUtil.java
 * @filetype     java source file
 * @brief        Reflection관련 Utility class
 * @author       박진성
 * @version      1.0
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박진성                 2016. 4. 43.      신규 작성
 *
 */
public class ReflUtil {
	final static Logger LOGGER = LoggerFactory.getLogger(ReflUtil.class);
	
	final static  String GET_STR = "get";
	final static  String SET_STR = "set";
	
	final static String[] getFilter = new String[]{ GET_STR };
	final static String[] setFilter = new String[]{ SET_STR };	

	/**
	 * 선언된 필드명들중 getter, setter메소드가 있는 것들만 조회해온다
	 * 
	 * @param Object srcData 가져올 데이터원본
	 * @param String fieldName 가져올 데이터필드
	 * @return String
	 * @throws ApplicationException
	 */
	public static List<String> getDataFieldNameList(Object srcData) {
		List<String> fieldNameList = new ArrayList<String>();
		
		Class<? extends Object> dataClass = srcData.getClass();
		
		Field[] fields = dataClass.getDeclaredFields();
		
		Method[] methods = dataClass.getMethods();
		
		for (Field field : fields) {
			String fieldName = field.getName();
			
			for (Method method : methods) {
				if (method.getName().equals("get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1))) {
					fieldNameList.add(fieldName);
				}
			}
		}
		
		return fieldNameList;
	}
	
	/**
	 * 입력된 Object에서 입력된 필드의 String값을 가져온다
	 * 필드타입이 다르면 가져오지 못한다
	 * 
	 * @param Object srcData 가져올 데이터원본
	 * @param String fieldName 가져올 데이터필드
	 * @return String
	 * @throws ApplicationException
	 */
	public static String getStringValue(Object srcData, String fieldName) {
		String returnValue = null;
		
		Object doGetterMethod = doGetterMethod(srcData, fieldName);
		
		if (doGetterMethod != null) {
			if (doGetterMethod.getClass().isAssignableFrom(String.class)) {
				returnValue = StringUtils.nvl((String)doGetterMethod);
			}
			else if(doGetterMethod.getClass().isAssignableFrom(Integer.class)) {
				returnValue = String.valueOf((Integer)doGetterMethod);
			}
			else if(doGetterMethod.getClass().isAssignableFrom(BigDecimal.class)) {
				BigDecimal tempBigDecimal = (BigDecimal)doGetterMethod;
				returnValue = tempBigDecimal.toString();
			}
			else {
				LOGGER.debug("[]제공되는 자료형이 아닙니다." + fieldName);
			}
		}
		
		return returnValue;
	}
	
	
	/**
	 * 입력된 Object에서 입력된 필드의 String값을 가져온다
	 * 필드타입이 다르면 가져오지 못한다
	 * 
	 * @param Object srcData 가져올 데이터원본
	 * @param String fieldName 가져올 데이터필드
	 * @return String
	 * @throws ApplicationException
	 */
	public static String getStringValue(Method method, Object target) throws Exception {
		String returnValue = "";
		
		try {
			// 각기 다른 자료형을 String 형태로 변환
			if (method.getReturnType().isAssignableFrom(Integer.class)) {
				returnValue = String.valueOf((Integer)method.invoke(target, new Object[]{}));
			}
			else if (method.getReturnType().isAssignableFrom(Double.class)) {
				returnValue = String.valueOf((Double)method.invoke(target, new Object[]{}));
			} 
			else if (method.getReturnType().isAssignableFrom(BigDecimal.class)) {
				BigDecimal tempBigDecimal = (BigDecimal)method.invoke(target, new Object[]{});
				returnValue = tempBigDecimal.toString();
			} 
			else if (method.getReturnType().isAssignableFrom(Date.class)) {
				Date tempDate = (Date)method.invoke(target, new Object[]{});
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				returnValue = sdf.format(tempDate);
			} 
			else {
				returnValue = StringUtils.nvl((String)method.invoke(target, new Object[]{}));
			}

		} catch (IllegalAccessException e) {
			LOGGER.debug("[IllegalAccessException] occurred");
			throw new Exception(e);
		} catch (IllegalArgumentException e) {
			LOGGER.debug("[IllegalArgumentException] occurred");
			throw new Exception(e);
		} catch (InvocationTargetException e) {
			LOGGER.debug("[InvocationTargetException] occurred");
			throw new InvocationTargetException(e);
		}
			
			return returnValue;
		}	
	
	/**
	 * 입력된 필드의 getter메소드 실행 
	 * 
	 * @param Object srcData 입력할 데이터원본
	 * @param String fieldName 입력할 데이터필드
	 * @return String
	 * @throws ApplicationException
	 */
	public static Object doGetterMethod(Object srcData, String fieldName) {
		Object returnValue = null;
		
		try {
			Method getterMethod = srcData.getClass().getMethod("get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1), new Class[]{});
			returnValue = getterMethod.invoke(srcData, new Object[]{});
		} catch (NoSuchMethodException e) {
			LOGGER.debug("[NoSuchMethodException] getter 메소드 없음 : " + fieldName);
		} catch (IllegalAccessException e) {
			LOGGER.debug("[IllegalAccessException] invoke중 에러");
		} catch (IllegalArgumentException e) {
			LOGGER.debug("[IllegalArgumentException] invoke중 에러");
		} catch (InvocationTargetException e) {
			LOGGER.debug("[InvocationTargetException] invoke중 에러");
		}
		
		return returnValue;
	}
	
	/**
	 * 입력된 Object에서 입력된 필드의 String값을 입력한다
	 * 
	 * @param Object srcData 입력할 데이터원본
	 * @param String fieldName 입력할 데이터필드
	 * @param String paramValue 입력할 데이터값
	 * @throws ApplicationException
	 */
	public static void setStringValue(Object srcData, String fieldName, String paramValue) {
		doSetterMethod(srcData, fieldName, String.class, paramValue);
	}
	
	/**
	 * 입력된 필드의 setter메소드 실행
	 * 
	 * @param Object srcData 입력할 데이터원본
	 * @param String fieldName 입력할 데이터필드
	 * @param Class<? extends Object> paramClassType 입력할 데이터값의 Class
	 * @param Object paramValue 입력할 데이터값
	 * @throws ApplicationException
	 */
	public static void doSetterMethod(Object srcData, String fieldName, Class<? extends Object> paramClassType, Object paramValue) {
		try {
			Method setterMethod = srcData.getClass().getMethod("set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1), new Class[]{paramClassType});
			StringUtils.nvl((String)setterMethod.invoke(srcData, new Object[]{paramClassType.cast(paramValue)}));
		} catch (NoSuchMethodException e) {
			LOGGER.debug("[NoSuchMethodException] setter 메소드 없음 : " + fieldName);
		} catch (IllegalAccessException e) {
			LOGGER.debug("[IllegalAccessException] invoke중 에러");
		} catch (IllegalArgumentException e) {
			LOGGER.debug("[IllegalArgumentException] invoke중 에러");
		} catch (InvocationTargetException e) {
			LOGGER.debug("[InvocationTargetException] invoke중 에러");
		}
	}
	
	public static void setObjData(Object getter, Object setter){
		LOGGER.debug(">>>setData call");
		
		if(getter==null || setter==null){
			return;
		}
		Class<?> getClass = getter.getClass();
		Class<?> setClass = setter.getClass();
		
		Map<String,Method> getMap = getMap(getClass,GET_STR);
		Map<String,Method> setMap = getMap(setClass,SET_STR);
				
		try{
			Iterator<String> it = getMap.keySet().iterator();
			while(it.hasNext()){
				String methodName = it.next();
				Method method = getMap.get(methodName);
				
				Object val = null;
				
				try{
					val =ReflectionUtils.invokeMethod(method, getter);
				}catch(Exception se){
					LOGGER.debug(">>>invoke error");
				}
				
				String setMethdoName = getMethodName(methodName);
				
				if(val!=null){
					Method setMethod = setMap.get(setMethdoName);
					
					if(setMethod!=null){
						try{
							ReflectionUtils.invokeMethod(setMethod, setter, val);
						}catch(Exception se){
							LOGGER.debug(">>>invoke error");
						}
					}
				}
						
			}
		}catch(Exception e){
			LOGGER.debug(">>>에러 발생 방지");
		}
	}	
	
	
	/**
	 * <p> 해당 클래스의 함수목록을 도출 </p>
	 * @param cls  :  대상omm
	 * @param div  :  getter or setter 지정  [get,set]
	 */			
	public static Map<String,Method> getMap(Class<?> cls, String div){
		
		Map<String,Method> map = new HashMap<String,Method>();
		
		Method[] setMethods = cls.getDeclaredMethods();
		Field[] fields = cls.getDeclaredFields();
		
		Map<String,Object> typeMap = new HashMap<String,Object>();
		
		for(Field field : fields){
			typeMap.put(field.getName().toUpperCase(), field.getType());
		}
		
		for(int i=0; i<setMethods.length; i++){
			Method method = setMethods[i];
			
			String methodName = method.getName();
			
			//System.out.println(methodName);
			if(getTargetYn(methodName,div)){
				
				String chkName=methodName.substring(3).toUpperCase();
				
				if(typeMap.containsKey(chkName)){
					//System.out.println(chkName);
					if(GET_STR.equals(div)){
						Class<?> returnType = method.getReturnType();
						
						if(returnType==typeMap.get(chkName)){
							map.put(methodName, method);
						}
					}
					else if(SET_STR.equals(div)){						
						Class<?> returnType = method.getParameterTypes()[0];
						if(returnType==typeMap.get(chkName)){
							map.put(methodName, method);
						}
					}
				}
				
			}
		}
		
		return map;
	}		

	/**
     * <p> 대상함수인지 여부   </p>
     * @param name  :  대상함수명
     * @param div  :  getter or setter 지정  [get,set]
     * @return boolean : 대상여부
    */		
	private static boolean getTargetYn(String name,String div){
		
		if(GET_STR.equals(div)){
			return getTargetYn(getFilter, name);
		}else if(SET_STR.equals(div)){
			return getTargetYn(setFilter, name);
		}
		
		return false;
	}

	
	/**
     * <p> 대상함수인지 여부   </p>
     * @param name  :  대상함수명
     * @param div  :  getter or setter 지정  [get,set]
     * @return boolean : 대상여부
    */		
	private static boolean getTargetYn(String[] filter,String name){
		for(int i=0; i<filter.length; i++){
			if(name.indexOf(filter[i])==0 && name.length()>filter[i].length()) return true;
		}
		
		return false;
	}
	
	/**
     * <p> getter 에 대응되는 setter 반환 </p>
     * @param name  :  대상함수명
     * @return String :  setter 함수명
     */	
	private static String getMethodName(String name){
		
		if(name.indexOf(GET_STR)==0){
			name=name.replaceAll(GET_STR, SET_STR);
		}
		
		return name;
	}
	
	/**
     * <p> IOmm등 Object유형을 JSON형태의 String으로 변환한다 </p>
     * 하위 2레벨까지 트리구조 반환
     * @param srcData  :  소스 Object
     * @return String :  JSON String
     */	
	public static String createJSONString(Object srcData) {
		List<String> fieldNameList = getDataFieldNameList(srcData);
		
		JSONObject jsonObject = doObjectToJSON(srcData);
		
		for (String fieldName : fieldNameList) {
			try {
				Method method = srcData.getClass().getMethod("get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1), new Class[]{});
				
				if (method.getReturnType().isAssignableFrom(Integer.class)) {
					continue;
				} else if (method.getReturnType().isAssignableFrom(Double.class)) {
					continue;
				} else if (method.getReturnType().isAssignableFrom(BigDecimal.class)) {
					continue;
				} else if (method.getReturnType().isAssignableFrom(String.class)) {
					continue;
				} else if (method.getReturnType().isAssignableFrom(List.class)) {
					// 1차 하위리스트 생성
					Object tempObj1 = ReflUtil.doGetterMethod(srcData, fieldName);
					List<? extends Object> lv1List = (List<? extends Object>)tempObj1;
					
					if (lv1List != null) {
						JSONArray lv1JsonArray = new JSONArray();
						jsonObject.put(fieldName, lv1JsonArray);
						
						// 1차 하위 리스트 생성
						for (Object lv1Obj : lv1List) {
							
							/*
							 * 2차 하위 건수 확인하여 생성한다 
							 */
							List<String> lv1FieldNameList = getDataFieldNameList(lv1Obj);
							for (String lv1Name : lv1FieldNameList) {
								Method lv1Method = lv1Obj.getClass().getMethod("get" + lv1Name.substring(0, 1).toUpperCase() + lv1Name.substring(1), new Class[]{});
								
								if (lv1Method.getReturnType().isAssignableFrom(Integer.class)) {
									continue;
								} else if (lv1Method.getReturnType().isAssignableFrom(Double.class)) {
									continue;
								} else if (lv1Method.getReturnType().isAssignableFrom(BigDecimal.class)) {
									continue;
								} else if (lv1Method.getReturnType().isAssignableFrom(String.class)) {
									continue;
								} else if (lv1Method.getReturnType().isAssignableFrom(List.class)) {
									// 2차 하위리스트 생성
									Object tempObj2 = ReflUtil.doGetterMethod(srcData, lv1Name);
									List<? extends Object> lv2List = (List<? extends Object>)tempObj2;
									
									if (lv1List != null) {
										JSONArray lv2JsonArray = new JSONArray();
										jsonObject.put(lv1Name, lv2JsonArray);
										
										for (Object lv2Obj : lv2List) {
											JSONObject lv2Object = doObjectToJSON(lv2Obj);
											lv1JsonArray.put(lv2Object);
										}
									}
								} else {
									// 2차 하위 Object생성
									Object lv2Obj = ReflUtil.doGetterMethod(lv1Obj, fieldName);
									if (lv2Obj != null) {
										JSONObject tmpJsonObject = doObjectToJSON(lv2Obj);
										jsonObject.put(fieldName, tmpJsonObject);
									} else {
										jsonObject.put(fieldName, JSONObject.NULL);
									}
								}
							}
							
							JSONObject lv1Object = doObjectToJSON(lv1Obj);
							lv1JsonArray.put(lv1Object);
						}
					}
				} else {
					// 1차 하위 Object생성
					Object lv1Obj = ReflUtil.doGetterMethod(srcData, fieldName);
					
					if (lv1Obj != null) {
						JSONObject tmpJsonObject = doObjectToJSON(lv1Obj);
						jsonObject.put(fieldName, tmpJsonObject);
					} else {
						jsonObject.put(fieldName, JSONObject.NULL);
					}
				}
				
			} catch (NoSuchMethodException e) {
				LOGGER.debug("[NoSuchMethodException] invoke중 에러 fieldName: " + fieldName);
			} catch (SecurityException e) {
				LOGGER.debug("[SecurityException] invoke중 에러 fieldName: " + fieldName);
			} catch (JSONException e) {
				LOGGER.debug("[JSONException] jsonObject.put 중 에러");
			}
		}
		
		return jsonObject.toString();
	}
	
	/**
	 * <p> IOmm등 Object유형을 JSON형태의 String으로 변환한다 </p>
	 * 하위 2레벨까지 트리구조 반환
	 * @param srcData  :  소스 Object
	 * @return String :  JSON String
	 */	
	public static Object createJsonToOMM(String jsonData, Object objData) throws Exception {
		List<String> fieldNameList = getDataFieldNameList(objData);
		
		JSONObject jsonObject = null;
		
		try{
			jsonObject =  new JSONObject(jsonData);
		}catch(JSONException e){
			LOGGER.debug("[JSONException] : " + e.getMessage());
			throw e;
		}
		
		for (String fieldName : fieldNameList) {
			try {
				String value = jsonObject.getString(fieldName);
				
				setStringValue(objData, fieldName, value);

			} catch (JSONException e) {
				LOGGER.debug("[JSONException setStringValue] : " + e.getMessage());
			}
		}
		
		return objData;
	}

	/**
     * <p> IOmm등 Object유형을 JSONObject로 반환한다 </p>
     * 하위레벨 반환안함
     * @param srcData  :  소스 Object
     * @return JSONObject :  JSONObject로
     */	
	private static JSONObject doObjectToJSON(Object srcData) {
		List<String> fieldNameList = getDataFieldNameList(srcData);
		
		JSONObject jsonObject = new JSONObject();
		
		for (String fieldName : fieldNameList) {
			Object obj = ReflUtil.doGetterMethod(srcData, fieldName);
			
			try {
				if (obj != null) {
					if (obj.getClass().isAssignableFrom(Integer.class)) {
						jsonObject.put(fieldName, (Integer)obj);
					} else if (obj.getClass().isAssignableFrom(Double.class)) {
						jsonObject.put(fieldName, (Double)obj);
					} else if (obj.getClass().isAssignableFrom(BigDecimal.class)) {
						BigDecimal tempBigDecimal = (BigDecimal)obj;
						jsonObject.put(fieldName, tempBigDecimal.longValue());
					} else if (obj.getClass().isAssignableFrom(String.class)) {
						jsonObject.put(fieldName, (String)obj);
					} else if (obj.getClass().isAssignableFrom(List.class)) {
						// 리스트면 Pass
						continue;
					} else {
						// 하위 Object의 인스턴스이면 Pass
						continue;
					}
				} else {
					jsonObject.put(fieldName, JSONObject.NULL);
				}
			} catch (JSONException e) {
				LOGGER.debug("[JSONException] jsonObject.put 중 에러");
			}
		}
		
		return jsonObject;
	}
	
			
}