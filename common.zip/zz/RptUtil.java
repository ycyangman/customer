package cigna.zz;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import klaf.app.ApplicationException;
import klaf.common.util.DateUtils;
import klaf.common.util.StringUtils;
import klaf.container.LApplicationContext;
import klaf.request.ExtendedCignaSystemHeader;
import m2soft.ers.invoker.InvokerException;
import m2soft.ers.invoker.http.ReportingServerInvoker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import SCSL.SLDsFile;
import cigna.cm.a.io.COM_E_DMIBS000000001Io;


/**
 * @file         cigna.zz.RptUtil.java
 * @filetype     java source file
 * @brief        리포트 처리를 위한 Utility class
 * @author       박진성
 * @version      1.0
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박진성                 2016. 3. 28.      신규 작성
 * 0.2           김재모                 2016. 9. 06.      Batch용 안내장 관할 조직코드 리스트 및 메소드 추가
 *
 */
public class RptUtil {
	final static Logger LOGGER = LoggerFactory.getLogger(RptUtil.class);

	/** report 파일경로 */
	private static final String REPORT_FILE_PATH = "/sdata/biz/report/";
	
	public static final String DMI_FILE_PATH = "/dmi_sdata/companion/recv/eai/";
	
	public static final String DMI_BAT_IFID  = "COM_E_DMIBS000000001";
	
	public static final String DMI_BAT_SHELL  = "/dmi_sdata/companion/recv/bin/dmiloader.sh";
	
	public static final String XML_TAG = "<%1s>%1s</%1s>";
	
	public static final String XML_RECORD_HEAD = "<record>";
	
	public static final String XML_RECORD_TAIL = "</record>";
	
	public static final String CS_REPORT_FILE_PATH = "/sdata/biz/CS/batch/";
	
	private final static Hashtable<String, String> DEPT_LIST = new Hashtable<String, String>();
	
	/** Batch용 안내장 관할 조직코드 리스트(각 조직별 정의 완료, 2017-02-02) */
	static {
		/*
		DEPT_LIST.put("CS"	, "100977");
		DEPT_LIST.put("VI"	, "190011");
		DEPT_LIST.put("PA"	, "190009");
		DEPT_LIST.put("DP"	, "100980");
		DEPT_LIST.put("PR"	, "190008"); 
		DEPT_LIST.put("LN"	, "385000");
		DEPT_LIST.put("CM"	, "123456");
		DEPT_LIST.put("CC"	, "190023");
		*/
		DEPT_LIST.put("CS", "100977"); // 고객서비스팀
		DEPT_LIST.put("VI", "100938"); // 특별계정팀
		DEPT_LIST.put("PA", "100977"); // 고객서비스팀
		DEPT_LIST.put("DP", "101115"); // 통합모니터링팀
		DEPT_LIST.put("PR", "100977"); // 고객서비스팀
		DEPT_LIST.put("CC", "100977"); // 고객서비스팀
		DEPT_LIST.put("NB", "101113"); // 업무표준화팀
		DEPT_LIST.put("SL", "100903"); // 영업운영팀
		DEPT_LIST.put("AI", "101116"); // 심사운영팀
	}
	
	/**
	 * Batch용 안내장 관할 조직코드
	 * (안내장 모듈 호출시(Batch) 처리영업소에 세팅을 위해서 필요함)
	 * 
	 * @return 배치관할 조직코드
	 */
	public static String getBatchDeptCd() {
		
		ExtendedCignaSystemHeader header = (ExtendedCignaSystemHeader)LApplicationContext.getCurrentApplicationHeader();
		
		String job				= FwUtil.getPgmId();  // Batch의 UserID는 Job ID이므로
		
		String deptCd		= "";
		String deptCd2	= "";
	
		if( null != job && job.length() >= 3 )	{
			
			deptCd		= job.substring(1, 3);
			deptCd2	= DEPT_LIST.get(deptCd);
			// DEPT_LIST에 존재하지 않은 경우 고객서비스팀
			if( deptCd2 == null ) {
				deptCd2 = "100977";
			}
			
		}
		
		return deptCd2;
		
	}
	
	/**
	 * DRM REPORT 파일을 만든다
	 * 
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataList 출력될 데이터리스트
	 * @throws ApplicationException
	 */
	public static String createDrmReport(String reportReqInfo, List<? extends Object>[] sourceDataListArr) throws ApplicationException {
		String fileName = createReport(reportReqInfo, sourceDataListArr);
		
		String drmFileName = fileName.replace(".pdf", "_drm.pdf");

		SLDsFile sFile = new SLDsFile();
		sFile.SettingPathForProperty("/app/softcamp/02_Module/02_ServiceLinker/softcamp.properties"); 
		
		sFile.SLDsInitGrade();
		int dSSLDocuGradeEncAddCreator = sFile.DSSLDocuGradeEncAddCreator ( "/app/softcamp/04_KeyFile/keyGrade_SVR0.sc", 
		"System",  "none", "0000003", //Grade ID
		"SECURITYDOMAIN", "SECURITYDOMAIN;", "none", fileName, drmFileName, "SECURITYDOMAIN", "SECURITYDOMAIN;", 	"/app/softcamp/04_KeyFile/keyDAC_SVR0.sc", 0, 0 );
		LOGGER.debug( "DSSLDocuGradeEncAddCreator [" + dSSLDocuGradeEncAddCreator  + "]");
		
		// 암호화 이전 원본파일은 삭제한다
		File file = new File(fileName);
		if(file.exists() && !file.isDirectory()) {
			try {
				file.delete();
			} catch (Exception e) {
				LOGGER.error("{} 파일삭제오류: {}", new Object[] {fileName, e});
				throw new ApplicationException("APCME0032", new Object[] {fileName});
			}
		}
		
		return drmFileName;
	}
	
	/**
	 * REPORT 파일을 만든다
	 * 
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String createReport(String reportReqInfo, List<? extends Object>[] sourceDataListArr) throws ApplicationException {
		String response = "";
		String reportingtUrl = System.getProperty("reporting.url", "http://localhost:10080");  // Default url
		ReportingServerInvoker invoker = new ReportingServerInvoker(reportingtUrl+"/ReportingServer/service");  //Server System Property 사용
		
		invoker.setCharacterEncoding("utf-8");   //캐릭터셋  데이터에 맞게 수정 필요
		invoker.setReconnectionCount(3);           //재접속 시도 회수
		invoker.setConnectTimeout(5);               //커넥션 타임아웃
		invoker.setReadTimeout(1800);                 //송수신 타임아웃
		
		StringBuffer mrdPath = new StringBuffer();
		//StringBuffer mrdParam = new StringBuffer();
		//StringBuffer mrdData = new StringBuffer();
		
		invoker.addParameter("opcode", "500");
		invoker.addParameter("export_type", "pdf");
		invoker.addParameter("protocol", "sync");
		
		if (StringUtils.isEmpty(reportReqInfo) || reportReqInfo.split("\\|").length < 3) {
			// {0} 필수 입력 사항 입니다.
			throw new ApplicationException( "APCME0009", new Object[]{"레포트 요청정보는"}, new Object[]{"레포트 요청정보는"});
		}
		
		LOGGER.debug("reportReqInfo : " + reportReqInfo);
		String[] reportReqInfoArr = reportReqInfo.split("\\|");
		
		// 파일경로
		mrdPath.append(reportReqInfoArr[0]);
		
		// 파일명은 yyyyMMddHHmmss001.xls 형태로 생성된다
		String date = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		String time = DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE);
		
		String fileName = date + time + "001.pdf";
		
		String rdXml = "";
		try {
			rdXml = toRptXml(reportReqInfo, sourceDataListArr);
			
			//LOGGER.debug(" toRptXml : " + rdXml);
			
		} catch (Exception e) {

			LOGGER.error("toXml : " + e.toString());
			
		}
		
		invoker.addParameter("mrd_path",  mrdPath.toString());   //mrd파일의 경로
		invoker.addParameter("mrd_param", "");  //파라미터
		invoker.addParameter("mrd_data",  rdXml);   //xml데이터 
		invoker.addParameter("export_name", fileName); // pdf파일명
		
		try {
			
			response = invoker.invoke();   //요청전송 응답받기 1or0 | pdf파일의 경로 or 오류 메시지( 성공인경우 1, 실패일 경우 0)
		
		} catch (InvokerException e) {

			LOGGER.error("createReport : " + e.toString());
			throw new ApplicationException( "APCME0005", null, new Object[]{ "IOException", "IOException" });
		
		}
		
		LOGGER.debug(" response :  " + response);
		
		return REPORT_FILE_PATH + fileName;
	}


	/**
	 * 레포트서버로 보낼 XML을 작성한다
	 * 
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String toRptXml(String reportReqInfo, List<? extends Object>[] sourceDataListArr) throws Exception {

		StringBuffer buff = new StringBuffer();
		
		LOGGER.debug("reportReqInfo : " + reportReqInfo);
		String[] reportReqInfoArr = reportReqInfo.split("\\|");
		
		// 데이터셋 배열
		String[] datasetInfoArr = reportReqInfoArr[1].split(",");
		// 파라메터정보 XML
		String paramXML = reportReqInfoArr[2];
		
		// 화면에서보낸 dataset 개수와 서비스에서 보낸 실제데이터 개수를 비교한다
		if (datasetInfoArr.length > sourceDataListArr.length) {
			throw new ApplicationException( "APCME0009", new Object[]{"레포트 요청 데이터셋이 실제 데이터보다 많습니다 실제 데이터는"}, new Object[]{"레포트 요청 데이터셋이 실제 데이터보다 많습니다 실제 데이터는"});
		}
		
		buff.append("<?xml version='1.0' encoding='utf-8'?> \n");
		buff.append("<root> \n ");
		
		// 데이터셋 정보 XML생성
		for (int i=0; i<datasetInfoArr.length; i++) {
			
			buff.append("<").append(datasetInfoArr[i]).append(">");
			
			// 데이터셋을 데이터셋 정보와 기존소스가 순서와 짝이 맞아야 한다
			List<? extends Object> sourceDataList = sourceDataListArr[i];
			
			for(Object srcDataObject : sourceDataList) {
				
				buff.append("<record>");
				
				buff.append(getRptElementsXml(srcDataObject));
				
				buff.append("</record>");
			}
	
			//LOGGER.debug("buff.toString() :"+ buff.toString());
			
			buff.append("</").append(datasetInfoArr[i]).append(">");
		}
		
		buff.append(paramXML);
		buff.append("</root>");

		return buff.toString();
	}

	/**
	 * 레포트서버로 보낼 XML을 작성한다
	 * 
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String toRptBatchData(COM_E_DMIBS000000001Io prtHeader, String[] dsId,  Object[] sourceDataArr) throws ApplicationException {
		
		makeBatHeader(prtHeader);
		
		String xmlData = toRptXml(dsId,  sourceDataArr);
		
		String rptData = makeDelimHeader(prtHeader) + xmlData;
		
		LOGGER.debug("xmlData :"+ rptData);
		
		return rptData;
		
	}
	
	/**
	 * 레포트서버로 보낼 XML을 작성한다
	 * 
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String toRptBatchData(COM_E_DMIBS000000001Io prtHeader, Object sourceData) throws ApplicationException {
		
		makeBatHeader(prtHeader);

		String rptData = makeDelimHeader(prtHeader) + makeDelimBody(sourceData);
		
		LOGGER.debug("batData :"+ rptData);
		
		return rptData;
		
	}
	
	/**
	 * 레포트서버로 보낼 XML을 작성한다
	 * 
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String toRptBatchData(COM_E_DMIBS000000001Io prtHeader, Object sourceData, String gb) throws ApplicationException {
		
		makeBatHeader(prtHeader);

		String rptData = makeDelimHeader(prtHeader) + makeDelimBody(sourceData, gb);
		
		LOGGER.debug("batData :"+ rptData);
		
		return rptData;
		
	}
	
	/**
	 * 레포트서버로 보낼 XML을 작성한다
	 * 
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String toRptBatchData(COM_E_DMIBS000000001Io prtHeader, String xmlData) throws ApplicationException {
		
		makeBatHeader(prtHeader);
		
		String rptData = makeDelimHeader(prtHeader) + xmlData;
		
		LOGGER.debug("xmlData :"+ rptData);
		
		return rptData;
		
	}
	
	/**
	 * 레포트서버로 보낼 XML을 작성한다
	 * 
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String toRptXml(String[] dsId,  Object[] sourceDataArr) throws ApplicationException {
	
		if(dsId == null || dsId.length == 0
				|| sourceDataArr == null || sourceDataArr.length == 0) {
			return "<root></root>";
		}
		
		StringBuffer buff = new StringBuffer();

		buff.append("<root>");
		// 데이터셋 정보 XML생성
		for (int i=0; i<sourceDataArr.length; i++) {

			buff.append(getRptSubXml(dsId[i], sourceDataArr[i]));
			
		}
		
		buff.append("</root>");

		//LOGGER.debug("[XML] :"+ buff.toString());

		return buff.toString();
	}
	
	/**
	 * 레포트서버로 보낼 XML을 작성한다
	 * 데이터셋 영역작업
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String getRptSubXml(String dsId,  Object srcDataObject) throws ApplicationException {
	
		
		StringBuffer buff = new StringBuffer();
		
		// 데이터셋 정보 XML생성
		
		if(!StringUtils.isEmpty(dsId)) {
			buff.append("<").append(dsId).append(">");
		}

		if (srcDataObject.getClass().isAssignableFrom(java.util.ArrayList.class)) { // 
			for (Object arrData : (ArrayList<?>)srcDataObject) {
				
				buff.append("<record>");
				
				buff.append(getRptElementsXml(arrData));
				
				buff.append("</record>");
			}
		} 
		else  { 
			buff.append("<record>");
			
			buff.append(getRptElementsXml(srcDataObject));			
			
			buff.append("</record>");

		} //end if
		
		if(!StringUtils.isEmpty(dsId)) {
			buff.append("</").append(dsId).append(">");
		}
			
		//LOGGER.debug("[XML] :"+ buff.toString());

		return buff.toString();
	}
	
	/**
	 * 레포트서버로 보낼 XML을 작성한다
	 * 데이터셋 영역작업
	 * @param reportReqInfo 레포트요청정보
	 * @param sourceDataListArr 출력될 데이터리스트 배열
	 * @throws ApplicationException
	 */
	public static String getRptElementsXml(Object srcDataObject) throws ApplicationException {
		
		StringBuffer buff = new StringBuffer();
		
		List<String> dataFieldNameList = ReflUtil.getDataFieldNameList(srcDataObject);
		
		for (String fieldName : dataFieldNameList) {
			try {
				// 조회된 데이터셋 원본의 get매소드가 존재하는 필드명으로 invoke 시킨다
				Method method = srcDataObject.getClass().getMethod("get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1), new Class[]{});

				String value = ReflUtil.getStringValue(method, srcDataObject);
				
				if (StringUtils.isEmpty(value)) {
					value = "";
				}
				value = value.replaceAll("&nbsp;", " ");
				value = value.replaceAll("\n", "\\\\n").replaceAll("\r", "\\\\r");
				
				value = escapeXML(value);
				
				//LOGGER.debug("name/value :"+ fieldName +"/"+value);
				
				buff.append("<").append(fieldName).append(">");
				buff.append(value);
				buff.append("</").append(fieldName).append(">");
				
			} catch (Exception e) {
				LOGGER.debug("[toRptXml]  : " + fieldName);
				throw new ApplicationException( "KIERE0005", null, new Object[]{ "Method invoke중 에러" }, e );
			} 
		} //end for		
		
		return buff.toString();
	}
	
	/**
	 * 안내잘 발송 Header 정보 set
	 * @param 
	 * @return 
	 * @throws ApplicationException	 * 
	 */	
	private static void makeBatHeader(COM_E_DMIBS000000001Io req) throws ApplicationException {
		
		if(req == null) {
			throw new ApplicationException( "APCME0009", new Object[]{"데이터셋이 null"});
		}
		
		//서식구분코드가 1자리면 2자리로 늘린다
		if ("0".equals(req.getFormtDcd())) {
			req.setFormtDcd("00");
		} else if ("1".equals(req.getFormtDcd())) {
			req.setFormtDcd("01");
		}
		
		if( StringUtils.isEmpty(req.getReqSysId      ())) req.setReqSysId      ("");  //요청시스템ID
		//서식구분코드 :: 00: 일반낱장(Default), 01: 흑백낱장, 02: 상품안내책자,  03: 상품안내낱장, 04: 대봉투칼라단면, 05: 대봉투흑백단면 06: 지로안내
		if( StringUtils.isEmpty(req.getFormtDcd      ())) req.setFormtDcd      ("00");
		
		//안내장 시스템에서 관리하는 종합 안내장 서식 코드 (종합서식일 경우 필수)
		if( "01".equals(req.getFormtDcd()) && StringUtils.isEmpty(req.getNotclId  ())) {
			throw new ApplicationException( "APCME0005", new Object[]{ "서식코드[notclId]" } );
		}
		
		if( StringUtils.isEmpty(req.getVerNo         ())) req.setVerNo         ("");  //안내장버젼
		if( StringUtils.isEmpty(req.getNotclNm       ())) req.setNotclNm       ("");  //안내장명
		
		//문서코드(단일서식일 경우 필수)
		if( "00".equals(req.getFormtDcd()) && StringUtils.isEmpty(req.getDocCd())) {
			throw new ApplicationException( "APCME0005", new Object[]{ "문서서식코드[docCd]" } );
		}
		
		/** 처리조직번호
		 *    1. 온라인인 경우 로그인사번의 조직번호 세팅
		 *    2. 배치인 경우 업무별 정의된 조직번호 세팅
		**/
		if( FwUtil.isBatch() )	{
			// TODO 심사 승낙 문자 발송 배치시 심사운영팀(101116)
			if( "BNBUD05B".equals(FwUtil.getUserId()) ||
				 "BNBUD06B".equals(FwUtil.getUserId()) )	{
				req.setIsueOrgNo("101116");
			}else	{
				req.setIsueOrgNo(RptUtil.getBatchDeptCd());
			}
		}else	{
			req.setIsueOrgNo(FwUtil.getDeptCd());
		}
		
		LOGGER.debug("setting req 처리조직번호 : {}", req.getIsueEno());
		
		//처리자 사원번호(온라인인 로그인사번, 배치인 경우 Job ID)
		if( StringUtils.isEmpty(req.getIsueEno()) )	{
			req.setIsueEno(FwUtil.getUserId());
		}
		
		/** TODO 배치전문에 추가되면 넣을 것! (배치에서는 안내장에서 발송휴대폰번호를 받을 수 없는 구조이므로 사용 불가!!!)
		// SMS, LMS 발송시 휴대전화전화 필수 체크
		if( ("08".equals(req.getNotclSndMedcd()) || "09".equals(req.getNotclSndMedcd()) ) )	{
			// 발신자 휴대전화가 없는 경우  라이나콜센터 번호로 default Setting(1588-0058)
			if( StringUtils.isEmpty(req.getRespTelsno()) && StringUtils.isEmpty(req.getRespTelino()) )		{
				req.setRespTeldno		("");
				req.setRespTelsno		("1588");
				req.setRespTelino		("0058");
			}
		}
		*/
		
		// 수신자 고객번호(고객번호가 넘어오지 않는 경우 default 값 세팅 : 고객파트 요청)
		if( StringUtils.isEmpty(req.getReceCustNo()) ) {
			req.setReceCustNo("000000000");
		}
		
		if( StringUtils.isEmpty(req.getDocId         ())) req.setDocId         ("");  //문서ID_요청 시스템의 문서 UNIQUE ID(증권번호 or 접수번호)-생략가능
		if( StringUtils.isEmpty(req.getCtryCd        ())) req.setCtryCd        ("KR");  //국가코드
		if( StringUtils.isEmpty(req.getExpDt         ())) req.setExpDt         ("");  //예정일자
		if( StringUtils.isEmpty(req.getExpTi         ())) req.setExpTi         ("");  //예정시각
		if( StringUtils.isEmpty(req.getInspYn        ())) req.setInspYn        ("0");  //검사여부
		if( StringUtils.isEmpty(req.getDocInqYn      ())) req.setDocInqYn      ("1");  //문서조회여부(0:미조회, 1:조회(DEFAULT)
		if( StringUtils.isEmpty(req.getDocStrgPrd    ())) req.setDocStrgPrd    ("0");  //문서보관기간
		
		//--------------------------------------------------------------------------------------------
		//01:창구,02:EMAIL,03:FAX,04:일반우편,05:등기,06:방문전달,07:음성안내,08:SMS,09:LMS,10:콜센터,11:비정기,12:재발행
		if( StringUtils.isEmpty(req.getNotclSndMedcd ())) req.setNotclSndMedcd ("");  //안내장발송매체코드
		
		if( StringUtils.isEmpty(req.getReceCustNm    ())) req.setReceCustNm    ("");  //수신자-고객명
		
		if( StringUtils.isEmpty(req.getReceZip       ())) req.setReceZip       ("");  //수신우편번호
		if( StringUtils.isEmpty(req.getReceZipAddr   ())) req.setReceZipAddr   ("");  //우편번호주소
		if( StringUtils.isEmpty(req.getReceEtcAddr   ())) req.setReceEtcAddr   ("");  //수신기타주소
		if( StringUtils.isEmpty(req.getReceEmailId   ())) req.setReceEmailId   ("");  //이메일ID
		
	    if( StringUtils.isEmpty(req.getAtchFilePswd()))      req.setAtchFilePswd   ("");      //첨부파일비밀번호
        if( StringUtils.isEmpty(req.getEtcReceZip()))        req.setEtcReceZip     ("");      //기타수신우편번호
        if( StringUtils.isEmpty(req.getEtcReceZipAddr()))    req.setEtcReceZipAddr ("");      //기타우편번호주소
        if( StringUtils.isEmpty(req.getEtcReceEtcAddr()))    req.setEtcReceEtcAddr ("");      //기타수신기타주소
		if( StringUtils.isEmpty(req.getProvsLst()))          req.setProvsLst       ("");      //약관목록
		if( StringUtils.isEmpty(req.getSecuEmailYn()))       req.setSecuEmailYn    ("Y");     //보안이메일여부
		
		// 암호화가 필요한 필드에 암호화모듈 적용
		try	{
			if( !StringUtils.isEmpty(req.getReceEtcAddr()) )	{
				req.setReceEtcAddr(SecuUtil.getEncValue(req.getReceEtcAddr(), SecuUtil.EncType.Addr));						//수신기타주소
			}
		}catch(Exception e)	{
			req.setReceEtcAddr(req.getReceEtcAddr());					//수신기타주소
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getReceMphonTelino()) )	{
				req.setReceMphonTelino(SecuUtil.getEncValue(req.getReceMphonTelino(), SecuUtil.EncType.Contact));		//휴대전화전화개별번호
			}
		}catch(Exception e)	{
			req.setReceMphonTelino(req.getReceMphonTelino());			//휴대전화전화개별번호
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getReceFaxino()) )	{
				req.setReceFaxino(SecuUtil.getEncValue(req.getReceFaxino(), SecuUtil.EncType.Contact));					//수신자-팩스개별번호
			}
		}catch(Exception e)	{
			req.setReceFaxino(req.getReceFaxino());						//수신자-팩스개별번호
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getReceEmailId()) )	{
				req.setReceEmailId(SecuUtil.getEncValue(req.getReceEmailId(), SecuUtil.EncType.Email));						//이메일ID
			}
		}catch(Exception e)	{
			req.setReceEmailId(req.getReceEmailId());						//이메일ID
		}
		
		try	{
			if( !StringUtils.isEmpty(req.getEtcReceEtcAddr()) )	{
				req.setEtcReceEtcAddr(SecuUtil.getEncValue(req.getEtcReceEtcAddr(), SecuUtil.EncType.Addr));						//이메일ID
			}
		}catch(Exception e)	{
			req.setEtcReceEtcAddr(req.getEtcReceEtcAddr());						//안내장발행기타주소
		}
		
		LOGGER.debug("setting req data : {}", req);
		
	}

	/**
	 * 안내장 발송 Header Pipe Delimeter구분 생성
	 * @param COM_E_DMIBS000000001Io
	 * @return String
	 * @throws ApplicationException	 * 
	 */	
	private static String makeDelimHeader(COM_E_DMIBS000000001Io prtHeader)  {
		
		StringBuffer rptStrBf = new StringBuffer();
		
		List<String> dataFieldNameList = ReflUtil.getDataFieldNameList(prtHeader);
		
		for (String fieldName : dataFieldNameList) {
			String value = ReflUtil.getStringValue(prtHeader, fieldName);
			if(value == null) value = "";			
			rptStrBf.append(value);
			rptStrBf.append("|");
		}
		
		return rptStrBf.toString();
		
	}
	
	/**
	 * 안내잘 발송  Body Pipe Delimeter구분 생성
	 * @param Object
	 * @return String
	 * @throws ApplicationException	 * 
	 */	
	private static String makeDelimBody(Object bodyData)  {
		
		StringBuffer rptStrBf = new StringBuffer();
		
		List<String> dataFieldNameList = ReflUtil.getDataFieldNameList(bodyData);
		
		int idx = 0;
		for (String fieldName : dataFieldNameList) {
			idx++;
			
			String value = ReflUtil.getStringValue(bodyData, fieldName);
			if(value == null) value = "";			
			rptStrBf.append(value);
			
			if(idx < dataFieldNameList.size()) {
				rptStrBf.append("|");
			}
			
		}
		
		return rptStrBf.toString();
		
	}
	
	
	/**
	 * 안내잘 발송  Body Pipe Delimeter구분 생성
	 * @param Object
	 * @return String
	 * @throws ApplicationException	 * 
	 */	
	private static String makeDelimBody(Object bodyData, String gb)  {
		
		StringBuffer rptStrBf = new StringBuffer();
		
		List<String> dataFieldNameList = ReflUtil.getDataFieldNameList(bodyData);
		
		int idx = 0;
		for (String fieldName : dataFieldNameList) {
			idx++;
			
			String value = ReflUtil.getStringValue(bodyData, fieldName);
			if(value == null) value = "";			
			rptStrBf.append(value);
			
			if(idx < dataFieldNameList.size()) {
				rptStrBf.append(gb);
			}
			
		}
		
		return rptStrBf.toString();
		
	}	
	
	
	/**
	 * List를 XML Tag 데이터로 변환 - 데이터셋ID, record tag 포함
	 * @param xmlString
	 * @param mapData
	 * @throws IOException 
	 */
		
	public static String getRecordListXmlString(String dsId, List<Map<String,String>> list) {

		String xmlValue = "";
		for ( Map<String,String> mapData : list) {
			xmlValue += getRecordMapXmlString(mapData);			
		}
		
		return String.format( XML_TAG, dsId, xmlValue, dsId); 
		
	}
	
	/**
	 * List를 XML Tag 데이터로 변환 - record tag 포함
	 * @param xmlString
	 * @param mapData
	 * @throws IOException 
	 */
		
	public static String getRecordListXmlString(List<Map<String,String>> list) {

		String xmlValue = "";
		for ( Map<String,String> mapData : list) {
			xmlValue += getRecordMapXmlString(mapData);			
		}
		return xmlValue;
	}
	
	
	/**
	 * Map을 XML Tag 데이터로 변환 - 데이터셋ID, record tag 포함
	 * @param xmlString
	 * @param mapData
	 * @throws IOException 
	 */
	
	public static String getRootMapXmlString(String dsId, Map<String,String> mapData)  {
		
		return "<root>"+String.format( XML_TAG, dsId, getRecordMapXmlString(mapData), dsId) + "</root>"; 
		
	}
	
	/**
	 * Map을 XML Tag 데이터로 변환 - root tag 포함, 데이터셋ID/record tag 미포함
	 * 일반적으로 SMS 이메일 가변처리용을 사용
	 * @param xmlString
	 * @param mapData
	 * @throws IOException 
	 */	
	public static String getRootMapXmlString(Map<String,String> mapData)  {
		String rootTag = "root";
		
		return String.format( XML_TAG, rootTag, getRecordMapXmlString(mapData), rootTag); 
		
	}	
	
	/**
	 * Map을 XML Tag 데이터로 변환 - 데이터셋ID, record tag 포함
	 * @param xmlString
	 * @param mapData
	 * @throws IOException 
	 */
	
	public static String getRecordMapXmlString(String dsId, Map<String,String> mapData)  {
		
		return String.format( XML_TAG, dsId, getRecordMapXmlString(mapData), dsId); 
		
	}

	
	/**
	 * Map을 XML Tag 데이터로 변환 - record tag 포함
	 * @param xmlString
	 * @param mapData
	 * @throws IOException 
	 */
	
	public static String getRecordMapXmlString(Map<String,String> mapData)  {
		
		return XML_RECORD_HEAD + getMapXmlString(mapData) + XML_RECORD_TAIL;
		
	}
	
	/**
	 * Map을 XML Tag 데이터로 변환 
	 * @param xmlString
	 * @param mapData
	 * @throws IOException 
	 */
	
	public static String getMapXmlString(Map<String,String> mapData)  {
		String xmlTags = "";
		Object[] dataKeys = mapData.keySet().toArray();
		for(Object key : dataKeys){
			xmlTags += String.format( XML_TAG, key, xmlDataValue( mapData.get(key) ), key ) ;
		}
		
		return xmlTags;
		
	}	
	
	public static String xmlDataValue(Object data) {
		if( data == null)
			return "";		
		else if(data instanceof String)
			return escapeXML((String)data);
			//return "<![CDATA["+(String)data+"]]>";
		else
			return escapeXML(data.toString());
	}	
	
	/**
	 * Escape XML
	 * @param value
	 * @return
	 */
	public static String escapeXML(String value) {
		String data = "";
		if( value == null ) return data;
		
		if(value.indexOf("<![CDATA") >= 0) {
			return value;
		}
		
		data = value.replaceAll("&", "&amp;");
		data = data.replaceAll("<", "&lt;");
		data = data.replaceAll(">", "&gt;");
		data = data.replaceAll("\"", "&quot;");
		
		return data;
	}
	
	/**
	 * XML 태그의 값을 바꿈
	 * @param xmlStr
	 * @param tagName
	 * @param replaceValue
	 * @return
	 */
	public static String replaceXmlValue(String xmlStr, String tagName, String replaceValue) {
		String regex = "<"+tagName+">.*</"+tagName+">";
		String replacement = "<"+tagName+">"+replaceValue+"</"+tagName+">";
		String returnXml = xmlStr.replaceAll(regex, replacement);
		
		return returnXml;
	}
	
	/**
     * 안내장용 주민번호 마스킹타입적용 000000-0******
     * @param in  :  String
     * @return out : String
     * @throws ApplicationException
     */
	public static String getNotcMaskRrno(String rrno) {
		String returnRrno = rrno;
		
		if (!StringUtils.isEmpty(returnRrno) && returnRrno.length() >= 13) {
			returnRrno.replaceAll("-", "");
			returnRrno = returnRrno.substring(0,6) + "-" + returnRrno.substring(6,7) + "******";
		}
		
		return returnRrno;
	}
			
}