package cigna.zz;

import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.penta.scpdb.ScpDbAgent;


/**
 * @file         cigna.zz.SecuUtil.java
 * @filetype     java source file
 * @brief        개인정보 마스킹 및 DB암호화를 수행하는 공통 API 클래스<br>
 * <pre>
 * 본 클래스를 사용하기 위해서는 다음에 나오는 내용을 준수
 * 1. Mask관련 함수는 화면에 표시되는 개인정보를 '*'로 변환하며 출력하기 위한 함수
 * 2. Enc관련 함수는 암호화된 값을 DB에 저장
 * 3. Dec관련 함수는 복호화된 값을 DB에 저장
 * </pre>
 * @author       jixkim
 * @version      0.1
 * @history
 *
 *
 */
@KlafBean
public class SecuSAPUtil {
	final static Logger logger = LoggerFactory.getLogger(SecuSAPUtil.class);
	
	/** 
	 * CHARSET을 지정하지 않으면 UTF-8로 지정 
	 */
	private static final String DEFAULT_CHARSET = "UTF-8";
	
	/** 
	 * DAMO SCP API
	 */
	private final static String INI_FILE_PATH = "ini.filePath";
	
	private static ScpDbAgent agt = new ScpDbAgent();
	
	/** 
	 * DB암호화 대상 
	 * Jumin = 주민번호
	 * Accnt = 계좌번호
	 * Card = 카드번호
	 * Contact = 전화번호
	 * Addr = 주소
	 * Email = 이메일
	 * Salary = 연봉
	 * Etc = 로그 등 기타 정보
	 */
	public static enum EncSAPType {
		Jumin("JUMIN_SEP"),
		Accnt("ACCNT_SEP"),
		Card("CARD_SEP"),
		Contact("CONTACT_SEP"),
		Addr("ADDR_SEP"),
		Email("EMAIL_SEP"),
		Salary("SALARY_SEP"),
		Dise("DISE_SEP"),
		Etc("ETC_SEP"),
		
		// 실제컬럼형태
		emailId("EMAIL_SEP"),
		notclIsueEmailId("EMAIL_SEP"),
		tmpSecuCardRdnumVl("CARD_SEP"),
		secuCardRdnumVl("CARD_SEP"),
		sndInfoVl("CARD_SEP"),
		afchCtnt("ETC_SEP"),
		bfchCtnt("ETC_SEP"),
		icpsPswd("PWD_SEP"),
		kidiUsrPswd("PWD_SEP"),
		kliaUsrPswd("PWD_SEP"),
		curPswd("PWD_SEP"),
		bfusePswd("PWD_SEP"),
		pswd("PWD_SEP"),
		dofTelno("CONTACT_SEP"),
		undwrOrgTelno("CONTACT_SEP"),
		regDofTelno("CONTACT_SEP"),
		repFaxTelno("CONTACT_SEP"),
		repTelno("CONTACT_SEP"),
		cnslrTelno("CONTACT_SEP"),
		custTmpTelno("CONTACT_SEP"),
		rsvtTelno("CONTACT_SEP"),
		telno("CONTACT_SEP"),
		tmpTelno("CONTACT_SEP"),
		expsrCustTelno("CONTACT_SEP"),
		appltTelno("CONTACT_SEP"),
		chrgEmplReceMpno("CONTACT_SEP"),
		appltMpno("CONTACT_SEP"),
		membMpno("CONTACT_SEP"),
		afchContrMpno("CONTACT_SEP"),
		bfchContrTelno("CONTACT_SEP"),
		bfchContrMpno("CONTACT_SEP"),
		expsrCustMpno("CONTACT_SEP"),
		payAppltTelno("CONTACT_SEP"),
		indNagrinfCustTelno("CONTACT_SEP"),
		benfcTelno("CONTACT_SEP"),
		smsTrmsTelno("CONTACT_SEP"),
		smsRplyTelno("CONTACT_SEP"),
		appltOwnhTelno("CONTACT_SEP"),
		chrgEmplSndmsMpno("CONTACT_SEP"),
		afchContrTelno("CONTACT_SEP"),
		custTelno("CONTACT_SEP"),
		ownhTelno("CONTACT_SEP"),
		mphonTelno("CONTACT_SEP"),
		contrMpno("CONTACT_SEP"),
		heirMpno("CONTACT_SEP"),
		sndTelno("CONTACT_SEP"),
		clmpTelno("CONTACT_SEP"),
		chrgpTelno("CONTACT_SEP"),
		crdtTelno("CONTACT_SEP"),
		wkplTelno("CONTACT_E"),
		dncallEmailTelno("CONTACT_SEP"),
		sndEmplEmailTelno("CONTACT_SEP"),
		receCustEmailMpno("CONTACT_SEP"),
		pblInstChrgpTelno("CONTACT_SEP"),
		notclWrtpTelno("CONTACT_SEP"),
		notclWrtpFaxTelno("CONTACT_SEP"),
		undwrInlnTelno("CONTACT_SEP"),
		hospEtcAddr("ADDR_SEP"),
		intvwLoctnAddr("ADDR_SEP"),
		receEtcAddr("ADDR_SEP"),
		clmnDofEtcAddr("ADDR_SEP"),
		orgEngAddr("ADDR_SEP"),
		prvPlwBzarLoctnAddr("ADDR_SEP"),
		ptncoCentrAddr("ADDR_SEP"),
		orgEtcAddr("ADDR_SEP"),
		coopCmpyEtcAddr("ADDR_SEP"),
		bcfDofAddr("ADDR_SEP"),
		bkCentrEtcAddr("ADDR_SEP"),
		gpEtcAddr("ADDR_SEP"),
		offcEtcAddr("ADDR_SEP"),
		etcAddr("ADDR_SEP"),
		ctlpEngAddr("ADDR_SEP"),
		wkplEtcAddr("ADDR_SEP"),
		appltEtcAddr("ADDR_SEP"),
		bfchContrEtcAddr("ADDR_SEP"),
		crdtAddr("ADDR_SEP"),
		rsdplEtcAddr("ADDR_SEP"),
		afchContrEtcAddr("ADDR_SEP"),
		custEngAddr("ADDR_SEP"),
		benfcEtcAddr("ADDR_SEP"),
		notclIsueEtcAddr("ADDR_SEP"),
		outGanEtcAddr("ADDR_SEP"),
		accipRsdplEtcAddr("ADDR_SEP"),
		ownhEtcAddr("ADDR_SEP"),
		contrEtcAddr("ADDR_SEP"),
		insdEtcAddr("ADDR_SEP"),
		heirAddr("ADDR_SEP"),
		benfcRsdplEtcAddr("ADDR_SEP"),
		payAppltEtcAddr("ADDR_SEP"),
		ownhAddr("ADDR_SEP"),
		ownhDtlAddr("ADDR_SEP"),
		fctrAddr("ADDR_SEP"),
		incmrBzarLoctnAddr("ADDR_SEP"),
		invsgDeptAddr("ADDR_SEP"),
		hospAddr("ADDR_SEP"),
		notclIsueAddr("ADDR_SEP"),
		incmrAddr("ADDR_SEP"),
		pmtrEtcAddr("ADDR_SEP"),
		scknsNm("DISE_SEP"),
		rfScknsNm("DISE_SEP"),
		diseSynonNm("DISE_SEP"),
		grpEmailAddr("EMAIL_SEP"),
		emailAddr("EMAIL_SEP"),
		appltEmailAddr("EMAIL_SEP"),
		wkplEmailAddr("EMAIL_SEP"),
		contrEmailAddr("EMAIL_SEP"),
		chrgMktgEmplEmailAddr("EMAIL_SEP"),
		heirEmailAddr("EMAIL_SEP"),
		cybAppltEmailAddr("EMAIL_SEP"),
		heirCtadrCtnt("CONTACT_SEP"),
		ctadrCtnt("CONTACT_SEP"),
		ssoPswd("PWD_SEP"),
		telino("CONTACT_SEP"),
		chrgpTelino("CONTACT_SEP"),
		mpino("CONTACT_SEP"),
		notclIsueTelino("CONTACT_SEP"),
		jrdTaxofTelino("CONTACT_SEP"),
		outGanMpino("CONTACT_SEP"),
		ownhTelino("CONTACT_SEP"),
		wkplTelino("CONTACT_SEP"),
		chrgBkTelino("CONTACT_SEP"),
		repTelino("CONTACT_SEP"),
		chrgFaxino("CONTACT_SEP"),
		plnrMpino("CONTACT_SEP"),
		ofcTelino("CONTACT_SEP"),
		benfcMpino("CONTACT_SEP"),
		outGanTelino("CONTACT_SEP"),
		outInfpvrMpino("CONTACT_SEP"),
		outInfpvrTelino("CONTACT_SEP"),
		accipMpino("CONTACT_SEP"),
		accipTelino("CONTACT_SEP"),
		benfcTelino("CONTACT_SEP"),
		cybAppltMpino("CONTACT_SEP"),
		cybAppltOwnhTelino("CONTACT_SEP"),
		cybAppltWkplTelino("CONTACT_SEP"),
		slrepMpino("CONTACT_SEP"),
		slrepOwnhTelino("CONTACT_SEP"),
		extrnTelino("CONTACT_SEP"),
		acciUndwrTelino("CONTACT_SEP"),
		adjrTelino("CONTACT_SEP"),
		eduAppltMpino("CONTACT_SEP"),
		eduAppltTelino("CONTACT_SEP"),
		contrTelino("CONTACT_SEP"),
		repIntvwrMpino("CONTACT_SEP"),
		repIntvwrOfcTelino("CONTACT_SEP"),
		sndplTelino("CONTACT_SEP"),
		appltTelino("CONTACT_SEP"),
		dfctRegpTelino("CONTACT_SEP"),
		rcpTelino("CONTACT_SEP"),
		akgTelino("CONTACT_SEP"),
		chrgMktgEmplTelino("CONTACT_SEP"),
		benfcOwnhTelino("CONTACT_SEP"),
		contrMpino("CONTACT_SEP"),
		plnrTelino("CONTACT_SEP"),
		dfctChrgpTelino("CONTACT_SEP"),
		invgrTmngMpino("CONTACT_SEP"),
		clmnPlnrTelino("CONTACT_SEP"),
		invgrMpino("CONTACT_SEP"),
		smsReceMpino("CONTACT_SEP"),
		appltWkplTelino("CONTACT_SEP"),
		insdMpino("CONTACT_SEP"),
		contrOwnhTelino("CONTACT_SEP"),
		custWkplTelino("CONTACT_SEP"),
		infpvObjDscNo("JUMIN_SEP"),
		restrBzRltNo("JUMIN_SEP"),
		ptnrCardNo("CARD_SEP"),
		endSecuCardNo("CARD_SEP"),
		recvEndSecuCardNo("CARD_SEP"),
		sndEndSecuCardNo("CARD_SEP"),
		insdRrno("JUMIN_SEP"),
		rltpRrno("JUMIN_SEP"),
		achdRrno("JUMIN_SEP"),
		rrno("JUMIN_SEP"),
		dlgtRecvrRrno("JUMIN_SEP"),
		appltRrno("JUMIN_SEP"),
		kscoRrno("JUMIN_SEP"),
		contrRrno("JUMIN_SEP"),
		membRrno("JUMIN_SEP"),
		grntrRrno("JUMIN_SEP"),
		crdtRrno("JUMIN_SEP"),
		rlnmVrfcTgtpRrno("JUMIN_SEP"),
		outInfpvrRrno("JUMIN_SEP"),
		incmrRrno("JUMIN_SEP"),
		accipRrno("JUMIN_SEP"),
		benfcRrno("JUMIN_SEP"),
		payAppltRrno("JUMIN_SEP"),
		offrpRrno("JUMIN_SEP"),
		bkSelrRrno("JUMIN_SEP"),
		atrAchdRrno("JUMIN_SEP"),
		rmtAchdRrno("JUMIN_SEP"),
		payActAchdRrno("JUMIN_SEP"),
		recvrRrno("JUMIN_SEP"),
		pinsdRrno("JUMIN_SEP"),
		heirRrno("JUMIN_SEP"),
		rtpnsContrRrno("JUMIN_SEP"),
		famRrno("JUMIN_SEP"),
		dontrRrno("JUMIN_SEP"),
		bzacBzmanRrno("JUMIN_SEP"),
		spstEmplRrno("JUMIN_SEP"),
		custRrno("JUMIN_SEP"),
		diagDrRrno("JUMIN_SEP"),
		pboflRrno("JUMIN_SEP"),
		docRegpRrno("JUMIN_SEP"),
		pwpaRrno("JUMIN_SEP"),
		rdsnBzno("JUMIN_SEP"),
		accipCustRrno("JUMIN_SEP"),
		bfchCorpActNo("ACCNT_SEP"),
		afchCorpActNo("ACCNT_SEP"),
		custActNo("ACCNT_SEP"),
		corpCardNo("CARD_SEP"),
		newCorpCardNo("CARD_SEP"),
		secuCardNo("CARD_SEP"),
		aclosTgmCtnt("ETC_SEP"),
		taxpfTgmDataCtnt("ETC_SEP"),
		vactNo("ACCNT_SEP"),
		actNo("ACCNT_SEP"),
		outGanActNo("ACCNT_SEP"),
		fndOvrlActNo("ACCNT_SEP"),
		fndActNo("ACCNT_SEP"),
		bfchActNo("ACCNT_SEP"),
		afchActNo("ACCNT_SEP"),
		dpsActNo("ACCNT_SEP"),
		grntrActNo("ACCNT_SEP"),
		crdtActNo("ACCNT_SEP"),
		plnActNo("ACCNT_SEP"),
		ractNo("ACCNT_SEP"),
		payActNo("ACCNT_SEP"),
		atrActNo("ACCNT_SEP"),
		achdCustDscNo("JUMIN_SEP"),
		custDscNo("JUMIN_SEP"),
		cardOwnerCustDscNo("JUMIN_SEP"),
		appltDscNo("JUMIN_SEP"),
		mphonIdvrfCustDscNo("JUMIN_SEP"),
		msgReceCustRfNo("JUMIN_SEP"),
		pboflActNo("ACCNT_SEP"),
		custTxpyrRegNo("JUMIN_SEP"),
		ctlpTxpyrRegNo("JUMIN_SEP"),
		txpyrRegNo("JUMIN_SEP"),
		wdmThcoActNo("ACCNT_SEP"),
		dataCalcoDscNo("JUMIN_SEP"),
		vactMoActNo("ACCNT_SEP"),
		moActNo("ACCNT_SEP"),
		cardNo("CARD_SEP"),
		faxino("CONTACT_SEP"),
		ownhFaxino("CONTACT_SEP"),
		wkplFaxino("CONTACT_SEP"),
		strtSecuCardNo("CARD_SEP"),
		sndStrtSecuCardNo("CARD_SEP"),
		recvStrtSecuCardNo("CARD_SEP"),
		idcdNo("JUMIN_SEP"),
		pssptNo("JUMIN_SEP"),
		attnObjDscNo("JUMIN_SEP"),
		contrCustDscNo("JUMIN_SEP"),
		insdCustDscNo("JUMIN_SEP"),
		pwpaTelino("CONTACT_SEP"),
		pwpaTelino1("CONTACT_SEP"),
		pwpaTelino2("CONTACT_SEP"),
		pmpsDscNo("JUMIN_SEP"),
		pmpsActNo("ACCNT_SEP")
		;
		
		public String Sync;
		
		EncSAPType(String Sync){
			this.Sync = Sync;
		}
	}
	
	/** 
	 * CHARSET을 지정을 하지않고(Default UTF-8) 암호화된 데이터를 가져옴
	 * @param val input 값
	 * @param type 암호화 항목(EncType)
	 */
	public static String getEncSAPValue(String val, EncSAPType type) {
		return getEncSAPValue(val, type, DEFAULT_CHARSET);
	}
	
	/** 
	 * CHARSET을 지정하고 암호화된 데이터를 가져옴
	 * @param val input 값
	 * @param type 암호화 항목
	 * @param charset 인코딩 CHARSET
	 */
	public static String getEncSAPValue(String val, EncSAPType type, String charset) {
		return getScpEncSAPValue(val, type, charset);
		//return val;
	}

	//실제 DB암호화 호출
	@SuppressWarnings("unused")
	private static String getScpEncSAPValue(String val, EncSAPType type, String charset) {
		
		// 개발/운영서버 별로 암호화키가 다르다
		String encTypeString = type.Sync;
		
		if (StringUtils.isEmpty(encTypeString)) {
			return null;
		}
		// 운영서버가 아닐경우 암호화키는 XXX_SED
		
		int systemType = FwUtil.getSystemType();
		
		if (systemType != FwUtil.SYSTEM_REAL) {
			encTypeString = encTypeString.replaceAll("_SEP", "_SED");
		}
		
		logger.debug("systemType : " + systemType);
		logger.debug("val : " + val);
		logger.debug("encTypeString : " + encTypeString);
		
		String strRtn = agt.ScpEncB64( System.getProperty(INI_FILE_PATH), encTypeString, val );
		
		return strRtn;
	}

	/** 
	 * CHARSET을 지정을 하지않고 복호화된 값을 가져옴
	 * @param val input 값
	 * @param type 암호화 항목(EncType)
	 */
	public static String getDecSAPValue(String val, EncSAPType type) {
		return getDecSAPValue(val, type, DEFAULT_CHARSET);
	}
	
	/** 
	 * CHARSET을 지정한 복호화된 값을 가져옴
	 * @param val input 값
	 * @param type 암호화 항목(EncType)
	 * @param charset 인코딩 CHARSET
	 */
	public static String getDecSAPValue(String val, EncSAPType type, String charset) {
		return getScpDecSAPValue(val, type, charset);
		//return val;
	}

	//실제 DB복호화 호출
	private static String getScpDecSAPValue(String val, EncSAPType type, String charset) {
		
		// 개발/운영서버 별로 암호화키가 다르다
		String encTypeString = type.Sync;
		
		if (StringUtils.isEmpty(encTypeString)) {
			return null;
		}
		
		// 운영서버가 아닐경우 암호화키는 XXX_SED
		int systemType = FwUtil.getSystemType();
		
		
		if (systemType != FwUtil.SYSTEM_REAL) {
			logger.info(":::: 개발서버용 encType으로 변경 : :::");			
			encTypeString = encTypeString.replaceAll("_SEP", "_SED");
		}
		
		logger.debug("systemType : " + systemType);
		logger.debug("val : " + val);
		logger.debug("encTypeString : " + encTypeString);
		
		String strRtn = agt.ScpDecB64( System.getProperty(INI_FILE_PATH), encTypeString, val);
		
		return strRtn;
	}
	
}

