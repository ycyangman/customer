package cigna.zz;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.bind.annotation.XmlType;

import klaf.app.ApplicationException;
import klaf.common.util.StringUtils;
import klaf.container.annotation.KlafBean;
import klaf.omm.root.IOmmObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.penta.scpdb.ScpDbAgent;
 
/**
 * @file         cigna.zz.SecuUtil.java
 * @filetype     java source file
 * @brief        개인정보 마스킹 및 DB암호화를 수행하는 공통 API 클래스<br>
 * <pre>
 * 본 클래스를 사용하기 위해서는 다음에 나오는 내용을 준수
 * 1. Mask관련 함수는 화면에 표시되는 개인정보를 '*'로 변환하며 출력하기 위한 함수
 * 2. Enc관련 함수는 암호화된 값을 DB에 저장
 * 3. Dec관련 함수는 복호화된 값을 DB에 저장
 * </pre>
 * @author       jixkim
 * @version      0.1
 * @history
 * 
 *
 */

@KlafBean
public class SecuUtil {
	final static Logger logger = LoggerFactory.getLogger(SecuUtil.class);
	
	/** 
	 * CHARSET을 지정하지 않으면 UTF-8로 지정 
	 */
	private static final String DEFAULT_CHARSET = "UTF-8";
	
	private static final String DEC = "DEC";
	private static final String ENC = "ENC";
	
	
	/** 
	 * DAMO SCP API
	 */
	private final static String INI_FILE_PATH = "ini.filePath";
	private final static String DAMO_INI_FILE = System.getProperty(INI_FILE_PATH);
	
	private static ScpDbAgent agt = new ScpDbAgent();
	private static ScpDbAgent agtPwd = null;
	
	private static Map<String, EncType> secuMap = new HashMap<String, EncType>();
	
	private static boolean initPWdAgent() {
		int ret = 0;
		agtPwd = new ScpDbAgent();
		ret = agt.AgentInit( DAMO_INI_FILE );
		if ( ret != 0 && ret != 118 ) {
			// Failed
			logger.error("ScpDbAgent for Pswd initialize failed. {}", ret);
			return false;
		}
		logger.info("ScpDbAgent for Pswd initialized {}",ret);
		return true;
	}
	
	private synchronized static void initSec() {

		if(secuMap.size() != EncType.values().length) {
			
			logger.debug("initSec :: {} / {}", secuMap.size(), EncType.values().length );
			
			EncType[] encTypeArr = EncType.values();
			secuMap = new HashMap<String, EncType>(0);
			
			for (EncType encTypeItem : encTypeArr) {
				secuMap.put(encTypeItem.name().toUpperCase(Locale.ENGLISH), encTypeItem);
			}
		}
	}
	
	
	/** 
	 * 마스킹 타입 대상
	 * RRNo = 주민번호
	 * ActNo = 계좌번호
	 * CardNo = 카드번호
	 * TelNo = 전화번호
	 * Address = 주소
	 * Email = 이메일
	 * Name = 이름
	 */
	public static enum MaskType {
		RRNo,
		ActNo,
		CardNo,
		TelNo,
		TelNo1,
		Address,
		EMail,
		Name
		
	}
	
	/** 
	 * DB암호화 대상 
	 * Jumin = 주민번호
	 * Accnt = 계좌번호
	 * Card = 카드번호
	 * Contact = 전화번호
	 * Addr = 주소
	 * Email = 이메일
	 * Salary = 연봉
	 * Etc = 로그 등 기타 정보
	 */
	public static enum EncType {
		Jumin("JUMIN_E"),
		Accnt("ACCNT_E"),
		Card("CARD_E"),
		Contact("CONTACT_E"),
		Addr("ADDR_E"),
		Email("EMAIL_E"),
		Salary("SALARY_E"),
		Dise("DISE_E"),
		Etc("ETC_E"),
		
		// 실제컬럼형태
		emailId("EMAIL_E"),
		notclIsueEmailId("EMAIL_E"),
		tmpSecuCardRdnumVl("CARD_E"),
		secuCardRdnumVl("CARD_E"),
		sndInfoVl("CARD_E"),
		afchCtnt("ETC_E"),
		bfchCtnt("ETC_E"),
		icpsPswd("PWD_E"),
		icpsFdupPswd("ETC_E"),
		kidiUsrPswd("PWD_E"),
		kliaUsrPswd("PWD_E"),
		kidiUsrFdupPswd("ETC_E"),
		kliaUsrFdupPswd("ETC_E"),
		curPswd("PWD_E"),
		bfusePswd("PWD_E"),
		pswd("PWD_E"),
		dofTelno("CONTACT_E"),
		undwrOrgTelno("CONTACT_E"),
		regDofTelno("CONTACT_E"),
		repFaxTelno("CONTACT_E"),
		repTelno("CONTACT_E"),
		cnslrTelno("CONTACT_E"),
		custTmpTelno("CONTACT_E"),
		rsvtTelno("CONTACT_E"),
		telno("CONTACT_E"),
		custBzmanTelno("CONTACT_E"),
		tmpTelno("CONTACT_E"),
		expsrCustTelno("CONTACT_E"),
		appltTelno("CONTACT_E"),
		chrgEmplReceMpno("CONTACT_E"),
		appltMpno("CONTACT_E"),
		membMpno("CONTACT_E"),
		custMpno("CONTACT_E"),
		afchContrMpno("CONTACT_E"),
		bfchContrTelno("CONTACT_E"),
		bfchContrMpno("CONTACT_E"),
		expsrCustMpno("CONTACT_E"),
		payAppltTelno("CONTACT_E"),
		indNagrinfCustTelno("CONTACT_E"),
		benfcTelno("CONTACT_E"),
		smsTrmsTelno("CONTACT_E"),
		smsRplyTelno("CONTACT_E"),
		appltOwnhTelno("CONTACT_E"),
		chrgEmplSndmsMpno("CONTACT_E"),
		afchContrTelno("CONTACT_E"),
		custTelno("CONTACT_E"),
		ownhTelno("CONTACT_E"),
		mphonTelno("CONTACT_E"),
		contrMpno("CONTACT_E"),
		heirMpno("CONTACT_E"),
		sndTelno("CONTACT_E"),
		clmpTelno("CONTACT_E"),
		chrgpTelno("CONTACT_E"),
		crdtTelno("CONTACT_E"),
		dncallEmailTelno("CONTACT_E"),
		sndEmplEmailTelno("CONTACT_E"),
		receCustEmailMpno("CONTACT_E"),
		pblInstChrgpTelno("CONTACT_E"),
		notclWrtpTelno("CONTACT_E"),
		notclWrtpFaxTelno("CONTACT_E"),
		wkplTelno("CONTACT_E"),
		dncallTelno("CONTACT_E"),
		undwrInlnTelno("CONTACT_E"),
		mphonTelino("CONTACT_E"),
		hospEtcAddr("ADDR_E"),
		intvwLoctnAddr("ADDR_E"),
		receEtcAddr("ADDR_E"),
		clmnDofEtcAddr("ADDR_E"),
		orgEngAddr("ADDR_E"),
		prvPlwBzarLoctnAddr("ADDR_E"),
		ptncoCentrAddr("ADDR_E"),
		orgEtcAddr("ADDR_E"),
		coopCmpyEtcAddr("ADDR_E"),
		bcfDofAddr("ADDR_E"),
		bkCentrEtcAddr("ADDR_E"),
		gpEtcAddr("ADDR_E"),
		offcEtcAddr("ADDR_E"),
		etcAddr("ADDR_E"),
		ctlpEngAddr("ADDR_E"),
		wkplEtcAddr("ADDR_E"),
		appltEtcAddr("ADDR_E"),
		bfchContrEtcAddr("ADDR_E"),
		crdtAddr("ADDR_E"),
		rsdplEtcAddr("ADDR_E"),
		afchContrEtcAddr("ADDR_E"),
		custEngAddr("ADDR_E"),
		custEngAddr1("ADDR_E"),
		custEngAddr2("ADDR_E"),
		benfcEtcAddr("ADDR_E"),
		notclIsueEtcAddr("ADDR_E"),
		outGanEtcAddr("ADDR_E"),
		accipRsdplEtcAddr("ADDR_E"),
		ownhEtcAddr("ADDR_E"),
		contrEtcAddr("ADDR_E"),
		insdEtcAddr("ADDR_E"),
		heirAddr("ADDR_E"),
		benfcRsdplEtcAddr("ADDR_E"),
		payAppltEtcAddr("ADDR_E"),
		ownhAddr("ADDR_E"),
		ownhDtlAddr("ADDR_E"),
		fctrAddr("ADDR_E"),
		incmrBzarLoctnAddr("ADDR_E"),
		invsgDeptAddr("ADDR_E"),
		hospAddr("ADDR_E"),
		notclIsueAddr("ADDR_E"),
		incmrAddr("ADDR_E"),
		pmtrEtcAddr("ADDR_E"),
		scknsNm("DISE_E"),
		rfScknsNm("DISE_E"),
		diseSynonNm("DISE_E"),
		grpEmailAddr("EMAIL_E"),
		emailAddr("EMAIL_E"),
		appltEmailAddr("EMAIL_E"),
		wkplEmailAddr("EMAIL_E"),
		contrEmailAddr("EMAIL_E"),
		chrgMktgEmplEmailAddr("EMAIL_E"),
		heirEmailAddr("EMAIL_E"),
		cybAppltEmailAddr("EMAIL_E"),
		dncallEmailAddr("EMAIL_E"),
		heirCtadrCtnt("CONTACT_E"),
		ctadrCtnt("CONTACT_E"),
		ssoPswd("PWD_E"),
		telino("CONTACT_E"),
		chrgpTelino("CONTACT_E"),
		mpino("CONTACT_E"),
		notclIsueTelino("CONTACT_E"),
		jrdTaxofTelino("CONTACT_E"),
		outGanMpino("CONTACT_E"),
		ownhTelino("CONTACT_E"),
		wkplTelino("CONTACT_E"),
		chrgBkTelino("CONTACT_E"),
		repTelino("CONTACT_E"),
		chrgFaxino("CONTACT_E"),
		plnrMpino("CONTACT_E"),
		ofcTelino("CONTACT_E"),
		benfcMpino("CONTACT_E"),
		outGanTelino("CONTACT_E"),
		outInfpvrMpino("CONTACT_E"),
		outInfpvrTelino("CONTACT_E"),
		accipMpino("CONTACT_E"),
		accipTelino("CONTACT_E"),
		benfcTelino("CONTACT_E"),
		cybAppltMpino("CONTACT_E"),
		cybAppltOwnhTelino("CONTACT_E"),
		cybAppltWkplTelino("CONTACT_E"),
		slrepMpino("CONTACT_E"),
		slrepOwnhTelino("CONTACT_E"),
		extrnTelino("CONTACT_E"),
		acciUndwrTelino("CONTACT_E"),
		adjrTelino("CONTACT_E"),
		eduAppltMpino("CONTACT_E"),
		eduAppltTelino("CONTACT_E"),
		contrTelino("CONTACT_E"),
		repIntvwrMpino("CONTACT_E"),
		repIntvwrOfcTelino("CONTACT_E"),
		sndplTelino("CONTACT_E"),
		appltTelino("CONTACT_E"),
		dfctRegpTelino("CONTACT_E"),
		rcpTelino("CONTACT_E"),
		akgTelino("CONTACT_E"),
		chrgMktgEmplTelino("CONTACT_E"),
		benfcOwnhTelino("CONTACT_E"),
		contrMpino("CONTACT_E"),
		plnrTelino("CONTACT_E"),
		dfctChrgpTelino("CONTACT_E"),
		invgrTmngMpino("CONTACT_E"),
		clmnPlnrTelino("CONTACT_E"),
		invgrMpino("CONTACT_E"),
		smsReceMpino("CONTACT_E"),
		appltWkplTelino("CONTACT_E"),
		insdMpino("CONTACT_E"),
		contrOwnhTelino("CONTACT_E"),
		custWkplTelino("CONTACT_E"),
		infpvObjDscNo("JUMIN_E"),
		restrBzRltNo("JUMIN_E"),
		ptnrCardNo("CARD_E"),
		endSecuCardNo("CARD_E"),
		recvEndSecuCardNo("CARD_E"),
		sndEndSecuCardNo("CARD_E"),
		insdRrno("JUMIN_E"),
		rltpRrno("JUMIN_E"),
		achdRrno("JUMIN_E"),
		rrno("JUMIN_E"),
		dlgtRecvrRrno("JUMIN_E"),
		appltRrno("JUMIN_E"),
		kscoRrno("JUMIN_E"),
		contrRrno("JUMIN_E"),
		membRrno("JUMIN_E"),
		grntrRrno("JUMIN_E"),
		crdtRrno("JUMIN_E"),
		rlnmVrfcTgtpRrno("JUMIN_E"),
		outInfpvrRrno("JUMIN_E"),
		incmrRrno("JUMIN_E"),
		accipRrno("JUMIN_E"),
		benfcRrno("JUMIN_E"),
		payAppltRrno("JUMIN_E"),
		offrpRrno("JUMIN_E"),
		bkSelrRrno("JUMIN_E"),
		atrAchdRrno("JUMIN_E"),
		rmtAchdRrno("JUMIN_E"),
		payActAchdRrno("JUMIN_E"),
		recvrRrno("JUMIN_E"),
		pinsdRrno("JUMIN_E"),
		heirRrno("JUMIN_E"),
		rtpnsContrRrno("JUMIN_E"),
		famRrno("JUMIN_E"),
		dontrRrno("JUMIN_E"),
		bzacBzmanRrno("JUMIN_E"),
		spstEmplRrno("JUMIN_E"),
		custRrno("JUMIN_E"),
		diagDrRrno("JUMIN_E"),
		pboflRrno("JUMIN_E"),
		docRegpRrno("JUMIN_E"),
		pwpaRrno("JUMIN_E"),
		rdsnBzno("JUMIN_E"),
		accipCustRrno("JUMIN_E"),
		bfchCorpActNo("ACCNT_E"),
		afchCorpActNo("ACCNT_E"),
		custActNo("ACCNT_E"),
		corpCardNo("CARD_E"),
		newCorpCardNo("CARD_E"),
		secuCardNo("CARD_E"),
		aclosTgmCtnt("ETC_E"),
		taxpfTgmDataCtnt("ETC_E"),
		vactNo("ACCNT_E"),
		actNo("ACCNT_E"),
		outGanActNo("ACCNT_E"),
		fndOvrlActNo("ACCNT_E"),
		fndActNo("ACCNT_E"),
		bfchActNo("ACCNT_E"),
		afchActNo("ACCNT_E"),
		dpsActNo("ACCNT_E"),
		grntrActNo("ACCNT_E"),
		crdtActNo("ACCNT_E"),
		plnActNo("ACCNT_E"),
		ractNo("ACCNT_E"),
		payActNo("ACCNT_E"),
		atrActNo("ACCNT_E"),
		achdCustDscNo("JUMIN_E"),
		custDscNo("JUMIN_E"),
		cardOwnerCustDscNo("JUMIN_E"),
		appltDscNo("JUMIN_E"),
		mphonIdvrfCustDscNo("JUMIN_E"),
		msgReceCustRfNo("JUMIN_E"),
		pboflActNo("ACCNT_E"),
		wdmThcoActNo("ACCNT_E"),
		dataCalcoDscNo("JUMIN_E"),
		vactMoActNo("ACCNT_E"),
		moActNo("ACCNT_E"),
		cardNo("CARD_E"),
		faxino("CONTACT_E"),
		ownhFaxino("CONTACT_E"),
		wkplFaxino("CONTACT_E"),
		strtSecuCardNo("CARD_E"),
		sndStrtSecuCardNo("CARD_E"),
		recvStrtSecuCardNo("CARD_E"),
		idcdNo("JUMIN_E"),
		pssptNo("JUMIN_E"),
		attnObjDscNo("JUMIN_E"),
		contrCustDscNo("JUMIN_E"),
		insdCustDscNo("JUMIN_E"),
		contrDscNo("JUMIN_E"),
		pinsdDscNo("JUMIN_E"),
		aclOwnerRdsnNo("JUMIN_E"),
		pwpaTelino("CONTACT_E"),
		pwpaTelino1("CONTACT_E"),
		pwpaTelino2("CONTACT_E"),
		pmpsDscNo("JUMIN_E"),
		pmpsActNo("ACCNT_E"),
		faxTelino("CONTACT_E"), 
		crtfMphonIdcsNo("CONTACT_E"),
		cnslCustTelino("CONTACT_E"),
		sndmsMgrEmailAddr("EMAIL_E"),
		receChrgpEmailAddr("EMAIL_E"),
		receChrgpTelno("CONTACT_E"),
		benfcCustRrno("JUMIN_E"),
		bzCntcReqCtnt("ETC_E")
		;
		 
		
		public String Sync;
		
		EncType(String Sync){
			this.Sync = Sync;
		}
	}
	
	/** 
	 * CHARSET을 지정을 하지않고(Default UTF-8) 암호화된 데이터를 가져옴
	 * @param val input 값
	 * @param type 암호화 항목(EncType)
	 */
	public static String getEncValue(String val, EncType type) {
		return getEncValue(val, type, DEFAULT_CHARSET);
	}
	
	/** 
	 * CHARSET을 지정하고 암호화된 데이터를 가져옴
	 * @param val input 값
	 * @param type 암호화 항목
	 * @param charset 인코딩 CHARSET
	 */
	public static String getEncValue(String val, EncType type, String charset) {
		return getScpEncValue(val, type, charset);
		//return val;
	}

	//실제 DB암호화 호출
	@SuppressWarnings("unused")
	private static String getScpEncValue(String val, EncType type, String charset) {
		
		initSec();
		
		Object	objRtn  = null;
		String	strRtn	= null;
		
		strRtn = agt.ScpEncB64( DAMO_INI_FILE, type.Sync, val );
		
		if (objRtn != null) {
			strRtn = (String)objRtn;
		}
		
		return strRtn;
	}

	/** 
	 * CHARSET을 지정을 하지않고 복호화된 값을 가져옴
	 * @param val input 값
	 * @param type 암호화 항목(EncType)
	 */
	public static String getDecValue(String val, EncType type) {
		return getDecValue(val, type, DEFAULT_CHARSET);
	}
	
	/** 
	 * CHARSET을 지정한 복호화된 값을 가져옴
	 * @param val input 값
	 * @param type 암호화 항목(EncType)
	 * @param charset 인코딩 CHARSET
	 */
	public static String getDecValue(String val, EncType type, String charset) {
		return getScpDecValue(val, type, charset);
	}

	//실제 DB복호화 호출
	@SuppressWarnings("unused")
	private static String getScpDecValue(String val, EncType type, String charset) {
		
		initSec();
		
		Object	objRtn  = null;
		String	strRtn	= null;
		
		strRtn = agt.ScpDecB64( DAMO_INI_FILE, type.Sync, val);
		
		if (objRtn != null) {
			strRtn = (String)objRtn;
		}
		
		return strRtn;
	}

	/** 
	 * 패스워드 암호화
	 * @param val 암호화된 passwd를 가져옴
	 */
	public static String getEncPasswd(String val) {
		
		logger.debug("SecuUtil trace info :: "+ FwUtil.getBizStacktrace( new Throwable() ) );
		
		return getScpEncPasswd(val);
		//return val;
	}

	//실제 DB암호화 호출
	private static String getScpEncPasswd(String val) {

		String strHash = "";
		
		if(agtPwd==null) {
			if(initPWdAgent() == false) {
				logger.error("initPwdAgent() failed");
				return null;
			}
		}
	    strHash = agtPwd.AgentCipherHashStringB64(71, val);
	      
		return strHash;
	}

	/** 
	 * 마스킹 항목
	 * @param val 마스킹 문자열
	 * @param type 마스킹 항목 
	 */
	public static String getMasking(String val, MaskType type) {
		String rtValue = "";
		
		switch (type) {
			case RRNo :
				rtValue = getMaskedRRNo(val); 
				break;
			case ActNo :
				rtValue = getMaskedActNo(val);
				break;
			case CardNo :
				rtValue = getMaskedCardNo(val);
				break;
			case TelNo :
				rtValue = getMaskedTelNo(val);
				break;
			case TelNo1 :
				rtValue = getMaskedTelNo1(val);
				break;
			case Address :
				rtValue = getMaskedAddress(val);
				break;
			case EMail :
				rtValue = getMaskedEMail(val);
				break;
			case Name :
				//rtValue = getMaskedName(val);
				rtValue = getMaskedNameN(val);
				break;
			default :
				rtValue = getMaskedDefault(val);
				break;
		}
		return rtValue;
	}
	
	/** 
	 * File 암호화
	 * @param srcFile 기존 파일
	 * @param dstFile 변환 파일
	 */
	public static int encFile(String srcFile, String dstFile) {
		return 0;
	}
	
	/** 
	 * File 복호화
	 * @param srcFile 기존 파일
	 * @param dstFile 변환 파일
	 */
	public static int decFile(String srcFile, String dstFile) {
		return 0;
	}
	
	/** 
	 * 주민번호 뒷6자리
	 * @param str 입력 문자열
	 */
	private static String getMaskedRRNo(String str) {
		if(StringUtils.isEmpty(str)) {
			return "";
		}
		String regex = "(\\d{6})([- \\t\\n\\x0B\\f\\r])([0123456789])(\\d{6})";
		
		if(str.indexOf("-")<0) {
			regex = "(\\d{6})([0123456789])(\\d{6})";
			return str.replaceAll(regex, "$1$2******");
		}
		else {
			return str.replaceAll(regex, "$1$2$3******");
		}
	}

	/** 
	 * 계좌번호 중간6자리[앞 5번째자리에서 6자리숫자]
	 * @param str 입력 문자열
	 */
	
	private static String getMaskedActNo(String str) {
		String regex = null;
		int[] hyphen = new int[10];
		
		int tHypen = str.indexOf("-");
		int cnt = 0;
		while (tHypen >=0 ) {
			hyphen[cnt++] = tHypen;
			str = str.replaceFirst("-","");
			tHypen = str.indexOf("-");
		}
		
		if(str.length()>10) {
			regex = "(\\d{4})(\\d{6})(\\d{0,20})";
			Matcher matcher = Pattern.compile(regex).matcher(str);
			if(matcher.find()) {
				String replaceString = matcher.group(2);
				char[] chr = new char[replaceString.length()];
				Arrays.fill(chr, '*');
				str = matcher.group(1) + matcher.group(2).replace(replaceString, String.valueOf(chr)) + matcher.group(3);
			}			
		} else {
			regex = "(\\d{4})(\\d{0,6})";
			Matcher matcher = Pattern.compile(regex).matcher(str);
			if(matcher.find()) {
				String replaceString = matcher.group(2);
				char[] chr = new char[replaceString.length()];
				Arrays.fill(chr, '*');
				str = matcher.group(1) + matcher.group(2).replace(replaceString, String.valueOf(chr));
			}			
		}

		
		if(hyphen[0]>0) {
			for(int i=cnt; i>=0; i--) {
				if(hyphen[i]>0) {
					
					str = str.substring(0, hyphen[i]) +"-"+ str.substring(hyphen[i]);
				} 
			}
		}
		
		return str;			
	}
	
	/** 
	 * 카드번호 중간6자리[앞 5번째자리에서 6자리 숫자]
	 * @param str 입력 문자열
	 */
	private static String getMaskedCardNo(String str) {
		String regex = null;
		int[] hyphen = new int[10];
		
		int tHypen = str.indexOf("-");
		int cnt = 0;
		while (tHypen >=0 ) {
			hyphen[cnt++] = tHypen;
			str = str.replaceFirst("-","");
			tHypen = str.indexOf("-");
		}
		
		if(str.indexOf("-")<0) regex = "(\\d{6})(\\d{6})(\\d{2})(\\d+)";
		Matcher matcher = Pattern.compile(regex).matcher(str);
		if(matcher.find()) {
			String replaceString = matcher.group(2);
			char[] chr = new char[replaceString.length()];
			Arrays.fill(chr, '*');
			str = matcher.group(1) + matcher.group(2).replace(replaceString, String.valueOf(chr)) + matcher.group(3) + matcher.group(4);
		}
		
		if(hyphen[0]>0) {
			for(int i=cnt; i>=0; i--) {
				if(hyphen[i]>0) {
					
					str = str.substring(0, hyphen[i]) +"-"+ str.substring(hyphen[i]);
				} 
			}
		}
		
		return str;			
	}

	/** 
	 * 전화번호 국번: 국번미인식 시 [앞 4번째짜리에서 4자리 숫자]
	 * @param str 입력 문자열
	 */
	private static String getMaskedTelNo(String str) {
		String regex = "(\\d{2,3}[-])(\\d{3,4})([-]\\d{4})";
		if(str.indexOf("-")<0) regex = "(\\d{2,3})(\\d{3,4})(\\d{4})";

		Matcher matcher = Pattern.compile(regex).matcher(str);
		if(matcher.find()) {
			String replaceString = matcher.group(2);
			char[] chr = new char[replaceString.length()];
			Arrays.fill(chr, '*');
			return matcher.group(1) + matcher.group(2).replace(replaceString, String.valueOf(chr)) + matcher.group(3);
		}
		return str;
	}
	
	/** 
	 * 전화번호 국번: 국번 인식 시 [앞 4번째짜리에서 3,4자리 숫자]
	 * @param str 입력 문자열 
	 */
	private static String getMaskedTelNo1(String str) {
		String regex = "([\\d]+)";	
		Matcher matcher = Pattern.compile(regex).matcher(str);
		if(matcher.find()) {
			String replaceString = matcher.group(1);
			char[] chr = new char[replaceString.length()];
			Arrays.fill(chr, '*');
			return str.replace(replaceString, String.valueOf(chr));
		}
		return str;
	}
	
	/** 
	 * 상세주소 전체(동 이후 전체)
	 * @param str 입력 문자열
	 */
	private static String getMaskedAddress(String str) {
		String regex = "([\\S||\\s]+)";	
		Matcher matcher = Pattern.compile(regex).matcher(str);
		if(matcher.find()) {
			String replaceString = matcher.group(1);
			char[] chr = new char[replaceString.length()];
			Arrays.fill(chr, '*');
			return str.replace(replaceString, String.valueOf(chr));
		}
		return str;	
	}
	
	/** 
	 * 이메일 3번째 자리부터 '@'까지 '*'로 치환
	 * @param str 입력 문자열
	 */
	private static String getMaskedEMail(String str) {
		try {
			String regex = "(\\S{2})(\\S+)(@\\S+.\\S+)";	//5번째자리(1그룹)
			Matcher matcher = Pattern.compile(regex).matcher(str);
			if(matcher.find()) {
				String replaceString = matcher.group(2);
				char[] chr = new char[replaceString.length()];
				Arrays.fill(chr, '*');
				return matcher.group(1) + matcher.group(2).replace(replaceString, String.valueOf(chr)) + matcher.group(3);
			}
		} catch (Exception ex) {
			logger.debug("getMaskedEMail 에러" + ex.toString());
		}
		return str;
	}
	
	private static String getMaskedNameN(String str) {
		
		String backStr="";
		if(StringUtils.isEmpty(str)) {
			return backStr;
		}
		str = str.trim();
		
		String mask ="*";		
		if(str.length() == 2) {
			backStr = "";
		} else if (str.length() == 1) {
			return str;
		} else {
			backStr = str.substring(str.length()-1);
			String maskStr = str.substring(1, str.length()-1);
			mask = maskStr.replaceAll(".", "*");
		}
		
		str = str.substring(0, 1) + mask + backStr;
		
		return str;	
	}

	/** 
	 * 마스킹되지 않은 문자열 출력
	 * @param str 입력 문자열
	 */
	private static String getMaskedDefault(String str) {
		
		return str;
	}
	
	
	/**
	 * OMM 구조의 Object에서 ioEncField에 포함된 필드를 ioEncType의 유형으로 암호화 
	 * @param srcData		원본 omm 유형의 Data
	 * @param ioEncField	해당 Omm 객체에서 암호화 대상 필드명 리스트 
	 * @param ioEncType	해당 Omm 객체에서 암호화 대상 필드의 암호화 유형
	 * @throws ApplicationException
	 */
	private static void doEncDecObject (Object srcData, Map<String, EncType> encMap, String encDecType) throws ApplicationException {
		logger.debug("doEncDecObject");
		
		try {
		
			if (srcData != null) {
				if (srcData.getClass().isAssignableFrom(String.class)) {
					throw new ApplicationException("APCME0033", new Object[]{"입력하신 데이터타입(String)", "사용가능한 객체"}, new Object[]{});
				}
				
				Object[] objField = encMap.keySet().toArray();
				
				EncType encType = null;
				String fieldName = null;
				for (int i = 0; objField!=null && i<objField.length; i++) {	
					fieldName	=	(String)objField[i];
					encType		=	(EncType)encMap.get(fieldName);
					
					// fieldName이 암호화 대상인것만 복호화
					if (encType != null) {
						// getter메소드에서 값을 가져온다
						String value = ReflUtil.getStringValue(srcData, fieldName);
						if (!StringUtils.isEmpty(value)) {
							
							String encDecValue = "";
							
							logger.debug("암복호화  입력값 : " + fieldName + " , " + value + " , " + encType);
							
							if(ENC.equals(encDecType)) {
								// 암호화 실행
								encDecValue = getEncValue(value, encType);
							}
							
							if(DEC.equals(encDecType)) {
								// 암호화 실행
								encDecValue = getDecValue(value, encType);
							}
							
							logger.debug("암복호화 결과값 : " + encDecValue);
							
							// 암호화값을 setter 메소드로 입력한다
							ReflUtil.setStringValue(srcData, fieldName, encDecValue);
							
						}
					}
				} //end for
	
			}
		}
		catch(Exception e) {
			logger.error("SecuUtil 암복화 에러 : " + e.getMessage(), e);
		}
	}
	
	/**
	 * 암복화 대상 필드 맵핑
	 * 
	 * @param Object srcData
	 * @throws ApplicationException
	 */
	private static Map<String, EncType> getEncMap(Object srcData) throws ApplicationException {
		
		initSec();
		
		Map<String, EncType> encMap = new HashMap<String, EncType>();
		
		XmlType xmlType = srcData.getClass().getAnnotation(XmlType.class);
		
		String ioPropOrder[] = null;
		
		if(xmlType == null) {
			
			Field[] fields = srcData.getClass().getDeclaredFields();;
			
			ioPropOrder =  new String[fields.length];
			for (int i=0; i<fields.length; i++) {
				ioPropOrder[i] =  fields[i].getName();
			}
			
		}
		else {
			ioPropOrder = xmlType.propOrder(); // IO 필드명
		}
		
		for (int i = 0; ioPropOrder!=null && i<ioPropOrder.length; i++) {
			
			String ioName = ioPropOrder[i].toUpperCase(Locale.ENGLISH); 
			if(secuMap.get(ioName) != null) {
				encMap.put(ioPropOrder[i],  secuMap.get(ioName) );
			}
		}
		return encMap;
		
	}
	
	/**
	 * 입력된 Object 리스트에
	 * 암호화할 대상이 있다면 암호화 한다
	 * 
	 * @param List<? extends Object> srcDataList
	 * @throws ApplicationException
	 */
	public static void doEncList (List<? extends Object> srcDataList) throws ApplicationException {
		logger.debug("doEncList");
		
		if (srcDataList != null && srcDataList.size()>0) {
			Map<String, EncType> encMap =  getEncMap(srcDataList.get(0));
		
			for(Object srcData : srcDataList) {
				doEncDecObject(srcData, encMap, ENC);
			}
		}
	}
	
	/**
	 * 입력된 Object에
	 * 암호화할 대상이 있다면 암호화 한다
	 * 
	 * @param List<? extends Object> srcDataList
	 * @throws ApplicationException
	 */
	public static void doEncObject (Object srcData) throws ApplicationException {
		logger.debug("doEncObject");
		
		if (srcData != null) {
			if (srcData.getClass().isAssignableFrom(String.class)) {
				throw new ApplicationException("APCME0033", new Object[]{"입력하신 데이터타입(String)", "사용가능한 객체"}, new Object[]{});
			}
			
			Map<String, EncType> encMap =  getEncMap(srcData);
			
			doEncDecObject(srcData, encMap, ENC);
			
		}
	}
	
	/**
	 * 입력된 Object리스트에
	 * 복호화할 대상이 있다면 암호화 한다
	 * 
	 * @param List<? extends Object> srcDataList
	 * @throws ApplicationException
	 */
	public static void doDecList (List<? extends Object> srcDataList) throws ApplicationException {
		logger.debug("doDecList");
		if (srcDataList != null && srcDataList.size()>0) {
			
			Map<String, EncType> encMap =  getEncMap(srcDataList.get(0));
			
			for(Object srcData : srcDataList) {
				doEncDecObject(srcData, encMap, DEC);
			}
		}
	}
	
	/**
	 * 입력된 Object에
	 * 복호화할 대상이 있다면 암호화 한다
	 * 
	 * @param Object srcData
	 * @throws ApplicationException
	 */
	public static void doDecObject (Object srcData) throws ApplicationException {
		logger.debug("doDecObject");
		
		if (srcData != null) {
			if (srcData.getClass().isAssignableFrom(String.class)) {
				throw new ApplicationException("APCME0033", new Object[]{"입력하신 데이터타입(String)", "사용가능한 객체"}, new Object[]{});
			}
			
			if (srcData.getClass().isAssignableFrom(List.class)) {
				throw new ApplicationException("APCME0033", new Object[]{"입력하신 데이터타입(List)", "사용가능한 객체"}, new Object[]{});
			}
			
			Map<String, EncType> encMap =  getEncMap(srcData);
			
			doEncDecObject(srcData, encMap, DEC);
			
		}
	}
	
	/**
	 * 입력된 IOmmObject에 복호화할 대상이 있다면 복호화 하고
	 * 하위 리스트들중 복호화 대상이 있다면 모두 복호화한다
	 * 
	 * @param Object srcData
	 * @throws ApplicationException
	 */
	public static void doDecOmm (IOmmObject srcData) throws ApplicationException {
		logger.debug("doDecOmm");
		
		if (srcData != null) {
			
			// 데이터 복호화
			doDecObject(srcData);
			
			// data필드 명들을 조회한다
			List<String> dataFieldNameList = ReflUtil.getDataFieldNameList(srcData);
			
			// 리스트데이터들을 복호화 한다
			for (String fieldName: dataFieldNameList) {
				
				try {
					Field declaredField = srcData.getClass().getDeclaredField(fieldName);
					
					Class<?> type = declaredField.getType();
					
					if (IOmmObject.class.isAssignableFrom(type)) { // 상위객체를 상속받았는지 체크
						
						IOmmObject subObject = (IOmmObject)ReflUtil.doGetterMethod(srcData, fieldName);
						doDecObject(subObject);
					} else if (type.isAssignableFrom(List.class)) {
						
						@SuppressWarnings("unchecked")
						List<IOmmObject> subList = (List<IOmmObject>)ReflUtil.doGetterMethod(srcData, fieldName);
						for(Object subObject : subList) {
							doDecObject(subObject);
						}
					}
				} catch (NoSuchFieldException e) {
					logger.debug("[NoSuchFieldException] getDeclaredField중 에러");
				} catch (SecurityException e) {
					logger.debug("[SecurityException] getDeclaredField중 에러");
				}
	
			} //end for

		}
		
	}
	
	/**
	 * 입력된 IOmmObject에 암호화할 대상이 있다면 암호화 하고
	 * 하위 리스트들중 암호화 대상이 있다면 모두 암호화한다
	 * 
	 * @param Object srcData
	 * @throws ApplicationException
	 */
	public static void doEncOmm (IOmmObject srcData) throws ApplicationException {
		logger.debug("doDecOmm");
		
		if (srcData != null) {
			
			// 데이터 암호화
			doEncObject(srcData);
			
			// data필드 명들을 조회한다
			List<String> dataFieldNameList = ReflUtil.getDataFieldNameList(srcData);
			
			// 리스트데이터들을 암호화 한다
			for (String fieldName: dataFieldNameList) {
				
				try {
					Field declaredField = srcData.getClass().getDeclaredField(fieldName);
					
					Class<?> type = declaredField.getType();
					
					if (IOmmObject.class.isAssignableFrom(type)) { // 상위객체를 상속받았는지 체크
						
						IOmmObject subObject = (IOmmObject)ReflUtil.doGetterMethod(srcData, fieldName);
						doEncObject(subObject);
					} else if (type.isAssignableFrom(List.class)) {
						
						@SuppressWarnings("unchecked")
						List<IOmmObject> subList = (List<IOmmObject>)ReflUtil.doGetterMethod(srcData, fieldName);
						for(Object subObject : subList) {
							doEncObject(subObject);
						}
					}
				} catch (NoSuchFieldException e) {
					logger.debug("[NoSuchFieldException] getDeclaredField중 에러");
				} catch (SecurityException e) {
					logger.debug("[SecurityException] getDeclaredField중 에러");
				}
	
			} //end for

		}
		
	}

	
}

