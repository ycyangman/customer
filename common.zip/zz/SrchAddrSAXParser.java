package cigna.zz;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import klaf.app.ApplicationException;
import klaf.container.LApplicationContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import cigna.cm.z.io.CMZ009SVC00Out;
import cigna.cm.z.io.CMZ009SVC00Sub;




/**
 * @file         cigna.zz.SrchAddrSAXParser.java
 * @filetype     java source file
 * @brief        SrchAddrSAXParser 주소정재 XML파싱
 * @author       박진성
 * @version      1.0
 * @history
 *
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------	
 * 0.1           박진성                 2016. 6. 1.      신규 작성
 *
 */
public class SrchAddrSAXParser extends DefaultHandler {
	
	private final static String ADDRESS_SERVER_IP = "http://slipostwas.lina.cignakorea.com:9080";   // 2016.11.28 도로명주소 서버 URL변경 - 2017.01.17 도메인으로 변경  (IP 200.22.201.47) 
	private final static String POST_SVC_ADDR="post.svc.addr"; // 주소정제서비스 System property Key
	// 주소검색 서버 주소(지번)
	public final static String JIBUN_NAME_SERVER_URL = "/address/searchJibun.xml";
	
	// 주소검색 서버 주소(도로명)
	public final static String ROAD_NAME_SERVER_URL = "/address/searchRoad.xml";
	
	// 주소검색 서버 주소(정제)
	public final static String REFIND_ZIPCODE_SERVER_URL = "/address/callRefinde.xml";
	
	final Logger logger = LoggerFactory.getLogger(SrchAddrSAXParser.class);
	
	private final SAXParserFactory parserFact;
	private SAXParser parser;
	
	// XML읽는 소스 URL
	private String sourceUrl;
	// 조회되고 있는 태그명
	private String tagName;
	
	private CMZ009SVC00Out cmz009svc00out = null;
	private CMZ009SVC00Sub cmz009svc00sub = null;
	List<CMZ009SVC00Sub> addrList = null;
	
	public SrchAddrSAXParser() throws ApplicationException {
		
		super();
		
		parserFact = SAXParserFactory.newInstance();
		
		try {
			parser = parserFact.newSAXParser();
		} catch (ParserConfigurationException e) {
			logger.debug("ParserConfigurationException" + e.toString());
			// 요청하신 내용을 처리할 수 없습니다.
			// {0} 함수 처리중 {1} 오류가 발생했습니다. 공통파트에 문의해 주십시오.
			throw new ApplicationException("APCME0000", new Object[] {},new Object[] { "SrchAddrSAXParser", e.toString() });
		} catch (SAXException e) {
			logger.debug("SAXException" + e.toString());
			// 요청하신 내용을 처리할 수 없습니다.
			// {0} 함수 처리중 {1} 오류가 발생했습니다. 공통파트에 문의해 주십시오.
			throw new ApplicationException("APCME0000", new Object[] {},new Object[] { "SrchAddrSAXParser", e.toString() });
		}
		
	}
	
	
	// 문서시작시 핸들링
	@Override
	public void startDocument() throws SAXException {
		// 초기값생성
		cmz009svc00out = new CMZ009SVC00Out();
		addrList = new ArrayList<CMZ009SVC00Sub>();
		cmz009svc00out.setAddrList(addrList);
	}

	// 태그시작시 핸들링
	@Override
	public void startElement(String uri, String localName, String tagName, Attributes attributes) {
		this.tagName = tagName;
		
		if (JIBUN_NAME_SERVER_URL.equals(sourceUrl)) {
			// 지번주소 로직
			if ("jibun".equals(tagName)) {
				// jibun 태그가 시작할때 마다 주소정보 인스턴스를 생성한다 
				cmz009svc00sub = new CMZ009SVC00Sub();
			}
		} else if (ROAD_NAME_SERVER_URL.equals(sourceUrl)) {
			// 도로명주소 로직
			if ("road".equals(tagName)) {
				// jibun 태그가 시작할때 마다 주소정보 인스턴스를 생성한다 
				cmz009svc00sub = new CMZ009SVC00Sub();
			}
		} else if (REFIND_ZIPCODE_SERVER_URL.equals(sourceUrl)) {
			// 주소정재 로직
			if ("data".equals(tagName)) {
				// data 태그가 시작할때 마다 주소정보 인스턴스를 생성한다 
				cmz009svc00sub = new CMZ009SVC00Sub();
			}
		}
		
		// 입력된 데이터는 출력하지 않는다
		if ("input".equals(tagName)) {
			cmz009svc00sub = null;
		}
	}
	
	// 태그내용 핸들링
	@Override
	public void characters(char[] tagValue, int startIdx, int endIdx) throws SAXException {
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(tagValue, startIdx, endIdx);
		
		String tagValueString = stringBuffer.toString();
		
		// 에러코드,메시지 매핑
		if ("errorcode".equals(this.tagName)) {
			cmz009svc00out.setErrorcode(tagValueString);
		} else if ("errormessage".equals(this.tagName)) {
			cmz009svc00out.setErrormessage(tagValueString);
		}
		
		// 주소정재 에러코드,메시지 매핑
		if ("rcd3".equals(this.tagName)) {
			cmz009svc00out.setRcd3(tagValueString);
		} else if ("rmg3".equals(this.tagName)) {
			cmz009svc00out.setRmg3(tagValueString);
		}
		
		if (cmz009svc00sub == null) {
			return;
		}
		
		if (JIBUN_NAME_SERVER_URL.equals(sourceUrl)) {
			// 지번주소 매핑
			if ("sido".equals(this.tagName)) {
				cmz009svc00sub.setSido(tagValueString);
			} else if ("sigugun".equals(this.tagName)) {
				cmz009svc00sub.setSigungu(tagValueString);
			} else if ("dong".equals(this.tagName)) {
				cmz009svc00sub.setDong(tagValueString);
			} else if ("bunji".equals(this.tagName)) {
				cmz009svc00sub.setBunji(tagValueString);
			} else if ("detalAddr".equals(this.tagName)) {
				cmz009svc00sub.setDtlAddr(tagValueString);
			} else if ("zipCode".equals(this.tagName)) {
				cmz009svc00sub.setZipcode(tagValueString);
			}
		} else if (ROAD_NAME_SERVER_URL.equals(sourceUrl)) {
			// 도로명주소 매핑
			if ("sidoNm".equals(this.tagName)) {
				cmz009svc00sub.setSido(tagValueString);
			} else if ("sigunguNm".equals(this.tagName)) {
				cmz009svc00sub.setSigungu(tagValueString);
			} else if ("umNm".equals(this.tagName)) {
				cmz009svc00sub.setDong(tagValueString);
			} else if ("rdNm".equals(this.tagName)) {
				cmz009svc00sub.setRoad(tagValueString);
			} else if ("bldNo".equals(this.tagName)) {
				cmz009svc00sub.setBldgMaiNo(tagValueString);
			} else if ("bldNm".equals(this.tagName)) {
				cmz009svc00sub.setBldgNm(tagValueString);
			} else if ("zipcode".equals(this.tagName)) {
				cmz009svc00sub.setNewZipcode(tagValueString);
			}
		} else if (REFIND_ZIPCODE_SERVER_URL.equals(sourceUrl)) {
			// 주소정재 매핑
			if ("node".equals(this.tagName)) {
				cmz009svc00sub.setNode(tagValueString);
			} else if ("display".equals(this.tagName)) {
				cmz009svc00sub.setDisplay(tagValueString);
			} else if ("gubun".equals(this.tagName)) {
				cmz009svc00sub.setAddrDivNm(tagValueString);
			} else if ("zipm6".equals(this.tagName)) {
				cmz009svc00sub.setZipcode(tagValueString);
			} else if ("addr1h".equals(this.tagName)) {
				cmz009svc00sub.setAddr1(tagValueString);
			} else if ("stdaddr".equals(this.tagName)) {
				cmz009svc00sub.setAddr2(tagValueString);
			} else if ("gisx".equals(this.tagName)) {
				cmz009svc00sub.setGisx(tagValueString);
			} else if ("gisy".equals(this.tagName)) {
				cmz009svc00sub.setGisy(tagValueString);
			} else if ("Addrps".equals(this.tagName)) {
				cmz009svc00sub.setAddrps(tagValueString);
			} else if ("zipr6".equals(this.tagName)) {
				cmz009svc00sub.setNewZipcode(tagValueString);
			} else if ("nadr1s".equals(this.tagName)) {
				cmz009svc00sub.setNewAddr1(tagValueString);
			} else if ("nadr3s".equals(this.tagName)) {
				cmz009svc00sub.setNewAddr2(tagValueString);
			} else if ("nadreh".equals(this.tagName)) {
				cmz009svc00sub.setNewAddrEtc1(tagValueString);
			} else if ("nadrem".equals(this.tagName)) {
				cmz009svc00sub.setNewAddrEtc2(tagValueString);
			} else if ("nadreg".equals(this.tagName)) {
				cmz009svc00sub.setNewAddrEtc3(tagValueString);
			} else if ("nnmx".equals(this.tagName)) {
				cmz009svc00sub.setNnmx(tagValueString);
			} else if ("nnmy".equals(this.tagName)) {
				cmz009svc00sub.setNnmy(tagValueString);
			} else if ("nnmz".equals(this.tagName)) {
				cmz009svc00sub.setNnmz(tagValueString);
			}
		}
	}

	// 태그종료시 핸들링
	@Override
	public void endElement(String uri, String localName, String tagName)
			throws SAXException {
		if (JIBUN_NAME_SERVER_URL.equals(sourceUrl)) {
			// 지번주소 로직
			if ("jibun".equals(tagName)) {
				// jibun 태그가 끝날때 마다 주소정보 인스턴스를 생성한다 
				if (cmz009svc00sub != null && addrList !=null) {
					addrList.add(cmz009svc00sub);
				}
			}
		} else if (ROAD_NAME_SERVER_URL.equals(sourceUrl)) {
			// 도로명주소 로직
			if ("road".equals(tagName)) {
				// road 태그가 끝날때 마다 주소정보 인스턴스를 생성한다 
				if (cmz009svc00sub != null && addrList !=null) {
					addrList.add(cmz009svc00sub);
				}
			}
		} else if (REFIND_ZIPCODE_SERVER_URL.equals(sourceUrl)) {
			// 주소정재 로직
			if ("data".equals(tagName)) {
				// data 태그가 끝날때 마다 주소정보 인스턴스를 생성한다 
				if (cmz009svc00sub != null && addrList !=null) {
					addrList.add(cmz009svc00sub);
				}
			}
		}
	}
	
	public void parse(String sourceUrl, Map<String, Object> parameters) throws ApplicationException {
		
		InputStream requestInputStream = null;
		
		try {
			String addressServerIp = "";
			String mode = LApplicationContext.getSystemMode();
			
			addressServerIp = System.getProperty(POST_SVC_ADDR, ADDRESS_SERVER_IP);  // 도로명주소 서버 URL 변경. 2016.11.28
			
			logger.debug("mode {} , addressServerIp:{}", mode, addressServerIp);
			
			String param = urlEncodeUTF8(parameters);
			logger.debug("request URL : " + addressServerIp + sourceUrl + param);
			
			this.sourceUrl = sourceUrl;
			
			URL requestURL = new URL(addressServerIp + sourceUrl + param);
			URLConnection requestConnection = requestURL.openConnection();
			
			// URL타임아웃설정
			requestConnection.setConnectTimeout(30000);
			requestConnection.setReadTimeout(30000);
			
			requestInputStream = requestConnection.getInputStream();
			
			parser.parse(requestInputStream, this);
		} catch (SAXException e) {
			logger.debug("SAXException" + e.toString());
			// 요청하신 내용을 처리할 수 없습니다.
			// {0} 함수 처리중 {1} 오류가 발생했습니다. 공통파트에 문의해 주십시오.
			throw new ApplicationException("APCME0000", new Object[] {},new Object[] { "SrchAddrSAXParser", e.toString() });
		} catch (IOException e) {
			logger.debug("IOException" + e.toString());
			// 요청하신 내용을 처리할 수 없습니다.
			// {0} 함수 처리중 {1} 오류가 발생했습니다. 공통파트에 문의해 주십시오.
			throw new ApplicationException("APCME0000", new Object[] {},new Object[] { "SrchAddrSAXParser", e.toString() });
		} finally {
			try {
				requestInputStream.close();
			} catch (IOException e) {
				logger.debug("[IOException] URL input스트림 닫는중 오류");
			}
		}
	}
	
	/**
	 * <pre>
	 * MethodName : urlEncodeUTF8
	 * </pre>
	 * @param map
	 * @return
	 */
	private String urlEncodeUTF8(Map<?, ?> map) {
		StringBuilder sb = new StringBuilder();
		
		for (Map.Entry<?, ?> entry : map.entrySet()) {
			if (sb.length() > 0) {
				sb.append("&");
			} else {
				sb.append("?");
			}
			
			String key = ""; 
			if (entry != null && entry.getKey() != null) {
				key = urlEncodeUTF8(entry.getKey().toString());
			}
			
			String value = "";
			if (entry != null && entry.getValue() != null) {
				value = urlEncodeUTF8(entry.getValue().toString());
			}
			
			sb.append(String.format("%s=%s", key, value));
		}
		return sb.toString();
	}
	
	/**
	 * <pre>
	 * MethodName : urlEncodeUTF8
	 * </pre>
	 * @param str String
	 * @return String
	 */
	private String urlEncodeUTF8(String str) {
		try {
			return URLEncoder.encode(str, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new UnsupportedOperationException(e);
		}
	}

	// 주소XML 파싱 결과 조회
	public CMZ009SVC00Out getSrchAddrResult() {
		return cmz009svc00out;
	}

}