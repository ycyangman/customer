import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import org.springframework.util.ClassUtils;
import org.swaf.foundation.crypto.EncKey;

public class Test {

	private static final String FOLDER_SEPARATOR= "/";
	
	public static String getFilename( String path)
	{
		if( path== null)	return null;
		int separatorindex= path.lastIndexOf( FOLDER_SEPARATOR);
		return separatorindex!= -1 ? path.substring( separatorindex+ 1) : path;
	}	
	
	public static String getFilePath(String path) {
		
		if( path== null)	return null;
		
		int folderIndex = path.lastIndexOf( FOLDER_SEPARATOR);
		return folderIndex > -1 ? path.substring(0, folderIndex) : null;
		
	}
	
	public static void main(String[] args) throws Exception {
		
		/*
		String res = "D:/eclipse/workspace/sample-online/target/classes/";		
		String path = "D:\\eclipse\\workspace\\sample-online\\target\\classes\\kr\\ezinsurance\\sample\\svc\\CM000SVC.class";
				
		path = path.replace("\\", "/");
		path = path.replace(res, "");
		System.out.println(getFilePath(path));
		*/
		
		String fqClassName = "kr.ezinsurance.sample.svc.CM000SVC";
		
		String svcPackage = ClassUtils.getPackageName(fqClassName);
		
		System.out.println(svcPackage);
		
		
		EncKey wuser=new EncKey("swaf_key".getBytes(), "ciper4Dcet".getBytes(), "salt".getBytes());
		
		FileOutputStream fos=new FileOutputStream("_key");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(wuser);
		oos.close();
		
	}
}
