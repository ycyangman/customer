package org.swaf.admin.annotation;

import org.swaf.admin.context.Auth;

public @interface AdminService {

	Auth[] auths() default {};
}
