package org.swaf.admin.aspect;

import java.lang.reflect.Method;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.swaf.admin.annotation.AdminService;
import org.swaf.admin.context.AdminContext;
import org.swaf.admin.context.Auth;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.exception.AuthException;
import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.property.PropertyManager;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
public class AdminServiceAspect {

	@Autowired
	PropertyManager pm;
	
	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	CacheClient<String> cache;
	
	@Before("@annotation(org.swaf.admin.annotation.AdminService)")
	public void beforService(JoinPoint joinPoint) throws Throwable {
		
		log.debug("before advice for admin service .... {}", joinPoint.getTarget().getClass().getTypeName());
		
		AdminContext ctx = (AdminContext)ContextContainer.get();
		
		checktokenAndSetUserInfo();
		
		String methodName = joinPoint.getSignature().getName();
		Method[] methods = joinPoint.getTarget().getClass().getDeclaredMethods();
		
		Method method = null;
		for(Method m : methods) {
			if(m.getName().equals(methodName)) {
				method = m;
				break;
			}
		}
		
		if(method == null) {
			log.warn("could not find method auth info. method name : {}.", methodName);
			return;
		}
		
		
		Auth[] auths = method.getDeclaredAnnotation(AdminService.class).auths();
		
		if(auths != null) {
			long permit = 0;
			for(Auth auth : auths) {
				permit += auth.getVal();
			}
			
			log.debug("methodName :: {}", methodName);
			log.debug("permit :: {}", permit);
			log.debug("roles :: {}", ctx.getRoles());
			log.debug("auth check :: {}", ctx.getRoles() & permit);

			if((ctx.getRoles() & permit) ==0L) {
				throw new AuthException("ADM00003");
			}
			
		}

	}
	
	private void checktokenAndSetUserInfo() {
		
		AdminContext ctx = (AdminContext)ContextContainer.get();
		
		if(ctx==null) {
			return;
		}
		
		String userInfoString = cache.get(String.format("admtoken.%s.%s", ctx.getUsrId(), ctx.getAuthToken()), String.class);
		
		if(StringUtils.isEmpty(userInfoString)) {
			
			log.error("could not find the auth token.. {}", ctx.getAuthToken());
			
			throw new SysException("ADM00009");
		}
		
		//TODO
		
	}
}
