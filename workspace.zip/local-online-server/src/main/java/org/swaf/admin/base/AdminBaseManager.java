package org.swaf.admin.base;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.crypto.DataEncryptionManager;
import org.swaf.foundation.property.PropertyManager;

@Component
public class AdminBaseManager {

	@Autowired
	@Qualifier("swafSession")
	protected SqlSessionTemplate sqlSession;
	
	@Autowired
	protected PropertyManager pm;
	
	@Autowired
	protected DataEncryptionManager crypto;
	
	@Autowired
	protected CacheClient<String> cache;
	
	
}
