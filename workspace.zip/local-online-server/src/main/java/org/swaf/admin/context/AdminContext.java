package org.swaf.admin.context;

import org.swaf.foundation.context.DefaultContext;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class AdminContext extends DefaultContext {

	String authToken;
	String userIpAd;
	
	long roles;
	String method;
	String callUrl;
	String reqDtlCtnt;
}
