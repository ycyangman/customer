package org.swaf.admin.context;

import lombok.Data;

@Data
public class AdminHeader {

	String usLang;
	String usrNo;
	String usrIpAd;
	String authToken;
	String tz;
	String procRscd;
	int resultCnt;
}
