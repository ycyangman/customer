package org.swaf.admin.context;

import lombok.Getter;

public enum Auth {
	ALL (0xFFFFFFFF)
	,FWK_ADM(0x00000008)
	,APP_ADM(0x00000002)
	,USR_ADM(0x00000004)
	,GENERAL_USR(0x00000001);
	
	@Getter final int val;
	
	private Auth(int val) {
		this.val=val;
	}
}
