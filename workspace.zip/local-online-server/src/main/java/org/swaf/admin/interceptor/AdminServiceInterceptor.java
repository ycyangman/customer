package org.swaf.admin.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.swaf.admin.context.AdminContext;
import org.swaf.admin.context.AdminHeader;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.property.PropertyManager;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class AdminServiceInterceptor extends HandlerInterceptorAdapter{

	@Autowired
	PropertyManager pm;
	
	@Autowired
	ObjectMapper mapper;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		AdminHeader header = getAdminHeader(request);
		
		return super.preHandle(request, response, header);
	}
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
		super.postHandle(request, response, handler, modelAndView);
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		
		registerWorkHistry();
	}
	
	private AdminHeader getAdminHeader(HttpServletRequest request) throws Exception {
		String swafAdminHeader = request.getHeader("admin-header");
		
		AdminHeader adminHeader = mapper.readValue(swafAdminHeader, AdminHeader.class);
		
		adminHeader.setUsrIpAd(request.getRemoteAddr());
		
		return adminHeader;
	}
	
	//작업이력등록
	private void registerWorkHistry() {
		
		AdminContext ctx = (AdminContext)ContextContainer.get();
		
		
	}
	
}
