package org.swaf.admin.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.property.PropertyManager;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class AdminBaseController {

	
	@Autowired
	protected ObjectMapper mapper;
	
	@Autowired
	protected PropertyManager pm;
	
	@Autowired
	protected MessageManager mm;
	
}
