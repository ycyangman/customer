package org.swaf.admin.services.messages;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.ResponseBody;
import org.swaf.admin.annotation.AdminService;
import org.swaf.admin.base.AdminBaseManager;
import org.swaf.admin.context.AdminContext;
import org.swaf.admin.context.Auth;
import org.swaf.admin.services.messages.manager.MessageManager;
import org.swaf.admin.services.messages.model.MM011In;
import org.swaf.admin.services.messages.model.MM011Out;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.util.APSStringUtils;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
public class MessageController extends AdminBaseManager{

	@Autowired
	@Qualifier("swaf-admin-message-manager")
	MessageManager messageManager;
	
	
	@ResponseBody
	@GetMapping("/message/messages")
	@AdminService(auths= {Auth.ALL})
	public MM011Out mm011 (@ModelAttribute MM011In in) {
		
		AdminContext ctx = (AdminContext)ContextContainer.get();
		
		if(log.isDebugEnabled()) {
			log.debug("start MM011 Service :::");
		}
		ctx.setReqDtlCtnt(APSStringUtils.convertToJsonString(in));
		
		HashMap<String, Object> param = new HashMap<>();
		
		if(StringUtils.isEmpty(in.getMsgId())) {
			param.put("condMsgId", "N");
			param.put("msgId", "");
		}
		else {
			param.put("condMsgId", "Y");
			param.put("msgId", in.getMsgId());
		}
		
		if(StringUtils.isEmpty(in.getMsgCtnt())) {
			param.put("condMsgCtnt", "N");
			param.put("msgCtnt", "");
		}
		else {
			param.put("condMsgCtnt", "Y");
			param.put("msgCtnt", in.getMsgCtnt());
		}
		
		
		if(StringUtils.isEmpty(in.getLang())) {
			param.put("condLang", "N");
			param.put("lang", "");
		}
		else {
			param.put("condLang", "Y");
			param.put("msgId", in.getLang());
		}
		
		MM011Out out = new MM011Out();
		
		return out;
	}
	
	
	@ResponseBody
	@GetMapping("/message/refrechCaches")
	@AdminService(auths= {Auth.FWK_ADM, Auth.APP_ADM})
	public Object mm011 () {
		
		if(log.isDebugEnabled()) {
			log.debug("start MM011 Service :::");
		}
		
		messageManager.refreschCacheMessage();
		
		return null;
	}
}
