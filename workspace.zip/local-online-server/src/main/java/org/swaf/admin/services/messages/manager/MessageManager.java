package org.swaf.admin.services.messages.manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.swaf.admin.base.AdminBaseManager;

@Component("swaf-admin-message-manager")
public class MessageManager extends AdminBaseManager {

	@Autowired
	org.swaf.foundation.message.MessageManager swafMessageManager;
	
	public boolean refreschCacheMessage() {
		
		return swafMessageManager.refreshMessages();
		
	}
}
