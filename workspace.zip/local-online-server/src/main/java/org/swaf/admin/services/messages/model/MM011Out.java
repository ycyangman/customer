package org.swaf.admin.services.messages.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MM011Out {

	MessageVO[] list;
	
}
