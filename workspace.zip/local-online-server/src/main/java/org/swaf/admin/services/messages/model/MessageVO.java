package org.swaf.admin.services.messages.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MessageVO {

	String msgId;
	String lang;
	String msgCtnt;
	
	String mode="";
	String status="";
}
