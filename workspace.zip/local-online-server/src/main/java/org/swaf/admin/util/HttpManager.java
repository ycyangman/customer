package org.swaf.admin.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class HttpManager {

	ObjectMapper mapper = new ObjectMapper();
	
	public HttpServiceResponse post(String ipAd, String portNum, String path, HashMap<String, String> header, HashMap<String, String> param) {
		
		HttpServiceResponse serviceResponse = new HttpServiceResponse();
		
		RequestConfig config = RequestConfig.custom().setConnectTimeout(1000).setSocketTimeout(3000).build();
		CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(config).build();
		
		try {
			URI uri = new URI(String.format("httP://%s:%s/%s", ipAd, portNum, path));
			
			HttpPost httpPost = new HttpPost(uri);
			
			httpPost.addHeader("Content-type", "application/json");
			
			if(header != null) {
				Iterator<String> keys = header.keySet().iterator();
				while(keys.hasNext()) {
					String key = keys.next();
					httpPost.addHeader(key, header.get(key));
					
				}
			}
			String jsonParams = null;
			if(param != null) {
				jsonParams = mapper.writeValueAsString(param);
				StringEntity entity = new StringEntity(jsonParams);
				httpPost.setEntity(entity);
			}
			
			CloseableHttpResponse response = httpClient.execute(httpPost);
			
			if(response != null) {
				Header[] responseHeaders = response.getAllHeaders();
				if(responseHeaders != null) {
					HashMap<String, String> hMap = new HashMap<>();
					
					for(Header responseHeader : responseHeaders) {
						hMap.put(responseHeader.getName(), responseHeader.getValue());
						
					}
					serviceResponse.setHaders(hMap);
				}
				
			}
			
			HttpEntity entity = response.getEntity();
			if(entity != null) {
				
				byte[] buf = new byte[1024];
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				
				int len = -1;
				while((len = entity.getContent().read(buf, 0, buf.length)) != -1) {
					bos.write(buf, 0, len);
					
				}
				bos.flush();
				
				serviceResponse.setData(bos.toByteArray());
				
				if(entity.getContentType()!=null) {
					serviceResponse.setContentType(entity.getContentType().getValue());
				}
				
				if(entity.getContentEncoding()!=null) {
					serviceResponse.setEncoding(entity.getContentEncoding().getValue());
				}
				
				log.debug("HttpServiceResponse :: {}", new String(bos.toByteArray()));
				
				bos.close();
				bos = null;
			}
			
			serviceResponse.setStatusCode(response.getStatusLine().getStatusCode());
			
			
			
		}
		catch(Exception e) {
			log.error("fail to request http", e); 
			serviceResponse.setData(e.getMessage().getBytes());
			serviceResponse.setStatusCode(-1);
		}
		finally {
			
			try {
				httpClient.close();
			}
			catch(IOException e) {
				log.warn("fail to close connection", e);
			}
		}
		
		return serviceResponse;
		
	}
}
