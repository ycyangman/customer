package org.swaf.admin.util;

import java.util.Map;

import lombok.Data;

@Data
public class HttpServiceResponse {

	Map<String, String> haders;
	byte[] data;
	String encoding;
	String contentType;
	int statusCode;
}
