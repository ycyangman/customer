package org.swaf.app.cl;


import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.swaf.foundation.util.APSBeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.swaf.foundation.property.CachedPropertyManager;
import org.swaf.foundation.exception.SysException;

@Slf4j
public class AppClassLoader extends ClassLoader{

	private File[] classDirs;
	
	private HashMap<String, ClassFileInfo> loadedClassFiles = new HashMap<>();

	private List<String> loadedClassNames = new ArrayList<>();

	
	public File[] getClassDirs() {
	
		CachedPropertyManager pm = APSBeanUtils.getBean(CachedPropertyManager.class);
		String clDirs = pm.getProperty("app.class.dirs");
		
		if(StringUtils.isEmpty(clDirs)) {
			log.error("Application class path is Empty");
			
			throw new SysException("SYSE0001");
		}
		
		String[] arrDir = clDirs.split("\\s*, \\s*");
		
		ArrayList<File> classPath = new ArrayList<>();
	
		for(String dir : arrDir) {
			classPath.add(new File(dir));
			
			if(log.isInfoEnabled()) {
				log.info("classPath : {}", dir);
			}
			
		}
		
		return classPath.toArray(new File[classPath.size()]);		
	}
	
	public AppClassLoader() {
		super(AppClassLoader.class.getClassLoader());
		this.classDirs = getClassDirs();
	}
	
	public void destroy() {
		
		if (!this.loadedClassFiles.isEmpty()) {
			this.loadedClassFiles.clear();
		}
		
		if (!this.loadedClassNames.isEmpty()) {
			this.loadedClassNames.clear();
		}
	
		if(log.isInfoEnabled()) {
			log.info("########## AppClassLoader is destroyed");
		}
	}
	
	@Override
	protected void finalize() throws Throwable {
		destroy();
	}
	
	@Override
	protected Class<?> findClass(String name) throws ClassNotFoundException {
		
		log.info("#################findClass By name {}/{}", name, this.classDirs.length);
		
		Class<?> clz = null;
		
		String classFileName = name.replace('.', '/');
		
		for (int i=0; i<this.classDirs.length; i++) {
			
			
			File clzFile = new File(this.classDirs[i], classFileName + ".class");
			
			if(!clzFile.exists()) {
				continue;
			}
			
			int classFileSize = (int) clzFile.length();
			byte[] classBytes = new byte[classFileSize];
		
			
			DataInputStream in = null;
			
			try {
				in = new DataInputStream(new FileInputStream(clzFile));
				in.readFully(classBytes);
				
			}
			catch(FileNotFoundException e) {
				throw new SysException("SYSE0001", e);
			}
			catch(IOException e) {
				throw new SysException("SYSE0001", e);
			}
			finally {
				if (in != null) {
					try {
						in.close();
					} catch (IOException e) {
						//
					}
				}
				in = null;
			}
			
			synchronized(this.loadedClassFiles) {
				if(log.isInfoEnabled()) {
					log.info("########## new Class is loaded on AppClassLoader::{} / {}", name, classFileName);
				}
				
				this.loadedClassFiles.put(name, new ClassFileInfo(name, clzFile, classFileSize));
				this.loadedClassNames.add(name);
			}
			
			clz = defineClass(name, classBytes, 0, classFileSize);
			break;
		}
		
		if(clz == null) {
			throw new ClassNotFoundException(Arrays.toString(classDirs) + "/" + classFileName);
		}
		
		return clz;
	}
	
	public File getLoadedClassFile(String name) {
		return this.loadedClassFiles.get(name).getClassFile();
	}

	public int getLoadedClassFileSize(String name) {
		return this.loadedClassFiles.get(name).getClassFileSize();
	}

	public long getLoadedTime(String name) {
		return this.loadedClassFiles.get(name).getLoadedTime();
	}

	public boolean containsModifiedClassFile() {
		
		for(int i=0; i<this.loadedClassNames.size(); i++) {
			try {
				String className = (String) this.loadedClassNames.get(i);
				ClassFileInfo classFileInfo = (ClassFileInfo) this.loadedClassFiles.get(className);
				
				if(!classFileInfo.getClassFile().exists()) {
					return true; // 삭제파일 reload
				}
				else if(classFileInfo.getClassFile().lastModified() > classFileInfo.getLoadedTime()) {
					return true;
				}
				
			}
			catch(Exception e) {
				
			}
		}
		return false;
		
		
	}
	
	public int getModifiedClassFileCount() {
		
		int modifiedCnt = 0;
		
		for(int i=0; i<this.loadedClassNames.size(); i++) {
			try {
				String className = (String) this.loadedClassNames.get(i);
				ClassFileInfo classFileInfo = (ClassFileInfo) this.loadedClassFiles.get(className);
				
				if(!classFileInfo.getClassFile().exists()) {
					modifiedCnt ++; 
				}
				else if(classFileInfo.getClassFile().lastModified() > classFileInfo.getLoadedTime()) {
					modifiedCnt ++;
				}
				
			}
			catch(Exception e) {
				
			}
		}
		return modifiedCnt;		
		
	}
	
	@Override
    protected URL findResource(String name)  {

		for(int i=0; i<this.classDirs.length; i++) {
			File file = new File(this.classDirs[i], name);
			
			if(file.exists()) {
				
				try {
					return file.toURI().toURL();
				} catch (MalformedURLException e) {
					return null;
				}
				
			}
		}
		return null;
		
	}
}
