package org.swaf.app.cl;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;

import lombok.extern.slf4j.Slf4j;

import org.springframework.core.io.Resource;
import org.springframework.util.StringUtils;


import org.swaf.foundation.annotation.DM;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.annotation.BM;
import org.swaf.foundation.annotation.DBAlias;
import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.service.ServiceExecutor;
import org.swaf.foundation.util.APSBeanUtils;


@Slf4j
public class AppRegistry {

	private AppClassLoader appCl;
	
	private HashMap<String, Object> loadedObjects = new HashMap<>();
	private HashMap<String, String> loadedServices = new HashMap<>();
	
	public void init() {
		
		log.info("################### AppRegistry init #################");
		
		
		this.appCl = new AppClassLoader();
		
		
		File[] clsDirs = this.appCl.getClassDirs();
		
		//서비스로딩
		for (int i=0; i<clsDirs.length; i++) {
			
			String clsDirPath = clsDirs[i].getAbsolutePath() ;
			
			//log.info("#######clsDirPath :: {}", clsDirPath);
			
			String svcLocation = "file:/"+ clsDirPath +"/**/*SVC.class";
			try {
				Resource[] resourcs = APSBeanUtils.getResources(svcLocation);
			
				for( Resource res : resourcs) {
					//log.info("###################Resource:{}/{}" ,res.getFile().getAbsolutePath() ,  res.getFilename());
				
					String svcClassId = res.getFilename().replace(".class", "");
					
					String resPath = res.getFile().getAbsolutePath(); //D:\eclipse\workspace\sample-online\target\classes\kr\ezinsurance\sample\svc\CM000SVC.class
					String svcClass = resPath.replace( clsDirPath +"\\" , "").replace(".class", "").replace("\\", ".");
					
					//log.info("###################svcInfo :{} , {}" ,svcClassId, svcClass);
					
					loadedServices.put(svcClassId, svcClass);
					
				}
				
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	
	@SuppressWarnings("unchecked")
	public ServiceExecutor<DefaultDTO, DefaultDTO> getService(String svcId) {
		
		if(!loadedServices.containsKey(svcId)) {
			return null;
		}
		else {
			String svcClass = loadedServices.get(svcId);
			
			return getAppObject(svcClass, ServiceExecutor.class);			
		}

	}
	
	
	@SuppressWarnings("unchecked")
	public <T> T getAppObject(String className, Class<T> type) {
		
		T obj = null;
		
		if(log.isInfoEnabled()) {
			log.info("########## getAppObject  : {}", className);
		}
		
		try {
			//full package
			if(loadedObjects.containsKey(className)) {
				if(log.isInfoEnabled()) {
					log.info("########## getAppObject from local cache : {}", className);
				}
				
				obj = (T)loadedObjects.get(className);
			}
			else {
				obj = (T) appCl.loadClass(className).getDeclaredConstructor().newInstance();
				
				if(!"org.swaf.runtime.foundation.prototype.DasModule".equals(type.getSuperclass().getTypeName())) {
				
					Field[] fields = obj.getClass().getDeclaredFields();
					
					for(Field field : fields) {
						Annotation[] anns = field.getDeclaredAnnotations();
						for (Annotation ann : anns) {
							if(ann.annotationType().equals(BM.class) || ann.annotationType().equals(DM.class)) {
								
								obj.getClass().getDeclaredMethod("set"+ StringUtils.capitalize(field.getName()), field.getType())
								.invoke(obj, getAppObject(field.getType().getTypeName(), field.getType()));
								
							}
						}
					}
				}
				else {
					DBAlias dbaliasAnno = obj.getClass().getDeclaredAnnotation(DBAlias.class);
					
					if (dbaliasAnno != null) {
						String dbAlias = dbaliasAnno.value();
						obj.getClass().getMethod("setDbAlias",  String.class).invoke(obj, dbAlias);
					}
				}
				
				loadedObjects.put(className, obj);
			}
			
		}
		catch(Exception e) {
			log.error("fail to load AppOjbect {}", className, e);
			throw new SysException ("SYSE0001", e);
		}
		
		return obj;
	}
	
	public Class<?> getType(String className) {
		Class<?> type = null;
		
		try {
			type = this.appCl.loadClass(className);
		} 
		catch (ClassNotFoundException e) {
			log.error("fail to lookup the class {}", className, e);
			throw new SysException ("SYSE0001", e);
		}
		return type;
	}
	
	public Method getTypeMethod(String className, String methodName, Class<?>[] params) {
		Method method = null;
		
		try {
			method = this.appCl.loadClass(className).getDeclaredMethod(methodName, params);
		} 
		catch (Exception e) {
			log.error("fail to lookup the method {}.{}", className, methodName);
			throw new SysException ("SYSE0001", e);
		}
		return method;
	}
	
	public void refreshAppClassLoader() {
		
		synchronized(this.appCl) {
			if (this.appCl.containsModifiedClassFile() ) {
				this.appCl = createNewClassLoader();
				
				if(log.isInfoEnabled()) {
					log.info("########## AppClassLoader is repalced!!");
				}
				
				this.loadedObjects.clear();
				
				//TODO
				/*
				ScafDOMapper getterMapper = (ScafDOMapper) APSBeanUtils.getBean("getterMapper");
				getterMapper.clear();
				
				ScafDOMapper setterMapper = (ScafDOMapper) APSBeanUtils.getBean("setterMapper");
				setterMapper.clear();
				*/
				
				
			}
			else {
				if(log.isInfoEnabled()) {
					log.info("########## AppClassLoader classes are not modified!!");
				}
			}
		}

		
	}
	
	private AppClassLoader createNewClassLoader()  {
		AppClassLoader appCl = new AppClassLoader();
		
		return appCl;
	}
	
	public void destroy()  {

		this.appCl.destroy();
		if(log.isInfoEnabled()) {
			log.info("########## AppClassLoader is destroyed!!");
		}
	}
	
}
