package org.swaf.app.cl;

import java.io.File;

import lombok.Getter;

public class ClassFileInfo {

	
	@Getter
	private String className = null;
	
	@Getter
	private File classFile = null;
	
	@Getter
	private int classFileSize;
	
	@Getter
	private long loadedTime;
	
	
	public ClassFileInfo (String className, File classFile, int classFileSize ) {
		
		this.className = className;
		this.classFile = classFile;
		this.classFileSize = classFileSize;
		this.loadedTime = System.currentTimeMillis();
	}
}
