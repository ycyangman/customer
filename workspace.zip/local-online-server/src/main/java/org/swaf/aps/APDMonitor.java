package org.swaf.aps;

import lombok.extern.slf4j.Slf4j;

/**
 * APD 실행상태 체크 및 실행중이 아닐때 재실행
 * 
 * @author yangs
 *
 */
@Slf4j
public class APDMonitor implements Runnable {

	Thread th;
	AsyncProcessDaemon apd;
	APSContext context;
	
	boolean prepareStop = false;
	
	@Override
	public void run() {

		while(!this.prepareStop) {
			
			try {
				if(!checkAPD()) {
					startAPD();
				}
				
				Thread.sleep(60000L);
			}
			catch(InterruptedException e) {
				log.info("APDMonitor InterruptedException occurred");
				break;
			}
		}
		
		stopAPD();
	}
	
	private boolean checkAPD() {
		boolean checkResult = true;
		if(this.th == null) {
			checkResult = false;
		}
		else if(this.th.isAlive()) {
			checkResult = false;
		}
		
		return checkResult;
	}
	
	public void init(APSContext context) {
		this.context = context;
	}
	
	public void startAPD() {
		if((this.th != null) && (this.th.isAlive())) {
			stopAPD();
			this.th = null;
		}
		
		this.apd = new AsyncProcessDaemon();
		this.apd.init(this.context);
		
		this.th = new Thread(this.apd);
		this.th.setDaemon(true);
		this.th.start();
	}

	public void stopAPD() {
		if(this.th == null) {
			return;
		}
		
		if(this.apd != null) {
			this.apd.setPrepareStop(true);
			this.th.interrupt();
			this.apd = null;
		}
		this.th = null;
	}
	
	public boolean isPrepareStop() {
		return this.prepareStop;
	}
	
	public void setPrepareStop(boolean prepareStop) {
		this.prepareStop = prepareStop;
	}
	
	
}
