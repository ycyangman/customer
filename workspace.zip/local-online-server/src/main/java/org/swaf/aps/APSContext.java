package org.swaf.aps;

import java.util.HashMap;

import org.swaf.aps.db.SqlManager;
import org.swaf.aps.vo.HandlerDTL;

import lombok.Data;

@Data
public class APSContext {

	long periodOfExecutorTracker = 10000L;
	long periodOfCheckState = 5000L;
	long periodOfMoveToActive = 6000L;
	
	String instanceId;
	String state;
	
	int retryLimit;
	int chunkSize;
	
	SqlManager sqlManager;
	
	String dbDriver;
	String dbUrl;
	String dbUsr;
	String dbPwd;
	
	HashMap <String, HandlerDTL> handlerMap;
		
	
}
