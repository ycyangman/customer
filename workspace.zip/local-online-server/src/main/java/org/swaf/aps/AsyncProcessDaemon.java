package org.swaf.aps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Timer;

import org.swaf.aps.db.SqlManager;
import org.swaf.aps.vo.ApsInstanceVO;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * APS 메인데모
 * 데몬의 상태를 (Active, inactive)를 DB에서 읽어서 주기적으로  UPDATE
 * Active 상태일때 ExecuteTrackerTask 반복실행
 * inActive 상태일때 MoveToActiveTask 반복실행
 * 
 * @author yangs
 *
 */


@Slf4j
public class AsyncProcessDaemon implements Runnable {

	APSContext context;
	Timer timerForExecutorTracker;
	Timer timerForMoveActive;
	
	ExecuteTrackerTask executeTrackerTask; 
	MoveToActiveTask moveToActiveTask;
	
	
	Connection conn;
	boolean prepareStop = false;
	
	public void init(APSContext context) {
		
		this.context = context;
		
		try {
			this.conn = DriverManager.getConnection(context.getDbUrl(), context.getDbUsr(), context.getDbPwd());
			
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		
	}
	
	@Override
	public void run() {

		String contentState = "0";
		boolean stateChanged = false;
		
		this.timerForExecutorTracker = new Timer();
		this.timerForMoveActive = new Timer();
		
		try {
			setInactive();
			
			startMoveToActiveTask();
			
			while (!this.prepareStop) {
				
				ApsInstanceVO instance = getInstanceStatus();
				if(instance != null) {
					this.context.setState(instance.getApsLastStcd());
				}
				
				if(!this.context.getState().equals(contentState)) {
					stateChanged = true;
					contentState = this.context.getState();
					
				}
				else {
					stateChanged = false;
				}
				
				if ( (stateChanged) && ("0".equals(contentState))) {
					proceedToInactive();
				}
				else if ( (stateChanged) && ("1".equals(contentState))) {
					proceedToActive();
				}
				else if(stateChanged) {
					log.warn("데몬의 상태를 확인할 수 없어 종료합니다.");
					break;
				}
				setStatus();
				
				try {
					Thread.sleep(this.context.periodOfCheckState);
				}
				catch(InterruptedException e ) {
					log.info("APD is InterruptedException.. APD 종료");
					break;
				}
			}//end of while
			
			log.info("APD 데몬이 중지됨");
		}
		catch(Exception e) {
			log.error("APD is InterruptedException.. APD 종료", e);
		}
		finally {
			removeStatus();
			
			if(this.conn != null) {
				
				try {
					this.conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				this.conn = null;
				
			}
			
			this.timerForExecutorTracker.cancel();
			this.timerForMoveActive.cancel();
			this.timerForExecutorTracker.purge();
			this.timerForMoveActive.purge();
			
			this.timerForExecutorTracker = null;
			this.timerForMoveActive = null;
		}
	}
	
	private void setStatus() {
		PreparedStatement pstmt = null;
		
		SqlManager sqlManager = this.context.getSqlManager();
		try {
			this.conn.setAutoCommit(false);
			
			pstmt = this.conn.prepareStatement(sqlManager.getSql("apsinstnacee.u01"));
			
			long current = System.currentTimeMillis();
			
			pstmt.setString(1, this.context.getState());
			pstmt.setTimestamp(2, new Timestamp(current));
			pstmt.setString(3, this.context.getInstanceId());
			
			pstmt.executeUpdate();
			
			this.conn.commit();
			
		}
		catch(Exception e) {
			log.error("인스턴스 상태변경 실패",  e);
		}
		finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				pstmt = null;
			}
		}
	}
	
	private void startMoveToActiveTask() {
		if(this.timerForMoveActive != null) {
			this.moveToActiveTask.cancel();
			this.timerForExecutorTracker.purge();
			
		}
		
		this.moveToActiveTask = new MoveToActiveTask(this.context);
		this.timerForExecutorTracker.scheduleAtFixedRate(moveToActiveTask, 60000L, this.context.getPeriodOfMoveToActive());
		
		log.info("[{}] timerForMoveActive start", this.context.getInstanceId());
	}
	
	private void stopMoveToActiveTask() {
		if(this.timerForMoveActive != null) {
			this.moveToActiveTask.cancel();
			this.timerForExecutorTracker.purge();
			
			this.timerForMoveActive = null;
		}
		
		
		log.info("[{}] timerForMoveActive stop", this.context.getInstanceId());
	}
	
	private void startExecuteTrackerTask() {
		if(this.executeTrackerTask != null) {
			this.executeTrackerTask.cancel();
			this.timerForExecutorTracker.purge();
			
		}
		
		this.executeTrackerTask = new ExecuteTrackerTask(this.context);
		this.timerForExecutorTracker.scheduleAtFixedRate(moveToActiveTask, 60000L, this.context.getPeriodOfMoveToActive());
		
		log.info("[{}] timerForMoveActive start", this.context.getInstanceId());
	}

	private void stopExecuteTrackerTask() {
		if(this.moveToActiveTask != null) {
			this.moveToActiveTask.cancel();
			this.timerForExecutorTracker.purge();
			
			this.moveToActiveTask = null;
		}
				
		log.info("[{}] stopExecuteTrackerTask stopped!!", this.context.getInstanceId());
	}
	
	public boolean isPrepareStop() {
		return this.isPrepareStop();
	}

	public void setPrepareStop(boolean prepareStop) {
		this.prepareStop = prepareStop;
		
		if(prepareStop) {
			log.info("APD 데몬중지");
		}
		
		stopExecuteTrackerTask();
		stopMoveToActiveTask();
	}
	
	private void removeStatus() {
		PreparedStatement pstmt = null;
		
		SqlManager sqlManager = this.context.getSqlManager();
		try {
			this.conn.setAutoCommit(false);
			
			pstmt = this.conn.prepareStatement(sqlManager.getSql("apsinstnacee.d01"));
						
			pstmt.setString(1, this.context.getState());
			
			pstmt.executeUpdate();
			
			this.conn.commit();
			
		}
		catch(Exception e) {
			log.error("인스턴스 상태변경 실패",  e);
		}
		finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				pstmt = null;
			}
		}
	}
	
	private void setInactive() {
		PreparedStatement pstmt = null;
		
		SqlManager sqlManager = this.context.getSqlManager();
		try {
			this.conn.setAutoCommit(false);
			
			pstmt = this.conn.prepareStatement(sqlManager.getSql("apsinstnacee.u03"));
						
			pstmt.setString(1, this.context.getState());
			
			pstmt.executeUpdate();
			
			this.conn.commit();
			
		}
		catch(Exception e) {
			log.error("인스턴스 상태변경 실패",  e);
		}
		finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				pstmt = null;
			}
		}
	}

	private void proceedToActive() {
		log.info("데몬을 inactive 상태로 전환합니다.");
		
		stopMoveToActiveTask();
		startExecuteTrackerTask();
	}
	
	private void proceedToInactive() {
		log.info("데몬을 inactive 상태로 전환합니다.");
		
		stopExecuteTrackerTask();
		startMoveToActiveTask();
	}
	
	private ApsInstanceVO getInstanceStatus() {
		
		ApsInstanceVO result = null;
		
		PreparedStatement pstmt = null;
		
		SqlManager sqlManager = this.context.getSqlManager();
		try {
			pstmt = this.conn.prepareStatement(sqlManager.getSql("apsinstnacee.s01"));
						
			pstmt.setString(1, this.context.getInstanceId());
			
			ResultSet rs = pstmt.executeQuery();
			
			if (rs.next()) {
				if (result == null) {
					result = new ApsInstanceVO();
				}
				result.setApsInsNm(rs.getString("apsInsNm"));
				result.setApsLastStcd(rs.getString("apsLastStcd"));
				result.setLastChgDtm(rs.getTimestamp("lastChgDtm"));
			}
			
			
		}
		catch(Exception e) {
			log.error("인스턴스 상태변경 실패",  e);
		}
		finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				pstmt = null;
			}
		}
		
		return result;
	}
}
