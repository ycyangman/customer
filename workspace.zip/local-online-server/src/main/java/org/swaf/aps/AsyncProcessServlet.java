package org.swaf.aps;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.swaf.aps.db.SqlManager;
import org.swaf.aps.vo.HandlerDTL;

import lombok.extern.slf4j.Slf4j;
/*
 * 
 * 온라인서비스를 비동기적으로 지연처리하는 데몬
 * 
 * */

@Slf4j
public class AsyncProcessServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	APDMonitor monitor;
	Thread monitorThread;
	SampleWork sampleWork;
	APSContext context;
	
	private APSContext initContext(ServletConfig config) {
		
		APSContext context = new APSContext();
		
		String apsConfigPath = System.getProperty("aps.config.path");
		FileInputStream in = null;
		
		try {
			in = new FileInputStream(new File(apsConfigPath)) ;
			
			Properties conf = new Properties();
			conf.load(in);
			
			context.setPeriodOfExecutorTracker(Long.parseLong(conf.getProperty("period.execute.tracker", "10000")));
			context.setPeriodOfMoveToActive(Long.parseLong(conf.getProperty("period.move.to.active", "6000")));
			context.setPeriodOfCheckState(Long.parseLong(conf.getProperty("period.check.to.state", "5000")));
			context.setInstanceId(conf.getProperty("instance.id"));
			context.setRetryLimit(Integer.parseInt(conf.getProperty("retry.limit", "5")));
			context.setChunkSize(Integer.parseInt(conf.getProperty("chunk.size", "10")));
			
			context.setDbDriver(conf.getProperty("aps.db.driver"));
			context.setDbUrl(conf.getProperty("aps.db.url"));
			context.setDbUsr(conf.getProperty("aps.db.user.name"));
			context.setDbPwd(conf.getProperty("aps.db.user.password"));
			
			SqlManager sqlmanger = new SqlManager(conf.getProperty("sql.dir"));
			context.setSqlManager(sqlmanger);
			context.setState("0");
			
			String[] handlers = conf.getProperty("handlers").split("\\s*,\\s*");
			
			HashMap<String, HandlerDTL> handlerMap = new HashMap<>();
			for(String handler : handlers) {
				HandlerDTL handlerDTL = new HandlerDTL();
				
				handlerDTL.setService  (conf.getProperty(handler + ".handler.service"));
				handlerDTL.setOperation(conf.getProperty(handler + ".handler.operation"));
				handlerDTL.setUrl(conf.getProperty(handler + ".handler.url"));
				handlerDTL.setSysTypFlag(conf.getProperty(handler + ".handler.sysTypFlag"));
				
				handlerMap.put(handler, handlerDTL);
				
				log.info("handler key {} , 서비스 : {}.[]", handler, handlerDTL.getService(), handlerDTL.getOperation());
				
			}
			context.setHandlerMap(handlerMap);
			
		}
		catch(FileNotFoundException e) {
			log.error("", e);
			
		}
		catch(Exception e) {
			log.error("", e);
			
		}
		finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				in = null;
			}
		}
		return context;
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cmd = request.getParameter("cmd");
		
		if("sample".equals(cmd)) {
			if(this.sampleWork == null) {
				this.sampleWork = new SampleWork();
				this.sampleWork.init(context);
			}
			
//			response.getWriter().append("inserted : "  +this.sampleWork.in)
		}
		else if("status".equalsIgnoreCase(cmd)) {
			
			response.getWriter().append(String.format("%s aps status : %s", new Object[] {this.context.getInstanceId(), this.context.getState()}));
		}
		else if("test_service".equalsIgnoreCase(cmd)) {
			
			InputStream is = request.getInputStream();
			
			byte[] buf = new byte[1024];
			int read = 0;
			
			ByteArrayOutputStream bos  = new ByteArrayOutputStream();
			while((read = is.read(buf, 0, buf.length)) > 0) {
				bos.write(buf, 0, read);
			}
			bos.flush();
			
			log.info("received : {}", new String(bos.toByteArray()));
			
			bos.close();
			bos = null;
			
			try {
				Thread.sleep(15000L);
			}
			catch(InterruptedException e ) {
				e.printStackTrace();
			}
			response.getWriter().append("ok~~~~~");
		}	
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}
	
	public void destroy() {
		log.info("stop APS");
		
		stopAPDMonitor();
	
		super.destroy();
	}
	
	
	public void init(ServletConfig config) throws ServletException{
		
		super.init(config);
		
		APSContext context = initContext(config);
		this.context = context;
		
		try {
			Class.forName(context.getDbDriver());
			
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
			
		}
		
		startAPDMonitor();
	}
	
	private void startAPDMonitor() {
		this.monitor = new APDMonitor();
		this.monitor.init(this.context);
		
		this.monitorThread = new Thread(this.monitor);
		
		this.monitorThread.start();
		
		log.info("APDMonitor 를 시작했습니다. id: {}, stat:{}", this.monitorThread.getId(), this.monitorThread.getState().name());
	}

	private void stopAPDMonitor() {
		
		if(this.monitor != null) {
			this.monitor.setPrepareStop(true);
			
			this.monitorThread.interrupt();
			this.monitor = null;
			this.monitorThread = null;			
		
		}
				
		log.info("APDMonitor 중지 !!!!!!!!!!!!");
		
		try {
			Thread.sleep(5000L);
		}
		catch(InterruptedException e ) {
			e.printStackTrace();
		}
	}
	
}
