package org.swaf.aps;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

public class Encryption {

	
	private static byte[] KEY = null;
	
	public static void main(String[] args) {
		
		String cmd = null;
		String inputText = null;
		
		if( args.length != 2 ) {
			printHelp();
			
			return;
			
		}
		cmd = args[0];
		inputText = args[1];
		
		if( (!"enc".equals(cmd.toLowerCase())) && (!"dec".equals(cmd.toLowerCase()))) {
			printHelp();
		}
		
		if ("enc".equals(cmd.toLowerCase())) {
			System.out.println("[" + enc(inputText) + "]");
		}
		else {
			System.out.println("[" + dec(inputText) + "]");
		}
		
		
	}
	
	public static String enc(String text) {
		byte[] key = new byte[16];
		key = Arrays.copyOf(getKey(), 16);
		
		byte[] encypted = null;
		SecretKey sKey = new SecretKeySpec(key, "AES");
		
		Cipher c;
		try {
			c = Cipher.getInstance("AES/ECB/PKCS5PADDING");
			
			c.init(1, sKey);
		
			encypted = c.doFinal(text.getBytes("UTF_8"));
			
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {

			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		return DatatypeConverter.printBase64Binary(encypted);
				
	}
	
	public static String dec(String text) {
		byte[] key = new byte[16];
		key = Arrays.copyOf(getKey(), 16);
		
		SecretKey sKey = new SecretKeySpec(key, "AES");		
		Cipher c;
		byte[] resutls = null;
		
		try {
			c = Cipher.getInstance("AES/ECB/PKCS5PADDING");
			
			c.init(2, sKey);
		
			resutls = c.doFinal(DatatypeConverter.parseBase64Binary(text));
			
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {

			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}
		
		return new String(resutls);
				
	}
	
	public static void printHelp() {
		System.out.println("Wrong arguments");
	}
	
	public static void createKeyFile(String key) {
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		
		
		try {
			fos = new FileOutputStream("key.ser");
			oos = new ObjectOutputStream(fos);
			
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hashed = digest.digest(key.getBytes("UTF-8"));
			
			oos.writeObject(hashed);
			oos.flush();
			
			oos.close();
			fos.close();
			
			oos = null;
			fos = null;

		}
		catch(NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				oos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	private static byte[] getKey() {
		
		if( KEY == null) {
			try {
				InputStream is = Encryption.class.getClassLoader().getResourceAsStream("key.ser");
				ObjectInputStream ois = new ObjectInputStream(is);
			
				KEY = (byte[])ois.readObject();
			}
			catch(ClassNotFoundException e) {
				e.printStackTrace();
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		return KEY;
	}
}
