package org.swaf.aps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.TimerTask;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExecuteTrackerTask extends TimerTask {

	APSContext context;
	JobTracker jobTracker;
	
	Connection conn;
	
	@Override
	public void run() {

		if(this.jobTracker.getState().equals("1")) {
			
			log.info("이전 jobtracker가 아직 실행중 임");
			return;
		}
		
		this.jobTracker.run();
		
	}

	public ExecuteTrackerTask(APSContext context) {
		this.context = context;
		this.jobTracker = new JobTracker();
		this.jobTracker.init(context);
	}
}
