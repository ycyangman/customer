package org.swaf.aps;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;

import javax.net.ssl.HttpsURLConnection;

import org.swaf.aps.vo.ApsWorkVO;
import org.swaf.aps.vo.CallMessage;
import org.swaf.aps.vo.CallMessageHeader;
import org.swaf.aps.vo.HandlerDTL;
import org.swaf.aps.vo.PrcsStcd;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HandlerExecutor implements Runnable {

	ApsWorkVO apsWorkVO;
	APSContext context;
	Connection conn;
	HandlerDTL handlerDTL;
	
	public HandlerExecutor(ApsWorkVO apsWorkVO, HandlerDTL handlerDTL, APSContext context) {
		this.apsWorkVO = apsWorkVO;
		this.handlerDTL = handlerDTL;
		this.context = context;
	}



	@Override
	public void run() {

		CallMessageHeader header = null;
		
		try {
			
			if(connectDB()) {
				
				if(this.conn == null) {
					log.warn("작업 아이디 : [{}], 작업구분코드 : [{}] ::DB연결실패로 인한 처리 SKip !!", this.apsWorkVO.getWrkId(), this.apsWorkVO.getWrkDcd());
				}
			
				this.conn.setAutoCommit(false);
				
				if(changeWorkState(PrcsStcd.PROCESSING)) {
					log.debug("작업 아이디 : [{}], 작업구분코드 : [{}] :: 작업상태변경 !!", this.apsWorkVO.getWrkId(), this.apsWorkVO.getWrkDcd());
				
					this.conn.commit();
				}
				else {
					throw new Exception("작업상태변경 실패");
				}
				
				long stTm = System.currentTimeMillis();
				
				try {
					header = callTrxService();
				}
				catch(Exception e ) {
					changeWorkState(PrcsStcd.FAIL);
					this.conn.commit();
					
					throw new Exception("핸들러 호출 실패", e);
				}
				
				long edTm = System.currentTimeMillis();
				
				header.setPrcsPeriod(edTm - stTm);
				if("0".equals(header.getRstTyp())) {
					
					changeWorkState(PrcsStcd.SUCCESS);
					
				}
				else {
					
					changeWorkState(PrcsStcd.FAIL);
				}
				
			
				this.conn.commit();
			}
		}
		catch(Exception e) {
			log.error("핸들러 실행 실패", e);
		
		
			if(this.apsWorkVO.getPrcsNts() + 1 == this.context.getRetryLimit()) {
				log.warn("[재시도회수 초과] ID : {}, DCD :{}", this.apsWorkVO.getWrkId(), this.apsWorkVO.getWrkDcd());
			}
			
			if(this.conn != null) {
				CallMessageHeader forceError = new CallMessageHeader();
				forceError.setAdMsg(e.getMessage());
				forceError.setRstTyp("1");
				
				registerWorkHistroy(forceError);
				
				try {
					this.conn.commit();
				}
				catch(SQLException se) {
					
				}
			
			}
			
	
		}

	}

	
	
	private String makeCallMessage() {
		String json = null;
		ObjectMapper mapper = new ObjectMapper();
		
		CallMessage callMessage = new CallMessage();
		CallMessageHeader header = new CallMessageHeader();
		
		header.setSvcNm(this.handlerDTL.getService());
		header.setOpNm(this.handlerDTL.getOperation());
		header.setSysTypFlag(this.handlerDTL.getSysTypFlag());
		
		HashMap<String, String>  userDv = null;
		
		try {
			userDv = (HashMap<String, String> )mapper.readValue(this.apsWorkVO.getWrkParmCtnt(), new TypeReference <HashMap<String, String>>() {
			});
			callMessage.setHeader(header);
			callMessage.setUser(userDv);
			json = mapper.writeValueAsString(callMessage);
		}
		catch(Exception e) {
			log.error("전문생성에러", e);
		}
		return json;
		
	}
	
	private CallMessageHeader callTrxService() {
		URL url = null;
		
		HttpURLConnection con = null;
		String urlString = this.handlerDTL.getUrl();
		CallMessageHeader header = new CallMessageHeader();
		
		try {
			boolean isSSL = false;
			if(urlString.startsWith("https")) {
				isSSL = true;
			}
			url = new URL(urlString);
			
			if(isSSL) {
				con = (HttpsURLConnection)url.openConnection();
			}
			else {
				con = (HttpURLConnection)url.openConnection();
			}
			
			con.setConnectTimeout(3000);
			con.setReadTimeout(30000);
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			con.setRequestProperty("Accept-Encoding", "gzip, deflate, br");
			con.setRequestProperty("Accept-Language", "ko,en;q=0.9, en-Us;q=0.8");
			
			con.setDoInput(true);
			con.setDoInput(true);
			
			DataOutputStream output = new DataOutputStream(con.getOutputStream());
			String jsonTrxMessage =  makeCallMessage();
			
			output.write(jsonTrxMessage.getBytes("UTF-8"));
			output.flush();
			output.close();
			
			DataInputStream input = new DataInputStream(con.getInputStream());
			
			ObjectMapper mapper = new ObjectMapper();
			
			BufferedReader rd = new BufferedReader(new InputStreamReader(input));
			
			StringBuffer sb = new StringBuffer();
			String inputLine;
			
			while ((inputLine = rd.readLine()) != null) {
				sb.append(inputLine);
			}
			
			JsonNode headerNode = mapper.readTree(sb.toString()).path("header");
			header = (CallMessageHeader)mapper.readValue(headerNode.toString(), CallMessageHeader.class);
			
			input.close();
			con.disconnect();
			con = null;
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con != null) {
				con.disconnect();
			}
		}
		return header;
	}
	
	
	private boolean connectDB() {
		
		boolean result = false;
		
		
		try {
			this.conn = DriverManager.getConnection(this.context.getDbUrl(), this.context.getDbUsr(), this.context.getDbPwd());
			
			result = true;
			
		}
		catch(Exception e) {
			log.error("db connet error", e);
			throw new RuntimeException(e);
		}
		
		return result;
	}
	
	private void disConnectDB() {
		if(this.conn != null) {
			try {
				this.conn.close();
				
			}
			catch(Exception e) {
				log.error("db connet error", e);
				throw new RuntimeException(e);
			}
		}
	}

	private boolean registerWorkHistroy(CallMessageHeader header) {
		
		boolean result = false;
		
		return result;
	}
	
	private boolean changeWorkState(PrcsStcd toState) {
		boolean result = false;
		
		
		return result;
	}
}
