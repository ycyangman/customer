package org.swaf.aps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.swaf.aps.db.SqlManager;
import org.swaf.aps.vo.ApsWorkVO;
import org.swaf.aps.vo.HandlerDTL;
import org.swaf.aps.vo.PrcsStcd;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JobTracker {

	
	APSContext context;
	Connection conn;
	public static int activeThreadCount = 0;
	
	static final int maxThreads = 10;
	
	static Object sync1 = new Object();
	static Object sync2 = new Object();
	
	String state = "0";
	
	public void init(APSContext context) {
		this.context = context;
	}
	
	public void run() {
		this.state = "1";
		
		try {
			connectDB();
			
			List<ApsWorkVO> works = getWorks();
			
			if(works != null) {
				log.debug("to Do count {}", works.size());
			}
			
			if(works != null) {
				for (ApsWorkVO work : works) {
					
					Thread executor = getExecutor(work, this.context);
					
					log.debug("작업 아이디 : [{}], 작업구분코드 : [{}] :: 파라미터 !!", work.getWrkId(), work.getWrkDcd(), work.getWrkParmCtnt());
					
					executor.start();
				}
			}
			
			while(activeThreadCount > 0) {
				try {
					
					log.debug("Active jobs :: {}", activeThreadCount+"");
					Thread.sleep(500L);
					
				}
				catch(InterruptedException e) {
					log.warn("확인필요", e);
				}
				
			}
			log.debug("All jobs are  completed");
		}
		finally {
			this.state = "0";
			if(this.conn != null) {
				
				try {
					this.conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				this.conn = null;
				
			}
		}
	}
	
	
	private List<ApsWorkVO> getWorks() {
		
		List<ApsWorkVO> results = null;
		PreparedStatement pstmt = null;
		
		SqlManager sqlManager = this.context.getSqlManager();
		try {
			
			pstmt = this.conn.prepareStatement(sqlManager.getSql("apswork.s01"));
			
			pstmt.setString(1, PrcsStcd.NOT_PROCESSED.getVal());
			pstmt.setString(2, PrcsStcd.FAIL.getVal());
			pstmt.setInt(3, this.context.getRetryLimit());
			
			pstmt.setTimestamp(4, new Timestamp(System.currentTimeMillis() - 20000L));
			pstmt.setInt(5, this.context.getChunkSize());
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) { 
				if (rs.next()) {
					if (results == null) {
						results = new ArrayList<>();
					}
					ApsWorkVO result = new ApsWorkVO();
					
					result.setWrkId(rs.getString("wrkId"));
					result.setWrkDcd(rs.getString("wrkDcd"));
					result.setWrkDcd(rs.getString("wrkParmCtnt"));
					result.setWrkDcd(rs.getString("lastPrcsStcd"));
					result.setWrkDcd(rs.getString("prcsNts"));

					results.add(result);
					
				}
			}
			
		}
		catch(Exception e) {
			log.error("인스턴스 상태변경 실패",  e);
		}
		finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				pstmt = null;
			}
		}
		
		return results;
	}
	
	private static Thread getExecutor(ApsWorkVO apsWorkVO, APSContext context) {
		
		Thread executor = null;
		synchronized(sync1) {
			
			while (activeThreadCount > 10) {
				try {
					log.info("최대 쓰레드 갯수 [{}] 소진.... 잠시 대기중", "10");
				
					Thread.sleep(10L);
					
				}catch(InterruptedException e) {
					log.warn("getExecutor InterruptedException", e);
					
				}
				
			}
			
			activeThreadCount += 1;
			HandlerDTL handlerDTL = (HandlerDTL)context.getHandlerMap().get(apsWorkVO.getWrkDcd());
			
			executor =new Thread(new HandlerExecutor(apsWorkVO, handlerDTL, context));
		}
		
		return executor;
	}
	
	public static void returnExecutor() {
		synchronized (sync2) {
			if(activeThreadCount > 0) {
				activeThreadCount -= 1;
			}
		}
	}
	
	private void connectDB() {
		try {
			this.conn = DriverManager.getConnection(this.context.getDbUrl(), this.context.getDbUsr(), this.context.getDbPwd());
			
		}
		catch(Exception e) {
			log.error("db connet error", e);
			throw new RuntimeException(e);
		}
	}
	
	public String getState() {
		return this.state;
	}
}
