package org.swaf.aps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.TimerTask;

import org.swaf.aps.db.SqlManager;
import org.swaf.aps.vo.ApsInstanceVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MoveToActiveTask extends TimerTask {

	APSContext context;
	Connection conn;
	
	public MoveToActiveTask(APSContext context) {
		this.context = context;
	}
	
	public void run() {
		
	
		connectDB();
		
		try {
			this.conn.setAutoCommit(false);
			boolean existActiveInstance = false;
			
			List<ApsInstanceVO> instances = getAllInstancesWithLock();
			
			if(instances != null) {
				for(ApsInstanceVO instance : instances) {
					if((!"1".equals(instance.getApsLastStcd())) ||
					(System.currentTimeMillis() - instance.getLastChgDtm().getTime() > 30000L)) {
						continue;
					}
					
					existActiveInstance = true;
					
					break;
				}
			}
			if( !existActiveInstance) {
				if(!chageAllInstancesToInactive()) {
					throw new Exception("처리중단");
					
				}
				updateStatus("1");
			}
		
			this.conn.commit();
		}
		catch(Exception e) {
			try {
				this.conn.rollback();
			}
			catch(SQLException se) {
				log.warn("",se);
			}
		}
		finally {
			if(this.conn != null) {
				try {
					this.conn.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				this.conn = null;
			}
		}
	}
	
	private void connectDB() {
		try {
			this.conn = DriverManager.getConnection(this.context.getDbUrl(), this.context.getDbUsr(), this.context.getDbPwd());
			
		}
		catch(Exception e) {
			log.error("db connet error", e);
			throw new RuntimeException(e);
		}
	}
	
	private List<ApsInstanceVO> getAllInstancesWithLock() {
			
		List<ApsInstanceVO> results = null;
		PreparedStatement pstmt = null;
		
		SqlManager sqlManager = this.context.getSqlManager();
		try {
			
			pstmt = this.conn.prepareStatement(sqlManager.getSql("apsinstnacee.s02"));
			
			long current = System.currentTimeMillis();
			
			pstmt.setTimestamp(1, new Timestamp(current));
		
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) { 
				if (rs.next()) {
					if (results == null) {
						results = new ArrayList<>();
					}
					ApsInstanceVO result = new ApsInstanceVO();
					
					result.setApsInsNm(rs.getString("apsInsNm"));
					result.setApsLastStcd(rs.getString("apsLastStcd"));
					result.setLastChgDtm(rs.getTimestamp("lastChgDtm"));
					
					results.add(result);
					
				}
			}
			
		}
		catch(Exception e) {
			log.error("인스턴스 상태변경 실패",  e);
		}
		finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				pstmt = null;
			}
		}
		
		return results;
	}

	private boolean chageAllInstancesToInactive() {
		
		boolean result = false;
		PreparedStatement pstmt = null;
		
		SqlManager sqlManager = this.context.getSqlManager();
		try {
			this.conn.setAutoCommit(false);
			
			pstmt = this.conn.prepareStatement(sqlManager.getSql("apsinstnacee.u02"));
			
			long current = System.currentTimeMillis();
			
			pstmt.setTimestamp(1, new Timestamp(current));
		
			pstmt.executeUpdate();
			
			this.conn.commit();
			
			result = true;
			
		}
		catch(Exception e) {
			log.error("인스턴스 상태변경 실패",  e);
		}
		finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				pstmt = null;
			}
		}
		
		return result;
	}
	
	private void updateStatus(String toState) {
		PreparedStatement pstmt = null;
		
		SqlManager sqlManager = this.context.getSqlManager();
		try {
			this.conn.setAutoCommit(false);
			long current = System.currentTimeMillis();
			
			pstmt = this.conn.prepareStatement(sqlManager.getSql("apsinstnacee.u01"));
						
			pstmt.setString(1, toState);
			pstmt.setTimestamp(2, new Timestamp(current));
			pstmt.setString(3, this.context.getInstanceId());
			
			pstmt.executeUpdate();
			
			this.conn.commit();
			
		}
		catch(Exception e) {
			log.error("인스턴스 상태변경 실패",  e);
		}
		finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}
				catch(SQLException se) {
					log.warn("",se);
				}
				pstmt = null;
			}
		}
	}
}
