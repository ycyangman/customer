package org.swaf.aps;

import java.sql.Connection;

public class SampleWork {

	APSContext context;
	Connection conn;
	
	public void init(APSContext context) {
		this.context = context;
	}
}
