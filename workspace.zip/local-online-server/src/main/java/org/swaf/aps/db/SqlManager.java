package org.swaf.aps.db;

import java.io.File;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class SqlManager {

	
	private HashMap<String, String> sqlMap = null;
	
	public String getSql(String sqlId) {
		return (String)this.sqlMap.get(sqlId);
	}
	
	private HashMap<String, String> loadSql(String sqlDir) {
		
		HashMap<String, String> sqlMap = null;
		
		try {
			DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
			DocumentBuilder parser = f.newDocumentBuilder();
			Document xmlDoc = null;
			
			sqlMap = new HashMap<>();
			File dir = new File(sqlDir);
			File[] sqlFiles = dir.listFiles();
			
			
			for(File sqlFile: sqlFiles) {
				if(!getExt(sqlFile.getName()).equalsIgnoreCase("xml")) {
					continue;
				}
				
				xmlDoc = parser.parse(sqlFile);
				Element root = xmlDoc.getDocumentElement();
				
				NodeList sqlNodes = root.getElementsByTagName("sql");
				
				for(int i=0; i<sqlNodes.getLength(); i++) {
					Element sqlNode = (Element)sqlNodes.item(i);
					
					String sqlId = sqlNode.getAttribute("id");
					String sqlCnts = sqlNode.getTextContent();
					
					sqlMap.put(sqlId, sqlCnts);
				}
			}
			
		}
		catch(Exception e ) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		return sqlMap;
	}
	
	public SqlManager (String sqlDir) {
		this.sqlMap = loadSql(sqlDir);
	}
	
	private SqlManager () {
		
	}
	
	private String getExt(String fileName) {
		String ext = "";
		int dotIdx = fileName.lastIndexOf(".");
		if((dotIdx > 0) && (dotIdx +1<fileName.length()) ) {
			ext = fileName.substring(dotIdx + 1);
		}
		
		return ext;
	}
	
	
}
