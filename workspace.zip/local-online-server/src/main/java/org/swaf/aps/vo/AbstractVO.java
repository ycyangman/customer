package org.swaf.aps.vo;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class AbstractVO {

	Timestamp fstCrtDtm;
	String fstCrtOrgNo;
	String fstCrtrId;
	
	Timestamp lastChgDtm;
	String lasChgrId;
}
