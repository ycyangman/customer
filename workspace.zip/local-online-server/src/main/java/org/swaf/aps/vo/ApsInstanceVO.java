package org.swaf.aps.vo;


import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ApsInstanceVO extends AbstractVO {

	String apsInsNm;
	
	String apsLastStcd;
	
}
