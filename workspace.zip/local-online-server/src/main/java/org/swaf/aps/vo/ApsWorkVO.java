package org.swaf.aps.vo;


import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ApsWorkVO extends AbstractVO {

	String wrkId;
	
	String wrkDcd;
	String wrkParmCtnt;
	String lastPrcsStcd;
	
	int prcsNts;
	
}
