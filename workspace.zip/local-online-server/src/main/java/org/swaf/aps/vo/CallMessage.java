package org.swaf.aps.vo;


import java.util.HashMap;

import lombok.Data;

@Data
public class CallMessage {

	CallMessageHeader header;
	HashMap<String, String> user;
}
