package org.swaf.aps.vo;

import lombok.Data;

@Data
public class CallMessageHeader {

	String globalUid;
	String prgDvNo = "";
	String prgNo = "00";
	String callTyp = "S";
	String interfaceId = "";
	String interfaceTyp = "U";
	String medTyp = "GAP";
	String akRspDvCd = "S";
	String sysTypFlag;
	String flsys = "";
	String appNm = "GA";
	String svcNm;
	String opNm;
	String srcnNo = "";
	String txDt;
	String tdHms;
	String chrgpDeptCd = "101138";
	String chrgpMpNo = "R00000009";
	String usrId;
	String usrIpAd;
	String authToken;

	long prcsPeriod = 0L;
	/*
	 * 응답전문항목
	 */

	// 처리결과코드
	String procRscd;
	String rstTyp;
	// 메시지코드
	String msgCd;
	// 기본메시지
	String bascMsg;
	// 부가메시지
	String adMsg;
	// 다음실행명령정보
	String sysMsg;
	String nxtExeCmdInfo;
	
}
