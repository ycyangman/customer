package org.swaf.aps.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class HandlerDTL {

	
	String service;
	String operation;
	String url;
	String sysTypFlag;
}
