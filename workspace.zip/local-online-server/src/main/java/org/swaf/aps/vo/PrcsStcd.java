package org.swaf.aps.vo;

public enum PrcsStcd {

	NOT_PROCESSED("N"), PROCESSING("P"), SUCCESS("0"), FAIL("1");
	
	final String val;
	private PrcsStcd(String val) {
		this.val = val;
	}
	
	public String getVal() {
		return this.val;
	}
}
