package org.swaf.batch.config;

import java.io.FileNotFoundException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.TypeAliasRegistry;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.CacheManager;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.swaf.app.cl.AppRegistry;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.context.DASMapper;
import org.swaf.foundation.context.DasVO;
import org.swaf.foundation.context.LogLevelInfo;
import org.swaf.foundation.crypto.AESEncryptionManager;
import org.swaf.foundation.crypto.DataEncryptionManager;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.property.CachedPropertyManager;
import org.swaf.foundation.property.PropertyManager;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class BatchConfig {

	@Autowired
	ApplicationContext context;
	
	@Bean
	public ObjectMapper mapper() {
		return new ObjectMapper();
	}
	
	@Bean
	public CachedPropertyManager propertyManager() {
		return new CachedPropertyManager();
	}
	
	@Bean
	public CacheClient<LogLevelInfo> logLevelCacheClient(RedisTemplate<String, Object> redisTemplate) {
		CacheClient<LogLevelInfo>  cacheClient = new CacheClient<LogLevelInfo>(redisTemplate);
		return cacheClient;
	}
	
	@Bean(initMethod="init")
	public MessageManager messageManager() {
		return new MessageManager();
	}
	
	
	@Bean(initMethod="init", destroyMethod="destroy")
	public DataEncryptionManager dataEncryptionManager() {
		return new AESEncryptionManager();
	}
	
	
	private List<RedisNode> getRedisNodes() {
		
		PropertyManager pm = propertyManager();
		
		List<RedisNode> redisNodes = null;
		
		String cacheHosts = pm.getProperty("cache.hosts"); 
		String[] arrCacheHosts = cacheHosts.split("\\s*,\\s*");
		
		for (String cacheHost : arrCacheHosts) {
			if (redisNodes == null) {
				redisNodes = new ArrayList<>();
			}
			String[] nodeInfo = cacheHost.split("\\:");
			RedisNode redisNode = new RedisNode(nodeInfo[0], Integer.parseInt(nodeInfo[1]));
			redisNodes.add(redisNode);
		}
		
		return redisNodes;
				
	}
	
	@Bean
	public RedisConnectionFactory redisConnectionFactory() {
		
		RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration();
		
		redisClusterConfiguration.setClusterNodes(getRedisNodes());
		LettuceConnectionFactory connectionFactory = new LettuceConnectionFactory(redisClusterConfiguration);
		
		return connectionFactory;

	}
	
	@Bean
	public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.setValueSerializer(new GenericToStringSerializer<Object>(Object.class));
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		
		
		return redisTemplate;
	}
	
	@Bean
	public RedisTemplate<String, Object> appRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.setValueSerializer(new GenericToStringSerializer<Object>(Object.class));
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		
		
		return redisTemplate;
	}
	
	
	@Bean
	public CacheManager adminCacheManager(RedisConnectionFactory redisConnectionFactory) {
		
		RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
				.serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
				.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()))
				.prefixCacheNameWith("_admin_")
				.disableCachingNullValues();
		
		RedisCacheManager cacheManager = RedisCacheManager.RedisCacheManagerBuilder
				.fromConnectionFactory(redisConnectionFactory).cacheDefaults(config).build();
		
		return cacheManager;
	}
	
	@Bean
	@Primary
	public CacheManager appCacheManager(RedisConnectionFactory redisConnectionFactory) {
		
		PropertyManager pm = propertyManager();
		RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
				.serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
				.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()))
				.prefixCacheNameWith("_app_").entryTtl(Duration.ofSeconds(pm.getProperty("cache.ttl", Long.class)))
				.disableCachingNullValues();
		
		RedisCacheManager cacheManager = RedisCacheManager.RedisCacheManagerBuilder
				.fromConnectionFactory(redisConnectionFactory).cacheDefaults(config).build();
		
		return cacheManager;
	}
	
	@Bean(destroyMethod="destroy")
	public CacheClient<String> messageCacheClient(RedisTemplate<String, Object> redisTemplate) {
		
		CacheClient<String> cacheClient = new CacheClient<String>(redisTemplate);
		
		return cacheClient;
	}
	
	@Bean(destroyMethod="destroy")
	public CacheClient<String> cacheClient(RedisTemplate<String, Object> redisTemplate) {
		
		CacheClient<String> cacheClient = new CacheClient<String>(redisTemplate);
		
		return cacheClient;
	}
	
	@Bean(initMethod="init", destroyMethod="destroy")
	public AppRegistry appRegistry() {
		
		AppRegistry appRegistry = new AppRegistry();
		
		return appRegistry;
	}
	
	@Bean(destroyMethod="close")
	@Primary
	public DataSource adminDS() {
		
		PropertyManager pm = propertyManager();
		BasicDataSource ds = new BasicDataSource();
		
		ds.setDriverClassName(pm.getProperty("admin.db.driver.class"));
		ds.setUrl(pm.getProperty("admin.db.url"));
		ds.setUsername(pm.getProperty("admin.db.username"));
		
		//ds.setPassword(pm.getDecryptedProperty("admin.db.password"));
		ds.setPassword(pm.getProperty("admin.db.password"));
		
		ds.setInitialSize(pm.getProperty("admin.db.initial.size", Integer.class));
		ds.setMaxTotal(pm.getProperty("admin.db.max.size", Integer.class));
		ds.setMaxWaitMillis(pm.getProperty("admin.db.pool.wait.millis", Integer.class));
		ds.setDefaultAutoCommit(false);

		return ds;
	}

	@Bean(destroyMethod="close")
	public DataSource appDS() {
		
		PropertyManager pm = propertyManager();
		BasicDataSource ds = new BasicDataSource();
		
		ds.setDriverClassName(pm.getProperty("app.db.driver.class"));
		ds.setUrl(pm.getProperty("app.db.url"));
		ds.setUsername(pm.getProperty("app.db.username"));
		
		//ds.setPassword(pm.getDecryptedProperty("admin.db.password"));
		ds.setPassword(pm.getProperty("app.db.password"));
		
		ds.setInitialSize(pm.getProperty("app.db.initial.size", Integer.class));
		ds.setMaxTotal(pm.getProperty("app.db.max.size", Integer.class));
		ds.setMaxWaitMillis(pm.getProperty("app.db.pool.wait.millis", Integer.class));
		ds.setDefaultAutoCommit(false);

		return ds;
	}
	
	@Bean
	public DataSourceTransactionManager adminTxManager(@Qualifier("adminDS") DataSource adminDS) {
		return new DataSourceTransactionManager(adminDS);
	}
	
	@Bean
	public DataSourceTransactionManager appTxManager(@Qualifier("appDS") DataSource appDS) {
		return new DataSourceTransactionManager(appDS);
	}
	
	@Bean
	public org.apache.ibatis.session.Configuration adminSessionConfiguration() {
		PropertyManager pm = propertyManager();
		
		org.apache.ibatis.session.Configuration conf = new org.apache.ibatis.session.Configuration();
		conf.setLazyLoadingEnabled("true".equalsIgnoreCase(pm.getProperty("admin.query.lazy.loading"))? true : false);
		conf.setMapUnderscoreToCamelCase("true".equalsIgnoreCase(pm.getProperty("admin.map.use.camelcase"))? true : false);
		conf.setDefaultFetchSize(pm.getProperty("admin.fetch.size", Integer.class));
		conf.setDefaultStatementTimeout(pm.getProperty("admin.query.timeout", Integer.class));
		
		//TODO
		TypeAliasRegistry aliasRgistry = conf.getTypeAliasRegistry();
		aliasRgistry.registerAlias("adminvo", DasVO.class);
		
		return conf;
	}

	@Bean
	public SqlSessionFactory adminSessionFactory(@Qualifier("adminDS") DataSource adminDS) {
		
		SqlSessionFactory factory = null;
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		factoryBean.setDataSource(adminDS);
		
		try {
			factoryBean.setMapperLocations(context.getResources("classpath:/org/swaf/sql/**/*.xml"));
			
			org.apache.ibatis.session.Configuration conf = new org.apache.ibatis.session.Configuration();

			conf.setLazyLoadingEnabled(true);
			conf.setDefaultStatementTimeout(100);
			conf.setMapUnderscoreToCamelCase( true);
			conf.setDefaultFetchSize(1000);
			conf.setShrinkWhitespacesInSql(true);
			
			
			TypeAliasRegistry aliasRgistry = conf.getTypeAliasRegistry();
			aliasRgistry.registerAlias("adminvo", DasVO.class);
			
			factoryBean.setConfiguration(conf);
			
			//factoryBean.afterPropertiesSet();
			
			factory = factoryBean.getObject();
			
			if (log.isInfoEnabled()) {
				log.info("specified sql mapper location : [{}]", "classpath:/org/swaf/sql/**/*.xml");
			}
		}
		catch (Exception e)	{
			if (log.isWarnEnabled()) {
				log.warn("fail to create sqlSession of admin");
			}
			
		}		
		
		return factory;
	}
	
	@Bean
	public SqlSessionFactory sqlSessionFactory(@Qualifier("appDS") DataSource appDS) {
		PropertyManager pm = propertyManager();
		
		SqlSessionFactory factory = null;
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		factoryBean.setDataSource(appDS);
		
		try {
			
			String mapperResources = pm.getProperty("app.mapper.resources");
			
			if(StringUtils.isEmpty(mapperResources)) {
				if(log.isWarnEnabled()) {
					log.warn(" mapperResources not found");
				}
				
				mapperResources = "";
			}
			
			String[] resources = mapperResources.split("\\s*,\\s*");
			Resource[] res = null;
			for(String resource : resources) {

				String mapperLocation = "file:/"+ resource +"/**/*.xml";
				
				try {
					Resource[] r = context.getResources(mapperLocation);
					res = ArrayUtils.addAll(res,r);
				}
				catch(FileNotFoundException e) {
					if(log.isWarnEnabled()) {
						log.warn(" File {} not found", mapperLocation);
					}
					continue;
				}
				
				if(log.isInfoEnabled()) {
					log.info(" specified sqlmapperLocation : [{}]", mapperLocation);
				}
			}
			
			factoryBean.setMapperLocations(res);
			
			org.apache.ibatis.session.Configuration conf = new org.apache.ibatis.session.Configuration();
			conf.setLazyLoadingEnabled("true".equalsIgnoreCase(pm.getProperty("app.query.lazy.loading"))? true : false);
			conf.setMapUnderscoreToCamelCase("true".equalsIgnoreCase(pm.getProperty("app.map.use.camelcase"))? true : false);
			conf.setDefaultFetchSize(pm.getProperty("app.fetch.size", Integer.class));
			conf.setDefaultStatementTimeout(pm.getProperty("app.query.timeout", Integer.class));
			conf.setShrinkWhitespacesInSql(true);
			
			TypeAliasRegistry aliasRgistry = conf.getTypeAliasRegistry();
			aliasRgistry.registerAlias("dasvo", DasVO.class);

			factoryBean.setConfiguration(conf);
			factory = factoryBean.getObject();
			
			
		}
		catch(Exception e) {
			if(log.isWarnEnabled()) {
				log.warn(" fail to create sqlSessionFactory of Application", e);
			}
		}
		
		return factory;
	}
	

	//serviceManager.java ==> swafSession
	@Bean
	public SqlSessionTemplate swafSession(@Qualifier("adminSessionFactory") SqlSessionFactory adminSqlSessionFactory) {
		return new SqlSessionTemplate(adminSqlSessionFactory, ExecutorType.BATCH);
	}
	
	@Bean
	public SqlSessionTemplate session(@Qualifier("sqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
		return new SqlSessionTemplate(sqlSessionFactory, ExecutorType.BATCH);
	}
		
	@Bean
	public DASMapper getterMapper() {
		
		DASMapper dasMapper = new DASMapper();
		
		return dasMapper;
	}
	
	@Bean
	public DASMapper setterMapper() {
		
		DASMapper dasMapper = new DASMapper();
		
		return dasMapper;
	}
	

}
