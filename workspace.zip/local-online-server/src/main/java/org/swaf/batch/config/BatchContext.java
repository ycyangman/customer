package org.swaf.batch.config;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.swaf.batch.listener.SwafJobExecutionListener;
import org.swaf.batch.listener.SwafStepExecutionListener;

@Configuration
@PropertySources({
	@PropertySource("file:${batch.config.dir}/batch.properties")
})
@ComponentScan(basePackages= {"org.swaf.foundation"})
@Import({ BatchConfig.class })
public class BatchContext {

	@Autowired
	DataSource adminDS;
		
	@Autowired
	DataSource appDS;
	
	@Autowired
	DataSourceTransactionManager adminTxManager;
	
	@Autowired
	DataSourceTransactionManager jobTxManager;
	
	@Bean
	public BatchConfigurer batchConfigurer() {
		
		
		return new DefaultBatchConfigurer() {
			
			@Override
			protected JobRepository createJobRepository() throws Exception {
				JobRepositoryFactoryBean factroy = new JobRepositoryFactoryBean();
				
				factroy.setDataSource(adminDS);
				factroy.setTransactionManager(adminTxManager);
				factroy.setIsolationLevelForCreate("ISOLATION_READ_COMMITTED");
				factroy.setTablePrefix("ADMINBATCH_");
				factroy.setMaxVarCharLength(2500);
				factroy.setDatabaseType("MYSQL");
				
				return factroy.getObject();
				
			}
			
			@Override
			protected JobLauncher createJobLauncher() throws Exception {
				
				SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
				
				jobLauncher.setJobRepository(this.getJobRepository());
				jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
				jobLauncher.afterPropertiesSet();
								
				return jobLauncher;
			}
			
			@Override
			public PlatformTransactionManager getTransactionManager() {
								
				return jobTxManager;
			}
			
		};
	}
	
	@Bean
	SwafJobExecutionListener swafJobExecutionListener() {
		return new SwafJobExecutionListener();
	}
	
	@Bean
	SwafStepExecutionListener swafStepExecutionListener() {
		return new SwafStepExecutionListener();
	}
}
