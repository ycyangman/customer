package org.swaf.batch.context;

import lombok.Data;

@Data
public class JobInfo {

	String jobId;
	String jobNm;
	
	String bizLv1;
	String bizLv2;
	String bizLv3;
	
	int jobKndNum;
	
	String jobConfPkg;
	String jobConfClass;
	
	String logLv;
	
}
