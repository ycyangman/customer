package org.swaf.batch.listener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.MDC;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.swaf.batch.context.JobInfo;
import org.swaf.foundation.context.BatchApplicationContext;
import org.swaf.foundation.context.BatchContextHelper;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.context.ExceptionInfo;
import org.swaf.foundation.exception.BatchException;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.util.ContextUtils;


import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SwafJobExecutionListener implements JobExecutionListener {

	@Autowired
	AnnotationConfigApplicationContext context;
	
	@Override
	public void beforeJob(JobExecution jobExecution) {
		
		JobInfo jobInfo = getJobInfo(jobExecution.getJobInstance().getJobName());
		
		createBatchContext(jobInfo);
		
		setLogLevel(jobInfo);
		
		BatchApplicationContext ctx = ContextUtils.getBatchContext();
		
		ctx.setJobInstId(jobExecution.getJobInstance().getId());
		ctx.setJobExecId(jobExecution.getId());
		ctx.setGuid(String.format("%032d", jobExecution.getId()));
		
		Map<String, JobParameter> params = jobExecution.getJobParameters().getParameters();
		
		if(params != null) {
			HashMap<String, String> jobParameters = new HashMap<>();
			Iterator<String> keys = params.keySet().iterator();
			while(keys.hasNext()) {
				
				String key = keys.next();
				jobParameters.put(key, params.get(key).getValue().toString());
			}
			ctx.setJobParamers(jobParameters);
			
		}
		
		if(StringUtils.isEmpty(jobExecution.getJobParameters().getString("callSysId"))) {
			ctx.setCallSysId("NA");
		}
		else {
			ctx.setCallSysId(jobExecution.getJobParameters().getString("callSysId"));
		}
		
		log.info("########### beforeJob : [{}]{} ##########", ctx.getJobId(), ctx.getJobNm());
		
	}
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		
		BatchApplicationContext ctx = ContextUtils.getBatchContext();
		
		log.info("########### afterJob : [{}]{} ##########", ctx.getJobId(), ctx.getJobNm());
		
		if(jobExecution.getExitStatus().compareTo(ExitStatus.COMPLETED) == 0) {
			BatchContextHelper.setSuccessResult(ctx);
			
		}
		if(jobExecution.getExitStatus().compareTo(ExitStatus.STOPPED) == 0) {
			BatchContextHelper.setBatchStoppedResult(ctx);
		}
		if (jobExecution.getExitStatus().compareTo(ExitStatus.UNKNOWN) == 0 || 
			jobExecution.getExitStatus().compareTo(ExitStatus.NOOP) == 0) {
			BatchContextHelper.setBatchUnknownResult(ctx);
		}
		else {
			if(jobExecution.getAllFailureExceptions() != null && jobExecution.getAllFailureExceptions().size() > 0) {

				List<Throwable> throwables = jobExecution.getAllFailureExceptions();
				if(throwables.get(0) instanceof BatchException) {
					BatchContextHelper.setBatchErrResult(ctx, (BatchException)throwables.get(0));
				}
				else {
					BatchContextHelper.setGeneralErrResult(ctx, (Exception)throwables.get(0));
				}
				ArrayList<ExceptionInfo> exceptions = convertToExceptionInfo(null, throwables.get(0));
				
				ctx.setExTraces(exceptions.toArray(new ExceptionInfo[exceptions.size()]));
			}
		}
	}

	private ArrayList<ExceptionInfo> convertToExceptionInfo(ArrayList<ExceptionInfo> exceptionList, Throwable t) {
		
		ArrayList<ExceptionInfo> exceptions = exceptionList;
		
		if(t==null) {
			return null;
		}
		if(exceptions == null) {
			exceptions = new ArrayList<>();
		}
		
		ExceptionInfo ex = new ExceptionInfo();
		ex.setExMsg(StringUtils.mid(t.getMessage(), 0, 50));
		ex.setThrowableNm(t.getClass().getTypeName());
		
		if(t.getStackTrace() != null && t.getStackTrace().length >0) {
			StackTraceElement st = t.getStackTrace()[0];
			 ex.setExOccrClass((st.getClassName()));
			 ex.setExOccrMeth(st.getMethodName());
			 ex.setExOccrLnNum(st.getLineNumber());
			 ex.setSq(exceptions.size());
		}
		
		if(t.getCause() != null) {
			exceptions = convertToExceptionInfo(exceptions, t.getCause());
		}
		return exceptions;
	}
	
	private void createBatchContext(JobInfo jobInfo) {
		
		PropertyManager pm = context.getBean(PropertyManager.class);
		
		BatchApplicationContext ctx = new BatchApplicationContext();
		
		ctx.setJobId(jobInfo.getJobId());
		ctx.setJobNm(jobInfo.getJobNm());
		
		ctx.setJobKndNum(jobInfo.getJobKndNum());
		
		ctx.setSysEnvDscd(pm.getProperty("sys.env.dscd"));
		ctx.setProcSysId(pm.getProperty("sys.id"));
		ctx.setProcHostNm(pm.getProperty("host.name"));
		
		ctx.setBizLv1(jobInfo.getBizLv1());
		ctx.setBizLv2(jobInfo.getBizLv2());
		ctx.setBizLv3(jobInfo.getBizLv3());
		
		
		SimpleDateFormat utcHHMMSS = new SimpleDateFormat("HHmmss");
		utcHHMMSS.setTimeZone(TimeZone.getTimeZone("GMT"));
		
		SimpleDateFormat locHHMMSS = new SimpleDateFormat("HHmmss");
		locHHMMSS.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		
		SimpleDateFormat utcDateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat utcTimeFormat = new SimpleDateFormat("HHmmss");
		
		utcDateFormat.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		utcTimeFormat.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		
		Date current = new Date();
				
		ctx.setTxDt(utcDateFormat.format(current));
		ctx.setTxBgnTm(utcTimeFormat.format(current));
		ctx.setUtcDt(utcDateFormat.format(current));
		ctx.setUtcBgnTm(utcTimeFormat.format(current));
		ctx.setProcBgnTs(current.getTime());
		
		ctx.setUsLang(pm.getProperty("default.lang"));
		
		ContextContainer.set(ctx);
	}
	
	private void setLogLevel(JobInfo jobInfo) {
		String logLevel = jobInfo.getLogLv();
		if(StringUtils.isEmpty(logLevel)) {
			logLevel = "OFF";
		}
		
		MDC.put("jobId", jobInfo.getJobId());
		MDC.put("job.log.level", logLevel);
		
		
	}
	private JobInfo getJobInfo(String jobId) {
		SqlSessionTemplate sqlSession =  (SqlSessionTemplate)context.getBean("adminSession");
		JobInfo jobInfo = sqlSession.selectOne("org.swqf.batch.jobprofiles.getJobById", jobId);
		
		return jobInfo;
	}

}
