package org.swaf.batch.prototype;

import org.apache.ibatis.session.SqlSessionFactory;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.swaf.batch.listener.SwafJobExecutionListener;
import org.swaf.batch.listener.SwafStepExecutionListener;
import org.swaf.foundation.property.PropertyManager;

import lombok.Setter;

@Configuration
@EnableBatchProcessing
public class SwafBatchJob {

	
	@Autowired
	protected DataSourceTransactionManager appTxManager;
	
	@Autowired
	protected PropertyManager pm;
	
	@Autowired
	protected JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	protected StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	@Qualifier("sqlSessionFactory")
	protected SqlSessionFactory sqlSessionFactory;
	
	@Autowired
	protected JobRepository jobRepository;
	
	@Autowired
	protected JobLauncher jobLauncher;
	
	@Autowired
	JobRegistry JobRegistry;

	@Autowired
	@Setter
	PlatformTransactionManager transactionManager;
	
	//see BatchContext.java
	@Autowired
	SwafJobExecutionListener jobExecutionListener;
	
	@Autowired
	SwafStepExecutionListener stepExecutionListener;
	
	@Bean
	public DataSourceTransactionManager jobTxManager() {
		return appTxManager;
	}
	
	protected JobBuilder getJobBuilder(String jobId) {
		return jobBuilderFactory.get(jobId).listener(jobExecutionListener);
	}
	
	protected StepBuilder getStepBuilder(String stepId) {
		return stepBuilderFactory.get(stepId).listener(stepExecutionListener);
	}
}
