package org.swaf.batch.runner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.converter.DefaultJobParametersConverter;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ConfigurableJobRunner {

	public ConfigurableJobRunner() {
		
	}
	
	public static void main(String[] args) {

		List<String> newArgs = new ArrayList<String>(Arrays.asList(args));
		
		String jobIdentifier = null;
		List<String> params = new ArrayList<>();
		int count = 0;
		
		for(String arg : newArgs) {
			
			switch(count) {
			
			case 0:
				jobIdentifier = arg;
				params.add("jobName="+jobIdentifier);
				break;
				
			default:
				params.add(arg);
				break;
					
			}
			count++;
		}
		
		log.info("====================================");
		log.info("jobIdentifier : {}", jobIdentifier);
		log.info("====================================");
		
		String[] springConfig = new String[2];
		String apConfigLoc = "classpath:kr/ezinsurance/batch/quartz/batch-context.xml";
		String qzConfigLoc = "classpath:kr/ezinsurance/batch/quartz/batch-quartz.xml";
		String jbConfigLoc = "classpath:kr/ezinsurance/batch/jobx/"+jobIdentifier+".xml";
		
		springConfig[0] = apConfigLoc;
		if( jobIdentifier == null ) {
			log.info("Requested job will be executed by quartz!!");
			
			springConfig[1] = qzConfigLoc;
		}
		else {
			springConfig[1] = jbConfigLoc;
		}
		
		ConfigurableApplicationContext context = null;
		try {
			context = new ClassPathXmlApplicationContext(springConfig);
			
			if( jobIdentifier != null ) {
				
				String[] parameters = params.toArray(new String [params.size()]);
				
				JobParameters jobParameters = new DefaultJobParametersConverter()
						.getJobParameters(StringUtils.splitArrayElementsIntoProperties(parameters, "="));
				
				Job job = (Job)context.getBean(jobIdentifier);
				
				JobLauncher jobLanuncher = (JobLauncher)context.getBean(org.springframework.batch.core.launch.JobLauncher.class);
				
				jobLanuncher.run(job, jobParameters);
					
			}
		}
		catch(Throwable e) {
			log.error("", e);			
		}
		finally {
			if (context != null) {
				context.close();
			}
		}
	}
	
	
}
