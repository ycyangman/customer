package org.swaf.batch.runner;


import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.swaf.batch.config.BatchConfig;
import org.swaf.batch.config.BatchContext;
import org.swaf.batch.context.JobInfo;
import org.swaf.batch.prototype.SwafBatchJob;
import org.swaf.foundation.crypto.AESEncryptionManager;
import org.swaf.foundation.crypto.DataEncryptionManager;
import org.swaf.foundation.exception.BatchException;

import lombok.Cleanup;
import lombok.extern.slf4j.Slf4j;


/**
 * 
 * @author yangs
 * 
 * -Dbatcj.config.dir=D:/eclipse/workspace/sample-batch 
 * jzz011 filename=users.csv 11
 *
 */
@Slf4j
public class DefaultJobRunner {

	
//	protected AnnotationConfigApplicationContext context;
	protected  ConfigurableApplicationContext context;
	
	protected String jobId;
	
	public static void main(String[] args) {
		DefaultJobRunner jobRunner = new DefaultJobRunner();
		
		jobRunner.runJob(args);
	}
	
	private void printUsae() {
		log.error("Parameter >> JOB_ID callSysId=value baseDate=yyyymmdd param1=value1 param2=value2 ...");
	}
	
	protected void runJob(String[] cmdArgs) {
		
		if(cmdArgs == null || cmdArgs.length < 1)  {
			log.error("invalid command");
			printUsae();
			throw new RuntimeException("check the batch execution command");
		}
		
		this.jobId = cmdArgs[0];
		
		JobParametersBuilder builder = new JobParametersBuilder();
		JobParameters jobParams = builder.toJobParameters();
		
		
		if( cmdArgs.length > 1)  {
			for(int i=1; i<cmdArgs.length; i++) {
				String arg = cmdArgs[i];
				if(arg.contains("=")) {
					String[] kv = arg.split("\\=");
					builder.addString(kv[0], kv[0]);
				}
				else {
					builder.addString("param"+i, arg);
				}
			}
			jobParams = builder.toJobParameters();
		}
		
		execute(jobParams);
	}
	
	private void init() {
		Class<?> jobConfig;
		
		JobInfo jobInfo = getJobConfigInfo(jobId);
		
//		context = new AnnotationConfigApplicationContext();	
//		context.register(BatchConfig.class);
//		context.register(BatchContext.class);
		
		//context.register(SwafBatchJob.class);
		
		//TODO
		/*
		if (jobInfo == null) {
			log.warn("no batch information on db", jobId);

			jobInfo =new JobInfo();
			jobInfo.setJobConfPkg("kr.ezinsurance.sample.job");
			jobInfo.setJobConfClass("JCM001");
			//throw new RuntimeException("no batch information on db");
		}
		*/
		
		if (jobInfo != null) {
			
			try {
				jobConfig = (Class<?>) this.getClass().getClassLoader()
						.loadClass(jobInfo.getJobConfPkg() + "." + jobInfo.getJobConfClass());
			}
			catch (ClassNotFoundException e) {
				log.error("could not find batch config info {}", jobInfo.getJobConfClass());
				throw new RuntimeException(e);
			}

			this.jobId = this.jobId+"B";
			context = new AnnotationConfigApplicationContext(BatchConfig.class, BatchContext.class, jobConfig);
			
			//context.register(jobConfig);
			//context.refresh();
		}
		else {
			AnnotationConfigApplicationContext parent = new AnnotationConfigApplicationContext(BatchConfig.class, BatchContext.class, SwafBatchJob.class);
			
			
			String jobPath = "classpath:kr/ezinsurance/sample/job/"+this.jobId+".xml";

			context = new ClassPathXmlApplicationContext(new String[] {jobPath}, true, parent);
			
			
			//context.getAutowireCapableBeanFactory().autowireBeanProperties(BatchConfig.class,
			//		AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, false);

			//context.getAutowireCapableBeanFactory().autowireBeanProperties(BatchContext.class,
			//		AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, false);
			
			//context.getAutowireCapableBeanFactory().createBean(BatchConfig.class);
			//context.getAutowireCapableBeanFactory().createBean(BatchContext.class);
			
			//context.refresh();
	
		}

		
		
		
	}
	
	private JobInfo getJobConfigInfo(String jobId) {
		
		JobInfo jobInfo = null;
		
		try {
			File conf = null;
			String configDir = System.getProperty("batch.config.dir");
			
			log.error("configDir : {}", configDir);
			
			if(!StringUtils.isEmpty(configDir)) {
				conf = new File(configDir, "batch.properties");
			}
			
			@Cleanup FileInputStream fis = new FileInputStream(conf);
			Properties p = new Properties();
			p.load(fis);
			
			String jdbcDriver = p.getProperty("admin.db.driver.class");
			String url = p.getProperty("admin.db.url");
			String username = p.getProperty("admin.db.username");
			String password = p.getProperty("admin.db.password");
			
			if(!StringUtils.isEmpty(p.getProperty("key.dir"))) {
				System.setProperty("key.dir", p.getProperty("key.dir"));
			}
			if(password.matches("\\{.+\\}.+")) {
				DataEncryptionManager crypto = new AESEncryptionManager();
				crypto.init();
				
				String dataType = password.replaceAll("\\}.*", "").replaceAll("\\{", "");
				password = password.replaceAll("\\{"+dataType+"\\}", "");
				password = crypto.decrypt(password, dataType);
				
			}
			
			Class.forName(jdbcDriver);
			
			@Cleanup 
			Connection conn = DriverManager.getConnection(url, username, password);
			
			@Cleanup
			PreparedStatement pstmt = conn.prepareStatement(
					"select job_conf_pkg, job_conf_class from admin_job_profiles where user_yn='Y' and job_id=?");
			pstmt.setString(1, jobId);
			
			@Cleanup
			ResultSet rs = pstmt.executeQuery();
			
			if(rs != null && rs.next()) {
				jobInfo = new JobInfo();
				jobInfo.setJobId(jobId);
				jobInfo.setJobConfPkg(rs.getString("job_conf_pkg"));
				jobInfo.setJobConfClass(rs.getString("job_conf_class"));
			}
		
		}catch (Exception e) {
			log.error("could not job find job config file info", e);
			//throw new RuntimeException("could not job find job config file info", e);
		}
		
		return jobInfo;
	}
	
	private void execute(JobParameters jobPrarams) {
		
		init();
		
		BatchConfigurer batchConfigurer  = context.getBean(BatchConfigurer.class);
		
		try {
			JobLauncher jobLanuncher = batchConfigurer.getJobLauncher();
			
			Job job= context.getBean(jobId, Job.class);
			
			jobLanuncher.run(job, jobPrarams);
		}
		catch(JobInstanceAlreadyCompleteException e) {
			log.error("Already Complete Job", e);
		}
		catch(BatchException e) {
			log.error("Fail to execute batch Job {}, {}, {}", jobId, jobPrarams.toString(), e);
			
			throw e;
		}
		catch(Exception e) {
			log.error("Fail to execute batch Job {}, {}, {}", jobId, jobPrarams.toString(), e);
		}
	}
}
