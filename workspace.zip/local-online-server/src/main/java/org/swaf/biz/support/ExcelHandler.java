package org.swaf.biz.support;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.util.StringUtils;
import org.swaf.biz.util.ExcelExUtils;
import org.swaf.foundation.context.DasVO;
import org.swaf.foundation.context.DefaultVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExcelHandler<T,T1 extends DefaultVO> implements ResultHandler<T>{

	private T result;
	private ResultContext<? extends T> rstContext;
	
	private SXSSFWorkbook workbook;
	private SXSSFSheet sheet;
	
	private Class<T1> voType;
	private ExcelInfo excelInfo;
	private String filePathNm;
	
	String voPropOrder[] = null;
	private int rowIndex=0;
	private int bodyRow = 0;
	
	private int rowCnt = 0;
	private CellStyle[] arrayOfCellStyle = null;
	
	public ExcelHandler(String fileNm) {
		workbook = new SXSSFWorkbook();
		workbook.setCompressTempFiles(true);
		
		sheet = workbook.createSheet(fileNm);
		sheet.setRandomAccessWindowSize(10000);
	}
	
	public ExcelHandler(String path, String fileNm, ExcelInfo xlsInfo, Class<T1> clazz, String[] propOrder) {

		this(fileNm);
		
		this.excelInfo = xlsInfo;
		this.voType = clazz;
		
		if(propOrder != null && propOrder.length>0) {
			voPropOrder = propOrder;
		}
		else {
			voPropOrder = StringUtils.toStringArray(xlsInfo.getColumn());
		}
		
		this.filePathNm = ExcelExUtils.getXlsFileId(path, "", "", fileNm);
		int xlsCursor = ExcelExUtils.processSheet(workbook, sheet, xlsInfo);
		
		this.rowIndex += xlsCursor;
	}
	
	@SuppressWarnings("unchecked")
	public void processResult() {
		
		if(this.arrayOfCellStyle == null) {
			this.arrayOfCellStyle = ExcelExUtils.createStyles(workbook, 
					excelInfo.getAlign(), 
					excelInfo.getMask(), 
					StringUtils.toStringArray(excelInfo.getType()));
		}
		
		if(this.arrayOfCellStyle == null) {
			this.arrayOfCellStyle = new CellStyle[voPropOrder.length];
			
			for(int i=0; i<voPropOrder.length; i++) {
				CellStyle cellStyle= ExcelExUtils.getCellStyle(workbook, false);
				this.arrayOfCellStyle[i] = cellStyle;
			}
		}
		
		
		int columnCursor = 0;
		CellStyle bodyCellStyle = null;
		for(String propOrder : voPropOrder) {
			if(arrayOfCellStyle.length > columnCursor) {
				bodyCellStyle = arrayOfCellStyle[columnCursor];
			}
		
			DasVO<T1> dto = (DasVO<T1>) result;
			T1 appVo = dto.getReuslt(voType);
			
			Object rstObject = null;
			String rstValue = "";
			
			if("currow".equals(propOrder)) {
				rstValue = bodyRow +"";
			}
			else {
				try {
					rstObject = appVo.get(propOrder);
				}
				catch (Exception e) {
					log.warn("mismatch properOrder[{}]", propOrder);
				}
				
				if(rstObject != null) {
					rstValue = rstObject.toString();
				}
				
				Row row = sheet.getRow(rowIndex);
				if(row == null) {
					row = sheet.createRow(rowIndex);
				}
				
				columnCursor = ExcelExUtils.createCell(workbook, sheet, row, rstValue, columnCursor, bodyCellStyle);
			}
			bodyRow++;
			
		}
		
		
	}
	
	@Override
	public void handleResult(ResultContext<? extends T> resultContext) {


		if(resultContext.getResultObject() == null) {
			return;
		}
		
		rstContext = resultContext;
		result = rstContext.getResultObject();
		
		try {
			processResult();
		}
		catch (Exception e) {
			log.error("fail to excel handle Result", e);
		}
	
		rowIndex++;
		rowCnt++;
	}
	
	public String close() throws Exception {
		FileOutputStream fos = null;
		
		try {
			fos = new FileOutputStream(filePathNm);
			
			workbook.write(fos);
		}
		catch(FileNotFoundException e) {
			log.error("file not found exception [{}]", filePathNm);
			throw e;
		}
		finally {
			try {
				if(fos != null) {
					fos.close();
				}
			}
			catch(IOException e) {
				log.error("fail to excel file close ");
			}
		}
		
		return this.filePathNm;
	}

}
