package org.swaf.biz.support;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ExcelInfo {

	String sheetName;
	
	String width;
	String align;
	String mask;
	
	int startRow;
	int col;
	int maxBodyRowIdx;
	
	List<List<String>> header;
	List<List<String>> body;
	
	List<String> column;
	List<String> type;
	
	boolean maskYn = true;
}
