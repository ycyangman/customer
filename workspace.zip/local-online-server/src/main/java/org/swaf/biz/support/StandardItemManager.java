package org.swaf.biz.support;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;
import org.swaf.foundation.annotation.VoField;
import org.swaf.foundation.annotation.VoType;

public class StandardItemManager {

	public static List<String> getBaseItems(Class<?> abstClazz) throws Exception {
		
		VoType voType = abstClazz.getAnnotation(VoType.class);
		String[] propOrders = voType.propOrder();
		
		List<String> baseItems = new ArrayList<>();
		
		for(String propOrder : propOrders) {
			String desciption = "";
			Field declaredField = abstClazz.getDeclaredField(propOrder);
			
			desciption = declaredField.getAnnotation(VoField.class).description();
			
			if(StringUtils.hasText(desciption)) {
				baseItems.add(desciption);
			}
		}
		return baseItems;
	}
	
	
	
	public static boolean isMatchStndItem(String optrVl, String itemVl, String abstStrVal, boolean isStringType) throws Exception {
		
		boolean isMatch = false;
		if("IN".equalsIgnoreCase(optrVl)) {
			
			if(abstStrVal.indexOf(",") > 0) {
			
				String[] tokens = StringUtils.commaDelimitedListToStringArray(abstStrVal);
				
				for(String token : tokens ) {
					if(StringUtils.commaDelimitedListToSet(itemVl).contains(token)) {
						isMatch = true;
						break;
					}
				}
			}
			else {
				isMatch = StringUtils.commaDelimitedListToSet(itemVl).contains(abstStrVal);
			}
			
		}
		if("NOTIN".equalsIgnoreCase(optrVl)) {
			isMatch = !StringUtils.commaDelimitedListToSet(itemVl).contains(abstStrVal);
		}
		if("BETWEEN".equalsIgnoreCase(optrVl)) {
			
			String[] arrItemVl = StringUtils.delimitedListToStringArray(itemVl, ",");
			
			if (arrItemVl == null || arrItemVl.length < 2) {
				isMatch = false;
			}
			else {
				isMatch = ((getDouble(abstStrVal) >= getDouble(arrItemVl[0]) &&
						    getDouble(abstStrVal) <= getDouble(arrItemVl[1]))
						);
			}
			isMatch = StringUtils.commaDelimitedListToSet(itemVl).contains(abstStrVal);
			
		}
		
		if("=".equals(optrVl) || "==".equals(optrVl)) {
			
			if(isStringType) {
				
				if(abstStrVal.indexOf(",") > 0) {
					isMatch = abstStrVal.contains(itemVl);
				}
				else {
					isMatch = abstStrVal.equals(itemVl);
				}
			}
			else {
				isMatch = getDouble(abstStrVal) == getDouble(itemVl);
			}
		}
		if("<>".equals(optrVl) || "!=".equals(optrVl)) {
			
			if(isStringType) {
				isMatch = (!abstStrVal.equals(itemVl));
				
			}
			else {
				isMatch = getDouble(abstStrVal) != getDouble(itemVl);
			}
		}
		if(">=".equals(optrVl)) {
			isMatch = getDouble(abstStrVal) >= getDouble(itemVl);
		}
		
		if("<=".equals(optrVl)) {
			isMatch = getDouble(abstStrVal) <= getDouble(itemVl);
		}
		
		if(">".equals(optrVl)) {
			isMatch = getDouble(abstStrVal) > getDouble(itemVl);
		}
		
		if("<".equals(optrVl)) {
			isMatch = getDouble(abstStrVal) < getDouble(itemVl);
		}
		
		return isMatch;
	}
	
	public static double getDouble(String input) {
		try {
			if( !StringUtils.hasText(input)) {
				return 0;
			}
			
			return Double.parseDouble(input);
		}
		catch(Exception e) {
			return 0;
		}
	}
}
