package org.swaf.biz.support;

import org.swaf.foundation.annotation.VoField;
import org.swaf.foundation.annotation.VoType;

import lombok.Data;

@Data
@VoType(propOrder= {"itmCd", "itmVl"})
public class StndTypeVO {

	@VoField(description="항목코드")
	private String itmCd;
	
	@VoField(description="항목값")
	private String itmVl;
	
	@VoField(description="항목값명")
	private String itmVlNm;
	
}
