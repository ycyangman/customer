package org.swaf.biz.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ReflectionUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BizCommUtils {

	
	/*
	 * Collect source 내의 특정한 객체의 object  필드값과 일치하면 리턴
	 */
	public static <T> T findValueOfType( List<T> collection, Object object, String... fieldNames) {
		
		if(ObjectUtils.isEmpty(collection) || object == null) {
			return null;
		}
		
		String objMergedValues = "";
		for(String fieldName : fieldNames) {
			
			String objValue = getStringValue(object, fieldName);
		
			if(objValue == null || "".equals(objValue)) {
				return null;
			}
		
			objMergedValues += objValue;
		}
		
		String matchValues = "";
		T elementObj = null;
		for (T element : collection) {
			
			matchValues = "";
			elementObj = element;
			String value = null;
			
			for(String fieldName : fieldNames) {
				
				value =  getStringValue(elementObj, fieldName);
				
				if(value == null || "".equals(value)) {
					return null;
				}
				
				
				matchValues += value;
			}
			
			if(objMergedValues.equals(matchValues)) {
				return elementObj;
			}
		}
		
		return null;
	}
	
	/*
	 * Collect source 내의 특정한 객체의 object  필드값과 일치하면 리턴
	 */
	public static <T> T findValueOfAnyType( List<T> collection, Object object, String... fieldNames) {
		
		if(ObjectUtils.isEmpty(collection) || object == null) {
			return null;
		}
		
		String[] objValues = new String[fieldNames.length];
		for(int idx=0; idx<fieldNames.length; idx++) {
			
			String fieldName = fieldNames[idx];
			
			String objValue = getStringValue(object, fieldName);
		
			if(objValue == null || "".equals(objValue)) {
				return null;
			}
		
			objValues[idx] = objValue;
		}
		
		T elementObj = null;
		for (T element : collection) {
			
			elementObj = element;
			String value = null;
			
			for(int idx=0; idx<fieldNames.length; idx++) {
				
				String fieldName = fieldNames[idx];
				value =  getStringValue(elementObj, fieldName);
				
				if(value == null || "".equals(value)) {
					return null;
				}
				
				if(value.equals(objValues[idx])) {
					return elementObj;
				}
			}
		}
		
		return null;
	}
	
	public static String getStringValue(Object srcObject, String fieldName) {
		String returnValue = "";
		
		Field field = ReflectionUtils.findField(srcObject.getClass(), fieldName);
		
		if(field == null) {
			return null;
		}
		
		try {
			Method method = srcObject.getClass().getMethod("get"+StringUtils.capitalize(fieldName));
			
			Object result = method.invoke(srcObject, new Object[] {});
			
			if(result == null) {
				return returnValue;
			}
		
			if (method.getReturnType().isAssignableFrom(Long.class) || method.getReturnType() == Integer.TYPE) {
				returnValue = String.valueOf((Long)result);
			}
			else if(method.getReturnType().isAssignableFrom(Double.class)) {
				returnValue = String.valueOf((Double)result);
			}
			else if(method.getReturnType().isAssignableFrom(Integer.class)) {
				returnValue = String.valueOf((Integer)result);
			}
			else if(method.getReturnType().isAssignableFrom(BigDecimal.class)) {
				BigDecimal tempBigDecimal = (BigDecimal)result;
				returnValue = tempBigDecimal.toString();
			}
			else {
				returnValue = StringUtils.defaultString((String)result);
			}
		}
		catch(Exception e) {
			log.warn("could not getStringValue by the field {} ::{}", srcObject.getClass().getName(), fieldName);
		}
		
		return returnValue;
	}
	
	/**
	 * 입력된 Object에서 입력된 필드의 String값을 입력한다
	 * 
	 * @param Object srcData 입력할 데이터원본
	 * @param String fieldName 입력할 데이터필드
	 * @param String paramValue 입력할 데이터값
	 */
	public static void setStringValue(Object srcData, String fieldName, String paramValue) {
		setTypeValue(srcData, String.class, fieldName, paramValue);
	}
	
	/**
	 * 입력된 필드의 setter메소드 실행
	 * 
	 * @param Object srcData 입력할 데이터원본
	 * @param Class<? extends Object> paramClassType 입력할 데이터값의 Class
	 * @param String fieldName 입력할 데이터필드
	 * @param Object paramValue 입력할 데이터값
	 */
	public static void setTypeValue(Object targetObj, Class<? extends Object> paramClassType, String fieldName, String paramValue) {
		
		try {
			Method targetMethod = targetObj.getClass().getMethod("set" + StringUtils.capitalize(fieldName), new Class[]{paramClassType});
			targetMethod.invoke(targetObj, new Object[]{paramClassType.cast(paramValue)});
		
		}
		catch (Exception e) {
			log.warn(" fail to setter : " + fieldName);
		} 
	}
	

}
