
package org.swaf.biz.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;


public abstract class DateUtils
{
	/** 날자문자열 유형을 나타내는 상수 : yyyy-MM-dd */
    public static final int DASH_DATE_TYPE= 0;
    /** 날자문자열 유형을 나타내는 상수 : yyyy/MM/dd*/
    public static final int SLASH_DATE_TYPE= 1;
    /** 날자문자열 유형을 나타내는 상수 : yyyyMMdd*/
    public static final int EMPTY_DATE_TYPE= 2;
    /** 날자문자열 유형을 나타내는 상수 : yyyy년 MM월 dd일*/
    public static final int KOR_DATE_TYPE= 3;
    /** 날자문자열 유형을 나타내는 상수 : yyyy.MM.dd*/
    public static final int DOT_DATE_TYPE= 4;
    /** 날자문자열 유형을 나타내는 상수 : yyyy MM dd*/
    public static final int BLANK_DATE_TYPE= 5;

    /** 시간문자열 유형을 나타내는 상수 : HH:mm:ss*/
    public static final int FULL_TIME_TYPE= 0;
    /** 시간문자열 유형을 나타내는 상수 : HH:mm*/
    public static final int MIN_TIME_TYPE= 1;
    /** 시간문자열 유형을 나타내는 상수 : HH*/
    public static final int HOUR_TIME_TYPE= 2;
    /** 시간문자열 유형을 나타내는 상수 : a hh:mm:ss*/
    public static final int AMPM_TIME_TYPE= 3;
    /** 시간문자열 유형을 나타내는 상수 : a hh:mm*/
    public static final int AMPM_MIN_TIME_TYPE= 4;
    /** 시간문자열 유형을 나타내는 상수 : a hh*/
    public static final int AMPM_HOUR_TIME_TYPE= 5;
    /** 시간문자열 유형을 나타내는 상수 : HHmmss*/
    public static final int NOCOLON_TIME_TYPE= 6;

    private static final int[] months= new int[]{ 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    private static final int[] monthStacks= new int[]{ 0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365};
    private static final int[] reverseMonthStacks= new int[]{ 0, 365, 334, 306, 275, 245, 214, 184, 153, 122, 92, 61, 31, 0};

    private static final int[] monthsLeapYear= new int[]{ 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    private static final int[] monthStacksLeapYear= new int[]{ 0, 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366};
    private static final int[] reverseMonthStacksLeapYear= new int[]{ 0, 366, 335, 306, 275, 245, 214, 184, 153, 122, 92, 61, 31, 0};

    /** 날자 변환 포맷 종류
     *  "yyyy-MM-dd", "yyyy/MM/dd", "yyyyMMdd", "yyyy년 MM월 dd일", "yyyy.MM.dd", "yyyy MM dd"
     */
    private static String formatListDate[]= { "yyyy-MM-dd", "yyyy/MM/dd", "yyyyMMdd", "yyyy년 MM월 dd일", "yyyy.MM.dd", "yyyy MM dd"};
    /** 시간 변환 포맷 종류
     *  "HH:mm:ss", "HH:mm", "HH", "a hh:mm:ss", "a hh:mm", "a hh", "HHmmss"
     */
    private static String formatListTime[]= { "HH:mm:ss", "HH:mm", "HH", "a hh:mm:ss", "a hh:mm", "a hh", "HHmmss"};

    /**
     * 기본 TimeZone과 Locale을 이용하여 GregorialCalendar를 생성한다.
     * @return GregorialCalendar를 리턴한다.
     */
    public static GregorianCalendar getGregorialCalendar()
    {
    	return new GregorianCalendar( TimeZone.getDefault(), Locale.getDefault());
    }
    
    /**
     * 전달된 문자열이 유효할 날자인지 판단한다.
     * @param inString 검사할 문자열
     * @param format<br>포맷
     * DateUtils.DASH_TYPE  "yyyy-MM-dd", <br>DateUtils.SLASH_TYPE  "yyyy/MM/dd",<br> DateUtils.EMPTY_TYPE "yyyyMMdd",<br> DateUtils.KOR_TYPE "yyyy년 MM월 dd일", <br>DateUtils.DOT_TYPE "yyyy.MM.dd", <br>DateUtils.BLANK_TYPE "yyyy MM dd"
     * @return 유효할 날자인지 여부
     */
    public static boolean isValidDate( String inString, int format)
    {

    	SimpleDateFormat simpledateformat= new SimpleDateFormat( formatListDate[format]);
    	if( inString.length()!= simpledateformat.toPattern().length())
    		return false;
    	simpledateformat.setLenient( false);
    	try
		{
			simpledateformat.parse( inString);
		}
		catch( ParseException e)
		{
			return false;
		}
    	return true;
    }
    
    /**
     * System-time(millisecond단위)를 형식화된 문자열로 변환한다.
     * @param milliseconds 입력할 milliseconds
     * @param pattern 사용할 포맷패턴
     * @return 패턴에 맞추어 변환된 문자열
     */
    public static String getString( long milliseconds, String pattern)
    {
        Calendar calendar= Calendar.getInstance();
        calendar.setTimeInMillis( milliseconds);
        return new SimpleDateFormat( pattern).format( calendar.getTime()).toString();
    }

    /**
     * 전달된 연도가 윤년인지를 판단한다.
     * @param strYear 판단할 연도, 4자리 문자열 (예: "2000")
     * @return 윤년일 경우 <code>true</code>를 리턴
     */
    public static boolean isLeapYear( String strYear)
    {
        int year= Integer.parseInt( strYear);
        if(  year% 400== 0 || ( year% 4== 0 && year% 100!= 0)) 
        	return true;
        return false;
    }

    /**
     * 입력된 연도가 윤년인지를 판단한다.
     * @param year 판단할 연도, int 값 (예: 2000)
     * @return 윤년일 경우 <code>true</code>를 리턴
     */
    public static boolean isLeapYear( int year)
    {
        if(  year% 400== 0 || ( year% 4== 0 && year% 100!= 0)) 
        	return true;
        return false;
    }

    /**
     * 주어진 두 날짜 사이의 일 수를 계산한다.
     * @param beginDate 시작 날짜, 8자리의 String (예: "20121212")
     * @param endDate 끝 날짜, 8자리의 문자열
     * @return 두 날짜 사이의 일 수 (int 값)
     */
    public static int getPeriodBetween( String beginDate, String endDate)
    {
        return getPeriodBetween( Integer.parseInt( beginDate.substring( 0, 4)), Integer.parseInt( beginDate.substring( 4, 6)),
                Integer.parseInt( beginDate.substring( 6)), Integer.parseInt( endDate.substring( 0, 4)), 
                Integer.parseInt( endDate.substring( 4, 6)), Integer.parseInt( endDate.substring( 6)));

    }

    /**
     * 주어진 두 날짜 사이의 일 수를 계산한다.
     * @param beginYear 시작 연도, int 값 (예: 2012)
     * @param beginMonth 시작 월, int 값 (예: 12)
     * @param beginDay 시작 일, int 값 (예: 25)
     * @param endYear 끝 연도, int 값 (예: 2010)
     * @param endMonth 끝 월, int 값 (예: 3)
     * @param endDay 끝 일, int 값 (예: 9)
     * @return 두 날짜 사이의 일 수 (int 값)
     */
    public static int getPeriodBetween( int beginYear, int beginMonth, int beginDay, int endYear, int endMonth, int endDay)
    {
        int daysCnt= 0;

        if( beginYear< endYear)
        {
            int beginYear2= beginYear- 1;
            int endYear2= endYear- 1;

            daysCnt+= ( ( endYear- beginYear)* 365);

            // 윤년
            daysCnt+= ( endYear2>> 2);
            daysCnt-= ( beginYear2>> 2);
            daysCnt+= ( beginYear2/ 100);
            daysCnt-= ( endYear2/ 100);
            daysCnt+= ( endYear2/ 400);
            daysCnt-= ( beginYear2/ 400);

            if( beginYear% 400== 0&& beginMonth> 2)
                daysCnt--;
            else if( beginMonth> 2&& beginYear% 4== 0 && beginYear% 100!= 0)
                daysCnt--;

            if( endYear% 400== 0 && endMonth> 2)
                daysCnt++;
            else if( endYear% 4== 0 && endMonth> 2 && endYear% 100!= 0)
                daysCnt++;

            daysCnt+= ( monthStacks[endMonth]- monthStacks[beginMonth]);

            // 일자
            daysCnt+= ( endDay- beginDay);
            return daysCnt;
        }
        else if( beginYear> endYear)
        	return - ( getPeriodBetween( endYear, endMonth, endDay, beginYear, beginMonth, beginDay)); 
        if( beginMonth< endMonth)
        {
            if( beginYear% 400== 0 && beginMonth<= 2 && endMonth> 2)
                daysCnt++;
            else if( beginMonth<= 2&& endMonth> 2&& beginYear% 4== 0&& beginYear% 100!= 0)
                daysCnt++;

            daysCnt+= ( monthStacks[endMonth]- monthStacks[beginMonth]);
            // 일자
            daysCnt+= ( endDay- beginDay);
        }
        else if( beginMonth> endMonth)
            return - ( getPeriodBetween( endYear, endMonth, endDay, beginYear, beginMonth, beginDay));
        else
            daysCnt+= endDay- beginDay;

        return daysCnt;
    }

    /**
     * 지정된 년수로부터 주어진 년수 만큼 후의 날짜를 구한다.
     * @param after 몇년 후의 날짜를 구할 것인지, int 값
     * @param date 기준날짜, 8자리 String (예 : "20121225")
     * @return 기준 연도로부터 after만큼 후의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateYearsAfter( int after, String date)
    {
        return getDateYearsAfter( after, Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)),
                Integer.parseInt( date.substring( 6)));
    }

    /**
     * 지정된 년수로부터 주어진 년수 만큼 후의 날짜를 구한다.
     * @param after 몇년 후의 날짜를 구할 것인지, int 값
     * @param year 기준 연도, int 값 (예 : 2012)
     * @param month 기준 월, int 값 (예 : 3)
     * @param day 기준 일, int 값 (예 : 1)
     * @return 기준 연도로 부터 after만큼 후의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateYearsAfter( int after, int year, int month, int day)
    {
        year+= after;
        
        /**
         * 2013.07.01 changyoung.shin update
         * 윤년 적용
         */
        if( ! isLeapYear( year)) {
        	if(months[month] < day) day = months[month];
        } 
        else {
        	if(monthsLeapYear[month] < day) day = monthsLeapYear[month];
        }
        
        return Integer.toString( year* 10000+ month* 100+ day);
    }

    /**
     * 지정된 년수로부터 주어진 년수 만큼 전의 날짜를 구한다.
     * @param before 몇년 전의 날짜를 구할 것인지, int 값
     * @param date 기준날짜, 8자리 String (예 : "20121225")
     * @return 기준 연도로부터 before만큼 전의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateYearsBefore( int before, String date)
    {
        return getDateYearsBefore( before, Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)),
                Integer.parseInt( date.substring( 6)));
    }

    /**
     * 지정된 년수로부터 주어진 년수 만큼 전의 날짜를 구한다.
     * @param before 몇년 전의 날짜를 구할 것인지, int 값
     * @param year 기준 연도, int 값 (예 : 2012)
     * @param month 기준 월, int 값 (예 : 3)
     * @param day 기준 일, int 값 (예 : 1)
     * @return 기준 연도로부터 before만큼 전의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateYearsBefore( int before, int year, int month, int day)
    {
        year-= before;
        
        /**
         * 2013.07.01 changyoung.shin update
         * 윤년 적용
         */
        if( ! isLeapYear( year)) 
        {
        	if(months[month] < day) 
        		day = months[month];
        } 
        else 
        {
        	if(monthsLeapYear[month] < day) 
        		day = monthsLeapYear[month];
        }
        
        return Integer.toString( year* 10000+ month* 100+ day);
    }

    /**
     * 지정된 월수로부터 주어진 월수 만큼 후의 날짜를 구한다.
     * @param after 몇월 후의 날짜를 구할 것인지, int 값
     * @param date 기준날짜, 8자리 String (예 : "20121225")
     * @return 기준 월수로부터 after만큼 후의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateMonthsAfter( int after, String date)
    {
        return getDateMonthsAfter( after, Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)),
                Integer.parseInt( date.substring( 6)));
    }

    /**
     * 지정된 월수로부터 주어진 월수 만큼 후의 날짜를 구한다.
     * @param after 몇월 후의 날짜를 구할 것인지, int 값
     * @param year 기준 연도, int 값 (예 : 2012)
     * @param month 기준 월, int 값 (예 : 3)
     * @param day 기준 일, int 값 (예 : 1)
     * @return 기준 월수로부터 after만큼 후의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateMonthsAfter( int after, int year, int month, int day)
    {
        month+= after;
        if( month>= 13)
        {
            year+= month/ 12;
            month= month% 12;
            if( month% 12== 0)
            {
                --year;
                month= 12;
            }
        }
        
        if( ! isLeapYear( year)) {
        	if(months[month] < day) day = months[month];
        } 
        else {
        	if(monthsLeapYear[month] < day) day = monthsLeapYear[month];
        }
        return Integer.toString( year* 10000+ month* 100+ day);
    }

    /**
     * 지정된 월수로부터 주어진 월수 만큼 전의 날짜를 구한다.
     * @param before 몇월 전의 날짜를 구할 것인지, int 값
     * @param date 기준날짜, 8자리 String (예 : "20121225")
     * @return 기준 월수로부터 before만큼 전의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateMonthsBefore( int before, String date)
    {
        return getDateMonthsBefore( before, Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)),
                Integer.parseInt( date.substring( 6)));
    }

    /**
     * 지정된 월수로부터 주어진 월수 만큼 전의 날짜를 구한다.
     * @param before 몇월 전의 날짜를 구할 것인지, int 값
     * @param year 기준 연도, int 값 (예 : 2012)
     * @param month 기준 월, int 값 (예 : 3)
     * @param day 기준 일, int 값 (예 : 1)
     * @return 기준 월수로부터 before만큼 전의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateMonthsBefore( int before, int year, int month, int day)
    {
        month-= before;
        while( month<= 0)
        {
            month= 12+ month;
            year--;
        }
        
        if( ! isLeapYear( year)) 
        {
        	if(months[month] < day) 
        		day = months[month];
        } 
        else 
        {
        	if(monthsLeapYear[month] < day) 
        		day = monthsLeapYear[month];
        }
        
        return Integer.toString( year* 10000+ month* 100+ day);
    }

    /**
     * 지정된 날짜로부터 주어진 일 수 만큼 후의 날짜를 구한다.
     * @param after 며칠 후의 날짜를 구할 것인지, int 값
     * @param date 기준 날짜, 8자리 String (예 : "20121225")
     * @return 기준 날짜로 부터 after만큼 후의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateDaysAfter( int after, String date)
    {
        return getDateDaysAfter( after, Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)), 
        		Integer.parseInt( date.substring( 6)));
    }

    /**
     * 지정된 날짜로부터 주어진 일 수 만큼 후의 날짜를 구한다.
     * @param after 며칠 후의 날짜를 구할 것인지, int 값
     * @param year 기준 연도, int 값 (예 : 2012)
     * @param month 기준 월, int 값 (예 : 3)
     * @param day 기준 일, int 값 (예 : 1)
     * @return 기준 날짜로 부터 after만큼 후의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateDaysAfter( int after, int year, int month, int day)
    {
        if( ! isLeapYear( year))
        {
            if( after<= ( months[month]- day)) 
            	return Integer.toString( year* 10000+ month* 100+ ( day+ after));

            after-= ( months[month]- day);
            ++month;
            if( month== 13)
            {
                ++year;
                month= 1;
            }
        }
        else
        {
            if( after<= ( monthsLeapYear[month]- day)) 
            	return Integer.toString( year* 10000+ month* 100+ ( day+ after));

            after-= ( monthsLeapYear[month]- day);
            ++month;
            if( month== 13)
            {
                ++year;
                month= 1;
            }
        }

        if( ! isLeapYear( year))
        {
            if( after<= reverseMonthStacks[month])
            {
                while( after> months[month])
                {
                    after-= months[month];
                    ++month;
                }

                return Integer.toString( year* 10000+ month* 100+ after);
            }

            after-= reverseMonthStacks[month];
            ++year;
            month= 1;
        }
        else
        {
            if( after<= reverseMonthStacksLeapYear[month])
            {
                while( after> monthsLeapYear[month])
                {
                    after-= monthsLeapYear[month];
                    ++month;
                }

                return Integer.toString( year* 10000+ month* 100+ after);
            }

            after-= reverseMonthStacksLeapYear[month];
            ++year;
            month= 1;
        }

        while( after> 365+ getLeapYearCount( year))
        {
            after-= ( 365+ getLeapYearCount( year));
            ++year;
        }

        if( ! isLeapYear( year))
        {
            while( after> months[month])
            {
                after-= months[month];
                ++month;
            }

            return Integer.toString( year* 10000+ month* 100+ after);
        }
        while( after> monthsLeapYear[month])
        {
            after-= monthsLeapYear[month];
            ++month;
        }

        return Integer.toString( year* 10000+ month* 100+ after);

    }

    /**
     * 지정된 날짜로부터 주어진 일 수 만큼 전의 날짜를 구한다.
     * @param before 며칠 전의 날짜를 구할 것인지, int 값
     * @param date 기준 날짜, 8자리 String (예 : "20121225")
     * @return 기준 날짜로 부터 before만큼 전의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateDaysBefore( int before, String date)
    {
        return getDateDaysBefore( before, Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)),
                Integer.parseInt( date.substring( 6)));
    }

    /**
     * 지정된 날짜로부터 주어진 일 수 만큼 전의 날짜를 구한다.
     * @param before 며칠 전의 날짜를 구할 것인지, int 값
     * @param year 기준 연도, int 값 (예 : 2012)
     * @param month 기준 월, int 값 (예 : 3)
     * @param day 기준 일, int 값 (예 : 1)
     * @return 기준 날짜로 부터 before만큼 전의 날짜를 8자리 String으로 돌려줌
     */
    public static String getDateDaysBefore( int before, int year, int month, int day)
    {
        if( ! isLeapYear( year))
        {
            if( before< day) return Integer.toString( year* 10000+ month* 100+ ( day- before));

            before-= day;
            --month;
            if( month== 0)
            {
                --year;
                month= 12;
            }
        }
        else
        {
            if( before< day) return Integer.toString( year* 10000+ month* 100+ ( day- before));

            before-= day;
            --month;
            if( month== 0)
            {
                --year;
                month= 12;
            }
        }

        if( ! isLeapYear( year))
        {
            if( before< monthStacks[month+ 1])
            {
                while( before>= months[month])
                {
                    before-= months[month];
                    --month;
                }

                return Integer.toString( year* 10000+ month* 100+ months[month]- before);
            }

            before-= monthStacks[month+ 1];
            --year;
            month= 12;
        }
        else
        {
            if( before< monthStacksLeapYear[month+ 1])
            {
                while( before>= monthsLeapYear[month])
                {
                    before-= monthsLeapYear[month];
                    --month;
                }

                return Integer.toString( year* 10000+ month* 100+ monthsLeapYear[month]- before);
            }

            before-= monthStacksLeapYear[month+ 1];
            --year;
            month= 12;
        }

        while( before>= 365+ getLeapYearCount( year))
        {
            before-= ( 365+ getLeapYearCount( year));
            --year;
        }

        if( ! isLeapYear( year))
        {
            while( before>= months[month])
            {
                before-= months[month];
                --month;
            }

            return Integer.toString( year* 10000+ month* 100+ months[month]- before);
        }
        while( before>= monthsLeapYear[month])
        {
            before-= monthsLeapYear[month];
            --month;
        }

        return Integer.toString( year* 10000+ month* 100+ monthsLeapYear[month]- before);
    }

    /**
     * 지정된 날짜로부터 주어진 일 수 만큼 전의 날짜를 구한다.
     * @param diff 며칠 전(후)의 날짜를 구할것인지, int 값 (양수일 경우 후, 음수일 경우 전)
     * @param year 기준 연도, int 값 (예 : 2012)
     * @param month 기준 월, int 값 (예 : 3)
     * @param day 기준 일, int 값 (예 : 1)
     * @return 기준 날짜로 부터 diff만큼 전(후)의 날짜를 8자리 String으로 돌려줌 
     * @see getDateDaysAfter
     * @see getDateDaysBefore
     */
    public static String getDateDaysDiff( int diff, int year, int month, int day)
    {
        if( diff> 0) return getDateDaysAfter( diff, year, month, day);

        return getDateDaysBefore( 0- diff, year, month, day);
    }

    /**
     * 주어진 날짜가 무슨 요일인지 알려준다.
     * @param year 연도, int 값 (예 : 2012)
     * @param month 월, int 값 (예 : 12)
     * @param day 일, int 값 (예 : 3)
     * @return 요일을 int 값으로 돌려줌 (일요일 : 1, 월요일 : 2, ... , 토요일 : 7)
     */
    public static int getDayOfTheWeek( int year, int month, int day)
    {
        Calendar cal= Calendar.getInstance();
        cal.set( year, month- 1, day);
        return cal.get( Calendar.DAY_OF_WEEK);
    }

    /**
     * 주어진 날짜가 무슨 요일인지 알려준다.
     * @param date 날짜, 8자리 String (예 : "20121225")
     * @return 요일을 int 값으로 돌려줌(일요일 : 1, 월요일 : 2, ... , 토요일 : 7)
     */
    public static int getDayOfTheWeek( String date)
    {
        return getDayOfTheWeek( Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)), 
        		Integer.parseInt( date.substring( 6)));
    }

    /**
     * 주어진 날짜가 무슨 요일인지 영문 String으로 알려준다.
     * @param year 연도, int 값 (예 : 2012)
     * @param month 월, int 값 (예 : 12)
     * @param day 일, int 값 (예 : 3)
     * @return 요일을 영문 String으로 돌려줌 ( 일요일 : "Sun", 월요일 : "Mon", ... , 토요일 : "Sat")
     */
    public static String getDayOfTheWeekInEnglish( int year, int month, int day)
    {
        int dow= getDayOfTheWeek( year, month, day);

        switch( dow)
        {
	        case 1:
	            return "Sun";
	        case 2:
	            return "Mon";
	        case 3:
	            return "Tue";
	        case 4:
	            return "Wed";
	        case 5:
	            return "Thu";
	        case 6:
	            return "Fri";
	        default:
	            return "Sat";
        }
    }

    /**
     * 주어진 날짜가 무슨 요일인지 영문 String으로 알려준다.
     * @param date 날짜, 8자리 String (예 : "20121225")
     * @return 요일을 영문 String으로 돌려줌 ( 일요일 : "Sun", 월요일 : "Mon", ... , 토요일 : "Sat")
     */
    public static String getDayOfTheWeekInEnglish( String date)
    {
        return getDayOfTheWeekInEnglish( Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)),
                Integer.parseInt( date.substring( 6)));
    }

    /**
     * 주어진 날짜가 무슨 요일인지 한글 String으로 알려준다.
     * @param year 연도, int 값 (예 : 2012)
     * @param month 월, int 값 (예 : 12)
     * @param day 일, int 값 (예 : 3)
     * @return 요일을 한글 String으로 돌려줌 ( 일요일 : "일", 월요일 : "월", ... , 토요일 : "토")
     */
    public static String getDayOfTheWeekInKorean( int year, int month, int day)
    {
        int dow= getDayOfTheWeek( year, month, day);

        switch( dow)
        {
	        case 1:
	            return "일";
	        case 2:
	            return "월";
	        case 3:
	            return "화";
	        case 4:
	            return "수";
	        case 5:
	            return "목";
	        case 6:
	            return "금";
	        default:
	            return "토";
        }
    }

    /**
     * 주어진 날짜가 무슨 요일인지 한글 String으로 알려준다.
     * @param date 날짜, 8자리 String (예 : "20121225")
     * @return 요일을 한글 String으로 돌려줌 ( 일요일 : "일", 월요일 : "월", ... , 토요일 : "토")
     */
    public static String getDayOfTheWeekInKorean( String date)
    {
        return getDayOfTheWeekInKorean( Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)),
                Integer.parseInt( date.substring( 6)));
    }

    /**
     * 주어진 날짜가 속한 주의 날짜를 일요일 - 토요일 순의 배열로 돌려준다.
     * <p><pre>
     * 주어진 날짜가 2012년 12월20일(화요일) 일 경우 
     * "20121218", "20121219", ... , "20121224"
     * 를 String형 배열로 돌려준다. 
     *  </pre>
     * @param year 연도, int 값 (예 : 2012)
     * @param month 월, int 값 (예 : 12)
     * @param day 일, int 값 (예 : 3)
     * @return 주어진 날짜가 속한 주의 날짜들의 배열
     */
    public static String[] getWeekDays( int year, int month, int day)
    {
        int dow= getDayOfTheWeek( year, month, day)- 1;

        String[] days= new String[7];

        for( int i= 0; i< 7; ++i)
            days[i]= getDateDaysDiff( i- dow, year, month, day);

        return days;
    }

    /**
     * 주어진 날짜가 속한 주의 날짜를 일요일 - 토요일 순의 배열로 돌려준다.
     * <p><pre>
     * 주어진 날짜가 2012년 12월20일(화요일) 일 경우 
     * "20121218", "20121219", ... , "20121224"
     * 를 String형 배열로 돌려준다. 
     *  </pre>
     * @param date 날짜, 8자리의 String (예 : "20121225")
     * @return 주어진 날짜가 속한 주의 날짜들의 배열
     */
    public static String[] getWeekDays( String date)
    {
        return getWeekDays( Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)), 
        		Integer.parseInt( date.substring( 6)));
    }

    /**
     * 주어진 달이 몇 일 까지 있는지를 돌려준다.
     * @param year 연도, int 값 (예 : 2012)
     * @param month 월, int 값 (예 : 12)
     * @return 주어진 달이 가진 일 수
     */
    public static int getDaysOfTheMonth( int year, int month)
    {
        if( ! isLeapYear( year)) return months[month];
        return monthsLeapYear[month];
    }

    /**
     * 주어진 달이 몇 일 까지 있는지를 돌려준다.
     * @param date 날짜, 8자리 또는 6자리의 String ( 예 : "20121203" 또는 "201212")
     * @return 주어진 달이 가진 일 수
     */
    public static int getDaysOfTheMonth( String date)
    {
        return getDaysOfTheMonth( Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)));
    }

    /**
     * <pre>현재날짜를 주어진 포맷으로 리턴한다. 
     * System.out.println(DateUtils.currentDate(0));
     * 결과는 "yyyy-MM-dd" 포맷에 맞춘 결과값이 나온다. </pre>
     * @param format<br>포맷
     * DateUtils.DASH_TYPE  "yyyy-MM-dd", <br>DateUtils.SLASH_TYPE  "yyyy/MM/dd",<br> DateUtils.EMPTY_TYPE "yyyyMMdd",<br> DateUtils.KOR_TYPE "yyyy년 MM월 dd일", <br>DateUtils.DOT_TYPE "yyyy.MM.dd", <br>DateUtils.BLANK_TYPE "yyyy MM dd"
     * @return String로 변환된 값
     */
    public static String getCurrentDate( int format)
    {
        if( format>= formatListDate.length|| format< 0) return null;
        SimpleDateFormat simpledateformat= new SimpleDateFormat( formatListDate[format]);
        Calendar calendar= Calendar.getInstance();
        simpledateformat.setCalendar( calendar);
        String s= simpledateformat.format( simpledateformat.getCalendar().getTime());
        return s;
    }

    /**
     * <pre>주어진 날짜를 지정된 포맷으로 변환하여 리턴한다.
     * System.out.println(DateUtils.getDate("20120301",0);
     * 결과는 yyyy-MM-dd 포맷으로 변환된 2012-03-01 </pre>
     * @param date 기준 날짜, 8자리 String (예 : "20120301")
     * @param format<br>
     * DateUtils.DASH_TYPE  "yyyy-MM-dd", <br>DateUtils.SLASH_TYPE  "yyyy/MM/dd",<br> DateUtils.EMPTY_TYPE "yyyyMMdd",<br> DateUtils.KOR_TYPE "yyyy년 MM월 dd일", <br>DateUtils.DOT_TYPE "yyyy.MM.dd", <br>DateUtils.BLANK_TYPE "yyyy MM dd"
     * @return String로 변환된 날짜
     */
    public static String getDate( String date, int format)
    {
        return getDate( Integer.parseInt( date.substring( 0, 4)), Integer.parseInt( date.substring( 4, 6)), 
        		Integer.parseInt( date.substring( 6)), format);
    }

    /**
     * <pre>주어진 날짜를 지정된 포맷으로 변환하여 리턴한다.
     * System.out.println(DateUtils.getDate(2012, 3, 1, 0));
     * 결과는 yyyy-MM-dd 포맷으로 변환된 2012-03-01 </pre>
     * @param year 연도, int 값 (예 : 2012 )
     * @param month 월, int 값 (예 : 3 )
     * @param day 일, int 값 (예 : 1 )
     * @param format<br>
     * DateUtils.DASH_TYPE  "yyyy-MM-dd", <br>DateUtils.SLASH_TYPE  "yyyy/MM/dd",<br> DateUtils.EMPTY_TYPE "yyyyMMdd",<br> DateUtils.KOR_TYPE "yyyy년 MM월 dd일", <br>DateUtils.DOT_TYPE "yyyy.MM.dd", <br>DateUtils.BLANK_TYPE "yyyy MM dd"
     * @return String로 변환된 날짜
     */
    public static String getDate( int year, int month, int day, int format)
    {
        SimpleDateFormat simpledateformat= new SimpleDateFormat( formatListDate[format]);
        Calendar calendar= Calendar.getInstance();
        calendar.set( year, month- 1, day);
        simpledateformat.setCalendar( calendar);
        String s= simpledateformat.format( simpledateformat.getCalendar().getTime());
        return s;
    }

    /**
     * <pre>현재시간을 주어진 포맷으로 리턴한다. 
     * System.out.println(DateUtils.currentTime(1));
     * 결과는 "HH:mm" 포맷에 맞춘 결과값이 나온다.</pre>
     * @param format 
     * DateUtils.FULL_TYPE "HH:mm:ss", <br>DateUtils.MIN_TYPE "HH:mm",<br>DateUtils.HOUR_TYPE "HH",<br>    DateUtils.AMPM_TYPE "a hh:mm:ss",<br>    DateUtils.AM_MIN_TYPE "a hh:mm",<br>DateUtils.AMHOUR_TYPE "a hh",<br> DateUtils.NOCOLON_TYPE "HHmmss"
     *     
     * @return String로 변환된 값
     */
    public static String getCurrentTime( int format)
    {
        if( format>= formatListTime.length|| format< 0) return null;
        SimpleDateFormat simpledateformat= new SimpleDateFormat( formatListTime[format]);
        Calendar calendar= Calendar.getInstance();
        simpledateformat.setCalendar( calendar);
        String s= simpledateformat.format( simpledateformat.getCalendar().getTime());
        return s;
    }

    private static int getLeapYearCount( int year)
    {
        if( year% 400== 0 || ( year% 4== 0 && year% 100!= 0)) 
        	return 1;
        return 0;
    }
    
}
