package org.swaf.biz.util;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.springframework.util.StringUtils;
import org.swaf.biz.support.ExcelInfo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExcelExUtils {

	private static final String FONT_NAME = "돋움체";

	public static final String FILE_BIZ_KND = "online";

	static Pattern regex = Pattern.compile("^([\\s\\S]*?)(\\$(C)([0-9]+))*(\\$([CR])([0-9]+)){1}$");

	public static String getXlsFileId(String path, String bizKnd, String prefix, String fileNm) {
		
		if(!StringUtils.hasText(bizKnd)) {
			bizKnd = FILE_BIZ_KND;
		}
		
		if(!StringUtils.hasText(prefix)) {
			prefix = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE);
		}
		
		String curDtm = DateUtils.getCurrentDate(DateUtils.EMPTY_DATE_TYPE) + DateUtils.getCurrentTime(DateUtils.NOCOLON_TIME_TYPE) ;
		String fileId = String.format("%s_%s_%s", new Object[] {bizKnd, prefix, fileNm+curDtm}).toLowerCase();
		String filePath = String.format("%s/%s/%s", new Object[] {path, bizKnd, prefix});
		
		File dir = new File(filePath);
		if (!dir.isDirectory()) {
			dir.mkdir();
		}
		fileId += ".xlsx";
		
		return filePath +"/" + fileId;
		
	}
	
	public static int processSheet(Workbook workbook, ExcelInfo excelInfo) {

		SXSSFSheet sheet = null;
		String sheetNm = excelInfo.getSheetName();

		if (sheetNm != null && !"".equals(sheetNm)) {

			sheetNm = sheetNm.replaceAll("[\\\\/:*?\\[\\]]", "_");
			if (workbook.getSheet(sheetNm) != null) {
				sheet = (SXSSFSheet) workbook.getSheet(sheetNm);
			} else {
				sheet = (SXSSFSheet) workbook.createSheet(sheetNm);
			}
		} else {
			sheet = (SXSSFSheet) workbook.createSheet(sheetNm);
		}

		sheet.setRandomAccessWindowSize(10000);

		return processSheet(workbook, sheet, excelInfo);
	}

	public static int processSheet(Workbook workbook, SXSSFSheet sheet, ExcelInfo excelInfo) {

		int rowIndex = 0;

		rowIndex += excelInfo.getStartRow();

		List<List<String>> headerList = excelInfo.getHeader();
		int cursor = 0;

		if (ObjectUtils.isNotEmpty(headerList)) {
			int i = 0;
			for (int len = headerList.size(); i < len; i++) {
				cursor = processHeader(workbook, sheet, (List<?>) headerList.get(i), cursor);
			}
		}

		String width = excelInfo.getWidth();
		if(StringUtils.hasText(width)) {
			setColumnWidth(sheet, StringUtils.delimitedListToStringArray(width, "^"));
		}
		
		return rowIndex+=cursor;
	}

	public static int processHeader(Workbook workbook, SXSSFSheet sheet, List<?> hColumns, int rowIndex) {
		Row headerRow = sheet.getRow(rowIndex);

		CellStyle style = getCellStyle(workbook, true);

		if (headerRow == null) {
			headerRow = sheet.createRow(rowIndex);
		}

		int columnIndex = 0;
		int lineBreakCount = 0;

		for (int i = 0; i < hColumns.size(); i++) {
			String titleName = (String) hColumns.get(i);
			titleName = titleName.replaceAll("&amp;", "&");
			lineBreakCount = Math.max(lineBreakCount, StringUtils.countOccurrencesOf(titleName, "\n"));
			columnIndex = createCell(workbook, sheet, headerRow, titleName, columnIndex, style);
		}

		if (lineBreakCount > 0) {
			headerRow.setHeightInPoints((lineBreakCount + 1) * sheet.getDefaultRowHeightInPoints());
		}

		return headerRow.getRowNum() + 1;
	}

	public static int processBody(Workbook workbook, SXSSFSheet sheet, CellStyle[] styles, List<?> bodyRows,
			int rowIndex) {
		int len = rowIndex + bodyRows.size();
		int idx = 0;
		int rowCursor = rowIndex;
		int columnCursor = 0;

		Row row = null;
		CellStyle bodyCellStyle = null;

		int currentStyleIndex = 0;

		if (styles == null) {
			bodyCellStyle = getCellStyle(workbook, false);
		}

		for (int i = rowIndex; i < len; i++) {
			List<?> cells = (List<?>) bodyRows.get(idx++);
			row = sheet.getRow(rowCursor);

			if (row == null) {
				row = sheet.createRow(rowCursor);
			}

			int j = 0;
			for (int cellLen = cells.size(); j < cellLen; j++) {
				String cellData = (String) cells.get(j);

				if (styles != null) {

					CellStyle cellStyle = styles[currentStyleIndex + j];
					columnCursor = createCell(workbook, sheet, row, cellData, columnCursor, cellStyle);
				} else {
					columnCursor = createCell(workbook, sheet, row, cellData, columnCursor, bodyCellStyle);
				}
			}

			rowCursor++;
			columnCursor = 0;

		}
		return row.getRowNum() + 1;
	}

	public static int createCell(Workbook workbook, SXSSFSheet sheet, Row row, String cellData, int column,
			CellStyle style) {
		Cell cell = row.getCell(column);
		int cursor = column;

		cellData = cellData == null ? "" : cellData;
		if (cell != null) {
			cursor = createCell(workbook, sheet, row, cellData, column + 1, style);
		} else {
			cell = row.createCell(column);

			if (cellData.indexOf("\n") >= 0) {
				CellStyle cloneStyle = workbook.createCellStyle();
				cloneStyle.cloneStyleFrom(style);
				style = cloneStyle;
				style.setWrapText(true);
			}

			Matcher matcher = regex.matcher(cellData);

			if (matcher.matches()) {
				String data = matcher.group(1);
				int rowIndex = cell.getRowIndex();
				int columnIndex = cell.getColumnIndex();

				if (matcher.group(2) != null) {
					int colMergeCount = Integer.parseInt(matcher.group(4));
					int rowMergeCount = Integer.parseInt(matcher.group(7));

					createEmptyColumnForMerge(sheet, row, style, columnIndex, colMergeCount);

					for (int i = 1; i < rowMergeCount; i++) {
						Row nextRow = sheet.getRow(rowIndex + i);
						if (nextRow == null) {
							nextRow = sheet.createRow(rowIndex + i);
						}
						nextRow.createCell(column).setCellStyle(style);

						createEmptyColumnForMerge(sheet, nextRow, style, columnIndex, colMergeCount);
					}

					sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex + rowMergeCount - 1, columnIndex,
							columnIndex + colMergeCount - 1));
				} else {
					String mergeType = matcher.group(6);
					int mergeCount = Integer.parseInt(matcher.group(7));

					if (mergeType.equals("R")) {
						createEmptyRowForMerge(sheet, style, rowIndex, column, mergeCount);
						sheet.addMergedRegion(
								new CellRangeAddress(rowIndex, rowIndex + mergeCount - 1, columnIndex, columnIndex));
						cursor = column + 1;
					} else if (mergeType.equals("C")) {
						createEmptyColumnForMerge(sheet, row, style, columnIndex, mergeCount);
						sheet.addMergedRegion(
								new CellRangeAddress(rowIndex, rowIndex, columnIndex, columnIndex + mergeCount - 1));
						cursor = column + mergeCount;
					}
				}

				cell.setCellStyle(style);
				setCellValue(cell, data);
			} else {
				cell.setCellStyle(style);
				setCellValue(cell, cellData);
				cursor = column + 1;
			}
		}

		return cursor;
	}

	public static CellStyle getCellStyle(Workbook wb, boolean headerFlag) {

		CellStyle style = wb.createCellStyle();

		if (headerFlag) {
			Font font = wb.createFont();
			font.setFontName(FONT_NAME);
			font.setFontHeightInPoints((short) 10);
			font.setColor(IndexedColors.BLACK.getIndex());
			font.setBold(true);

			style.setFont(font);

			style.setAlignment(HorizontalAlignment.CENTER);
			style.setVerticalAlignment(VerticalAlignment.CENTER);
			style.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setBorderRight(BorderStyle.THIN);
			style.setRightBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderLeft(BorderStyle.THIN);
			style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderBottom(BorderStyle.THIN);
			style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			style.setDataFormat(HSSFDataFormat.getBuiltinFormat("text"));
		} else {
			Font font = wb.createFont();
			font.setFontName(FONT_NAME);
			font.setFontHeightInPoints((short) 10);
			font.setColor(IndexedColors.BLACK.getIndex());
			style.setFont(font);

			style.setAlignment(HorizontalAlignment.CENTER);
			style.setVerticalAlignment(VerticalAlignment.CENTER);
			style.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setBorderRight(BorderStyle.THIN);
			style.setRightBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderLeft(BorderStyle.THIN);
			style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderBottom(BorderStyle.THIN);
			style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			style.setDataFormat(HSSFDataFormat.getBuiltinFormat("text"));
		}

		return style;
	}

	public static CellStyle[] createStyles(Workbook wb, String alignPoperty, String maskPoperty, String[] types) {
		if ((alignPoperty == null) && (alignPoperty == null)) {
			return null;
		}

		String[] alignArr = null;
		String[] maskArr = null;

		int cellCount = 0;

		if (alignPoperty != null) {
			alignArr = StringUtils.delimitedListToStringArray(alignPoperty, "^");
			cellCount = alignArr.length;
		}

		if (maskPoperty != null) {
			maskArr = StringUtils.delimitedListToStringArray(maskPoperty, "^");
			cellCount = maskArr.length;
		}

		CellStyle[] cellStyles = new CellStyle[cellCount];

		for (int i = 0; i < cellCount; i++) {
			CellStyle cellStyle = getCellStyle(wb, false);

			if (alignArr != null) {
				String align = alignArr[i];
				if (align.equals("L")) {
					cellStyle.setAlignment(HorizontalAlignment.LEFT);
				} else if (align.equals("R")) {
					cellStyle.setAlignment(HorizontalAlignment.RIGHT);
				} else {
					cellStyle.setAlignment(HorizontalAlignment.CENTER);
				}
			} else {
				cellStyle.setAlignment(HorizontalAlignment.CENTER);
			}

			if ((maskArr != null) && (!maskArr[i].trim().equals("")) && (!maskArr[i].contains("##:"))) {
				cellStyle.setDataFormat(wb.createDataFormat().getFormat(maskArr[i]));
			} else if (types != null && i < types.length) {
				String dataFormat = getDataTypeFormat(types[i]);
				if (!"".equals(dataFormat)) {
					cellStyle.setDataFormat(wb.createDataFormat().getFormat(dataFormat));
				}
			} else {
				cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("text"));
			}

			cellStyles[i] = cellStyle;
		}

		return cellStyles;
	}

	private static void setCellValue(Cell cell, String value) {
		if (DateUtil.isCellDateFormatted(cell)) {
			try {
				String dFormat = cell.getCellStyle().getDataFormatString();
				SimpleDateFormat dateFormat = new SimpleDateFormat(dFormat, Locale.KOREA);

				if (dFormat.length() > value.length()) {
					cell.setCellValue(dateFormat.format(toDate(value, dFormat)));
					return;
				}
				cell.setCellValue(value);
			} catch (ParseException e) {
				e.printStackTrace();
				cell.setCellValue(value);
			}
		} else if ((!cell.getCellStyle().getDataFormatString().equals("@"))
				&& (org.apache.commons.lang3.StringUtils.isNumeric(value))) {
			cell.setCellValue(Double.parseDouble(value));
		} else {
			cell.setCellValue(value);
		}
	}

	private static void setColumnWidth(SXSSFSheet sheet, String[] columnWidths) {
		int i = 0;
		for (int len = columnWidths.length; i < len; i++) {
			sheet.setColumnWidth(i, Integer.parseInt(columnWidths[i]) * 256);
		}
	}
	  
	private static void createEmptyRowForMerge(SXSSFSheet sheet, CellStyle style, int rowIndex, int colIndex,
			int mergeCount) {
		for (int i = 1; i < mergeCount; i++) {
			Row nextRow = sheet.getRow(rowIndex + i);
			if (nextRow == null) {
				nextRow = sheet.createRow(rowIndex + i);
			}
			nextRow.createCell(colIndex).setCellStyle(style);
		}
	}

	private static void createEmptyColumnForMerge(SXSSFSheet sheet, Row row, CellStyle style, int columnIndex,
			int mergeCount) {
		for (int i = 1; i < mergeCount; i++) {
			row.createCell(columnIndex + i).setCellStyle(style);
		}
	}

	private static String getDataTypeFormat(String type) {

		if ("ssn".equalsIgnoreCase(type)) {
			return "######-#######";
		} // ssn 주민등록번호
		if ("lrn".equalsIgnoreCase(type)) {
			return "######-#######";
		} // lrn 법인등록번호
		if ("post".equalsIgnoreCase(type)) {
			return "###-###";
		} // post 우편번호
		if ("card".equalsIgnoreCase(type)) {
			return "####-####-####-####";
		} // card 신용카드번호
		if ("mobile".equalsIgnoreCase(type)) {
			return "###-####-####";
		} // mobile 휴대폰번호
		if ("date".equalsIgnoreCase(type)) {
			return "####-##-##";
		}
		if ("time".equalsIgnoreCase(type)) {
			return "##:##:##";
		} // time 시간 (hh:mm:ss)
		if ("datetime".equalsIgnoreCase(type)) {
			return "####-##-## ##:##:##";
		} // time 시간 (hh:mm:ss)

		return "";
	}

	private static Date toDate(String dateStr, String mask) throws ParseException {
		String dMask = "";

		int i = 0;
		for (int len = mask.length(); i < len; i++) {
			char c = mask.charAt(i);
			if ((c == 'y') || (c == 'M') || (c == 'd')) {
				dMask = dMask + c;
			}
		}

		SimpleDateFormat format = new SimpleDateFormat(dMask);
		return format.parse(dateStr);
	}

}
