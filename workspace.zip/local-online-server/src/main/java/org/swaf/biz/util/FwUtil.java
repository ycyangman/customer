package org.swaf.biz.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.swaf.biz.support.ExcelInfo;
import org.swaf.foundation.context.DasVO;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.ContextUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FwUtil {

	public static <T> ArrayList<T> toArrayList(List<DasVO<T>> rstList, Class<T> clazz ) {
		
		ArrayList<T> elements = new ArrayList<T>();
		
		if(ObjectUtils.isEmpty(rstList)) {
			return elements;
		}
		
		for(DasVO<T> dasVos : rstList ) {
			T obj = dasVos.getReuslt(clazz);
			elements.add(obj);
		}
		return elements;
	}
	
	public static <T> ArrayList<T> toPgArrayList(List<DasVO<T>> rstList, Class<T> clazz ) {
		
		if(existNextResult(rstList)) {
			rstList.remove(rstList.size()-1);
		}
		
		return toArrayList(rstList, clazz);
	}
	
	public static boolean existNextResult(List<?> list) {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		if(list!=null && list.size() > ctx.getPgSz()) {
			ctx.setPgHasNext("Y");
			return true;
		}
		else {
			ctx.setPgHasNext("N");
			return false;
		}
	}
	
	public static List<ExcelInfo> getExcelInfo(String xlsJsonInfo) {
		
		ObjectMapper mapper = null;
		
		try {
			mapper = (ObjectMapper) APSBeanUtils.getBean(ObjectMapper.class);
			
		}
		catch (Exception e) {
			log.warn("fail to ObjectMapper");
			mapper = new ObjectMapper();
		}
		
		List<ExcelInfo> xlsInfoList = null;
		List<List<String>> columns = null;
		List<List<String>> types = null;
		
		try {
			JsonNode  xlsNode = mapper.readTree(xlsJsonInfo).get("excelInfo");
			JsonNode  colNode = mapper.readTree(xlsJsonInfo).get("column");
			JsonNode  typeNode = mapper.readTree(xlsJsonInfo).get("type");
			
			String excelInfo = xlsNode.toString();
			String column = colNode.toString();
			String type = typeNode.toString();
			
			if(xlsNode!=null && xlsNode.isArray()) {
				xlsInfoList = mapper.readValue(excelInfo, new TypeReference<List<ExcelInfo>>() {});
			}
			
			if(colNode!=null && colNode.isArray()) {
				columns = mapper.readValue(column, new TypeReference<List<List<String>>>() {});
			
				for(int i=0;xlsInfoList!=null && i<xlsInfoList.size(); i++ ) {
					if(i<columns.size()) {
						xlsInfoList.get(i).setColumn(columns.get(i));	
					}
				}
			}
			if(typeNode!=null && typeNode.isArray()) {
				types = mapper.readValue(type, new TypeReference<List<List<String>>>() {});
				
				for(int i=0;xlsInfoList!=null && i<xlsInfoList.size(); i++ ) {
					if(i<types.size()) {
						xlsInfoList.get(i).setType(types.get(i));	
					}
				}
			}
		}
		catch (Exception e) {
			log.warn("fail to get ExcelInfo");
		}
		
		return xlsInfoList;
	}
	
	public static void addMessage(String msgId, String[] params) {
		if(msgId == null) {
			return;
		}
		
		MessageManager mm = (MessageManager) APSBeanUtils.getBean(MessageManager.class);
		
		String message = mm.getMessage(msgId, params);
		
		if(message == null) {
			return;
		}
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		ctx.setMsgCd(msgId);
		ctx.setBascMsg(message);
	}
	
}
