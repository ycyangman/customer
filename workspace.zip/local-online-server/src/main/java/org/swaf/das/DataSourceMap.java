package org.swaf.das;


import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DataSourceMap {

	@Getter @Setter
	DataSource primaryDS;
	
	HashMap<String, BasicDataSource> dsMap;
	
	public void init() {
		
	}
	
	public void closeAll() {
		if (dsMap != null && dsMap.size() > 0 ) {
			Iterator<String> keys = dsMap.keySet().iterator();
			while(keys.hasNext()) {
				try {
					dsMap.get(keys.next()).close();
				}
				catch(SQLException e) {
					if(log.isWarnEnabled()) {
						log.warn("fail to close datasource!!", e);
					}
				}
				
			}
			this.dsMap.clear();
			this.dsMap = null;
		}
	}
	
	public BasicDataSource getDataSource(String alias) {
		BasicDataSource ds = null;
		if(dsMap != null && dsMap.size() > 0 ) {
			ds = dsMap.get(alias);
		}
		return ds;
	}
	
	public void putDataSource(String alias, BasicDataSource ds) {
		if(dsMap == null) {
			this.dsMap = new HashMap<>();
		}
		this.dsMap.put(alias, ds);
		
	}
	
	public int size() {
		int sz = 0;
		if(this.dsMap != null) {
			sz = this.dsMap.size();
		}
		return sz;
	}
	
	public Iterator<String> iterAlias() {
	
		Iterator<String> aliases = null;
		if(this.dsMap != null) {
			aliases = this.dsMap.keySet().iterator();
		}
		return aliases;
	}
}
