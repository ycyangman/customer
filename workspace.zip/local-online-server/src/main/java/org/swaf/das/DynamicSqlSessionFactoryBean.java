package org.swaf.das;

import java.io.File;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.io.FileUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DynamicSqlSessionFactoryBean extends SqlSessionFactoryBean {

	
	@Autowired
	ApplicationContext contex;
	
	private SqlSessionFactory proxy;
	private int interval = 500;
	
	private Timer timer;
	private TimerTask task;
	
	private Resource[] mapperLocations;
	
	private String sqlReloadDirective;
	
	//파일 감시 쓰레드가 실행중인여부
	private boolean running = false;
	
	private final ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
	private final Lock r = rwl.readLock();
	private final Lock w = rwl.writeLock();
	
	
	public void setMapperLocations(Resource... mapperLocations ) {
		super.setMapperLocations(mapperLocations);
		this.mapperLocations = mapperLocations;
	}
	
	public void setSqlReloadDirective(String sqlReloadDirective ) {
		this.sqlReloadDirective = sqlReloadDirective;
	}
	
	public void setInterval(int interval) {
		this.interval= interval;
	}
	
	public void refresh() {
		if(log.isInfoEnabled()) {
			log.info("refreshing sqlMapClient!!");
		}
		w.lock();
		
		try {
			super.afterPropertiesSet();
			
		}
		catch(Exception e) {
			log.error("fail to refresh sql mapper files!!", e);
			throw new RuntimeException("fail to refresh sql mapper files!!");
		}
		finally {
			w.unlock();
		}
		
		
	}
	
	//singletone SqlMapClient 원본대신 프록시로 설정하도록 오버라이드
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		setRefreshable();
	}
	
	private Object getParentObject() throws Exception {
		r.lock();
		try {
			return super.getObject();
		}
		finally {
			r.unlock();
		}
	}
	public void setRefreshable() {
		proxy = (SqlSessionFactory) Proxy.newProxyInstance(SqlSessionFactory.class.getClassLoader(),
				new Class[] {SqlSessionFactory.class}, new InvocationHandler() {
					public Object invoke(Object proxy, Method method, Object[] args) throws Throwable{
						
						log.info("####################### method : {}", method.getName());
						return method.invoke(getParentObject(), args);
					}
				
		});
		
		task = new TimerTask() {
			public void run() {
				if(existSqlReloadDirective()) {
					
					try {
						refresh();
						if(log.isInfoEnabled()) {
							log.info("sqlmap xml files are sucessfully reloaded!!");
						}
					}
					finally {
						try {
							FileUtils.forceDelete(new File(sqlReloadDirective));
						}
						catch(Exception e) {
							if(log.isWarnEnabled()) {
								log.warn("fail to delte sql reload directive file [{}]", sqlReloadDirective );
							}
						}
					}
					
				}
			}
			
			private boolean existSqlReloadDirective() {
				
				if(sqlReloadDirective == null) {
					return false;
				}
				File directive = new File(sqlReloadDirective);
				return directive.exists();
			}
		};
		
		if(timer != null) {
			if(running) {
				timer.cancel();
				timer.purge();
				running = false;
				timer = null;
			}
			else {
				timer = null;
			}
		}
		timer = new Timer(true);
		resetInterval();
	}
	
	public SqlSessionFactory getObject() {
		return this.proxy;
	}
	
	public Class<? extends SqlSessionFactory> getObjectType() {
		return (this.proxy != null ? this.proxy.getClass() : SqlSessionFactory.class);
	}
	
	public boolean isSingleton() {
		return true;
	}
	
	public void setCheckInterval(int ms) {
		interval = ms;
		
		if(timer != null) {
			resetInterval();
		}
	}
	
	private void resetInterval() {
		if(running) {
			timer.cancel();
			timer.purge();
			running = false;
		}
		if(interval > 0) {
			timer.schedule(task, 0, interval);
			running = true;
		}
		
	}
	
	public void destroy() throws Exception {
		log.info("DynamicSqlSessionFactoryBean is destroyed now !");
		
		if(timer != null) {
			timer.cancel();
			timer.purge();
			timer = null;
		}
		
		Thread.sleep(3000);
		
	}
	
}
