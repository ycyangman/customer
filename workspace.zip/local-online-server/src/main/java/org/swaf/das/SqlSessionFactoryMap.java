package org.swaf.das;

import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.lang3.ObjectUtils;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SqlSessionFactoryMap {

	@Getter
	HashMap<String, DynamicSqlSessionFactoryBean> map;
	
	@Getter @Setter
	DynamicSqlSessionFactoryBean primarySqlSessionFactoryBean;
	
	public DynamicSqlSessionFactoryBean getSqlSessionFactoryBean(String alias) {
		
		DynamicSqlSessionFactoryBean sqlSessionFactoryBean = null;
		if( !ObjectUtils.isEmpty(map) ) {
			sqlSessionFactoryBean = this.map.get(alias);
		}
		return sqlSessionFactoryBean;
	}
	
	public void putSqlSessionFactoryBean(String alias,DynamicSqlSessionFactoryBean sqlSessionFactoryBean ) {
		
		if( this.map == null) {
			this.map = new HashMap<>();
		}
		this.map.put(alias, sqlSessionFactoryBean);
		
	}
	
	public void destroyAll() {
		if( !ObjectUtils.isEmpty(map) ) {
			Iterator<String> keys = map.keySet().iterator();
			while(keys.hasNext()) {
				try {
					map.get(keys.next()).destroy();
				}
				catch(Exception e) {
					if(log.isWarnEnabled()) {
						log.warn("fail to destroy sqlSessionFactoryBean!!", e);
					}
				}
				
			}
			this.map.clear();
			this.map = null;
		}
	}
}
