package org.swaf.das;

import java.util.HashMap;

import org.apache.commons.lang3.ObjectUtils;
import org.mybatis.spring.SqlSessionTemplate;

import lombok.Getter;
import lombok.Setter;

public class SqlSessionTemplateMap {

	@Getter
	HashMap<String, SqlSessionTemplate> map;
	
	@Getter @Setter
	SqlSessionTemplate primarySqlSessionTemplate;
	
	
	public SqlSessionTemplate getSqlSessionTemplate(String alias) {
		SqlSessionTemplate sqlSessionTemplate = null;
		if( !ObjectUtils.isEmpty(map) ) {
			sqlSessionTemplate = this.map.get(alias);
		}
		return sqlSessionTemplate;
	}
	
	public void putSqlSessionTemplate(String alias, SqlSessionTemplate sqlSessionTemplate ) {
		if( this.map == null) {
			this.map = new HashMap<>();
		}
		this.map.put(alias, sqlSessionTemplate);
	}
}
