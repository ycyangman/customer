package org.swaf.das;

import java.util.HashMap;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import lombok.Getter;
import lombok.Setter;

public class TransactionManagerMap {

	
	HashMap<String, DataSourceTransactionManager> map;
	
	@Getter @Setter
	DataSourceTransactionManager primaryTxManager;
	
	
	public DataSourceTransactionManager getTxManager(String alias) {
		DataSourceTransactionManager txManager = null;
		if( !ObjectUtils.isEmpty(map) ) {
			txManager = this.map.get(alias);
		}
		return txManager;
	}
	
	public void putTxManager(String alias, DataSourceTransactionManager txManager ) {
		if( this.map == null) {
			this.map = new HashMap<>();
		}
		this.map.put(alias, txManager);
	}
}
