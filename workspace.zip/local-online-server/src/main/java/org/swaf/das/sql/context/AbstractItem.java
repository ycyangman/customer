package org.swaf.das.sql.context;

public abstract class AbstractItem {
	public static final int LEFT = 0;
	public static final int RIGHT = 1;
	public static final int BOTH = 2;
	private String name;
	protected int position = 0;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPosition() {
		return this.position;
	}

	public abstract void setPosition(int paramInt);
}