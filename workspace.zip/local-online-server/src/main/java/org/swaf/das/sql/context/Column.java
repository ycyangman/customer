package org.swaf.das.sql.context;

public class Column {
	String name;
	String type;
	String length;
	String decimal;
	String comment;

	public Column(String name, String type, String length, String decimal, String comment) {
		this.name = name;
		this.type = type;
		this.length = length;
		this.decimal = decimal;
		this.comment = comment;
	}

	public String getName() {
		return this.name;
	}

	public String getType() {
		return this.type;
	}

	public String getLength() {
		return this.length;
	}

	public String getDecimal() {
		return this.decimal;
	}

	public String getComment() {
		return this.comment;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s, %s, %s, %s, %s",
				new Object[] { this.name, this.type, this.length, this.decimal, this.comment }));
		return sb.toString();
	}
}