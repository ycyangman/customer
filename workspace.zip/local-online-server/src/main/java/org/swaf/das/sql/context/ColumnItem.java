package org.swaf.das.sql.context;

import org.apache.commons.lang3.StringUtils;

public class ColumnItem extends AbstractItem {
	private static final String TIMESTAMP = "TIMESTAMP";
	private TableItem parent;
	public static final int VALID = 0;
	public static final int INVALID_TYPE = 1;
	public static final int UNREGISTERD_META = 2;
	private String type = "";
	private String ommType = "";
	private String length = "";
	private String decimal = "";
	private String comment = "";
	private String etc;
	private int valid = 0;

	public TableItem getParent() {
		return this.parent;
	}

	public void setParent(TableItem parent) {
		this.parent = parent;
	}

	public void setPosition(int position) {
		this.position = position;

		if (parent.isAllChildInSide(position)) {
			parent.setPosition(position);
		} else {
			this.parent.setPosition(2);
		}
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		if (type == null)
			return;
		this.type = type;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		if (comment == null)
			return;
		this.comment = comment;
	}

	public String getLength() {
		return this.length;
	}

	public void setLength(String length) {
		if (length == null)
			return;
		this.length = length;
	}

	public String getDecimal() {
		return this.decimal;
	}

	public void setDecimal(String decimal) {
		if (decimal == null)
			return;
		this.decimal = decimal;
	}

	public String getEtc() {
		return this.etc;
	}

	public void setEtc(String etc) {
		this.etc = etc;
	}

	public String getOmmType() {
		return this.ommType;
	}

	public void setOmmType(String ommType) {
		this.ommType = ommType;
	}

	/*
	 * public int isValid() { boolean isDefaultType =
	 * ClassTypeUtil.isDefaultType(getOmmType());
	 * 
	 * if (!isDefaultType) { return 1; }
	 * 
	 * return this.valid; }
	 */
	public void setValid(int valid) {
		this.valid = valid;
	}

	public String toString() {
		if ("TIMESTAMP".equals(this.type))
			return String.format("%s - %s : (%s)", new Object[] { getName(), getType(), getComment() });
		if (StringUtils.isEmpty(this.decimal)) {
			return String.format("%s - %s(%s) : (%s)",
					new Object[] { getName(), getType(), getLength(), getComment() });
		}
		return String.format("%s - %s(%s,%s)  : (%s)",
				new Object[] { getName(), getType(), getLength(), getDecimal(), getComment() });
	}
}