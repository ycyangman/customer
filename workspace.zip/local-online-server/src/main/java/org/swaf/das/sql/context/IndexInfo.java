package org.swaf.das.sql.context;

import java.util.ArrayList;
import java.util.List;

import org.swaf.das.sql.generator.DatabaseMetaColumn;

public class IndexInfo {
	  private String indexName;
	  private boolean unique = false;

	  private List<DatabaseMetaColumn> columns = new ArrayList<>();


	  public IndexInfo(String indexName, boolean unique) {
	    this.indexName = indexName;
	    this.unique = unique;
	  }

	  public List<DatabaseMetaColumn> getColumns() {
	    return this.columns;
	  }

	  public void setColumns(List<DatabaseMetaColumn> columns) {
	    this.columns = columns;
	  }


	  public String getIndexName() {
	    return this.indexName;
	  }

	  public void setIndexName(String indexName) {
	    this.indexName = indexName;
	  }

	  public boolean isUnique() {
	    return this.unique;
	  }

	  public void setUnique(boolean unique) {
	    this.unique = unique;
	  }

	  public String toString()
	  {
	    StringBuilder builder = new StringBuilder();
	    builder.append("IndexInfo [indexName=").append(this.indexName)
	      .append(", unique=").append(this.unique).append(", columns=")
	      .append(this.columns).append("]\n");
	    return builder.toString();
	  }
}
