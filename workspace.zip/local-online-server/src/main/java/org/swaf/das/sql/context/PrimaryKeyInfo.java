package org.swaf.das.sql.context;

import java.util.HashMap;
import java.util.Map;

import org.swaf.das.sql.generator.DatabaseMetaColumn;

public class PrimaryKeyInfo {

	
	  private String pkName;
	  private Map<Integer, DatabaseMetaColumn> pkColumns = new HashMap<>();

	  public PrimaryKeyInfo(String pkName) {
	    this.pkName = pkName;
	  }

	  public String getPkName() {
	    return this.pkName;
	  }

	  public void setPkName(String pkName) {
	    this.pkName = pkName;
	  }

	  public Map<Integer, DatabaseMetaColumn> getPkColumns() {
	    return this.pkColumns;
	  }

	  public void setPkColumns(Map<Integer, DatabaseMetaColumn> pkColumns) {
	    this.pkColumns = pkColumns;
	  }
	  
}
