package org.swaf.das.sql.context;

import java.util.Iterator;
import java.util.LinkedHashMap;

public class Table {

	public LinkedHashMap<String, Column> columnMap = new LinkedHashMap<>();
	private String tableName;
	private String comment;

	public Table(String tableName, String comment) {
		this.tableName = tableName;
		this.comment = comment;
	}

	public String getTableName() {
		return this.tableName;
	}

	public String getComment() {
		return this.comment;
	}

	public void putColumn(Column column) {
		this.columnMap.put(column.getName(), column);
	}

	public Column getColumn(String name) {
		return (Column) this.columnMap.get(name);
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("tableName=");
		sb.append(this.tableName);
		sb.append("\n");

		sb.append("comment=");
		sb.append(this.comment);
		sb.append("\n");

		Iterator it = this.columnMap.keySet().iterator();

		while (it.hasNext()) {
			String key = (String) it.next();
			sb.append("\t");
			sb.append("column : " + ((Column) this.columnMap.get(key)).toString());
			sb.append("\n");
		}

		return sb.toString();
	}

}
