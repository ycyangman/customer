package org.swaf.das.sql.context;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class TableInfo {

	
    String tableName           ;
    String tableComment        ;
    String columnName          ;
    String columnComment       ;
    String columnDataType      ;
    String columnDataLength    ;
    String columnDataScale     ;
    String columnDataPrecision ;
    
}
