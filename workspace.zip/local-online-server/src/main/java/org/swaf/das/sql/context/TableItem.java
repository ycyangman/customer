package org.swaf.das.sql.context;

import java.util.ArrayList;

public class TableItem extends AbstractItem
{
  private boolean isOpened = false;
  private boolean isExpanded = false;
  private String comment = null;

  private ArrayList<ColumnItem> columns = new ArrayList<>();

  public boolean isOpened() {
    return this.isOpened;
  }

  public void setOpened(boolean isOpened) {
    this.isOpened = isOpened;
  }

  public boolean addColumn(ColumnItem item)
  {
    item.setParent(this);
    return this.columns.add(item);
  }

  public boolean removeColumn(ColumnItem item)
  {
    return this.columns.remove(item);
  }

  public int indexOf(ColumnItem item)
  {
    return this.columns.indexOf(item);
  }

  public void clear()
  {
    this.columns.clear();
  }

  public boolean isAllChildInSide(int position)
  {
    boolean isAllChildInSide = true;

    synchronized (this.columns) {
      for (ColumnItem ci : this.columns)
      {
        if (ci.getPosition() == position)
          continue;
        isAllChildInSide = false;
        break;
      }
    }

    return isAllChildInSide;
  }

  public ColumnItem[] getChildren()
  {
    return (ColumnItem[])this.columns.toArray(new ColumnItem[this.columns.size()]);
  }

  public void setPosition(int position) {
    this.position = position;
  }

  public void setPositionAll(int position)
  {
    this.position = position;

    for (ColumnItem ci : this.columns)
    {
      ci.position = position;
    }
  }

  public boolean isExpanded() {
    return this.isExpanded;
  }

  public void setExpanded(boolean isExpanded) {
    this.isExpanded = isExpanded;
  }

  public String toString()
  {
    if (this.comment == null)
    {
      return getName();
    }

    return String.format("%s : (%s)", new Object[] { getName(), getComment() });
  }

  public String getComment()
  {
    return this.comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }
}
