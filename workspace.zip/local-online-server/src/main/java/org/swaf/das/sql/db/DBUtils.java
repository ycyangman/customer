package org.swaf.das.sql.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DBUtils {
	public static void setAutoCommit(Connection con, boolean autoCommit)
		    throws SQLException
		  {
		    if (con == null) {
		      return;
		    }

		    con.setAutoCommit(autoCommit);
		    log.debug(" TX : Change Auto Commit = {} ", Boolean.valueOf(autoCommit));
		  }

		  public static void tryCommit(Connection con)
		  {
		    if (con == null)
		      return;
		    try
		    {
		      con.commit();
		      log.debug(" TX : commit ");
		    } catch (SQLException localSQLException) {
		      log.debug(" TX : fail to commit ");
		      tryRollback(con);
		    }
		  }

		  public static void tryRollback(Connection con)
		  {
		    if (con == null) {
		      return;
		    }
		    try
		    {
		      con.rollback();
		      log.debug(" TX : rollback ");
		    }
		    catch (SQLException localSQLException) {
		    }
		  }

		  public static void tryClose(ResultSet rs) {
		    if (rs == null)
		      return;
		    try
		    {
		      rs.close();
		    }
		    catch (SQLException localSQLException) {
		    }
		  }

		  public static void tryClose(Statement st) {
		    if (st == null)
		      return;
		    try
		    {
		      st.close();
		    }
		    catch (SQLException localSQLException) {
		    }
		  }

		  public static void tryClose(Connection con) {
		    if (con == null)
		      return;
		    try
		    {
		      con.close();
		    }
		    catch (SQLException localSQLException)
		    {
		    }
		  }
}
