package org.swaf.das.sql.db;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public interface IQueryConstants {

	  public static final String TEXT_READ_ONLY = "읽기전용입니다.";
	  public static final String DOCTYPE_NAME = "mapper";
	  public static final String DOCTYPE_PUBLIC = "-//mybatis.org//DTD Mapper 3.0//EN";
	  public static final String DOCTYPE_SYSTEM = "http://mybatis.org/dtd/mybatis-3-mapper.dtd";
	  public static final String[] SUB_ELEMENTS = { 
	    "if", "choose", "when", "otherwise", "trim", "where", "set", "foreach" };
	  public static final String SHORTCUT_ID = "swaf.das.ui.shortcut";
	  public static final String QUERY_TYPE_SELECT = "select";
	  public static final String QUERY_TYPE_INSERT = "insert";
	  public static final String QUERY_TYPE_UPDATE = "update";
	  public static final String QUERY_TYPE_DELETE = "delete";
	  public static final String QUERY_TYPE_MERGE = "merge";
	  public static final Set<String> QUERY_TYPES = new HashSet<String>(
	    Arrays.asList(new String[] { 
	    "select", 
	    "insert", 
	    "update", 
	    "delete", 
	    "merge" }));

	  public static final String[] ATTR_NAMES = { 
	    "parameterType", 
	    "parameterMap", 
	    "resultType", 
	    "resultMap", 
	    "flushCache", 
	    "useCache", 
	    "timeout", 
	    "fetchSize", 
	    "statementType", 
	    "resultSetType", 
	    "useGeneratedKeys", 
	    "keyProperty", 
	    "keyColumn" };
	  public static final String JAVADOC_TEST_VALUES = "@TestValues";
	  public static final String DATA_ACCESS_QUALIFIED_NAME = "swaf.container.annotation.swafDataAccess";
	  //public static final String DATA_ACCESS_NAME = JavaUtils.getClassName("swaf.container.annotation.swafDataAccess");
	  public static final String DATA_ACCESS_ATTR_MAPPER = "mapper";
	  public static final String DATA_ACCESS_ATTR_DATASOURCE = "datasource";
	  public static final String swaf_CATEGORY_QUALIFIED_NAME = "swaf.common.annotaion.swafCategory";
	  public static final String swaf_CATEGORY_ATTR_LOGICAL_NAME = "logicalName";
	  public static final String swaf_CATEGORY_ATTR_DESCRIPTION = "description";
	  public static final String EXECUTOR_QUALIFIED_NAME = "swaf.container.das.DasExecutor";
	  //public static final String EXECUTOR_NAME = JavaUtils.getClassName("swaf.container.das.DasExecutor");
	  public static final String EXECUTOR_ATTR_EXECUTOR = "executor";
	  public static final String EXECUTOR_TYPE_QUALIFIED_NAME = "swaf.container.das.ExecutorType";
	  //public static final String EXECUTOR_TYPE_NAME = JavaUtils.getClassName("swaf.container.das.ExecutorType");
	  public static final String DASLIST_UPDATE_QUALIFIED_NAME = "swaf.container.das.DasListUpdate";
	  //public static final String DASLIST_UPDATE_NAME = JavaUtils.getClassName("swaf.container.das.DasListUpdate");
	  public static final String EXECUTOR_TYPE_SIMPLE = "SIMPLE";
	  public static final String EXECUTOR_TYPE_CONNECTED_BATCH = "CONNECTED_BATCH";
	  public static final String EXECUTOR_TYPE_DEFAULT_VALUE = "SIMPLE";
	  public static final Set<String> EXECUTOR_TYPE_VALUES = new HashSet<String>(
	    Arrays.asList(new String[] { "CONNECTED_BATCH", "SIMPLE" }));
	  public static final String HISTORY_QUALIFIED_NAME = "swaf.container.das.DasHistory";
	  //public static final String HISTORY_NAME = JavaUtils.getClassName("swaf.container.das.DasHistory");
	  public static final String HISTORY_ATTR_TABLE = "table";
	  public static final String PARAM_QUALIFIED_NAME = "org.apache.ibatis.annotations.Param";
	  //public static final String PARAM_NAME = JavaUtils.getClassName("org.apache.ibatis.annotations.Param");
	  public static final String QUERY_CUD_RETURN_TYPE = "int";
	  public static final String SQL_LINE_COMMENT = "--";
	  public static final int SQL_LINE_COMMENT_LEN = "--".length();
	  public static final String SQL_BLOCK_COMMENT_START = "/*";
	  public static final String SQL_BLOCK_COMMENT_END = "*/";

	  public static abstract interface ErrorMessageType
	  {
	    public static final String RETURN_TYPE = "ReturnType";
	    public static final String EXECUTOR_TYPE = "ExecutorType";
	    public static final String BINDINGS = "Bindings";
	    public static final String DESC = "Desc";
	    public static final String SQL_CONTENTS = "SqlContents";
	    public static final String ATTRIBUTES = "Attr";
	    public static final String STATEMENT_TYPE = "StatementType";
	    public static final String ID = "ID";
	    public static final String INPUT_PARAM = "InputParam";
	  }
}
