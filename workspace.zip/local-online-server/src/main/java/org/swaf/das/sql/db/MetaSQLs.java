package org.swaf.das.sql.db;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.HashMap;

import org.springframework.util.StreamUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MetaSQLs {

	private static MetaSQLs INSTANCE;
	private HashMap<String, String> map = null;

	private MetaSQLs() {
		load();
	}

	public static MetaSQLs instance() {
		if (INSTANCE == null) {
			INSTANCE = new MetaSQLs();
		}
		return INSTANCE;
	}

	private void load() {
		this.map = new HashMap<>();

		InputStream mariaIs = Thread.currentThread().getContextClassLoader().getResourceAsStream("/org/swaf/das/sql/db/maria_sql.resource");
		InputStream oracleIs = Thread.currentThread().getContextClassLoader().getResourceAsStream("/org/swaf/das/sql/db/oracle_sql.resource");

		if (mariaIs == null && oracleIs == null) {

			mariaIs  = MetaSQLs.class.getClassLoader().getResourceAsStream("org/swaf/das/sql/db/maria_sql.resource");
			oracleIs = MetaSQLs.class.getClassLoader().getResourceAsStream("org/swaf/das/sql/db/oracle_sql.resource");
			
		}
		
		log.debug("############ mariaIs:: {}" , mariaIs );
		log.debug("############ oracleIs:: {}" , oracleIs );
		
		try {
			String mariaSql = new String(StreamUtils.copyToByteArray(mariaIs));
			this.map.put("MARIA_SQL", mariaSql);

			String oracleSql = new String(StreamUtils.copyToByteArray(oracleIs));
			this.map.put("ORACLE_SQL", oracleSql);
		} 
		catch (Exception localException) {
		
		}
	}

	public String getSQL(String id) {
		if ((this.map == null) || (this.map.size() == 0))
			load();

		return (String) this.map.get(id);
	}
}
