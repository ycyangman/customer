package org.swaf.das.sql.db;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SQLParseUtils {


	
	public static String getVariable(String columnName) throws Exception {
		StringBuilder buf = new StringBuilder();

		String name = columnName.toLowerCase();

		int index = 0;
		char ch = name.charAt(index);
		if (!Character.isJavaIdentifierStart(ch)) {
			log.error("columnName = {}, index= {}", columnName, Integer.valueOf(index));
			throw new Exception("테이블 컬럼명을 이용한 변수명 변환에 실패하였습니다." + columnName);
		}
		buf.append(ch);

		boolean upperCase = false;

		for (index = 1; index < name.length(); index++) {
			ch = name.charAt(index);

			if (ch == '_') {
				upperCase = true;
			} else {
				if (!Character.isJavaIdentifierPart(ch)) {
					log.error("columnName = {}, index= {}", columnName, Integer.valueOf(index));
					throw new Exception("테이블 컬럼명을 이용한 변수명 변환에 실패하였습니다." + columnName);
				}

				if (upperCase) {
					buf.append(Character.toUpperCase(ch));
					upperCase = false;
				} else {
					buf.append(ch);
				}
			}
		}
		return buf.toString();
	}

	public static boolean isOperator(char ch) {
		if (Character.isLetterOrDigit(ch)) {
			return false;
		}

		switch (ch) {
		case '$':
		case '.':
		case '@':
		case '_':
			return false;
		}

		return true;
	}

	public static int findEndMarkQuotation(String sql, int pos, char endMark) throws Exception {
		int index = pos + 1;

		log.debug(" Search End Mark [{}], {} ", Character.valueOf(endMark), Integer.valueOf(pos));

		int end = sql.indexOf(endMark, index);
		if (end < 0) {
			log.debug("Wrong SQL : Can't find end Mark");
			throw new Exception("SQL 이 올바르게 작성되지 않았습니다.");
		}

		if (endMark == '\'') {
			end++;
			char ch = sql.charAt(end);
			if (ch == '\'')
				index = findEndMarkQuotation(sql, end, '\'');
			else
				index = end - 1;
		} else {
			index = end;
		}

		log.debug(" [{}] End Position = {}", Character.valueOf(sql.charAt(index)), Integer.valueOf(index));

		return index;
	}

	public static int findEndMarkDoubleQuotation(String sql, int pos) {
		int index = pos + 1;

		log.debug(" find EndMark of DoubleQuotation {} ", Integer.valueOf(pos));

		int end = sql.indexOf('"', index);
		if (end < 0) {
			log.debug("Wrong SQL : Can't find endMark of DoubleQuotation");
			throw new RuntimeException();
		}

		index = end;
		log.debug(" [{}] Quotation End Position = {}", Character.valueOf(sql.charAt(index)), Integer.valueOf(index));

		return index;
	}

	public static int findEndMarkSingleQuotation(String sql, int pos) {
		int index = pos + 1;

		log.debug(" find EndMark of SingleQuotation {} ", Integer.valueOf(pos));

		int end = sql.indexOf('\'', index);
		if (end < 0) {
			log.debug("Wrong SQL : Can't find endMark of SingleQuotation");
			throw new RuntimeException();
		}

		end++;
		char ch = sql.charAt(end);
		if (ch == '\'')
			index = findEndMarkSingleQuotation(sql, end);
		else {
			index = end - 1;
		}

		log.debug(" [{}] Quotation End Position = {}", Character.valueOf(sql.charAt(index)), Integer.valueOf(index));

		return index;
	}

	public static int findEndMarkBind(String sql, int pos) {
		int index = pos + 1;

		if (sql.charAt(index) != '{') {
			log.debug("Wrong SQL : Can't find endMark of Bind");
			throw new RuntimeException();
		}

		log.debug(" find EndMark of Bind = {} ", Integer.valueOf(pos));

		int end = sql.indexOf('}', index);
		if (end < 0) {
			log.debug("Wrong SQL : Can't find endMark of DoubleQuotation");
			throw new RuntimeException();
		}

		index = end;
		log.debug(" [{}] End Position of bind = {}", Character.valueOf(sql.charAt(index)), Integer.valueOf(index));

		return index;
	}

	public static boolean isDynamicSyntax(String sql, int index) {
		if (getSubElementName(sql, index + 1) != null) {
			return true;
		}

		return sql.charAt(index + 1) == '/';
	}

	public static int findEndMarkDynamic(String sql, int index) {
		int current = index;

		int endMark = sql.indexOf('>', current);
		if (endMark < 0) {
			throw new RuntimeException("SQL의 Dynamic 문법 작성이 올바르지 않습니다.");
		}

		int doubleQuotationMark = sql.indexOf('"', current);
		if (doubleQuotationMark < 0) {
			return endMark;
		}
		if (endMark < doubleQuotationMark) {
			return endMark;
		}
		int next = findEndMarkDoubleQuotation(sql, doubleQuotationMark);
		return findEndMarkDynamic(sql, next + 1);
	}

	public static String getSubElementName(String input, int i) {
		for (String sub : IQueryConstants.SUB_ELEMENTS) {
			if (!input.startsWith(sub, i))
				continue;
			char ch = input.charAt(i + sub.length());
			if ((Character.isWhitespace(ch)) || (ch == '>')) {
				return sub;
			}

		}

		return null;
	}
}