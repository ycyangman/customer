package org.swaf.das.sql.generator;

public class DatabaseMetaColumn {

	private String columnName;
	private String variable;
	private boolean numeric;
	private String dataType;
	private int intDataType = 0;
	private String desc;
	

	public DatabaseMetaColumn(String columnName, String variable, boolean numeric, String dataType, String desc) {
		this.columnName = columnName;
		this.variable = variable;
		this.numeric = numeric;
		this.dataType = dataType;
		this.desc = desc;
	}

	public DatabaseMetaColumn(String columnName, String variable, boolean numeric, int dataType, String desc) {
		this.columnName = columnName;
		this.variable = variable;
		this.numeric = numeric;
		this.intDataType = dataType;
		this.desc = desc;
	}
	
	public String getColumnName() {
		return this.columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getVariable() {
		return this.variable;
	}

	public void setVariable(String variable) {
		this.variable = variable;
	}

	public boolean isNumeric() {
		return this.numeric;
	}

	public void setNumeric(boolean numeric) {
		this.numeric = numeric;
	}

	public String getDataType() {
		return this.dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDataTypeString(int dbType) {
		return getOracleDataTypeString();
	}

	public String getDesc() {
		return this.desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	private String getOracleDataTypeString() {
		switch (this.intDataType) {
		case 12:
			return "VARCHAR";
		case -5:
			return "BIGINT";
		case -2:
			return "BINARY";
		case -7:
			return "BIT";
		case 2004:
			return "BLOB";
		case 16:
			return "BOOLEAN";
		case 1:
			return "CHAR";
		case 2005:
			return "CLOB";
		case 91:
			return "DATE";
		case 3:
			return "DECIMAL";
		case 8:
			return "DOUBLE";
		case 6:
			return "FLOAT";
		case 4:
			return "INTEGER";
		case -15:
			return "NCHAR";
		case 2011:
			return "NCLOB";
		case 0:
			return "NULL";
		case 2:
			return "NUMERIC";
		case -9:
			return "NVARCHAR";
		case 1111:
			return "OTHER";
		case 7:
			return "REAL";
		case 5:
			return "SMALLINT";
		case 2002:
			return "STRUCT";
		case 92:
			return "TIME";
		case 93:
			return "TIMESTAMP";
		case -3:
			return "VARBINARY";
		case -16:
		case -8:
		case -4:
		case -1:
		case 70:
		case 2000:
		case 2001:
		case 2003:
		case 2006:
		case 2009:
		}

		return "UNDEFINED";
	}

	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DatabaseMetaColumn [columnName=").append(this.columnName).append(", variable=")
				.append(this.variable).append(", numeric=").append(this.numeric).append(", dataType=")
				.append(this.dataType).append(", desc=").append(this.desc).append("]\n");
		return builder.toString();
	}
}
