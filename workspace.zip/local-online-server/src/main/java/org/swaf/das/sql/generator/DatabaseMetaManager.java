package org.swaf.das.sql.generator;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.lang3.StringUtils;
import org.swaf.das.support.vo.VoGenerator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DatabaseMetaManager {

	
	public String generateSQL(String driverType, DataSource dataSource, String statementType, String schemaName, String tableName, String tableComment, boolean isAutoJdbcType, boolean isDynamic) throws Exception {

		DefaultSQLGenerate generateSQL = new DefaultSQLGenerate(driverType);

		if (StringUtils.isEmpty(statementType)) {
			throw new Exception("statement Type 을 선택하세요.");
		}

		if ("SELECT".equalsIgnoreCase(statementType)) {

			return generateSQL.generateDefaultSQLForSelect(dataSource,schemaName ,tableName,
					isAutoJdbcType, tableComment, true);
		}

		if ("INSERT".equalsIgnoreCase(statementType)) {
			return generateSQL.generateDefaultSQLForInsert(dataSource, schemaName, tableName, isDynamic,
					isAutoJdbcType, tableComment);
		}
		if ("UPDATE".equalsIgnoreCase(statementType)) {
			return generateSQL.generateDefaultSQLForUpdate(dataSource, schemaName, tableName, isDynamic,
					isAutoJdbcType, tableComment, true);
		}
		if ("DELETE".equalsIgnoreCase(statementType)) {
			return generateSQL.generateDefaultSQLForDelete(dataSource, schemaName, tableName,
					isAutoJdbcType, tableComment, true);
		}

		if ("MERGE".equalsIgnoreCase(statementType)) {
			return generateSQL.generateDefaultSQLForMerge(dataSource, schemaName, tableName, isAutoJdbcType,
					tableComment);
		}

		throw new Exception("statement Type 이 알 수 없는 Type 입니다.");
	}

	public static void main(String[] args) throws Exception {
		
		BasicDataSource ds = new BasicDataSource();
		
		//for maria
		/*
		String driver = "org.mariadb.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/swaf";
		String username = "root";
		String password = "5912";
		
		String driverType = "MARIADB";
		String schemaName = "ezins";
		String tableName = "tb_txlogs";
		
		*/
		
				
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		String username = "ycyang";
		String password = "5912";
		

		ds.setDriverClassName(driver);
		ds.setUrl(url);
		ds.setUsername(username);		
		ds.setPassword(password);
		

		
		DatabaseMetaManager dbMetaMgr = new DatabaseMetaManager();
		
		String driverType = "ORACLE";
		String schemaName = "ycyang";
		String tableName = "TBMSACM010";
		
		
		String statementType = "MERGE";
		String tableComment = "거래로그";
		boolean isAutoJdbcType = true;
		boolean isDynamic = true;
		
		
		String result = "";
		try {
		
			result = dbMetaMgr.generateSQL(driverType, ds, statementType, schemaName, tableName, tableComment, isAutoJdbcType, isDynamic);
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("==================================");
		System.out.println(result);
		
		ds.close();
		
		/*
		
		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
		}

		//String url = "jdbc:oracle:thin:@192.168.0.10:1521:EAMT";
		
		Connection conn = null;
		
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		*/
		
		
		
	}
}
