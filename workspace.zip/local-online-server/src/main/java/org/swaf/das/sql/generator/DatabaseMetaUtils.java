package org.swaf.das.sql.generator;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.swaf.das.sql.context.ColumnItem;
import org.swaf.das.sql.context.IndexInfo;
import org.swaf.das.sql.context.PrimaryKeyInfo;
import org.swaf.das.sql.context.TableItem;
import org.swaf.das.sql.db.DBUtils;
import org.swaf.das.sql.db.SQLParseUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DatabaseMetaUtils  {

	private static void validate(String schemaName, String tableName) throws Exception {
		if (StringUtils.isEmpty(schemaName)) {
			throw new Exception("스키마명이 입력되지 않았습니다.");
		}
		log.debug("schema = {}", schemaName);

		if (StringUtils.isEmpty(tableName)) {
			throw new Exception("테이블명이 입력되지 않았습니다.");
		}
		log.debug("table = {}", tableName);
	}

	protected static boolean isNumeric(int type) {
		
		switch (type) {
		case -6:   //java.sql.Types.TINYINT
		case -5:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 8:
			return true;
		case -4:
		case -3:
		case -2:
		case -1:
		case 0:
		case 1:
		case 7:
		}
		return false;
	}


	public static Map<Integer, DatabaseMetaColumn> getColumns(String driverType, DataSource dataSource, String schemaname, String tablename)
			throws Exception {
		validate(schemaname, tablename);

		schemaname.toUpperCase();

		Connection conn = dataSource.getConnection();

		if (conn == null) {
			throw new Exception("Connection is null : " + dataSource);
		}

		log.debug("DataSource : {}, Connection : {}", new Object[] { dataSource, conn });

		Map<Integer, DatabaseMetaColumn> result = new HashMap<>();

		TableItem[] tableItems = null;


		MetaInfoAction metaInfo = null;
		
		if("MARIADB".equalsIgnoreCase(driverType)) {
			metaInfo = new MariaMetaInfoAction(conn, schemaname.toUpperCase(), tablename, false);
		}
		else {
			metaInfo = new MetaInfoAction(conn, schemaname.toUpperCase(), tablename, false);
		}
		
		try {
			metaInfo.run();
		} 
		catch (InvocationTargetException e) {
			e.printStackTrace();
			throw new Exception();
		}
		
		tableItems = metaInfo.getTableItems();
		

		TableItem found = null;

		for (TableItem item : tableItems) {
			if (!item.getName().equalsIgnoreCase(tablename))
				continue;
			found = item;
			break;
		}

		ColumnItem[] columns = found.getChildren();
		int i = 0;
		for (ColumnItem column : columns) {
			i++;
			String columnName = column.getName().toLowerCase();
			String variable = SQLParseUtils.getVariable(columnName);
			String type = column.getType();
			String desc = column.getComment();

			
			DatabaseMetaColumn col = new DatabaseMetaColumn(columnName, variable, false, type, desc);

			result.put(Integer.valueOf(i), col);
		}
		if (result.isEmpty()) {
			throw new Exception("테이블이 존재하지 않거나 테이블에 컬럼이 존재하지 않습니다.");
		}
		return result;
	}

	public static IndexInfo[] getIndexInfoList(DataSource dataSource, String schemaName, String tableName,
			Set<String> pkNameSet, boolean includePk) throws Exception {
		validate(schemaName, tableName);

		Connection conn = dataSource.getConnection();

		log.debug("DataSource : {}, Connection : {}", new Object[] { dataSource, conn });

		Map<String, IndexInfo> indexMap = new LinkedHashMap<>();

		ResultSet rs = null;
		String indexName;
		try {
			DatabaseMetaData dbMeta = conn.getMetaData();

			rs = dbMeta.getIndexInfo(null, schemaName, tableName, false, true);

			while (rs.next()) {
				indexName = rs.getString("INDEX_NAME");

				if ((StringUtils.isEmpty(indexName)) || ((!includePk) && (pkNameSet.contains(indexName)))) {
					continue;
				}
				IndexInfo indexInfo = (IndexInfo) indexMap.get(indexName);

				if (indexInfo == null) {
					boolean nonUnique = rs.getBoolean("NON_UNIQUE");
					indexInfo = new IndexInfo(indexName, !nonUnique);

					indexMap.put(indexName, indexInfo);
				}

				String columnName = rs.getString("COLUMN_NAME");
				if (columnName == null)
					continue;
				String variable = SQLParseUtils.getVariable(columnName);

				ResultSet rsColumn = dbMeta.getColumns(null, schemaName, tableName, columnName);

				int dataType = -1;
				try {
					while (rsColumn.next()) {
						dataType = rsColumn.getInt("DATA_TYPE");
					}
				} 
				catch (Exception e) {
					e.printStackTrace();
					throw new Exception(e);
				}
				finally {
					DBUtils.tryClose(rsColumn);
				}

				DatabaseMetaColumn col = new DatabaseMetaColumn(columnName.toLowerCase(), variable, false, dataType, "");

				indexInfo.getColumns().add(col);
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} 
		finally {
			DBUtils.tryClose(rs);
		}

		for (IndexInfo indexInfo : indexMap.values()) {
			System.out.println(indexInfo);
		}

		return (IndexInfo[]) indexMap.values().toArray(new IndexInfo[indexMap.size()]);
	}

	public static PrimaryKeyInfo[] getPrimaryKeyInfo(DataSource dataSource, String schemaName, String tableName)
			throws Exception {
		validate(schemaName, tableName);

		String schema = schemaName.toUpperCase();
		String table = tableName.toUpperCase();

		Connection conn = dataSource.getConnection();

		ResultSet rs = null;

		Map<String, PrimaryKeyInfo> pkMap = new LinkedHashMap<>();
		try {
			DatabaseMetaData dbMeta = conn.getMetaData();

			rs = dbMeta.getPrimaryKeys(null, schema, table);
			System.out.println("~~~~~~~~~~~~~~@ 1 : " + dataSource);
			
			while (rs.next()) {
				String pkName = rs.getString("PK_NAME");
				System.out.println(">>pkName : " + pkName);
				
				PrimaryKeyInfo pkInfo = (PrimaryKeyInfo) pkMap.get(pkName);

				if (pkInfo == null) {
					pkInfo = new PrimaryKeyInfo(pkName);

					pkMap.put(pkName, pkInfo);
				}

				String columnName = rs.getString("COLUMN_NAME");
				System.out.println(">>columnName : " + columnName);
				String variable = SQLParseUtils.getVariable(columnName);
				ResultSet rsColumn = dbMeta.getColumns(null, null, table, columnName);

				int dataType = -1;
				while (rsColumn.next()) {
					dataType = rsColumn.getInt("DATA_TYPE");
				}

				rsColumn.close();

				int index = rs.getInt("KEY_SEQ");

				DatabaseMetaColumn col = new DatabaseMetaColumn(columnName, variable, false, dataType, "");

				pkInfo.getPkColumns().put(Integer.valueOf(index), col);
			}
		}
		catch (SQLException e) {
			throw new Exception(e.getMessage());
		} 
		finally {
			DBUtils.tryClose(rs);
		}

		return (PrimaryKeyInfo[]) pkMap.values().toArray(new PrimaryKeyInfo[pkMap.size()]);
	}

	public static Map<Integer, DatabaseMetaColumn> getPKColumns(DataSource dataSource, String schemaname, String tablename)
			throws Exception {
		
		validate(schemaname, tablename);

		schemaname.toUpperCase();
		String table = tablename.toUpperCase();

		Connection conn = dataSource.getConnection();

		log.debug("DataSource : {}, Connection : {}", new Object[] { dataSource, conn });

		Map<Integer, DatabaseMetaColumn> result = new HashMap<>();
		ResultSet rs = null;
		try {
			DatabaseMetaData dbMeta = conn.getMetaData();

			String driverName = dbMeta.getDriverName().toUpperCase();
			
			String catalog = null;
			if(driverName.indexOf("MARIA") >=0) {
				catalog = schemaname;
			}
			
			rs = dbMeta.getPrimaryKeys(catalog, null, table);

			//log.debug("driverName : {}, rs : {}", new Object[] { driverName, rs.getFetchSize() });
			
			while (rs.next()) {
				String columnName = rs.getString("COLUMN_NAME").toLowerCase();
				String variable = SQLParseUtils.getVariable(columnName);
				
				ResultSet rsColumn = dbMeta.getColumns(catalog, null, table, columnName);

				log.debug("columnName : {}, rsColumnSize : {}", new Object[] { columnName, rsColumn.getFetchSize() });
				
				int dataType = -1;
				while (rsColumn.next()) {
					dataType = rsColumn.getInt("DATA_TYPE");
				}
				rsColumn.close();

				int index = rs.getInt("KEY_SEQ");

				DatabaseMetaColumn col = new DatabaseMetaColumn(columnName, variable, false, dataType, "");
				result.put(Integer.valueOf(index), col);
			}
			rs.close();
		}
		catch (SQLException e) {
			throw new Exception(e);
		} 
		finally {
			DBUtils.tryClose(rs);
		}

		return result;
	}

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
		}

		ResultSet rs = null;
		String url = "jdbc:oracle:thin:@192.168.0.10:1521:EAMT";
		Connection conn = null;
		
		try {
			conn = DriverManager.getConnection(url, "escode", "escode");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("-1");

		Map<String, IndexInfo> indexMap = new LinkedHashMap<>();
		String indexName;
		
		try {
			DatabaseMetaData dbMeta = conn.getMetaData();

			rs = dbMeta.getIndexInfo(null, null, "CSD_METHOD_CALLEE", false, false);

			while (rs.next()) {
				indexName = rs.getString("INDEX_NAME");

				if (StringUtils.isEmpty(indexName)) {
					continue;
				}
				
				IndexInfo indexInfo = (IndexInfo) indexMap.get(indexName);

				if (indexInfo == null) {
					boolean nonUnique = rs.getBoolean("NON_UNIQUE");
					indexInfo = new IndexInfo(indexName, !nonUnique);

					indexMap.put(indexName, indexInfo);
				}

				String columnName = rs.getString("COLUMN_NAME");

				String variable = SQLParseUtils.getVariable(columnName);

				ResultSet rsColumn = dbMeta.getColumns(null, null, "CSD_METHOD_CALLEE", columnName);

				int dataType = -1;
				try {
					while (rsColumn.next()) {
						dataType = rsColumn.getInt("DATA_TYPE");
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception(e);
				} finally {
					DBUtils.tryClose(rsColumn);
				}

				DatabaseMetaColumn col = new DatabaseMetaColumn(columnName, variable, false, dataType, "");
				indexInfo.getColumns().add(col);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
			DBUtils.tryClose(conn);
			DBUtils.tryClose(rs);
		}

		for (IndexInfo indexInfo : indexMap.values()) {
			System.out.println(indexInfo);
		}

		System.out.println("-2");
	}
}