package org.swaf.das.sql.generator;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.swaf.das.sql.context.IndexInfo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DefaultSQLGenerate {

	private static final String TAB = "        ";
	private static final String INDENT4 = "    ";
	public static final int WHERE_TYPE_PK = 0;
	public static final int WHERE_TYPE_UNIQUE_INDEX = 1;
	public static final int WHERE_TYPE_NON_UNIQUE_INDEX = 2;

	private String driverType = "ORACLE";
	
	public DefaultSQLGenerate (String driverType) {
		this.driverType = driverType;
	}
	
	public String generateDefaultSQLForInsert(DataSource dataSource, String schema, String table, boolean dynamic,
			boolean isAutoJdbcType, String tableComment) throws Exception {
		
		StringBuilder buf = new StringBuilder();

		Map<Integer, DatabaseMetaColumn> cols = DatabaseMetaUtils.getColumns(this.driverType, dataSource, schema, table);

		buf.append("INSERT  ");
		buf.append("\n");
		buf.append("  INTO  ");
		buf.append(table.toLowerCase());
		if (!StringUtils.isEmpty(tableComment)) {
			buf.append(INDENT4).append("/* ").append(tableComment).append(" */");
		}
		buf.append('\n');

		buf.append("(");
		buf.append('\n');

		if (dynamic) {
			buf.append("  ");
			buf.append("<trim suffixOverrides=\",\">");
			buf.append('\n');
		}

		for (int index = 0; index < cols.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) cols.get(Integer.valueOf(index + 1));
			
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			if (dynamic) {
				buf.append("  ");

				//String variableName = DASProperties.instance().ignoreColumnNameToBindName(col.getColumnName());

				String variableName = null;
				if (variableName == null) {
					buf.append("<if test=\" ");
					buf.append(col.getVariable());
					buf.append(" != null");
					if (col.isNumeric()) {
						buf.append(" && ");
						buf.append(col.getVariable());
						buf.append(" != 0");
					} else {
						buf.append(" && ");
						buf.append(col.getVariable());
						buf.append(" != ''");
					}
					buf.append(" \">");
					buf.append(" ");

					buf.append(col.getColumnName());

					if (!StringUtils.isEmpty(col.getDesc())) {
						buf.append("    ").append("/*").append(col.getDesc()).append("*/");
					}
					if (index < cols.size() - 1)
						buf.append(", ");
					buf.append(" </if>");
					buf.append('\n');
				} 
				else {
					buf.append(variableName);
					if (!StringUtils.isEmpty(col.getDesc())) {
						buf.append("    ").append("/*").append(col.getDesc()).append("*/");
					}
					if (index < cols.size() - 1)
						buf.append(", ");
					buf.append('\n');
				}

			} else {
				buf.append("  ");

				buf.append(col.getColumnName());

				if (!StringUtils.isEmpty(col.getDesc())) {
					buf.append("    ").append("/*").append(col.getDesc()).append("*/");
				}
				if (index < cols.size() - 1)
					buf.append(", ");
				buf.append('\n');
			}
		}

		if (dynamic) {
			buf.append("  ");
			buf.append("</trim>");
			buf.append('\n');
			buf.append(")");
			buf.append("\n");
			buf.append("VALUES ");
			buf.append("\n");
			buf.append("(");
			buf.append("\n");
			buf.append("  ");

			buf.append("<trim suffixOverrides=\",\">");
			buf.append('\n');
		} else {
			buf.append(")");
			buf.append("\n");
			buf.append("VALUES ");
			buf.append("\n");
			buf.append("(");
			buf.append("\n");
		}

		for (int index = 0; index < cols.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) cols.get(Integer.valueOf(index + 1));
			
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}
			System.out.println(">> col.getVariable() ; " + col.getVariable());
			if (dynamic) {
				buf.append("  ");

				String variableName = null;
				//String variableName = DASProperties.instance().ignoreColumnNameToBindName(col.getColumnName());

				if (variableName == null) {
					buf.append("<if test=\" ");
					buf.append(col.getVariable());
					buf.append(" != null");
					if (col.isNumeric()) {
						buf.append(" && ");
						buf.append(col.getVariable());
						buf.append(" != 0");
					} else {
						buf.append(" && ");
						buf.append(col.getVariable());
						buf.append(" != ''");
					}
					buf.append(" \">");
					buf.append(" ");

					buf.append("#{");
					buf.append(col.getVariable());
					buf.append("}");

					if (!StringUtils.isEmpty(col.getDesc())) {
						buf.append("    ").append("/*").append(col.getDesc()).append("*/");
					}
					if (index < cols.size() - 1)
						buf.append(", ");
					buf.append(" </if>");
					buf.append('\n');
				} else {
					buf.append(variableName);

					if (!StringUtils.isEmpty(col.getDesc())) {
						buf.append("    ").append("/*").append(col.getDesc()).append("*/");
					}
					if (index < cols.size() - 1)
						buf.append(", ");
					buf.append('\n');
				}
			} else {
				buf.append("  ");

				String variableName = null;
				//String variableName = DASProperties.instance().ignoreColumnNameToBindName(col.getColumnName());

				//-------------------------------------
				if (variableName == null) {
					buf.append(getRefinedVariableName(col, isAutoJdbcType));
				} 
				else {
					buf.append(variableName);
				}

				if (!StringUtils.isEmpty(col.getDesc())) {
					buf.append("    ").append("/*").append(col.getDesc()).append("*/");
				}
				if (index < cols.size() - 1)
					buf.append(", ");
				buf.append('\n');
			}
		}

		if (dynamic) {
			buf.append("  ");
			buf.append("</trim>");
			buf.append('\n');
			buf.append(")\n");
		} else {
			buf.append(")\n");
		}

		String result = buf.toString();
		log.debug(" SQL  => \n {}", result);

		return result;
	}

	public String generateDefaultSQLForDelete(DataSource dataSource, String schemaName, String tableName,
			boolean isAutoJdbcType, String tableComment, boolean pkWhere) throws Exception {
		StringBuilder buf = new StringBuilder();

		buf.append("DELETE  FROM  ");
		buf.append(tableName.toLowerCase());
		if (!StringUtils.isEmpty(tableComment)) {
			buf.append("    ").append("/* ").append(tableComment).append(" */");
		}
		buf.append('\n');

		if (pkWhere) {
			String whereStr = getWhereByPKColumns(dataSource, schemaName, tableName, isAutoJdbcType);
			if (!StringUtils.isEmpty(whereStr)) {
				buf.append(" WHERE  ");
				buf.append(whereStr);
				buf.append('\n');
			}
		}

		String result = buf.toString();
		log.debug(" SQL  = {}", result);

		return result;
	}

	public String generateDefaultSQLForUpdate(DataSource dataSource, String schema, String table, boolean dynamic,
			boolean isAutoJdbcType, String tableComment, boolean pkWhere) throws Exception {
		StringBuilder buf = new StringBuilder();

		Map<Integer, DatabaseMetaColumn> cols = DatabaseMetaUtils.getColumns(this.driverType, dataSource, schema, table);
		Collection<DatabaseMetaColumn> pkCols = DatabaseMetaUtils.getPKColumns(dataSource, schema, table).values();

		Set<String> pkColSet = new HashSet<>();

		for (DatabaseMetaColumn pkCol : pkCols) {
			pkColSet.add(pkCol.getColumnName());
		}

		buf.append("UPDATE  ");
		buf.append("\n");
		buf.append("        ");
		buf.append(table.toLowerCase());
		if (!StringUtils.isEmpty(tableComment)) {
			buf.append("    ").append("/* ").append(tableComment).append(" */");
		}
		buf.append('\n');
		buf.append("   SET  ");

		if (dynamic) {
			buf.append("<trim suffixOverrides=\",\">");
			buf.append('\n');
		}

		boolean first = true;

		for (int index = 0; index < cols.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) cols.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			if (pkColSet.contains(col.getColumnName())) {
				log.info("PK [{}] 무시", col.getColumnName());
			}
			/*
			else if (DASProperties.instance().isExcludeCreationColumnForUpdate(col.getColumnName())) {
				log.info("등록된 컬럼명 [{}] 무시", col.getColumnName());
			}
			*/ 
			else if (dynamic) {
				buf.append("        ");

				//String variableName = DASProperties.instance().ignoreColumnNameToBindName(col.getColumnName());
				String variableName = null;

				if (variableName == null) {
					buf.append("<if test=\" ");
					buf.append(col.getVariable());
					buf.append(" != null");
					if (col.isNumeric()) {
						buf.append(" && ");
						buf.append(col.getVariable());
						buf.append(" != 0");
					} else {
						buf.append(" && ");
						buf.append(col.getVariable());
						buf.append(" != ''");
					}

					buf.append(" \">");
					buf.append(" ");
					buf.append(col.getColumnName());
					buf.append(" = #{");
					buf.append(col.getVariable());
					buf.append("}");

					if (!StringUtils.isEmpty(col.getDesc())) {
						buf.append("    ").append("/* ").append(col.getDesc()).append(" */");
					}
					if (index < cols.size() - 1)
						buf.append(", ");
					buf.append(" </if>");
					buf.append('\n');
				} else {
					buf.append(variableName);
					if (!StringUtils.isEmpty(col.getDesc())) {
						buf.append("    ").append("/* ").append(col.getDesc()).append(" */");
					}
					if (index < cols.size() - 1)
						buf.append(", ");
					buf.append('\n');
				}
			} else {
				if (first)
					first = false;
				else {
					buf.append("        ");
				}
				buf.append(col.getColumnName());
				buf.append(" = ");

				String variableName = null;
				//String variableName = DASProperties.instance().ignoreColumnNameToBindName(col.getColumnName());
				
				System.out.println(">> variableName : " + variableName);
				if (variableName == null) {
					buf.append(getRefinedVariableName(col, isAutoJdbcType));
				} else {
					buf.append(variableName);
				}

				if (!StringUtils.isEmpty(col.getDesc())) {
					buf.append("    ").append("/* ").append(col.getDesc()).append(" */");
				}
				if (index < cols.size() - 1)
					buf.append(", ");
				buf.append('\n');
			}
		}

		if (dynamic) {
			buf.append("        ");
			buf.append("</trim>");
			buf.append('\n');
		}

		if (pkWhere) {
			String whereStr = getWhereByPKColumns(dataSource, schema, table, isAutoJdbcType);
			if (!StringUtils.isEmpty(whereStr)) {
				buf.append(" WHERE  ");
				buf.append(whereStr);
				buf.append('\n');
			}
		}

		String result = buf.toString();
		log.debug(" SQL  = {}", result);

		return result;
	}

	public String generateDefaultSQLForSelect(DataSource dataSource, String schemaName, String tableName,
			boolean isAutoJdbcType, String tableComment, boolean pkWhere) throws Exception {
		StringBuilder buf = new StringBuilder();

		Map<Integer, DatabaseMetaColumn> cols = DatabaseMetaUtils.getColumns(this.driverType, dataSource, schemaName, tableName);

		buf.append("SELECT  ");

		if (!StringUtils.isEmpty(tableComment)) {
			buf.append("/* ").append(tableComment).append(" */");
		}
		buf.append("\n");

		for (int index = 0; index < cols.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) cols.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			buf.append("        ");
			buf.append(col.getColumnName()).append(" AS ").append(col.getVariable());

			if (!StringUtils.isEmpty(col.getDesc())) {
				buf.append("    ").append("/*").append(col.getDesc()).append("*/");
			}

			if (index < cols.size() - 1)
				buf.append(", ");

			buf.append('\n');
		}

		buf.append("  FROM  ");
		buf.append(tableName.toLowerCase());
		buf.append('\n');

		if (pkWhere) {
			String whereStr = getWhereByPKColumns(dataSource, schemaName, tableName, isAutoJdbcType);

			if (!StringUtils.isEmpty(whereStr)) {
				buf.append(" WHERE  ");
				buf.append(whereStr);
				buf.append('\n');
			}
		}
		return buf.toString();
	}

	public String getWhereByIndexColumns(IndexInfo indexInfo) {
		StringBuilder buf = new StringBuilder();

		boolean first = true;

		for (DatabaseMetaColumn col : indexInfo.getColumns()) {
			if (first)
				first = false;
			else {
				buf.append("   AND  ");
			}
			buf.append(col.getColumnName());
			buf.append(" = #{");
			buf.append(col.getVariable());
			buf.append("}");
			buf.append('\n');
		}

		return buf.toString();
	}

	private String getWhereByPKColumns(DataSource dataSource, String schema, String table, boolean isAutoJdbcType)
			throws Exception {
		StringBuilder buf = new StringBuilder();

		boolean first = true;

		Map<Integer, DatabaseMetaColumn> pks = DatabaseMetaUtils.getPKColumns( dataSource, schema, table);
		if ((pks == null) || (pks.isEmpty())) {
			return null;
		}

		for (int index = 0; index < pks.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) pks.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			if (first)
				first = false;
			else {
				buf.append("   AND  ");
			}
			buf.append(col.getColumnName());
			buf.append(" = #{");
			buf.append(col.getVariable());
			buf.append("}");
			buf.append('\n');
		}

		return buf.toString();
	}

	private String getRefinedVariableName(DatabaseMetaColumn col, boolean isAutoJdbcType) {
		StringBuilder buf = new StringBuilder();

		buf.append("#{");
		buf.append(col.getVariable());
		if (isAutoJdbcType) {
			buf.append(", jdbcType=");
			buf.append(refineMyBatisType(col.getDataType()));
		}
		buf.append("}");

		return buf.toString();
	}

	/*
	private String getRefinedVariableName(DatabaseMetaColumn col, boolean isAutoJdbcType) {
		StringBuilder buf = new StringBuilder();

		buf.append("#{");
		buf.append(col.getVariable());
		if (isAutoJdbcType) {
			buf.append(", jdbcType=");
			buf.append(col.getDataTypeString(col.getDataType()));
		}
		buf.append("}");

		return buf.toString();
	}
	*/
	
	private String getRefinedVariableName(DatabaseMetaColumn col) {
		StringBuilder buf = new StringBuilder();

		buf.append("#{");
		buf.append(col.getVariable());
		buf.append("}");

		return buf.toString();
	}



	private String refineMyBatisType(String type) {
		if (("VARCHAR2".equalsIgnoreCase(type)) || "VARCHAR".equalsIgnoreCase(type) || "CHAR".equalsIgnoreCase(type)) {
			return "VARCHAR";
		}
		if ("NUMBER".equalsIgnoreCase(type) || type.indexOf("int")>-1 ) {
			return "NUMERIC";
		}
		return type.toUpperCase();
	}

	public String generateDefaultSQLForMerge(DataSource dataSource, String schemaName, String tableName,
			boolean isAutoJdbcType, String tableComment) throws Exception {
		StringBuilder buf = new StringBuilder();

		Map<Integer, DatabaseMetaColumn> cols = DatabaseMetaUtils.getColumns(this.driverType, dataSource, schemaName, tableName);

		Map<Integer, DatabaseMetaColumn> pks = DatabaseMetaUtils.getPKColumns(dataSource, schemaName, tableName);

		String syntaxForMergeOnPart = generateSytaxForMergeOnPart(pks, isAutoJdbcType);

		String syntaxForMergeMatchedPart = generateSyntaxForMergeMatchedPart(pks, cols, isAutoJdbcType);

		String syntaxForMergeNotMatchedPart = generateSyntaxForMergeNotMatchedPart(cols, isAutoJdbcType);

		buf.append("MERGE  INTO ").append(tableName);

		if (!StringUtils.isEmpty(tableComment)) {
			buf.append("    ").append("/*").append(tableComment).append("*/");
		}

		buf.append("\n").append("USING DUAL").append("\n").append("ON").append("(\n").append(syntaxForMergeOnPart)
				.append(")\n");

		buf.append("WHEN MATCHED THEN").append("\n").append(syntaxForMergeMatchedPart).append("\n")
				.append("WHEN NOT MATCHED THEN").append("\n").append(syntaxForMergeNotMatchedPart).append("\n");

		return buf.toString();
	}

	@Deprecated
	private String generateSytaxForMergeUsingPart(Map<Integer, DatabaseMetaColumn> pks) throws Exception {
		StringBuilder sb = new StringBuilder();
		sb.append("    ");
		sb.append("SELECT  ");

		for (int index = 0; index < pks.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) pks.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			if (index > 0)
				sb.append("    ").append("        ");

			sb.append(getRefinedVariableName(col)).append(" AS ").append(col.getVariable());

			if (index < pks.size() - 1)
				sb.append(", ");

			if (!StringUtils.isEmpty(col.getDesc())) {
				sb.append("    ").append("/*").append(col.getDesc()).append("*/");
			}

			sb.append("\n");
		}
		sb.append("    ");
		sb.append("  FROM  dual").append("\n");

		return sb.toString();
	}

	private String generateSytaxForMergeOnPart(Map<Integer, DatabaseMetaColumn> pks, boolean isAutoJdbcType)
			throws Exception {
		StringBuilder sb = new StringBuilder();

		for (int index = 0; index < pks.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) pks.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			if (index == 0) {
				sb.append("    ");
				if (pks.size() > 1)
					sb.append("    ");
			} else {
				sb.append("   AND  ");
			}

			sb.append(col.getColumnName()).append(" = ").append(getRefinedVariableName(col, false));

			if (!StringUtils.isEmpty(col.getDesc())) {
				sb.append("    ").append("/*").append(col.getDesc()).append("*/");
			}
			sb.append('\n');
		}

		return sb.toString();
	}

	private String generateSyntaxForMergeMatchedPart(Map<Integer, DatabaseMetaColumn> pks,
			Map<Integer, DatabaseMetaColumn> cols, boolean isAutoJdbcType) throws Exception {
		StringBuilder sb = new StringBuilder();
		sb.append("    ");

		sb.append("UPDATE  SET").append("\n");

		HashSet<String> pkCols = new HashSet<>();
		Iterator<DatabaseMetaColumn> it = pks.values().iterator();

		while (it.hasNext()) {
			pkCols.add(((DatabaseMetaColumn) it.next()).getColumnName());
		}

		for (int index = 0; index < cols.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) cols.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			if (pkCols.contains(col.getColumnName())) {
				continue;
			}
			sb.append("    ");
			sb.append("  ");
			sb.append(col.getColumnName());
			sb.append(" = ");
			sb.append(getRefinedVariableName(col, isAutoJdbcType));
			if (index < cols.size() - 1)
				sb.append(", ");
			if (!StringUtils.isEmpty(col.getDesc())) {
				sb.append("    ").append("/* ").append(col.getDesc()).append(" */");
			}
			sb.append("\n");
		}

		return sb.toString();
	}

	private String generateSyntaxForMergeNotMatchedPart(Map<Integer, DatabaseMetaColumn> cols, boolean isAutoJdbcType)
			throws Exception {
		StringBuilder sb = new StringBuilder();
		sb.append("    ");

		sb.append("INSERT  ").append("    ").append("\n").append("    ").append("(").append("    ").append('\n');

		for (int index = 0; index < cols.size(); index++) {
			sb.append("    ");
			DatabaseMetaColumn col = (DatabaseMetaColumn) cols.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			sb.append("  ");
			sb.append(col.getColumnName());

			if (index < cols.size() - 1)
				sb.append(", ");
			if (!StringUtils.isEmpty(col.getDesc())) {
				sb.append("    ").append("/*").append(col.getDesc()).append("*/");
			}
			sb.append('\n');
		}
		sb.append("    ");
		sb.append(")").append("    ").append("\n").append("    ").append("VALUES ").append("    ").append("\n")
				.append("    ").append("(").append("    ").append("\n");

		for (int index = 0; index < cols.size(); index++) {
			sb.append("    ");
			DatabaseMetaColumn col = (DatabaseMetaColumn) cols.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new Exception("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}

			sb.append("  ");
			sb.append(getRefinedVariableName(col, isAutoJdbcType));

			if (index < cols.size() - 1)
				sb.append(", ");
			if (!StringUtils.isEmpty(col.getDesc())) {
				sb.append("    ").append("/*").append(col.getDesc()).append("*/");
			}
			sb.append('\n');
		}
		sb.append("    ");
		sb.append(")").append("\n");

		return sb.toString();
	}

	public String generateDefaultSQLForSelectByUniqueIndex(DataSource dataSource, String schemaName, String tableName,
			boolean isAutoJdbcType, String tableComment, IndexInfo indexInfo) throws Exception {
		StringBuilder buf = new StringBuilder();

		buf.append(generateDefaultSQLForSelect(dataSource, schemaName, tableName, isAutoJdbcType, tableComment, false));

		if (indexInfo != null) {
			String whereStr = getWhereByIndexColumns(indexInfo);

			if (!StringUtils.isEmpty(whereStr)) {
				buf.append(" WHERE  ");
				buf.append(whereStr);
				buf.append('\n');
			}
		}

		return buf.toString();
	}
}