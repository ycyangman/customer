package org.swaf.das.sql.generator;

import java.sql.Connection;

import org.apache.commons.lang3.StringUtils;
import org.swaf.das.sql.context.TableItem;
import org.swaf.das.sql.db.MetaSQLs;

public class MariaMetaInfoAction extends MetaInfoAction{

	Connection connection;
	String schemaName;
	String tableName;
	boolean like;

	TableItem[] tableItems;

	public MariaMetaInfoAction(Connection connection, String schemaName, String tableName, boolean like) {
		
		super(connection, schemaName, tableName, like);
		
		this.connection = connection;
		this.schemaName = schemaName;
		this.tableName = tableName;

		this.like = like;
	}

	public String createSql() {
		StringBuilder sb = new StringBuilder();

		if (!StringUtils.isEmpty(schemaName)) {
			sb.append("AND A.TABLE_SCHEMA = ").append('\'').append(this.schemaName).append('\'').append('\n');
		}

		if (!StringUtils.isEmpty(tableName)) {
			if (this.like) {
				sb.append("AND A.TABLE_NAME like ").append("'%").append(this.tableName).append("%'").append('\n');
			} else {
				sb.append("AND A.TABLE_NAME = ").append("'").append(this.tableName).append("'").append('\n');
			}
		}

		String sql = String.format(MetaSQLs.instance().getSQL("MARIA_SQL"), new Object[] { sb.toString() });
		return sql;
	}


}
