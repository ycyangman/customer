package org.swaf.das.sql.generator;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.swaf.das.sql.context.Column;
import org.swaf.das.sql.context.ColumnItem;
import org.swaf.das.sql.context.Table;
import org.swaf.das.sql.context.TableItem;
import org.swaf.das.sql.db.MetaSQLs;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MetaInfoAction {

	Connection connection;
	String schemaName;
	String tableName;
	boolean like;

	TableItem[] tableItems;

	public MetaInfoAction(Connection connection, String schemaName, String tableName, boolean like) {
		this.connection = connection;
		this.schemaName = schemaName;
		this.tableName = tableName;

		this.like = like;
	}

	public String createSql() {
		StringBuilder sb = new StringBuilder();

		if (!StringUtils.isEmpty(schemaName)) {
			sb.append("AND A.OWNER = ").append('\'').append(this.schemaName.toUpperCase(Locale.ENGLISH)).append('\'').append('\n');
		}

		if (!StringUtils.isEmpty(tableName)) {
			this.tableName = this.tableName.toUpperCase(Locale.ENGLISH);
			
			if (this.like) {
				sb.append("AND A.TABLE_NAME like ").append("'%").append(this.tableName).append("%'").append('\n');
			} else {
				sb.append("AND A.TABLE_NAME = ").append("'").append(this.tableName).append("'").append('\n');
			}
		}

		String sql = String.format(MetaSQLs.instance().getSQL("ORACLE_SQL"), new Object[] { sb.toString() });
		
		//log.info(sql);
		
		return sql;
	}

	public void run() throws InvocationTargetException {
		String platformEncoding = System.getProperty("file.encoding");
		
		if(StringUtils.isEmpty(platformEncoding)) {
			platformEncoding = "UTF-8";
		}

		LinkedHashMap<String, Table> tableMap = new LinkedHashMap<>();

		try {
			PreparedStatement ps = this.connection.prepareStatement(createSql());

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String tableName = rs.getString("TABLE_NAME");
				String tableComment = rs.getString("TABLE_COMMENT");
				String columnName = rs.getString("COLUMN_NAME");
				String columnComment = rs.getString("COLUMN_COMMENT");
				String columnDataType = rs.getString("COLUMN_DATA_TYPE");
				String columnDataLength = rs.getString("COLUMN_DATA_LENGTH");
				String columnDataScale = rs.getString("COLUMN_DATA_SCALE");
				String columnDataPrecision = rs.getString("COLUMN_DATA_PRECISION");

				if (tableName != null)
					tableName = new String(tableName.getBytes(), platformEncoding);
				else
					tableName = "";
				if (tableComment != null)
					tableComment = new String(tableComment.getBytes(), platformEncoding);
				else
					tableComment = "";
				if (columnName != null)
					columnName = new String(columnName.getBytes(), platformEncoding);
				else
					columnName = "";
				if (columnComment != null)
					columnComment = new String(columnComment.getBytes(), platformEncoding);
				else
					columnComment = "";
				if (columnDataType != null)
					columnDataType = new String(columnDataType.getBytes(), platformEncoding);
				else
					columnDataType = "";
				if (columnDataLength != null)
					columnDataLength = new String(columnDataLength.getBytes(), platformEncoding);
				else
					columnDataLength = "";
				if (columnDataScale != null)
					columnDataScale = new String(columnDataScale.getBytes(), platformEncoding);
				else
					columnDataScale = "";
				if (columnDataPrecision != null)
					columnDataPrecision = new String(columnDataPrecision.getBytes(), platformEncoding);
				else
					columnDataPrecision = "";

				String length = null;
				String decimal = null;

				Table tc = new Table(tableName, tableComment);
				;

				if (tableMap.containsKey(tableName)) {
					tc = (Table) tableMap.get(tableName);
				} else {
					tc = new Table(tableName, tableComment);
					tableMap.put(tableName, tc);
				}

				if ("NUMBER".equalsIgnoreCase(columnDataType) || "INT".equalsIgnoreCase(columnDataType)
						|| "BIGINT".equalsIgnoreCase(columnDataType) || "DECIMAL".equalsIgnoreCase(columnDataType)) {
					length = StringUtils.isEmpty(columnDataPrecision) ? "22" : columnDataPrecision;
					decimal = columnDataScale;
				}
				if ("TIMESTAMP".equalsIgnoreCase(columnDataType) || "DATETIME".equalsIgnoreCase(columnDataType)) {
					length = "30";
				} else {
					length = columnDataLength;
				}
				Column col = new Column(columnName, columnDataType, length, decimal, columnComment);
				tc.putColumn(col);

			}
			rs.close();
			ps.close();

			try {
				ArrayList<TableItem> tableItemList = new ArrayList<>();

				Iterator<Table> itTable = tableMap.values().iterator();

				while (itTable.hasNext()) {
					Table table = (Table) itTable.next();

					TableItem ti = new TableItem();
					ti.setName(table.getTableName());
					ti.setOpened(false);
					ti.setPosition(0);
					ti.setComment(table.getComment());

					Iterator<Column> itColumn = table.columnMap.values().iterator();

					while (itColumn.hasNext()) {
						Column col = (Column) itColumn.next();

						ColumnItem ci = new ColumnItem();
						ti.addColumn(ci);

						ci.setName(col.getName());
						ci.setComment(col.getComment());
						ci.setLength(col.getLength());

						String typeName = col.getType();
						if (typeName.startsWith("TIMESTAMP")) {
							ci.setType(typeName.substring(0, typeName.indexOf('(')));
							ci.setLength("30");
						} else {
							ci.setType(typeName);
							ci.setLength(col.getLength());
							ci.setDecimal(col.getDecimal());
						}
						ci.setPosition(0);
					}

					tableItemList.add(ti);
				}
				this.tableItems = ((TableItem[]) tableItemList.toArray(new TableItem[tableItemList.size()]));
			} catch (Exception e) {
				e.printStackTrace();
				throw new InvocationTargetException(e);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new InvocationTargetException(e);
		}
	}

	public TableItem[] getTableItems() {
		return this.tableItems;
	}
}
