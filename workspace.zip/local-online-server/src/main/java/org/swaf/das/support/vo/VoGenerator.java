package org.swaf.das.support.vo;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.swaf.das.sql.generator.DatabaseMetaColumn;
import org.swaf.das.sql.generator.DatabaseMetaUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class VoGenerator {

	
	public String makeMetaVO (String driverType, DataSource dataSource, String schemaName, String tableName, String packageName, String voName) throws Exception {
		
		//voName = "";
		
		Map<Integer, DatabaseMetaColumn> cols = DatabaseMetaUtils.getColumns(driverType, dataSource, schemaName, tableName);
		
		
		StringBuilder buf = new StringBuilder();
		buf.append("package " + packageName + ";");
		buf.append("\n");
		buf.append("\n");
		buf.append("import org.swaf.foundation.context.DefaultVO;");
		buf.append("\n");
		buf.append("import lombok.Data;");
		buf.append("\n");
		buf.append("import lombok.EqualsAndHashCode;");
		buf.append("\n");
		buf.append("\n");
		
		buf.append("@Data");
		buf.append("\n");
		buf.append("@EqualsAndHashCode(callSuper=false)");
		buf.append("\n");
		buf.append("public class "+voName+" extends DefaultVO { ");
		buf.append("\n");
		
		for (int index = 0; index < cols.size(); index++) {
			DatabaseMetaColumn col = (DatabaseMetaColumn) cols.get(Integer.valueOf(index + 1));
			if (col == null) {
				throw new RuntimeException("테이블의 해당 순서의 컬럼이 존재하지 않습니다. " + (index + 1));
			}
			
			buf.append("\t" +refineClassType(col.getDataType()) +" "+  col.getVariable() +"; ");
			buf.append("/* " + col.getDesc()+ " */"  );
			buf.append("\n");
			
		}
		buf.append("} ");
		
		log.debug(" vo  => \n{}", buf.toString());
		
		return buf.toString();
	}
	
	private void writeVO(String tgtAbsFileName, String content) {
		BufferedOutputStream bos = null;
		try {
			File file = new File(tgtAbsFileName);
			String voContent = content;
			byte[] bytes = voContent.getBytes("UTF-8");
			
			log.debug("Try write genertate VO source file : {}", file.getAbsolutePath());
			
			if(!file.getParentFile().exists()) {
				if(!file.getParentFile().mkdirs()) {
					throw new Exception("Could not create source directory :"+ file.getParentFile().getAbsolutePath());
				}
			}
			
			bos = new BufferedOutputStream(new FileOutputStream(file));
			bos.write(bytes);
			bos.flush();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				bos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	private String refineClassType(String type) {
		if (("VARCHAR2".equalsIgnoreCase(type)) || "VARCHAR".equalsIgnoreCase(type) || "CHAR".equalsIgnoreCase(type)) {
			return "String";
		}
		if ("NUMBER".equalsIgnoreCase(type) || type.indexOf("int")>-1 ) {
			return "int";
		}
		return type.toUpperCase();
	}
	
	public static void main(String[] args) throws Exception {
		
		String devPath = "D:/eclipse/workspace/sample-online/src/main/java";
		String pkgPath = "kr/ezinsurance";
		String svcPath = "sample/vo";
		
		String voName = "TBTxLogs";
		
		String filePath = String.format("%s/%s/%s/%s.java", devPath, pkgPath, svcPath, voName);
		String packageStr = String.format("%s.%s", pkgPath, svcPath).replaceAll("\\/", ".");
				
		System.out.println("path :" + filePath);
		
		BasicDataSource ds = new BasicDataSource();
		
		//for maria
		/*
		String driver = "org.mariadb.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/swaf";
		String username = "root";
		String password = "5912";
		
		String driverType = "MARIADB";
		String schemaName = "ezins";
		String tableName = "tb_txlogs";
		
		*/
		
				
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		String username = "ycyang";
		String password = "5912";
		
		String driverType = "ORACLE";
		String schemaName = "ycyang";
		String tableName = "tb_txlogs";
		
		ds.setDriverClassName(driver);
		ds.setUrl(url);
		ds.setUsername(username);		
		ds.setPassword(password);
		

		
		VoGenerator voGenerator = new VoGenerator();
		
		String voContents = voGenerator.makeMetaVO (driverType, ds, schemaName, tableName, packageStr, voName);
		
		voGenerator.writeVO(filePath, voContents);
		
		ds.close();
		
		/*
		
		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
		}

		//String url = "jdbc:oracle:thin:@192.168.0.10:1521:EAMT";
		
		Connection conn = null;
		
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		*/
		
		
		
	}
	
}
