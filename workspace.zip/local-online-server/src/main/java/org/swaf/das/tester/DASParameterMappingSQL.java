package org.swaf.das.tester;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.ibatis.executor.parameter.ParameterHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.ParameterMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DASParameterMappingSQL
{
  private final ParameterHandler parameterHandler;
  private final BoundSql boundSql;

  private Logger log()
  {
    return LoggerFactory.getLogger(getClass());
  }

  public DASParameterMappingSQL(ParameterHandler parameterHandler, BoundSql boundSql)
  {
    this.parameterHandler = parameterHandler;
    this.boundSql = boundSql;
  }

  private void replaceTypeHandler(List<ParameterMapping> parameterMappings, DASTypeHandler dasTypeHandler)
  {
    if (parameterMappings == null) {
      return;
    }

    for (ParameterMapping parameterMapping : parameterMappings)
      try {
        ReflectionUtils.reflectSetField(parameterMapping, "typeHandler", dasTypeHandler);
      } catch (Exception e) {
        e.printStackTrace();
      }
  }

  public String guessExecuteSql()
    throws SQLException
  {
    List parameterMappings = this.boundSql.getParameterMappings();
    if ((parameterMappings == null) || (parameterMappings.size() <= 0)) {
      log().debug("parameterMappings is null or size is zero");
      return this.boundSql.getSql();
    }

    List backup = new ArrayList();

    backup.addAll(parameterMappings);

    DASTypeHandler dasTypeHandler = new DASTypeHandler(this.boundSql.getSql());
    replaceTypeHandler(parameterMappings, dasTypeHandler);

    PreparedStatement ps = new DASPreparedStatement();
    this.parameterHandler.setParameters(ps);

    parameterMappings.clear();
    parameterMappings.addAll(backup);

    return dasTypeHandler.getSQL();
  }
}