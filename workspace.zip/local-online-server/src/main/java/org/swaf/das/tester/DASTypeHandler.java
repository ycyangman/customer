package org.swaf.das.tester;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;

@SuppressWarnings("rawtypes")
public class DASTypeHandler implements TypeHandler {
	private final StringBuilder sql;
	private int index = 0;

	public DASTypeHandler(String sql) {
		this.sql = new StringBuilder(sql);
		this.index = 1;
	}

	public void setParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType) throws SQLException {
		if (this.index != i) {
			return;
		}

		this.index += 1;

		int pos = this.sql.indexOf("?");
		if (pos < 0) {
			return;
		}

		if (jdbcType == null) {
			if (parameter == null) {
				this.sql.replace(pos, pos + 1, "null");
			} else if ((parameter instanceof Number)) {
				this.sql.replace(pos, pos + 1, parameter.toString());
			} else {
				this.sql.replace(pos, pos + 1, MessageFormat.format("''{0}''", new Object[] { parameter.toString() }));
			}

		} else if ((jdbcType == JdbcType.INTEGER) || (jdbcType == JdbcType.FLOAT) || (jdbcType == JdbcType.DOUBLE)
				|| (jdbcType == JdbcType.DECIMAL) || (jdbcType == JdbcType.REAL) || (jdbcType == JdbcType.NUMERIC)) {
			this.sql.replace(pos, pos + 1, parameter.toString());
		} else
			this.sql.replace(pos, pos + 1, MessageFormat.format("''{0}''", new Object[] { parameter.toString() }));
	}

	public Object getResult(ResultSet rs, String columnName) throws SQLException {
		return null;
	}

	public Object getResult(CallableStatement cs, int columnIndex) throws SQLException {
		return null;
	}

	public String getSQL() {
		return this.sql.toString();
	}

	@Override
	public Object getResult(ResultSet rs, int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}