package org.swaf.das.tester;

import java.lang.reflect.Field;
import org.apache.ibatis.plugin.Invocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InterceptorUtils
{
  private static Logger log()
  {
    return LoggerFactory.getLogger(InterceptorUtils.class);
  }

  public static void debugInvocation(Invocation invocation)
  {
    log().debug("getTarget = {}", invocation.getTarget());
    log().debug("getMethod = {}", invocation.getMethod());

    Object[] args = invocation.getArgs();
    for (int index = 0; index < args.length; index++) {
      Object arg = args[index];
      log().debug("[{}] arg = {}", Integer.valueOf(index), arg);
    }
  }

  public static void debugFields(Object obj)
  {
    log().debug("debug Object Fields = {}", obj);

    Field[] fields = obj.getClass().getDeclaredFields();
    for (Field field : fields) {
      field.setAccessible(true);
      try {
        log().debug("field : {} = {}", field.getName(), field.get(obj));
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }
}