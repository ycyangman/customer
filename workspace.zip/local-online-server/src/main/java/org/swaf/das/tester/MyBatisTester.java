package org.swaf.das.tester;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.swaf.das.tester.input.jaxb.DataSourceField;
import org.swaf.das.tester.input.jaxb.MapperField;
import org.swaf.das.tester.input.jaxb.MapperInput;
import org.swaf.das.tester.input.jaxb.MapperTestInputConverter;
import org.swaf.foundation.annotation.DataAccess;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MyBatisTester {
	private Class<?> clazz = null;
	private MapperInput testInput = null;

	private String testFile = null;

	private final String connectionConfig = "DASTest_MyBatisConfig.xml";

	public static void main(String[] args) {
		MyBatisTester tester = new MyBatisTester();
		try {
			tester.test(args);
		} 
		catch (Exception e) {
			System.out.println("Exception : " + e);
			e.printStackTrace();
		}
	}

	void test(String[] args) throws Exception {
		//configureLogger();

		log.debug(" MyBatis Test Start ");

		if (args.length == 1) {
			this.testFile = args[0];
			log.debug(" >> This is Test Mode ... File = {}", this.testFile);
		}

		this.testInput = getTestInput();

		this.clazz = Class.forName(this.testInput.getNamespace());

		SqlSessionFactory sqlSessionFactory = createSqlSessionFactory();
		SqlSession session = sqlSessionFactory.openSession();

		execute(session, this.testInput.getMethodName(), this.testInput.getFields());

		session.close();
	}

	protected void configureLogger() {
		URL url = getClass().getClassLoader().getResource("DASTest_log4j.properties");
		if (null == url) {
			System.out.println(" URL is null ");
			return;
		}

		System.out.println(" >> Find Log Configuration :" + url);

	}

	protected MapperInput getTestInput() throws IOException {
		String xmlStr = null;

		if (this.testFile != null)
			xmlStr = readStreamForTest(this.testFile);
		else {
			xmlStr = readStream();
		}

		MapperInput testInput = MapperTestInputConverter
				.unmarshal(new ByteArrayInputStream(xmlStr.getBytes("UTF-8")));

		log.info("");
		log.info(" ---------------------------------------------- ");
		log.info("> namespace = {}", testInput.getNamespace());
		log.info("> method = {}", testInput.getMethodName());
		log.info(" ---------------------------------------------- ");
		log.info("");

		return testInput;
	}

	protected String readStreamForTest(String testFile) throws IOException {
		StringBuilder buffer = new StringBuilder();

		Reader reader = Resources.getResourceAsReader(testFile);
		BufferedReader buf_in = new BufferedReader(reader);

		while (buf_in.ready()) {
			buffer.append(buf_in.readLine());
		}

		return buffer.toString();
	}

	protected String readStream() throws IOException {
		StringBuilder buffer = new StringBuilder();

		InputStreamReader reader = new InputStreamReader(System.in);
		BufferedReader buf_in = new BufferedReader(reader);

		while (buf_in.ready()) {
			buffer.append(buf_in.readLine());
			buffer.append('\n');
		}

		return buffer.toString();
	}

	protected SqlSessionFactory createSqlSessionFactory() throws SQLException, IOException {
		String nameSpace = this.clazz.getName();

		DataAccess a = (DataAccess) this.clazz.getAnnotation(DataAccess.class);
		String xmlResource = a.mapper();

		//URL url = ClassLoader.getSystemClassLoader().getResource("DASTest_MyBatisConfig.xml");		
		URL url = getClass().getClassLoader().getResource("DASTest_MyBatisConfig.xml");
		
		Reader reader = new InputStreamReader(url.openStream());
		Properties prop = getDataSourceProperties(this.testInput.getDataSource());

		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(reader, prop);

		factory.getConfiguration().addMapper(this.clazz);
		loadMapper(nameSpace, xmlResource, factory.getConfiguration());

		return factory;
	}

	protected Properties getDataSourceProperties(DataSourceField ds) {
		Properties out = new Properties();

		out.setProperty("driver", ds.getDriver());
		out.setProperty("url", ds.getUrl());
		out.setProperty("username", ds.getUsername());
		out.setProperty("password", ds.getPassword());

		out.setProperty("maxRows", "50");
		//out.setProperty("v$session.program", "KLAF Builder");
		out.setProperty("v$session.module", "QueryTester");

		return out;
	}

	protected void loadMapper(String nameSpace, String xmlResource, Configuration configuration) throws IOException {
		InputStream inputStream = null;

		inputStream = Resources.getResourceAsStream(xmlResource);
		if (inputStream != null) {
			XMLMapperBuilder xmlParser = new XMLMapperBuilder(inputStream, configuration, xmlResource,
					configuration.getSqlFragments(), nameSpace);
			xmlParser.parse();
		}
	}

	protected void execute(SqlSession session, String methodName, List<MapperField> fields) throws Exception {
		
		Object mapper = session.getMapper(this.clazz);

		Method[] methods = this.clazz.getMethods();
		Object out = null;

		for (Method method : methods) {
			if (!method.getName().equals(methodName)) {
				continue;
			}

			boolean isDasListUpdate = false;
/*
			for (Annotation annotation : method.getAnnotations()) {
				if ("klaf.container.das.DasListUpdate".equals(annotation.annotationType().getName())) {
					isDasListUpdate = true;
					break;
				}
			}
*/			
			if (isDasListUpdate) {
				continue;
			}

			log.info("");
			log.info("---- STEP 1 : Input Parameter ----");

			Class<?> classes[] = method.getParameterTypes();
			
			Object[] params = null;

			if (hasParams(classes)) {
				params = new Object[classes.length];

				for (int i = 0; i < params.length; i++) {
					params[i] = getNullValue(classes[i].getName());
				}

				if (isHashMapParam(classes))
					params = getHashMapParam(params, fields);
				else
					params = getObjectParam(params, method.getParameterTypes(), fields);
			} else {
				log.info(" method 에 정의된 파라미터가 없습니다. ");
			}

			log.info("");
			log.info("---- STEP 2 : Execute SQL ----");


			out = invokeMethod(method, mapper, params);

		}

		log.info("");
		log.info("---- STEP 3 : Output ----");
		if ((out instanceof List)) {
			List<?> list = (List<?>) out;

			for (int index = 0; index < list.size(); index++) {
				Object item = list.get(index);
				log.info("output ([{}] of list) = {}", Integer.valueOf(index), item);
			}
		} else {
			log.info("output = {}", out);
		}

		log.info(" ---------------------------------------------- ");
		session.rollback();
		log.info("rollback ");
	}

	protected Object invokeMethod(Method method, Object mapper, Object[] params) throws Exception {
		long start = System.currentTimeMillis();
		Object out = method.invoke(mapper, params);
		long end = System.currentTimeMillis();

		long elpased = end - start;

		log.info("");
		log.info("Elapsed Time : {} sec {} millsec", Long.valueOf(elpased / 10000L), Long.valueOf(elpased % 10000L));

		return out;
	}

	protected Object[] getObjectParam(Object[] params, Class<?>[] classes, List<MapperField> fields)
			throws Exception {
		params = getParams(params, classes, fields);
		if ((params != null) && (params.length > 0)) {
			for (int index = 0; index < params.length; index++) {
				Class<?> paramClass = classes[index];
				Object param = params[index];

				log.info("([{}], {}) param = {}", new Object[] { Integer.valueOf(index), paramClass.getName(), param });
			}
		} else
			log.info(" 사용되는 입력 파라미터가 없습니다. ");

		return params;
	}

	protected Object[] getHashMapParam(Object[] params, List<MapperField> fields) throws Exception {
		log.info(" HashMap 을 사용합니다. ");

		Map<String, Object> param = new HashMap<>();

		for (MapperField field : fields) {
			String key = field.getName();
			Object value = getValue(field.getType(), field.getValue(), "");

			log.debug("set : key = {}, Value = {}", key, value);
			param.put(key, value);
		}

		if ((params != null) && (params.length == 1))
			params[0] = param;
		else {
			throw new Exception("HashMap 을 사용하는 Parameter List 가 잘못되었습니다.");
		}

		return params;
	}

	protected boolean isHashMapParam(Class<?>[] classes) {
		return (classes != null) && (classes.length == 1) && ("java.util.HashMap".equals(classes[0].getName()));
	}

	protected Method getForHistoryMethod(Method[] methods, String methodName, String keyQueryIdSuffix) {
		String id = methodName + keyQueryIdSuffix;

		for (Method method : methods) {
			if (method.getName().equals(id)) {
				log.debug(" find history method = {}", id);
				return method;
			}
		}

		return null;
	}

	protected Object[] getParams(Object[] params, Class<?>[] classes, List<MapperField> fields) throws Exception {
		Object[] objs = params;

		for (MapperField field : fields) {
			String name = field.getName();
			int pos = 0;
			if (StringUtils.isEmpty(name))
				pos = -1;
			else {
				pos = name.indexOf('.');
			}

			if (pos < 0) {
				objs[field.getParamNum()] = getValue(field.getType(), field.getValue(), "");
			} 
			else {
				Object obj = objs[field.getParamNum()];
				if (obj == null) {
					obj = classes[field.getParamNum()].newInstance();
					objs[field.getParamNum()] = obj;
				}

				String childName = name.substring(pos + 1);
				setValue(obj, childName, field.getType(), field.getValue());
			}
		}

		return objs;
	}

	protected void setValue(Object obj, String name, String type, String value) throws Exception {
		int pos = name.indexOf('.');
		Class<? extends Object> clazz = obj.getClass();

		if (pos < 0) {
			String format = null;

			Field field = getDeclaredField(clazz, name);

			//Annotation[] annotations = field.getAnnotations();

			/*
			 * int i=0; do { if(i >= annotations.length) { break; }
			 * 
			 * i++; } while(true)
			 * 
			 */

			Object vObj = getValue(type, value, format);

			field.setAccessible(true);
			field.set(obj, vObj);
		} else {
			String parentName = name.substring(0, pos);
			String childName = name.substring(pos + 1);

			Field field = getDeclaredField(clazz, parentName);
			field.setAccessible(true);

			Object childObj = field.get(obj);
			if (childObj == null) {
				childObj = field.getType().newInstance();
			}
			field.set(obj, childObj);

			setValue(childObj, childName, type, value);
		}
	}

	protected Field getDeclaredField(Class<?> clazz, String name) throws NoSuchFieldException {
		Field field = _getDeclaredField(clazz, name);

		return field;
	}

	protected Field _getDeclaredField(Class<?> clazz, String name) throws NoSuchFieldException {
		Field field = null;
		try {
			field = clazz.getDeclaredField(name);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			Class<?> superClazz = clazz.getSuperclass();
			if (superClazz != null) {
				field = getDeclaredField(superClazz, name);
			}
		}

		if (field == null) {
			throw new NoSuchFieldException();
		}

		return field;
	}

	protected boolean hasParams(Class<?>[] classes) {
		if (classes == null)
			return false;

		if (classes.length == 0)
			return false;

		if ((classes.length == 1) && (classes[0].isPrimitive())) {
			Class<?> clazz = classes[0];
			if ("void".equals(clazz.getName())) {
				return false;
			}
		}

		return true;
	}

	protected Object getNullValue(String qn) {
		if ("byte".equals(qn))
			return Byte.valueOf("");
		if ("long".equals(qn))
			return Long.valueOf(0L);
		if ("short".equals(qn))
			return Short.valueOf("0");
		if ("int".equals(qn))
			return Integer.valueOf(0);
		if ("double".equals(qn))
			return Double.valueOf(0.0D);
		if ("float".equals(qn))
			return Float.valueOf(0.0F);
		if ("boolean".equals(qn)) {
			return Boolean.valueOf(null);
		}
		return null;
	}

	protected Object getValue(String qn, String value, String format) throws ParseException {
		if (StringUtils.isEmpty(value)) {
			if ("java.lang.String".equals(qn)) {
				return value;
			}
			return null;
		}

		if ("byte".equals(qn))
			return Byte.valueOf(value);
		if ("long".equals(qn))
			return Long.valueOf(value);
		if ("short".equals(qn))
			return Short.valueOf(value);
		if ("int".equals(qn))
			return Integer.valueOf(value);
		if ("double".equals(qn))
			return Double.valueOf(value);
		if ("float".equals(qn))
			return Float.valueOf(value);
		if ("boolean".equals(qn))
			return Boolean.valueOf(value);
		if ("java.lang.String".equals(qn))
			return value;
		if ("java.lang.Byte".equals(qn))
			return new Byte(value);
		if ("java.lang.Long".equals(qn))
			return new Long(value);
		if ("java.lang.Short".equals(qn))
			return new Short(value);
		if ("java.lang.Integer".equals(qn))
			return new Integer(value);
		if ("java.lang.Double".equals(qn))
			return new Double(value);
		if ("java.lang.Float".equals(qn))
			return new Float(value);
		if ("java.lang.Boolean".equals(qn))
			return new Boolean(value);
		if ("java.util.Date".equals(qn)) {
			if (value == null) {
				return new Date();
			}
			if (value.trim().isEmpty()) {
				return new Date();
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			return sdf.parse(value);
		}

		if ("java.math.BigDecimal".equals(qn))
			return new BigDecimal(value);
		if ("java.math.BigInteger".equals(qn))
			return new BigInteger(value);

		System.out.println("#############################################");
		System.out.println("#Unsurported type : " + qn);
		System.out.println("#############################################\n");
		return null;
	}
}