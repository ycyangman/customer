package org.swaf.das.tester;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReflectionUtils
{
  private static Logger log()
  {
    return LoggerFactory.getLogger(ReflectionUtils.class);
  }

  public static void reflectSetField(Object obj, String fieldName, Object value) throws Exception
  {
    reflectField(true, obj, fieldName, value);
  }

  public static Object reflectGetField(Object obj, String fieldName) throws Exception
  {
    return reflectField(false, obj, fieldName, null);
  }

  public static Object reflectField(boolean set, Object obj, String fieldName, Object value) throws Exception
  {
    Object result = null;

    Field[] fields = obj.getClass().getDeclaredFields();
    for (Field field : fields) {
      try {
        if (field.getName().equals(fieldName)) {
          field.setAccessible(true);
          if (set)
            field.set(obj, value);
          else {
            result = field.get(obj);
          }

          break;
        }
      } catch (Exception e) {
        throw e;
      }
    }

    return result;
  }

  public static Map<String, Object> getAllFields(Object obj) throws Exception
  {
    Map results = new HashMap();

    Field[] fields = obj.getClass().getDeclaredFields();
    for (Field field : fields) {
      field.setAccessible(true);
      try {
        results.put(field.getName(), field.get(obj));
      }
      catch (Exception e) {
        throw e;
      }
    }

    return results;
  }
}