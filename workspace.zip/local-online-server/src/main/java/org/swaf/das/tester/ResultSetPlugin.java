package org.swaf.das.tester;

import java.lang.reflect.Field;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.executor.parameter.ParameterHandler;
import org.apache.ibatis.executor.resultset.DefaultResultSetHandler;

import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Intercepts({
		@org.apache.ibatis.plugin.Signature(
				type = org.apache.ibatis.executor.resultset.ResultSetHandler.class,
				method = "handleResultSets", args = {Statement.class }) })
public class ResultSetPlugin implements Interceptor {
	private Properties prop;

	private Logger log() {
		return LoggerFactory.getLogger(getClass());
	}

	public Object intercept(Invocation invocation) throws Throwable {
		int maxCount = resetMaxRows(invocation);
		Object result;

		if (UseHooker(invocation)) {
			DefaultResultSetHandler resultSetHandler = create((DefaultResultSetHandler) invocation.getTarget());
			result = resultSetHandler.handleResultSets((Statement) invocation.getArgs()[0]);
		} else {
			result = invocation.proceed();
		}

		if ((result instanceof List)) {
			List results = (List) result;
			if (results.size() == maxCount) {
				log().info("");
				log().info("테스트 성능를 위해 최대 건수를 [{}] 로 제한되었습니다.", Integer.valueOf(maxCount));
			}
		}

		return result;
	}

	public Object plugin(Object target) {
		return Plugin.wrap(target, this);
	}

	public void setProperties(Properties prop) {
		for (String key : prop.stringPropertyNames()) {
			log().debug("Properties : {} = {}", key, prop.getProperty(key));
		}

		this.prop = prop;
	}

	private int resetMaxRows(Invocation invocation) {
		Object[] args = invocation.getArgs();
		Statement stmt = (Statement) args[0];

		Integer _max = Integer.valueOf(this.prop.getProperty("MAXCOUNT"));
		if (_max != null) {
			int maxCount = _max.intValue();
			if (maxCount > 0) {
				try {
					stmt.setMaxRows(maxCount);
					return maxCount;
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return 0;
	}

	protected boolean UseHooker(Invocation invocation) {
		if (!(invocation.getTarget() instanceof DefaultResultSetHandler)) {
			return false;
		}

		try {
			DefaultResultSetHandler target = (DefaultResultSetHandler) invocation.getTarget();
			MappedStatement mappedStatement = getMappedStatement(target);

			return !mappedStatement.getId().endsWith("__getKeyForHistory");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	protected DefaultResultSetHandler create(DefaultResultSetHandler obj) throws Exception {
		Map<String, Object> args = ReflectionUtils.getAllFields(obj);

	
		return new DefaultResultSetHandler((Executor) args.get("executor"), (MappedStatement) args.get("mappedStatement"),
				(ParameterHandler) args.get("parameterHandler"), (ResultHandler) args.get("resultHandler"),
				(BoundSql) args.get("boundSql"), (RowBounds) args.get("rowBounds"));
	}

	protected MappedStatement getMappedStatement(DefaultResultSetHandler obj) throws Exception {
		Field[] fields = obj.getClass().getDeclaredFields();
		for (Field field : fields) {
			try {
				if ("mappedStatement".equals(field.getName())) {
					field.setAccessible(true);
					return (MappedStatement) field.get(obj);
				}
			} catch (Exception e) {
				throw e;
			}
		}

		throw new Exception("mappedStatement 가 없음");
	}
}