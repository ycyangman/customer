package org.swaf.das.tester.input.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="DataSourceField", propOrder={})
public class DataSourceField
{

  @XmlElement(required=true)
  protected String driver;

  @XmlElement(required=true)
  protected String url;

  @XmlElement(required=true)
  protected String username;

  @XmlElement(required=true)
  protected String password;

  public String getDriver()
  {
    return this.driver;
  }

  public void setDriver(String value)
  {
    this.driver = value;
  }

  public String getUrl()
  {
    return this.url;
  }

  public void setUrl(String value)
  {
    this.url = value;
  }

  public String getUsername()
  {
    return this.username;
  }

  public void setUsername(String value)
  {
    this.username = value;
  }

  public String getPassword()
  {
    return this.password;
  }

  public void setPassword(String value)
  {
    this.password = value;
  }
}