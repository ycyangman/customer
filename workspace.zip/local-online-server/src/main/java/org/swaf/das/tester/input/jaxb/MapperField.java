package org.swaf.das.tester.input.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MapperTestField", propOrder = {})
public class MapperField {
	protected int paramNum;

	@XmlElement(required = true)
	protected String type;

	@XmlElement(required = true)
	protected String name;

	@XmlElement(required = true)
	protected String value;

	public int getParamNum() {
		return this.paramNum;
	}

	public void setParamNum(int value) {
		this.paramNum = value;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String value) {
		this.type = value;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String value) {
		this.name = value;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}