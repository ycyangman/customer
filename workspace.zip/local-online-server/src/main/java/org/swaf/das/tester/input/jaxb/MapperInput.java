package org.swaf.das.tester.input.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MapperInput", propOrder = { "fields", "dataSource", "history" })
public class MapperInput {
	protected List<MapperField> fields;

	@XmlElement(required = true)
	protected DataSourceField dataSource;
	
	protected boolean history;

	@XmlAttribute
	protected String namespace;

	@XmlAttribute
	protected String methodName;

	public List<MapperField> getFields() {
		if (this.fields == null) {
			this.fields = new ArrayList<>();
		}
		return this.fields;
	}

	public DataSourceField getDataSource() {
		return this.dataSource;
	}

	public void setDataSource(DataSourceField value) {
		this.dataSource = value;
	}

	public boolean isHistory() {
		return this.history;
	}

	public void setHistory(boolean value) {
		this.history = value;
	}

	public String getNamespace() {
		return this.namespace;
	}

	public void setNamespace(String value) {
		this.namespace = value;
	}

	public String getMethodName() {
		return this.methodName;
	}

	public void setMethodName(String value) {
		this.methodName = value;
	}
}