package org.swaf.das.tester.input.jaxb;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MapperTestInputConverter {

	static Logger log() {
		return LoggerFactory.getLogger(MapperTestInputConverter.class);
	}

	public static MapperInput unmarshal(InputStream inputStream) throws IOException {
		MapperInput out = null;
		try {
			JAXBContext jc = JAXBContext.newInstance(org.swaf.das.tester.input.jaxb.MapperInput.class);

			XMLInputFactory xif = XMLInputFactory.newInstance();
			xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);
			XMLStreamReader xsr = xif.createXMLStreamReader(inputStream);
			
			Unmarshaller unmarsharller = jc.createUnmarshaller();
			out = (MapperInput) unmarsharller.unmarshal(xsr);
			
			/*
			Unmarshaller u = jc.createUnmarshaller();
			JAXBElement e = (JAXBElement) u.unmarshal(inputStream);
			out = (MapperInput) e.getValue();
			*/
		} 
		catch (Exception e) {
			e.printStackTrace();
			throw new IOException(e);
		}

		return out;
	}

	public static MapperTestInput unmarshalT(InputStream inputStream) throws IOException {
		MapperTestInput out = null;
		try {
			JAXBContext jc = JAXBContext.newInstance(org.swaf.das.tester.input.jaxb.MapperTestInput.class);
			
			XMLInputFactory xif = XMLInputFactory.newInstance();
			xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);
			XMLStreamReader xsr = xif.createXMLStreamReader(inputStream);
			
			Unmarshaller unmarsharller = jc.createUnmarshaller();

			out = (MapperTestInput) unmarsharller.unmarshal(xsr);

			
		} catch (Exception e) {
			e.printStackTrace();
			throw new IOException(e);
		}

		return out;
	}

	public static String marshal(MapperInput mapperTestInput) throws IOException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		try {
			JAXBContext jc = JAXBContext.newInstance("klaf.das.tester.input.jaxb");
			Marshaller m = jc.createMarshaller();
			m.setProperty("jaxb.formatted.output", Boolean.TRUE);

			JAXBElement<?> e = new ObjectFactory().createMapperTestInput(mapperTestInput);

			m.marshal(e, outputStream);

			return outputStream.toString("UTF-8");
		} catch (JAXBException e) {
			e.printStackTrace();
			throw new IOException(e);
		}
	}
}