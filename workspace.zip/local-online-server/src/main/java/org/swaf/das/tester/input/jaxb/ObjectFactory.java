package org.swaf.das.tester.input.jaxb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory
{
  private static final QName _MapperTestInput_QNAME = new QName("", "mapperTestInput");

  public MapperField createMapperTestField()
  {
    return new MapperField();
  }

  public DataSourceField createDataSourceField()
  {
    return new DataSourceField();
  }

  public MapperInput createMapperTestInput()
  {
    return new MapperInput();
  }

  @XmlElementDecl(namespace="", name="mapperTestInput")
  public JAXBElement<MapperInput> createMapperTestInput(MapperInput value) {
	  return new JAXBElement<MapperInput>(_MapperTestInput_QNAME, MapperInput.class, null, value);
  }
  
}