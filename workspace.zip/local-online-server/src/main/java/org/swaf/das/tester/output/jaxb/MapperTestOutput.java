package org.swaf.das.tester.output.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="MapperTestOutput", propOrder={"results"})
public class MapperTestOutput
{
  protected List<MapperTestResult> results;

  public List<MapperTestResult> getResults()
  {
    if (this.results == null) {
      this.results = new ArrayList();
    }
    return this.results;
  }
}