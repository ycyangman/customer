package org.swaf.das.tester.output.jaxb;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MapperTestOutputConverter
{
  static final String JAXB_LOCATION = "klaf.das.tester.output.jaxb";

  static Logger log()
  {
    return LoggerFactory.getLogger(MapperTestOutputConverter.class);
  }

  public static MapperTestOutput unmarshal(InputStream inputStream)
    throws IOException
  {
    MapperTestOutput out = null;
    try
    {
      JAXBContext jc = JAXBContext.newInstance("klaf.das.tester.output.jaxb");
      Unmarshaller u = jc.createUnmarshaller();

      JAXBElement e = (JAXBElement)u.unmarshal(inputStream);

      out = (MapperTestOutput)e.getValue();
    }
    catch (Exception e) {
      e.printStackTrace();
      throw new IOException(e);
    }

    return out;
  }

  public static String marshal(MapperTestOutput mapperTestOutput)
    throws IOException
  {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    try
    {
      JAXBContext jc = JAXBContext.newInstance("klaf.das.tester.output.jaxb");
      Marshaller m = jc.createMarshaller();
      m.setProperty("jaxb.formatted.output", Boolean.TRUE);

      JAXBElement e = new ObjectFactory().createMapperTestOutput(mapperTestOutput);

      m.marshal(e, outputStream);

      return outputStream.toString("UTF-8");
    }
    catch (JAXBException e) {
      e.printStackTrace();
      throw new IOException(e);
    }
  }
}