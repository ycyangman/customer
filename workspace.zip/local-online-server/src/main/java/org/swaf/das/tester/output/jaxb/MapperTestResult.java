package org.swaf.das.tester.output.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="MapperTestResult", propOrder={})
public class MapperTestResult
{

  @XmlElement(required=true)
  protected int seq;
  private String variable;
  protected String column;
  protected String javaClass;
  protected String dbType;
  protected int precision;
  protected int scale;
  protected boolean used;
  protected boolean dup;
  protected String emsg;
  protected String value;

  public int getSeq()
  {
    return this.seq;
  }

  public void setSeq(int value)
  {
    this.seq = value;
  }

  public String getColumn()
  {
    return this.column;
  }

  public void setColumn(String value)
  {
    this.column = value;
  }

  public String getJavaClass()
  {
    return this.javaClass;
  }

  public void setJavaClass(String value)
  {
    this.javaClass = value;
  }

  public String getDBType()
  {
    return this.dbType;
  }

  public void setDBType(String value)
  {
    this.dbType = value;
  }

  public int getPrecision()
  {
    return this.precision;
  }

  public void setPrecision(int value)
  {
    this.precision = value;
  }

  public int getScale()
  {
    return this.scale;
  }

  public void setScale(int value)
  {
    this.scale = value;
  }

  public String getValue()
  {
    return this.value;
  }

  public void setValue(String value)
  {
    this.value = value;
  }

  public String getVariable()
  {
    return this.variable;
  }

  public void setVariable(String variable)
  {
    this.variable = variable;
  }

  public String getEmsg()
  {
    return this.emsg;
  }

  public void setEmsg(String emsg)
  {
    this.emsg = emsg;
  }

  public boolean isUsed()
  {
    return this.used;
  }

  public void setUsed(boolean used)
  {
    this.used = used;
  }

  public boolean isDup()
  {
    return this.dup;
  }

  public void setDup(boolean dup)
  {
    this.dup = dup;
  }
}