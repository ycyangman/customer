package org.swaf.das.tester.output.jaxb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory
{
  private static final QName _MapperTestOutput_QNAME = new QName("", "mapperTestOutput");

  public MapperTestResult createMapperTestResult()
  {
    return new MapperTestResult();
  }

  public MapperTestOutput createMapperTestOutput()
  {
    return new MapperTestOutput();
  }

  @XmlElementDecl(namespace="", name="mapperTestOutput")
  public JAXBElement<MapperTestOutput> createMapperTestOutput(MapperTestOutput value)
  {
    return new JAXBElement(_MapperTestOutput_QNAME, MapperTestOutput.class, null, value);
  }
}