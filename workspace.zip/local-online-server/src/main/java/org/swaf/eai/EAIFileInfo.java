package org.swaf.eai;

import lombok.Data;

@Data
public class EAIFileInfo {

	String localFilePath;
	
	String remoteFilePath;
	
	String shellPath;
	
	String shellParam;
	
	
}
