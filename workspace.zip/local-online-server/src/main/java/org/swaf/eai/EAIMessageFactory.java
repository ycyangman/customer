package org.swaf.eai;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EAIMessageFactory {

	static ObjectMapper mapper = null;
	
	static {
		
		mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}
	
	public static <T> byte[] toBytes(EAIStandardMessage<T> message) {
		byte[] result = null;
		
		try {
			result = mapper.writeValueAsBytes(message);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;
		
	}
	
	public static <T> EAIStandardMessage<T> parse(byte[] bMessage, Class<T> clazz) {
		EAIStandardMessage<T> message = null;
		
		try {
			JavaType  messageType = mapper.getTypeFactory().constructParametricType(EAIStandardMessage.class, clazz);
			message = mapper.readValue(bMessage, messageType);
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		
		return message;
		
	}
}
