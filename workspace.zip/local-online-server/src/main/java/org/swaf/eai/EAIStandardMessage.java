package org.swaf.eai;

import lombok.Getter;
import lombok.Setter;

public class EAIStandardMessage<T> {
	
	@Getter @Setter
	EAIHeader header;
	
	@Getter @Setter
	T user;
	
}
