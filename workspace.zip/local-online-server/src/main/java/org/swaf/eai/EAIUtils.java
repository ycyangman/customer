package org.swaf.eai;

import java.util.ArrayList;
import java.util.List;

import org.swaf.foundation.context.InterfaceResult;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.util.ContextUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EAIUtils {

	
	public static final String SYNC = "S";
	public static final String ASYNC = "A";
	
	//TODO
/*	
	public static <T> EAIStandardMessage<T> callServcie(EAIStandardMessage<T> message, Class<T> type) {
		return callService(message, type, 0);
	}
	
	public static <T> EAIStandardMessage<T> callService(EAIStandardMessage<T> message, Class<T> type, int timeout) {
	
		Eai eai = new Eai();
		
		byte[] txBytes = EAIMessageFactory.toBytes(message);
		if(txBytes == null) {
			throw new SysException("SYSE2001", new String[] {new String(txBytes)});
			
		}
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		InterfaceResult eaiResult = new InterfaceResult();
		eaiResult.setId(message.getHeader().getInterfaceId());
		eaiResult.setTypCd("E");
		eaiResult.setKndCd(message.getHeader().getCallTyp());
		eaiResult.setRsCd("Q");
		//.....
		
		List<InterfaceResult> interfaceResults = null;
		
		if(ctx.getInterfaces() == null) {
			interfaceResults = new ArrayList<>();
			ctx.setInterfaces(interfaceResults);
		}
		else {
			interfaceResults = ctx.getInterfaces();
		}
		
		interfaceResults.add(eaiResult);
		
		//ticod
		EAIMessage resp = null;
		
		try {
			if(message.getHeader().getCallTyp().equals(SYNC)) {
				if(timeout > 0 ) {
					resp = eai.sync(txBytes, timeout);
				}
				else {
					resp = eai.sync(txBytes);
				}
				
				eaiResult.setResTm();
				eaiResult.setRsCd("0".equals(resp.getCode()) ? "R" : "F");
				eaiResult.setRsMsg(resp.getCode());
				
			}
			else {
				resp = eai.async(txBytes);
			}
		}
		catch(Exception e ) {
			e.printStackTrace();
			throw new SysException("SYSE2003", e);
		}
		
		EAIStandardMessage<T> eaiResponse = null;
		
		eaiResponse = EAIMessageFactory.parse(resp.getMsgByte(), type);
		if(eaiResponse == null) {
			log.error("EAI 응답전문 파싱실패");
			throw new SysException("SYSE2002", new String[] {new String(resp.getMsgByte())});
			
		}
		
		return eaiResponse;
	}
	
	public static EAIStandardMessage<EAIFileInfo> transFile(EAIStandardMessage<EAIFileInfo> message) {
		
		EaiFile eaiFile = new EaiFile();
		
		boolean includeShell = message.getUser().getShellPath() != null ? true : false;
		
		EAIMessage resp = null;
		
		try {
			if(message.getHeader().getCallTyp().equals(ASYNC)) {
				if(includeShell ) {
					resp = eai.fileAsnc(txBytes, timeout);
				}
				else {
					resp = eai.fileAsnc(txBytes);
				}
				
			}
			else {
				if(includeShell ) {
					resp = eai.fileSync(txBytes, timeout);
				}
				else {
					resp = eai.fileSync(txBytes);
				}
			}
		}
		catch(Exception e ) {
			e.printStackTrace();
			throw new SysException("SYSE2003", e);
		}
		
		EAIStandardMessage<EAIFileInfo> eaiResponse = EAIMessageFactory.parse(resp.getMsgByte(), EAIFileInfo.class);
		
		return eaiResponse;
	}

	*/
	
}
