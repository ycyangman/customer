package org.swaf.foundation.annotation;

import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Retention;


@Retention(RUNTIME)
public @interface DataAccess {


	public abstract String datasource();
	
	public abstract String mapper();
	
		
}

