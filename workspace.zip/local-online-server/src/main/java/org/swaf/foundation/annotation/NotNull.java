package org.swaf.foundation.annotation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Retention(RUNTIME)
@Target(FIELD)
/**
 *  DTO 또는 VO 멤버변수의 값을 Validate 할 때, 값이 null 인지 체크한다.   
 * @author yonghan.lee
 *
 */
public @interface NotNull {

}
