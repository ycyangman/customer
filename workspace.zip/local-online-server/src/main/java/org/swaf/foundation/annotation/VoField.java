package org.swaf.foundation.annotation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;


@Retention(RUNTIME)
@Target(FIELD)

public @interface VoField {

	/**
	 * 
	 * @return 필드길이
	 */
	int length() default 0;
	
	
	String formatType() default "";
	
	/**
	 * 
	 * @return 지정한 논리명의 문자열
	 */
	String description() default "";
	
	String align() default "left";
	
	String arrayReference() default "";
	
	String operator() default "";
	
}

