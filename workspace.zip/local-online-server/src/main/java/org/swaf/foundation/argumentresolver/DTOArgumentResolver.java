package org.swaf.foundation.argumentresolver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.swaf.foundation.annotation.RequestDTO;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.util.ContextUtils;

@Component
public class DTOArgumentResolver implements HandlerMethodArgumentResolver {

	@Autowired
	ObjectMapper mapper;
	
	@Override
	public boolean supportsParameter(MethodParameter parameter) {
		return parameter.hasParameterAnnotation(RequestDTO.class);
	}

	@Override
	public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
			NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		byte[] in = ctx.getInput();		
		return mapper.readValue(in, parameter.getParameter().getType());

	}

}
