package org.swaf.foundation.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.exception.InvalidInputException;
import org.swaf.foundation.util.APSStringUtils;
import org.swaf.foundation.util.ContextUtils;

@Slf4j
@Aspect
@Component
public class ValidateInputAspect {
	
	private static final String DTO_CLASS_NAME 
		= "org.swaf.foundation.dto.DefaultDTO";
	
	@Pointcut("@annotation(org.swaf.foundation.annotation.ValidateInput)")
	public void inputTobeValidated() {}
	
	/**
	 * ValidateInput Annotation 이 붙은 서비스의 Input 데이터를 
	 * 자동으로 Validation 한다.
	 *  
	 * @param jp
	 */
	@Before("inputTobeValidated()")
	public void validateInput (JoinPoint jp) {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		if (log.isDebugEnabled()) {
			log.debug("::: validate input ::: {}, {}", ctx.getCallUrl(), ctx.getGuid());
		}
		
		Object[] args = jp.getArgs();
		if (args != null && args.length > 0) {
			for (Object arg : args) {
				
				if (ValidateInputAspect.DTO_CLASS_NAME.equals(arg.getClass().getSuperclass().getTypeName())) {
					
					if (log.isDebugEnabled()) {
						log.debug("input validation required :: {}", arg.getClass().getName());
					}
					
					DefaultDTO dto = (DefaultDTO)arg;
					
					if (!dto.validate(arg.getClass().asSubclass(DefaultDTO.class))) {
						ctx.setAdMsg(APSStringUtils.convertToJsonString(dto.getValidateErrors()));
						//입력데이터에 오류가 있습니다.
						throw new InvalidInputException("SYSE0019");
					}					
					
				}
				
			}
		}
	}

}
