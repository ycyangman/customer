package org.swaf.foundation.auth;

import java.sql.Timestamp;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.swaf.foundation.context.DefaultVO;

@Data
@EqualsAndHashCode(callSuper=false)
public class AuthToken extends DefaultVO {
	
	String tokenId;
	String usrId;
	String usrNm;
	String usrIpAd;
	Timestamp loginTs;
	
	long roles;
	
}
