package org.swaf.foundation.cache;

import java.time.Duration;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import org.swaf.foundation.property.PropertyManager;

@Slf4j
public class CacheClient<T> {

	@Autowired
	ObjectMapper mapper;
	
	RedisTemplate<String, Object> template;
	
	@Autowired
	PropertyManager pm;
	
	public CacheClient (RedisTemplate<String, Object> template) {
		this.template = template;
	}
	
	public void put (String key, Object val) {
		
		long baseTtl = pm.getProperty("cache.ttl", Long.class);
		put (key, val, baseTtl);
		
	}
	
	public void setExpire (String key, Date date) {
		template.expireAt(key, date);
	}

	public void setExpire (String key, long ttlSeconds) {
		template.expire(key, ttlSeconds, TimeUnit.SECONDS);
	}

	public void put (String key, Object val, long ttl) {
		
		long baseTtl = ttl;
		String strVal = null;
		
		try {
			
			strVal = mapper.writeValueAsString(val);
			template.opsForValue().set(key, strVal, Duration.ofSeconds(baseTtl));
		
		} catch (Exception e) {
			if (log.isWarnEnabled()) {
				log.warn("fail to set cache {}::{}", key, strVal, e);
			}
		}
		
	}
	
	public Boolean delete (String key) {
		return template.delete(key);
	}
	
	public void putHashData (String hash, String key, Object val) {
		
		String strVal = null;
		
		try {
			
			strVal = mapper.writeValueAsString(val);
			template.opsForHash().put(hash, key, strVal);
		
		} catch (Exception e) {
			if (log.isWarnEnabled()) {
				log.warn("fail to set cache {}.{}::{}", hash, key, strVal, e);
			}
		}
		
	}
	
	public Set<String> getKeys (String keyPattern) {
		return template.keys(keyPattern);
	}
	

	public T get (String key, Class<T> type) {
		
		T obj = null;

		try {
			String val = (String)template.opsForValue().get(key);
			
			if (val != null) {
				obj = mapper.readValue(val, type);
			}
			
		} catch (Exception e) {
			if (log.isWarnEnabled()) {
				log.warn("fail to get cache data of  {}", key, e);
			}
		}

		return obj;
		
	}

	public T getHashData (String hash, String key, Class<T> type) {
		
		T obj = null;

		try {
			String val = (String)template.opsForHash().get(hash, key);
		
			if (val != null) {
				obj = mapper.readValue(val, type);
			}
			
		} catch (Exception e) {
			if (log.isWarnEnabled()) {
				log.warn("fail to get cache data of  {}.{}", hash, key, e);
			}
		}

		return obj;
		
	}
	
	public void deleteHashData (String hash, String key) {
		
		try {
			template.opsForHash().delete(hash, new Object[] {key});
		} catch (Exception e) {
			if (log.isWarnEnabled()) {
				log.warn("fail to delete cache data of  {}.{}", hash, key, e);
			}
		}
		
	}


	
	public long getExpireInSeconds (String key) {
		return template.getExpire(key);
	}

	public void destroy() {
		
		if(template != null) {
		
			RedisConnectionFactory redisConnectionFactory = template.getConnectionFactory();
			
			try {
				if(!redisConnectionFactory.getClusterConnection().isClosed()) {
			
					template.getConnectionFactory().getClusterConnection().close();
					
					if (log.isInfoEnabled()) {
						log.info("redis cluster connection has been closed");
					}
					
				}
				
			}
			catch(Exception e) {
				log.warn("Fail to close redis cluster connection", e);
				if(!redisConnectionFactory.getConnection().isClosed()) {
					
					template.getConnectionFactory().getConnection().close();
					
					if (log.isInfoEnabled()) {
						log.info("redis connection has been closed");
					}
					
				}
				
			}
			

		}
	}
	
}
