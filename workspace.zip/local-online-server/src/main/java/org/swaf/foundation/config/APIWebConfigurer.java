package org.swaf.foundation.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import lombok.extern.slf4j.Slf4j;
import org.swaf.foundation.argumentresolver.DTOArgumentResolver;
import org.swaf.foundation.interceptor.APIInterceptor;
import org.swaf.foundation.interceptor.DefaultAuthInterceptor;

//TODO
@Slf4j
//@Configuration
public class APIWebConfigurer implements WebMvcConfigurer  {

	@Autowired(required=true)
	APIInterceptor apiInterceptor;
	
	@Autowired(required=true)
	DefaultAuthInterceptor authInterceptor;
	
	@Autowired(required=true)
	DTOArgumentResolver dtoArgumentResolver;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		
		if (log.isDebugEnabled()) {
			log.debug("APIInterceptor 등록 완료");
		}
		
		registry.addInterceptor(apiInterceptor).addPathPatterns("/api/**/*");
		registry.addInterceptor(authInterceptor).addPathPatterns("/api/**/*");
	}

	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
		// TODO Auto-generated method stub
		WebMvcConfigurer.super.addArgumentResolvers(resolvers);
		resolvers.add(dtoArgumentResolver);
	}
	
	
	
	

}
