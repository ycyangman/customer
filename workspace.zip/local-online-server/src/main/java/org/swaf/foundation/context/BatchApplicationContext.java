package org.swaf.foundation.context;

import java.util.HashMap;

import lombok.Data;

@Data
public class BatchApplicationContext extends DefaultContext {

	String jobId;
	String jobNm;
	
	int jobKndNum;
	long jobInstId;
	
	long jobExecId;
	
	long targetCnt;
	
	long currentCnt;
	
	HashMap<String, String> jobParamers;
}
