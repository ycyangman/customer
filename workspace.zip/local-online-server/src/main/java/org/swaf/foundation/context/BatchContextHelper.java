package org.swaf.foundation.context;

import org.swaf.foundation.exception.BatchException;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.util.APSBeanUtils;

public class BatchContextHelper extends ContextHelper {


	public static void setBatchErrResult (BatchApplicationContext ctx, BatchException e) {
		ctx.setProcRscd(ProcRscd.BAT_ERROR.getVal());
		ctx.setMsgCd (e.getMsgId());
		ctx.setBascMsg(e.getMessage());
	
		setResult(ctx);
	}
	
	public static void setBatchUnknownResult (BatchApplicationContext ctx) {
		
		MessageManager mm = APSBeanUtils.getBean(MessageManager.class);
		
		ctx.setProcRscd(ProcRscd.BAT_UNKNOWN.getVal());
		ctx.setMsgCd ("SYSI0008"); //배치작없의 실행상태 확인 불가
		ctx.setBascMsg(mm.getMessage("SYSI0008"));

		setResult(ctx);
	}
	
	public static void setBatchStoppedResult (BatchApplicationContext ctx) {
		
		MessageManager mm = APSBeanUtils.getBean(MessageManager.class);
		
		ctx.setProcRscd(ProcRscd.BAT_STOPPED.getVal());
		ctx.setMsgCd ("SYSI0007"); //배치작업 강제 중지되었습니다.
		ctx.setBascMsg(mm.getMessage("SYSI0007"));

		setResult(ctx);
	}
}
