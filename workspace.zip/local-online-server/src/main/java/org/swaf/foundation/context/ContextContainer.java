package org.swaf.foundation.context;

/**
 * @author yonghan.lee
 *
 */
public class ContextContainer {
	
	static final ThreadLocal<DefaultContext> ctx;
	
	static {
		ctx = new ThreadLocal<>();
	}

	public static void set (DefaultContext container) {
		ctx.set(container);
	}
	
	public static DefaultContext get () {
		return ctx.get();
	}
	
	public static void unset () {
		ctx.remove();
	}
	
}
