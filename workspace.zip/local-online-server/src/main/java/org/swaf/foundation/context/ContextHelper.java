package org.swaf.foundation.context;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.util.APSBeanUtils;

import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.exception.BizException;

@Slf4j
public class ContextHelper {

	public static void setSuccessResult (DefaultContext ctx) {
		
		MessageManager mm=(MessageManager)APSBeanUtils.getBean("messageManager");
		setResult (ctx) ;
		ctx.setProcRscd(ProcRscd.SUCCESS.getVal());
	
		if (StringUtils.isEmpty(ctx.getMsgCd())) {
			ctx.setMsgCd ("SYSI0001");
			ctx.setBascMsg(mm.getMessage ("SYSI0001"));
		}
	
	}
	
	public static void setSysErrResult (DefaultContext ctx, SysException e) {

		ctx.setProcRscd(ProcRscd.SYSEXECPTION.getVal());
		ctx.setMsgCd  (e. getMsgId());
		ctx.setBascMsg(e.getMessage());
		
		setErrResult (ctx, e);
		setResult (ctx);
	}
	
	public static void setBizErrResult (DefaultContext ctx, BizException e) {
		ctx.setProcRscd(ProcRscd.BIZEXCEPTION.getVal());
		ctx.setMsgCd  (e. getMsgId());
		ctx.setBascMsg(e.getMessage());
		
		setErrResult (ctx, e);
		setResult (ctx);
	}

	public static void setGeneralErrResult (DefaultContext ctx, Exception e) {
		MessageManager mm=(MessageManager)APSBeanUtils.getBean("messageManager");
		ctx.setProcRscd(ProcRscd.SYSEXECPTION.getVal());
		ctx.setMsgCd ("SYSE0001");
		ctx.setBascMsg(mm.getMessage ("SYSE0001"));
		setErrResult (ctx, e);
		setResult (ctx);
	}
	
	
	public static void setResult (DefaultContext ctx) {


		SimpleDateFormat utcHHMMSS = new SimpleDateFormat("HHmmss");
		utcHHMMSS.setTimeZone(TimeZone.getTimeZone("GMT"));
		
		SimpleDateFormat locHHMMSS = new SimpleDateFormat("HHmmss");
		locHHMMSS.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		
		Date current = new Date();
		
		ctx.setTxEndTm(locHHMMSS.format(current));
		ctx.setUtcEndTm(utcHHMMSS.format(current));
		
		ctx.setProcEndTs(current.getTime());
		ctx.setProcPd((int)(current.getTime()-ctx.getProcBgnTs()));
	}
	
	public static void setErrResult (DefaultContext ctx, Throwable t) {
		 
		ArrayList<ExceptionInfo> exList = assembleExceptionInfo(null, t);
		if(exList != null) {
			ctx.setExTraces(exList.toArray(new ExceptionInfo[exList.size()]));
			
			ObjectMapper mapper = APSBeanUtils.getBean(ObjectMapper.class);
			
			try {
				ctx.setAdMsg(mapper.writeValueAsString(ctx.getExTraces()));				
			}
			catch(Exception e) {
				log.warn(e.getMessage(), e);
			}
			
		}
	}
	
	protected static ArrayList<ExceptionInfo> assembleExceptionInfo(ArrayList<ExceptionInfo> exList,Throwable t) {
		ArrayList<ExceptionInfo> tmpExList = exList;
		
		if(t == null) {
			return exList;
		}
		
		if(exList == null) {
			tmpExList =  new ArrayList<>();
		}
		
		tmpExList.add(extractInfo(t, tmpExList.size()));
		if (t.getCause() != null) {
			tmpExList.add(extractInfo (t.getCause(), tmpExList.size()));
		}
		
		while(tmpExList.size() > 10 ) {
			tmpExList.remove(tmpExList.size() -2);
		}

		return tmpExList;
	}
	
	protected static ExceptionInfo extractInfo(Throwable t, int sq) {
		if(t == null) {
			return null;
		}
		
		ExceptionInfo exInfo = new ExceptionInfo();
		exInfo.setThrowableNm(t.getClass().getTypeName());
		
		if(t instanceof SysException) {
			exInfo.setExMsg(StringUtils.mid(t.getMessage(), 0, 50));
		}
		if(t instanceof BizException) {
			exInfo.setExMsg(StringUtils.mid(t.getMessage(), 0, 50));
		}
		exInfo.setSq(sq);
		StackTraceElement[] ste = t.getStackTrace();
		if(ste != null && ste.length>0) {
			exInfo.setExOccrClass(ste[0].getClassName());
			exInfo.setExOccrLnNum(ste[0].getLineNumber());
			exInfo.setExOccrMeth(ste[0].getMethodName());
		}
		
		return exInfo;
	}
	
	
}
