package org.swaf.foundation.context;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.concurrent.locks.ReentrantLock;


import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DASMapper {

	HashMap<String, Method> map = new HashMap<>();
	
	ReentrantLock lock = new ReentrantLock();
	
	public Method getMethod(String key) {
		watingUnlock();
		return map.get(key);
	}
	
	public void putMethod(String key, Method method) {
		watingUnlock();
		map.put(key, method);
	}
	
	public void clear() {
		lock.lock();
		try {
			map.clear();
		}
		finally {
			map.clear();
		}
	}
	
	private void watingUnlock() {
		while(lock.isLocked()) {
			try {
				Thread.sleep(5);
			}
			catch(InterruptedException e) {
				log.warn("fail to sleep thread");
			}
		}
	}
}
