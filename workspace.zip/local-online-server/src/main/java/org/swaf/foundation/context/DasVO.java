package org.swaf.foundation.context;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.commons.lang3.ClassUtils;
import org.apache.ibatis.type.Alias;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.util.StringUtils;
import org.swaf.foundation.property.CachedPropertyManager;
import org.swaf.foundation.util.APSBeanUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Alias("dasVo")
public class DasVO<T> extends HashMap<String, Object> {

	private static final long serialVersionUID = 5757575757571L;

	private DASMapper getterMapper;
	
	private DASMapper setterMapper;
	
	
	boolean convertCamelCase = true;
	boolean outputColumnUppercase = false;

	
	public DasVO() {
		super();
		
		CachedPropertyManager pm = APSBeanUtils.getBean(CachedPropertyManager.class);
		String alias = pm.getProperty("appdb.primary");
		
		this.getterMapper = (DASMapper)APSBeanUtils.getBean("getterMapper");
		this.setterMapper = (DASMapper)APSBeanUtils.getBean("setterMapper");
		
		if(pm.getProperty(alias+".map.use.camelcase").toLowerCase().equals("false")) {
			this.convertCamelCase = false;
		}
		if(pm.getProperty(alias+".map.output.column.uppercase").toLowerCase().equals("true")) {
			this.outputColumnUppercase = true;
		}
	}
	
	
	public DasVO(String alias) {
		super();
		
		CachedPropertyManager pm = APSBeanUtils.getBean(CachedPropertyManager.class);
		this.getterMapper = (DASMapper)APSBeanUtils.getBean("getterMapper");
		this.setterMapper = (DASMapper)APSBeanUtils.getBean("setterMapper");
		
		if(pm.getProperty(alias+".map.use.camelcase").toLowerCase().equals("false")) {
			this.convertCamelCase = false;
		}
		if(pm.getProperty(alias+".map.output.column.uppercase").toLowerCase().equals("true")) {
			this.outputColumnUppercase = true;
		}
	}
	
	public Object put(String key, String value) {
		
		if(convertCamelCase && key.matches("[a-z]+[_][a-z]+.*")) {
			return super.put(JdbcUtils.convertUnderscoreNameToPropertyName(key), value);
		}
		else {
			return super.put(key, value);
		}
	}
	
	public T putParam(T obj, Class<T> type) {
		
		Field[] fields = type.getDeclaredFields();
		Field[] serperFields = DefaultVO.class.getDeclaredFields();
		
		for(Field field : fields) {
			try {
				this.put(field.getName(), getGetterMethod(type, field).invoke(obj));
			}
			catch(Exception e) {
				log.debug("fail to set parameter  :: {}",field.getName(), e);
			}
		}
		
		for(Field field : serperFields) {
			try {
				this.put(field.getName(), getGetterMethod(type, field).invoke(obj));
			}
			catch(Exception e) {
				log.warn("fail to set parameter  :: {}",field.getName(), e.getMessage());
			}
		}
		
		return obj;
	}
	
	public T getReuslt(Class<T> type) {
		
		T obj = null;
		
		try {
			obj = type.getDeclaredConstructor().newInstance();
		}
		catch(Exception e) {
			log.debug("could not create instance of class  :: {}",type.getName(), e);
			
			return null;
		}
		
			
		Field[] fields = type.getDeclaredFields();
		Field[] serperFields = DefaultVO.class.getDeclaredFields();
		
		for(Field field : fields) {
			try {
				
				boolean primitive = ClassUtils.isPrimitiveOrWrapper(field.getType());
				String fieldName = null;
				
				if(outputColumnUppercase) {
					fieldName = field.getName().toUpperCase();
				}
				else {
					fieldName = field.getName();
				}
				
				Method setter = getSetterMethod(type, field);
				
				if(primitive) {
					if(field.getType() == java.lang.Long.TYPE) {
						setter.invoke(obj, getLong(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Integer.TYPE) {
						setter.invoke(obj, getInt(this.get(fieldName)));
					}					
					if(field.getType() == java.lang.Double.TYPE) {
						setter.invoke(obj, getDouble(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Boolean.TYPE) {
						setter.invoke(obj, getBoolean(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Character.TYPE) {
						setter.invoke(obj, getChar(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Short.TYPE) {
						setter.invoke(obj, getShort(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Byte.TYPE) {
						setter.invoke(obj, getByte(this.get(fieldName)));
					}
					/*
					if(field.getType() == java.lang.Float.TYPE) {
						setter.invoke(obj, getFloat(this.get(fieldName)));
					}
					*/
				}
				else {
					setter.invoke(obj, this.get(fieldName));
				}
			}
			catch(Exception e) {
				log.debug("fail to set return value of field  :: {}",field.getName(), e);
			}
		}
		
		for(Field field : serperFields) {
			try {
				
				boolean primitive = ClassUtils.isPrimitiveOrWrapper(field.getType());
				String fieldName = null;
				
				if(outputColumnUppercase) {
					fieldName = field.getName().toUpperCase();
				}
				else {
					fieldName = field.getName();
				}
				
				Method setter = getSetterMethod(type, field);
				
				if(primitive) {
					if(field.getType() == java.lang.Long.TYPE) {
						setter.invoke(obj, getLong(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Integer.TYPE) {
						setter.invoke(obj, getInt(this.get(fieldName)));
					}					
					if(field.getType() == java.lang.Double.TYPE) {
						setter.invoke(obj, getDouble(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Boolean.TYPE) {
						setter.invoke(obj, getBoolean(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Character.TYPE) {
						setter.invoke(obj, getChar(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Short.TYPE) {
						setter.invoke(obj, getShort(this.get(fieldName)));
					}
					if(field.getType() == java.lang.Byte.TYPE) {
						setter.invoke(obj, getByte(this.get(fieldName)));
					}
					/*
					if(field.getType() == java.lang.Float.TYPE) {
						setter.invoke(obj, getFloat(this.get(fieldName)));
					}
					*/
				}
				else {
					setter.invoke(obj, this.get(fieldName));
				}
			}
			catch(Exception e) {
				//log.debug("fail to set return value of field  :: {}",field.getName(), e);
			}
		}
		
		return obj;
	}
	
	public void setPagingParam(int pgSq, int pgSz) {
		put("_offset", pgSq*pgSz);
		put("_pgSz", pgSz);
	}
	
	public void setDBAlias(String dbAlias) {
		
		CachedPropertyManager pm = APSBeanUtils.getBean(CachedPropertyManager.class);
		
		if(pm.getProperty(dbAlias+".map.use.camelcase").toLowerCase().equals("false")) {
			this.convertCamelCase = false;
		}
		if(pm.getProperty(dbAlias+".map.output.column.uppercase").toLowerCase().equals("true")) {
			this.outputColumnUppercase = true;
		}
	}
	
	
	private Method getGetterMethod(Class<?> type, Field field) {
		
		String key = String.format("%s.%s", type.getTypeName(), field.getName());
		
		Method method = getterMapper.getMethod(key);
		
		if(method ==null) {
			try {
				method = type.getDeclaredMethod("get"+StringUtils.capitalize(field.getName()));
				getterMapper.putMethod(key, method);
			}
			catch(NoSuchMethodException e) {
				log.warn("fail to find getter method :: {}", key, e.getMessage());
			}
		}
		
		return method;
	}
	
	private Method getSetterMethod(Class<?> type, Field field) {
		
		String key = String.format("%s.%s", type.getTypeName(), field.getName());
		
		Method method = setterMapper.getMethod(key);
		
		if(method ==null) {
			try {
				method = type.getDeclaredMethod("set"+StringUtils.capitalize(field.getName()), field.getType());
				setterMapper.putMethod(key, method);
			}
			catch(NoSuchMethodException e) {
				log.warn("fail to find setter method :: {}", key, e);
			}
		}
		
		return method;
	}
	
	
	private boolean getBoolean(Object obj) {
		boolean result = false;
		
		if(obj instanceof Boolean) {
			result = (Boolean)obj;
		}
		else if(obj instanceof String) {
			result = (Boolean)obj;
		}
		else {
			log.warn("could not convert to boolean value from {}", obj.getClass().getTypeName());
		}
		
		return result;
	}
	
	private byte getByte(Object obj) {
		byte result = 0;
		
		if(obj instanceof Byte) {
			result = (Byte)obj;
		}
		else if(obj instanceof Integer) {
			result = ((Integer)obj).byteValue();
		}
		else {
			log.warn("could not convert to byte value from {}", obj.getClass().getTypeName());
		}
		
		return result;
	}
	
	private char getChar(Object obj) {
		char result = 0;
		
		if(obj instanceof Character) {
			result = (Character)obj;
		}
		else if(obj instanceof Integer) {
			result = (char)((Integer)obj).intValue();
		}
		else {
			log.warn("could not convert to char value from {}", obj.getClass().getTypeName());
		}
		
		return result;
	}
	
	private short getShort(Object obj) {
		short result = 0;
		
		if(obj instanceof Short) {
			result = (Short)obj;
		}
		else if(obj instanceof Integer) {
			result = ((Integer)obj).shortValue();
		}
		else {
			log.warn("could not convert to short value from {}", obj.getClass().getTypeName());
		}
		
		return result;
	}

	private long getLong(Object obj) {
		long result = 0L;
		
		if(obj instanceof Long) {
			result = ((Long)obj).longValue();
		}
		else if(obj instanceof BigDecimal) {
			result = ((BigDecimal)obj).longValue();
		}
		else if(obj instanceof Integer) {
			result = ((Integer)obj).longValue();
		}
		else if(obj instanceof String) {
			result = Long.valueOf((String)obj);
		}
		else {
			log.warn("could not convert to long value from {}", obj.getClass().getTypeName());
		}
		
		return result;
	}
	
	private int getInt(Object obj) {
		int result = 0;
		
		if(obj instanceof Integer) {
			result = ((Integer)obj).intValue();
		}
		else if(obj instanceof BigDecimal) {
			result = ((BigDecimal)obj).intValue();
		}
		else if(obj instanceof Long) {
			result = ((Long)obj).intValue();
		}
		else if(obj instanceof String) {
			result = Integer.valueOf((String)obj);
		}
		else {
			log.warn("could not convert to int value from {}", obj.getClass().getTypeName());
		}
		
		return result;
	}
	
	private double getDouble(Object obj) {
		double result = 0;
		
		if(obj instanceof Double) {
			result = ((Double)obj);
		}
		else if(obj instanceof BigDecimal) {
			result = ((BigDecimal)obj).doubleValue();
		}
		else if(obj instanceof Long) {
			result = ((Long)obj) * 1.0;
		}
		else if(obj instanceof String) {
			result = Integer.valueOf((String)obj);
		}
		else {
			log.warn("could not convert to double value from {}", obj.getClass().getTypeName());
		}
		
		return result;
	}
}
