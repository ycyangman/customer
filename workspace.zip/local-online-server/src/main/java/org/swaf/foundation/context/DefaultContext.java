package org.swaf.foundation.context;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author yonghan.lee
 *
 */

@Data
@EqualsAndHashCode(callSuper=false)
public abstract class DefaultContext extends DefaultVO {
	
	//Global UID
	String guid;
	
	//사용자번호
	String usrId;
	
	//사용자이름
	String usrNm;
	
	//시스템환경구분코드
	String sysEnvDscd;

	//호출시스템아이디
	String callSysId;
	
	//처리시스템아이디
	String procSysId;
	
	//처리호스트명;
	String procHostNm;
	
	//처리인스턴스아이디;
	String procInstId;
	
	//업무레벨1
	String bizLv1;
	
	//업무레벨2
	String bizLv2;
	
	//업무레벨3
	String bizLv3;
	
	//거래일자
	String txDt;

	//Timezone
	String tz;
	
	//UTC일자
	String utcDt;

	//거래시작시각
	String txBgnTm;
	
	//UTC시작시각
	String utcBgnTm;

	//거래종료시각
	String txEndTm;
	
	//UTC종료시각
	String utcEndTm;

	//처리시간
	long procPd;
	
	//처리시작시각
	long procBgnTs;
	
	//처리종료시각
	long procEndTs;

	//사용언어
	String usLang;
	
	//처리결과코드
	String procRscd;
	
	//메시지코드
	String msgCd;
	
	//기본메시지
	String bascMsg;
	
	//부가메시지
	String adMsg;
	
	//예외트레이스
	ExceptionInfo[] exTraces; 
	


}
