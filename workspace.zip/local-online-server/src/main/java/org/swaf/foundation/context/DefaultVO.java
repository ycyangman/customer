package org.swaf.foundation.context;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;

import org.swaf.foundation.util.ContextUtils;

/**
 * @author yonghan.lee
 *
 */
public class DefaultVO {
	
	String useYn;
	String regDt;
	String regTm;
	String modDt;
	String modTm;
	String modUsrId;
	Timestamp lstModTs;

	// VO 기본 파라메터의 값을 현재 기준으로 업데이트 한다. 
	private void updateBaseParameters () {
		
		DefaultContext ctx = ContextUtils.getContext();
		
		SimpleDateFormat HHmmss = new SimpleDateFormat("HHmmss");
		HHmmss.setTimeZone(TimeZone.getTimeZone("GMT"));
		Date now = new Date();
		
		this.useYn = "Y";

		if (ctx != null) {
			this.regDt = ctx.getUtcDt();
			this.modDt = ctx.getUtcDt();
			this.modUsrId = ctx.getUsrId();
		}
		this.regTm = HHmmss.format(now);
		this.modTm = HHmmss.format(now);
		this.lstModTs = new Timestamp(System.currentTimeMillis());

	}

	//key에 해당하는 필드 값을 리턴한다. 
	public Object get(String key) {
		
		Object val = null;
		
		try {
			
			Method method = this.getClass().getMethod("get"+StringUtils.capitalize(key));
			val = method.invoke(this);
			
		} catch (Exception e) {
			throw new RuntimeException ("fail to get the value for the key", e);
		} 

		return val;
		
	}
	
	//key에 해당하는 필드에 값을 세팅한다. 
	public void set (String key, Object val) {
		
		String methodName = "set" + StringUtils.capitalize(key);
		boolean set = false;
		
		Method[] methods = this.getClass().getMethods();
		
		try {
			
			for (Method m : methods) {
				if (m.getName().equals(methodName)) {
					m.invoke(this, val);
					set = true;
					break;
				}
			}
			
		} catch (Exception e) {
			throw new RuntimeException ("fail to set the value for the key", e);
		}
		
		if (!set) {
			throw new RuntimeException ("there is no setter method for the key");
		}
		
		
	}
	
	public DefaultVO () {
		updateBaseParameters ();
	}
	
	public void refresh () {
		updateBaseParameters ();
	}
	
	
}
