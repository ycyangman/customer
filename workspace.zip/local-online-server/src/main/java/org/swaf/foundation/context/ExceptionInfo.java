package org.swaf.foundation.context;

import lombok.Data;

/**
 * @author yonghan.lee
 *
 */

@Data
public class ExceptionInfo {
	
	//순번
	int sq;
	
	//예외명
	String throwableNm;
	
	//예외메시지
	String exMsg;
	
	//예외발생클래스
	String exOccrClass;
	
	//예외발생클래스
	String exOccrMeth;

	//예외발생라인수
	int exOccrLnNum;

}
