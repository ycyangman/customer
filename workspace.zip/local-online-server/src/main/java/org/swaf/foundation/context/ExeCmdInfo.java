package org.swaf.foundation.context;

import lombok.Data;

/**
 * @author yonghan.lee
 *
 */

@Data
public class ExeCmdInfo {
	//실행명령타입
	String exeCmdTypCd;
	//실행명령상세
	String exeCmdDtl;
}
