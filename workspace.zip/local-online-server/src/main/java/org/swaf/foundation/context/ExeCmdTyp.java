package org.swaf.foundation.context;

import lombok.Getter;

public enum ExeCmdTyp {

	REDIRECT("REDIRECT"), FORWARD("FORWARD"), POPUP("POPUP");
	
	@Getter final private String val;

	private ExeCmdTyp (String val) {
		this.val = val;
	}	
	
}
