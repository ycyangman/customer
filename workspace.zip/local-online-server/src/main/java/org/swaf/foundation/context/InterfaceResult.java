package org.swaf.foundation.context;

import lombok.Data;

@Data
public class InterfaceResult {

	String id;
	
	String typCd;
	
	String kndCd;
	
	String reqTm;
	
	String resTm;
	
	String rsCd;
	
	String rsMsg;
	
}
