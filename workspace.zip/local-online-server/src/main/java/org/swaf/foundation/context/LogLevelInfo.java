package org.swaf.foundation.context;

import lombok.Data;

@Data
public class LogLevelInfo {

	String svcId;
	String logLevel;
	String userNo;
	String ipAd;
}
