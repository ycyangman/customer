package org.swaf.foundation.context;

import java.util.ArrayList;
import java.util.List;

import org.springframework.transaction.TransactionStatus;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.swaf.foundation.dto.DefaultHeader;
import org.swaf.foundation.dto.DefaultDTO;

/**
 * @author yonghan.lee
 *
 */

@Data
@ToString (callSuper=true)
@EqualsAndHashCode(callSuper=false)
public class OnlineApplicationContext extends DefaultContext {
	
	//진행번호
	String prgNo;

	//처리일련번호
	String prcSqNo;
	
	//컨텍스트아이디
	String ctxId;
	
	//서비스ID
	String svcId;
	
	String svcNm;
	
	//호출URL
	String callUrl;
	
	//인증필요여부
	String authReqYn;
	
	//접근가능역할
	long accRoles;
	
	//화면번호
	String scrnNo;
	
	//인증토큰
	String authToken;
	
	//사용자부서코드
	String usrDeptCd;
	
	//사용자IP주소
	String usrIpAd;
	
	//사용자MAC주소
	String usrMacAd;
	
	//직원역할목록
	long roles;
	
	//다음실행명령정보
	ExeCmdInfo[] nxtExeCmdInfo;	
	
	//페이징쿼리를 위한 항목
	//요청순번
	int pgSq;
	//페이지사이즈
	int pgSz;
	//다음데이터존재여부 ('Y' or 'N')
	String pgHasNext;
	//현재 조회건 수
	int pgResultCount;
	//페이징쿼리 상관없는 전체 건 수
	int totalCount;

	DefaultHeader header;
	byte[] input;
	Object output;
	
	Object in;
	DefaultDTO out;
	
	ArrayList<TransactionStatus> userTxStatuses;

	int lnkSqNo;
	
	List<InterfaceResult> interfaces;

}
