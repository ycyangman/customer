package org.swaf.foundation.context;

import lombok.Getter;

/**
 * 처리결과
 * @author yonghan.lee
 *
 */
public enum ProcRscd {

	SUCCESS("0"), SYSEXECPTION("1"), BIZEXCEPTION("2"), BAT_ERROR("3"), BAT_UNKNOWN("4"), BAT_STOPPED("5"), BAT_EXECUTING("6");
	
	@Getter final private String val;

	private ProcRscd (String val) {
		this.val = val;
	}	
	
}
