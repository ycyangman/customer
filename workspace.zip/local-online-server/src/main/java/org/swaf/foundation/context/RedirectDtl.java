package org.swaf.foundation.context;

import lombok.Data;

/**
 * @author yonghan.lee
 */
@Data
public class RedirectDtl {
	String url;
	String params;	
}
