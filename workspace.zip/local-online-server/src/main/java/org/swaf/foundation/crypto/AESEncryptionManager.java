package org.swaf.foundation.crypto;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

import lombok.Cleanup;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * @author yonghan.lee
 *
 */
@Slf4j
public class AESEncryptionManager implements DataEncryptionManager {

	@Value("${key.dir}")
	@Setter
	String keyDir;
	HashMap<String, EncKey> encKeys;
	HashMap<String, Cipher> encCiphers;
	HashMap<String, Cipher> decCiphers;

	@Override
	public void init() {

		try {
			
			if (StringUtils.isEmpty(keyDir)) {
				keyDir = System.getProperty("key.dir");
			}
			
			/*
			if (StringUtils.isAllEmpty(keyDir)) {
				throw new Exception ("key.dir is empty !!");
			}
			*/
			
			File conf = null;
			String configDir = System.getProperty("config.dir");
			if(!StringUtils.isEmpty(configDir)) {
				conf = new File(configDir, "app.properties");
			}
			else {
				conf = new File(System.getProperty("batch.config.dir"), "batch.properties");
			}
			
			@Cleanup FileInputStream fis = new FileInputStream(conf);
			Properties p = new Properties();
			p.load(fis);
			
			String keyDir = p.getProperty("key.dir");
			if(keyDir.matches("\\$\\{.+\\}")) {
				String envParam = keyDir.replaceAll("\\$\\{\\s*+", "").replaceAll("\\s*\\}+", "");
				keyDir = System.getProperty(envParam);
			}
			this.keyDir = keyDir;
	
		} catch (Exception e) {
			throw new RuntimeException ("암복호화 모듈 초기화 실패", e);
		}
		
		if (log.isDebugEnabled()) {
			log.debug(":::::: keydir :::::: {} ", this.keyDir);
		}
		
		encKeys = new HashMap<>();
		encCiphers = new HashMap<>();
		decCiphers = new HashMap<>();

		File dir = new File(keyDir);
		File[] encFiles = dir.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith("_enckey");
			}
		});

		if (encFiles != null) {

			for (File f : encFiles) {
				String dataType = f.getName().split("\\_")[0];

				try {

					@Cleanup
					FileInputStream in = new FileInputStream(f);
					@Cleanup
					ObjectInputStream oin = new ObjectInputStream(in);

					EncKey key = (EncKey) oin.readObject();

					log.info("#######AESEncryptionManager encKey init {} / {}", dataType, key);
					
					encKeys.put(dataType, key);

				} catch (Exception e) {
					log.error("fail to load enc key files", e);
					throw new RuntimeException ("암호키 파일 로그 실패", e);
				}

			}
		}

	}

	@Override
	public void destroy() {
		
		
	}

	@Override
	public String decrypt(String cryptedText, String dataType) {

		Cipher cipher4Dec;
		
		if (dataType.equals(KeyType.PASSWORD.getVal())) {
			//비밀번호는 복호화 할 수 없습니다. 
			log.error ("비밀번호는 복호화 할 수 없습니다.");
			throw new RuntimeException ("Password could not be decrypted");
		}

		try {

			cipher4Dec = decCiphers.get(dataType);
			if (cipher4Dec == null) {
				cipher4Dec = Cipher.getInstance("AES/CBC/PKCS5Padding");
				
				
				cipher4Dec.init(Cipher.DECRYPT_MODE, new SecretKeySpec(encKeys.get(dataType).getKey(), "AES"),
						new IvParameterSpec(encKeys.get(dataType).getIv()));
				
				decCiphers.put(dataType, cipher4Dec);
			}

			return new String(cipher4Dec.doFinal(Base64.getDecoder().decode(cryptedText)), "UTF-8");
		} catch (Exception e) {
			log.warn("fail to decrypt text ({}){}", dataType, cryptedText, e);
			throw new RuntimeException("fail to decrypt text", e); 
		}
	}

	@Override
	public String encrypt(String plainText, String dataType) {

		Cipher cipher4Enc;

		try {
			
			if (KeyType.PASSWORD.getVal().equals(dataType)) {
				return getHashValue(plainText);
			}

			cipher4Enc = encCiphers.get(dataType);
			if (cipher4Enc == null) {
				cipher4Enc = Cipher.getInstance("AES/CBC/PKCS5Padding");
				cipher4Enc.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(encKeys.get(dataType).getKey(), "AES"),
						new IvParameterSpec(encKeys.get(dataType).getIv()));
				encCiphers.put(dataType, cipher4Enc);
			}

			return Base64.getEncoder().encodeToString(cipher4Enc.doFinal(plainText.getBytes("UTF-8")));
		} catch (Exception e) {
			log.warn("fail to encrypt text {}", plainText);
			throw new RuntimeException("fail to encrypt text", e);
		}
	}

	private String getHashValue (String plainText) throws NoSuchAlgorithmException, UnsupportedEncodingException {

		if (StringUtils.isEmpty(plainText)) {
			return plainText;
		}

		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hashed = digest.digest(plainText.getBytes("UTF-8"));

		return new String(Base64.getEncoder().encode(hashed), "UTF-8");

	}

	@Override
	public void generateKey(String seedText, String dataType) {

		byte[] key256 = new byte[32];
		byte[] iv128 = new byte[16];
		byte[] salt128 = new byte[16];

		try {

			MessageDigest md = MessageDigest.getInstance("SHA-256");

			// generate a salt value
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
			String random = sdf.format(new Date(System.currentTimeMillis()));
			md.update(random.getBytes("UTF-8"));
			System.arraycopy(md.digest(), 0, salt128, 0, 16);

			// generate an IV value
			md.update(seedText.getBytes("UTF-8"));
			System.arraycopy(md.digest(), 0, iv128, 0, 16);

			// generate a new key
			byte[] bUserKey = seedText.getBytes("UTF-8");
			byte[] salted = new byte[bUserKey.length + 16];
			System.arraycopy(bUserKey, 0, salted, 0, bUserKey.length);
			System.arraycopy(salt128, 0, salted, bUserKey.length, 16);
			md.update(salted);
			System.arraycopy(md.digest(), 0, key256, 0, 32);

			EncKey encKey = new EncKey(key256, iv128, salt128);

			save(dataType, encKey);

			addKey(dataType, encKey);

		} catch (Exception e) {
			log.error("fail to generate enc key for {}", dataType);
			throw new RuntimeException ("fail to generate enc key", e);		
		}

	}

	private void save(String dataType, EncKey key) throws IOException {

		@Cleanup
		FileOutputStream out = new FileOutputStream(new File(keyDir, dataType + "_enckey"));
		@Cleanup
		ObjectOutputStream oout = new ObjectOutputStream(out);

		oout.writeObject(key);
		oout.flush();

	}

	private void addKey(String dataType, EncKey key) {
		encKeys.put(dataType, key);
	}

}
