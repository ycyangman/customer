package org.swaf.foundation.crypto;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import lombok.Cleanup;

public class CryptoCtl {

	
	String keyDir = null;
	
	AESEncryptionManager encManager = null;
	
	public static void main(String[] args) throws Exception {
		
		CryptoCtl ctl = new CryptoCtl();
		
		if(args.length != 2) {
			System.out.println("명령어 확인 요망");
			
			ctl.printUsage();
		}
		
		if(!ctl.chekKeyType(args[0])) {
		
			System.out.println("생성할 keytype 종류 확인");
			
			return;
			
		}
		
		ctl.encrypt(args[0], args[1]);
		
		
	}
	
	private boolean chekKeyType (String strKeyType) {
		boolean result = false;
		
		if(strKeyType != null) {
			KeyType keyType = null;
			
			try {
				keyType = KeyType.valueOf(strKeyType);
				
			}
			catch(IllegalArgumentException e) {
				e.printStackTrace();
			}
			if (keyType != null) {
				result = true;
			}
		}
		
		return result;
	}
	
	private void printUsage() {
	
		System.out.println("usage ::::");
		System.out.println("java -Dconfig.dir org.swaf.foundation.crypto.CryptoCtl key종류 암호할 평문");
		
	
	}
	
	private void encrypt(String strKeyType, String plainText) throws Exception {
	
		init();
	
		encManager = new AESEncryptionManager();
		encManager.setKeyDir(keyDir);
		encManager.init();
		
		System.out.println(String.format("암호화 키종류 : [%s], 평문 :[%s], 암호문 :[%s]",
				strKeyType
				, plainText
				, encManager.encrypt(plainText, strKeyType)));
		
	}
	
	
	private void init() {

		try {
			
			File conf = null;
			
			String configDir = System.getProperty("config.dir");
			
			if(StringUtils.isEmpty(configDir)) {
				configDir = "D:/eclipse/workspace/local-online-server/config";
				System.setProperty("config.dir", configDir );
			}
			if(!StringUtils.isEmpty(configDir)) {
				conf = new File(configDir, "app.properties");
			}
			
			@Cleanup FileInputStream fis = new FileInputStream(conf);
			Properties p = new Properties();
			p.load(fis);
			
			String keyDir = p.getProperty("key.dir");
			if(keyDir.matches("\\$\\{.+\\}")) {
				String envParam = keyDir.replaceAll("\\$\\{\\s*+", "").replaceAll("\\s*\\}+", "");
				keyDir = System.getProperty(envParam);
			}
			this.keyDir = keyDir;
	
		} catch (Exception e) {
			throw new RuntimeException ("암복호화 모듈 초기화 실패", e);
		}
		
		

	}

}
