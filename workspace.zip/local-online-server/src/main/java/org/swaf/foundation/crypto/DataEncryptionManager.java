package org.swaf.foundation.crypto;

/**
 * @author yonghan.lee
 *
 */
public interface DataEncryptionManager {
	
	public void init();
	public void destroy();
	public String decrypt (String cryptedText, String dataType);
	public String encrypt (String plainText, String dataType);
	public void generateKey (String seedText, String dataType);

}
