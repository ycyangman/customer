package org.swaf.foundation.crypto;

import java.io.Serializable;

import javax.crypto.Cipher;

import lombok.Data;
import lombok.NonNull;

/**
 * @author yonghan.lee
 *
 */

@Data
public class EncKey implements Serializable {

	  private static final long serialVersionUID = 8246350082857294584L;
	  
	  @NonNull byte[] key = null;
	  @NonNull byte[] iv = null;
	  @NonNull byte[] salt = null;
	  
  	  Cipher cipher4Enc;
	  Cipher cipher4Dec;

	  public EncKey (byte[] key, byte[] iv, byte[] salt) {
		  this.key = key;
		  this.iv = iv;
		  this.salt = salt;
	  }
	  

}
