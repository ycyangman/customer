package org.swaf.foundation.crypto;

import lombok.Getter;

/**
 * @author yonghan.lee
 *
 */
public enum KeyType {
	
	SWAF("SWAF"), ETC("ETC"), PASSWORD("PASSWORD");
	
	@Getter final private String val;

	KeyType(String val) {
		this.val = val;
	}
	
	

}
