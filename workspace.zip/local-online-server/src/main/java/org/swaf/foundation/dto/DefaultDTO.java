package org.swaf.foundation.dto;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;
import lombok.Setter;
import org.swaf.foundation.annotation.Length;
import org.swaf.foundation.annotation.NotEmpty;
import org.swaf.foundation.annotation.NotNull;
import org.swaf.foundation.annotation.Patterned;
import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.util.APSBeanUtils;


/**
 * @author yonghan.lee
 *
 */
public class DefaultDTO {

	MessageManager mm = APSBeanUtils.getBean(MessageManager.class);
	@Getter ArrayList<String> validateErrors;
	
	@Getter @Setter
	String pgHasNext = "N"; 
	@Getter @Setter
	int pgSq = 0;
	@Getter @Setter
	int pgSz = 20;
	@Getter @Setter
	int pgResultCount = 0;
	@Getter @Setter
	int totalCount = 0;

	//DTO 항목의 값을 Annotation 설정을 기준으로 Validation 한다.
	public <T extends DefaultDTO> boolean validate (Class<T> type) {
		
		boolean result = true;
		
		Field[] fields = type.getDeclaredFields();
		ArrayList<String> checkErrors = new ArrayList<>();
		
		
		for (Field field : fields) {
			
			Annotation[] annotations = field.getDeclaredAnnotations();
			
			for (Annotation annotation : annotations) {
				
				String name = field.getName();
				Object val = this.get(name);
				
				if (annotation.annotationType() == NotEmpty.class) {
					
					if (val == null) {
						checkErrors.add (mm.getMessage("SYSI0002", new String[]{name}));
					} else {
						if (val instanceof String && ((String) val).length() == 0) {
							checkErrors.add (mm.getMessage("SYSI0002", new String[]{name}));
						}
					}
					
				} else if (annotation instanceof NotNull) {
					
					if (val == null) {
						checkErrors.add (mm.getMessage("SYSI0002", new String[]{name}));
					} 

				} else if (annotation instanceof Patterned) {
					
					Patterned ann = (Patterned) annotation;					
					if (val instanceof String && !((String) val).matches(ann.pattern())) {
						checkErrors.add (mm.getMessage("SYSI0003", new String[]{name}));
					}
					
				} else if (annotation instanceof Length) {
					Length ann = (Length) annotation;					
					if (val instanceof String) {
						
						int min = ann.min();
						int max = ann.max();
						
						if (min > -1 && ((String) val).length() < min) {
							checkErrors.add (mm.getMessage("SYSI0004", new String[]{name, String.valueOf(min)}));
						}
						if (max > -1 && ((String) val).length() > max) {
							checkErrors.add (mm.getMessage("SYSI0005", new String[]{name, String.valueOf(max)}));
						}
						
					}
				}
			}
		}
		
		if (checkErrors.size() > 0) {
			result = false;
			this.validateErrors = checkErrors;
		}
		
		return result;
	}
	
	//key에 해당하는 필드 값을 리턴한다. 
	public Object get(String key) {
		
		Object val = null;
		
		try {
			
			Method method = this.getClass().getMethod("get"+StringUtils.capitalize(key));
			val = method.invoke(this);
			
		} catch (Exception e) {
			//지정한 파라메터를 찾을 수 없습니다. (${0})
			throw new SysException ("SYSE0017", new String[] {key}, e);
		} 

		return val;
		
	}
	
	//key에 해당하는 필드에 값을 세팅한다. 
	public void set (String key, Object val) {
		
		String methodName = "set" + StringUtils.capitalize(key);
		boolean set = false;
		
		Method[] methods = this.getClass().getMethods();
		
		try {
			
			for (Method m : methods) {
				if (m.getName().equals(methodName)) {
					m.invoke(this, val);
					set = true;
					break;
				}
			}
			
		} catch (Exception e) {
			if (val == null) {
				//지정된 파라메터 값을 세팅 할 수 없습니다. (${0} : ${1})
				throw new SysException ("SYSE0018", new String[] {key, "null"}, e);
			} else {
				//지정된 파라메터 값을 세팅 할 수 없습니다. (${0} : ${1})
				throw new SysException ("SYSE0018", new String[] {key, val.toString()}, e);
			}
		}
		
		if (!set) {
			if (val == null) {
				//지정된 파라메터 값을 세팅 할 수 없습니다. (${0} : ${1})
				throw new SysException ("SYSE0018", new String[] {key, "null"});
			} else {
				//지정된 파라메터 값을 세팅 할 수 없습니다. (${0} : ${1})
				throw new SysException ("SYSE0018", new String[] {key, val.toString()});
			}
		}
		
		
	}

}
