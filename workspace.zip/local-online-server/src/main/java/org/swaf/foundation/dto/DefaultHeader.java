package org.swaf.foundation.dto;

import lombok.Data;

/**
 * @author yonghan.lee
 *
 */

@Data
public class DefaultHeader {

	/*
	 * 공통항목
	 */

	// guid
	String guid;
	// 진행번호
	String prgNo;
	// 서비스아이디
	String svcId;
	// 시스템환경구분코드
	String sysEnvDscd;
	// 호출시스템아이디
	String callSysId;
	// 화면번호
	String scrnNo;
	// 사용언어
	String usLang;
	// 사용자번호
	String usrId;
	// 사용자 IP주소
	String usrIpAd;
	// auth token
	String authToken;

	/*
	 * 응답전문항목
	 */

	// 처리결과코드
	String procRscd;
	// 메시지코드
	String msgCd;
	// 기본메시지
	String bascMsg;
	// 부가메시지
	String adMsg;
	// 다음실행명령정보
	String nxtExeCmdInfo;

}
