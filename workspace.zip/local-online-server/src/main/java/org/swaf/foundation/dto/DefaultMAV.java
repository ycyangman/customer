package org.swaf.foundation.dto;

import org.springframework.web.servlet.ModelAndView;

import lombok.Getter;
import lombok.Setter;

public class DefaultMAV<T extends DefaultDTO> extends ModelAndView {

	@Getter @Setter
	T dto;
	
	public DefaultMAV (){
		this.setViewName("jsonView");
	}
	
	public DefaultMAV (T dto){
		this.setViewName("jsonView");
		this.addObject("responseDTO", dto);
	}

}
