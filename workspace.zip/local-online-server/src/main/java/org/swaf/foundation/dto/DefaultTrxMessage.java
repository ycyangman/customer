package org.swaf.foundation.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author yonghan.lee
 *
 */
public class DefaultTrxMessage {
	
	@Getter @Setter private DefaultHeader header;
	@Getter @Setter private Object body;
	@Getter @Setter private DefaultDTO user;

}
