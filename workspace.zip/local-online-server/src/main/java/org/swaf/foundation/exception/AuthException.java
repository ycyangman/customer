package org.swaf.foundation.exception;

public class AuthException extends BizException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5962188771901773416L;

	
	public AuthException(String msgId) {
		super(msgId);
		// TODO Auto-generated constructor stub
	}


	public AuthException(String msgId, String[] params, Throwable t) {
		super(msgId, params, t);
		// TODO Auto-generated constructor stub
	}


	public AuthException(String msgId, String[] params) {
		super(msgId, params);
		// TODO Auto-generated constructor stub
	}


	public AuthException(String msgId, Throwable t) {
		super(msgId, t);
		// TODO Auto-generated constructor stub
	}

	
	

}
