package org.swaf.foundation.exception;

public class BatchException extends SysException {

	private static final long serialVersionUID = 167686868686868686L;
	
	public BatchException(String msgId, String[] params, Throwable t) {
		super(msgId, params, t);

	}

	public BatchException (String msgId, Throwable t) {
		super(msgId, t);
	}

	public BatchException (String msgId, String[] params) {
		super(msgId, params);
	}
	
	public BatchException(String msgId) {
		super(msgId);
	}
	


	@Override
	public String getLocalizedMessage() {
		return getMessage();
	}

}
