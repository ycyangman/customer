package org.swaf.foundation.exception;

public class InvalidCryptoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7846538193413040696L;
	
	public InvalidCryptoException () {
		super();
	}

	public InvalidCryptoException (Throwable t) {
		super(t);
	}

	public InvalidCryptoException (String msg) {
		super(msg);
	}

	public InvalidCryptoException (String msg, Throwable t) {
		super(msg, t);
	}

}
