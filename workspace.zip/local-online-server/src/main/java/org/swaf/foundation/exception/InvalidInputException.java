package org.swaf.foundation.exception;

public class InvalidInputException extends BizException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3148744013983959372L;


	public InvalidInputException(String msgId) {
		super(msgId);
		// TODO Auto-generated constructor stub
	}


	public InvalidInputException(String msgId, String[] params, Throwable t) {
		super(msgId, params, t);
		// TODO Auto-generated constructor stub
	}


	public InvalidInputException(String msgId, String[] params) {
		super(msgId, params);
		// TODO Auto-generated constructor stub
	}


	public InvalidInputException(String msgId, Throwable t) {
		super(msgId, t);
		// TODO Auto-generated constructor stub
	}

}
