package org.swaf.foundation.exception;

public class KeyGenerationException extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6078653596990336459L;

	public KeyGenerationException () {
		super();
	}

	public KeyGenerationException (Throwable t) {
		super(t);
	}

	public KeyGenerationException (String msg) {
		super(msg);
	}

	public KeyGenerationException (String msg, Throwable t) {
		super(msg, t);
	}

}
