package org.swaf.foundation.exception;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.util.APSBeanUtils;

public class SysException extends RuntimeException {

	private static final long serialVersionUID = -2917910820942890441L;
	
	@Getter protected String msgId = null;
	@Getter protected String message = null;
	
	private void setMessageInfo (String msgId, String[] params) {
		
		this.msgId = msgId;
		
		MessageManager mm = APSBeanUtils.getBean(MessageManager.class);
		
		String errMessage = mm.getMessage(msgId, params);
		
		if (!StringUtils.isEmpty(errMessage)) {
			this.message = String.format("[%s] %s", msgId, errMessage);
		}
	}
	
	
	public SysException (String msgId, String[] params, Throwable t) {
		super(msgId, t);
		setMessageInfo(msgId, params);
	}
	
	public SysException (String msgId, Throwable t) {
		super(msgId, t);
		setMessageInfo(msgId, null);
	}

	public SysException (String msgId, String[] params) {
		super(msgId);
		setMessageInfo(msgId, params);
	}
	
	
	public SysException (String msgId) {
		super(msgId);
		setMessageInfo(msgId, null);
	}

	@Override
	public String getLocalizedMessage() {
		return getMessage();
	}
	
}
