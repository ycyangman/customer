package org.swaf.foundation.handler;


import org.swaf.foundation.dto.DefaultHeader;
import org.swaf.foundation.service.ServiceInfo;
import org.apache.commons.lang3.StringUtils;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.context.ProcRscd;
import org.swaf.foundation.util.ContextUtils;

public class DefaultHandler {

	
	public static DefaultHeader createHeaderFromContext() {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		DefaultHeader header = ctx.getHeader();
		
		header.setGuid     (ctx.getGuid());
		header.setPrgNo    (ctx.getPrgNo()+1);
		header.setAuthToken(ctx.getAuthToken());
		header.setProcRscd (StringUtils.isEmpty(ctx.getProcRscd()) ? ProcRscd.SUCCESS.getVal() : ctx.getProcRscd());
		header.setMsgCd    (StringUtils.isEmpty(ctx.getMsgCd()) ? "" : ctx.getMsgCd());
		header.setBascMsg  (StringUtils.isEmpty(ctx.getBascMsg()) ? "" : ctx.getBascMsg());
		header.setAdMsg    (StringUtils.isEmpty(ctx.getAdMsg()) ? "" : ctx.getAdMsg());
		
		if(StringUtils.isEmpty(header.getUsrIpAd())) {
			header.setUsrIpAd(ctx.getUsrIpAd());
		}
		
		return header;
		
	}
	
	public static void setServiceInfoToContext(OnlineApplicationContext ctx, ServiceInfo serviceInfo) {
		
		ctx.setSvcId(serviceInfo.getSvcId());
		ctx.setSvcNm(serviceInfo.getSvcNm());
		ctx.setAuthReqYn(serviceInfo.getAuthReqYn());
	}
	
}
