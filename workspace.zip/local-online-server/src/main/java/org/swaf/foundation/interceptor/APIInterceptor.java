package org.swaf.foundation.interceptor;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.context.ProcRscd;
import org.swaf.foundation.dto.DefaultHeader;
import org.swaf.foundation.dto.DefaultTrxMessage;
import org.swaf.foundation.exception.BizException;
import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.ContextUtils;

@Slf4j
public class APIInterceptor extends DefaultInterceptor   {

	@Autowired
	ObjectMapper objectMapper;
	
	@Autowired
	PropertyManager pm;
	
	@Autowired
	@Qualifier("apsSession")
	SqlSessionTemplate apsSession;
	
	@Autowired
	@Qualifier("session")
	SqlSessionTemplate session;
	
	@Autowired
	@Qualifier ("appTxManager")
	DataSourceTransactionManager txManager;
	
	@Autowired
	MessageManager mm;
	
	
	final SimpleDateFormat utcDateFormat = new SimpleDateFormat("yyyyMMdd");
	final SimpleDateFormat utcTimeFormat = new SimpleDateFormat("HHmmss");
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

		//
		boolean doContinue = false;
		
		
		//기본인터셉터를 먼저 실행한다. 
		super.preHandle(request, response, handler);
		
		//Context객체를 얻는다.
		OnlineApplicationContext ctx = (OnlineApplicationContext)ContextContainer.get();
		
		ByteArrayOutputStream bos = null;
		
		try {
		
			//JSON전문에서 헤더를 파싱한다. 
			InputStream in = request.getInputStream();
			int len = 0;
			byte[] buff = new byte[1024];
			bos = new ByteArrayOutputStream();
			while ((len = in.read(buff, 0, buff.length))!=-1) {
				bos.write(buff, 0, len);
			}
			bos.flush();
			byte[] requestMessage = bos.toByteArray();
			
			JsonNode headerNode = objectMapper.readTree(requestMessage).get("header");
			DefaultHeader h = objectMapper.treeToValue(headerNode, DefaultHeader.class);		
			APSBeanUtils.copyProperties(h, ctx);
			ctx.setHeader(h);
			
			//Body부
			JsonNode bodyNode = objectMapper.readTree(requestMessage).get("body");
			byte[] body = objectMapper.writeValueAsBytes(bodyNode);
			
			if (log.isDebugEnabled()) {
				log.debug("header ::: {}", h);
				log.debug("body ::: {}", new String(body, "UTF-8"));
			}
			
			ctx.setIn(body);
			
			//시스템환경구분코드가 없으면 오류 발생시킴
			if (StringUtils.isEmpty(ctx.getSysEnvDscd())) {
				throw new RuntimeException ("헤더 내 시스템환경구분코드 값 없음");
			}

			//허용되지 않은 시스템환경구분코드가 들어오면 오류 발생시킴
			boolean isAllowedSysEnvDscd = false;
			for (String envDscd : pm.getProperty("allowedSysEnvDscd", String[].class)) {
				if (ctx.getSysEnvDscd().equals(envDscd)) {
					isAllowedSysEnvDscd = true;
					break;
				}
			}
			if (!isAllowedSysEnvDscd) {
				log.error("허용되지 않은 sys.env.dscd : {}", ctx.getSysEnvDscd());
				throw new RuntimeException ("허용되지 않은 sys.env.dscd");
			}
			
			//GUID가 없을 경우 새로 생성한다.
			if (StringUtils.isEmpty(ctx.getGuid())) {
				ctx.setGuid(UUID.randomUUID().toString());
			}
			
			//컨텍스트에 기본정보를 세팅한다. 
			setBgnTime();
			setSystemInfo(request);
			setIpAd(request);
			setEtcInfo();
			ctx.setCallUrl(request.getServletPath());
			
			//추가적인 필터를 실행한다. 
			//TODO
						
			
			doContinue = true;
		} catch (Exception e) {
			log.error("선처리필터실행오류", e);
			doContinue = false;
		
		} finally {
			
			if (bos != null) {
				bos.close();
				bos = null;
			}
			
		}
		
		return doContinue;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
		
		if (modelAndView == null) {
			//매핑된 URL이 없는 경우
			return;
		}
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		Object responseDTO = modelAndView.getModelMap().get("responseDTO");		
		ctx.setOutput(responseDTO);
		
		modelAndView.clear();
		
		super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

		//Context객체를 얻는다.
		OnlineApplicationContext ctx = (OnlineApplicationContext)ContextContainer.get();

		//처리종료시각
		setEndTime();
		
		//처리결과 
		if (ex == null) {
			//정상처리
			ctx.setProcRscd(ProcRscd.SUCCESS.getVal());
			if (StringUtils.isEmpty(ctx.getMsgCd())) {
				ctx.setMsgCd("SYSI0001");
				ctx.setBascMsg(mm.getMessage("SYSI0001"));
			}
			
		} else {
		
			if (ex instanceof BizException) {
				ctx.setMsgCd(((BizException) ex).getMsgId());
				ctx.setBascMsg(ex.getMessage());
				ctx.setProcRscd(ProcRscd.BIZEXCEPTION.getVal());
			} else if (ex instanceof SysException) {
				ctx.setMsgCd(((SysException) ex).getMsgId());
				ctx.setBascMsg(ex.getMessage());
				ctx.setProcRscd(ProcRscd.SYSEXECPTION.getVal());
			} else {
				ctx.setMsgCd("SYSE0001");
				ctx.setMsgCd(mm.getMessage("SYSE0001"));
				ctx.setProcRscd(ProcRscd.SYSEXECPTION.getVal());
			}

			log.error("error occurred", ex);
			
		}
		
		//Http Header조립
		response.addHeader("Content-type", "application/json; charset=UTF-8");
		
		//전문조립
		DefaultTrxMessage trxMessage = new DefaultTrxMessage();
		DefaultHeader header = getResponseHeader();
		trxMessage.setHeader(header);
		if (ctx.getOut() != null)
			trxMessage.setBody(ctx.getOut());
		OutputStream os = response.getOutputStream();
		os.write(objectMapper.writeValueAsBytes(trxMessage));
		os.flush();
		
		super.afterCompletion(request, response, handler, ex);
	}


	/**
	 * 종료시각 정보 세팅
	 */
	private void setEndTime () {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss");

		//Context객체를 얻는다.
		OnlineApplicationContext ctx = (OnlineApplicationContext)ContextContainer.get();

		dateFormat.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		timeFormat.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		
		//현재시각 세팅
		long currentTs = System.currentTimeMillis();
		
		ctx.setProcEndTs(currentTs);
		ctx.setTxEndTm(timeFormat.format(new Date(currentTs)));
		ctx.setUtcEndTm(utcTimeFormat.format(new Date(currentTs)));
		ctx.setProcPd(ctx.getProcEndTs()-ctx.getProcBgnTs());
		
	}
	
	
	/**
	 * 시작시각 정보 세팅
	 */
	private void setBgnTime () {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss");

		//Context객체를 얻는다.
		OnlineApplicationContext ctx = (OnlineApplicationContext)ContextContainer.get();

		//사용자 Timezone
		if (StringUtils.isEmpty(ctx.getTz())) {
			ctx.setTz(pm.getProperty("default.timezone"));
		}
		
		dateFormat.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		timeFormat.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		
		//현재시각 세팅
		long currentTs = System.currentTimeMillis();
		ctx.setProcBgnTs(currentTs);
		ctx.setTxDt(dateFormat.format(new Date(currentTs)));
		ctx.setTxBgnTm(timeFormat.format(new Date(currentTs)));
		ctx.setUtcDt(utcDateFormat.format(new Date(currentTs)));
		ctx.setUtcBgnTm(utcTimeFormat.format(new Date(currentTs)));		
		
	}
	
	/**
	 * 처리시스템 정보 세팅
	 */
	private void setSystemInfo (HttpServletRequest request) {

		//Context객체를 얻는다.
		OnlineApplicationContext ctx = (OnlineApplicationContext)ContextContainer.get();

		ctx.setCtxId("api");
		ctx.setProcInstId(pm.getProperty("GAE_INSTANCE"));

	}
	
	/**
	 * 요청자의 IP를 세팅한다. 
	 * @param request
	 */
	private void setIpAd (HttpServletRequest request) {
		
		//Context객체를 얻는다.
		OnlineApplicationContext ctx = (OnlineApplicationContext)ContextContainer.get();

		String ip = request.getHeader("X-Forwarded-For");

        if (ip == null) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null) {
            ip = request.getHeader("WL-Proxy-Client-IP"); 
        }
        if (ip == null) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null) {
            ip = request.getRemoteAddr();
        }
        
        if (log.isDebugEnabled()) {
        	log.debug("요청자 IP 주소 ::: {}", ip);
        }
 
        ctx.setUsrIpAd(ip);
 		
	}
	
	
	
	/**
	 * 기타정보 세팅
	 */
	private void setEtcInfo () {

		//Context객체를 얻는다.
		OnlineApplicationContext ctx = (OnlineApplicationContext)ContextContainer.get();
		
		//사용언어
		if (StringUtils.isEmpty(ctx.getUsLang())) {
			ctx.setUsLang(pm.getProperty("default.lang"));
		}		
		
	}
	
	/**
	 * 응답할 헤더객체를 얻는다. 
	 * @return
	 */
	private DefaultHeader getResponseHeader () {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		DefaultHeader header = ctx.getHeader();
		
		header.setMsgCd(ctx.getMsgCd());
		header.setBascMsg(ctx.getBascMsg());
		header.setAdMsg(ctx.getAdMsg());
		header.setGuid(ctx.getGuid());
		header.setAuthToken(ctx.getAuthToken());
		header.setProcRscd(ctx.getProcRscd());
		
		if (ctx.getNxtExeCmdInfo() != null) {
			try {
				header.setNxtExeCmdInfo(objectMapper.writeValueAsString(ctx.getNxtExeCmdInfo()));
			} catch (JsonProcessingException e) {
				log.warn ("fail to transform json format", e);
			}
		}
		
		return header;
	}

	/**
	 * Bean 초기화
	 */
	public void init () {		
		
		utcDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		utcTimeFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

		
		String allowedSysEnvDscd = pm.getProperty("allowed.sys.env.dscd");

		if (StringUtils.isEmpty(allowedSysEnvDscd)) {
			//반드시 세팅되어야 함
			throw new RuntimeException ("allowed.sys.env.dscd 값 누락되었음");
		}
		
		String[] aAllowedSysEnvDscd = allowedSysEnvDscd.split("\\s*,\\s*");
		pm.setProperty("allowedSysEnvDscd", aAllowedSysEnvDscd);
			
	
	}
}
