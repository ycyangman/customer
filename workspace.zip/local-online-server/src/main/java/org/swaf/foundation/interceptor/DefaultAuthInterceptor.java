package org.swaf.foundation.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import lombok.extern.slf4j.Slf4j;
import org.swaf.foundation.annotation.Authorized;
import org.swaf.foundation.auth.AuthToken;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.exception.AuthException;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.util.APSStringUtils;
import org.swaf.foundation.util.ContextUtils;

@Slf4j
public class DefaultAuthInterceptor implements HandlerInterceptor {

	@Autowired
	CacheClient<String> cache;
	
	@Autowired
	PropertyManager pm;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		String tokenId = ctx.getAuthToken();
		AuthToken token = null;
		
		//tokenId 가 있으면 무조건 TTL 을 reset 시킨다.
		if (StringUtils.isNotEmpty(tokenId)) {
			cache.setExpire(tokenId, Long.parseLong(pm.getProperty("login.keep.period")));
			// redis key 형식 : authtoken."시스템환경구분코드".사용자아이디.토큰ID
			String strToken = cache.get(String.format("%s.%s.%s.%s", "authtoken", ctx.getSysEnvDscd(), ctx.getUsrId(), tokenId), String.class);
			token = APSStringUtils.convertJsonStringToObject(strToken, AuthToken.class);
			if (log.isDebugEnabled()) {
				log.debug("redis key ::: {}", String.format("%s.%s.%s.%s", "authToken", ctx.getSysEnvDscd(), ctx.getUsrId(), tokenId));
			}
		}
			
		if (handler instanceof HandlerMethod) {
			HandlerMethod hm = (HandlerMethod) handler;
			if (hm.hasMethodAnnotation(Authorized.class)) {
				
				//인증이 필요한 서비스임
				if (token == null) {
					//사용자 인증이 필요한 서비스입니다.
					throw new AuthException("SYSE0004");
				}
		
				//권한 체크
				Authorized ann = hm.getMethodAnnotation(Authorized.class);
				//실행 허용된 역할
				long allowed = 0;
				for (long role : ann.roles()) {
					allowed = allowed | role;
				}
				//사용자의 역할과 비교
				if ((allowed & token.getRoles()) == 0L ) {
					//실행 권한이 없습니다.
					throw new AuthException("SYSE0010");
				}
				
				hm.getMethodAnnotation(Authorized.class).roles();
				
			}
		}	
		
		return true;
	}
	
	
	

}
