package org.swaf.foundation.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import lombok.extern.slf4j.Slf4j;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.context.OnlineApplicationContext;


@Slf4j
public class DefaultInterceptor implements HandlerInterceptor {
	
	//protected HashMap<String,LinkedList<FilterInfo>> filterContainer;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		if (log.isDebugEnabled()) {
			log.debug("기본 선처리필터 시작");
		}
		
		//컨텍스트를 세팅하여 ThreadLocal에 세팅한다. 
		ContextContainer.set(new OnlineApplicationContext());
		
		

		return true;
	}
	
//	protected void executeFilters (FilterType filterType, HttpServletRequest request, HttpServletResponse response, Exception ex) throws Exception {
//		
//		OnlineContext ctx = ContextUtils.getOnlineContext();
//		
//		String filterSetKey = String.format("%s::$s", ctx.getSysEnvDscd(), filterType.getVal());
//		filterSetKey = filterSetKey.toUpperCase();
//		
//		LinkedList<FilterInfo> filters = filterContainer.get(filterSetKey);
//		
//		try {
//			
//			for (FilterInfo filter : filters) {
//			
//				boolean doExecute = true;
//				
//				if (filter.getAExcludePats() != null && filter.getAExcludePats().length > 0) {
//					String path = request.getPathInfo();
//					for (String excludePat : filter.getAExcludePats()) {
//						if (path.matches(excludePat)) {
//							//실행하지 않는다. 
//							doExecute = false;
//							break;
//						}
//					}
//				}
//				
//				if (doExecute) {
//					filter.getFilter().execute(request, response, ex);					
//				}
//				
//			}
//			
//		} catch (Exception e) {
//			throw e;
//		}
//		
//	}
	

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("기본 후처리필터 시작");
		}

		
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

		if (log.isDebugEnabled()) {
			log.debug("기본 시스템 후처리필터 시작");
		}
		
		//ThreadLocal 에서 컨텍스트를 제거한다. 
		ContextContainer.unset();

		
	}
	
	

}
