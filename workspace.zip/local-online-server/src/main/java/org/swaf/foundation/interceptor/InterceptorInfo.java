package org.swaf.foundation.interceptor;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.swaf.foundation.context.DefaultVO;

@Data
@EqualsAndHashCode(callSuper=false)
public class InterceptorInfo extends DefaultVO {
	
	String fltId;
	String fltNm;
	String fltTyp;
	String excludePats;
	String[] aExcludePats;	
}
