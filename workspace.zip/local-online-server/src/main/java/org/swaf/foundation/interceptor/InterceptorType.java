package org.swaf.foundation.interceptor;

import lombok.Getter;

public enum InterceptorType {

	PREFILTER("1"), POSTFILTER("2"), COMPLETEFILTER("3");

	@Getter final private String val;

	private InterceptorType (String val) {
		this.val = val;
	}
	
	
}
