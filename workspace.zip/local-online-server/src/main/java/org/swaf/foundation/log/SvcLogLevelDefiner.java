package org.swaf.foundation.log;

import org.slf4j.MDC;

import ch.qos.logback.core.Context;
import ch.qos.logback.core.spi.PropertyDefiner;
import ch.qos.logback.core.status.Status;
import lombok.Getter;
import lombok.Setter;

public class SvcLogLevelDefiner implements PropertyDefiner {

	@Getter
	@Setter
	String svcId;
	
	
	@Override
	public String getPropertyValue() {

		String svcId = MDC.get("svcId");
		
		System.out.println("::::::svcId :"+svcId);
		
		String logLevel = "OFF";
		
		if ("CMM001".equals(svcId)) {
			logLevel = "DEBUG";
		}
		
		return logLevel;
				
				
	}

	
	@Override
	public void setContext(Context context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Context getContext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addStatus(Status status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addInfo(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addInfo(String msg, Throwable ex) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addWarn(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addWarn(String msg, Throwable ex) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addError(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addError(String msg, Throwable ex) {
		// TODO Auto-generated method stub
		
	}


}
