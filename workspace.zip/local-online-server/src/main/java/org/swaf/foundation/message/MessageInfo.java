package org.swaf.foundation.message;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.swaf.foundation.context.DefaultVO;

/**
 * @author yonghan.lee
 *
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MessageInfo extends DefaultVO {

	String msgId;
	String lang;
	String msgCtnt;
	
}
