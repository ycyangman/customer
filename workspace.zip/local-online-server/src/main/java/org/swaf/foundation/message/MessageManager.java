package org.swaf.foundation.message;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.context.DefaultContext;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.util.ContextUtils;

public class MessageManager { 
	
	@Autowired
	SqlSessionTemplate swafSession;
	
	@Autowired
	PropertyManager pm;
	
	
	//private HashMap<String,String> cache;
	@Autowired
	@Qualifier("adminMessageCacheClient")
	CacheClient<String> cache;
	
	
	public void init () {
		//this.cache = new HashMap<>();
	}

	public String getMessage (String msgId) {
		
		DefaultContext ctx = ContextUtils.getContext();
		String lang = null;
		
		if (ctx != null) {
			lang = ctx.getUsLang();
		} else {
			lang = pm.getProperty("default.lang");
		}

		return getMessage(msgId, lang);
	}

	public String getMessage (String msgId, String [] param) {
		
		DefaultContext ctx = ContextUtils.getContext();
		String lang = null;
		
		if (ctx != null) {
			lang = ctx.getUsLang();
		} else {
			lang = pm.getProperty("default.lang");
		}
		
		return getMessage(msgId, lang, param);
	}

	public String getMessage (String msgId, String lang, String[] params) {
		
		String message = getMessageFromCache(msgId, lang);
		
		if (!StringUtils.isEmpty(message)) {
		
			if (params != null && params.length > 0) {
				
				for (int i=0; i<params.length; i++) {
					if (params[i] == null) {
						params[i] = "null";
					}
					message = message.replaceAll ("\\$\\{"+i+"\\}", params[i]);
				}
				
			}
		}
		
		return message;
	}

	public String getMessage (String msgId, String lang) {
		return getMessage (msgId, lang, null);
	}
	
	private String getMessageFromDB (String msgId, String lang) {
		
		if(StringUtils.isEmpty(lang)) {
			lang = "KO";
		}
		
		String message = null;
		
		HashMap<String, String> params = new HashMap<>();
		params.put("msgId", msgId);
		params.put("lang", lang);
		
		MessageInfo messageInfo = swafSession.selectOne("org.swaf.admin.selectMessageById", params);
		
		if (messageInfo != null) {
			message = messageInfo.getMsgCtnt();
		} 
		
		return message;
		
	}

	private String getMessageFromCache (String msgId, String lang) {
		
		String cachedData = cache.getHashData("admin.message", msgId+"::"+lang, String.class);
		
		if (StringUtils.isEmpty(cachedData)) {
			String message = getMessageFromDB (msgId, lang);
			
			if (!StringUtils.isEmpty(message)) {
				cache.putHashData("admin.message", msgId+"::"+lang, message);
				
				cachedData = message;
			} else {
				cachedData = msgId;
			}
			
		}
		
		return cachedData;
		
	}
	
	
	/*
	private String getMessageFromCache (String msgId, String lang) {
		
		String cachedData = cache.get(msgId+"::"+lang);
		
		if (StringUtils.isEmpty(cachedData)) {
			String message = getMessageFromDB (msgId, lang);
			
			if (!StringUtils.isEmpty(message)) {
				cache.put(msgId + "::" + lang, message);
				cachedData = message;
			} else {
				cachedData = msgId;
			}
			
		}
		
		return cachedData;
		
	}
	*/
	
	/**
	 * Cache 에 등록된 모든 메시지 정보를 초기화한다. 
	 */
	public boolean refreshMessages () {
		//cache.clear();
		return cache.delete("admin.message");
		
	}

}
