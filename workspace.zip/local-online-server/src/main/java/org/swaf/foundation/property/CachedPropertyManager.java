package org.swaf.foundation.property;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import org.swaf.foundation.crypto.DataEncryptionManager;

/**
 * 
 * @author yonghan.lee
 *
 */
public class CachedPropertyManager implements PropertyManager {

	@Autowired
	Environment env;
	
	@Autowired
	DataEncryptionManager crypto;
	

	HashMap<String, Object> props = new HashMap<>();	
	
	public String getProperty (String key) {
		
		String val = null;
		
		if (props.containsKey(key)) {
			val = props.get(key).toString();
		} else {
			val = env.getProperty(key);
			if (val == null) {
				val = "";
			}
			props.put(key,val);
		}
		
		return val;
	}

	@SuppressWarnings("unchecked")
	public <T> T getProperty (String key, Class<T> type) {
		
		T val = null;
		
		if (props.containsKey(key)) {
			val = (T) props.get(key);
		} else {
			val = env.getProperty(key, type);
			props.put(key,val);
		}
		
		return val;
	}
	
	
	@Override
	public String getDecryptedProperty(String key) {
		String encrypted = getProperty(key);
		String dataType = encrypted.replaceAll("\\}.*", "").replaceAll("\\{", "");
		encrypted = encrypted.replaceAll("\\{"+dataType+"\\}", "");
		String decrypted = null;
		decrypted = crypto.decrypt(encrypted, dataType);

		return decrypted;
	}
	
	public void setProperty (String key, Object value) {
		props.put(key, value);
	}

	@Override
	public void refreshProperty() {
		synchronized (props) {
			props = new HashMap<>();				
		}
	}

}
