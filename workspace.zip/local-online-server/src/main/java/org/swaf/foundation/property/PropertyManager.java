package org.swaf.foundation.property;

/**
 * @author yonghan.lee
 *
 */
public interface PropertyManager {
	public String getProperty(String key);
	public <T> T getProperty (String key, Class<T> type);
	public String getDecryptedProperty (String key);
	public void refreshProperty ();
	public void setProperty (String key, Object value);

}

