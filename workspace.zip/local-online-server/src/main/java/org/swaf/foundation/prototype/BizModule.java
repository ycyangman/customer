package org.swaf.foundation.prototype;

import java.util.ArrayList;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.swaf.das.TransactionManagerMap;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.crypto.DataEncryptionManager;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.ContextUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BizModule {

	protected PropertyManager pm;
	protected TransactionManagerMap txManagerMap;
	protected CacheClient<String> cache;
	protected DataEncryptionManager crypto;
	
	
	@SuppressWarnings("unchecked")
	public BizModule() {
		
		this.pm = APSBeanUtils.getBean(PropertyManager.class);
		this.txManagerMap = APSBeanUtils.getBean(TransactionManagerMap.class);
		this.cache = (CacheClient<String>)APSBeanUtils.getBean("cacheClient");
		this.crypto = APSBeanUtils.getBean(DataEncryptionManager.class);
	}
	
	public TransactionStatus beginRequiresNewTx() {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		DataSourceTransactionManager txManager = txManagerMap.getPrimaryTxManager();
		
		DefaultTransactionDefinition transactionDefinition = (DefaultTransactionDefinition)APSBeanUtils.getBean("requiresNewTransactionDefinition");
		
		
		TransactionStatus txStatus = txManager.getTransaction(transactionDefinition);
		
		if(ctx.getUserTxStatuses() == null) {
			ctx.setUserTxStatuses(new ArrayList<>());
		}
		
		ctx.getUserTxStatuses().add(txStatus);
		
		return txStatus;
	}

	public TransactionStatus beginRequiresNewTx(String alias) {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		DataSourceTransactionManager txManager = txManagerMap.getTxManager(alias);
		
		DefaultTransactionDefinition transactionDefinition = 
				(DefaultTransactionDefinition)APSBeanUtils.getBean("requiresNewTransactionDefinition");
		
		
		TransactionStatus txStatus = txManager.getTransaction(transactionDefinition);
		
		if(ctx.getUserTxStatuses() == null) {
			ctx.setUserTxStatuses(new ArrayList<>());
		}
		
		ctx.getUserTxStatuses().add(txStatus);
		
		return txStatus;
	}
	
	public void endRequiresNewtTxWithCommit(TransactionStatus txStatus) {
		DataSourceTransactionManager txManager = txManagerMap.getPrimaryTxManager();
		
		txManager.commit(txStatus);
		
		if(log.isDebugEnabled()) {
			log.debug("required new transaction status :::: {}", txStatus.isCompleted());
		}
	}

	public void endRequiresNewtTxWithCommit(TransactionStatus txStatus, String alias) {
		DataSourceTransactionManager txManager = txManagerMap.getTxManager(alias);
		
		txManager.commit(txStatus);
		
		if(log.isDebugEnabled()) {
			log.debug("required new transaction status {}:::: {}", alias, txStatus.isCompleted());
		}
	}
	
	public void endRequiresNewtTxWithRollback(TransactionStatus txStatus) {
		DataSourceTransactionManager txManager = txManagerMap.getPrimaryTxManager();
		
		txManager.rollback(txStatus);
		
		if(log.isDebugEnabled()) {
			log.debug("required new transaction status rollback :::: {}", txStatus.isCompleted());
		}
	}

	public void endRequiresNewtTxWithRollback(TransactionStatus txStatus, String alias) {
		DataSourceTransactionManager txManager = txManagerMap.getTxManager(alias);
		
		txManager.rollback(txStatus);
		
		if(log.isDebugEnabled()) {
			log.debug("required new transaction status rollback {}:::: {}", alias, txStatus.isCompleted());
		}
	}

}
