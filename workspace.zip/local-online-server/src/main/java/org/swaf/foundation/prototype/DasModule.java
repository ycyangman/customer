package org.swaf.foundation.prototype;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionTemplate;
import org.swaf.das.DataSourceMap;
import org.swaf.das.SqlSessionTemplateMap;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.util.APSBeanUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DasModule {

	public SqlSessionTemplate sqlSession;
	protected SqlSessionTemplateMap sqlSessionMap;
	protected PropertyManager pm;
	
	protected DataSourceMap dataSourceMap;
	public DataSource dataSource;
	
	String primaryDbAlias;
	String dbAlias;
	
	public DasModule() {
		this.pm = APSBeanUtils.getBean(PropertyManager.class);
		this.sqlSessionMap = APSBeanUtils.getBean(SqlSessionTemplateMap.class);
		this.sqlSession = sqlSessionMap.getPrimarySqlSessionTemplate();
		
		this.dataSourceMap = APSBeanUtils.getBean(DataSourceMap.class);
		this.dataSource = dataSourceMap.getPrimaryDS();
		
		this.primaryDbAlias = pm.getProperty("appdb.primary");
		this.dbAlias = this.primaryDbAlias;
	}
	
	public SqlSessionTemplate getSqlSession(String alias) {
		
		return sqlSessionMap.getSqlSessionTemplate(alias);
	}

	public void setDbAlias(String dbAlias) {
		this.dbAlias = dbAlias;
		this.sqlSession = getSqlSession(dbAlias);
	}
	
}
