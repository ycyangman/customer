package org.swaf.foundation.prototype;

public interface Executable<T1, T2> {

	public T2 execute(T1 dto);
	
}
