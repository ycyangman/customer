package org.swaf.foundation.service;


import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.prototype.Executable;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class Filter<T1 extends DefaultDTO, T2 extends DefaultDTO> implements Executable<T1, T2> {


	@Getter @Setter Filter<T1, T2> nextFilter;
	
	public T2 invoke(T1 in) {
		
		log.debug("Filter {} is executed ...", this.getClass().getTypeName());
		
		T2 out = null;
		
		out = execute(in);
		
		if (hasNextFilter()) {
			out = this.nextFilter.invoke(in);
		}
	
		return out;
	}
	
	public abstract T2 execute(T1 in);
	
	public boolean hasNextFilter() {
		boolean result = false;
		
		if(nextFilter != null) {
			result = true;
		}
		return result;
	}
	
	
}
