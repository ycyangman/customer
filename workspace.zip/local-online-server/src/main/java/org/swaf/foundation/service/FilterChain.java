package org.swaf.foundation.service;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.TransactionTimedOutException;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.swaf.foundation.context.ContextHelper;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.ContextUtils;
import org.swaf.foundation.exception.BizException;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FilterChain {

	Filter<DefaultDTO, DefaultDTO> lastPreFilter = null;
	Filter<DefaultDTO, DefaultDTO> lastPostFilter = null;
	Filter<DefaultDTO, DefaultDTO> lastAlwaysPostFilter = null;
	
	
	@Getter @Setter Filter<DefaultDTO, DefaultDTO> preFilter = null;
	@Getter @Setter Filter<DefaultDTO, DefaultDTO> postFilter = null;
	@Getter @Setter Filter<DefaultDTO, DefaultDTO> alwaysPostFilter = null;
	
	@Getter @Setter ServiceExecutor<DefaultDTO, DefaultDTO> service;
	
	@Setter DataSourceTransactionManager txManager;
	
	@Setter int timeOut;
	
	
	public void execute() {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		try {
			if(preFilter != null) {
				preFilter.invoke((DefaultDTO)ctx.getIn());
			}
		
			DefaultTransactionDefinition txDefinition = (DefaultTransactionDefinition)APSBeanUtils.getBean("defaultTransactionDefinition");
			
			txDefinition.setTimeout(timeOut);
			
			//start transaction
			TransactionStatus txStatus = txManager.getTransaction(txDefinition);
			
			try {
				
				DefaultDTO out = service.execute((DefaultDTO)ctx.getIn());
				ctx.setOut(out);
				
			}
			catch(TransactionTimedOutException e) {
				txManager.rollback(txStatus);
				throw new SysException ("SYSE0001", new String[] {String.valueOf(txDefinition.getTimeout())}, e);
			}
			catch(RuntimeException e) {
				txManager.rollback(txStatus);
				throw e;
			}
			finally {
				if(!txStatus.isCompleted() && txStatus.isRollbackOnly()) {
					txManager.rollback(txStatus);
				}
				else if(!txStatus.isCompleted()) {
					txManager.commit(txStatus);
				}
				
				if(ctx.getUserTxStatuses() != null && ctx.getUserTxStatuses().size() > 0) {
					for (TransactionStatus userTxStatus : ctx.getUserTxStatuses()) {
						if(!userTxStatus.isCompleted() && userTxStatus.isRollbackOnly()) {
							txManager.rollback(txStatus);
						}
						else if(!userTxStatus.isCompleted()) {
							
							log.debug("userTxStatus : {}", userTxStatus.isCompleted());
							
							txManager.commit(txStatus);
						}
					}
				}
						
			}
			
			if(postFilter != null) {
				postFilter.invoke((DefaultDTO)ctx.getIn());
			}
			
			ContextHelper.setSuccessResult(ctx);
		}
		catch(BizException e) {
			ContextHelper.setBizErrResult(ctx, e);
			throw e;
		}
		catch(SysException e) {
			ContextHelper.setSysErrResult(ctx, e);
			throw e;
		}
		catch(Exception e) {
			ContextHelper.setGeneralErrResult(ctx, e);
			throw e;
		}
		finally {
			if (alwaysPostFilter != null) {
				alwaysPostFilter.invoke((DefaultDTO)ctx.getIn());
			}
		}
	}
	
	public void addPreFilter(Filter<DefaultDTO, DefaultDTO> filter) {
		if(filter == null) {
			return;
		}
		if(preFilter == null) {
			preFilter = filter;
			lastPreFilter = filter;
		}
		else {
			lastPreFilter.setNextFilter(filter);
			lastPreFilter = filter;
		}
	}

	public void addPostFilter(Filter<DefaultDTO, DefaultDTO> filter) {
		if(filter == null) {
			return;
		}
		if(postFilter == null) {
			postFilter = filter;
			lastPostFilter = filter;
		}
		else {
			lastPostFilter.setNextFilter(filter);
			lastPostFilter = filter;
		}
	}
	
	public void addAlwaysPostFilter(Filter<DefaultDTO, DefaultDTO> filter) {
		if(filter == null) {
			return;
		}
		if(alwaysPostFilter == null) {
			alwaysPostFilter = filter;
			lastAlwaysPostFilter = filter;
		}
		else {
			lastAlwaysPostFilter.setNextFilter(filter);
			lastAlwaysPostFilter = filter;
		}
	}
}
