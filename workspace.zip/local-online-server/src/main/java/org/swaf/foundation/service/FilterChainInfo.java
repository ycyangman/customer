package org.swaf.foundation.service;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FilterChainInfo {

	
	@Getter List<FilterInfo> preFilterDefs;
	@Getter List<FilterInfo> postFilterDefs;
	@Getter List<FilterInfo> alwaysPostFilterDefs;
	
	
	public void addFiletDef(FilterInfo filterInfo) {
		if(filterInfo == null) {
			if (log.isWarnEnabled()) {
				log.warn("no filter definition to be added");
			}
			return;
		}
	
		if(FilterType.PRE_FILTER.getVal().equals(filterInfo.getFltTyp()))  {
			preFilterDefs.add(filterInfo);
		}
		else if(FilterType.POST_FILTER.getVal().equals(filterInfo.getFltTyp()))  {
			postFilterDefs.add(filterInfo);
		}
		else if(FilterType.ALWAYS_POST_FILTER.getVal().equals(filterInfo.getFltTyp()))  {
			alwaysPostFilterDefs.add(filterInfo);
		}
	}
	
	public FilterChainInfo() {
		this.preFilterDefs = new ArrayList<>();
		this.postFilterDefs = new ArrayList<>();
		this.alwaysPostFilterDefs = new ArrayList<>();
	}

}
