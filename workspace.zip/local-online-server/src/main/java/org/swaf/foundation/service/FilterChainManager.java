package org.swaf.foundation.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.swaf.app.cl.AppRegistry;
import org.swaf.das.TransactionManagerMap;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.exception.SysException;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FilterChainManager {

	@Autowired
	SqlSessionTemplate swafSession;
	
	@Autowired
	@Getter
	AppRegistry appRegistry;
	
	@Getter
	ServiceManager svcManager;
	
	@Autowired
	TransactionManagerMap txManagerMap;
	
	HashMap<String, FilterChainInfo> filterChainInfoMap = new HashMap<>();
	
	HashMap<String, Filter<DefaultDTO, DefaultDTO>> systemFilterMap = new HashMap<>();
	
	public FilterChainManager(ServiceManager svcManager) {
		this.svcManager =  svcManager;
	}
	
	public void init() {
		
		String sysEnvDscd = System.getProperty("allowed.sys.env.dscd");
		
		if(StringUtils.isEmpty(sysEnvDscd)) {
			log.error("System parameter allowed.sys.env.dscd [{}] is required!", sysEnvDscd);
			
			//throw new SysException("SYSE000p", new String[] {sysEnvDscd});
		}
		
		String[] arrSysEnvDscd = sysEnvDscd.split("\\s*, \\s*");
		String[] arrCtxId = new String[] {"json", "fld", "xml", "eai"};
		
		for(String evnDscd : arrSysEnvDscd) {
			for (String ctxId : arrCtxId) {
				loadFilterDefinitions(ctxId, evnDscd);
			}
		}
	}
	
	/* 
	 * 
	 * 필터정보 조회 
	 * 
	 */
	private void loadFilterDefinitions(String ctxId, String sysEvnDscd) {
		HashMap<String, String> params = new HashMap<>();
		params.put("ctxId", ctxId);
		params.put("sysEvnDscd", sysEvnDscd);
		
		List<FilterInfo> list = new ArrayList<>(); 
		
		try {
			list = swafSession.selectList("filters.filtersByContext", params);
		}
		catch(Exception e) {
			//log.error("loadFilterDefinitions error", e);
			log.error("#######################loadFilterDefinitions error");
		}
		
		FilterChainInfo filterChainInfo = new FilterChainInfo();
		for(FilterInfo fi : list) {
			filterChainInfo.addFiletDef(fi);
		}
		
		/*
		 * 인증
		 */
		FilterInfo filterInfo = new FilterInfo();
		filterInfo.setFltTyp("1");
		filterInfo.setCmmFltYn("Y");  //공통필터여부
		filterInfo.setExtFltYn("N");  //
		filterInfo.setFltPkg("org.swaf.processor.support.auth");
		filterInfo.setFltClass("AuthCheckFilter");
		filterChainInfo.addFiletDef(filterInfo);
		
		/*
		 *거래로깅(후처리)
		 */
		filterInfo = new FilterInfo();
		filterInfo.setFltTyp("3");
		filterInfo.setCmmFltYn("Y");  //공통필터여부
		filterInfo.setExtFltYn("Y");  //업무필터
		filterInfo.setFltPkg("kr.ezinsurance.misc");
		filterInfo.setFltClass("TxLogDBFilter");
		filterChainInfo.addFiletDef(filterInfo);
		
		filterChainInfoMap.put(ctxId + "::"+sysEvnDscd, filterChainInfo);
	}
	
	private Filter<DefaultDTO, DefaultDTO> connectFilters(Filter<DefaultDTO, DefaultDTO> parent, Filter<DefaultDTO, DefaultDTO> filter) {
		Filter<DefaultDTO, DefaultDTO> current = filter;
		
		if(parent != null) {
			parent.setNextFilter(filter);
		}
		return current;
	}
	
	
	//filter chain 구성
	@SuppressWarnings("unchecked")
	private Filter<DefaultDTO, DefaultDTO> consitFilterChain(List<FilterInfo> filterInfoDefs, String svcId) {
		Filter<DefaultDTO, DefaultDTO> root = null;
		Filter<DefaultDTO, DefaultDTO> current = null;
		
		if(filterInfoDefs == null) {
			return null;
		}
		
		
		for(FilterInfo fi : filterInfoDefs) {
			
			try {
				Filter<DefaultDTO, DefaultDTO> filter = null;
				
				if ("Y".equals(fi.getExtFltYn())) {  //업무필터
					filter = appRegistry.getAppObject(fi.getFltPkg()+"."+fi.getFltClass(), Filter.class);
				}
				else {
					if(!systemFilterMap.containsKey(fi.getFltPkg()+"."+fi.getFltClass())) {
						filter = (Filter<DefaultDTO, DefaultDTO>)Class.forName(fi.getFltPkg()+"."+fi.getFltClass()).getDeclaredConstructor().newInstance();
						systemFilterMap.put(fi.getFltPkg()+"."+fi.getFltClass(), filter);
					}
					else {
						filter = systemFilterMap.get(fi.getFltPkg()+"."+fi.getFltClass());
					}
				}
				if(root == null && current == null) {
					root = filter;
					current = filter;
				}
				else {
					current = connectFilters(current, filter);
				}
			}
			catch(Exception e) {
				log.error("fail to initiatle a filterChain!!", e);
				throw new SysException("SYSE0001", e);
			}
			
		}
		return root;
	}
	
	@SuppressWarnings("unchecked")
	public FilterChain newFilterChain(String filterChainKey, String svcId) {
		
		FilterChain filterChain = new FilterChain();
		
		if(!filterChainInfoMap.containsKey(filterChainKey)) {
			log.error("filterChain is not defined!! [key:{}]", filterChainKey);
						
			throw new SysException("SYSE0003", new String[] {filterChainKey});
		}
	
		FilterChainInfo filterChainInfo = filterChainInfoMap.get(filterChainKey);
		
		//선처리필터
		filterChain.setPreFilter(consitFilterChain(filterChainInfo.getPreFilterDefs(), svcId));
		
		//후처리필터
		filterChain.setPostFilter(consitFilterChain(filterChainInfo.getPostFilterDefs(), svcId));
		
		filterChain.setAlwaysPostFilter(consitFilterChain(filterChainInfo.getAlwaysPostFilterDefs(), svcId));
		
		//타켓서비스구성------------------------------------------
		ServiceInfo si = svcManager.getServiceInfo(svcId);
		
		filterChain.setService(appRegistry.getAppObject(si.getSvcPkg()+"."+si.getSvcClass(), ServiceExecutor.class));
		
		filterChain.setTxManager(txManagerMap.getPrimaryTxManager());
		
		if(si.getSvcProcTo() == 0) {
			filterChain.setTimeOut(30);
		}
		else {
			filterChain.setTimeOut(si.getSvcProcTo());
		}
		
		return filterChain;
	}
	
	
}
