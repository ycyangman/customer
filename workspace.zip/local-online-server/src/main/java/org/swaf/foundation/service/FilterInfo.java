package org.swaf.foundation.service;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class FilterInfo {

	
	String ctxId;
	String fltId;
	int sq;
	String fltTyp;
	String cmmFltYn;
	String extFltYn;
	String svcIdPat;
	String fltPkg;
	String fltClass;
	
}
