package org.swaf.foundation.service;

import lombok.Getter;

public enum FilterType {

	PRE_FILTER("1"), POST_FILTER("2"), ALWAYS_POST_FILTER("3");
	
	@Getter final private String val;
	
	private FilterType(String val) {
		this.val = val;
	}

}
