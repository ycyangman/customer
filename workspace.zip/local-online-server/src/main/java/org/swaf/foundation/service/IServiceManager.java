package org.swaf.foundation.service;

public interface IServiceManager {

	public void init();
	public ServiceInfo getServiceInfo(String svcId);
}
