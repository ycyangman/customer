package org.swaf.foundation.service;

import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.prototype.Executable;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.message.MessageManager;
import org.swaf.foundation.crypto.DataEncryptionManager;

public abstract class ServiceExecutor<T1 extends DefaultDTO, T2 extends DefaultDTO> implements Executable<T1, T2> {

	@Override
	public abstract T2 execute(T1 dto);
	
	protected DataEncryptionManager em;
	protected PropertyManager pm;
	protected MessageManager mm;
	
	
	
	public ServiceExecutor() {
		this.em = APSBeanUtils.getBean(DataEncryptionManager.class);
		this.pm = APSBeanUtils.getBean(PropertyManager.class);
		this.mm = APSBeanUtils.getBean(MessageManager.class);
	}
	
}
