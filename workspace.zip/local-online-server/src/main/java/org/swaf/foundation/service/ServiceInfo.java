package org.swaf.foundation.service;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ServiceInfo {

	String svcId;
	
	String ioOutClass;
	String ioOutPkg;
	String ioInClass;
	String ioInPkg;
	String svcClass;
	String svcMthd;
	String svcPkg;
	String bizLv1;
	String bizLv2;
	String bizLv3;
	String svcNm;
	
	int trxKndNum;
	String authReqYn;
	
	long accRoles;
	int svcProcTo;
	
}
