package org.swaf.foundation.service;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.ClassUtils;
import org.swaf.app.cl.AppRegistry;
import org.swaf.foundation.annotation.Service;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.util.APSBeanUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ServiceManager implements IServiceManager {

	
	@Autowired
	@Qualifier("swafSession")
	SqlSessionTemplate swafSession;
	
	HashMap<String, ServiceInfo> services = new HashMap<>();
	
	public void init() {
		loadAllAvailableServiceInfo();		
	}
	
	public ServiceInfo getServiceInfo(String svcId) {
		ServiceInfo si = services.get(svcId);
		
		if(si == null) {
			
			ServiceInfo serviceInfo = null;
			try {
				serviceInfo = swafSession.selectOne("org.swaf.admin.serviceById", svcId);
			}
			catch(Exception e) {
				log.warn("while getting serviceInfo error occurred!!", e);
			}
			
			if(serviceInfo != null) {
				si = serviceInfo;
				services.put(svcId, serviceInfo);
			}
		}
		if(si == null) {
			log.error("Service [{}] is not exist!!", svcId);
			
			// ADMIN 서비스프로파일 테이블 서비스정보 미존재시
			AppRegistry appRegistry = APSBeanUtils.getBean(AppRegistry.class);
			
			ServiceExecutor<DefaultDTO, DefaultDTO> service = appRegistry.getService(svcId);
			
			if( service == null) {
				throw new SysException("SYSE0002", new String[] {svcId});
			}
			
			si = new ServiceInfo();
			
			String svcPackage = ClassUtils.getPackageName(service.getClass().getName());
			si.setSvcId(svcId);
			si.setSvcClass(service.getClass().getSimpleName());
			si.setSvcPkg(svcPackage);
			
			//TODO
			Service serviceAnn =  service.getClass().getAnnotation(Service.class);
			if (serviceAnn != null) {
				log.info("Service annotation [{}]", serviceAnn);
				
				if(serviceAnn.authCheck()) {
					si.setAuthReqYn("Y");
				}
				else {
					si.setAuthReqYn("N");
				}
				
			}
			
			//Annotation[] annotations = service.getClass().getDeclaredAnnotations();
			
			Method[] declaredMethods = service.getClass().getDeclaredMethods();
			for (Method method : declaredMethods) {
				
				//log.info("###############service: {} , {}, {}" , svcPackage, method.getName(),  method.getParameterTypes()[0].getName());
				
				String inType = method.getParameterTypes()[0].getName();
				String inClass = method.getParameterTypes()[0].getSimpleName();
				
				if (inType.indexOf("DefaultDTO")>-1) {
					continue;
				}
				
				if ("execute".equals(method.getName())) {
				
					si.setIoInPkg(ClassUtils.getPackageName(inType));
					si.setIoInClass(inClass);
					
				}
			}
		}
		
		return si;
		
	}
	
	public boolean removeServiceInfo(String svcId) {
		
		boolean result = false;
		if(svcId != null) {
			ServiceInfo si = services.remove(svcId);
			if(si != null) {
				log.debug("Service [{}] is removed from memory!!", svcId);
				result = true;
			}
			
		}
		return result;
	}
	
	private void loadAllAvailableServiceInfo() {
		synchronized(services) {
			
			List<ServiceInfo> svcList = new ArrayList<>();
					
			try {
				svcList = swafSession.selectList("org.swaf.admin.loadAllAvailableServices");
			}
			catch(Exception e) {
				log.warn("loadAllAvailableServiceInfo error occurred!!", e);
			}
			
			for(ServiceInfo si : svcList) {
				
				log.debug("loaded service info : {}/{}", si.getSvcId(), si.getSvcNm());
				
				services.put(si.getSvcId(), si);
			}
		}
	}
}
