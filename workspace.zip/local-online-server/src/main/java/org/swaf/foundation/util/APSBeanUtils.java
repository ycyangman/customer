package org.swaf.foundation.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * @author yonghan.lee
 *
 */

@Slf4j
@Component
public class APSBeanUtils implements ApplicationContextAware {

	private static ApplicationContext context;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		APSBeanUtils.context = applicationContext;
	}
	
	public static Object getBean (String beanName) {
		return APSBeanUtils.context.getBean(beanName);
	}
	
	public static <T> T getBean (Class<T> beanClass) {
		return APSBeanUtils.context.getBean(beanClass);
	}

	public static <T> T getBean (Class<T> beanClass, Object[] args) {
		return APSBeanUtils.context.getBean(beanClass, args);
	}
	
	public static Resource[] getResources(String location) throws Exception {
		return APSBeanUtils.context.getResources(location);
	}
	

	
	private static HashMap<String,Field> getAllSourceFields(@SuppressWarnings("rawtypes") Class klass) {
		
		HashMap<String,Field> sf = null;
		
		//Getter 가 존재하는 모든 필드를 찾는다.
		if (klass.getSuperclass()!=null) {
			sf = APSBeanUtils.getAllSourceFields(klass.getSuperclass());
		}
		
		if (sf == null) {
			sf = new HashMap<>();
		}
		
		Field[] asf = klass.getDeclaredFields();
		Method[] asm = klass.getMethods();

		for (Field field : asf) {			
			String methodName = "get" + StringUtils.capitalize(field.getName());
			for (Method method : asm) {
				if (methodName.equals(method.getName())) {
					sf.put(field.getName(), field);
					break;
				}
			}
		}

		return sf;

	}
	
	private static HashMap<String,Field> getAllTargetFields(@SuppressWarnings("rawtypes") Class klass) {
		
		HashMap<String,Field> tf = null;
		
		//Setter 가 존재하는 모든 필드를 찾는다.
		if (klass.getSuperclass()!=null) {
			tf = APSBeanUtils.getAllTargetFields(klass.getSuperclass());
		}
		
		if (tf == null) {
			tf = new HashMap<>();
		}
		
		Field[] atf = klass.getDeclaredFields();
		Method[] atm = klass.getMethods();
		for (Field field : atf) {
			String methodName = "set" + StringUtils.capitalize(field.getName());
			for (Method method : atm) {
				if (methodName.equals(method.getName())) {
					tf.put(field.getName(), field);
				}
			}
		}

		return tf;

	}
	
	public static void copyProperties(Object source, Object target) throws BeansException {
		
		HashMap<String,Field> mf = new HashMap<>();
		
		//Getter 가 존재하는 모든 필드
		HashMap<String,Field> sf = APSBeanUtils.getAllSourceFields(source.getClass());
		
		//Setter 가 존재하는 모든 필드
		HashMap<String,Field> tf = APSBeanUtils.getAllTargetFields(target.getClass());
		
		//Matching 되는 필드만 가려낸다. 
		Iterator<String> keys = sf.keySet().iterator();
		while (keys.hasNext()) {
			String key = keys.next();
			//이름와 타입이 동일한 필드가 Target 에 있는지 체크한다. 
			if (tf.get(key)!=null) {
				if (tf.get(key).getType().equals(sf.get(key).getType())) {
					//복제할 대상임
					mf.put(key, sf.get(key));
				}
			}
		}
		
		//source 에서 target 에서 복사한다. 
		keys = mf.keySet().iterator();
		String key = null;
		while (keys.hasNext()) {
			key = keys.next();
			String getter = "get" + StringUtils.capitalize(key);
			String setter = "set" + StringUtils.capitalize(key);
			try {
				Object val = source.getClass().getMethod(getter).invoke(source);
				target.getClass().getMethod(setter, mf.get(key).getType()).invoke(target, val);
				
//				if (log.isDebugEnabled()) {
//					log.debug("key {} is copied", key);
//				}
				
			} catch (Exception e) {
				log.warn (String.format("fail to copy key of %s", key));
			} 
		}
//		BeanUtils.copyProperties(source, target);
	} 
}
