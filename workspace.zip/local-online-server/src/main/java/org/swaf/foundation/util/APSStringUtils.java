package org.swaf.foundation.util;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class APSStringUtils extends StringUtils {

	public static final char[] WORD_SEPARATORS = { '_', '-', '@', '$', '#', ' ' };
	
	public static String convertToJsonString (Object object) {
		
		ObjectMapper mapper = null;
		String converted = null;
		
		try {
			mapper = APSBeanUtils.getBean(ObjectMapper.class);
			converted = mapper.writeValueAsString(object);
		} catch (Exception e) {
			log.warn("json conversion fail", e);
		}
		
		return converted;
	}

	public static <T> T convertJsonStringToObject (String raw, Class<T> type) {
		
		ObjectMapper mapper = null;
		T converted = null;
		
		try {
			mapper = APSBeanUtils.getBean(ObjectMapper.class);
			converted = mapper.readValue(raw, type);
		} catch (Exception e) {
			log.warn("fail to deserialize json string :: {}", raw, e);
		}
		
		return converted;
	}

	/**
	 * <p>
	 * 문자(char)가 단어 구분자('_', '-', '@', '$', '#', ' ')인지 판단한다.
	 * </p>
	 * 
	 * @param c
	 *            문자(char)
	 * @return 단어 구분자이면 true, 아니면 false를 반환한다.
	 */
	public static boolean isWordSeparator(char c) {
		for (int i = 0; i < WORD_SEPARATORS.length; i++) {
			if (WORD_SEPARATORS[i] == c) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * <p>
	 * 문자열(String)을 카멜표기법으로 표현한다.
	 * </p>
	 * 
	 * <pre>
	 * StringUtils.camelString("ITEM_CODE", true)  = "ItemCode"
	 * StringUtils.camelString("ITEM_CODE", false) = "itemCode"
	 * </pre>
	 * 
	 * @param str
	 *            문자열
	 * @param firstCharacterUppercase
	 *            첫문자열을 대문자로 할지 여부
	 * @return 카멜표기법으로 표현환 문자열
	 */
	public static String underbarToCamel(String str,
			boolean firstCharacterUppercase) {
		if (str == null) {
			return null;
		}

		StringBuffer sb = new StringBuffer();

		boolean nextUpperCase = false;
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);

			if (isWordSeparator(c)) {
				if (sb.length() > 0) {
					nextUpperCase = true;
				}
			} else {
				if (nextUpperCase) {
					sb.append(Character.toUpperCase(c));
					nextUpperCase = false;
				} else {
					sb.append(Character.toLowerCase(c));
				}
			}
		}

		if (firstCharacterUppercase) {
			sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
		}
		return sb.toString();
	}

	/**
	 * <p>
	 * 문자열(String)을 카멜표기법으로 표현한다.
	 * </p>
	 * 
	 * <pre>
	 * StringUtils.camelString(&quot;ITEM_CODE&quot;) = &quot;itemCode&quot;
	 * </pre>
	 * 
	 * @param str
	 *            문자열
	 * @return 카멜표기법으로 표현환 문자열
	 */
	public static String underbarToCamel(String str) {
		return underbarToCamel(str, false);
	}

	/**
	 * <p>
	 * 카멜표기법을 문자열(String)로 표현한다.
	 * </p>
	 * 
	 * <pre>
	 * StringUtils.camelString(&quot;ItemCode&quot;, true) = &quot;ITEM_CODE&quot;
	 * </pre>
	 * 
	 * @param str
	 *            카멜표기법으로 표현환 문자열
	 * @param wordSeparator
	 *            단어 사이의 문자('_','-','@','$','#',' ')
	 * @return 문자열
	 */
	public static String camelToUnderbar(String str, String wordSeparator) {
		if (str == null) {
			return null;
		}
		if (wordSeparator == null || wordSeparator.length() != 1
				|| !isWordSeparator(wordSeparator.charAt(0))) {
			wordSeparator = "_";
		}

		StringBuffer sb = new StringBuffer();
		StringBuffer upperCharBuffer = new StringBuffer();
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);

			if (Character.isUpperCase(c)) {
				upperCharBuffer.append(c);
			} else {
				if (upperCharBuffer.length() > 0) {
					for (int j = 0; j < upperCharBuffer.length(); j++) {
						if (j == 0
								|| (j == upperCharBuffer.length() - 1 && sb
										.length() > 0)) {
							sb.append(wordSeparator);
						}
						sb.append(upperCharBuffer.charAt(j));
					}
				}
				upperCharBuffer.delete(0, upperCharBuffer.length());
				sb.append(Character.toUpperCase(c));
			}
		}
		if (upperCharBuffer.length() > 0) {
			if (sb.length() > 0) {
				sb.append(wordSeparator);
			}
			sb.append(upperCharBuffer.toString());
		}

		return sb.toString();
	}

	/**
	 * <p>
	 * 카멜표기법을 문자열(String)로 표현한다.
	 * </p>
	 * 
	 * <pre>
	 * StringUtils.camelString(&quot;ItemCode&quot;, true) = &quot;ITEM_CODE&quot;
	 * </pre>
	 * 
	 * @param str
	 *            카멜표기법으로 표현환 문자열
	 * @param wordSeparator
	 *            단어 사이의 문자('_','-','@','$','#',' ')
	 * @return 문자열
	 */
	public static String camelToUnderbar(String str) {
		return camelToUnderbar(str, null);
	}
}
