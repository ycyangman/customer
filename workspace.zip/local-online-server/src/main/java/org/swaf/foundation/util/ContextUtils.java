package org.swaf.foundation.util;

import org.swaf.foundation.context.BatchApplicationContext;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.context.DefaultContext;
import org.swaf.foundation.context.OnlineApplicationContext;

/**
 * @author yonghan.lee
 *
 */
public class ContextUtils {

	public static OnlineApplicationContext getOnlineContext () {
		OnlineApplicationContext ctx = (OnlineApplicationContext)ContextContainer.get();
		return ctx;
	}
	
	public static BatchApplicationContext getBatchContext () {
		BatchApplicationContext ctx = (BatchApplicationContext)ContextContainer.get();
		return ctx;
	}

	public static DefaultContext getContext () {
		DefaultContext ctx = ContextContainer.get();
		return ctx;
	}

}
