package org.swaf.foundation.util;

import org.swaf.foundation.crypto.AESEncryptionManager;
import org.swaf.foundation.crypto.DataEncryptionManager;

public class Encryptor {
	
	public static void main (String [] args) {
		
		if (args.length > 1) {
			Encryptor enc = new Encryptor();
			enc.encrypt(args[0], args[1]);
		} else {
			System.out.println ("Usage ::: Encryptor -Dconfig.dir=[config_dir] [KeyType] [Plain text to be crypted]");
		}

	}
	
	public void encrypt (String keyType, String plainText) {
		
		DataEncryptionManager enc = new AESEncryptionManager();
		enc.init();		
		
		String crypted = enc.encrypt(plainText, keyType);
		System.out.println ("Encrypted Text ::: [" + crypted + "]");
		
		
	}

}
