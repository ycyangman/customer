package org.swaf.foundation.util;

import org.swaf.foundation.crypto.AESEncryptionManager;
import org.swaf.foundation.crypto.DataEncryptionManager;

public class KeyGenerator {
	
	public static void main (String[] args) {
		
		KeyGenerator generator = new KeyGenerator();
		
		String keyType = null;
		String seed = "appspine";
		
		if (args.length > 0) {
			keyType = args[0];
		}
		
		if (args.length > 1) {
			seed = args[1];
		}
		
		generator.execute(seed, keyType);
		
		
	}

	public void execute(String seed, String keyType) {
		
		DataEncryptionManager enc = new AESEncryptionManager();
		enc.init();		
		enc.generateKey(seed, keyType);

		System.out.println ("new key is created");
		
		
	}
	
}
