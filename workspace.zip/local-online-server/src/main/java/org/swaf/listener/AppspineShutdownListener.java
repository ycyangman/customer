package org.swaf.listener;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AppspineShutdownListener implements ApplicationListener<ContextClosedEvent> {

	@Override
	public void onApplicationEvent(ContextClosedEvent event) {
		
		if (log.isInfoEnabled()) {
			log.info("어플리케이션을 종료합니다. ");
		}
		
		
	}



}
