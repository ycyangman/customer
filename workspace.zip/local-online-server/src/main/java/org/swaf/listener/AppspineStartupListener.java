package org.swaf.listener;

import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AppspineStartupListener  implements ApplicationListener<ApplicationStartedEvent>{

	@Override
	public void onApplicationEvent(ApplicationStartedEvent event) {
		
		if (log.isInfoEnabled()) {
			log.info("어플리케이션을 시작합니다.");
		}
	}

}
