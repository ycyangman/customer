package org.swaf.processor.admin;

import lombok.Getter;

public enum ActionResult {

	SUCESS("0"), FAIL("1");
	@Getter final private String val;
	
	private ActionResult(String val) {
		this.val = val;
	}
	
}
