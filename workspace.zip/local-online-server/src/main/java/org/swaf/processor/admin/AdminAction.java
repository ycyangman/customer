package org.swaf.processor.admin;

import lombok.Getter;

public enum AdminAction {

	SERVIC_INFO_CHANGE ("1"),
	ONLINE_REFRESH ("2"),
	GET_MODIFIED_PROGRAMS ("3");
	
	@Getter final private String val;
	
	private AdminAction(String val) {
		this.val = val;
	}
}
