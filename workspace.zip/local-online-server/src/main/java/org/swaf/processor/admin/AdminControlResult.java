package org.swaf.processor.admin;

import java.util.HashMap;

import lombok.Data;

@Data
public class AdminControlResult {

	AdminAction adminAction;
	ActionResult actionResult;
	
	String svrKey;
	String resultMsg;
	HashMap<String, String> data;
	long resTs;
	
	public static AdminControlResult newResult(AdminAction adminAction, ActionResult actionResult, String msg) {
	
		AdminControlResult adminControlResult = new AdminControlResult();
		
		adminControlResult.setAdminAction(adminAction);
		adminControlResult.setActionResult(actionResult);
		adminControlResult.setResultMsg(msg);
		adminControlResult.setResTs(System.currentTimeMillis());
		
		return adminControlResult;
	}
}
