package org.swaf.processor.admin;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.swaf.app.cl.AppRegistry;
import org.swaf.das.DataSourceMap;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.service.FilterChainManager;
import org.swaf.foundation.service.ServiceManager;
import org.swaf.processor.support.log.LogLevelManager;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class AdminController 
{

	@Autowired
	PropertyManager propertyManager;
	
	@Autowired
	ObjectMapper objectMapper;
	
	@Autowired
	FilterChainManager filterChainManager;
	
	@Autowired
	ServiceManager serviceManager;
	
	@Autowired
	LogLevelManager logLevelManager;
	
	@Autowired
	AppRegistry appRegistry;
	
	@Autowired
	DataSourceMap dsMap;

	@ResponseBody
	@RequestMapping("/refresh.online")
	public AdminControlResult refreshOnline(HttpServletRequest request) {
		
		String svrKey = request.getHeader("svrKey");
		String propKey= propertyManager.getProperty("svr.key");
		
		if(StringUtils.isNotEmpty(propKey)) {
			if(!propKey.equals(svrKey)) {
				
				AdminControlResult failResult = AdminControlResult.newResult(AdminAction.ONLINE_REFRESH, ActionResult.FAIL, "Fail to check server key");
				
				log.error("Fail to check server key");
			
				return failResult;
			}
		}
		
		appRegistry.refreshAppClassLoader();
		
		Iterator<String> dbAliases = dsMap.iterAlias();
		while(dbAliases.hasNext()) {
			
			String dbAlias = dbAliases.next();
			int modifiedMappers = 0;
			String mapperResources = propertyManager.getProperty(dbAlias+".mapper.resources");
			if(StringUtils.isNotEmpty(mapperResources)) {
				
				Date baseDate = new Date(Long.parseLong(System.getProperty("startup.time")));
				if(log.isErrorEnabled()) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					
					log.debug("was refreshe at : {}", sdf.format(baseDate));
				}
				
				String[] resources = mapperResources.split("\\s*,\\s*");
				for(String resource : resources) {
					modifiedMappers += getNumOfModifiedFiles(resource, baseDate);
				}
				
			}
			
			if(modifiedMappers == 0) {
				if(log.isInfoEnabled()) {
					log.info("[{}] There is not modified mapper file", dbAlias);
				}
			}
			else {
				String sqlReloadDirective =  propertyManager.getProperty(dbAlias+".sql.reload.directive");
				
				File reloadFile = new File(sqlReloadDirective);
				
				try {
					FileUtils.touch(reloadFile);
				}
				catch(IOException e) {
					AdminControlResult failResult = AdminControlResult.newResult(AdminAction.ONLINE_REFRESH, ActionResult.FAIL
							, "Fail to reload mapper flie");
					
					log.error("[{}]Fail to reload mapper flie", dbAlias);
				
					return failResult;
				}
			}
			
			System.setProperty("startup.time", String.valueOf(System.currentTimeMillis()));
		}
		
		AdminControlResult sucessResult = AdminControlResult.newResult(AdminAction.ONLINE_REFRESH, 
				ActionResult.SUCESS, "Online applications are successfully refreshed");
		
		log.error("Fail to check server key");
	
		return sucessResult;

	}
	
	@ResponseBody
	@RequestMapping("/refresh.service")
	public AdminControlResult refreshService(HttpServletRequest request) {
		
		String svrKey = request.getHeader("svrKey");
		String propKey= propertyManager.getProperty("svr.key");
		
		if(StringUtils.isNotEmpty(propKey)) {
			if(!propKey.equals(svrKey)) {
				
				AdminControlResult failResult = AdminControlResult.newResult(AdminAction.ONLINE_REFRESH
						, ActionResult.FAIL
						, "Fail to check server key refresh service");
				
				log.error("Fail to check server key");
			
				return failResult;
			}
		}
		
		filterChainManager.getSvcManager().init();
		
		AdminControlResult sucessResult = AdminControlResult.newResult(AdminAction.ONLINE_REFRESH, 
				ActionResult.SUCESS, "Online services are successfully refreshed");
		
		log.error("Fail to check server key");
	
		return sucessResult;

	}
	
	@ResponseBody
	@RequestMapping("/refresh.loglevel")
	public String refreshLoglevel(@RequestParam Map<String, String> request) {
		
		String svcId = request.get("svcId");
		String logLevel =request.get("logLevel");
		
		if(StringUtils.isEmpty(svcId) || StringUtils.isEmpty(logLevel)) {
				
			log.error("Fail to check server key");
			
			return "fail to config log level";

		}
		
		logLevelManager.setLogLevel(request);
		
		return String.format("log level of %s is chaged %s", svcId, logLevel);

	}
	
	private int getNumOfModifiedFiles(String path, Date baseDate) {
		
		int modifiedFileCnt = 0;
		
		File dir = new File(path);
		
		if(!dir.isDirectory()) {
			return 0;
		}
		
		File[] files = dir.listFiles();
		if(files == null) {
			return 0;
		}
		
		for (File file: files) {
			if(file.isDirectory()) {
				modifiedFileCnt += getNumOfModifiedFiles(file.getAbsolutePath(), baseDate);
			}
			else if(file.isFile()) {
				if(FileUtils.isFileNewer(file, baseDate)) {
					modifiedFileCnt++;
				}
			}
		}
		
		return modifiedFileCnt;
	}
	
}
