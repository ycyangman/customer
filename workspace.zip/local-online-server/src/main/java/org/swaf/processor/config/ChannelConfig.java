package org.swaf.processor.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.swaf.foundation.property.CachedPropertyManager;
import org.swaf.processor.handler.EAIHandler;


@Configuration
public class ChannelConfig {

	
	@Bean
	public CachedPropertyManager propertyManager() {
		return new CachedPropertyManager();
	}
	
	@Bean(initMethod="init")
	public EAIHandler eaiHandler() {
		
		return new EAIHandler();
	}
	

}
