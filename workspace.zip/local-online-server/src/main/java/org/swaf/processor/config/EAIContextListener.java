package org.swaf.processor.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EAIContextListener implements ServletContextListener{

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		
		if((System.getProperty("adt.type") != null) && "WS".equals(System.getProperty("adt.type"))) 
		
		//EMSInboud.getInstance.shutdown();
		
		if(log.isInfoEnabled()) {
			log.info("Context contextDestroyed");
		}
	}
	
	 public void contextInitialized(javax.servlet.ServletContextEvent sce) {
		 
		 log.info("EAI Context contextInitialized");
		 
		 if((System.getProperty("adt.type") == null) && !"WS".equals(System.getProperty("adt.type")))  {
			 
			 log.info("check the EAI property");
			 
			 return;
		 }
			 
		 
		 
		 ServletContext sc = sce.getServletContext();
		 
		 if(sc != null) {
			 
			 if(sc.getInitParameter("EAI_RECV_CLASS") != null) {
				 
				 try {
					 Class clazz = Class.forName(sc.getInitParameter("EAI_RECV_CLASS"));
					 
					 //EMSListener listener = (EMSListener)clazz.newInstance();
					// EMSInbound.getInstance().setListener(listener);
				 }
				 catch(Exception e) {
					 log.error(e.getMessage(), e);
				 }
			 }
			 else {
				 log.info("EAI_RECV_CLASS is null");
			 }
		 }
		 else {
			 log.info("ServletContextEvent is null");
		 }
		
		 //EMSInbound.getInstance().starup();
	}
}
