package org.swaf.processor.config;

import java.io.FileNotFoundException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.TypeAliasRegistry;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.CacheManager;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import lombok.extern.slf4j.Slf4j;

import org.swaf.foundation.property.CachedPropertyManager;
import org.swaf.foundation.service.FilterChainManager;
import org.swaf.foundation.service.ServiceManager;
import org.swaf.processor.support.auth.AuthTokenManager;
import org.swaf.processor.support.fileupoad.FileUploadManager;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.app.cl.AppRegistry;
import org.swaf.das.DataSourceMap;
import org.swaf.das.DynamicSqlSessionFactoryBean;
import org.swaf.das.SqlSessionFactoryMap;
import org.swaf.das.SqlSessionTemplateMap;
import org.swaf.das.TransactionManagerMap;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.context.DASMapper;
import org.swaf.foundation.context.DasVO;
import org.swaf.foundation.context.LogLevelInfo;
import org.swaf.foundation.crypto.DataEncryptionManager;
import org.swaf.foundation.crypto.AESEncryptionManager;
import org.swaf.foundation.message.MessageManager;


@Slf4j
@Configuration
public class OnlineConfig {

	@Autowired
	ApplicationContext context;
	
	@Bean
	public CachedPropertyManager propertyManager() {
		return new CachedPropertyManager();
	}
	
	@Bean(initMethod="init")
	public ServiceManager serviceManager() {
		
		ServiceManager serviceManager = new ServiceManager();
		return serviceManager;
	}
	
	@Bean(initMethod="init")
	public FilterChainManager filterChainManager(ServiceManager serviceManager ) {
		
		FilterChainManager filterChainManager = new FilterChainManager(serviceManager);
		return filterChainManager;
	}
	
	/*
	 * 인자 이름이 빈 function과 같아야 함
	 */
	@Bean
	public CacheClient<LogLevelInfo> logLevelCacheClient(RedisTemplate<String, Object> adminRedisTemplate) {
		CacheClient<LogLevelInfo>  cacheClient = new CacheClient<LogLevelInfo>(adminRedisTemplate);
		return cacheClient;
	}
	
	@Bean(initMethod="init")
	public MessageManager messageManager() {
		return new MessageManager();
	}
	
	
	@Bean(initMethod="init", destroyMethod="destroy")
	public DataEncryptionManager dataEncryptionManager() {
		return new AESEncryptionManager();
	}
	
	
	private List<RedisNode> getRedisNodes() {
		
		PropertyManager pm = propertyManager();
		
		List<RedisNode> redisNodes = null;
		
		String cacheHosts = pm.getProperty("cache.hosts"); 
		String[] arrCacheHosts = cacheHosts.split("\\s*,\\s*");
		
		for (String cacheHost : arrCacheHosts) {
			if (redisNodes == null) {
				redisNodes = new ArrayList<>();
			}
			String[] nodeInfo = cacheHost.split("\\:");
			RedisNode redisNode = new RedisNode(nodeInfo[0], Integer.parseInt(nodeInfo[1]));
			redisNodes.add(redisNode);
		}
		
		log.info("###################################");
		log.info("redisNodes : {}", redisNodes);
		log.info("###################################");
		
		return redisNodes;
				
	}
	
	@Bean
	public RedisConnectionFactory redisConnectionFactory() {
		
		List<RedisNode> redisNodes = getRedisNodes();
		
		LettuceConnectionFactory connectionFactory = null;
		
		boolean isCluster = false;
		
		if (!isCluster) {
			if(redisNodes!=null && redisNodes.size()>0) {
				
				RedisNode redisNode = redisNodes.get(0);
				
				connectionFactory = new LettuceConnectionFactory(redisNode.getHost(), redisNode.getPort().intValue());
			}
		}
		else {
			//cluster
			RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration();
			
			redisClusterConfiguration.setClusterNodes(redisNodes);
			connectionFactory = new LettuceConnectionFactory(redisClusterConfiguration);
		}
		

		return connectionFactory;

	}
	
	@Bean
	public RedisTemplate<String, Object> adminRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.setValueSerializer(new GenericToStringSerializer<Object>(Object.class));
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		
		
		return redisTemplate;
	}
	
	@Bean
	public RedisTemplate<String, Object> appRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.setValueSerializer(new GenericToStringSerializer<Object>(Object.class));
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		
		
		return redisTemplate;
	}
	
	@Bean
	public CacheManager logLevelCacheManager(RedisConnectionFactory redisConnectionFactory) {
		
		PropertyManager pm = propertyManager();
		RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
				.serializeKeysWith(
						RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
				.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()))
				.prefixCacheNameWith("_log_").entryTtl(Duration.ofSeconds(pm.getProperty("loglevel.ttl", Long.class)))
				.disableCachingNullValues();
		
		RedisCacheManager cacheManager = RedisCacheManager.RedisCacheManagerBuilder
				.fromConnectionFactory(redisConnectionFactory).cacheDefaults(config).build();
		
		return cacheManager;
	}
	
	@Bean
	public CacheManager adminCacheManager(RedisConnectionFactory redisConnectionFactory) {
		
		RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
				.serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
				.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()))
				.prefixCacheNameWith("_admin_")
				.disableCachingNullValues();
		
		RedisCacheManager cacheManager = RedisCacheManager.RedisCacheManagerBuilder
				.fromConnectionFactory(redisConnectionFactory).cacheDefaults(config).build();
		
		return cacheManager;
	}
	
	@Bean
	@Primary
	public CacheManager appCacheManager(RedisConnectionFactory redisConnectionFactory) {
		
		PropertyManager pm = propertyManager();
		RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
				.serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
				.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()))
				.prefixCacheNameWith("_app_").entryTtl(Duration.ofSeconds(pm.getProperty("cache.ttl", Long.class)))
				.disableCachingNullValues();
		
		RedisCacheManager cacheManager = RedisCacheManager.RedisCacheManagerBuilder
				.fromConnectionFactory(redisConnectionFactory).cacheDefaults(config).build();
		
		return cacheManager;
	}
	
	@Bean(destroyMethod="destroy")
	public CacheClient<String> adminMessageCacheClient(RedisTemplate<String, Object> adminRedisTemplate) {
		
		CacheClient<String> cacheClient = new CacheClient<String>(adminRedisTemplate);
		
		return cacheClient;
	}
	
	@Bean(destroyMethod="destroy")
	public CacheClient<String> cacheClient(RedisTemplate<String, Object> appRedisTemplate) {
		
		CacheClient<String> cacheClient = new CacheClient<String>(appRedisTemplate);
		
		return cacheClient;
	}
	
	@Bean(initMethod="init", destroyMethod="destroy")
	public AppRegistry appRegistry() {
		
		AppRegistry appRegistry = new AppRegistry();
		
		return appRegistry;
	}
	
	@Bean(destroyMethod="close")
	public DataSource adminDS() {
		
		PropertyManager pm = propertyManager();
		BasicDataSource ds = new BasicDataSource();
		
		ds.setDriverClassName(pm.getProperty("admin.db.driver.class"));
		ds.setUrl(pm.getProperty("admin.db.url"));
		ds.setUsername(pm.getProperty("admin.db.username"));
		
		//ds.setPassword(pm.getDecryptedProperty("admin.db.password"));
		String dbPasswd = "";
		
		try {
			dbPasswd = pm.getDecryptedProperty("admin.db.password");
		}
		catch(Exception e) {
			log.warn("while getting app password[{}] error occurred!!", "admin.db.password");
			dbPasswd = pm.getProperty("admin.db.password");
		}
		
		ds.setPassword(dbPasswd);
		
		ds.setInitialSize(pm.getProperty("admin.db.initial.size", Integer.class));
		ds.setMaxTotal(pm.getProperty("admin.db.max.size", Integer.class));
		ds.setMaxWaitMillis(pm.getProperty("admin.db.pool.wait.millis", Integer.class));
		ds.setDefaultAutoCommit(false);

		return ds;
	}
	
	@Bean
	public DataSourceTransactionManager adminTxManager(@Qualifier("adminDS") DataSource adminDS) {
		return new DataSourceTransactionManager(adminDS);
	}
	
	@Bean
	public org.apache.ibatis.session.Configuration adminSessionConfiguration() {
		PropertyManager pm = propertyManager();
		
		org.apache.ibatis.session.Configuration conf = new org.apache.ibatis.session.Configuration();
		conf.setLazyLoadingEnabled("true".equalsIgnoreCase(pm.getProperty("admin.query.lazy.loading"))? true : false);
		conf.setMapUnderscoreToCamelCase("true".equalsIgnoreCase(pm.getProperty("admin.map.use.camelcase"))? true : false);
		conf.setDefaultFetchSize(pm.getProperty("admin.fetch.size", Integer.class));
		conf.setDefaultStatementTimeout(pm.getProperty("admin.query.timeout", Integer.class));
		
		//TODO
		TypeAliasRegistry aliasRgistry = conf.getTypeAliasRegistry();
		aliasRgistry.registerAlias("adminvo", DasVO.class);
		
		return conf;
	}
	
	@Bean
	public SqlSessionFactoryBean adminSessionFactory(@Qualifier("adminDS") DataSource adminDS
			, @Qualifier("adminSessionConfiguration") org.apache.ibatis.session.Configuration adminSessionConfiguration) {
		
		PropertyManager pm = propertyManager();
		
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		
		factoryBean.setTypeAliasesPackage("org.swaf.foundation");
		factoryBean.setDataSource(adminDS);
		
		Properties p = new Properties();
		p.setProperty("lazyLoadingEnabled", pm.getProperty("admin.query.lazy.loading"));
		p.setProperty("defaultStatementTimeout", pm.getProperty("admin.query.timeout"));
		p.setProperty("defaultFetchSize", pm.getProperty("admin.fetch.size"));
		p.setProperty("mapUnderscoreToCamelCase", pm.getProperty("admin.map.use.camelcase"));
		p.setProperty("shrinkWhitespacesInSql", String.valueOf(true));
		
		factoryBean.setConfigurationProperties(p);

		try {
			factoryBean.setMapperLocations(context.getResources("classpath:/org/swaf/sql/**/*.xml"));
			factoryBean.setConfiguration(adminSessionConfiguration);
			
			factoryBean.afterPropertiesSet();
			
			if (log.isInfoEnabled()) {
				log.info("specified sql mapper location : [{}]", "classpath:/org/swaf/sql/**/*.xml");
			}
		}
		catch (Exception e)	{
			if (log.isWarnEnabled()) {
				log.warn("fail to create sqlSession of admin");
			}
			
		}		
		
		return factoryBean;
	}
	
	//serviceManager.java ==> swafSession
	@Bean
	public SqlSessionTemplate swafSession(@Qualifier("adminSessionFactory") SqlSessionFactory adminSqlSessionFactory) {
		return new SqlSessionTemplate(adminSqlSessionFactory);
	}
	
	
	@Bean(initMethod="init", destroyMethod="closeAll")
	public DataSourceMap appDSMap() {
		
		DataSourceMap dsMap = new DataSourceMap();
		
		PropertyManager pm = propertyManager();
		
		String appdbNames = pm.getProperty("appdb.names");
		
		if(StringUtils.isEmpty(appdbNames)) {
			if(log.isWarnEnabled()) {
				log.warn(" appdbNames not found");
			}
		}
		else {
			String[] aliases = appdbNames.split("\\s*,\\s*");
			
			for(String alias : aliases) {
				BasicDataSource ds = new BasicDataSource();
				
				ds.setDriverClassName(pm.getProperty(alias+".db.driver.class"));
				ds.setUrl(pm.getProperty(alias+".db.url"));
				ds.setUsername(pm.getProperty(alias+".db.username"));
				
				String dbPasswd = "";
				
				try {
					dbPasswd = pm.getDecryptedProperty(alias+".db.password");
				}
				catch(Exception e) {
					log.warn("while getting app password[{}] error occurred!!", alias+".db.password");
					dbPasswd = pm.getProperty(alias+".db.password");
				}
				
				ds.setPassword(dbPasswd);
				ds.setInitialSize(pm.getProperty(alias+".db.initial.size", Integer.class));
				ds.setMaxTotal(pm.getProperty(alias+".db.max.size", Integer.class));
				ds.setMaxWaitMillis(pm.getProperty(alias+".db.pool.wait.millis", Integer.class));
				ds.setDefaultAutoCommit(false);
				
				dsMap.putDataSource(alias, ds);
			}
			
			String primary = pm.getProperty("appdb.primary");
			
			if (log.isInfoEnabled()) {
				log.info("primary application db alias is : [{}]", primary);
			}
			dsMap.setPrimaryDS(dsMap.getDataSource(primary));
		}
		
		return dsMap;
	}
	
	@Bean
	public TransactionManagerMap appTxManagerMap(DataSourceMap appDSMap) {
		TransactionManagerMap txManagerMap = new TransactionManagerMap();
		
		PropertyManager pm = propertyManager();
		
		Iterator<String> aliases = appDSMap.iterAlias();
		if(aliases != null) {
			while (aliases.hasNext()) {
				String alias = aliases.next();
				
				DataSourceTransactionManager txManager = new DataSourceTransactionManager(appDSMap.getDataSource(alias));
			
				txManagerMap.putTxManager(alias, txManager);
			}
			
			String primary = pm.getProperty("appdb.primary");
			if (log.isInfoEnabled()) {
				log.info("primary application db alias is : [{}]", primary);
			}
			
			txManagerMap.setPrimaryTxManager(txManagerMap.getTxManager(primary));
			
		}
		
		return txManagerMap;
	}
	
	@Bean(destroyMethod="destroyAll")
	public SqlSessionFactoryMap sqlSessionFactoryMap(DataSourceMap appDSMap) {
		SqlSessionFactoryMap sqlSessionFactoryMap = new SqlSessionFactoryMap();
		
		PropertyManager pm = propertyManager();
		
		Iterator<String> aliases = appDSMap.iterAlias();
		if(aliases != null) {
			while (aliases.hasNext()) {
				String alias = aliases.next();
				
				DynamicSqlSessionFactoryBean sqlSessionFactoryBean = sqlSessionFactory(alias, appDSMap.getDataSource(alias));
			
				sqlSessionFactoryMap.putSqlSessionFactoryBean(alias, sqlSessionFactoryBean);
			}
			
			String primary = pm.getProperty("appdb.primary");
			if (log.isInfoEnabled()) {
				log.info("primary application db alias is : [{}]", primary);
			}
			
			sqlSessionFactoryMap.setPrimarySqlSessionFactoryBean(sqlSessionFactoryMap.getSqlSessionFactoryBean(primary));
			
		}
		
		return sqlSessionFactoryMap;
	}
	
	private DynamicSqlSessionFactoryBean sqlSessionFactory(String alias, DataSource ds) {
		PropertyManager pm = propertyManager();
		
		DynamicSqlSessionFactoryBean factoryBean = null;
		
		try {
			
			factoryBean = new DynamicSqlSessionFactoryBean();
			factoryBean.setDataSource(ds);
			factoryBean.setTypeAliasesPackage("org.swaf.foundation");
			
			String mapperResources = pm.getProperty(alias+".mapper.resources");
			
			if(StringUtils.isEmpty(mapperResources)) {
				if(log.isWarnEnabled()) {
					log.warn(" mapperResources not found");
				}
				
				mapperResources = "";
			}
			
			String[] resources = mapperResources.split("\\s*,\\s*");
			Resource[] res = null;
			for(String resource : resources) {

				String mapperLocation = "file:/"+ resource +"/**/*.xml";
				
				try {
					Resource[] r = context.getResources(mapperLocation);
					res = ArrayUtils.addAll(res,r);
				}
				catch(FileNotFoundException e) {
					if(log.isWarnEnabled()) {
						log.warn(" File {} not found", mapperLocation);
					}
				}
				
				if(log.isInfoEnabled()) {
					log.info(" specified sqlmapperLocation : [{}]", mapperLocation);
				}
			}
			
			factoryBean.setMapperLocations(res);
			
			factoryBean.setSqlReloadDirective(pm.getProperty(alias+".sql.reload.directive"));
			
			Properties p = new Properties();
			p.setProperty("lazyLoadingEnabled", pm.getProperty(alias+".query.lazy.loading"));
			p.setProperty("defaultStatementTimeout", pm.getProperty(alias+".query.timeout"));
			p.setProperty("defaultFetchSize", pm.getProperty(alias+".fetch.size"));
			p.setProperty("mapUnderscoreToCamelCase", pm.getProperty(alias+".map.use.camelcase"));
			p.setProperty("shrinkWhitespacesInSql", String.valueOf(true));
			
			factoryBean.setConfigurationProperties(p);
			factoryBean.afterPropertiesSet();
			
		}
		catch(Exception e) {
			if(log.isWarnEnabled()) {
				log.warn(" fail to create sqlSessionFactory of Application", e);
			}
		}
		
		return factoryBean;
	}
	
	@Bean
	public SqlSessionTemplateMap sessionMap(SqlSessionFactoryMap sqlSessionFactoryMap) {
		
		SqlSessionTemplateMap sqlSessionTemplateMap = new SqlSessionTemplateMap();
		
		HashMap<String, DynamicSqlSessionFactoryBean> sessionFactoryMap = sqlSessionFactoryMap.getMap();
		
		PropertyManager pm = propertyManager();
		if(!ObjectUtils.isEmpty(sqlSessionFactoryMap)) {
			
			Iterator<String> aliases = sessionFactoryMap.keySet().iterator();
			while(aliases.hasNext()) {
				String alias = aliases.next();
				
				log.info("#################SqlSessionTemplateMap : [{}]", alias);
				
				SqlSessionTemplate sessionTemplate = new SqlSessionTemplate(sqlSessionFactoryMap.getSqlSessionFactoryBean(alias).getObject());
				sqlSessionTemplateMap.putSqlSessionTemplate(alias, sessionTemplate);
				
			}
			
			String primary = pm.getProperty("appdb.primary");
			if(log.isInfoEnabled()) {
				log.info(" primary application db alias is : [{}]", primary);
			}
			
			sqlSessionTemplateMap.setPrimarySqlSessionTemplate(sqlSessionTemplateMap.getSqlSessionTemplate(primary));
		}
		
		return sqlSessionTemplateMap;
	}
	
	@Bean 
	public DefaultTransactionDefinition defaultTransactionDefinition() {
	
		PropertyManager pm = propertyManager();
		
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		transactionDefinition.setTimeout(pm.getProperty("svc.default.timeout", Integer.class));
		return transactionDefinition;
	}
	
	@Bean 
	public DefaultTransactionDefinition requiresNewTransactionDefinition() {
	
		PropertyManager pm = propertyManager();
		
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
		transactionDefinition.setTimeout(pm.getProperty("svc.default.timeout", Integer.class));
		return transactionDefinition;
	}
	
	@Bean
	public DASMapper getterMapper() {
		
		DASMapper dasMapper = new DASMapper();
		
		return dasMapper;
	}
	
	@Bean
	public DASMapper setterMapper() {
		
		DASMapper dasMapper = new DASMapper();
		
		return dasMapper;
	}
	
	@Bean 
	public CommonsMultipartResolver multipartResolver() {
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
	
		multipartResolver.setMaxInMemorySize(1024);
		multipartResolver.setMaxUploadSize(100*1024*1024); //100MB
		multipartResolver.setDefaultEncoding("UTF-8");
		
		return multipartResolver;
	}
	
	@Bean(initMethod="init")
	public FileUploadManager fileUploadManager()  {
		return new FileUploadManager();
	}
	
	@Bean
	public AuthTokenManager authTokenManager(PropertyManager pm, CacheClient<String> cacheClient) {
		
		AuthTokenManager tokenManager  = new AuthTokenManager();
		tokenManager.setPm(pm);
		tokenManager.setCache(cacheClient);
		return tokenManager;
	}
}
