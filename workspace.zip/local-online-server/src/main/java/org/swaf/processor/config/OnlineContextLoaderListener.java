package org.swaf.processor.config;

import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.ServletContextEvent;

import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;

import io.netty.util.internal.InternalThreadLocalMap;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OnlineContextLoaderListener extends ContextLoaderListener {

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		
		super.contextDestroyed(event);
		
		InternalThreadLocalMap.destroy();
		Enumeration<Driver> drivers = DriverManager.getDrivers();
		while (drivers.hasMoreElements()) {
			Driver driver = drivers.nextElement();
			try {
				DriverManager.deregisterDriver(driver);
				if(log.isInfoEnabled()) {
					log.info("deregisterDriver : {}", driver);
				}
			}
			catch(SQLException e) {
				log.warn("Error deregisterDriver : {}", driver, e);
			}
		}
		
		if(log.isInfoEnabled()) {
			log.info("Context contextDestroyed");
		}
	}
	
	public OnlineContextLoaderListener() {
		super();
	}

	public OnlineContextLoaderListener(WebApplicationContext context) {
		super(context);
	}
}
