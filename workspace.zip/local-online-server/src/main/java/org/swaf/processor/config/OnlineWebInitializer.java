package org.swaf.processor.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OnlineWebInitializer implements WebApplicationInitializer{

	public void onStartup(ServletContext servletContext) throws ServletException {
		
		registerDispatcherServlet(servletContext);
		
		setStartupTime();
	}
	
	private void registerDispatcherServlet(ServletContext servletContext) {
		
		boolean eaiRequried = false;
		
		String configDir = System.getProperty("config.dir");
		if (configDir != null) {
			FileInputStream fis = null;
			
			try {
				fis = new FileInputStream(new File(configDir, "app.properties"));
				Properties p  = new Properties();
				p.load(fis);
				
				eaiRequried = "Y".equalsIgnoreCase(p.getProperty("eai.required")) ? true : false;
			}
			catch(FileNotFoundException e) {
				log.warn("app.properties file not found!!");
			}
			catch(Exception e) {
				log.warn("app.properties file reading error!!");
			}
			finally {
				try {
					fis.close();
					fis = null;
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		AnnotationConfigWebApplicationContext appContext = new AnnotationConfigWebApplicationContext();
		appContext.register(OnlineContext.class);
		servletContext.addListener(new OnlineContextLoaderListener(appContext));
		
		if(eaiRequried) {
			servletContext.setInitParameter("EAI_RECV_CLASS", "org.swaf.processor.eai.EAIListener");
			//servletContext.addListener(TomcatListener.class);
		}
		
		AnnotationConfigWebApplicationContext webContext = new AnnotationConfigWebApplicationContext();
		appContext.register(WebConfigurer.class);

		ServletRegistration.Dynamic dispatcher = servletContext.addServlet("DispatcherServlet", new DispatcherServlet(webContext));
		
		dispatcher.setLoadOnStartup(1);
		dispatcher.addMapping("/online/*");
	}
	
	private void setStartupTime() {
		System.setProperty("startup.time", String.valueOf(System.currentTimeMillis()));
	}
}

