package org.swaf.processor.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.swaf.foundation.argumentresolver.DTOArgumentResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages= {"org.swaf.processor.contoller"})
public class WebConfigurer implements WebMvcConfigurer {

	/*
	@Autowired
	DTOArgumentResolver dtoArgumentResolver;
	
	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {

		WebMvcConfigurer.super.addArgumentResolvers(resolvers);
		resolvers.add(dtoArgumentResolver);
	}
	*/
}
