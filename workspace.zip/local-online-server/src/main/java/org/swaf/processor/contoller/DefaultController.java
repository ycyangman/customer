package org.swaf.processor.contoller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.TimeZone;
import java.util.UUID;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.swaf.app.cl.AppRegistry;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.dto.DefaultHeader;
import org.swaf.foundation.dto.DefaultTrxMessage;
import org.swaf.foundation.exception.AuthException;
import org.swaf.foundation.handler.DefaultHandler;
import org.swaf.foundation.property.CachedPropertyManager;
import org.swaf.foundation.service.FilterChain;
import org.swaf.foundation.service.FilterChainManager;
import org.swaf.foundation.service.ServiceInfo;
import org.swaf.foundation.service.ServiceManager;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.processor.support.fileupoad.FileUploadManager;
import org.swaf.processor.support.fileupoad.FileUploadResult;
import org.swaf.processor.support.fileupoad.UploadFileInfo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.netty.util.internal.InternalThreadLocalMap;
import lombok.Cleanup;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class DefaultController 
{

	@Autowired
	ObjectMapper objectMapper;
	
	@Autowired
	FilterChainManager filterChainManager;
	
	@Autowired
	ServiceManager serviceManager;
	
	@Autowired
	FileUploadManager fileUploadManager;
	
	
	@Autowired
	AppRegistry appRegistry;
	
	private OnlineApplicationContext createApplicationContext(byte[] reqRawMessage) {
		
		OnlineApplicationContext ctx = null;
		
		Class<?> inType = null;
		
		JsonNode userNode = null;
		
		try {
			
			JsonNode headerNode = objectMapper.readTree(reqRawMessage).get("header");			
			DefaultHeader header = objectMapper.treeToValue(headerNode, DefaultHeader.class);
			
			ctx = new OnlineApplicationContext();
			BeanUtils.copyProperties(header, ctx) ;
			
			ctx.setCtxId("json");
			ctx.setHeader(header);
			
			String svcId = header.getSvcId();

			ServiceInfo si = serviceManager.getServiceInfo(svcId);
			
			DefaultHandler.setServiceInfoToContext(ctx, si);
			
			inType = appRegistry.getType(si.getIoInPkg()+"."+si.getIoInClass());
			
			userNode = objectMapper.readTree(reqRawMessage).get("user");
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		Object in = convert(userNode, inType);
		//Object in = convert(userNode, DefaultDTO.class);
		
		log.info("####################### in [{}] is generated!!", in);
		
		ctx.setIn(in);
		
		ContextContainer.set(ctx);
		
		//logger 에 서비스 아이디 셋팅		
		MDC.put("svcId", ctx.getSvcId());
		
		//GUID가 없을때 생성
		if(StringUtils.isEmpty(ctx.getGuid())) {
			String uuid = UUID.randomUUID().toString().replaceAll("\\-", "");
			ctx.setGuid(uuid);
			
			if(log.isInfoEnabled()) {
				log.info("new guid [{}] is generated!!", uuid);
			}
		}
		
		CachedPropertyManager pm = (CachedPropertyManager) APSBeanUtils.getBean("propertyManager");
		
		//시간정보 셋팅
		if(StringUtils.isEmpty(ctx.getTz())) {
			ctx.setTz(StringUtils.defaultString(pm.getProperty("default.timezone")));
		}
		
		SimpleDateFormat utcDateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat utcTimeFormat = new SimpleDateFormat("HHmmss");
		
		utcDateFormat.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		utcTimeFormat.setTimeZone(TimeZone.getTimeZone(ctx.getTz()));
		
		Date current = new Date();
		
		ctx.setTxDt(utcDateFormat.format(current));
		ctx.setTxBgnTm(utcTimeFormat.format(current));
		ctx.setUtcDt(utcDateFormat.format(current));
		ctx.setUtcBgnTm(utcTimeFormat.format(current));
		ctx.setProcBgnTs(current.getTime());
		
		//기타정보 셋팅
		if(StringUtils.isEmpty(ctx.getPrgNo())) {
			ctx.setPrgNo("1");
		}
		
		ctx.setPrcSqNo("0");		
		ctx.setLnkSqNo(0);
		
		//---------------------
		ContextContainer.set(ctx);
		
		MDC.put("svcId", ctx.getSvcId());
		
		return ctx;
	}
	
	
	@ResponseBody
	@RequestMapping("/json")
	public DefaultTrxMessage servcie(@RequestBody byte[] reqRawMessage, HttpServletRequest request, HttpServletResponse response) {
		
		DefaultTrxMessage dtm = new DefaultTrxMessage();
		DefaultDTO result = null;
		
		try {
			
			
			OnlineApplicationContext appCtx = createApplicationContext(reqRawMessage);
			
			if(appCtx.getUsrIpAd()==null || "".equals(appCtx.getUsrIpAd())) {
				appCtx.setUsrIpAd(request.getRemoteAddr());
			}
			
			log.info("################service calling :: {}", appCtx);
			
			FilterChain fc = filterChainManager.newFilterChain("json::"+appCtx.getSysEnvDscd(), appCtx.getSvcId());
			
			fc.execute();
			result = appCtx.getOut();
			
			result.setPgSq(appCtx.getPgSq());
			result.setPgSz(appCtx.getPgSz());
			result.setPgHasNext(appCtx.getPgHasNext());
			result.setPgResultCount(appCtx.getPgResultCount());
			result.setTotalCount(appCtx.getTotalCount());
			
			dtm.setUser(result);
			
		}
		catch(AuthException e) {
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			log.error("fail to Auth", e);
		}
		catch(Exception e) {
			log.error("fail to execute service", e);
		}
		finally {
			dtm.setHeader(DefaultHandler.createHeaderFromContext());
			ContextContainer.unset();
			InternalThreadLocalMap.destroy();
		}
		
		log.info("dtm::::::::{}", dtm.getHeader());
		
		return dtm;
	}
	
	
	@ResponseBody
	@RequestMapping("/doUpload")
	public FileUploadResult doUpolad(MultipartHttpServletRequest request, HttpServletResponse response) {
		
		String bizKind = request.getParameter("bizKind");
		Iterator<String> fileNames = request.getFileNames();
		
		String resutMessage = null;
		FileUploadResult result = new FileUploadResult();
		
		try {
		
			ArrayList<UploadFileInfo> uploadFiles = null;
			if(!ObjectUtils.isEmpty(fileNames)) {
				
				while(fileNames.hasNext()) {
				
					if(uploadFiles == null) {
						uploadFiles = new ArrayList<>();
					}
					UploadFileInfo uploadFile = fileUploadManager.saveTempFile(request.getFile(fileNames.next()), 
							StringUtils.getIfEmpty(bizKind, ()-> "tmp"));
					uploadFiles.add(uploadFile);
				}
			}
			
			result.setResultMeessage("files uploaded sucessfully!!");
			if (!ObjectUtils.isEmpty(uploadFiles)) {
				result.setFiels(uploadFiles.toArray(new UploadFileInfo[uploadFiles.size()]));
			}
			response.setStatus(HttpServletResponse.SC_OK);
		}
		catch(Exception e) {
			if(StringUtils.isEmpty(resutMessage)) {
				log.error("fail to upload files", e);
				result.setResultMeessage("fail to upload files");
				response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			}
			else {
				log.error("fail to upload files", e);
				result.setResultMeessage("fail to upload files");
			}
		}

		return result;
		
	}
	
	@RequestMapping("/doDownload")
	public void doDownload(HttpServletRequest request, HttpServletResponse response) {
		
		String fileId     = request.getParameter("fileId");
		String realFileNm = request.getParameter("realFileNm");
		
		
		try {
		
			File beDownloaded = fileUploadManager.getFile(fileId);
			
			response.setCharacterEncoding("UTF-8");
			response.setContentLength((int)beDownloaded.length());
//			response.setContentType("text/plain");
			response.setContentType("application/octet-stream");
					
			String str = "attachment;filename=";
			str += URLEncoder.encode(realFileNm, "UTF-8");
			response.setHeader("Content-Disposition", str);
			
			@Cleanup
			FileInputStream fis = new FileInputStream(beDownloaded);
			ServletOutputStream out = response.getOutputStream();
			
			byte[] buf = new byte[1024];
			int len = 0;
			while ((len = fis.read(buf, 0, buf.length)) != -1) {
				out.write(buf, 0, len);
			}
			out.flush();
			response.setStatus(HttpServletResponse.SC_OK);
			out.close();

		}
		catch(Exception e) {
			log.error("fail to upload files", e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		
			try {
				response.getOutputStream().write(e.getMessage().getBytes("UTF-8"));
			}catch(IOException ioe) {
				ioe.printStackTrace();
			}
		}
		

		return;
		
	}
	
	
	private <T> T convert(JsonNode jn, Class<T> type) {
		T in = null;
		
		try {
			in = objectMapper.treeToValue(jn, type);
		}
		catch(JsonProcessingException e) {
			e.printStackTrace();
		}
		return in;
	}
	
}
