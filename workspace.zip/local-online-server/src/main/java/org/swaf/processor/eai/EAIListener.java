package org.swaf.processor.eai;

import org.swaf.processor.handler.EAIHandler;

import io.netty.util.internal.InternalThreadLocalMap;

import org.swaf.eai.EAIStandardMessage;
import org.swaf.eai.EAIMessageFactory;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.service.FilterChain;
import org.swaf.foundation.service.FilterChainManager;
import org.swaf.foundation.util.APSBeanUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//public class EAIListener implements EMSListener{

public class EAIListener{
	
	EAIHandler eAIHandler; 
	
	FilterChainManager filterChainManager;
	
	public EAIListener( ) {
		eAIHandler = APSBeanUtils.getBean(EAIHandler.class);
		filterChainManager = APSBeanUtils.getBean(FilterChainManager.class);
	}
	
	//@Override
	public byte[] onMsg(byte[] message) {
		
		EAIStandardMessage<DefaultDTO> em = new EAIStandardMessage<>();
		
		DefaultDTO result = null;
		
		try {
			
			OnlineApplicationContext ctx = eAIHandler.createAppContext(message);
			FilterChain fc = filterChainManager.newFilterChain("eai::"+ ctx.getSysEnvDscd(), ctx.getSvcId());
			
			fc.execute();
			
			result = ctx.getOut();
			
			em.setUser(result);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			em.setHeader(null);
		
			ContextContainer.unset();
			InternalThreadLocalMap.destroy();
		}
		
		return EAIMessageFactory.toBytes(em);
	}
}
