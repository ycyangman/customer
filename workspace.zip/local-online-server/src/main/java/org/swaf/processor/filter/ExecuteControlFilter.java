package org.swaf.processor.filter;

import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.service.Filter;
import org.swaf.foundation.util.ContextUtils;

public class ExecuteControlFilter extends Filter<DefaultDTO, DefaultDTO> {

    public DefaultDTO execute(DefaultDTO in) {

    	OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
    	
    	return null;

    	
    }
}
