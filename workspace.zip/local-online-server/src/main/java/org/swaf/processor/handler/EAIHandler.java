package org.swaf.processor.handler;

import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.swaf.app.cl.AppRegistry;
import org.swaf.foundation.context.ContextContainer;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultHeader;
import org.swaf.foundation.handler.DefaultHandler;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.service.IServiceManager;
import org.swaf.foundation.service.ServiceInfo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EAIHandler extends DefaultHandler{

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	IServiceManager serviceManager;
	
	@Autowired
	AppRegistry appRegistry;
	
	@Autowired
	PropertyManager pm;
	
	public void init() {
		System.setProperty("sysid", pm.getProperty("eai.sys.id"));
		System.setProperty("eai.hub.emsurl", pm.getProperty("eai.hub.emsurl"));
		System.setProperty("eai.daemon.count", pm.getProperty("eai.daemon.count"));
		
	}
	
	public OnlineApplicationContext createAppContext(byte[] reqRawMessage) {
		
		OnlineApplicationContext ctx = null;
		
		Class<?> inType = null;
		
		JsonNode userNode = null;
		
		try {
			
			JsonNode headerNode = objectMapper.readTree(reqRawMessage).get("header");			
			DefaultHeader header = objectMapper.treeToValue(headerNode, DefaultHeader.class);
			
			ctx = new OnlineApplicationContext();
			BeanUtils.copyProperties(header, ctx) ;
			
			ctx.setCtxId("eai");
			ctx.setHeader(header);
			
			String svcId = header.getSvcId();

			ServiceInfo si = serviceManager.getServiceInfo(svcId);
			
			DefaultHandler.setServiceInfoToContext(ctx, si);
			
			inType = appRegistry.getType(si.getIoInPkg()+"."+si.getIoInClass());
			
			userNode = objectMapper.readTree(reqRawMessage).get("user");
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		Object in = convert(userNode, inType);
		//Object in = convert(userNode, DefaultDTO.class);
		
		log.info("####################### in [{}] is generated!!", in);
		
		ctx.setIn(in);
		
		ContextContainer.set(ctx);
		//logger 에 서비스 아이디 셋팅		
		MDC.put("svcId", ctx.getSvcId());
		
		return ctx;
	}
	
	
	private <T> T convert(JsonNode jn, Class<T> type) {
		T in = null;
		
		try {
			in = objectMapper.treeToValue(jn, type);
		}
		catch(JsonProcessingException e) {
			e.printStackTrace();
		}
		return in;
	}
	
}
