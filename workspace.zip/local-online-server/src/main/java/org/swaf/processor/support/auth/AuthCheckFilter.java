package org.swaf.processor.support.auth;

import org.apache.commons.lang3.StringUtils;
import org.swaf.foundation.auth.AuthToken;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.exception.SysException;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.service.Filter;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.APSStringUtils;
import org.swaf.foundation.util.ContextUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * refer to FilterChainManager.loadFilterDefinitions
 * 
 * @author 
 *
 */

@Slf4j
public class AuthCheckFilter extends Filter<DefaultDTO, DefaultDTO> {

	CacheClient<String> cacheClient = null;
	PropertyManager pm = null;
	
	@SuppressWarnings("unchecked")
	@Override
    public DefaultDTO execute(DefaultDTO in) {

		log.info("#############AuthCheckFilter executing #############");
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		if(cacheClient == null) {
			cacheClient = (CacheClient<String>)APSBeanUtils.getBean("cacheClient");
		}
		
		if(pm == null) {
			pm = APSBeanUtils.getBean(PropertyManager.class);
		}
    	
		if(!"Y".equals(ctx.getAuthReqYn())) {
			return null;
		}
		
		String authToken = ctx.getAuthToken();
		
		log.info("#############AuthCheckFilter authToken::{} #############", authToken);
		
		if( StringUtils.isEmpty(authToken)) {
			throw new SysException("SYSE0004");
		}
		else {
			
			if(!verifyAuthToken(authToken)) {
				throw new SysException("SYSE0008");
			}
			else {
				String redisKey = String.format("authtoken.%s.%s.%s", ctx.getSysEnvDscd(), ctx.getUsrId(), authToken); 
				cacheClient.setExpire(redisKey, Long.parseLong(pm.getProperty("login.keep.peroid")));
			}
		}

    	return null;

    }

	
	private boolean verifyAuthToken(String authTokenVl) {
	
		// redis key 형식 : authtoken.시스템환경구분코드.사용자ID.토큰ID
		boolean result = false;
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		String redisKey = String.format("authtoken.%s.%s.%s", ctx.getSysEnvDscd(), ctx.getUsrId(), authTokenVl);
		AuthToken authToken = APSStringUtils.convertJsonStringToObject(cacheClient.get(redisKey, String.class), AuthToken.class);
		
		if(authToken != null) {
			if("fasle".equalsIgnoreCase(pm.getProperty("multi.login.allow"))) {
				if(authToken.getUsrIpAd().equals(ctx.getUsrIpAd())) {
					result = true;
				}
			}
			else {
				result = true;
			}
		}
		return result;
	}

}
