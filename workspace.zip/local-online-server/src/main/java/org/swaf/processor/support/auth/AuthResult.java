package org.swaf.processor.support.auth;

import lombok.Getter;

/**
 * 처리결과
 *
 */
public enum AuthResult {

	OK(0), NOT_EXISTS(1), WRONG_PW(2), EXCEEED_ERR_COUNT(3) ;
	
	@Getter final private int val;

	private AuthResult (int val) {
		this.val = val;
	}	
	
}
