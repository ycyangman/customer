package org.swaf.processor.support.auth;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.ObjectUtils;
import org.swaf.foundation.auth.AuthToken;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.util.APSStringUtils;
import org.swaf.foundation.util.ContextUtils;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AuthTokenManager {

	public static final String AUTH_TOKEN_TAG = "%s.%s.%s.%s";
	
	@Setter
	PropertyManager pm;
	
	@Setter
	CacheClient<String> cache;

	public AuthToken issueToken(String usrId) {
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		return issueToken(usrId,  ctx.getUsrIpAd());
		
	}
	
	
	public AuthToken issueToken(String usrId, String userIpAd) {
		
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		String tokenId = UUID.randomUUID().toString();
		
		String redisKey = String.format(AUTH_TOKEN_TAG,  "authtoken", ctx.getSysEnvDscd(), usrId, tokenId);
		
		AuthToken authToken = new AuthToken();
		
		authToken.setTokenId(tokenId);
		authToken.setLoginTs(new Timestamp(System.currentTimeMillis()));
		authToken.setUsrId(usrId);
		authToken.setUsrIpAd(userIpAd);
		
		cache.put(redisKey, APSStringUtils.convertToJsonString(authToken), Long.parseLong(pm.getProperty("login.keep.period")));
		
		ctx.setAuthToken(tokenId);
		
		return authToken;
		
	}
	
	public AuthToken getAuthToken(String usrId, String authTokenId) {
		
		AuthToken authToken = null;
		
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		String redisKey = String.format(AUTH_TOKEN_TAG,  "authtoken", ctx.getSysEnvDscd(), usrId, authTokenId);
		String redisVal  = cache.get(redisKey, String.class);
		
		if(redisVal != null) {
			authToken = APSStringUtils.convertJsonStringToObject(redisVal, AuthToken.class);
		}
		
		return authToken;
	}
	

	public AuthToken getAuthToken(String usrId) {
		
		AuthToken authToken = null;
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		String redisKey = String.format("%s.%s.%s.*",  "authtoken", ctx.getSysEnvDscd(), usrId);
		Set<String> keys  = cache.getKeys(redisKey);
		
		
		if(!ObjectUtils.isEmpty(keys)) {
			
			Iterator<String> keyItr = keys.iterator();
			String key = keyItr.next();
			String authTokenStr = cache.get(key, String.class);
			if(authTokenStr !=null) {
				authToken =  APSStringUtils.convertJsonStringToObject(authTokenStr, AuthToken.class);
			}
		}
		
		return authToken;
	}
	
	public boolean delToken(String usrId) {
		
		boolean result = false;
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		String redisKey = String.format("%s.%s.%s.*",  "authtoken", ctx.getSysEnvDscd(), usrId);
		Set<String> keys  = cache.getKeys(redisKey);
		
		if(!ObjectUtils.isEmpty(keys)) {
			
			for(String key: keys) {
				cache.delete(key);
			}
			result = true;
		}
		
		return result;
	}
	
	/**
	 * 인증토큰의 Time-To-Live 의 시간을 셋팅
	 * 
	 * @param authToken
	 * @param ttlSeconds
	 * @return
	 */
	public boolean setTTL(AuthToken authToken, long ttlSeconds) {
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		String redisKey = String.format(AUTH_TOKEN_TAG,  "authtoken", ctx.getSysEnvDscd(), authToken.getUsrId(), authToken.getTokenId());
		
		cache.setExpire(redisKey, ttlSeconds);
		
		return true;
	}
	
}
