package org.swaf.processor.support.auth;

import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.exception.AuthException;
import org.swaf.foundation.service.Filter;
import org.swaf.foundation.util.ContextUtils;

public class RoleCheckFilter extends Filter<DefaultDTO, DefaultDTO> {


    public DefaultDTO execute(DefaultDTO in) {

    	OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
    	
    	if( (ctx.getAccRoles() & ctx.getAccRoles()) == 0L) {
    		
    		//실행권한없
    		
    		throw new AuthException("SYSE0010");
    	}
    	return null;

    	
    }



}
