package org.swaf.processor.support.fileupoad;


import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import lombok.Cleanup;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.util.APSBeanUtils;
@Slf4j
public class FileUploadManager {

	SimpleDateFormat dateFormat = null;
	PropertyManager pm = null;
	
	public void init() {
		this.dateFormat = new SimpleDateFormat("yyyyMMdd");
		this.pm = APSBeanUtils.getBean(PropertyManager.class);
	}
	
	public UploadFileInfo saveTempFile(MultipartFile mf, String bizKnd) {
		
		UploadFileInfo fileInfo = null;
		
		if(mf == null) {
			return fileInfo;
		}
		
		try {
			fileInfo = new UploadFileInfo();
			String realFileNm = mf.getOriginalFilename();
			fileInfo.setRealFileNm(realFileNm);
			fileInfo.setFileSize(mf.getSize());
			fileInfo.setFileBizKnd(bizKnd);
			
			if(realFileNm.contains(".")) {
				String extNm = realFileNm.substring(StringUtils.lastIndexOf(realFileNm, ".")+1);
				if(StringUtils.isNotEmpty(extNm)){
					fileInfo.setExtNm(extNm.toUpperCase(Locale.ENGLISH));
				}
			}
			
			long currentTs = System.currentTimeMillis();
			String prefix = dateFormat.format(new Date(currentTs));
			String fileId = String.format("%s_%s_%s", bizKnd, prefix, UUID.randomUUID().toString().replaceAll("\\-", "")).toLowerCase();
			
			
			//파일저장
			File dir = new File(pm.getProperty("file.upload.dir")+"/tmp");
			if(!dir.exists()) {
				FileUtils.forceMkdir(dir);
			}
			
			@Cleanup FileOutputStream fos = new FileOutputStream(new File(dir, fileId));
			fos.write(mf.getBytes());
			fos.flush();
			
			fileInfo.setFileId(fileId);
			fileInfo.setCurrentTs(currentTs);
			
					
		}
		catch(Exception e) {
			log.error("fail to save file",e);
		}
		return fileInfo;
		
	}
	
	public boolean persistUploadFile(String fileId) throws Exception {
		boolean result = false;
		
		if(fileId == null) {
			log.warn("fileId should not empty : {}", fileId);
			
			return result;
		}
		
		try {
			File destDir = getPersistDir(fileId);
			File tmpFile = new File(pm.getProperty(pm.getProperty("file.upload.dir")+"/tmp"), fileId);
			FileUtils.moveToDirectory(tmpFile, destDir, true);
			result = true;
			
		}
		catch(Exception e) {
			log.error("fail to persistUpload file",e);
			throw e;
		}
		
		return result;
		
	}

	public File getFile(String fileId) {
		File file = null;
		if(fileId != null) {
			
			file = new File(getPersistDir(fileId), fileId);
		}
		return file;
	}
	
	
	private File getPersistDir(String fileId) {
		
		File dir = null;
		if(fileId != null) {
			
			String[] fileTokens = fileId.split("\\_");
			String fileUploadDir = String.format("%s/%s/%s", pm.getProperty("file.upload.dir")
					, fileTokens[0]    //업무구분
					, fileTokens[1]);  //yyyymmdd

			dir = new File(fileUploadDir);
		}
		
		return dir;

		
	}
	
}
