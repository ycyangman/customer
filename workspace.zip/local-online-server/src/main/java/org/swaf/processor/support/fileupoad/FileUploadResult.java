package org.swaf.processor.support.fileupoad;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class FileUploadResult {

	
	UploadFileInfo[] fiels;
	
	String resultMeessage;
}
