package org.swaf.processor.support.fileupoad;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class UploadFileInfo {

	String fileId;
	String fileBizKnd;
	String realFileNm;
	String extNm;
	
	long fileSize;
	long currentTs;
}
