package org.swaf.processor.support.log;


import org.slf4j.MDC;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.property.PropertyManager;
import org.swaf.foundation.service.Filter;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.ContextUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ApplicationLogFilter extends Filter<DefaultDTO, DefaultDTO> {

	public DefaultDTO execute (DefaultDTO in) {
		
		PropertyManager pm = APSBeanUtils.getBean(PropertyManager.class);
		LogLevelManager lm = APSBeanUtils.getBean(LogLevelManager.class);
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		String svcId = ctx.getSvcId();
		LogLevelInfo logLevel = lm.getLogLevel(svcId);
		if (logLevel != null) {
			
			//String userNo = logLevel.getUserNo();
			//String ipAd= logLevel.getIpAd();
			
			setLogLevel(logLevel);
		}
		else {
			setLogLevel(pm.getProperty("svc.log.level"));
		}
		
		return null;
	}
	
	private void setLogLevel(String logLevel) {
		MDC.put("svc.log.level", logLevel);
	}
	
	private void setLogLevel(LogLevelInfo logLevel) {
		MDC.put("svc.log.level", logLevel.getLogLevel());
	}
	
}
