package org.swaf.processor.support.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.util.ContextUtils;

public class LogFilter {

	private static Logger log = LoggerFactory.getLogger("txLog");
	
	public DefaultDTO execute (DefaultDTO in) {
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		if(log.isInfoEnabled()) {
			log.info("{}", ctx.toString());
		}
		return null;
	}
}
