package org.swaf.processor.support.log;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.swaf.foundation.cache.CacheClient;
import org.swaf.foundation.property.PropertyManager;

public class LogLevelManager {

	@Autowired
	@Qualifier("logLevelCacheClient")
	CacheClient<LogLevelInfo> cache;
	
	@Autowired
	PropertyManager pm;
	
	public void setLogLevel(Map<String, String> param) {
		
		LogLevelInfo logLevelInfo = new LogLevelInfo();
		
		logLevelInfo.setSvcId(param.get("svcId"));
		logLevelInfo.setLogLevel(param.get("logLevel"));
		logLevelInfo.setUserNo(param.get("userNo"));
		logLevelInfo.setIpAd(param.get("ipAd"));
		
		saveToCache(logLevelInfo);
	}
	
	public LogLevelInfo getLogLevel(String svcId) {
		LogLevelInfo logLevelInfo = cache.get("loglevel."+svcId, LogLevelInfo.class);
		
		return logLevelInfo;
	}
	
	private void saveToCache(LogLevelInfo logLevelInfo) {
		cache.put("loglevel."+logLevelInfo.getSvcId() , logLevelInfo, pm.getProperty("loglevel.ttl", Long.class));
	}
}
