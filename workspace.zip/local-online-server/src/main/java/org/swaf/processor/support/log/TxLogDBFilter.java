package org.swaf.processor.support.log;

import org.swaf.app.cl.AppRegistry;
import org.swaf.das.SqlSessionTemplateMap;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.service.Filter;
import org.swaf.foundation.service.FilterChainManager;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.ContextUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TxLogDBFilter extends Filter<DefaultDTO, DefaultDTO> {

	
	AppRegistry appRegistry;
	
	public DefaultDTO execute (DefaultDTO in) {

		if(appRegistry == null) {
			appRegistry = APSBeanUtils.getBean(AppRegistry.class);
		}
		
		log.debug("TxLogDBFilter starting");
		
		//TxLogManager txLogManager = appRegistry.getAppObject("kr.ezinsurance.sample.bm.TxlogManager", TxLogManager.class);
		//txLogManager.writeLog();
		
		return null;
	}
	
}
