package kr.ezinsurance;

import org.swaf.batch.runner.DefaultJobRunner;

/*
 * 
 * -Dbatch.config.dir=D:/eclipse/workspace/sample-batch JCM001 filename=users.csv 11
 * 
 */
public class JobRunner extends DefaultJobRunner {
	
	public static void main(String args[]) {
		
		JobRunner runner = new JobRunner();
		
		runner.runJob(args);
	}
	
}
