package kr.ezinsurance.sample.bean;

import java.util.Iterator;
import java.util.List;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Scope("step")
public class CM001BEAN implements ItemReader<Object>, ItemProcessor<Object, String>, ItemWriter<String>, ItemStream {

	private SqlSessionFactory sqlSessionFactory;
	private SqlSession sqlSession;
	private JobParameters jobParameters;
	private String pgmId;
	
	private int readCount = 0;
	private int skipCount = 0;
	private int errorCount = 0;
	private int writeCount = 0;
	
	//below developer area-----------------------------------------
	
	private Iterator<?> mainIt = null;
	
	public CM001BEAN(SqlSessionFactory sqlSessionFactory) {
		this.sqlSessionFactory = sqlSessionFactory;
	}
	
	@Override
	public void open(ExecutionContext context) throws ItemStreamException {
		
		log.info("=============CM001BEAN {}==================");

		log.info("====================================");
		
		sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH);
		
//		sqlSession.select
		
		//mainIt = DBCall;
	}
	
	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		
		log.info("beforeStep called");
		
		jobParameters = stepExecution.getJobExecution().getJobParameters();
		log.info("jobParameters : {}", jobParameters.getParameters());
		
		if(jobParameters != null) {
			pgmId = jobParameters.getString("jobName");
		}
		
	}

	@Override
	public Object read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		Object input = null;
		if(this.mainIt!=null && this.mainIt.hasNext()) {
			input = (Object)mainIt.next();
		}
		else {
			return null;
		}
		return input;
	}

	@Override
	public String process(Object input) throws Exception {
		
		readCount++;
	
		return null;
	}
	

	@Override
	public void update(ExecutionContext context) throws ItemStreamException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void write(List<? extends String> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@AfterStep
	public void afterStep(StepExecution stepExecution) {
		log.info("beforeStep called ; {}", stepExecution.getExitStatus());
		
		ExitStatus exitStatus = stepExecution.getExitStatus();
		
		/*
		if (exitStatus == ExitStatus.COMPLETED) {
			
		}
		*/
		
	}
	
	@Override
	public void close() throws ItemStreamException {

		log.info("=============CM001BEAN {}==================");
		
		log.info("===============================");
		log.info("READ 건수 : {}", readCount);
		log.info("SKIP 건수 : {}", skipCount);
		log.info("ERROR 건수: {}", errorCount);
		log.info("WRITE 건수: {}", writeCount);
		log.info("===============================");
		
	}

	private void batchLogeer(String dvsxn) {
		//TODO
		
	}
	
}
