package kr.ezinsurance.sample.job;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.batch.MyBatisPagingItemReader;
import org.mybatis.spring.batch.builder.MyBatisPagingItemReaderBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.swaf.batch.prototype.SwafBatchJob;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import kr.ezinsurance.sample.bean.CM001BEAN;


@Configuration
public class JCM001 extends SwafBatchJob {

	@Autowired
	@Qualifier("sqlSessionFactory")
	SqlSessionFactory sqlSessionFactory;
	
	final String jobId = "JCM001B";
	
	@Bean(name=jobId) 
	public Job job() {
		Step step1 = step1();
		Job job = getJobBuilder(jobId).start(step1).build();
		
		return job;
	}
	
	@Bean
	protected Step step1() {
		ItemReader<Object> itemReader = reader(null);
		ItemProcessor<Object, String> itemProcessor = processor();
		
		ItemWriter<Object> itemWriter = writer(null);
		
		CM001BEAN stream = new CM001BEAN(sqlSessionFactory);
		
		return getStepBuilder("step1").<Object, String> chunk(10).reader(stream).processor(stream).writer(stream).build();
		
		
		//return getStepBuilder("step1").<Object, String> chunk(10).reader(itemReader).processor(itemProcessor).writer(itemWriter).build();
		
		
	}
	
	@Bean
	@JobScope
	protected MyBatisPagingItemReader<Object> reader(@Value("#{jobExecution}") JobExecution jobExecution ) {

		MyBatisPagingItemReader<Object> itemReader = new MyBatisPagingItemReaderBuilder<>()
				.pageSize(10)
				.sqlSessionFactory(sqlSessionFactory)
				.queryId("kr.ezinsurance.sql.getAllUsers")
				.build();
		
		return itemReader;
		
	}
	
	@Bean
	@JobScope
	protected ItemProcessor<Object, String> processor() {

		ItemProcessor<Object, String> itemProcessor = new ItemProcessor<>() {

			@Override
			public String process(Object item) throws Exception {
				return null;
			}
		};
		return itemProcessor;
		
	}
	
	@Bean
	@JobScope
	public FlatFileItemWriter<Object> writer(@Value("#{jobParameters[filename]}") String filename) {

		FlatFileItemWriter<Object> itemWriter = new FlatFileItemWriter<>();

		


			
		return itemWriter;
		
	}
}
