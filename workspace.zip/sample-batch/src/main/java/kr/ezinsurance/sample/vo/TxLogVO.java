package kr.ezinsurance.sample.vo;


import org.swaf.foundation.context.DefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class TxLogVO extends DefaultVO{

	String guid;
	String lnkSqNo;
	String prgNo;
	String prcSqNo;
	String lnkSvcDscd;
	String ctxId;
	String svcId;
	String sysEvnDscd;
	String svcNm;
	String scrnNo;
	String txDt;
	String txBgnTm;
	String txEndTm;
	int    procPd;
	String usrNo;
	String usrIpAd;
	String msgCd;
	String bascMsg;
	String adMsg;
	String exTraces;
	
}
