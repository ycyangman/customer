package kr.ezinsurance.misc;

import org.swaf.app.cl.AppRegistry;
import org.swaf.foundation.dto.DefaultDTO;
import org.swaf.foundation.service.Filter;
import org.swaf.foundation.util.APSBeanUtils;

import kr.ezinsurance.sample.bm.TxLogManager;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TxLogDBFilter extends Filter<DefaultDTO, DefaultDTO> {

	
	AppRegistry appRegistry;
	
	public DefaultDTO execute (DefaultDTO in) {

		if(appRegistry == null) {
			appRegistry = APSBeanUtils.getBean(AppRegistry.class);
		}
		
		log.debug("TxLogDBFilter starting");
		
		TxLogManager txLogManager = appRegistry.getAppObject("kr.ezinsurance.sample.bm.TxLogManager", TxLogManager.class);
		
		txLogManager.writeLog();
		
		return null;
	}
	
}
