package kr.ezinsurance.sample.bm;

import org.swaf.foundation.crypto.KeyType;
import org.swaf.foundation.prototype.BizModule;
import org.swaf.processor.support.auth.AuthResult;

import kr.ezinsurance.sample.vo.UserVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoginManager extends BizModule {

	
	public AuthResult checkAuthById(String usrId, String usrPw) {
		
		
		String cryptedPw = crypto.encrypt(usrPw, "SWAF");
		
		log.debug("##########cryptedPw##############", cryptedPw);
		
		//사용자 정보조회 생략
		
		UserVO user = new UserVO();
		/*
		if(user == null) {
			return AuthResult.NOT_EXISTS;
		}
		
		if(user.getPwErrCnt() > pm.getProperty("login.err.count.limit", Integer.class)) {
			return AuthResult.EXCEEED_ERR_COUNT;
		}
		
		String crypted = String.format("{%s}%s", KeyType.PASSWORD.getVal(), crypto.encrypt(usrPw, KeyType.PASSWORD.getVal()));
		
		if(!crypted.equals(user.getUsrPw())) {
			return AuthResult.WRONG_PW;
		}
		*/
		return AuthResult.OK;
	}
	
}
