package kr.ezinsurance.sample.bm;

import org.springframework.beans.BeanUtils;
import org.springframework.transaction.TransactionStatus;
import org.springframework.util.ObjectUtils;
import org.swaf.foundation.annotation.DM;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.prototype.BizModule;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.ContextUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.ezinsurance.sample.dm.TxLogDM;
import kr.ezinsurance.sample.vo.TxLogVO;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TxLogManager extends BizModule  {

	ObjectMapper mapper;
	
	@Setter
	@DM
	TxLogDM txLogDM;
	
	public boolean writeLog() {
	
		boolean result = false;
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		TxLogVO txLogVo = new TxLogVO();
		BeanUtils.copyProperties(ctx, txLogVo);
		
		if(mapper == null) {
			mapper = APSBeanUtils.getBean(ObjectMapper.class);
		}
		
		if(!ObjectUtils.isEmpty(ctx.getExTraces())) {
			try {
				txLogVo.setExTraces(mapper.writeValueAsString(ctx.getExTraces()));				
			}
			catch(Exception e) {
				log.warn(e.getMessage(), e);
			}
		}
		
		TransactionStatus txStatus = beginRequiresNewTx();
		
		try {
			txLogDM.insertTxLog(txLogVo);
			endRequiresNewtTxWithCommit(txStatus);
			
			result = true;
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(!txStatus.isCompleted()) {
				endRequiresNewtTxWithRollback(txStatus);
			}
		}
		
		return result;
	}
}
