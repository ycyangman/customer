package kr.ezinsurance.sample.bm;

import java.util.List;

import org.swaf.foundation.annotation.DM;
import org.swaf.foundation.prototype.BizModule;

import kr.ezinsurance.sample.dm.UserDM;
import kr.ezinsurance.sample.vo.UserInfo;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserInfoMgrBM extends BizModule {

	@Setter
	@DM
	UserDM userDM;
	
	public List<UserInfo> getUserInfo(String usrId) {
	
		//userDM.selectMetaInfo();
		
		List<UserInfo> userList = userDM.selectUserList(usrId);
		
		return userList;
		
	}

}
