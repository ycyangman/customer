package kr.ezinsurance.sample.dm;

import org.swaf.foundation.context.DasVO;
import org.swaf.foundation.prototype.DasModule;

import kr.ezinsurance.sample.vo.TxLogVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TxLogDM extends DasModule{
	
	public int insertTxLog(TxLogVO txLogVO) {

		DasVO<TxLogVO> txLog = new DasVO<>();
		txLog.putParam(txLogVO, TxLogVO.class);
		
		try {
			return sqlSession.insert("kr.ezinsurance.sample.insertTxLog", txLog);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
		
	}

	
}
