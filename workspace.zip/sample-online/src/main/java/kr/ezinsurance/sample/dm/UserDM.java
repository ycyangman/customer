package kr.ezinsurance.sample.dm;

import java.util.List;

import org.swaf.biz.util.FwUtil;
import org.swaf.das.sql.generator.DatabaseMetaManager;
import org.swaf.das.support.vo.VoGenerator;
import org.swaf.foundation.context.DasVO;
import org.swaf.foundation.prototype.DasModule;

import kr.ezinsurance.sample.vo.UserInfo;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserDM extends DasModule{
	
	
	
	public void selectMetaInfo() {

		//DataSource adminDS = (DataSource) APSBeanUtils.getBean("adminDS");
		
		//log.info("############################adminDS : {} #######################", adminDS);
		
		DatabaseMetaManager dbMetaMgr = new DatabaseMetaManager();
		
		String driverType = "MARIADB";
		String statementType = "INSERT";
		String schemaName = "ezins";
		String tableName = "tb_txlogs";
		String tableComment = "거래로그";
		boolean isAutoJdbcType = true;
		boolean isDynamic = false;
		
		
		String result = "";
		try {
		
			// 기본SQL maker
			//result = dbMetaMgr.generateSQL(driverType, dataSource, statementType, schemaName, tableName, tableComment, isAutoJdbcType, isDynamic);
			
			// VO maker
			VoGenerator voGenerator = new VoGenerator();
			voGenerator.makeMetaVO(driverType, dataSource, schemaName, tableName, "kr.ezinsurance.smple.vo", "TBTxLogs");
		
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		log.info("############################sql : {} #######################", result);

		
	}

	
	public List<UserInfo> selectUserList(String usrId) {

		List<DasVO<UserInfo>> userList = sqlSession.selectList("kr.ezinsurance.sample.selectUserList", usrId);
		
		log.info("############################selectUserList {}#######################", userList);
		return FwUtil.toArrayList(userList, UserInfo.class);
		
	}
	
}
