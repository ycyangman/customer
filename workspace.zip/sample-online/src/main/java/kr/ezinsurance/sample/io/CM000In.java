package kr.ezinsurance.sample.io;


import org.swaf.foundation.dto.DefaultDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CM000In extends DefaultDTO{

	String usrId;
	String usrNm;
	String usrPw;
}
