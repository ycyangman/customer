package kr.ezinsurance.sample.io;


import org.swaf.foundation.dto.DefaultDTO;

import kr.ezinsurance.sample.vo.UserInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CM000Out extends DefaultDTO{

	String usrId;
	String usrNm;
	
	UserInfo[] userList = null;
}
