package kr.ezinsurance.sample.svc;

import org.springframework.beans.BeanUtils;
import org.swaf.foundation.annotation.BM;
import org.swaf.foundation.annotation.Service;
import org.swaf.foundation.auth.AuthToken;
import org.swaf.foundation.context.OnlineApplicationContext;
import org.swaf.foundation.exception.BizException;
import org.swaf.foundation.service.ServiceExecutor;
import org.swaf.foundation.util.APSBeanUtils;
import org.swaf.foundation.util.ContextUtils;
import org.swaf.processor.support.auth.AuthResult;
import org.swaf.processor.support.auth.AuthTokenManager;

import kr.ezinsurance.sample.bm.LoginManager;
import kr.ezinsurance.sample.io.CM000In;
import kr.ezinsurance.sample.io.CM000Out;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service(authCheck=false)
public class CM000SVC extends ServiceExecutor<CM000In, CM000Out> {
	
	@BM
	@Setter
	LoginManager loginMgrBM;

	public CM000Out execute(CM000In in) {
		
		log.debug("CM000SVC executed!!");
		
		OnlineApplicationContext ctx = ContextUtils.getOnlineContext();
		
		CM000Out out = new CM000Out();
		String usrId = in.getUsrId();
		String usrPw = in.getUsrPw();
		
		log.info("#########user input{}#######################", in);
		
		AuthResult authResult = loginMgrBM.checkAuthById(usrId, usrPw);
		
		if(!authResult.equals(AuthResult.OK)) {
			BeanUtils.copyProperties(authResult, out);

			if(authResult.equals(AuthResult.NOT_EXISTS)) {
				throw new BizException("MZZ00005");
			}
			else if(authResult.equals(AuthResult.EXCEEED_ERR_COUNT)) {
				throw new BizException("MZZ00005");
			}
			else if(authResult.equals(AuthResult.WRONG_PW)) {
				//loginMgrBM.increaseLoingErrCount(in.getUsrId());
				
				throw new BizException("MZZ00004");
				
			}
		}
		
		AuthTokenManager authTokenManager = APSBeanUtils.getBean(AuthTokenManager.class);

		//기로그인 확인
		AuthToken token = authTokenManager.getAuthToken(usrId);
		
		log.info("#########AuthToken token{}#######################", token);
		
		if(token != null) {
			
			if(pm.getProperty("multi.login.allow").toLowerCase().equals("false")) {
				//기 발행된 토큰의 IP주소가 로그인한 사용자의 IP주소와 다른경우
				//이미 다른 자리에서 동일 아이디로 로그인 된 상태입
				//기존 토큰을 삭제함
				if(ctx.getUsrIpAd()!=null && !ctx.getUsrIpAd().equals(token.getUsrIpAd())) {
					authTokenManager.delToken(usrId);
					
					//다른 자링세서 로그인 된 Session은 강제 로그아웃 처리한다는 메시지 셋팅
					ctx.setAdMsg(mm.getMessage("MZZ00006", new String[] {token.getUsrIpAd()}));
					
					token = authTokenManager.issueToken(usrId);
				}
				else {
					authTokenManager.setTTL(token, Long.parseLong(pm.getProperty("login.kepp.peroid")));
				}
			}
		}
		else {
			token = authTokenManager.issueToken(usrId);
		}
	
		log.info("#########issueToken token{}#######################", token);
		
		//비밀번호 오류횟수를 0으로 리셋한다
//		loginMgrBM.resetLoingErrCount(in.getUsrId());
		
		BeanUtils.copyProperties(token, out);
		
		return out;
	}

}
