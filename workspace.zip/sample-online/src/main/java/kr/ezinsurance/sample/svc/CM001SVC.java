package kr.ezinsurance.sample.svc;

import java.util.List;

import org.springframework.util.ObjectUtils;
import org.swaf.foundation.annotation.BM;
import org.swaf.foundation.annotation.Service;
import org.swaf.foundation.service.ServiceExecutor;

import kr.ezinsurance.sample.bm.UserInfoMgrBM;
import kr.ezinsurance.sample.io.CM000In;
import kr.ezinsurance.sample.io.CM000Out;
import kr.ezinsurance.sample.vo.UserInfo;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service(authCheck=true)
public class CM001SVC extends ServiceExecutor<CM000In, CM000Out> {
	
	@BM
	@Setter
	UserInfoMgrBM userInfoMgrBM;

	
	
	public CM000Out execute(CM000In in) {
		
		log.debug("CM001SVC executed!!");
		
		CM000Out out = new CM000Out();
		String usrId = in.getUsrId();
		
		List<UserInfo> userList = userInfoMgrBM.getUserInfo(usrId);
		
		log.info("############################selectUserList {}#######################", userList);
		
		if(!ObjectUtils.isEmpty(userList)) {
			out.setUserList(userList.toArray(new UserInfo[userList.size()]));
		}
		
		return out;
	}

}
