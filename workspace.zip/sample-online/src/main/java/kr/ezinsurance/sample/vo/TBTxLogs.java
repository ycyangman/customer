package kr.ezinsurance.sample.vo;

import org.swaf.foundation.context.DefaultVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class TBTxLogs extends DefaultVO { 
	String guid; /*  */
	int lnkSqNo; /*  */
	int prgNo; /*  */
	int prcSqNo; /*  */
	String lnkSvcDscd; /*  */
	String ctxId; /*  */
	String svcId; /*  */
	String sysEvnDscd; /*  */
	String svcNm; /*  */
	String scrnNo; /*  */
	String txDt; /*  */
	String txBgnTm; /*  */
	String txEndTm; /*  */
	int procPd; /*  */
	String usrNo; /*  */
	String usrIpAd; /*  */
	String msgCd; /*  */
	String bascMsg; /*  */
	String adMsg; /*  */
	String exTraces; /*  */
} 