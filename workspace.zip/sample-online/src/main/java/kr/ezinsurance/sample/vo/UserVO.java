package kr.ezinsurance.sample.vo;


import org.swaf.foundation.context.DefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class UserVO extends DefaultVO{

	String usrId;
	String usrNm;
	String usrPw;
	
	int pwErrCnt;
}
